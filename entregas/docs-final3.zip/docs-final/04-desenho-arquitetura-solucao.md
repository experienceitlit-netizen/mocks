# 04 — Desenho de Arquitetura de Solução: Termo de Adesão Multiproduto (Cash Management / Payments)

> Traduz o desenho conceitual (`02-desenho-conceitual.md`) e o modelo de domínio (`03-dominios-bounded-contexts-context-mapping.md`) em **componentes físicos, integrações, rede, segurança, resiliência e decisões de arquitetura (ADR)**.
> Os IDs herdados (CAP-xx, APP-xx, PRI-xx, DEC-CON-xx, SD-xx, BC-xx, R-xx, RN-xx, RFN-xx, RNFN-xx, QA-xxx, PRM-xxx) não mudam. Os IDs criados aqui (RF-xx, RNF-xx, COMP-xx, ADR-xx, RSK-xx, QA-TEC-xx, PRM-TEC-xx) são estáveis.
> O detalhe de cada componente está em **`04a-componentes-e-justificativas.md`**. Os diagramas formais estão em **`04b-diagramas-c4.md`** (C4) e **`04c-diagramas-archimate.md`** (ArchiMate). Aqui ficam só diagramas Mermaid de apoio.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 04 — Desenho de Arquitetura de Solução |
| Versão | v0.5 |
| Data | 2026-10-16 |
| Status | Rascunho para validação com os times |
| Autor | Arquitetura de Soluções — Atacado (Cash Management / Payments) |
| Documentos base | `01-contexto-de-negocio.md` (v0.2), `02-desenho-conceitual.md` (v0.2), `03-dominios-bounded-contexts-context-mapping.md` (v0.1), `stack-tech.md` |
| Documentos derivados | `04a-componentes-e-justificativas.md`, `04b-diagramas-c4.md`, `04c-diagramas-archimate.md` |
| Público | Time do Atacado Cash Payments, Time de Canais, Time de Experiência, Time do GACD; apoio: Plataformas Funcionais, FIRP, IMPD, Segurança |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: drivers, componentes, fluxos, rede, segurança, resiliência, análise do IMPD, ADR-01..ADR-12, riscos, questões e premissas técnicas |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: refinamentos do `05-especificacoes-tecnicas.md` §17 incorporados (repetição com `Idempotency-Key` → `202` + `Idempotent-Replayed`; `correlationId` fora do corpo; dois campos de correlação; fila de tarefas interna e outbox com consumidor único; tabelas `produto_aderido`, `decisao_elegibilidade`, `tarefa`, `requisicao_idempotente`; saga com `etapa` + `estado`; egress por NetworkPolicy + EgressFirewall do namespace, DT-20; CPF possivelmente exigido pelo GACD, QA-TEC-24); Axway posicionado no "Hub (localização a confirmar — QA-TEC-09)"; nome canônico "Canal Digital PJ" |
| v0.3 | 2026-09-24 | (1) Alerta de assinantes inválidos separado em duas L2 (02 v0.5): RF-08 rastreia a **recepção** (CAP-09.5, COMP-02) e RF-09 a **notificação ao Gerente** (CAP-09.2, COMP-03); leituras da §4 e do Fluxo 3 explicitam as duas metades e a regra de domínio no COMP-01. (2) Passo que faltava no caminho feliz: o **Canal Digital PJ revalida os assinantes na FIRP** (RN-06) e **só depois** registra a assinatura no GACD — incluído na §4 (setas rotuladas) e no Fluxo 2 (§6.2, que passa a começar no Canal) |
| v0.4 | 2026-09-27 | Convênio com **etapa de implantação e homologação** feita por pessoas (Gerente de Cash ou backoffice, a definir — QA-CON-24), alinhado ao 01 v0.5 e ao 02 v0.7 (`instrucoes-ajustes.md`, item 8) **[PREMISSA: PRM-CON-15 — padrão de mercado]**. Revisados: §2.3, RF-12, COMP-01.6, COMP-20, nota do Fluxo 2 (§6.2), ADR-11 (a porta `convenio-produto`, quando ativada, tende a **abrir uma pendência de implantação** visível no Salesforce e acompanhar o status Em implantação → Convênio ativo, e não a criar o convênio por API; status reservados da jornada) e QA-TEC-11. Novo **RSK-18** (implantação técnica feita pelo Gerente de Cash) |
| v0.5 | 2026-10-16 | Rodada 6: a **revalidação dos assinantes na FIRP (RN-06) passa ao domínio do Atacado**: o COMP-02 `atacado-adesao-receptor` revalida no callback de assinatura do GACD e grava o resultado na inbox; o Canal Digital PJ só dá acesso ao termo e coleta a assinatura **[FATO: CG]**. Sai a API de alerta de assinantes inválidos (antiga §11.3, rota `atacado-adesao-alerta-canal`, N-06); RF-08, §4, Fluxos 2 e 3, §8, §11.3 e COMP-18 revisados; ADR-09 substituída pela nova **ADR-13**; RSK-06 encerrado; novos **RSK-19** (janela entre assinar e revalidar) e **RSK-20** (FIRP indisponível no callback); QA-TEC-08 encerrada |

### 1.1 Convenção de marcação

| Marca | Significado |
|---|---|
| **[FATO: xx]** | Suportado por fonte (`[01]`..`[06]`, `[stack]`, `[CG]` = Contexto Geral/reuniões) |
| **[PREMISSA: PRM-TEC-xx]** | Suposição técnica adotada para seguir com o desenho (seção 16) |
| **[HIPÓTESE]** | Sem fonte (ex.: token LEAP) |
| **[ABERTO: QA-TEC-xx]** | Depende de resposta registrada em Questões em aberto técnicas (seção 15) |
| **[DECISÃO: ADR-xx]** | Decisão de arquitetura registrada na seção 13 |

---

## 2. Objetivos e escopo

### 2.1 Objetivo

Definir a solução técnica que permite ao **Gerente de Cash** solicitar, revisar, enviar para assinatura e acompanhar o **Termo de Adesão** multiproduto a partir do **Salesforce**. Pelos **Serviços de Integração do Atacado** no **ARO Atacado** (`atacado-core`), a solução integra FIRP, geração de documento, GACD e o callback de assinatura, no qual o próprio Atacado revalida os assinantes na FIRP. O Canal Digital do Cliente (Canal Digital PJ) só dá acesso ao termo e coleta a assinatura no GACD. Também deixa o **Convênio** preparado para ser ligado depois, sem construir o que ainda não foi definido.

### 2.2 Em escopo (implementação do Atacado)

- API de adesão consumida pelo Salesforce (APP-02.1) e artefatos do Atacado no Salesforce (UI, Named Credential, objetos de status).
- Integração com FIRP (APP-02.2), geração do documento (APP-03), integração com GACD em 3 passos com saga (APP-02.3).
- Recepção do callback do GACD (APP-02.4) com a **revalidação dos assinantes na FIRP** no callback (CAP-04.2, RN-06), feita pelo COMP-02. A API de alerta para o Canal (antiga APP-02.6) foi removida na rodada 6.
- Estado de integração, inbox, outbox e trilha de auditoria (APP-02.7), e entrega de status e alertas ao Salesforce (APP-02.5).
- Infraestrutura da solução: namespace `atacado-core` no ARO Atacado, PostgreSQL gerenciado, Blob Storage de staging, Key Vault, rotas no Axway, regras de rede.

### 2.3 Fora de escopo

- **Canal Digital PJ** (BGS, PDPJ, canal unificado): **abstraído**. O Canal só dá a opção de acessar o termo e assiná-lo, e registra a assinatura no GACD. Não consulta a FIRP, não bloqueia a assinatura e não chama nenhuma API do Atacado **[FATO: CG]** (PRI-10). Não há contrato da solução com o Time de Canais.
- Evolução de FIRP, GACD, GCC/Filenet e IMPD (componentes corporativos consumidos).
- **Convênio** (BC-04) e cadastro de **Tarifas** (Databricks): nada é construído antes de QA-CON-02. Só a porta e os eventos-gatilho ficam prontos **[DECISÃO: ADR-11]**. A implantação do produto e a homologação do convênio com o cliente são feitas por pessoas (Gerente de Cash ou backoffice, a definir — QA-CON-24), no sistema do produto, fora da solução **[PREMISSA: PRM-CON-15 — padrão de mercado]**.
- Notificação por e-mail ao cliente (QA-CON-10).

---

## 3. Drivers arquiteturais

### 3.1 Restrições (não negociáveis)

| ID | Restrição | Origem |
|---|---|---|
| RST-01 | O Salesforce só se comunica com serviços no ARO Atacado. Nunca chama FIRP ou GACD diretamente | **[FATO: CG]** PRI-01, RN-09, R-03 |
| RST-02 | Os serviços ficam no **ARO**, namespace `atacado-core`, domínio Plataformas Funcionais, vNet spoke em Hub and Spoke | **[FATO: CG, stack]** |
| RST-03 | FIRP e GACD são consumidos pelo **Axway API Gateway** | **[FATO: CG]** PRI-07 |
| RST-04 | Canal externo entra por **Akamai → Azure Application Gateway → Axway → microsserviços** | **[FATO: stack]** |
| RST-05 | Java é prioritário para transações e operações; Python fica para dados | **[FATO: stack, CG]** PRI-09 |
| RST-06 | Segredos no **Azure Key Vault** | **[FATO: stack]** PRI-08 |
| RST-07 | O GACD recebe o documento como **base64** no passo "Armazenar Prévia", com **usuário sistêmico** | **[FATO: 04]** |
| RST-08 | O callback do GACD **não fica no Salesforce**. Fica na Azure, no ARO Atacado | **[FATO: CG]** |

### 3.2 Requisitos funcionais da solução (RF)

| ID | Requisito funcional da solução | Rastreio (01 / 02 / 03) |
|---|---|---|
| RF-01 | Receber do Salesforce a solicitação do Termo de Adesão (snapshot da Proposta: `idProposta`, CNPJ, produtos) com **idempotência** (`Idempotency-Key`) e resposta assíncrona (`202` + `idAdesao`) | RFN-01; CAP-02.3, CAP-10.1; comando `SolicitarTermoAdesao`; R-01 |
| RF-02 | Aplicar a política de **elegibilidade** (contrato vigente → adesão dispensada) e de **tipo de termo** (Produtos / Produtos + Canal), com a fonte atrás de uma porta substituível | RFN-02, RFN-03; RN-02, RN-03; CAP-02.1, CAP-02.2; INV-02, INV-04; QA-DDD-10 |
| RF-03 | Consultar na **FIRP** (via Axway) os representantes com poderes e traduzi-los em `Assinante` (snapshot mínimo) | RFN-04; RN-05; CAP-04.1; R-04 (ACL-FIRP) |
| RF-04 | **Gerar o documento** do Termo (PDF base64) a partir de modelo versionado por tipo, registrando versão do modelo e hash SHA-256 | CAP-03.1, CAP-03.3, CAP-08.1; BC-02; RNFN-01; DEC-CON-03 |
| RF-05 | Disponibilizar ao Gerente a **prévia** (assinantes + PDF) e receber a **confirmação de envio** antes de abrir o protocolo no GACD (configurável) | RFN-04; QA-NEG-18; DEC-CON-07; comando `ConfirmarAssinantes` (refinado, ADR-02) |
| RF-06 | Registrar o termo no **GACD** nas 3 etapas (Coordenar Contrato → Armazenar Prévia → Coordenar Regra) como **saga** com retentativa, compensação e reconciliação | RFN-05; RN-08; CAP-05.1..05.3; R-05; `ProcessoEnvioAssinatura` |
| RF-07 | Receber o **callback** do GACD, autenticar, validar, deduplicar por `codigoProtocolo` e aplicar a transição de estado só se o protocolo estiver vigente | RFN-08; RN-08; CAP-05.5, CAP-10.3; R-06; INV-07 |
| RF-08 | **Revalidar os assinantes na FIRP no recebimento do callback de assinatura** (COMP-02) e transformar a invalidez em `AssinantesInvalidados`. O COMP-02 grava o callback na inbox, consulta a FIRP via Axway (mesmo contrato do COMP-01), compara os assinantes do callback com os poderes vigentes e grava o resultado no sinal. Se a FIRP falhar, o sinal fica pendente de revalidação e é reprocessado; a assinatura nunca é confirmada sem revalidar. A transição (Assinado ou Assinantes inválidos) é aplicada no COMP-01 **[FATO: CG]** | RFN-07; RN-06, RN-07; CAP-04.2, CAP-05.5, CAP-10.3; R-12; INV-08; ADR-13 |
| RF-09 | Projetar a **visão da jornada** e entregar **status e alertas** ao Salesforce com consistência eventual, ordem por agregado e reentrega. Inclui a **notificação ao Gerente**: ler `AssinantesInvalidados` da outbox, criar o `AlertaGerente` e fazer o upsert em `Alerta_Adesao__c`, com retentativa | RFN-07, RFN-08; CAP-09.1, CAP-09.2, CAP-10.4; BC-03; R-02 |
| RF-10 | Permitir ao Gerente **reemitir** (após falha ou assinantes inválidos) e **cancelar** o termo | Estados canônicos (01 §7.4); `ReemitirTermo`, `EncerrarTermo`; QA-NEG-12 |
| RF-11 | Permitir ao Salesforce **consultar** a adesão (estado, assinantes resumidos, protocolo) e baixar a prévia. O termo assinado depende da API do GACD | RFN-11; CAP-03.2; QA-NEG-17, QA-TEC-18 |
| RF-12 | Publicar os eventos-gatilho do **Convênio** (`AssinaturaConcluida`, `AdesaoDispensada`) na outbox, com a porta `convenio-produto` **desativada** até QA-CON-02. O gatilho **abre a implantação** do produto (EVN-13), não cria o convênio: quando ativada, a porta tende a abrir uma **pendência de implantação** visível no Salesforce e acompanhar o status (Em implantação → Convênio ativo) | RFN-09, RFN-10; RN-10..RN-13, RN-17; CAP-06; R-15; EVN-13, EVN-10; QA-CON-24; ADR-11; RSK-18 |
| RF-13 | Registrar a **trilha de auditoria** ponta a ponta e os eventos da jornada para os KPIs | RFN-12; RNFN-01, RNFN-07; CAP-12.1, CAP-09.4 |
| RF-14 | Oferecer **reprocessamento operacional**: retomar saga, reprocessar sinal da inbox, reentregar mensagem estacionada | CAP-10.4; §5.3 do 03 (estacionamento) |

### 3.3 Requisitos não funcionais da solução (RNF)

Metas numéricas são **[PREMISSA: PRM-TEC-03]** (volumetria) e **[PREMISSA: PRM-TEC-13]** (níveis de serviço) até que o negócio as confirme.

| ID | Categoria | Requisito não funcional | Meta / critério de aceite | Rastreio |
|---|---|---|---|---|
| RNF-01 | Segurança | Autenticação e autorização em **todas** as fronteiras: nenhum acesso anônimo; nenhum caminho direto Salesforce → FIRP/GACD | OAuth 2.0 + mTLS na entrada externa; token LEAP **[HIPÓTESE]** ou equivalente no Axway interno; teste de intrusão sem achados críticos | PRI-01, PRI-07; CAP-11.1; RST-01 |
| RNF-02 | Segurança | 100% dos segredos (credenciais, chaves privadas, certificados) no **Azure Key Vault**, com rotação sem redeploy | 0 segredos em código, imagem ou ConfigMap; rotação ≤ 90 dias | PRI-08; CAP-11.2 |
| RNF-03 | Segurança / rede | Segmentação **Hub and Spoke**: dados só por private endpoint; ingress só pelo Axway; egress só para destinos liberados | Acesso público desabilitado em PostgreSQL, Blob e Key Vault; NetworkPolicy "deny-all" por padrão | CAP-11.3; RST-02 |
| RNF-04 | Privacidade (LGPD) | Minimização de dados de representantes; mascaramento em logs; retenção limitada do PDF em staging | Nenhum CPF em logs ou eventos; PDF apagado do staging em ≤ 30 dias; criptografia em repouso e em trânsito (TLS 1.2+) | RNFN-05; PRM-DDD-08 |
| RNF-05 | Confiabilidade | Entrega **at-least-once** com consumidores **idempotentes**; nenhum callback confirmado (ACK) é perdido, inclusive quando a revalidação na FIRP falha | ACK só após commit; deduplicação por chave de negócio; ordem garantida por agregado | PRI-05, PRI-06; INV-10; CAP-10.4 |
| RNF-06 | Desempenho | Status no Salesforce em tempo quase real | p95 ≤ 60 s entre o commit do evento e o registro no Salesforce (Salesforce disponível) | RNFN-03; KPI-04; CAP-09.1 |
| RNF-07 | Desempenho | Resposta rápida ao Gerente e processamento assíncrono das etapas | `POST /v1/adesoes` p95 ≤ 1 s; Solicitado → Gerado p95 ≤ 60 s; confirmação → Aguardando assinatura p95 ≤ 90 s (dependente de FIRP/IMPD/GACD) | OE-02; RFN-01 |
| RNF-08 | Disponibilidade | Recepção do callback mais disponível que o restante; o ACK ao GACD não depende da FIRP | `atacado-adesao-receptor` ≥ 99,9%/mês; demais ≥ 99,5%/mês; RPO = 0 para sinais com ACK; RTO ≤ 1 h | CAP-05.5, CAP-10.3 |
| RNF-09 | Resiliência | Falhas transitórias de dependências tratadas sem intervenção humana; falhas persistentes isoladas e visíveis | Timeouts explícitos, retry com backoff e jitter, circuit breaker por dependência, estacionamento após N tentativas | CAP-10; §5.3 do 03 |
| RNF-10 | Rastreabilidade | Trilha de auditoria **append-only**, correlacionada ponta a ponta | 100% das transições com `idAdesao`, `codigoProtocolo`, ator, versão do modelo e hash; `correlationId` em 100% dos logs | RNFN-01, RNFN-02; CAP-12.1; PRI-11 |
| RNF-11 | Observabilidade | Métricas, logs e traces por etapa; alertas operacionais; dados para KPIs | Painel por etapa (FIRP, documento, GACD, callback, entrega); alerta para mensagem estacionada e saga em falha | RNFN-07; RFN-12; CAP-09.4 |
| RNF-12 | Capacidade | Dimensionamento para volume baixo e escala horizontal | Até 500 solicitações/dia, pico de 50/h, PDF ≤ 1 MB (PRM-TEC-03); escala ×10 sem mudança de arquitetura | PRM-TEC-03 |
| RNF-13 | Evolutividade | Dependências externas trocáveis por porta/adaptador: GACD ↔ Open Cash Hub, IMPD ↔ geração própria, Convênio (A/B/C) | Troca sem alterar a API Adesão (R-01) nem o contrato de status (R-02) | PRI-13, PRI-12; DEC-CON-01, DEC-CON-03 |
| RNF-14 | Conformidade | Evidência documental: todo documento carrega versão de modelo aprovada e hash. O termo assinado fica no repositório corporativo | Modelo com aprovação de Jurídico/Compliance registrada; hash enviado = hash auditado | RNFN-02, RNFN-04, RNFN-06; CAP-12.2, CAP-03.3 |
| RNF-15 | Interoperabilidade | Payloads base64 compatíveis com os limites de Axway, WAF e APIs | PDF ≤ 1 MB (≈ 1,33 MB em base64) nominal; limite técnico configurável até 5 MB; o PDF não trafega pelo Salesforce na ida ao GACD | **[FATO: 04]** base64; QA-TEC-10 |
| RNF-16 | Operabilidade | Reprocessamento, feature flags e runbooks | Endpoints administrativos internos (sem rota externa); flags para confirmação do Gerente, renderizador e convênio | CAP-10.4 |

### 3.4 Princípios herdados que mais pesam nas decisões

PRI-01 (Salesforce não integra direto), PRI-02 (ARO Atacado como ACL), PRI-03 (reusar antes de construir), PRI-05 (outbox), PRI-06 (idempotência), PRI-10 (Canal abstraído por contrato), PRI-12 (Termo × Convênio separados), PRI-13 (gerenciador de termos substituível) — ver 02 §6.

---

## 4. Visão macro da solução

```mermaid
flowchart LR
  GC(["Gerente de Cash"])
  subgraph SFX["Salesforce Financial Services Cloud - SaaS"]
    SF["COMP-06 Artefatos Salesforce do Atacado<br/>UI da jornada, Named Credential,<br/>Adesao_Termo__c e Alerta_Adesao__c"]
  end
  subgraph EDGE["Entrada de canais externos"]
    AK["COMP-07 Akamai"]
    AGW["COMP-08 Azure Application Gateway WAF"]
  end
  AXW["COMP-09 Axway API Gateway<br/>políticas externas e internas"]
  subgraph ARO["COMP-10 ARO Atacado - namespace atacado-core"]
    C1["COMP-01 atacado-adesao-termo<br/>BC-01 núcleo + BC-02 módulo termo-documento<br/>API Adesão, saga GACD, ACL-FIRP"]
    C2["COMP-02 atacado-adesao-receptor<br/>BC-01 borda de entrada<br/>callback GACD e revalidação<br/>dos assinantes na FIRP"]
    C3["COMP-03 atacado-adesao-acompanhamento<br/>BC-03 relay da outbox, projeção,<br/>status e alertas ao Salesforce"]
  end
  subgraph DADOS["Serviços de dados Azure - private endpoint"]
    DB[("COMP-04 atacado-adesao-db<br/>PostgreSQL Flexible Server<br/>estado, saga, inbox, outbox, auditoria")]
    BLOB[("COMP-05 atacado-adesao-staging<br/>Blob Storage - PDF transitório")]
    KV["COMP-11 Azure Key Vault"]
  end
  subgraph CORP["Componentes corporativos consumidos"]
    FIRP["COMP-13 FIRP"]
    GACD["COMP-14 GACD"]
    GCC["COMP-15 GCC/Filenet"]
    IMPD["COMP-16 IMPD API cloud<br/>impd-srv-doc-generator"]
  end
  CAN["COMP-18 Canal Digital PJ<br/>abstraído - Time de Canais<br/>acesso ao termo e assinatura"]

  GC --> SF
  SF -->|"1 API Adesão - HTTPS, OAuth2 e mTLS"| AK
  AK --> AGW
  AGW --> AXW
  AXW -->|"rota externa"| C1
  C1 -->|"FIRP e GACD via Axway interno"| AXW
  AXW --> FIRP
  AXW --> GACD
  C1 -.->|"renderização - rota a confirmar"| IMPD
  C1 --> DB
  C1 --> BLOB
  GACD --> GCC
  GACD -.->|"2 callback de assinatura"| AXW
  AXW -.->|"rota interna"| C2
  C2 -->|"3 revalida assinantes na FIRP via Axway - RN-06"| AXW
  C2 -->|"inbox com o resultado"| DB
  DB -->|"outbox"| C3
  C3 -->|"4 status e alertas - REST, OAuth JWT Bearer"| SF
  CAN -->|"a busca a pendência e registra a assinatura"| GACD
  C1 -.-> KV
  C2 -.-> KV
  C3 -.-> KV

  classDef novo fill:#e3f2fd,stroke:#1565c0,color:#000
  classDef corp fill:#e8f5e9,stroke:#2e7d32,color:#000
  classDef ext fill:#eeeeee,stroke:#616161,stroke-dasharray:4 3,color:#000
  class C1,C2,C3,DB,BLOB,SF novo
  class AK,AGW,AXW,KV,FIRP,GACD,GCC,IMPD corp
  class CAN ext
```

**Leitura:**

1. **Entrada do Salesforce** (1): só pelo padrão de canal externo (RST-04) e só para o `atacado-adesao-termo`, que expõe a API Adesão (OHS, R-01) e orquestra FIRP → documento → GACD **[DECISÃO: ADR-02, ADR-07]**.
2. **Assinatura no Canal** (a, fora do escopo do Atacado): o Canal Digital PJ busca a pendência no GACD, **só dá a opção de acessar o termo e assiná-lo** e registra a assinatura no GACD. Não consulta a FIRP e não chama nenhuma API do Atacado **[FATO: CG]**.
3. **Callback e revalidação** (2 e 3): o callback do GACD entra por rota **interna** do Axway em um deployable separado e altamente disponível, o `atacado-adesao-receptor`. Ele autentica, traduz (ACL), deduplica e grava na **inbox** (CAP-05.5). Em seguida, **revalida os assinantes na FIRP** (RN-06, CAP-04.2) e grava o resultado no sinal: assinatura confirmada ou `AssinantesInvalidados`. A revalidação acontece **depois** de a assinatura ser registrada no GACD, não antes. O receptor não aplica regra de estado do termo: quem muda o estado é o COMP-01 **[DECISÃO: ADR-01, ADR-08, ADR-13]**.
4. **Saída para o Salesforce** (4): nenhum componente chama o Salesforce dentro de uma transação de negócio. O `atacado-adesao-acompanhamento` lê a **outbox**, projeta a jornada (BC-03) e entrega status e alertas — é a **notificação ao Gerente** (CAP-09.1, CAP-09.2) **[DECISÃO: ADR-05, ADR-06]**.
5. **Documento:** o PDF é gerado pelo IMPD (Plano A) ou por um renderizador próprio (Plano B) atrás da mesma porta. Ele fica em **staging transitório** no Blob até ser enviado ao GACD, que guarda a versão oficial no GCC/Filenet **[DECISÃO: ADR-03, ADR-04]**.

---

## 5. Componentes da solução (resumo)

O detalhe (responsabilidade, stack, interfaces, dados, justificativa, RF/RNF, dono, riscos) está em `04a-componentes-e-justificativas.md`.

### 5.1 Componentes novos (construídos ou configurados pelo Atacado)

| ID | Nome técnico | Tipo | BC | Hospedagem | Responsabilidade resumida |
|---|---|---|---|---|---|
| COMP-01 | `atacado-adesao-termo` | Microsserviço Java 21 / Spring Boot 3 (monólito modular) | BC-01 (núcleo), BC-02 (módulo) | ARO Atacado, `atacado-core` | API Adesão (Salesforce); agregado `AdesaoTermo`; políticas; ACL-FIRP; ACL-GACD + saga; processamento da inbox; módulo `termo-documento`; porta `convenio-produto` desativada; outbox e auditoria |
| COMP-01.1 | módulo `adesao-termo` | Módulo (pacote) | BC-01 | dentro de COMP-01 | Domínio, API Adesão, processamento de sinais da inbox |
| COMP-01.2 | módulo `acl-firp` | Adaptador (porta `ConsultaAssinantesPort`) | BC-01 | dentro de COMP-01 | Consulta e tradução FIRP → `Assinante` |
| COMP-01.3 | módulo `acl-gacd` | Adaptador + process manager (saga) | BC-01 | dentro de COMP-01 | 3 chamadas GACD, retentativa, compensação, reconciliação |
| COMP-01.4 | módulo `termo-documento` | Módulo (porta `RenderizadorDocumento`) | BC-02 | dentro de COMP-01 | Catálogo de modelos, composição, adaptador IMPD (Plano A) e renderizador próprio (Plano B, desligado) |
| COMP-01.5 | módulo `acl-registro-contratos` | Adaptador (porta `ElegibilidadePort`) | BC-01 (ACL para BC-13) | dentro de COMP-01 | Elegibilidade e tipo de termo; enquanto QA-CON-21 estiver aberta, usa o indicador enviado pelo Salesforce |
| COMP-01.6 | módulo `convenio-produto` | Porta (`SolicitacaoConvenioPort`) — **desativada** | BC-04 (fronteira) | dentro de COMP-01 | Só contrato e flag; nenhuma implementação (ADR-11). Quando ativada, tende a **abrir uma pendência de implantação** (tarefa para o Gerente ou o backoffice, visível no Salesforce) e acompanhar o status (Em implantação → Convênio ativo), e não a criar o convênio por API no sistema do produto (RSK-18) |
| COMP-02 | `atacado-adesao-receptor` | Microsserviço Java 21 / Spring Boot 3 | BC-01 (ACL de entrada) | ARO Atacado, `atacado-core` | Endpoint de callback do GACD; autenticação complementar, validação de esquema, tradução, deduplicação e gravação na inbox; ACK; **revalidação dos assinantes na FIRP** (via Axway) e gravação do resultado no sinal (CAP-04.2, ADR-13) |
| COMP-03 | `atacado-adesao-acompanhamento` | Microsserviço Java 21 / Spring Boot 3 (worker) | BC-03 | ARO Atacado, `atacado-core` | Relay da outbox (polling), projeção `VisaoJornadaAdesao`, alertas ao Gerente, entrega ao Salesforce (REST, OAuth JWT Bearer), estacionamento e reentrega |
| COMP-04 | `atacado-adesao-db` | Azure Database for PostgreSQL Flexible Server | BC-01, BC-02, BC-03 (um schema por BC) | Spoke Plataformas Funcionais (subnet delegada / acesso privado) | Estado, saga, inbox, outbox, projeção, auditoria, catálogo de modelos |
| COMP-05 | `atacado-adesao-staging` | Azure Blob Storage (container `termos-staging`) | BC-02 | Spoke (private endpoint) | Guarda transitória do PDF (prévia, reprocessamento da saga), com lifecycle ≤ 30 dias |
| COMP-06 | Artefatos Salesforce do Atacado | Configuração em SaaS (LWC/Flow, Named/External Credential, Connected App, objetos customizados) | BC-05 | Salesforce FSC | Jornada do Gerente; chamada à API Adesão; recepção de status e alertas; notificação ao Gerente |

### 5.2 Componentes corporativos consumidos

| ID | Componente | Papel na solução | Dono |
|---|---|---|---|
| COMP-07 | Akamai | Borda de entrada do Salesforce (WAF, mTLS, allowlist de IPs) | Plataformas Funcionais / Segurança |
| COMP-08 | Azure Application Gateway (WAF v2) | Load balance e WAF na entrada | Plataformas Funcionais |
| COMP-09 | Axway API Gateway | Políticas de entrada (Salesforce, GACD) e saída (FIRP para COMP-01 e COMP-02, GACD, IMPD se exigido) | Plataformas Funcionais |
| COMP-10 | ARO Atacado (`atacado-core`) | Plataforma de contêineres | Plataformas Funcionais |
| COMP-11 | Azure Key Vault | Segredos, chaves e certificados | Atacado Cash Payments (cofre da solução) / Segurança (política) |
| COMP-12 | vNet Hub (Azure Firewall / egress) | Egress controlado ARO → Salesforce e demais destinos | Plataformas Funcionais |
| COMP-13 | FIRP | Fonte de representantes e poderes | FIRP |
| COMP-14 | GACD | Aceite digital: protocolo, prévia, regras, callback | GACD |
| COMP-15 | GCC/Filenet | Repositório da prévia/termo (via GACD) | GACD (consumo) |
| COMP-16 | IMPD API cloud `impd-srv-doc-generator` | Renderização do PDF (Plano A) | IMPD |
| COMP-17 | Emissor de token LEAP **[HIPÓTESE]** | Token de workload para APIs via Axway | Segurança |
| COMP-18 | Canal Digital PJ | Pendências, acesso ao termo e assinatura (registrada no GACD); notificação ao cliente. Sem revalidação na FIRP e sem chamada ao Atacado | Canais (com Experiência) |
| COMP-19 | Observabilidade corporativa | Coleta de logs, métricas e traces (OpenTelemetry) | Plataformas Funcionais |
| COMP-20 | Databricks (Tarifas) | Fora do escopo desta entrega; futuro consumidor de convênios **ativos** (após a homologação, RN-17) | Atacado Cash Payments |

### 5.3 Tratamento das orientações recebidas (aceitas, ajustadas, rejeitadas)

| Orientação | Decisão | Onde ficou | Por quê |
|---|---|---|---|
| Salesforce → microsserviço integrador com FIRP | **Ajustada**: a integração FIRP existe, mas como **módulo ACL** (COMP-01.2) acionado pela orquestração no ARO, não pelo Salesforce | COMP-01.2 | Um microsserviço por ACL cria serviço anêmico e transação distribuída (03 §8.2, PRM-DDD-04). Se o Salesforce chamar cada serviço, a saga fica espalhada em Apex (ADR-02) |
| Salesforce → microsserviço gerador de PDF base64 → Storage de staging | **Ajustada**: geração no módulo `termo-documento` (COMP-01.4), com staging em Blob **aceito** (COMP-05) | COMP-01.4, COMP-05 | O Salesforce não precisa tocar no PDF na ida ao GACD (limites de heap e payload). O staging se justifica pela prévia do Gerente e pelo reprocessamento (ADR-04) |
| Salesforce → microsserviço integrador com GACD (envia base64 + assinantes) | **Ajustada**: ACL-GACD + saga no COMP-01.3, acionada pela confirmação do Gerente | COMP-01.3 | As 3 chamadas exigem saga com compensação local e o PDF vem do staging. Nada disso deve ficar no Salesforce (ADR-02) |
| Microsserviço de callback que integra com o Salesforce e salva em outbox | **Ajustada**: o receptor (COMP-02) **não** chama o Salesforce. Ele grava na inbox e responde o ACK. O núcleo aplica a transição e grava na outbox; o COMP-03 entrega | COMP-02, COMP-01, COMP-03 | Chamar o Salesforce e gravar a outbox no mesmo fluxo é *dual write*: se o Salesforce estiver fora, o callback falha ou se perde. Com a separação, o ACK ao GACD não depende da disponibilidade do Salesforce (ADR-05, ADR-08) |
| PostgreSQL (outbox table) | **Aceita**, como Azure Database for PostgreSQL Flexible Server, com registro de premissa (fora do `stack-tech.md`) | COMP-04 | Transação local estado + outbox; baixo volume; sem broker confirmado (ADR-05) |
| Canal abstraído; API no ARO para avisar o Gerente quando os assinantes forem inválidos | **Substituída na rodada 6 (2026-10-16)**: o Canal continua abstraído, mas não há API para ele. O próprio Atacado revalida os assinantes na FIRP no callback (COMP-02) e o COMP-03 avisa o Gerente no Salesforce | COMP-02, COMP-03, §11.3 | ADR-13 (substitui a ADR-09): o Canal só dá acesso ao termo e coleta a assinatura **[FATO: CG]** |
| IMPD para gerar o termo (dúvida de maturidade e on-premise) | **Aceita com condição**: IMPD **API cloud** como Plano A, sujeito a gate técnico; geração própria como Plano B pronto. IMPD mainframe **rejeitado** | COMP-16, COMP-01.4 | §12 e ADR-03 |

---

## 6. Fluxos principais

### 6.1 Fluxo 1 — Geração e envio do termo para assinatura

```mermaid
sequenceDiagram
  autonumber
  actor GC as Gerente de Cash
  participant SF as Salesforce COMP-06
  participant BX as Borda externa Akamai AppGW Axway
  participant T as atacado-adesao-termo COMP-01
  participant DB as atacado-adesao-db COMP-04
  participant AXI as Axway interno
  participant FIRP as FIRP
  participant DOC as Renderizador IMPD ou próprio
  participant BL as Blob staging COMP-05
  participant GACD as GACD
  participant AC as atacado-adesao-acompanhamento COMP-03

  GC->>SF: Solicita Termo de Adesão da Proposta aprovada
  SF->>BX: POST /v1/adesoes com Idempotency-Key, OAuth2 e mTLS
  BX->>T: Encaminha requisição autenticada
  T->>T: Elegibilidade e tipo de termo - ElegibilidadePort
  T->>DB: Cria AdesaoTermo Solicitado e outbox TermoSolicitado na mesma transação
  T-->>SF: 202 Accepted com idAdesao
  Note over T: Etapas seguintes assíncronas no worker da saga do COMP-01
  T->>AXI: Consulta representantes com poderes - token LEAP hipótese
  AXI->>FIRP: Encaminha
  FIRP-->>T: Representantes e poderes
  T->>DB: Assinantes identificados e outbox AssinantesIdentificados
  T->>DOC: Gera documento com tipo, versão do modelo e variáveis
  DOC-->>T: PDF em base64
  T->>BL: Grava PDF em termos-staging por idAdesao e tentativa
  T->>DB: Gerado com versaoModelo, hash SHA-256, referência do blob e outbox TermoGerado
  AC->>DB: Lê outbox em ordem por agregado
  AC->>SF: Upsert Adesao_Termo__c status Gerado e assinantes resumidos
  GC->>SF: Abre a prévia
  SF->>BX: GET /v1/adesoes/id/documento
  BX->>T: Encaminha
  T->>BL: Lê PDF
  T-->>SF: application/pdf
  GC->>SF: Confirma assinantes e prévia
  SF->>BX: POST /v1/adesoes/id/confirmacao-envio
  BX->>T: Encaminha
  T->>DB: AssinantesConfirmados e saga criada na etapa 1
  T-->>SF: 202 Accepted
  T->>AXI: Passo 1 Coordenar Contrato com assinantes e callbackUrl
  AXI->>GACD: Encaminha
  GACD-->>T: codigoProtocolo
  T->>DB: Saga etapa 1 concluída - ProtocoloAberto
  T->>BL: Lê PDF e confere hash
  T->>AXI: Passo 2 Armazenar Prévia com base64 e usuário sistêmico
  AXI->>GACD: Encaminha
  GACD-->>T: IdPrevia e CaminhoPrevia
  T->>DB: Saga etapa 2 concluída - PreviaArmazenada
  T->>AXI: Passo 3 Coordenar Regra
  AXI->>GACD: Encaminha
  GACD-->>T: Prévia e regras confirmadas
  T->>DB: Aguardando assinatura e outbox TermoEnviadoParaAssinatura
  AC->>SF: Upsert status Aguardando assinatura e codigoProtocolo
  SF-->>GC: Termo enviado para assinatura
```

**Leitura:** os 3 passos do GACD e seus retornos são **[FATO: 04]**. Gerar o PDF antes do passo 1 é PRM-CON-06. A confirmação do Gerente fica atrás de uma flag (`adesao.confirmacao-gerente.habilitada=true`) até QA-NEG-18 ser respondida. Com a flag desligada, a saga começa logo depois de `TermoGerado`. Com contrato vigente, o fluxo termina no passo 5 com `AdesaoDispensada` (status da jornada "Não requerido").

### 6.2 Fluxo 2 — Assinatura no Canal, callback, revalidação no Atacado → outbox → Salesforce

```mermaid
sequenceDiagram
  autonumber
  actor CLI as Assinante do Cliente PJ Atacado
  participant CAN as Canal Digital PJ - abstraído
  participant GACD as GACD
  participant AXI as Axway interno
  participant R as atacado-adesao-receptor COMP-02
  participant FIRP as FIRP
  participant DB as atacado-adesao-db COMP-04
  participant T as atacado-adesao-termo COMP-01
  participant AC as atacado-adesao-acompanhamento COMP-03
  participant SF as Salesforce COMP-06
  actor GC as Gerente de Cash

  CLI->>CAN: Acessa pendências de assinatura
  CAN->>GACD: Busca termos pendentes do cliente
  GACD-->>CAN: Termo pendente com codigoProtocolo
  CLI->>CAN: Acessa o termo e assina
  CAN->>GACD: Registra a assinatura
  Note over CAN,GACD: O Canal não consulta a FIRP, não bloqueia a assinatura e não chama o Atacado
  GACD->>AXI: POST callback de assinatura concluída com codigoProtocolo
  AXI->>AXI: Autentica o GACD - mTLS ou token, QA-TEC-07
  AXI->>R: POST /v1/callbacks/gacd/assinaturas/idAdesao
  R->>R: Valida esquema e traduz para SinalExterno canônico - ACL
  R->>DB: INSERT inbox AGUARDANDO_REVALIDACAO com chave GACD, codigoProtocolo e tipoSinal - ON CONFLICT DO NOTHING
  R-->>AXI: 200 OK somente após commit, inclusive para duplicado
  AXI-->>GACD: ACK
  R->>AXI: Revalida assinantes na FIRP - RN-06, mesmo contrato do COMP-01
  AXI->>FIRP: Encaminha
  FIRP-->>R: Representantes com poderes vigentes
  R->>R: Compara os assinantes do callback com os poderes vigentes
  R->>DB: Sinal RECEBIDO com resultado VALIDOS
  Note over R,FIRP: Com assinantes inválidos, segue o Fluxo 3. Com a FIRP indisponível, o sinal fica pendente e é revalidado de novo com backoff
  T->>DB: Busca sinais RECEBIDO da inbox com SKIP LOCKED
  alt Protocolo vigente, estado Aguardando assinatura e assinantes válidos
    T->>DB: Assinado, outbox AssinaturaConcluida, auditoria e inbox PROCESSADO na mesma transação
  else Protocolo anterior, desconhecido ou estado incompatível
    T->>DB: Inbox IGNORADO ou QUARENTENA, auditoria e alerta operacional
  end
  AC->>DB: Lê outbox em ordem por idAdesao e versaoAgregado
  AC->>DB: Atualiza VisaoJornadaAdesao e cria EntregaStatus na mesma transação
  AC->>SF: Obtém token OAuth 2.0 JWT Bearer - cache
  AC->>SF: Upsert Adesao_Termo__c por Id_Adesao__c com status Assinado e versao
  SF-->>AC: 200 ou 201
  AC->>DB: EntregaStatus CONFIRMADA
  SF-->>GC: Notificação de termo assinado
  opt Salesforce indisponível ou erro 5xx ou 429
    AC->>AC: Retentativa com backoff exponencial e jitter por até 24 h
    AC->>DB: Após limite, EntregaStatus ESTACIONADA e alerta operacional
  end
  Note over T,AC: AssinaturaConcluida fica disponível como gatilho da implantação do Convênio - abre a implantação e não cria o convênio - porta convenio-produto desativada, ADR-11
```

**Leitura:** os passos 1 a 5 são do Canal Digital PJ (Time de Canais, fora do escopo de implementação do Atacado): o Canal só dá acesso ao termo e registra a assinatura no GACD **[FATO: CG]**. A **revalidação na FIRP (RN-06) é do Atacado** e acontece **depois** de a assinatura estar registrada no GACD, no recebimento do callback (CAP-04.2, ADR-13). O ACK ao GACD depende só do commit na inbox, não da FIRP, do Salesforce nem do processamento do domínio (RNF-05, RNF-08). O sinal só fica disponível ao COMP-01 (`RECEBIDO`) depois da revalidação: a assinatura nunca é confirmada sem revalidar. Se a FIRP falhar, o sinal continua `AGUARDANDO_REVALIDACAO` e o COMP-02 refaz a consulta com backoff, sem descartar o sinal (RSK-20). Com assinantes inválidos, segue o Fluxo 3. A regra INV-07 (protocolo vigente) é aplicada no núcleo (COMP-01), não no receptor. O `idAdesao` no caminho da callbackUrl é redundância de correlação e **não** substitui a validação por `codigoProtocolo`.

### 6.3 Fluxo 3 — Atacado detecta assinantes inválidos na revalidação do callback → Salesforce/Gerente

```mermaid
sequenceDiagram
  autonumber
  actor CLI as Assinante do Cliente PJ Atacado
  participant CAN as Canal Digital PJ - abstraído
  participant GACD as GACD
  participant AXI as Axway interno
  participant R as atacado-adesao-receptor COMP-02
  participant FIRP as FIRP
  participant DB as atacado-adesao-db COMP-04
  participant T as atacado-adesao-termo COMP-01
  participant AC as atacado-adesao-acompanhamento COMP-03
  participant SF as Salesforce COMP-06
  actor GC as Gerente de Cash

  CLI->>CAN: Acessa o termo pendente e assina
  CAN->>GACD: Registra a assinatura
  GACD->>AXI: POST callback de assinatura concluída com codigoProtocolo
  AXI->>R: Encaminha pela rota interna
  R->>DB: INSERT inbox AGUARDANDO_REVALIDACAO - ON CONFLICT DO NOTHING
  R-->>GACD: 200 OK após commit, via Axway
  R->>AXI: Revalida assinantes na FIRP - RN-06
  AXI->>FIRP: Encaminha
  FIRP-->>R: Poderes vigentes
  R->>R: Compara e encontra assinante sem poder vigente
  R->>DB: Sinal RECEBIDO com resultado INVALIDOS, motivo e quantidade, sem dado pessoal
  T->>DB: Processa inbox e valida protocolo vigente e estado Aguardando assinatura
  T->>DB: Assinantes inválidos e outbox AssinantesInvalidados na mesma transação
  AC->>DB: Lê outbox
  AC->>SF: Upsert status Assinantes inválidos e cria Alerta_Adesao__c do tipo ASSINANTES_INVALIDOS
  SF-->>GC: Notificação e tarefa para regularizar poderes e reemitir
  GC->>SF: Reemitir termo depois da regularização na FIRP
  SF->>T: POST /v1/adesoes/id/reemissao via borda externa
  T->>DB: ReemissaoSolicitada - volta a Solicitado com tentativa incrementada
  Note over T,GACD: Nova consulta FIRP, novo documento e novo protocolo. O destino do protocolo já assinado no GACD está em aberto, QA-NEG-20. Hoje o protocolo anterior é cancelado se houver API, QA-TEC-06
  opt FIRP indisponível ou timeout
    R->>DB: Sinal continua AGUARDANDO_REVALIDACAO com próxima tentativa agendada
    R->>AXI: Nova revalidação com backoff, sem descartar o sinal
  end
```

**Leitura:** a detecção e a notificação ficam em componentes diferentes. A **detecção** (COMP-02, CAP-04.2) recebe o callback, grava na inbox, responde o ACK, revalida na FIRP e grava o resultado no sinal, **sem regra de estado do termo**. O **COMP-01** aplica a regra de domínio (INV-08, estado Assinantes inválidos). A **notificação ao Gerente** (COMP-03, CAP-09.2) lê `AssinantesInvalidados` da outbox, cria o `AlertaGerente` e faz o upsert em `Alerta_Adesao__c`, com retentativa. O Canal não participa: ele já registrou a assinatura no GACD e não é avisado pelo Atacado. Como a revalidação ocorre **depois** da assinatura registrada no GACD, há uma janela em que o protocolo está assinado no GACD e o termo ainda não (RSK-19). O que fazer com esse protocolo (cancelar no GACD, invalidar o termo, exigir nova assinatura e quem executa) está em aberto em **QA-NEG-20**. Até a resposta, vale o tratamento de hoje: estado Assinantes inválidos, alerta ao Gerente e reemissão **[DECISÃO: ADR-13]**.

### 6.4 Fluxo 4 — Falha e compensação na saga do GACD

```mermaid
sequenceDiagram
  autonumber
  participant T as atacado-adesao-termo COMP-01
  participant DB as atacado-adesao-db COMP-04
  participant GACD as GACD via Axway
  participant AC as atacado-adesao-acompanhamento COMP-03
  participant SF as Salesforce COMP-06
  participant OPS as Operação Atacado

  T->>GACD: Passo 1 Coordenar Contrato
  GACD-->>T: codigoProtocolo
  T->>DB: Saga etapa 1 concluída
  T->>GACD: Passo 2 Armazenar Prévia
  GACD--xT: Timeout ou 5xx
  T->>T: Retentativa imediata Resilience4j - 3 tentativas com backoff e jitter
  alt Recupera
    GACD-->>T: IdPrevia e CaminhoPrevia
    T->>DB: Saga segue para etapa 3
  else Falha persiste ou circuito aberto
    T->>DB: Saga etapa 2 AGUARDANDO_RETENTATIVA com próxima execução agendada
    loop Retentativas agendadas por até 2 h - backoff 1, 5, 15, 30, 60 min
      T->>GACD: Passo 2 novamente
      GACD--xT: Falha
    end
    T->>GACD: Compensação - cancelar protocolo, se a API existir, QA-TEC-06
    alt Sem API de cancelamento ou cancelamento falhou
      T->>DB: Protocolo ORFAO e item de reconciliação manual
      T->>OPS: Alerta operacional com codigoProtocolo
    end
    T->>DB: Falha na geração, etapa GACD, reprocessável, e outbox GeracaoDoTermoFalhou
    AC->>SF: Status Falha na geração e Alerta_Adesao__c FALHA_GERACAO
    alt Gerente reemite
      SF->>T: POST /v1/adesoes/id/reemissao
    else Operação retoma a saga
      OPS->>T: POST /admin/v1/adesoes/id/saga/retomar - rota interna
    end
  end
  Note over T,GACD: Timeout ambíguo no passo 1 - antes de repetir, reconciliar pela referência externa idAdesao se o GACD permitir consulta. Sem consulta, a saga para em RESULTADO_INCERTO para decisão da operação, evitando protocolo duplicado
```

**Leitura:** os passos 2 e 3 são repetidos com segurança **[PREMISSA: PRM-TEC-11]**, porque o reenvio da mesma prévia no mesmo protocolo não deve gerar efeito duplicado relevante. O passo 1 **não** é repetido às cegas: um timeout pode ter aberto o protocolo. A falha de FIRP ou do renderizador segue o mesmo padrão, sem compensação externa: `GeracaoDoTermoFalhou` com etapa `FIRP` ou `DOCUMENTO`.

---

## 7. Visão de implantação e rede

```mermaid
flowchart TB
  SF["Salesforce FSC - internet, Hyperforce"]
  AK["COMP-07 Akamai<br/>WAF, mTLS, allowlist de IPs do Salesforce"]
  subgraph AZ["Azure - tenant corporativo"]
    subgraph HUB["vNet Hub"]
      AGW["COMP-08 Application Gateway WAF v2"]
      FW["COMP-12 Azure Firewall - egress<br/>allowlist FQDN do My Domain Salesforce"]
      AXW["COMP-09 Axway API Gateway<br/>Hub (localização a confirmar — QA-TEC-09)"]
    end
    subgraph SPOKE["vNet Spoke - Plataformas Funcionais"]
      subgraph AROC["COMP-10 ARO Atacado"]
        subgraph NS["namespace atacado-core"]
          ING["Ingress privado - router interno"]
          P1["atacado-adesao-termo<br/>2 a 4 réplicas, HPA"]
          P2["atacado-adesao-receptor<br/>2 a 3 réplicas, PDB, anti-afinidade por zona"]
          P3["atacado-adesao-acompanhamento<br/>2 réplicas, 1 ativa por lock"]
          CSI["Secrets Store CSI Driver<br/>provider Azure Key Vault"]
        end
      end
      subgraph PES["Subnet de private endpoints"]
        PEKV["PE Key Vault COMP-11"]
        PEBL["PE Blob COMP-05"]
      end
      PG[("COMP-04 PostgreSQL Flexible Server<br/>subnet delegada, HA com redundância de zona")]
    end
    IMPD["COMP-16 IMPD API cloud<br/>outra vNet - rota a confirmar"]
  end
  subgraph CORP["Corporativo - Azure ou on-premise, QA-TEC-09"]
    FIRP["COMP-13 FIRP"]
    GACD["COMP-14 GACD"]
  end

  SF -->|"HTTPS 443 - mTLS e OAuth2"| AK
  AK --> AGW
  AGW --> AXW
  AXW -->|"API Adesão"| ING
  AXW -->|"callback - rota interna"| ING
  ING --> P1
  ING --> P2
  P1 -->|"HTTPS via Axway - token LEAP hipótese"| AXW
  P2 -->|"revalidação FIRP via Axway"| AXW
  AXW --> FIRP
  AXW --> GACD
  GACD -.->|"callback"| AXW
  P1 -.->|"HTTPS - direto ou via Axway"| IMPD
  P1 --> PEBL
  P1 --> PG
  P2 --> PG
  P3 --> PG
  CSI --> PEKV
  P3 -->|"HTTPS 443 - OAuth JWT Bearer"| FW
  FW --> SF
```

### 7.1 Fluxos de rede (liberações necessárias)

| # | Origem | Destino | Protocolo | Autenticação | Rota | Status |
|---|---|---|---|---|---|---|
| N-01 | Salesforce | Akamai → App Gateway → Axway (política externa `atacado-adesao-sf`) → ingress privado → COMP-01 | HTTPS 443 | mTLS (certificado de cliente na Named Credential) + OAuth 2.0 client credentials | Entrada de canal externo (RST-04) | **[PREMISSA: PRM-TEC-06]** |
| N-02 | COMP-01 | Axway interno → FIRP | HTTPS | Token LEAP **[HIPÓTESE]** | Spoke → Axway | QA-TEC-03, QA-TEC-05 |
| N-03 | COMP-01 | Axway interno → GACD (3 APIs) | HTTPS | Token LEAP + usuário sistêmico no passo 2 **[FATO: 04]** | Spoke → Axway | QA-TEC-04, QA-TEC-06 |
| N-04 | COMP-01 | IMPD `impd-srv-doc-generator` | HTTPS | A definir | Peering/private endpoint ou Axway | **[ABERTO: QA-TEC-01]** |
| N-05 | GACD | Axway interno (política `atacado-adesao-callback-gacd`) → ingress privado → COMP-02 | HTTPS | mTLS ou token do GACD | Interna (PRM-CON-04) | QA-TEC-07, QA-TEC-09 |
| N-06 | ~~Canal Digital PJ → Axway interno (política `atacado-adesao-alerta-canal`) → COMP-02~~ | — | — | — | — | **Removido na rodada 6 (2026-10-16):** a revalidação passou ao Atacado; não há mais alerta do Canal (ADR-13) |
| N-07 | COMP-03 | Azure Firewall (Hub) → `https://<mydomain>.my.salesforce.com` | HTTPS 443 | OAuth 2.0 JWT Bearer (Connected App) | Egress controlado | **[PREMISSA: PRM-TEC-06]** |
| N-08 | COMP-01/02/03 | PostgreSQL (acesso privado) | TLS 5432 | Usuário por serviço (segredo no Key Vault) ou Microsoft Entra ID | Intra-spoke | PRM-TEC-01 |
| N-09 | COMP-01 | Blob (private endpoint) | HTTPS 443 | Identidade de workload ou SAS/chave no Key Vault | Intra-spoke | PRM-TEC-02, QA-TEC-14 |
| N-10 | Pods (CSI) | Key Vault (private endpoint) | HTTPS 443 | Identidade de workload / service principal | Intra-spoke | PRM-TEC-08 |
| N-11 | Pods | Coletor de observabilidade | OTLP / HTTPS | mTLS / token | Intra-spoke ou Hub | PRM-TEC-12 |
| N-12 | COMP-02 | Axway interno → FIRP (mesma política de consumo do N-02, com o client do COMP-02) | HTTPS | Token LEAP **[HIPÓTESE]** | Spoke → Axway | QA-TEC-03, QA-TEC-05; ADR-13 |

**Controles no namespace `atacado-core`:** NetworkPolicy com deny-all padrão e liberação explícita por fluxo. O ingress aceita só o Axway, via IPs ou subnet. O egress é restrito em três camadas (refinado em `05-especificacoes-tecnicas.md` DT-20, §17 I-07): **NetworkPolicy de egress por pod** (só o COMP-03 sai para o Salesforce; COMP-01 → Axway/IMPD; COMP-02 → Axway, só para a FIRP); **EgressFirewall** (OVN-Kubernetes) com a allowlist de FQDN — ele vale para o **namespace inteiro**, não por pod; e **EgressIP** dedicado, se disponível, para a regra por IP de origem no Firewall do Hub. Nenhuma Route pública. Imagens UBI 9 com OpenJDK 21, sem privilégios (SCC `restricted-v2`).

---

## 8. Segurança

### 8.1 Autenticação e autorização por fronteira

| Fronteira | Mecanismo proposto | Autorização | Decisão |
|---|---|---|---|
| Salesforce → API Adesão | **Named Credential + External Credential** no Salesforce: OAuth 2.0 client credentials contra o emissor corporativo (LEAP ou OAuth do Axway) **e** certificado de cliente (mTLS) validado no Akamai/Axway. Allowlist de IPs do Salesforce no Akamai como defesa extra | Escopos `adesao.escrita` e `adesao.leitura`; `matriculaGerente` no corpo, auditado (o Salesforce é cliente confiável; o Gerente não tem token próprio no banco) | ADR-07 |
| COMP-01 → FIRP / GACD | Token de workload (LEAP **[HIPÓTESE]**) por client credentials, com credencial no Key Vault; **usuário sistêmico** do GACD no passo 2, em cabeçalho/credencial definido pelo GACD | Aplicação cadastrada como "Produto" consumidor do GACD (QA-NEG-19) | ADR-10 |
| GACD → callback | Autenticação no Axway (mTLS ou token do GACD) + rota interna + validação de esquema + deduplicação + verificação de protocolo vigente (INV-07). Se o GACD tiver consulta de status, **confirmação ativa** (pull) antes de marcar Assinado | Só a identidade do GACD acessa a política de callback | ADR-08 |
| COMP-02 → FIRP (revalidação no callback) | Token de workload do COMP-02 (LEAP **[HIPÓTESE]**) por client credentials, com credencial própria no Key Vault; mesma política de consumo FIRP do COMP-01 no Axway, com o client do COMP-02. Substitui a antiga linha "Canal → API de alerta", removida na rodada 6 | Só consulta de representantes e poderes; limite de requisições por client | ADR-10, ADR-13 |
| COMP-03 → Salesforce | **OAuth 2.0 JWT Bearer** (Connected App ou External Client App), certificado com chave privada no Key Vault; **usuário de integração** com permission set mínimo (upsert em `Adesao_Termo__c` e `Alerta_Adesao__c`) | Menor privilégio; sem acesso a outros objetos | ADR-06 |
| Serviços → PostgreSQL / Blob / Key Vault | Identidade por serviço; role de banco por schema (o receptor só grava na inbox e registra nela o resultado da revalidação; o relay só lê a outbox do BC-01) | Menor privilégio por schema | ADR-05, ADR-10 |

### 8.2 Segredos e certificados

- Todos no **Azure Key Vault** (COMP-11): client secret/cert LEAP, usuário sistêmico do GACD, chave privada do JWT do Salesforce, certificado mTLS de cliente do Salesforce (a chave fica no Salesforce), credenciais do PostgreSQL e acesso ao Blob, se não houver identidade de workload.
- Montagem no pod pelo **Secrets Store CSI Driver** com provider Azure Key Vault (suportado no OpenShift), com rotação automática por polling. A aplicação relê a credencial sem redeploy **[PREMISSA: PRM-TEC-08]**. External Secrets Operator é a alternativa se for o padrão da plataforma (QA-TEC-14).
- Rotação: segredos ≤ 90 dias; certificados com alerta 30 dias antes do vencimento.

### 8.3 Proteção de dados (LGPD)

| Dado | Onde aparece | Classificação | Tratamento |
|---|---|---|---|
| CNPJ, razão social, produtos | API, estado, eventos, Salesforce | Confidencial (dado empresarial) | TLS; criptografia em repouso |
| Assinante (id FIRP, nome, papel) | Estado (COMP-04), documento, Salesforce (resumo) | **Dado pessoal** | Minimização (PRM-DDD-08): **sem CPF** em eventos, logs ou alertas; nome só no estado e no documento; mascaramento em logs. Se o GACD exigir CPF no passo 1, a FIRP é reconsultada nesse momento e o CPF fica só em memória, sem persistência (refinado em 05 §17 I-08; **[ABERTO: QA-TEC-24]**) |
| Documento PDF (contém nomes/assinantes) | Blob staging, GACD/GCC | Dado pessoal + confidencial | Staging com TTL ≤ 30 dias (ou exclusão ao chegar a Assinado/Encerrado), acesso só pelo COMP-01, sem acesso público, soft delete curto |
| Resultado da revalidação (assinantes inválidos) | Inbox, outbox, Salesforce | Sem dado pessoal | Só `codigoProtocolo`, motivo (enum) e quantidade. A resposta da FIRP (que pode trazer CPF) fica só em memória no COMP-02 e é descartada após a comparação (ADR-13) |
| Trilha de auditoria | COMP-04 | Pessoal (matrícula do Gerente) | Append-only; retenção conforme política (QA-TEC-17) |

### 8.4 Ameaças principais e controles (resumo STRIDE)

| Ameaça | Exemplo | Controle |
|---|---|---|
| Spoofing | Callback forjado marcando termo como Assinado | Rota interna + autenticação no Axway + protocolo vigente + confirmação ativa no GACD, se houver API (RSK-16) |
| Tampering | Troca do PDF entre prévia e envio | Hash SHA-256 gravado em Gerado e conferido antes do passo 2; staging sem escrita por outros serviços |
| Repudiation | Gerente nega ter confirmado o envio | Auditoria com matrícula, horário, versão do modelo e hash |
| Information disclosure | Nomes de assinantes em logs | Mascaramento; nada de payload em log; nível DEBUG proibido em produção |
| Denial of service | Rajada de callbacks | Rate limit no Axway; inbox absorve picos; bulkhead por endpoint |
| Elevation of privilege | Relay com acesso amplo no Salesforce | Permission set mínimo; roles de banco por schema |

---

## 9. Resiliência, observabilidade e auditoria

### 9.1 Política de chamadas externas (Resilience4j)

| Dependência | Timeout (conexão / leitura) | Retry imediato | Circuit breaker | Após esgotar |
|---|---|---|---|---|
| FIRP (consulta) | 2 s / 5 s | 3 tentativas, backoff 0,5 s → 2 s com jitter, só para timeout/5xx/429 | Janela de 20 chamadas, 50% de falha, aberto por 60 s | Etapa reagendada (até 2 h), depois `GeracaoDoTermoFalhou(FIRP)` |
| FIRP (revalidação no callback, COMP-02) | 2 s / 5 s | 3 tentativas, backoff 0,5 s → 2 s com jitter, só para timeout/5xx/429 | Próprio do COMP-02 (janela de 20 chamadas, 50% de falha, aberto por 60 s) | Sinal continua `AGUARDANDO_REVALIDACAO`; nova revalidação agendada (1, 5, 15, 30 min e depois a cada 30 min), sem limite e sem descarte; alerta operacional após 2 h pendente. Nunca libera a assinatura sem revalidar (ADR-13, RSK-20) |
| IMPD / renderizador | 2 s / 15 s | 2 tentativas | Idem | Reagendada, depois `GeracaoDoTermoFalhou(DOCUMENTO)` |
| GACD passo 1 | 2 s / 10 s | **Só erro de conexão antes do envio**; timeout de leitura leva a RESULTADO_INCERTO | Idem | Reconciliação (§6.4) |
| GACD passos 2 e 3 | 2 s / 30 s (passo 2, payload) e 10 s | 3 tentativas com backoff | Idem | Reagendada, depois compensação |
| Salesforce (relay) | 2 s / 20 s | Contínuo, com backoff exponencial até 24 h (1 s → 15 min) | Aberto por 120 s em 5xx/timeout; respeita `Retry-After` em 429 | Estacionada + alerta |

Bulkhead: pools separados por dependência no COMP-01 (a falha do GACD não esgota as threads da API Adesão). Virtual threads do Java 21 nas chamadas bloqueantes, com limite por semáforo.

### 9.2 Filas lógicas, erros e reprocessamento

| Estrutura (COMP-04) | Papel | Estados | Reprocessamento |
|---|---|---|---|
| `adesao_entrada.sinal_externo` (inbox) | Callbacks recebidos, com o resultado da revalidação na FIRP | AGUARDANDO_REVALIDACAO → RECEBIDO → PROCESSADO / IGNORADO / QUARENTENA | Revalidação reagendada pelo próprio COMP-02; `POST /admin/v1/sinais/{id}/reprocessar` |
| `adesao_termo.tarefa` | Fila de tarefas interna do COMP-01 (identificar assinantes, gerar documento, conduzir a saga), gravada na mesma transação da transição (05 DT-05) | PENDENTE → CONCLUIDA / FALHOU | Reagendamento pela própria fila |
| `adesao_termo.saga_envio_assinatura` | Estado dos 3 passos do GACD | ETAPA_n_PENDENTE, AGUARDANDO_RETENTATIVA, RESULTADO_INCERTO, COMPENSANDO, CONCLUIDA, FALHOU (no 05 §9.1, separados em `etapa` + `estado`) | `POST /admin/v1/adesoes/{id}/saga/retomar` e `/reconciliar` |
| `adesao_termo.outbox_evento` | Eventos de domínio **publicados** (envelope do 03 §5.2); os internos ficam só na auditoria e na saga. **Consumidor único: COMP-03** — o COMP-01 não consome a própria outbox (05 DT-05, §17 I-01/I-10) | PENDENTE → CONSUMIDO | Relay idempotente por `idEvento` |
| `adesao_acompanhamento.entrega_status` | Mensagens para o Salesforce (DLQ lógica) | PENDENTE → CONFIRMADA / ESTACIONADA | `POST /admin/v1/entregas/{id}/reentregar` |
| `adesao_termo.reconciliacao_manual` | Protocolos órfãos ou incertos | ABERTO → RESOLVIDO | Runbook com o GACD |

Os endpoints `/admin/**` ficam num listener separado, sem Route externa, acessíveis só pela operação autenticada (RBAC do OpenShift ou port-forward auditado).

### 9.3 Correlação ponta a ponta

- `X-Correlation-ID`: gerado pelo Salesforce na solicitação (ou, sem ele, pelo COMP-01). É propagado em todas as chamadas e gravado no envelope do evento (`correlationId`, correlação técnica). A chave de correlação **de negócio** vai em campo próprio, `chaveCorrelacaoNegocio`: `idAdesao` até o protocolo abrir e, depois, o `codigoProtocolo` (PRM-CON-12; refinado em 05 DT-08, §17 I-02).
- W3C `traceparent` (OpenTelemetry) do Axway até FIRP/GACD, quando os gateways propagarem. O relay e o processamento da inbox **reabrem o trace** a partir do `causationId` gravado.
- Logs estruturados em JSON com `idAdesao`, `idProposta`, `codigoProtocolo`, `etapa`, `correlationId` e `traceId`, sem payload de documento nem dados pessoais.

### 9.4 Métricas e alertas (mínimo)

| Métrica | Alerta |
|---|---|
| `adesao_etapa_duracao_seconds{etapa}` (FIRP, documento, GACD passo 1-3, entrega) | p95 acima da meta de RNF-06/RNF-07 por 15 min |
| `adesao_saga_estado_total{estado="FALHOU" \| "RESULTADO_INCERTO"}` | Qualquer ocorrência |
| `adesao_inbox_idade_max_seconds` | > 120 s |
| `adesao_revalidacao_pendente_idade_max_seconds` (sinais em `AGUARDANDO_REVALIDACAO`) | > 2 h (FIRP indisponível no callback, RSK-20) |
| `adesao_outbox_pendentes` e `adesao_entrega_estacionada_total` | > 0 estacionadas; pendentes > 100 por 10 min |
| `resilience4j_circuitbreaker_state` por dependência | Circuito aberto > 5 min |
| `adesao_callback_quarentena_total` | Qualquer ocorrência (possível forja ou falha de correlação) |
| Negócio (RFN-12): termos solicitados, gerados, enviados, assinados, com assinantes inválidos, falhos | Painel de KPIs (KPI-01..04) |

### 9.5 Auditoria (CAP-12.1)

Tabela `adesao_termo.trilha_auditoria` **append-only**: a role da aplicação só tem `INSERT`/`SELECT`. Colunas: `idRegistro`, `ocorridoEm`, `idAdesao`, `idProposta`, `codigoProtocolo`, `ator` (matrícula ou identidade de sistema), `acao` (comando/sinal), `origem` (SALESFORCE, GACD, OPERACAO, SISTEMA), `resultado`, `versaoModelo`, `hashDocumento`, `correlationId`. Retenção e eventual exportação para Databricks (KPIs, OP-03) em QA-TEC-17. A evidência jurídica do aceite continua sendo do GACD + GCC/Filenet (CAP-12.2).

---

## 10. Modelo de dados (resumo)

Um schema por BC, no mesmo servidor, sem joins entre schemas (03 §8.2). O detalhe e o diagrama ER estão em `04a` (COMP-04).

| Schema | Tabelas principais | Dono (deployable) |
|---|---|---|
| `adesao_termo` (BC-01) | `adesao_termo` (agregado, `versao` para lock otimista, índice único parcial por CNPJ para estados não terminais → INV-01), `produto_aderido`, `decisao_elegibilidade` (adesão dispensada, sem agregado), `tarefa` (fila interna), `requisicao_idempotente` (`Idempotency-Key`), `assinante`, `protocolo_assinatura`, `documento_termo` (versão, hash, ref. blob), `saga_envio_assinatura`, `outbox_evento`, `trilha_auditoria`, `reconciliacao_manual` | COMP-01 (migrações Flyway) |
| `termo_documento` (BC-02) | `modelo_termo` (tipo, versão, vigência, `referenciaTemplate`, aprovação) | COMP-01 |
| `adesao_entrada` (BC-01, borda) | `sinal_externo` (inbox; único por `origem` + `chaveIdempotencia`; guarda o resultado da revalidação) | COMP-02 grava e registra a revalidação, COMP-01 consome |
| `adesao_acompanhamento` (BC-03) | `visao_jornada`, `alerta_gerente`, `entrega_status`, `evento_consumido` | COMP-03 |

---

## 11. Contratos de integração (proposta)

### 11.1 API Adesão v1 (Salesforce → COMP-01) — OHS/PL (R-01)

| Operação | Método e caminho | Comando (03) | Resposta |
|---|---|---|---|
| Solicitar termo | `POST /v1/adesoes` (`Idempotency-Key` obrigatório) | `SolicitarTermoAdesao` | `202` + `idAdesao` + `Location`; `409` se já houver adesão não terminal no CNPJ (INV-01), com o `idAdesao` existente; repetição da mesma `Idempotency-Key` → **mesmo status e corpo originais (`202`)** com o cabeçalho `Idempotent-Replayed: true` (refinado em 05 DT-06, §17 I-03) |
| Consultar | `GET /v1/adesoes/{idAdesao}` | `ConsultarAdesao` | Estado, tipo, assinantes resumidos, `codigoProtocolo`, motivo de falha |
| Prévia do PDF | `GET /v1/adesoes/{idAdesao}/documento` | — | `application/pdf` (tamanho ≤ limite de callout Apex; ver RNF-15) |
| Confirmar envio | `POST /v1/adesoes/{idAdesao}/confirmacao-envio` | `ConfirmarAssinantes` (refinado: confirma assinantes + prévia) | `202` |
| Reemitir | `POST /v1/adesoes/{idAdesao}/reemissao` | `ReemitirTermo` | `202` |
| Cancelar | `POST /v1/adesoes/{idAdesao}/cancelamento` | `EncerrarTermo` (cancelado) | `202` |

Corpo de `POST /v1/adesoes` (resumo): `idProposta`, `cnpj`, `produtos[] {codigoProduto}`, `matriculaGerente`, `indicadores {possuiContratoVigente, possuiAcessoCanalDigital}` (fonte provisória, PRM-TEC-10). A correlação vai no cabeçalho `X-Correlation-ID`, não no corpo; um `correlationId` no corpo é ignorado (refinado em 05 §17 I-04).

### 11.2 Callback GACD (GACD → COMP-02) — Conformist + ACL (R-06)

- URL registrada no passo 1: `https://<axway-interno>/atacado/adesao/v1/callbacks/gacd/assinaturas/{idAdesao}`.
- **Payload: definido pelo GACD** (upstream). O receptor se conforma a ele e traduz para `SinalExterno {origem=GACD, tipoSinal, codigoProtocolo, ocorridoEm, dadosBrutosHash}` **[ABERTO: QA-TEC-07]**.
- Respostas: `200` após gravar (inclusive duplicado); `400` só para payload sintaticamente inválido; nunca `4xx` para protocolo desconhecido (vai para QUARENTENA, sem induzir retentativa infinita); `503` se o banco estiver indisponível (o GACD deve retentar).
- Expectativas levadas ao GACD: retentativa com backoff por ≥ 24 h, `codigoProtocolo` e tipo do evento no payload, identificação do emissor (mTLS/token), estados além de "assinado" (recusa, expiração, parcial) e, para a revalidação no COMP-02 (§11.3), **CNPJ e identificação dos assinantes que assinaram** (QA-TEC-07).

### 11.3 Revalidação na FIRP no callback (COMP-02 → FIRP) — Conformist + ACL (R-12)

> **Substitui na rodada 6 (2026-10-16)** a antiga "API de alerta de assinantes inválidos (Canal → COMP-02)" (R-13, removida). O Canal não chama mais o Atacado; a revalidação passou ao domínio do Atacado **[FATO: CG]** **[DECISÃO: ADR-13]**.

| Item | Definição |
|---|---|
| Quando | No recebimento do callback de assinatura concluída do GACD (§11.2), **depois** de o sinal ser gravado na inbox e o ACK ser respondido. A revalidação ocorre depois de a assinatura estar registrada no GACD, não antes (RSK-19) |
| Quem | COMP-02 `atacado-adesao-receptor` (CAP-04.2). O COMP-02 não muda o estado do termo: só registra o resultado no sinal |
| Entrada | `codigoProtocolo`, CNPJ e assinantes do callback (identificação de quem assinou). Se o callback do GACD não trouxer CNPJ ou assinantes, a expectativa é levada ao GACD em QA-TEC-07 |
| Consulta | Contrato de consulta de representantes e poderes da FIRP **já usado pelo COMP-01** (RF-03, R-04), via Axway interno (N-12), com token de workload do COMP-02 |
| Comparação | Cada assinante do callback precisa ter poder vigente na FIRP para assinar o termo, na forma exigida (isolada ou conjunta). As regras exatas (o que invalida, assinatura parcial, poderes alterados entre o envio e a assinatura) estão em **QA-CON-09** |
| Saída | Sinal da inbox passa de `AGUARDANDO_REVALIDACAO` para `RECEBIDO`, com o resultado: assinantes válidos (assinatura confirmada) ou inválidos (motivo em enum, quantidade, **sem dado pessoal**). O COMP-01 transforma o resultado em `AssinaturaConcluida` ou `AssinantesInvalidados` |
| Motivos (enum) | `PODERES_REVOGADOS`, `REPRESENTANTE_DESLIGADO`, `VIGENCIA_EXPIRADA`, `REGRA_ASSINATURA_NAO_ATENDIDA`, `OUTRO`. Sem texto livre |
| Dados pessoais | A resposta da FIRP (que pode trazer CPF) fica só em memória no COMP-02 e é descartada após a comparação. Nada de CPF ou nome no sinal, em logs ou eventos (RNF-04) |
| Falha | FIRP indisponível, timeout ou circuito aberto → retentativa com backoff (§9.1); o sinal **fica pendente** em `AGUARDANDO_REVALIDACAO` e é revalidado de novo, **sem descarte**. A assinatura **não é confirmada sem revalidar**. Alerta operacional após 2 h pendente (RSK-20) |
| Destino do protocolo assinado com assinantes inválidos | Em aberto em **QA-NEG-20** (cancelar no GACD, invalidar o termo, exigir nova assinatura, quem executa). Hoje: estado Assinantes inválidos, alerta ao Gerente no Salesforce e reemissão (Fluxo 3) |

Não há responsabilidades do Canal nesta integração: o Canal só dá acesso ao termo e coleta a assinatura no GACD. A antiga consulta `GET /alertas/{idNotificacao}` e o endpoint `POST /v1/alertas/assinantes-invalidos` foram removidos.

### 11.4 Entrega ao Salesforce (COMP-03 → Salesforce) — PL de status (R-02)

- `PATCH /services/data/vXX.X/sobjects/Adesao_Termo__c/Id_Adesao__c/{idAdesao}` (upsert por External ID) com `Status_Termo__c`, `Status_Jornada__c`, `Codigo_Protocolo__c`, `Versao_Evento__c`, `Atualizado_Em__c`, `Proposta__c` (lookup por `idProposta`).
- `PATCH .../sobjects/Alerta_Adesao__c/Id_Alerta__c/{idAlerta}` para os alertas. Um Flow no Salesforce dispara a Custom Notification ou tarefa para o Gerente dono da Proposta.
- **Ordem:** o relay entrega em série por `idAdesao`. No Salesforce, uma regra defensiva ignora atualização com `Versao_Evento__c` menor que a atual.
- **Adesão dispensada** (contrato vigente): não há agregado nem `idAdesao`. O registro "Não requerido" usa como `Id_Adesao__c` o `idDecisao` da tabela `decisao_elegibilidade` (refinado em 05 §17 I-09).
- Sem Platform Events de entrada nesta versão (ADR-06).

---

## 12. Análise crítica do IMPD e recomendação para a geração do termo

### 12.1 Fatos × hipótese

| Hipótese do usuário | O que as fontes dizem | Conclusão |
|---|---|---|
| "IMPD parece on-premise (nuvem privada Bradesco), o que é limitação" | Existe a **API cloud `impd-srv-doc-generator`, "disponível na Azure"**, recomendada. O mainframe é o **legado** **[FATO: 06]** | Hipótese **parcialmente contraditada**. Ainda não se sabe se a API cloud é alcançável pelo spoke do ARO Atacado nem qual é a maturidade dela em produção (QA-TEC-01) |
| "Não sei a maturidade" | Templates em **CSF Designer v21** (FIS). Cada área cria e mantém os seus; alteração complexa ou documento novo exige **terceiros**; pouco material público; esteira GitHub → testes → CMG, com **RDM** em produção; saída **só base64** **[FATO: 05, 06]** | Maturidade de **processo** alta (esteira, RDM, ambientes AL2/CM2/MZ). O custo e o lead time de **criar** os 2 templates são o ponto fraco. Base64 é exatamente o que o GACD espera (RST-07) |

### 12.2 Opções avaliadas

| Opção | Descrição |
|---|---|
| **O1 — IMPD API cloud** | COMP-01.4 chama `impd-srv-doc-generator` com o id do template CSF e as variáveis; recebe base64 |
| **O2 — IMPD mainframe** | Acionamento pelo legado (fluxo BCM) |
| **O3 — Geração própria no ARO** | Módulo `termo-documento` com template HTML/Thymeleaf versionado em Git, renderizado por OpenHTMLtoPDF (sobre Apache PDFBox) em PDF/A-2b com fontes embutidas |
| **O4 — Geração no Salesforce** | Serviço de documentos do Salesforce (ex.: OmniStudio Document Generation / Visualforce `renderAs=pdf`), com o PDF enviado ao ARO |

### 12.3 Matriz de avaliação (notas de 1 a 5; 5 = melhor)

Pesos propostos pelo arquiteto: o Termo é **documento jurídico-contratual** de banco, por isso governança e conformidade pesam mais que velocidade.

| Critério | Peso | O1 IMPD cloud | O2 IMPD mainframe | O3 Geração própria | O4 Salesforce |
|---|---|---|---|---|---|
| Maturidade (produto e uso em produção) | 10% | 3 — API existe e é recomendada; uso por consumidores cloud não comprovado | 4 — legado estável | 4 — bibliotecas maduras, novas no Atacado | 4 — recurso de mercado |
| Lead time até produção | 15% | 2 — template CSF novo (terceiros) + esteira + RDM | 1 — BCM/mainframe | 4 — 2 a 3 sprints | 3 — licença e configuração |
| Custo e esforço de template (criar e manter) | 10% | 2 — competência de nicho; terceiros para mudança complexa | 2 — idem | 4 — HTML/CSS, competência comum | 3 |
| Governança, padrão corporativo e marca | 20% | 5 — estrutural corporativo; padrão visual dos documentos do banco | 3 — legado desencorajado | 2 — exige exceção arquitetural; o Atacado passa a ter um gerador de documento (contraria PRI-03) | 1 — documento jurídico nasce no SaaS; contraria PRI-02 |
| Conformidade e evidência (controle de mudança do modelo) | 15% | 4 — esteira com testes, aprovação e RDM | 4 | 3 — viável (Git + PR com aprovação do Jurídico + RDM de deploy), mas é controle próprio | 2 |
| Latência e rede | 10% | 3 — Azure, conectividade a confirmar | 1 — on-premise, integração legada | 5 — in-process | 2 — PDF precisa sair do Salesforce e passar pelo WAF |
| Lock-in | 5% | 2 — CSF Designer (FIS) proprietário | 1 | 5 — OSS (PDFBox Apache 2.0; OpenHTMLtoPDF LGPL) | 1 |
| Operação e suporte | 15% | 4 — operado pelo time do IMPD | 3 | 2 — Atacado corrige CVEs, fontes e layout | 3 |
| **Nota ponderada** | 100% | **3,40** | **2,55** | **3,30** | **2,35** |

**Sensibilidade:** se o gate confirmar a API cloud (maturidade 4 e latência/rede 4), O1 vai para **3,60**. Se o prazo do go-live dominar (lead time com peso 30%, tirado de governança), O3 passa à frente. O2 e O4 ficam em último em qualquer ponderação razoável.

### 12.4 Recomendação

**Plano A — IMPD API cloud (O1)**, atrás da porta `RenderizadorDocumento`, **condicionado a um gate técnico de até 3 semanas** (spike com o time do IMPD: conectividade, autenticação, SLA, template-piloto simples). **Plano B — geração própria (O3)**, já implementada como adaptador **desligado** no mesmo módulo, com modelo HTML aprovado pelo Jurídico. Pode ser ativada por configuração, sem mudar a API nem a saga. **O2 (mainframe) e O4 (Salesforce) são rejeitadas.**

**Gatilhos de decisão (qualquer um ativa o Plano B, com registro de exceção arquitetural):**

| Gatilho | Critério objetivo |
|---|---|
| G1 — Conectividade | Rota ARO Atacado → `impd-srv-doc-generator` sem viabilidade confirmada em até 3 semanas |
| G2 — Maturidade/SLA | Sem consumidor produtivo de referência na API cloud, ou SLA < 99,5%, ou p95 > 5 s para documento de até 5 páginas |
| G3 — Lead time | Criação dos 2 templates CSF + esteira + RDM estimada além de (go-live − 4 semanas de homologação) |
| G4 — Custo | Contratação de especialista CSF acima do orçamento aprovado ou sem fornecedor em 30 dias |
| G5 — Frequência de mudança | Jurídico prevê mais de 1 alteração complexa por trimestre no conteúdo (cada uma exigiria terceiros) |

**Gatilho de retorno:** se o Plano B for ativado, a migração para o IMPD é reavaliada a cada revisão semestral de arquitetura ou quando surgir outro documento do Atacado que justifique o investimento em CSF. A porta mantém essa troca barata.

**Regras que valem nos dois planos:** um modelo **vigente** por tipo de termo, com versão imutável e aprovação registrada (BC-02); hash SHA-256 de todo documento; PDF ≤ 1 MB; saída base64 (formato exigido pelo GACD); nenhum dado além do necessário no documento.

---

## 13. Decisões de arquitetura (ADR)

Formato curto: contexto / decisão / alternativas / consequências. Status de todas: **Proposta** (validação com os times na revisão do 04), exceto a ADR-09, **Substituída pela ADR-13** na rodada 6 (2026-10-16).

### ADR-01 — Granularidade de deployables

- **Contexto:** o 03 recomenda um monólito modular (DU-01 `adesao-termo`) e um relay opcional (DU-02). A orientação recebida sugere 4 microsserviços (FIRP, gerador de PDF, GACD, callback). Há três perfis diferentes de exposição e disponibilidade: o Salesforce (comandos, PDF), os sinais de entrada (callback do GACD, que exige alta disponibilidade e ACK rápido; o alerta do Canal deixou de existir na rodada 6, ADR-13) e a saída para o Salesforce (egress para a internet, limites de API).
- **Decisão:** **3 deployables** no `atacado-core`, de **um único repositório** multi-módulo Maven, versionados juntos:
  1. `atacado-adesao-termo` (COMP-01): BC-01 núcleo + BC-02 como módulo + ACLs FIRP/GACD/registro de contratos + saga + processamento da inbox;
  2. `atacado-adesao-receptor` (COMP-02): borda de entrada do BC-01 (callback do GACD e revalidação dos assinantes na FIRP, ADR-13), **sem regra de estado do termo**, só ACL + inbox + revalidação;
  3. `atacado-adesao-acompanhamento` (COMP-03): BC-03 completo (relay, projeção, alertas, entrega ao Salesforce).
  O corte segue **exposição, disponibilidade e credenciais**, não as etapas do fluxo.
- **Alternativas:** (a) 4 microsserviços por etapa — **rejeitada**: ACLs anêmicas, saga distribuída entre serviços, transação por chamada remota, 4 pipelines para um time; (b) monólito único — **rejeitada**: um deploy ou pico de memória na geração de PDF derrubaria o callback, e a credencial do Salesforce e o egress para a internet ficariam no mesmo pod que recebe chamadas do Salesforce; (c) 03 literal (DU-01 + relay com a mesma imagem) — **ajustada**: o relay virou o BC-03 explícito, e o receptor foi separado.
- **Consequências:** o BC-01 roda em dois deployables (núcleo e borda), acoplados só pela tabela de inbox (contrato interno versionado). Migrações Flyway ficam centralizadas no COMP-01 (Job pré-deploy), no padrão expand/contract. Com ArchUnit/Spring Modulith, a extração futura de `termo-documento` ou de `convenio-produto` continua barata (03 §8.3).

### ADR-02 — Orquestração da jornada no ARO, com saga e confirmação do Gerente

- **Contexto:** DEC-CON-07. Chamadas a FIRP, geração e 3 passos no GACD, com risco de falha parcial (QA-CON-16).
- **Decisão:** o **COMP-01 orquestra** a jornada a partir de poucos comandos de negócio do Salesforce (solicitar, confirmar envio, reemitir, cancelar). A execução é **assíncrona** (`202`). A saga do GACD é um *process manager* persistido (`saga_envio_assinatura`), com retentativa agendada, compensação (cancelamento do protocolo, se houver API) e reconciliação manual. Idempotência: `Idempotency-Key` na API, índice único por CNPJ não terminal (INV-01), chaves de negócio nos sinais. A **confirmação do Gerente** acontece no estado **Gerado** e cobre assinantes + prévia em um único passo: é um refinamento de `ConfirmarAssinantes` do 03, sem estado novo. Fica atrás de uma flag até QA-NEG-18.
- **Alternativas:** (a) o Salesforce chama cada serviço — **rejeitada**: estado da saga em Apex, limites de callout (100 por transação, 120 s) e de heap (6/12 MB) com PDF, credenciais de APIs internas no SaaS, violação de PRI-02; (b) coreografia por eventos entre serviços — **rejeitada** (sem broker, QA-DDD-05); (c) motor de workflow (BPMN) — **rejeitada** pelo volume e pela simplicidade (3 passos).
- **Consequências:** o Salesforce só conhece a API Adesão. O Gerente tem prévia e controle. O timeout ambíguo no passo 1 exige reconciliação (QA-TEC-06).

### ADR-03 — Geração do documento: IMPD API cloud (Plano A) com geração própria como Plano B

- **Contexto:** DEC-CON-03; análise da §12.
- **Decisão:** porta `RenderizadorDocumento` no módulo `termo-documento`. Adaptador **IMPD API cloud** como alvo, condicionado ao gate G1-G5. Adaptador **próprio** (Thymeleaf + OpenHTMLtoPDF, PDF/A-2b) implementado e desligado, como Plano B. Os modelos são registrados em `modelo_termo` com `referenciaTemplate` (id CSF ou versão do template HTML).
- **Alternativas:** IMPD mainframe (rejeitada: legado, on-premise, lead time); Salesforce (rejeitada: PRI-02, payload); só geração própria (não recomendada como alvo por PRI-03 e governança, mas aceita como Plano B).
- **Consequências:** esforço duplicado pequeno (dois adaptadores e dois templates só se o Plano B for ativado). O conteúdo jurídico precisa de um dono (QA-CON-19) nos dois planos.

### ADR-04 — Staging do PDF em Azure Blob Storage

- **Contexto:** o GACD recebe o base64 no passo 2. O PDF precisa existir entre a geração, a prévia do Gerente (horas ou dias) e o envio, inclusive nas retentativas da saga, e precisa ser **o mesmo** documento auditado (hash).
- **Decisão:** **Azure Blob Storage** (COMP-05), conta StorageV2 só com private endpoint, acesso público e chave compartilhada desabilitados quando a identidade de workload estiver disponível. Container `termos-staging`, caminho `{idAdesao}/{tentativa}/termo.pdf`, criptografia em repouso (chave gerenciada pela Microsoft ou CMK no Key Vault, conforme política), **lifecycle de exclusão em 30 dias** e exclusão explícita ao chegar a Assinado/Encerrado. **Não** é repositório oficial: o oficial é o GCC/Filenet via GACD.
- **Alternativas:** (a) passar o base64 direto ao GACD sem guardar — **rejeitada**: sem prévia, e a retentativa exigiria regenerar o documento (hash diferente, risco de conteúdo divergente do aprovado); (b) `bytea` no PostgreSQL — **aceita como plano B** se o Blob não for aprovado (volume baixo, ≤ 1 MB), mas incha backup e réplicas; (c) o Salesforce guardar o PDF (Files) — **rejeitada**: o PDF voltaria a trafegar pelo SaaS e duplicaria o repositório de documentos.
- **Consequências:** mais um recurso Azure fora do `stack-tech.md` (PRM-TEC-02, QA-TEC-12). O PDF nunca trafega pelo Akamai ou pelo WAF na ida ao GACD; só na prévia (resposta ao Salesforce).

### ADR-05 — Estado e outbox em PostgreSQL Flexible Server, com relay por polling

- **Contexto:** PRI-05 e INV-10 exigem estado + evento na mesma transação. Não há broker confirmado (QA-DDD-05). O volume é baixo. O PostgreSQL não consta do `stack-tech.md`.
- **Decisão:** **Azure Database for PostgreSQL Flexible Server** (COMP-04), com acesso privado no spoke, HA com redundância de zona, backup com PITR (35 dias) e TLS obrigatório. Outbox transacional com o envelope do 03 §5.2 e inbox transacional. **Relay por polling** (`SELECT … FOR UPDATE SKIP LOCKED`, intervalo de 1 s, `LISTEN/NOTIFY` opcional para reduzir latência) no COMP-03, com uma instância ativa por lock (ShedLock) para garantir ordem por agregado.
- **Alternativas:** (a) CDC com Debezium/Kafka Connect — **rejeitada**: exige Kafka e replicação lógica para volume de dezenas por hora; (b) Azure Service Bus como transporte — **adiada**: se QA-TEC-13 confirmar broker, o relay passa a publicar nele sem mudar o produtor; (c) **Azure Functions** (timer) como relay — **rejeitada**: outro runtime e outra operação fora do ARO, integração de VNet e plano Premium para alcançar o banco privado, sem ganho no volume previsto; (d) Azure SQL / Cosmos DB — sem vantagem sobre o PostgreSQL para o padrão; a escolha segue a orientação recebida e PRM-CON-05.
- **Consequências:** consistência eventual com latência de segundos (RNF-06). Exige aprovação do PostgreSQL pela plataforma (RSK-10).

### ADR-06 — Entrega de status ao Salesforce: REST upsert com OAuth 2.0 JWT Bearer

- **Contexto:** DEC-CON-05 (a) push com outbox. É preciso idempotência, ordem e menor privilégio.
- **Decisão:** o COMP-03 faz **upsert REST por External ID** (`Adesao_Termo__c.Id_Adesao__c`, `Alerta_Adesao__c.Id_Alerta__c`). Autenticação por **OAuth 2.0 JWT Bearer** com Connected App (ou External Client App), certificado cuja chave privada fica no Key Vault, e **usuário de integração** com permission set mínimo. O token fica em cache até expirar. A notificação ao Gerente é feita por Flow no Salesforce.
- **Alternativas:** (a) **Platform Events** publicados pelo ARO — **rejeitada como principal**: se o subscriber no Salesforce falhar, o evento se perde sem retentativa explícita, e é preciso manter trigger ou Flow para materializar o registro. O upsert já é idempotente e persistente. Fica como alternativa se o Salesforce quiser desacoplar consumidores; (b) o Salesforce consultar o ARO periodicamente (pull) — **rejeitada**: não atende "tempo real" (KPI-04) e aumenta o tráfego de entrada; (c) client credentials flow — possível, mas o JWT Bearer evita segredo compartilhado.
- **Consequências:** exige liberar o egress no Hub para o My Domain do Salesforce (RSK-14, N-07) e acompanhar o consumo de limites de API (RSK-11).

### ADR-07 — Entrada Salesforce → ARO Atacado pelo padrão de canal externo

- **Contexto:** o Salesforce é SaaS na internet (Hyperforce). QA-CON-20, PRM-CON-11.
- **Decisão:** **Akamai → Azure Application Gateway (WAF v2) → Axway (política externa) → ingress privado do ARO → COMP-01**. No Salesforce: **Named Credential + External Credential** com OAuth 2.0 client credentials e **certificado de cliente (mTLS)**. Defesas extras: allowlist dos IPs do Salesforce no Akamai, validação de esquema e rate limit no Axway.
- **Alternativas:** (a) **Salesforce Private Connect** — **rejeitada**: é baseado em AWS PrivateLink e não conecta a vNets Azure; (b) exposição direta do App Gateway sem Akamai — **rejeitada** (fora do padrão RST-04); (c) chamar o Axway sem App Gateway — **rejeitada** (fora do padrão).
- **Consequências:** o limite de corpo do WAF e do Axway precisa comportar as requisições (pequenas). Não há upload de PDF pelo Salesforce. A prévia é **resposta**. A allowlist de IPs precisa de manutenção (RSK-14).

### ADR-08 — Callback GACD: rota interna, inbox, idempotência e validação

- **Contexto:** R-06, PRM-CON-04, QA-CON-12/13. Contrato de callback não documentado.
- **Decisão:** callback **GACD → Axway interno → ingress privado → COMP-02**, com URL por adesão registrada no passo 1. Autenticação no Axway (mTLS ou token do GACD). O COMP-02 valida o esquema, traduz, grava na **inbox** (único por `GACD + codigoProtocolo + tipoSinal`) e responde **200 só depois do commit**. Em seguida, revalida os assinantes na FIRP e grava o resultado no sinal (ADR-13). O COMP-01 aplica INV-07 e, se o GACD tiver API de consulta, confirma o status antes de marcar Assinado. Sinais desconhecidos vão para **QUARENTENA** com alerta.
- **Alternativas:** (a) callback exposto pelo Akamai (rota externa, DEC-CON-04 b) — só se o GACD estiver fora da rede interna (QA-TEC-09); (b) receptor que aplica o domínio de forma síncrona — rejeitada: o ACK passaria a depender de regra e estado, e o deployable da borda carregaria o domínio; (c) polling do status no GACD em vez de callback — rejeitada como principal, mas mantida como **reconciliação diária** de protocolos em Aguardando assinatura se houver API de consulta.
- **Consequências:** latência adicional de ~1-2 s (inbox → núcleo), mais a revalidação na FIRP no COMP-02 (ADR-13), aceitável. Os duplicados são inofensivos.

### ADR-09 — API de alerta de assinantes inválidos para o Canal

- **Status: Substituída pela ADR-13 (rodada 6, 2026-10-16).** A revalidação dos assinantes passou ao domínio do Atacado (COMP-02, no callback do GACD); o Canal só dá acesso ao termo e coleta a assinatura **[FATO: CG]**. O texto abaixo fica como registro histórico.
- **Contexto:** RN-07, R-13, QA-CON-08, QA-DDD-08. O Canal é abstraído e tem backlog próprio.
- **Decisão:** publicar o contrato **"Alerta de Assinantes Inválidos v1"** (§11.3) no COMP-02, em política dedicada do Axway, idempotente por `idNotificacao`, **sem dado pessoal**, com resposta `202` e consulta opcional de situação. Aceitar também o caminho alternativo pelo callback do GACD (DEC-CON-06 b), com a mesma tradução.
- **Alternativas:** (a) o Canal chamar o Salesforce — **rejeitada** (PRI-01); (b) o Atacado revalidar a FIRP periodicamente para todos os protocolos pendentes — **rejeitada como principal** (carga na FIRP e detecção fora do momento da assinatura), mas é candidata a OP-08; (c) só via GACD — depende de evolução do GACD.
- **Consequências:** depende de acordo e entrega do Time de Canais (RSK-06). Até lá, o termo com assinantes inválidos fica parado sem aviso. Mitigação: SLA de pendência com alerta ao Gerente após N dias em Aguardando assinatura (QA-TEC-08).

### ADR-10 — Autenticação de workload, segredos e rede

- **Contexto:** token LEAP é hipótese (PRM-CON-03). O GACD exige usuário sistêmico no passo 2 **[FATO: 04]**. Hub and Spoke.
- **Decisão:** abstração `CredencialProvider` por dependência, com dois mecanismos em paralelo: **token de workload** (LEAP, client credentials, cache até expirar) para o Axway, e **usuário sistêmico** do GACD onde exigido. Segredos no **Key Vault** via **Secrets Store CSI Driver**. Rede: sem Routes públicas, NetworkPolicy deny-all, EgressFirewall por destino, private endpoints para PostgreSQL, Blob e Key Vault, egress para o Salesforce só pelo Firewall do Hub.
- **Alternativas:** External Secrets Operator (equivalente; seguir o padrão da plataforma); credenciais em Secret do Kubernetes criadas por pipeline — rejeitada (rotação manual).
- **Consequências:** se o LEAP não existir como imaginado, só o adaptador de credencial muda (QA-TEC-03).

### ADR-11 — Convênio: porta desativada e eventos-gatilho, sem implementação

- **Contexto:** QA-CON-02/03/04, QA-CON-24/25, QA-CONV-01..13. Entre a assinatura e o convênio ativo existe uma etapa de **implantação e homologação** com o cliente (PN-10.1 a PN-10.4: parâmetros como layout CNAB 240/400 ou API e canal de transmissão, convênio em teste no sistema do produto, homologação de remessa e retorno, ativação), feita por pessoas — Gerente de Cash ou backoffice, a definir (QA-CON-24). O convênio só fica ativo após a homologação (RN-17) **[PREMISSA: PRM-CON-15 — padrão de mercado]**. O 03 traz as opções A (novo serviço), B (legado + ACL), C (Open Cash Hub) e D (Salesforce, não recomendada).
- **Decisão:** **não construir nada do BC-04 agora.** Deixar prontos: (1) `AssinaturaConcluida` e `AdesaoDispensada` na outbox, com `produtos[]` e `cnpj` (gatilhos de PRM-DDD-11); (2) a porta `SolicitacaoConvenioPort` e o evento `ConvenioSolicitado` definidos como contrato (PL), com flag `convenio.gatilho.habilitado=false`; (3) status da jornada por produto "Em implantação", "Convênio ativo" e "Tarifas cadastradas" reservados no BC-03, mas não projetados ("Convênio pendente" fica como situação de exceção, para falha ou atraso). Quando ativada, a porta tende a **abrir uma pendência de implantação** (tarefa para o Gerente ou o backoffice, visível no Salesforce) e acompanhar o status (Em implantação → Convênio ativo), e **não** a criar o convênio direto por API no sistema do produto. O contrato `ConvenioSolicitado` passa a representar a abertura da implantação (EVN-13 Implantação iniciada); o nome pode ser revisto na ativação. A pendência chega ao Salesforce pelo mesmo caminho dos demais status (outbox → COMP-03), a confirmar na ativação. Quando QA-CON-02 for respondida: B ou C → módulo `convenio-produto` (ACL) no COMP-01; A → novo microsserviço `atacado-convenio-produto` (COMP-31, adiado), consumidor da outbox; D → rejeitada. Em todas as opções existe a etapa de implantação com executor humano (02 DEC-CON-02).
- **Alternativas:** construir `convenio-produto` agora (opção A) — rejeitada: risco de duplicar sistema de registro existente (03 §2.3 item 4).
- **Consequências:** KPIs de ciclo até a tarifa (OE-02) ficam incompletos até a definição (RSK-13). O ciclo assinatura → convênio ativo → tarifa inclui a homologação, que depende do cliente; a métrica precisa separar o tempo de implantação e homologação do tempo interno (DRV-03 no 01). O executor humano da implantação traz o risco RSK-18.

### ADR-12 — Resiliência, observabilidade e auditoria como requisitos de primeira classe

- **Contexto:** RNF-05, RNF-09..RNF-11; CAP-12.
- **Decisão:** Resilience4j (timeouts, retry com jitter, circuit breaker, bulkhead) com os parâmetros da §9.1. Estruturas de erro e reprocessamento da §9.2 (inbox, saga, outbox, entrega estacionada, reconciliação manual). OpenTelemetry (agente Java) + Micrometer/Prometheus (monitoramento de workloads de usuário do OpenShift) + logs JSON, exportados para a stack corporativa (PRM-TEC-12). `X-Correlation-ID` + `traceparent` ponta a ponta. Trilha de auditoria append-only.
- **Alternativas:** fila dedicada (DLQ em broker) — adiada até haver broker; o "DLQ" é a tabela de estacionamento.
- **Consequências:** runbooks obrigatórios antes do go-live (reprocessar sinal, retomar saga, reentregar, reconciliar protocolo).

### ADR-13 — Revalidação de assinantes no receptor do Atacado (COMP-02), no callback do GACD

- **Status:** Proposta (rodada 6, 2026-10-16). Substitui a ADR-09.
- **Contexto:** RN-06, RN-07, CAP-04.2, R-12, QA-CON-09. O Canal Digital PJ só dá a opção de acessar o termo e assiná-lo; registra a assinatura no GACD e não consulta a FIRP **[FATO: CG]**. Quem revalida a assinatura na FIRP é o domínio do Atacado, com o `atacado-adesao-receptor` **[FATO: CG]**. O COMP-02 já é o ponto de entrada do callback de assinatura (ADR-08).
- **Decisão:** o **COMP-02** grava o callback na inbox (`AGUARDANDO_REVALIDACAO`), responde o ACK e, em seguida, **consulta a FIRP via Axway** com o mesmo contrato de consulta de poderes do COMP-01, compara os assinantes do callback com os poderes vigentes e grava o resultado no sinal (`RECEBIDO`, assinantes válidos ou inválidos). O **COMP-01** consome a inbox e aplica a regra de estado (INV-08): Assinado ou Assinantes inválidos, com outbox. O **COMP-03** alerta o Gerente no Salesforce (CAP-09.2). Se a FIRP falhar, o sinal fica pendente e é revalidado de novo com backoff, sem descarte; a assinatura não é confirmada sem revalidar (§11.3).
- **Alternativas:** (a) o Canal revalidar e avisar o Atacado por API (ADR-09) — **rejeitada**: decisão do negócio **[FATO: CG]**; elimina a dependência de contrato e de backlog de Canais; (b) o COMP-01 revalidar ao consumir a inbox — **rejeitada**: mantém o núcleo sem chamada síncrona extra no processamento da inbox, e o receptor já é o ponto de entrada do sinal; (c) revalidar antes de responder o ACK — **rejeitada**: o ACK ao GACD passaria a depender da FIRP (RNF-05, RNF-08).
- **Consequências:** (+) elimina a API de alerta, a rota `atacado-adesao-alerta-canal`, o contrato com Canais (QA-TEC-08) e a dependência D11 do roadmap; (+) o Atacado controla a regra de revalidação; (−) a revalidação ocorre **depois** de a assinatura ser registrada no GACD: há uma janela em que o protocolo está assinado no GACD e o termo ainda não (RSK-19); o destino desse protocolo fica em **QA-NEG-20**; (−) o COMP-02 passa a depender da FIRP (timeout, retentativa, circuit breaker; RSK-20) e a ter egress para o Axway e credencial de workload própria; (−) o COMP-02 deixa de ser "sem regra de negócio" e passa a ser "sem regra de estado do termo".

---

## 14. Riscos técnicos

Escala: Probabilidade/Impacto = Baixa (B), Média (M), Alta (A).

| ID | Risco | Prob. | Impacto | Mitigação | Dono |
|---|---|---|---|---|---|
| RSK-01 | API cloud do IMPD imatura ou sem conectividade com o ARO Atacado | M | A | Gate de 3 semanas (G1, G2); Plano B pronto (ADR-03) | Atacado Cash Payments (apoio: IMPD) |
| RSK-02 | Lead time e custo de criar os templates em CSF Designer v21 (terceiros, esteira, RDM) | A | M | Template-piloto no spike; contratação antecipada; gatilhos G3, G4 | Atacado Cash Payments (apoio: IMPD) |
| RSK-03 | Contrato do callback do GACD indefinido (payload, estados, autenticação, retentativa) | A | A | Receptor com ACL tolerante; quarentena; reconciliação por consulta (ADR-08); workshop de onboarding | GACD |
| RSK-04 | Falha parcial na saga gerando protocolos órfãos ou duplicados (sem API de cancelamento ou consulta) | M | A | Passo 1 sem retentativa cega; RESULTADO_INCERTO; reconciliação manual; pedir API ao GACD | GACD (com Atacado Cash Payments) |
| RSK-05 | Token LEAP não confirmado ou incompatível com workloads no ARO; usuário sistêmico com rotação manual | M | A | `CredencialProvider`; validação no spike; Key Vault + CSI | Segurança (apoio: Plataformas Funcionais) |
| RSK-06 | **Encerrado na rodada 6 (2026-10-16):** não há mais API de alerta do Canal; a revalidação passou ao Atacado (ADR-13). Texto original: Time de Canais não entrega a chamada à API de alerta no prazo | — | — | — (o alerta de pendência longa ao Gerente segue como mitigação de pendência sem assinatura) | — |
| RSK-07 | Contrato da FIRP desconhecido; possível consulta duplicada com o GACD (que já integra FIRP) | A | M | ACL isolada; QA-DDD-04; mock de contrato para desenvolvimento | FIRP (via Atacado Cash Payments) |
| RSK-08 | Limites de payload (WAF, Axway, APIs) para base64 e prévia | M | M | PDF ≤ 1 MB; PDF não passa pelo WAF na ida ao GACD; teste de carga com 5 MB | Plataformas Funcionais |
| RSK-09 | Rota GACD ("Azure > ON") → Axway → ARO ou egress ARO → Salesforce não liberados a tempo | M | A | Pedido de rede na sprint 0; teste de conectividade automatizado | Plataformas Funcionais |
| RSK-10 | PostgreSQL Flexible Server e Blob Storage fora do `stack-tech.md` (aprovação) | M | M | Registro de premissa; alternativa `bytea` para o staging; justificar via ADR-04/05 | Plataformas Funcionais (com Atacado Cash Payments) |
| RSK-11 | Limites de API ou indisponibilidade do Salesforce atrasam o status | B | M | Outbox com backoff por 24 h; upsert em série por agregado; monitorar consumo | Atacado Cash Payments |
| RSK-12 | Exposição LGPD (nomes de assinantes em logs, staging, eventos) | M | A | Minimização; mascaramento; TTL do staging; revisão de segurança | Segurança (com Atacado Cash Payments) |
| RSK-13 | Convênio indefinido impede fechar a jornada até a tarifa e medir OE-02 | A | A | ADR-11; decisão de negócio priorizada | Atacado Cash Payments |
| RSK-14 | Mudança de IPs do Salesforce (Hyperforce) bloqueia a entrada; mudança de My Domain bloqueia o egress | M | M | mTLS + OAuth como controle principal; allowlist gerenciada; monitoração de falhas 403 | Plataformas Funcionais |
| RSK-15 | Clientes do BGS sem integração ao GACD não conseguem assinar | A | A | Tratar no roadmap de Canais (QA-CON-07); sinalizar no Salesforce | Canais |
| RSK-16 | Callback forjado ou repetido altera o estado indevidamente | B | A | Rota interna, autenticação, protocolo vigente, confirmação ativa, quarentena | Segurança (com GACD) |
| RSK-17 | BC-01 em dois deployables (núcleo e receptor) com versões divergentes da inbox | B | M | Um repositório, versão única, contrato de inbox versionado, expand/contract | Atacado Cash Payments |
| RSK-18 | Implantação técnica do convênio (layout CNAB, canal de transmissão, homologação) feita pelo Gerente de Cash foge do papel comercial no padrão de mercado **[PREMISSA: PRM-CON-15]**: falta de capacidade ou conhecimento técnico e atraso no ciclo até o faturamento | M | A | Backoffice como executor (QA-CON-24, QA-CON-25); checklist de implantação no Salesforce; apoio do time de produto; porta `convenio-produto` só abre e acompanha a pendência de implantação (ADR-11) | Atacado Cash Payments |
| RSK-19 | Revalidação depois da assinatura registrada no GACD: na janela entre assinar e revalidar, o protocolo fica assinado no GACD com assinantes que podem ser inválidos, e o destino desse protocolo não está definido (QA-NEG-20) | M | A | Revalidação logo após o ACK do callback (p95 em segundos com a FIRP disponível); termo só vai a Assinado com assinantes válidos; estado Assinantes inválidos + alerta ao Gerente + reemissão até QA-NEG-20; regras em QA-CON-09 (ADR-13) | Atacado Cash Payments (com GACD) |
| RSK-20 | Indisponibilidade ou lentidão da FIRP no callback deixa assinaturas pendentes de revalidação e atrasa o status Assinado no Salesforce | M | M | ACK ao GACD independente da FIRP; sinal fica `AGUARDANDO_REVALIDACAO` e é revalidado com backoff, sem descarte; circuit breaker próprio do COMP-02; alerta após 2 h; SLA da FIRP em QA-TEC-05 (ADR-13) | Atacado Cash Payments (apoio: FIRP) |

---

## 15. Questões em aberto técnicas

| ID | Questão | Time responsável | Impacto |
|---|---|---|---|
| QA-TEC-01 | **IMPD — conectividade e maturidade:** como o ARO Atacado alcança `impd-srv-doc-generator` (peering, private endpoint, Axway)? Qual autenticação, SLA, volumetria suportada e quais consumidores cloud já estão em produção? | IMPD (com Plataformas Funcionais) | ADR-03, G1/G2 |
| QA-TEC-02 | **IMPD — templates:** esforço e custo para criar os 2 templates no CSF Designer v21; fornecedor; lead time da esteira (GitHub → CMG, RDM); suporte a PDF/A; limite de páginas e tamanho | IMPD (com Atacado Cash Payments) | ADR-03, G3/G4 |
| QA-TEC-03 | **Autenticação LEAP:** existe como padrão para workloads no ARO? Fluxo (client credentials, certificado), emissor, TTL, escopos, validação no Axway. Vale para FIRP (COMP-01 e COMP-02), GACD e Salesforce? | Segurança (com Plataformas Funcionais) | ADR-07, ADR-10 |
| QA-TEC-04 | **Usuário sistêmico do GACD:** formato (cabeçalho, basic, certificado), provisionamento, rotação; vale só no "Armazenar Prévia"? | GACD | ADR-10, N-03 |
| QA-TEC-05 | **Contrato FIRP:** endpoint no Axway, modelo de representante/poder, regras de assinatura conjunta, dados pessoais retornados, SLA, ambiente de homologação; o mesmo contrato é usado pelo COMP-02 na revalidação do callback (client próprio) | FIRP (via Atacado Cash Payments) | COMP-01.2, COMP-02, RF-03, RF-08, RSK-20 |
| QA-TEC-06 | **Contratos GACD:** payloads das 3 APIs e nomes oficiais (`coordenar` × `coordenador`; `cgcc_conteudo_gacd` × `cgcc-conteudo-gacd`); chave de idempotência ou referência externa no passo 1; API de **consulta** de protocolo e de **cancelamento**; códigos de erro | GACD | ADR-02, RSK-04 |
| QA-TEC-07 | **Callback:** payload, estados (assinado, recusado, expirado, parcial), autenticação do emissor, política de retentativa, timeout esperado do ACK, ordem, uso da URL por adesão; **CNPJ e identificação dos assinantes que assinaram** no payload, para a revalidação na FIRP (§11.3) | GACD | ADR-08, ADR-13, COMP-02 |
| QA-TEC-08 | **Encerrada — não se aplica (rodada 6, 2026-10-16):** não há mais contrato de alerta com o Canal; a revalidação passou ao Atacado (ADR-13). Texto original: contrato com o Canal (aceite do contrato da antiga §11.3, autenticação do Canal no Axway, momento da chamada, retentativa, SLA, alternativa via GACD, prazo de entrega no backlog) | — | ADR-09 (substituída), RSK-06 (encerrado) |
| QA-TEC-09 | **Rede:** onde ficam GACD e FIRP (Azure ou on-premise); rota Axway interno → ingress privado do ARO; liberação do egress ARO → Salesforce no Firewall do Hub (ou proxy corporativo); DNS privado | Plataformas Funcionais | §7, RSK-09 |
| QA-TEC-10 | **Payload:** limites de corpo e timeout do Axway (externo e interno), do WAF do Application Gateway e do Akamai; tamanho real esperado do PDF do termo | Plataformas Funcionais | RNF-15, RSK-08 |
| QA-TEC-11 | **Convênio:** sistema de registro, contrato de integração e gatilho (QA-CON-02/03) e executor da implantação (QA-CON-24/25) — define a ativação da porta `convenio-produto`, a forma da pendência de implantação no Salesforce e a opção A/B/C | Atacado Cash Payments | ADR-11, RSK-18 |
| QA-TEC-12 | **Aprovação de serviços fora do stack:** Azure Database for PostgreSQL Flexible Server e Azure Blob Storage no spoke de Plataformas Funcionais | Plataformas Funcionais | ADR-04, ADR-05 |
| QA-TEC-13 | **Broker corporativo** (Service Bus, Kafka, Event Grid) disponível para o `atacado-core`? | Plataformas Funcionais | ADR-05 |
| QA-TEC-14 | **Identidade de workload no ARO** (Microsoft Entra Workload ID) para Key Vault, Blob e PostgreSQL, ou service principal com segredo; CSI Driver ou External Secrets Operator como padrão | Plataformas Funcionais | ADR-10 |
| QA-TEC-15 | **Salesforce:** modelo de objetos (`Adesao_Termo__c`, `Alerta_Adesao__c`), Connected App ou External Client App, usuário de integração, limites de API da org, suporte a mTLS na Named Credential, UI da prévia | Atacado Cash Payments (com Experiência) | ADR-06, ADR-07 |
| QA-TEC-16 | **Observabilidade corporativa:** ferramenta padrão (Azure Monitor/Log Analytics, APM corporativo) e suporte a OpenTelemetry no ARO | Plataformas Funcionais | ADR-12 |
| QA-TEC-17 | **Retenção:** prazo da trilha de auditoria, do staging e dos sinais da inbox; exportação para Databricks (KPIs) | Atacado Cash Payments (com Segurança) | RNF-04, RNF-10 |
| QA-TEC-18 | **Termo assinado:** API do GACD/GCC para o Gerente baixar o documento assinado (RFN-11) | GACD | RF-11 |

---

## 16. Premissas técnicas

| ID | Premissa | Impacto se falsa | Validar com |
|---|---|---|---|
| PRM-TEC-01 | Azure Database for PostgreSQL Flexible Server pode ser provisionado no spoke de Plataformas Funcionais, com acesso privado (herda PRM-CON-05) | Trocar por outro relacional gerenciado aprovado; o padrão outbox se mantém | Plataformas Funcionais |
| PRM-TEC-02 | Azure Blob Storage com private endpoint pode ser usado para staging transitório | Staging em `bytea` no PostgreSQL (ADR-04 b) | Plataformas Funcionais |
| PRM-TEC-03 | Volumetria: até 500 solicitações/dia, pico de 50/h; PDF ≤ 1 MB; até 10 assinantes por termo | Revisar réplicas, pools e limites de payload | Atacado Cash Payments |
| PRM-TEC-04 | Chamadas ARO → Axway usam token de workload (LEAP) por client credentials; o GACD pede também usuário sistêmico no passo 2 (herda PRM-CON-03) | Troca do adaptador de credencial | Segurança, GACD |
| PRM-TEC-05 | O callback do GACD chega por rota interna do Axway (herda PRM-CON-04). O alerta do Canal deixou de existir na rodada 6 (ADR-13) | Publicar a política de callback pela borda externa (Akamai) | GACD, Plataformas Funcionais |
| PRM-TEC-06 | O Salesforce entra por Akamai → App Gateway → Axway; o egress do ARO para o Salesforce sai pelo Firewall do Hub com allowlist de FQDN (herda PRM-CON-11) | Proxy corporativo ou outra rota de saída | Plataformas Funcionais |
| PRM-TEC-07 | Não há broker corporativo disponível; eventos via outbox + polling | Relay publica no broker (ADR-05 b) | Plataformas Funcionais |
| PRM-TEC-08 | O Secrets Store CSI Driver com provider Azure Key Vault está disponível no ARO Atacado | Usar External Secrets Operator | Plataformas Funcionais |
| PRM-TEC-09 | Java 21 + Spring Boot 3.x sobre imagem UBI 9 OpenJDK 21 é suportado pela esteira corporativa de CI/CD para o ARO | Ajustar a versão ao padrão | Plataformas Funcionais |
| PRM-TEC-10 | Enquanto a fonte de contrato vigente (QA-CON-21) e de acesso ao Canal não estiverem definidas, o Salesforce informa `possuiContratoVigente` e `possuiAcessoCanalDigital`; o BC-01 aplica a política e audita a origem | Trocar o adaptador da `ElegibilidadePort` para o BC-13 | Atacado Cash Payments |
| PRM-TEC-11 | Os passos 2 (Armazenar Prévia) e 3 (Coordenar Regra) podem ser repetidos no mesmo protocolo sem efeito colateral relevante; o passo 1 não | Reconciliação obrigatória também nos passos 2 e 3 | GACD |
| PRM-TEC-12 | Existe stack corporativa de observabilidade compatível com OpenTelemetry/Prometheus no ARO | Adaptar exportadores | Plataformas Funcionais |
| PRM-TEC-13 | Níveis de serviço propostos (RNF-06, RNF-07, RNF-08) são aceitáveis para o negócio | Rever réplicas, HA e custos | Atacado Cash Payments |
| PRM-TEC-14 | A confirmação do Gerente antes do envio (QA-NEG-18) é desejada; fica atrás de flag | Desligar a flag; a saga começa depois de `TermoGerado` | Experiência, Atacado Cash Payments |
| PRM-TEC-15 | **Removida na rodada 6 (2026-10-16):** não há chamada do Canal ao Atacado (ADR-13). Texto original: o backend do Canal Digital PJ consegue chamar o Axway interno com identidade própria | — | — |

---

## 17. Impacto nos documentos anteriores e correspondência de nomes

| Documento 03 | Documento 04 | Observação |
|---|---|---|
| DU-01 `adesao-termo` | COMP-01 `atacado-adesao-termo` (núcleo BC-01 + BC-02) **e** COMP-02 `atacado-adesao-receptor` (borda de entrada do BC-01) | Prefixo `atacado-` para padronizar no namespace; BC-01 em dois deployables (ADR-01) |
| DU-02 `adesao-outbox-relay` (opcional) | COMP-03 `atacado-adesao-acompanhamento` | O relay passa a ser o BC-03 completo (nome técnico do 03: `adesao-acompanhamento`) |
| BC-02 `termo-documento` | Módulo COMP-01.4 `termo-documento` | Sem deployable próprio (03 §8.2) |
| BC-04 `convenio-produto` / módulo `convenio-gateway` | Porta COMP-01.6 `convenio-produto` (desativada); futuro COMP-31 `atacado-convenio-produto` (só na opção A) | ADR-11; o nome `convenio-gateway` do 03 fica substituído por `convenio-produto` (módulo) |
| Comando `ConfirmarAssinantes` (entre Assinantes identificados e Gerado) | Confirmação única de assinantes + prévia no estado **Gerado** (`POST …/confirmacao-envio`), emitindo `AssinantesConfirmados` | Refinamento compatível: os estados canônicos não mudam (ADR-02) |
| ACL-Callback e ACL-Alerta | Tradução do callback e revalidação na FIRP no COMP-02; a ACL-Alerta do Canal foi removida na rodada 6 (ADR-13); regras INV-07/INV-08 no COMP-01 | Inbox transacional como contrato interno |
| "Estacionamento (parking)" (03 §5.3) | `entrega_status` ESTACIONADA, `sinal_externo` QUARENTENA, `reconciliacao_manual` | §9.2 |
| BC-01 consumindo os próprios eventos pela outbox (03 §5.1) | Fila de tarefas interna `adesao_termo.tarefa`; outbox com consumidor único (COMP-03) | Refinado no 05 (DT-05, §17 I-01); o 03 v0.2 registra a nota |
| `correlationId` = chave de negócio (03 §5.2) | `correlationId` técnico + `chaveCorrelacaoNegocio` | Refinado no 05 (DT-08, §17 I-02) |

---

## 18. Referências

- `04a-componentes-e-justificativas.md` — ficha de cada componente e matrizes Componente × RF e Componente × RNF.
- `04b-diagramas-c4.md` — diagramas C4 (Contexto, Contêineres, Componentes).
- `04c-diagramas-archimate.md` — diagramas ArchiMate (camadas CAM-1..CAM-5).
- `01-contexto-de-negocio.md`, `02-desenho-conceitual.md`, `03-dominios-bounded-contexts-context-mapping.md`.
- Fontes: [04] Confluence GACD; [05] [06] IMPD; [stack] `stack-tech.md`; [CG] Contexto Geral.
