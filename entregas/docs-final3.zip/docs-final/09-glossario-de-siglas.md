# 09 — Glossário de Siglas: Termo de Adesão Multiproduto (Cash Management / Payments)

> Referência rápida para quem lê os documentos 01 a 08 e a apresentação executiva (07).
> Explica o que cada sigla significa: os prefixos de identificador (ADR, CAP, COMP, DRV…), os sistemas do banco (GACD, FIRP, IMPD…) e as siglas técnicas (ACL, OHS/PL, mTLS…).
> Não cria IDs nem renomeia nada. Os nomes e as definições são os dos documentos de origem.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 09 — Glossário de Siglas |
| Versão | v0.4 |
| Data | 2026-10-16 |
| Status | Rascunho |
| Autor | Arquitetura Corporativa — Atacado (Cash Management / Payments) |
| Documentos relacionados | 01 a 08 (origem das siglas); `07-apresentacao-executiva.pptx`/`.pdf` (slide "Glossário de siglas", gerado a partir das seções 3 a 5 deste documento) |
| Público | Todos os leitores dos documentos da iniciativa |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-27 | Versão inicial. Siglas levantadas por grep em todos os documentos de `docs-final/` (`instrucoes-ajustes.md`, item 4) |
| v0.2 | 2026-09-27 | Referências ao 02 atualizadas para a numeração do 02 v0.6 (Capacidades na §3.2, Negócio na §3.3) e exemplo da CAM ajustado (CAM-2 Camada de Capacidades) |
| v0.3 | 2026-09-27 | Novas siglas técnicas **CNAB** e **VAN**, usadas na implantação e homologação do Convênio (`instrucoes-ajustes.md`, item 8; origem no 01 v0.5 §14). Prefixos e exemplos conferidos: os novos IDs (ATR-09, EVN-13, RN-17, RSK-18, QA-CONV-12/13, QA-CON-24/25, PRM-RMP-14, RSK-RMP-13) usam prefixos já listados, sem mudança nas tabelas |
| v0.4 | 2026-10-16 | Rodada 6: a revalidação de assinantes na FIRP passa ao domínio do Atacado, no callback do GACD (COMP-02). Exemplo da FIRP ajustado. Os IDs novos (ADR-13, QA-NEG-20) usam prefixos já listados. Os IDs removidos ou cancelados (CAP-09.5, APP-02.6, R-13, D11) não eram exemplo em nenhuma tabela. As demais tabelas não mudam |

### 1.1 Como ler

- **Prefixo de ID** é a parte fixa de um identificador: em `CAP-09.2`, o prefixo é `CAP`. O número vem depois do hífen. IDs com ponto (`CAP-09.2`, `COMP-01.3`) indicam um item de segundo nível (L2) ou um módulo interno.
- **Documento de origem** é onde o ID é definido pela primeira vez. Os demais documentos só o referenciam.
- Os IDs com sufixo de documento indicam quem os criou: `-NEG` (01, negócio), `-CON` (02, conceitual), `-DDD` (03), `-TEC` (04 e 05), `-RMP` (06, roadmap). Exemplo: `PRM-NEG-01` é premissa do 01 e `PRM-TEC-01` é premissa técnica do 04.
- Referências como "02 §3.2" apontam para o documento 02, seção 3.2.

---

## 2. Documentos da pasta

| Nº | Documento | Conteúdo |
|---|---|---|
| 00 | `00-log-de-execucao.md` | Registro das rodadas de geração e dos ajustes |
| 01 | `01-contexto-de-negocio.md` | Problema, objetivos, drivers, regras e requisitos de negócio |
| 02 | `02-desenho-conceitual.md` | Camadas (estratégia a tecnologia), capacidades, processos, princípios |
| 03 | `03-dominios-bounded-contexts-context-mapping.md` | DDD: subdomínios, bounded contexts, context map |
| 04 | `04-desenho-arquitetura-solucao.md` | Requisitos, componentes, fluxos, rede, ADRs, riscos técnicos |
| 04a | `04a-componentes-e-justificativas.md` | Ficha e justificativa de cada componente (COMP-xx) |
| 04b | `04b-diagramas-c4.md` | Diagramas C4 |
| 04c | `04c-diagramas-archimate.md` | Diagramas ArchiMate |
| 05 | `05-especificacoes-tecnicas.md` | Especificações (SPEC) e critérios de aceite (CA) para fatiar tasks |
| 06 | `06-roadmap-de-implementacao.md` | Fases, marcos, dependências, decisões e riscos do roadmap |
| 07 | `07-apresentacao-executiva.pptx` / `.pdf` | Apresentação executiva |
| 08 | `08-consolidado-questoes-em-aberto-por-time.md` | Questões em aberto agrupadas por time |
| 09 | `09-glossario-de-siglas.md` | Este glossário |

---

## 3. Prefixos de identificadores

### 3.1 Estratégia e negócio

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| DRV | Driver de negócio | 01 §5.2 (e 02 §3.1.1) | DRV-01 Adesão digital fim a fim a partir do Salesforce |
| OE | Objetivo estratégico | 01 §4.3 | OE-01 Digitalizar a geração de termos |
| KPI | Indicador-chave de desempenho | 01 §4.3 | KPI-01 % de termos gerados via Salesforce (≥ 90% em 6 meses) |
| OP | Oportunidade de negócio | 01 §10 | OP-01 Reuso do GACD para outros produtos do Atacado |
| RN | Regra de negócio | 01 §8.1 | RN-01 O Termo de Adesão é único e multiproduto |
| RFN | Requisito funcional de negócio | 01 §8.2 | RFN-01 Solicitar a geração do termo a partir da proposta aprovada |
| RNFN | Requisito não funcional de negócio | 01 §8.3 | RNFN-01 Rastreabilidade completa de cada termo e convênio |
| ATR | Ator ou papel de negócio | 02 §3.3.1 | ATR-01 Gerente de Cash |
| PN | Processo de negócio | 02 §3.3.2 | PN-01 Negociar e aprovar Proposta |
| EVN | Evento de negócio | 02 §3.3.3 | EVN-01 Proposta aprovada |
| OBJ | Objeto de negócio | 02 §3.3.4 | OBJ-01 Proposta |

### 3.2 Desenho conceitual e ArchiMate

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| CAM | Camada do desenho conceitual | 02 §3 | CAM-2 Camada de Capacidades |
| CAP | Capacidade de negócio (L1 e L2) | 02 §3.2 | CAP-09.2 Alertas ao Gerente |
| APP | Bloco de aplicação (conceitual) | 02 §3.4 | APP-02 Serviços de Integração do Atacado |
| TEC | Elemento de tecnologia e integração | 02 §3.5 | TEC-04 Axway API Gateway |
| PRI | Princípio de arquitetura | 02 §6 | PRI-01 Salesforce nunca integra diretamente com componentes do banco |
| DEC-CON | Ponto de decisão conceitual | 02 §7 | DEC-CON-02 Dono, sistema e gatilho do Convênio por produto |
| AVL | Avaliação (ArchiMate) | 04c §3.1 | AVL-01 Termo de Adesão assinado manualmente, fora do Salesforce |
| VS | Value stream e seus estágios | 04c §4.1 | VS-01 Adesão a Produtos Cash |
| RES | Recurso (ArchiMate) | 04c §4.2 | RES-01 Salesforce — jornada do Gerente de Cash |
| COA | Curso de ação (ArchiMate) | 04c §4.2 | COA-01 Digitalizar a adesão na jornada do Salesforce |
| INC | Inconsistência entre documentos | 04c §11 | INC-01 Drivers com o mesmo ID e conteúdo diferente (resolvida) |

### 3.3 Domínios (DDD)

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| SD | Subdomínio | 03 §2.2 | SD-01 Adesão a Produtos Cash (Core) |
| BC | Bounded context (contexto delimitado) | 03 §3.1 | BC-01 Adesão ao Termo |
| INV | Invariante do agregado | 03 §3.2 | INV-01 No máximo um `AdesaoTermo` não terminal por CNPJ |
| R | Relação do context map | 03 §4.2 | R-01 Salesforce ↔ BC-01 (C/S + OHS/PL) |
| DU | Unidade de deploy proposta no DDD | 03 §8.1 | DU-01 `adesao-termo` |

### 3.4 Arquitetura de solução

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| RST | Restrição de arquitetura (não negociável) | 04 §3.1 | RST-01 O Salesforce só se comunica com serviços no ARO Atacado |
| RF | Requisito funcional da solução | 04 §3.2 | RF-01 Receber do Salesforce a solicitação do Termo de Adesão |
| RNF | Requisito não funcional da solução | 04 §3.3 | RNF-01 Autenticação e autorização em todas as fronteiras |
| COMP | Componente da solução | 04 §5 (ficha no 04a) | COMP-01 `atacado-adesao-termo` |
| N | Fluxo de rede (liberação necessária) | 04 §7.1 | N-01 Salesforce → Akamai → App Gateway → Axway → COMP-01 |
| G | Gatilho de decisão do IMPD (Plano A × B) | 04 §12.4 | G1 Conectividade ARO Atacado → IMPD |
| ADR | Registro de decisão de arquitetura | 04 §13 | ADR-01 Granularidade de deployables |
| RSK | Risco técnico | 04 §14 | RSK-01 API cloud do IMPD imatura ou sem conectividade |

### 3.5 Especificações técnicas

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| SPEC | Especificação técnica (`SPEC-<CÓD>-nn`) | 05 §1.2 | SPEC-TER-03 |
| CA | Critério de aceite de uma SPEC (`CA-<CÓD>-nn.m`) | 05 §1.2 | CA-TER-03.2 |
| DT | Decisão técnica do documento 05 | 05 §2.4 | DT-01 Maven multi-módulo com Maven Wrapper |
| T | Transição da máquina de estados do Termo | 05 §7.2 | T-01 — → Solicitado |
| RB | Runbook operacional | 05 §9.4 | RB-03 Cancelar protocolo órfão no GACD |
| DOR | Pré-requisito de ambiente (Definition of Ready) | 05 §14.1 | DOR-01 Repositório `atacado-adesao` criado, com acessos |
| I | Inconsistência tratada no documento 05 | 05 §17 | I-01 Consumo dos próprios eventos (03 × 04) |

### 3.6 Roadmap

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| F | Fase do roadmap | 06 §3.3 | F0 Destravamento |
| M | Marco | 06 §5 | M1 Decisão IMPD A/B (06/11/2026) |
| DEP | Dependência entre times | 06 §7 | DEP-01 Decisão GACD × Open Cash Hub |
| D | Decisão do plano de decisões, com prazo-limite | 06 §8 | D1 Gerenciador de termos: GACD × Open Cash Hub |
| RSK-RMP | Risco do roadmap | 06 §12 | RSK-RMP-01 Congelamento de fim de ano |

### 3.7 Questões em aberto e premissas

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| QA-NEG | Questão em aberto de negócio | 01 §12 | QA-NEG-01 Gerenciador de termos GACD × Open Cash Hub |
| QA-CONV | Questão em aberto sobre o Convênio | 01 §11 | QA-CONV-01 Onde o Convênio é gerado |
| QA-CON | Questão em aberto do desenho conceitual | 02 §8.1 | QA-CON-01 Qual é o gerenciador de termos oficial |
| QA-DDD | Questão em aberto de domínio (DDD) | 03 §9.1 | QA-DDD-01 Identidade e unicidade do agregado |
| QA-TEC | Questão em aberto técnica | 04 §15 (continua no 05 §16) | QA-TEC-01 Conectividade e maturidade do IMPD |
| QA-RMP | Questão em aberto de planejamento | 06 §13 | QA-RMP-01 Quando começa o relógio do KPI-01 |
| PRM-NEG | Premissa de negócio | 01 §13 | PRM-NEG-01 O GACD é o gerenciador de termos adotado |
| PRM-CON | Premissa do desenho conceitual | 02 §8.2 | PRM-CON-01 GACD é o gerenciador de referência |
| PRM-DDD | Premissa de domínio (DDD) | 03 §9.2 | PRM-DDD-01 BC-01 é o único core do Atacado |
| PRM-TEC | Premissa técnica | 04 §16 | PRM-TEC-01 PostgreSQL Flexible Server no spoke |
| PRM-RMP | Premissa de planejamento | 06 §2 | PRM-RMP-01 Datas indicativas, replanejadas no M2 |

### 3.8 Códigos `<CÓD>` das SPEC e dos CA

O `<CÓD>` em `SPEC-<CÓD>-nn` e `CA-<CÓD>-nn.m` indica o componente ou o tema (05 §1.2). Na matriz de rastreabilidade do 05, a SPEC aparece só com o código (ex.: `TER-03` = `SPEC-TER-03`).

| Código | Escopo | Componente(s) |
|---|---|---|
| TRV | Padrões transversais aos três serviços | COMP-01, COMP-02, COMP-03 |
| TER | Módulo `adesao-termo` (domínio, API Adesão, inbox, outbox, auditoria) | COMP-01.1 |
| FIR | Módulo `acl-firp` | COMP-01.2 |
| GAC | Módulo `acl-gacd` (adaptadores e saga) | COMP-01.3 |
| DOC | Módulo `termo-documento` | COMP-01.4 (+ COMP-05) |
| ELG | Módulo `acl-registro-contratos` (elegibilidade) | COMP-01.5 |
| CNV | Módulo `convenio-produto` (inativo) | COMP-01.6 |
| REC | `atacado-adesao-receptor` | COMP-02 |
| ACP | `atacado-adesao-acompanhamento` | COMP-03 |
| DB | `atacado-adesao-db` | COMP-04 |
| STG | `atacado-adesao-staging` | COMP-05 |
| SFC | Artefatos Salesforce do Atacado | COMP-06 |
| API | Contratos de API (entrada e saída) | COMP-01, 02, 03, 06, 09 |
| EVT | Eventos de domínio (outbox) | COMP-01, COMP-03 |
| SEG | Segurança | Todos os novos + COMP-07..12 |
| INF | Infraestrutura e deploy | COMP-04, 05, 09..12 |
| OBS | Observabilidade e auditoria | Todos os novos + COMP-19 |
| TST | Estratégia de testes | Todos os novos |

---

## 4. Sistemas e plataformas do banco

As fontes da iniciativa não trazem a expansão de todas as siglas internas do banco. Quando a expansão não consta nas fontes, a tabela descreve o papel do sistema e diz isso na coluna "Significado".

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| ARO | Azure Red Hat OpenShift, plataforma de contêineres corporativa | 02 §3.5 (TEC-03) | ARO Atacado, namespace `atacado-core` |
| BCM | Fluxo legado de publicação do IMPD via mainframe (expansão não consta nas fontes) | 04 §12.2 | Opção O2 "IMPD mainframe", descartada |
| BGS | Parte do Canal Digital PJ, ainda sem integração com o GACD (expansão não consta nas fontes) | 01 §3.4 | Assinatura de clientes BGS (QA-CON-07) |
| CSF | CSF Designer, ferramenta de mercado usada pelo IMPD para montar os modelos de documento | 01 §3.5 | Template CSF Designer v21 |
| FIRP | Sistema corporativo de firmas e poderes: assinantes e representantes do cliente | 02 §3.4 (APP-04) | Revalidação de assinantes na FIRP pelo COMP-02, no callback do GACD (CAP-04.2) |
| FSC | Salesforce Financial Services Cloud | 04 §5.1 (COMP-06) | COMP-06 Artefatos Salesforce do Atacado |
| GACD | Serviço corporativo de aceite digital: gestão de assinaturas, termos e contratos (expansão não consta nas fontes) | 02 §3.4 (APP-05) | 3 chamadas + callback do GACD |
| GCC | GCC/Filenet, repositório corporativo de documentos usado pelo GACD (expansão não consta nas fontes) | 02 §3.4 (APP-06) | Armazenamento da prévia do contrato |
| IMPD | Impressão de Documentos: serviço estrutural que formata PDFs (base64) | 02 §3.4 (APP-03) | API cloud `impd-srv-doc-generator` |
| LEAP | Padrão de token de workload do banco, hipótese de autenticação no Axway (expansão não consta nas fontes) | 02 §3.5 (TEC-08) | Token LEAP **[HIPÓTESE]** (QA-CON-14) |
| OCH | Open Cash Hub, alternativa de gerenciador de termos e de convênio | 03 §4.1 (BC-12) | Opção C do Convênio (DEC-CON-02) |
| PDPJ | Parte do Canal Digital PJ que já integra com o GACD (expansão não consta nas fontes) | 01 §3.4 | Clientes PDPJ no piloto (Onda 1) |
| RDM | Registro de mudança exigido para deploy em produção | 06 §2 (PRM-RMP-04) | RDM aprovada no comitê de mudanças |

---

## 5. Siglas técnicas e de método

| Sigla | Significado | Documento de origem | Exemplo |
|---|---|---|---|
| ACK | Confirmação de recebimento (*acknowledgement*) | 02 §3.2 | O COMP-02 grava na inbox e responde o ACK |
| ACL | Camada anticorrupção (*Anticorruption Layer*) | 03 §4.2 | ACL-FIRP, ACL-GACD |
| API | Interface de programação de aplicações | 02 §3.2 | API Adesão v1 |
| C4 | Modelo C4 de diagramas (contexto, contêiner, componente, código) | 04b | `c4-04-dinamico-jornada` |
| C/S | Customer/Supplier, relação cliente-fornecedor entre contextos | 03 §4.2 | R-05 GACD → BC-01 (C/S + ACL) |
| CI/CD | Integração e entrega contínuas | 05 §11.2 | Gates SAST/SCA na esteira |
| CNAB | Padrão de layout de arquivos de remessa e retorno entre empresas e bancos (240 ou 400 posições) | 01 §14 (e §11) | Layout CNAB 240/400 definido com o cliente na implantação (PN-10.1) |
| CNPJ | Cadastro Nacional da Pessoa Jurídica | 01 §12 | Um termo não terminal por CNPJ (INV-01) |
| DAST | Teste dinâmico de segurança de aplicação | 05 §10.6 | DAST em HML (QA-TEC-29) |
| DDD | *Domain-Driven Design* | 03 | Documento 03 |
| DEV, HML | Ambientes de desenvolvimento e de homologação (produção: ver PRD) | 06 §2 (PRM-RMP-07) | HML integrada com GACD, FIRP e IMPD |
| E2E | Ponta a ponta (*end-to-end*) | 05 §13 | Testes E2E em HML |
| HPA | *Horizontal Pod Autoscaler* (autoescala no ARO) | 04 §7 | COMP-01 com 2 a 4 réplicas e HPA |
| JWT | *JSON Web Token* | 04 §8 | OAuth JWT Bearer para o Salesforce |
| LGPD | Lei Geral de Proteção de Dados | 04 §8.3 | Revisão de LGPD antes do piloto (DEP-18) |
| LRM | *Last responsible moment*: data-limite de uma decisão | 06 §1.1 | LRM da D12 em 26/02/2027 |
| LWC | *Lightning Web Components* (Salesforce) | 04 §5.1 | Tela do Gerente em LWC/Flow |
| mTLS | TLS mútuo (autenticação por certificado dos dois lados) | 04 §8 | Entrada do Salesforce com mTLS |
| MVP | Produto mínimo viável | 06 §4 | F2 MVP termo ponta a ponta |
| OAuth | Protocolo de autorização (OAuth 2.0) | 04 §8 | *Client credentials* do Salesforce |
| OHS/PL | *Open Host Service* / *Published Language*: API aberta com linguagem publicada | 03 §4.2 | R-01 API Adesão (OHS/PL) |
| PDB | *Pod Disruption Budget* (disponibilidade no ARO) | 04 §7 | COMP-02 com PDB e anti-afinidade |
| PDF/A | PDF para arquivamento de longo prazo | 05 §2.2 | Termo gerado em PDF/A |
| PITR | Restauração a um ponto no tempo (*point-in-time restore*) | 04 §13 (ADR-05) | Backup com PITR de 35 dias |
| PRD | Documento de requisitos do produto (*Product Requirements Document*); no 06, também o ambiente de produção | Fontes [01]–[03]; 06 §2 | PRD Aceite Digital Cash; "PRD só depois do congelamento" |
| RACI | Matriz de responsabilidades (responsável, aprovador, consultado, informado) | 01 §6.3 | RACI dos stakeholders |
| REST | Estilo de API sobre HTTP | 04 §4 | REST síncrono via Axway |
| SaaS | Software como serviço | 02 §3.4 | Salesforce (SaaS) |
| SAST/SCA | Análise estática de código / análise de dependências | 05 §10.6 | Gates SAST/SCA no CI/CD |
| SIEM | Sistema de monitoramento de eventos de segurança | 05 §16 | Eventos 401/403 para o SIEM (QA-TEC-29) |
| SLA | Acordo de nível de serviço | 04 §12.4 | SLA do IMPD (QA-TEC-01) |
| TLS | Criptografia de transporte | 04 §8 | TLS obrigatório no PostgreSQL |
| UBI | *Universal Base Image* (imagem base Red Hat) | 04a §1.2 | UBI 9 OpenJDK 21 |
| VAN | *Value Added Network*: rede privada para transmissão de arquivos entre o cliente e o banco | 01 §14 (e §11) | Canal de transmissão da remessa e do retorno (internet banking, VAN, SFTP ou API) |
| WAF | *Web Application Firewall* | 04 §5.2 | Akamai com WAF na borda |

---

## 6. Marcas de rastreabilidade no texto

| Marca | Significado | Documento de origem |
|---|---|---|
| **[FATO: xx]** | Afirmação apoiada na fonte `xx` | 01 a 06 §1 |
| **[PREMISSA: PRM-xx]** | Suposição assumida para seguir, que precisa de validação | 01 a 06 §1 |
| **[HIPÓTESE]** | Hipótese técnica sem confirmação em fonte (ex.: token LEAP) | 02 §1.2 |
| **[ABERTO: QA-xx]** | Depende de resposta a uma questão em aberto | 02 §1.2 |
| **[DECISÃO: ADR-xx / Dx]** | Aponta para a decisão que sustenta o trecho | 04 §1.1, 06 §1.1 |
| **[BLOQUEIO: QA-xx]** | Questão que bloqueia a entrada ou a saída de uma fase | 06 §1.1 |
| CG | Contexto Geral informado nas reuniões (usado como fonte em `[FATO: CG]`) | 02 §1.1 |
