# Consolidado de questões em aberto por time

Projeto: Termo de Adesão multiproduto (Cash Management / Payments) — Atacado. Fontes: `docs-final/01` §11–12 (QA-CONV, QA-NEG), `02` §8.1 (QA-CON), `03` §9.1 (QA-DDD), `04` §15 (QA-TEC-01..18), `05` §16 (QA-TEC-19..30), `06` §13 (QA-RMP) e prazos do `06` §7–8 (DEP-xx e D1..D14).

Atualização da rodada 6 (2026-10-16): a revalidação de assinantes na FIRP passou ao domínio do Atacado, no callback do GACD (COMP-02 `atacado-adesao-receptor`, ADR-13) **[FATO: CG]**; o Canal só dá acesso ao termo e coleta a assinatura. Com isso, a linha 55 (API de alerta do Canal) foi encerrada, a QA-CON-09 passou ao Atacado Cash Payments com apoio da FIRP (linha 56), a QA-NEG-20 entrou como nova (linha 77) e a D11 foi cancelada. As linhas 33, 35, 49 e 50 (QA-TEC-03, QA-TEC-09, QA-TEC-25 e QA-TEC-26) seguem a redação revista do 04 v0.5 e do 05 v0.5, sem o Canal como chamador do Atacado.

## Como ler

- **Times responsáveis:** Atacado Cash Payments, Canais, Experiência e GACD. Questões dos times de apoio (Plataformas Funcionais, Segurança, IMPD, FIRP, Jurídico/Compliance, Open Cash Hub) ficam com o time do projeto que deve puxá-las, quase sempre o Atacado Cash Payments. O time de apoio aparece na coluna **Apoio**.
- **Sem duplicidade:** IDs equivalentes de documentos diferentes estão na mesma linha (ex.: `QA-CONV-01 / QA-CON-02 / QA-TEC-11`). Exceção: a QA-CON-14 junta duas perguntas (token LEAP e usuário sistêmico do GACD). Por isso ela aparece em duas linhas, marcada como "parte", uma no Atacado (QA-TEC-03) e outra no GACD (QA-TEC-04).
- **Prazo-limite:** é o LRM da decisão D-xx do roadmap (doc 06 §8). Se a decisão não sair até essa data, vale a regra padrão do roadmap. Quando não há decisão D-xx, mas há prazo de necessidade em dependência entre times (DEP-xx, doc 06 §7), ele aparece com essa indicação. Traço (—) = sem prazo definido no roadmap.
- **Origem:** documento e seção onde a questão está registrada, na ordem dos IDs.
- **Numeração (#) estável:** o número da linha não é reaproveitado. Linha encerrada fica no lugar, marcada como **Encerrada**, e não entra nas contagens de abertas. Linha que muda de time leva o número junto (ex.: a 56 está no Atacado Cash Payments desde a rodada 6). Linha nova recebe o próximo número livre (77).
- **Opções do Convênio (A/B/C/D):** as letras são as mesmas em 02 (DEC-CON-02), 03 §4.3, 04 (ADR-11) e 06 (D12): **A** = novo serviço no ARO Atacado; **B** = sistema legado/de produto + ACL; **C** = Open Cash Hub; **D** = Salesforce com efetivação no legado (não recomendada). O 02 (DEC-CON-02, v0.4) foi corrigido após a entrega e agora usa as mesmas letras.

## Resumo

| Time | Questões consolidadas (abertas) | IDs cobertos (abertos) | Com prazo-limite | Encerradas |
|---|---|---|---|---|
| Atacado Cash Payments | 55 | 78 | 26 | — |
| Canais | 4 | 6 | 3 | 1 linha (4 IDs) |
| Experiência | 7 | 8 | 5 | — |
| GACD | 10 | 18 | 5 | — |
| **Total** | **76** | **109 IDs únicos** (QA-CON-14 conta nas duas linhas) | **39** | **1 linha (4 IDs)** |

Distribuição dos 113 IDs registrados por documento: QA-CONV 13 e QA-NEG 20 (01), QA-CON 25 (02), QA-DDD 13 (03), QA-TEC 18 (04) + 12 (05), QA-RMP 12 (06). Destes, 4 estão encerrados desde a rodada 6 (QA-NEG-04, QA-CON-08, QA-TEC-08, QA-DDD-08) e 109 seguem abertos.

## Atacado Cash Payments (55)

### Convênio (13)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 1 | QA-CONV-01 / QA-CON-02 / QA-TEC-11 | Onde o Convênio é gerado, qual o sistema de registro e o contrato de integração (opção A/B/C/D)? | 01 §11; 02 §8.1; 04 §15 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | GACD (confirmar que não é escopo GACD) |
| 2 | QA-CONV-02 / QA-CONV-03 / QA-CON-03 | Quem gera o Convênio (Gerente de Cash ou backoffice, ver QA-CONV-12) e qual o gatilho que abre a implantação (callback de assinatura, contrato vigente, manual)? A ativação depende da homologação com o cliente | 01 §11; 02 §8.1 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | GACD (conteúdo do callback) |
| 3 | QA-CONV-04 / QA-CONV-08 / QA-CON-04 | Cardinalidade termo × convênio (1 → N por produto)? Cliente com contrato vigente e produto novo gera convênio? | 01 §11; 02 §8.1 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 4 | QA-CONV-05 | O Convênio exige assinatura própria ou é coberto pelo termo? | 01 §11 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | GACD |
| 5 | QA-CONV-06 | O Convênio é documento assinado ou apenas registro cadastral? | 01 §11 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 6 | QA-CONV-07 / QA-CON-05 | Ordem convênio × cadastro de tarifas (texto do PRD × diagrama)? | 01 §11; 02 §8.1 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 7 | QA-CONV-09 | O processo de convênio do Open Cash Hub pode ser reutilizado para clientes fora do ERP? | 01 §11 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | Time do Open Cash Hub |
| 8 | QA-CONV-10 | Quais dados o Convênio exige, de onde vêm, e o identificador é chave para o Databricks? | 01 §11 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 9 | QA-CONV-11 | Tratamento de falha na geração do convênio, incluindo falha ou atraso na homologação com o cliente (retentativa, fila de exceção, responsável)? | 01 §11 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 10 | QA-CONV-12 / QA-CON-24 | Quem executa a implantação do produto (Gerente de Cash ou backoffice): parâmetros com o cliente, convênio em teste, homologação e ativação? | 01 §11; 02 §8.1 | 30/04/27 (D12 — executor, em qualquer opção) | — |
| 11 | QA-CONV-13 / QA-CON-25 | Quais produtos Cash exigem homologação e existe hoje uma área de implantação de Cash (candidata natural a executora)? | 01 §11; 02 §8.1 | 30/04/27 (D12) | — |
| 12 | QA-DDD-06 | Gatilho do Convênio por coreografia (BC-04 assina o evento) ou orquestração pelo BC-01? Quem guarda "Convênio pendente"? | 03 §9.1 | 26/02/27 se opção A; 30/04/27 se B/C (D12) | — |
| 13 | QA-DDD-11 | Interface do Databricks (Tarifas): como recebe convênios e sinaliza TarifasCadastradas (evento, tabela, arquivo)? | 03 §9.1 | — | — |

### Negócio e planejamento (19)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 14 | QA-NEG-01 / QA-CON-01 | Gerenciador oficial de termos: GACD × Open Cash Hub? | 01 §12; 02 §8.1 | 30/10/26 (D1) | GACD, Arquitetura |
| 15 | QA-NEG-03 / QA-DDD-12 | Regras de assinatura (isolada/conjunta, quantidade, alçada) e tratamento quando a FIRP não retorna assinantes (falha ou estado próprio)? | 01 §12; 03 §9.1 | — | GACD, Experiência, FIRP |
| 16 | QA-NEG-06 / QA-CON-18 | Baseline do tempo de negociação → assinatura (KPI-02)? | 01 §12; 02 §8.1 | 31/03/27 (D14) | — |
| 17 | QA-RMP-01 | O relógio do KPI-01 começa no piloto ou no go-live amplo? O denominador inclui BGS e produtos fora do lote 1? | 06 §13 | 31/03/27 (D14) | Canais |
| 18 | QA-NEG-07 / QA-CON-17 | Critérios de conformidade regulatória, validade jurídica, prazo de guarda e LGPD do termo? | 01 §12; 02 §8.1 | 26/02/27 (D10 — critérios de conformidade) | Jurídico/Compliance |
| 19 | QA-NEG-08 / QA-CON-06 / QA-DDD-07 | Quais produtos de Cash/Payments estão no escopo e existe catálogo de códigos de produto de referência? | 01 §12; 02 §8.1; 03 §9.1 | 15/01/27 piloto; 30/04/27 lote 1 (D9) | — |
| 20 | QA-NEG-10 / QA-CON-19 | Conteúdo do termo (texto jurídico, variáveis, produtos listados) e dono/versionamento dos 2 modelos? | 01 §12; 02 §8.1 | 18/12/26 (D10 — modelo "Produtos"); 30/04/27 ("Produtos + Canal") | Jurídico/Compliance; IMPD se Plano A |
| 21 | QA-NEG-12 | Como tratar recusa ou cancelamento do termo (pelo cliente ou por alteração da proposta)? | 01 §12 | — | GACD |
| 22 | QA-NEG-14 / QA-CON-21 | Qual sistema/critério é a fonte de verdade de "contrato vigente"? | 01 §12; 02 §8.1 | — | — |
| 23 | QA-NEG-16 / QA-DDD-01 | Unidade e unicidade do termo: por CNPJ, raiz ou grupo econômico? Um agregado por solicitação ou por cliente? | 01 §12; 03 §9.1 | — | — |
| 24 | QA-CON-22 | Cliente com termo já assinado que adere a novo produto precisa de novo termo? | 02 §8.1 | — | — |
| 25 | QA-CON-23 | Quem aprova a proposta e a aprovação precede a solicitação do termo? | 02 §8.1 | — | — |
| 26 | QA-DDD-10 | A regra de elegibilidade e tipo de termo fica no Salesforce ou no BC-01? | 03 §9.1 | — | Experiência |
| 27 | QA-RMP-02 | Haverá reforço de capacidade (2 devs ou 2º squad) para a sobreposição de F4 e F5? | 06 §13 | — | — |
| 28 | QA-RMP-06 | Quem escolhe gerentes e clientes do piloto, com quais critérios, e quem autoriza cada onda? | 06 §13 | 15/01/27 piloto; 30/04/27 lote 1 (D9) | — |
| 29 | QA-RMP-09 | Calendário oficial de congelamento 2026/2027 e janelas de RDM (atacado-core, Axway, Salesforce)? | 06 §13 | — | Plataformas Funcionais |
| 30 | QA-RMP-10 | Quando e com qual critério o processo manual de termo é descontinuado? | 06 §13 | — | — |
| 56 | QA-CON-09 | Regras da revalidação de assinantes na FIRP pelo Atacado no callback (o que invalida, assinatura parcial, poderes alterados entre o envio e a assinatura)? Até a rodada 6, era do Canal e estava em Canais | 02 §8.1 | — | FIRP (dono junto com o Negócio) |
| 77 | QA-NEG-20 | Com a revalidação depois da assinatura registrada no GACD, o que acontece com o protocolo/termo já assinado quando os assinantes forem inválidos: cancelar o protocolo no GACD, invalidar o termo, exigir nova assinatura? Quem executa? Liga a RN-06, RN-07, CAP-04.2 e ADR-13. Até a resposta, vale o tratamento atual (estado Assinantes inválidos, alerta ao Gerente no Salesforce e reinício do envio) | 01 §12 | — | GACD (dono junto com o Negócio) |

### Técnicas (puxadas pelo Atacado com times de apoio) (23)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 31 | QA-TEC-01 | IMPD: conectividade ARO → impd-srv-doc-generator, autenticação, SLA, volumetria e consumidores cloud em produção? | 04 §15 | 06/11/26 (D2; limite absoluto 20/11/26) | IMPD, Plataformas Funcionais |
| 32 | QA-TEC-02 | IMPD: esforço, fornecedor e lead time dos 2 templates CSF Designer v21; PDF/A; limites de páginas e tamanho? | 04 §15 | 06/11/26 (D2; limite absoluto 20/11/26) | IMPD |
| 33 | QA-TEC-03 / QA-CON-14 (parte LEAP) | Token LEAP é padrão para workloads no ARO? Fluxo, emissor, TTL, escopos; vale para FIRP (COMP-01 e COMP-02), GACD e Salesforce? | 04 §15; 02 §8.1 | 27/11/26 (D4) | Segurança, Plataformas Funcionais |
| 34 | QA-TEC-05 / QA-CON-15 (parte FIRP) | Contrato FIRP: endpoint no Axway, modelo de representante/poder, assinatura conjunta, dados pessoais, SLA, HML? | 04 §15; 02 §8.1 | 27/11/26 (D6) | FIRP |
| 35 | QA-TEC-09 / QA-CON-13 / QA-CON-20 | Rede: localização de GACD e FIRP; rota Axway → ARO (callback); entrada do Salesforce e egress ARO → Salesforce; DNS? | 04 §15; 02 §8.1 | 20/11/26 (D7) | Plataformas Funcionais, GACD |
| 36 | QA-TEC-10 | Limites de corpo e timeout de Axway, WAF e Akamai; tamanho real do PDF do termo? | 04 §15 | 20/11/26 (D7) | Plataformas Funcionais |
| 37 | QA-TEC-12 | Aprovação de PostgreSQL Flexible Server e Blob Storage (fora do stack) no spoke? | 04 §15 | 13/11/26 (D3) | Plataformas Funcionais |
| 38 | QA-TEC-28 | Extensões e parâmetros do PostgreSQL (pg_cron, pg_partman, pgaudit, PgBouncer, particionamento)? | 05 §16 | — | Plataformas Funcionais |
| 39 | QA-TEC-13 / QA-DDD-05 | Existe broker corporativo (Service Bus, Kafka, Event Grid) disponível para o atacado-core? | 04 §15; 03 §9.1 | — | Plataformas Funcionais |
| 40 | QA-TEC-14 | Identidade de workload no ARO (Entra Workload ID ou service principal); CSI Driver ou External Secrets? | 04 §15 | — | Plataformas Funcionais |
| 41 | QA-TEC-15 | Salesforce: objetos, Connected App/External Client App, usuário de integração, limites de API, mTLS, UI da prévia? | 04 §15 | — | Experiência |
| 42 | QA-TEC-16 | Ferramenta corporativa de observabilidade e suporte a OpenTelemetry no ARO? | 04 §15 | — | Plataformas Funcionais |
| 43 | QA-TEC-17 | Retenção da trilha de auditoria, do staging e da inbox; exportação para Databricks (KPIs)? | 04 §15 | — | Segurança |
| 44 | QA-TEC-19 | Esteira CI/CD e GitOps para o ARO: ferramentas, gates SAST/SCA/DAST, Testcontainers, assinatura de imagem, Job de migração? | 05 §16 | — | Plataformas Funcionais |
| 45 | QA-TEC-20 | IaC (Terraform ou Bicep): módulos corporativos, quem aplica e onde fica o state? | 05 §16 | — | Plataformas Funcionais |
| 46 | QA-TEC-21 | HML integrada (GACD, FIRP, IMPD, sandbox Salesforce) com massa de CNPJs de teste coerente? | 05 §16 | — | GACD, FIRP, IMPD |
| 47 | QA-TEC-22 | Identidade e cabeçalhos propagados pelo Axway ao backend (client_id/DN, correlação, Idempotency-Key)? | 05 §16 | — | Plataformas Funcionais |
| 48 | QA-TEC-23 | Política de versionamento e depreciação de APIs no Axway (v1/v2, Deprecation/Sunset)? | 05 §16 | — | Plataformas Funcionais |
| 49 | QA-TEC-25 | FIRP, GACD, templates IMPD e Salesforce já aceitam o CNPJ alfanumérico? | 05 §16 | — | GACD, FIRP, IMPD |
| 50 | QA-TEC-26 | CA, validade e rotação coordenada dos certificados (mTLS Salesforce, JWT Bearer, mTLS GACD)? | 05 §16 | — | Segurança |
| 51 | QA-TEC-27 | Quem opera a API administrativa em produção; acesso em Prod; RDM para mudança de feature flag? | 05 §16 | — | Plataformas Funcionais |
| 52 | QA-TEC-29 | Autorização e ferramenta para DAST/pentest em HML; integração de eventos de autenticação negada ao SIEM? | 05 §16 | — | Segurança |
| 53 | QA-TEC-30 | Quais campos da Proposta o Salesforce envia em POST /v1/adesoes para compor as variáveis dos 2 modelos? | 05 §16 | — | Jurídico/Compliance |

## Canais (4 abertas + 1 encerrada)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 54 | QA-NEG-02 / QA-CON-07 | Como assinam os clientes do BGS enquanto o BGS não integra o GACD? | 01 §12; 02 §8.1 | 30/04/27 (D13) | — |
| 55 | QA-NEG-04 / QA-CON-08 / QA-TEC-08 / QA-DDD-08 | **Encerrada na rodada 6 (2026-10-16):** a revalidação passou ao Atacado (ADR-13); não há mais alerta do Canal. QA-CON-08, QA-TEC-08 e QA-DDD-08 não se aplicam; QA-NEG-04 foi substituída pela QA-NEG-20 (linha 77). Era: contrato da API de alerta de assinantes inválidos (o que o Canal faz, payload mínimo, autenticação, momento, retentativa, SLA, aceite e prazo no backlog) | 01 §12; 02 §8.1; 04 §15; 03 §9.1 | — (D11 cancelada) | — |
| 57 | QA-NEG-13 / QA-DDD-09 | "Produtos + Canal": quem efetiva a adesão ao canal após a assinatura e quem publica o sinal de termo assinado (GACD ou Atacado)? | 01 §12; 03 §9.1 | 30/04/27 (D13) | — |
| 58 | QA-RMP-03 | Em qual trimestre de planejamento de Canais entra o sinal de adesão ao canal? Qual a antecedência mínima? (A API de alerta saiu na rodada 6) | 06 §13 | 30/04/27 (D13) | — |
| 59 | QA-RMP-08 | Como o cliente do piloto é avisado da pendência de assinatura no PDPJ durante o piloto? | 06 §13 | — | Experiência |

## Experiência (7)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 60 | QA-NEG-05 / QA-CON-10 | Quem notifica o cliente (e-mail) sobre termo pendente: Canal, GACD ou Salesforce? | 01 §12; 02 §8.1 | 26/02/27 (DEP-15; sem decisão D-xx) | Canais |
| 61 | QA-NEG-09 | Personas do Gerente de Cash e do representante do cliente (vazias no PRD)? | 01 §12 | 11/12/26 (DEP-13; sem decisão D-xx) | — |
| 62 | QA-NEG-15 | Escopo do Time de Experiência: Salesforce, canal ou ambos? | 01 §12 | — | — |
| 63 | QA-NEG-18 | O Gerente revisa a prévia do termo e confirma antes do envio ao GACD? | 01 §12 | 11/12/26 (D8) | Atacado Cash Payments |
| 64 | QA-CON-11 | "Produtos + Canal": como o cliente novo acessa o Canal para assinar antes de ter acesso? | 02 §8.1 | — | Canais |
| 65 | QA-RMP-07 | Experiência conduz treinamento, comunicação e pesquisa de usabilidade de cada onda? Com qual capacidade? | 06 §13 | 26/03/27; 21/05/27 (DEP-14; sem decisão D-xx) | — |
| 66 | QA-RMP-11 | Quando o desenho da jornada do Gerente fica pronto para o squad e quem representa os Gerentes nas validações? | 06 §13 | 11/12/26 (D8) | Atacado Cash Payments |

## GACD (10)

| # | ID(s) | Questão | Origem | Prazo-limite | Apoio |
|---|---|---|---|---|---|
| 67 | QA-NEG-11 | Ciclo de vida do termo: estados, prazo de validade/expiração, reenvio e lembretes? | 01 §12 | — | Atacado Cash Payments |
| 68 | QA-NEG-17 / QA-DDD-13 / QA-TEC-18 | Guarda e acesso ao termo assinado: retenção, hash × cópia no BC-01 e API para o Gerente baixar o PDF assinado? | 01 §12; 03 §9.1; 04 §15 | — | — |
| 69 | QA-NEG-19 / QA-RMP-04 | Onboarding do Atacado como "Produto" consumidor do GACD: pré-requisitos, lead time e data da HML? | 01 §12; 06 §13 | 27/11/26 (D5) | — |
| 70 | QA-TEC-04 / QA-CON-14 (parte usuário sistêmico) | Usuário sistêmico do GACD: formato, provisionamento, rotação; vale só no Armazenar Prévia? | 04 §15; 02 §8.1 | 27/11/26 (D4) | Segurança |
| 71 | QA-TEC-06 / QA-CON-16 / QA-DDD-02 | Contratos v1 das 3 APIs: payloads, nomes oficiais, atomicidade/compensação, idempotência, consulta e cancelamento (reemissão)? | 04 §15; 02 §8.1; 03 §9.1 | 27/11/26 (D5) | — |
| 72 | QA-TEC-07 / QA-CON-12 / QA-DDD-03 | Callback e vocabulário de status: payload, estados (assinado, recusado, expirado, parcial), autenticação, retentativa, ACK? | 04 §15; 02 §8.1; 03 §9.1 | 27/11/26 (D5) | — |
| 73 | QA-DDD-04 | O GACD já consulta a FIRP para resolver assinantes? (define se a ACL-FIRP é só para exibição) | 03 §9.1 | 27/11/26 (D6) | FIRP via Atacado Cash Payments |
| 74 | QA-TEC-24 | O GACD exige CPF dos assinantes no passo 1? Aceita reconsulta à FIRP sem persistir o CPF? | 05 §16 | — | Segurança (LGPD) |
| 75 | QA-RMP-05 | O GACD suporta piloto restrito (lista de CNPJs ou produto) e qual seu calendário de congelamento? | 06 §13 | — | — |
| 76 | QA-RMP-12 | O GACD participa do hypercare (plantão e war room) nas Ondas 0, 1 e 3? | 06 §13 | — | — |

## Prazos-limite em ordem cronológica (decisões D-xx)

| Data | Decisão | Questões | Time |
|---|---|---|---|
| 30/10/26 | D1 — GACD × Open Cash Hub | QA-NEG-01 / QA-CON-01 | Atacado Cash Payments |
| 06/11/26 (limite 20/11/26) | D2 — IMPD Plano A × B | QA-TEC-01, QA-TEC-02 | Atacado Cash Payments (IMPD) |
| 13/11/26 | D3 — PostgreSQL/Blob fora do stack | QA-TEC-12 | Atacado Cash Payments (Plataformas Funcionais) |
| 20/11/26 | D7 — Rede e limites de payload | QA-TEC-09/10, QA-CON-13/20 | Atacado Cash Payments (Plataformas Funcionais) |
| 27/11/26 | D4 — LEAP e usuário sistêmico | QA-TEC-03, QA-TEC-04, QA-CON-14 | Atacado Cash Payments (Segurança); GACD |
| 27/11/26 | D5 — Contratos GACD e onboarding | QA-TEC-06/07, QA-NEG-19, QA-DDD-02/03, QA-CON-12/16, QA-RMP-04 | GACD |
| 27/11/26 | D6 — Contrato FIRP e papel FIRP × GACD | QA-TEC-05, QA-CON-15, QA-DDD-04 | Atacado Cash Payments (FIRP); GACD |
| 11/12/26 | D8 — Prévia/confirmação e jornada do Gerente | QA-NEG-18, QA-RMP-11 | Experiência |
| 18/12/26 · 26/02/27 · 30/04/27 | D10 — Texto "Produtos" · conformidade · "Produtos + Canal" | QA-NEG-10, QA-CON-19 · QA-NEG-07, QA-CON-17 | Atacado Cash Payments (Jurídico/Compliance) |
| 15/01/27 · 30/04/27 | D9 — Produto e clientes do piloto · lote 1 | QA-NEG-08, QA-CON-06, QA-DDD-07, QA-RMP-06 | Atacado Cash Payments |
| ~~26/02/27~~ | D11 — **Cancelada na rodada 6 (2026-10-16):** a revalidação passou ao Atacado (ADR-13); não há mais contrato da API de alerta com Canais | QA-TEC-08, QA-NEG-04, QA-CON-08, QA-DDD-08 encerradas; QA-RMP-03 segue só na D13 | — |
| 26/02/27 (A) · 30/04/27 (B/C e executor da implantação) | D12 — Convênio e executor da implantação | QA-CONV-01..13, QA-CON-02..05, QA-CON-24/25, QA-TEC-11, QA-DDD-06 | Atacado Cash Payments |
| 31/03/27 | D14 — Baseline KPI-02 e relógio/denominador KPI-01 | QA-NEG-06, QA-CON-18, QA-RMP-01 | Atacado Cash Payments |
| 30/04/27 | D13 — BGS e sinal de adesão ao canal | QA-NEG-02, QA-CON-07, QA-NEG-13, QA-DDD-09, QA-RMP-03 | Canais |
