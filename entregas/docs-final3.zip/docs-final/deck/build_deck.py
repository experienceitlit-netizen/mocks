"""
build_deck.py — Apresentação executiva do Termo de Adesão Multiproduto.

Style: deckkit (scripts/deckkit.py) — paleta, Calibri, header/footer, sem sombras.
Layout: estrutura de slides do scripts/sample-ppt.pptx (capa, agenda, onepage,
divisores, camadas, capacidades, AS-IS→TO-BE, macro, tabelas, Gantt, encerramento).

Conteúdo: deck/conteudo/topico1.json .. topico6.json (não editar aqui). O slide final de
glossário lê as tabelas de docs-final/09-glossario-de-siglas.md.

Uso:
    python3 build_deck.py            # gera docs-final/07-apresentacao-executiva.pptx
    python3 build_deck.py --pdf      # também exporta o PDF (requer soffice no PATH)
    python3 build_deck.py --render DIR  # PDF + PNG por slide em DIR (soffice + pdftoppm)

Para render fiel ao Calibri sem a fonte instalada, aponte FONTCONFIG_FILE para um
fonts.conf que inclua a fonte Carlito (métrica idêntica ao Calibri).
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True   # não gravar __pycache__ em scripts/
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, os.path.join(ROOT, 'scripts'))

import deckkit  # noqa: E402
from deckkit import (Deck, Slide, emu, M, CONTENT_W,  # noqa: E402
                     RED, DARK, GREY, LGREY, ALT, PINK, BORDER, RULE, RULE_SOFT, WHITE)

# Hífen inseparável (U+2011) dentro de identificadores (QA-CON-02/03, RSK-RMP-01,
# COMP-01...) para que não quebrem no fim da linha. Nomes kebab-case não são tocados.
NBH = '\u2011'
_ID_NB = re.compile(r'\b[A-Z]{2,5}(?:-[A-Z]{2,5})?-\d[\w./]*')
_run_kit = deckkit.run


def run(t, *a, **k):
    return _run_kit(_ID_NB.sub(lambda m: m.group(0).replace('-', NBH), t), *a, **k)


deckkit.run = run   # vale também para header/callout/footer do deckkit


def tech(name):
    """Nome técnico dos serviços (atacado-adesao-*) sem quebra de linha, só em caixas."""
    return name.replace('-', NBH) if name.startswith('atacado-adesao-') else name

CONTEUDO = os.path.join(HERE, 'conteudo')
OUT_PPTX = os.path.join(ROOT, 'docs-final', '07-apresentacao-executiva.pptx')

# cores semânticas extras (permitidas só com significado)
AMBER = 'F2A900'   # semáforo médio
GREEN = '2E7D32'   # semáforo baixo
WINE = 'A50021'    # marcos
BLUE = '1F4E79'    # evolução

FOOT = 'Bradesco  |  Termo de Adesão Multiproduto  |  Uso interno'
X_END = M + CONTENT_W   # 12.73

ID_RE = re.compile(r'\b[A-Z]{2,5}(?:-[A-Z]{2,5})?-\d+(?:\.\d+)?(?:/\d+)?\b')


def load(n):
    with open(os.path.join(CONTEUDO, f'topico{n}.json'), encoding='utf-8') as f:
        return json.load(f)


def idruns(text, sz, c_id, c_txt, b_txt=False, i_txt=False):
    """Quebra o texto em runs, deixando identificadores (CAP-02, QA-CON-12...) em negrito."""
    out, pos = [], 0
    for m in ID_RE.finditer(text):
        if m.start() > pos:
            out.append(run(text[pos:m.start()], sz, c_txt, b=b_txt, i=i_txt))
        out.append(run(m.group(0), sz, c_id, b=True, i=i_txt))
        pos = m.end()
    if pos < len(text):
        out.append(run(text[pos:], sz, c_txt, b=b_txt, i=i_txt))
    return out


# ============================================================ slide estendido
class S(Slide):
    """Slide do deckkit + primitivas que ele não cobre (mesmo XML, sem sombra)."""

    def __init__(self, number=0):
        super().__init__(number)
        self.notes = None

    @staticmethod
    def _ln(color, lw=12700, dash=None, head=False):
        if not color:
            return '<a:ln><a:noFill/></a:ln>'
        d = f'<a:prstDash val="{dash}"/>' if dash else ''
        h = '<a:tailEnd type="triangle" w="med" len="med"/>' if head else ''
        return (f'<a:ln w="{lw}"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
                f'{d}{h}</a:ln>')

    def rect(self, x, y, w, h, fill=WHITE, line=None, prst='rect', adj=None,
             lw=12700, dash=None, patt=None):
        """Forma com borda opcional tracejada. adj → roundRect (ou ajuste do prst dado)."""
        if adj is not None:
            pg = 'roundRect' if prst == 'rect' else prst
            geom = (f'<a:prstGeom prst="{pg}"><a:avLst><a:gd name="adj" fmla="val {adj}"/>'
                    f'</a:avLst></a:prstGeom>')
        else:
            geom = f'<a:prstGeom prst="{prst}"><a:avLst/></a:prstGeom>'
        if patt:
            fg, bg = patt
            f = (f'<a:pattFill prst="wdUpDiag"><a:fgClr><a:srgbClr val="{fg}"/></a:fgClr>'
                 f'<a:bgClr><a:srgbClr val="{bg}"/></a:bgClr></a:pattFill>')
        else:
            f = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else '<a:noFill/>'
        i = self._next()
        self._shapes.append(
            f'<p:sp><p:nvSpPr><p:cNvPr id="{i}" name="Shape {i}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>'
            f'{geom}{f}{self._ln(line, lw, dash)}</p:spPr></p:sp>')
        return self

    def seg(self, x1, y1, x2, y2, color=GREY, lw=12700, head=False, dash=None):
        """Segmento reto em qualquer direção; head=True põe seta no ponto final."""
        x, y = min(x1, x2), min(y1, y2)
        w, h = abs(x2 - x1), abs(y2 - y1)
        flip = (' flipH="1"' if x2 < x1 else '') + (' flipV="1"' if y2 < y1 else '')
        i = self._next()
        self._shapes.append(
            f'<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="{i}" name="Conn {i}"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>'
            f'<p:spPr><a:xfrm{flip}><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>'
            f'<a:prstGeom prst="line"><a:avLst/></a:prstGeom>{self._ln(color, lw, dash, head)}</p:spPr></p:cxnSp>')
        return self

    def path(self, pts, color=GREY, lw=12700, head=True, dash=None):
        """Poligonal ortogonal; seta só no último segmento."""
        for k in range(len(pts) - 1):
            (a, b), (c, d) = pts[k], pts[k + 1]
            self.seg(a, b, c, d, color, lw, head and k == len(pts) - 2, dash)
        return self

    def tx(self, x, y, w, h, paras, align='l', anchor='t', before=0, vert=None, bul=RED):
        """Texto com parágrafos ricos: cada item é lista de runs ou
        dict(runs=[...], bullet=bool, before=pt, align=...)."""
        if paras and isinstance(paras[0], str):
            paras = [paras]
        body = ''
        for p in paras:
            if isinstance(p, dict):
                runs, b_, bef, al = p['runs'], p.get('bullet'), p.get('before', before), p.get('align', align)
            else:
                runs, b_, bef, al = p, False, before, align
            spc = f'<a:spcBef><a:spcPts val="{int(bef * 100)}"/></a:spcBef>' if bef else ''
            if b_:
                ppr = (f'<a:pPr marL="{emu(0.13)}" indent="-{emu(0.13)}" algn="{al}">{spc}'
                       f'<a:buClr><a:srgbClr val="{bul}"/></a:buClr><a:buSzPct val="100000"/>'
                       f'<a:buFont typeface="Arial"/><a:buChar char="&#9642;"/></a:pPr>')
            else:
                ppr = f'<a:pPr algn="{al}" indent="0" marL="0">{spc}<a:buNone/></a:pPr>'
            body += '<a:p>' + ppr + ''.join(runs) + '</a:p>'
        v = f' vert="{vert}"' if vert else ''
        i = self._next()
        self._shapes.append(
            f'<p:sp><p:nvSpPr><p:cNvPr id="{i}" name="Text {i}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr>'
            f'<p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" rtlCol="0" anchor="{anchor}"{v}/>'
            f'<a:lstStyle/>{body}</p:txBody></p:sp>')
        return self

    def badge(self, cx, cy, label, fill=RED, d=0.21):
        self.rect(cx - d / 2, cy - d / 2, d, d, fill, WHITE, prst='ellipse', lw=9525)
        self.tx(cx - 0.2, cy - d / 2, 0.4, d, [[run(label, 7.3, WHITE, b=True)]], align='ctr', anchor='ctr')
        return self

    def table(self, x, y, widths, rows, mar=(0.07, 0.035)):
        """Tabela nativa. rows: [(altura, [cell, ...])];
        cell = dict(p=parágrafos, fill=hex|None, align, anchor, line=hex|None)."""
        ml, mt = emu(mar[0]), emu(mar[1])
        grid = ''.join(f'<a:gridCol w="{emu(w)}"/>' for w in widths)
        trs = ''
        for h, cells in rows:
            tcs = ''
            for c in cells:
                paras = c['p']
                if paras and isinstance(paras[0], str):
                    paras = [paras]
                body = ''
                for p in paras:
                    al = c.get('align', 'l')
                    body += (f'<a:p><a:pPr algn="{al}" indent="0" marL="0"><a:buNone/></a:pPr>'
                             + ''.join(p) + '</a:p>')
                none = '<a:noFill/>'
                ln_b = (f'<a:lnB w="6350"><a:solidFill><a:srgbClr val="{c["line"]}"/></a:solidFill></a:lnB>'
                        if c.get('line') else f'<a:lnB w="0">{none}</a:lnB>')
                fill = (f'<a:solidFill><a:srgbClr val="{c["fill"]}"/></a:solidFill>'
                        if c.get('fill') else none)
                tcs += (f'<a:tc><a:txBody><a:bodyPr/><a:lstStyle/>{body}</a:txBody>'
                        f'<a:tcPr marL="{ml}" marR="{ml}" marT="{mt}" marB="{mt}" anchor="{c.get("anchor", "ctr")}">'
                        f'<a:lnL w="0">{none}</a:lnL><a:lnR w="0">{none}</a:lnR>'
                        f'<a:lnT w="0">{none}</a:lnT>{ln_b}{fill}</a:tcPr></a:tc>')
            trs += f'<a:tr h="{emu(h)}">{tcs}</a:tr>'
        i = self._next()
        tw, th = sum(widths), sum(h for h, _ in rows)
        self._shapes.append(
            f'<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="{i}" name="Table {i}"/>'
            f'<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>'
            f'<p:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(tw)}" cy="{emu(th)}"/></p:xfrm>'
            f'<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">'
            f'<a:tbl><a:tblPr/><a:tblGrid>{grid}</a:tblGrid>{trs}</a:tbl></a:graphicData></a:graphic>'
            f'</p:graphicFrame>')
        return self

    def label(self, x, y, w, text, color=RED, sz=10.5):
        return self.tx(x, y, w, 0.24, [[run(text, sz, color, b=True)]], anchor='ctr')

    def foot(self):
        return self.footer(FOOT)


class D(Deck):
    def slide(self, number=None) -> S:
        s = S(number if number is not None else len(self.slides) + 1)
        self.slides.append(s)
        return s


# ================================================================== slides
def capa(deck):
    s = deck.slide()
    s.rect(0, 0, 13.333, 7.5, RED)
    s.tx(0.80, 0.80, 8.0, 0.35, [[run('BRADESCO', 14, WHITE, b=True, spc=300)]], anchor='ctr')
    s.tx(0.80, 2.30, 11.5, 0.90, [[run('Termo de Adesão Multiproduto', 44, WHITE, b=True)]], anchor='ctr')
    s.tx(0.80, 3.30, 11.5, 0.50,
         [[run('Cash Management / Payments — Arquitetura de Solução', 20, WHITE)]], anchor='ctr')
    s.rect(0.80, 5.30, 11.73, 0.02, WHITE)
    s.tx(0.80, 5.50, 11.0, 0.95, [
        [run('Diretoria Comercial Atacado  |  Arquitetura', 12, WHITE, b=True)],
        [run('Setembro/2026', 12, WHITE)],
        [run('Versão para validação', 12, WHITE, i=True)]], anchor='t', before=2)
    s.notes = ('Apresentação executiva da arquitetura de solução do Termo de Adesão Multiproduto '
               '(Cash Management / Payments). Versão para validação com os times envolvidos.')


AGENDA = [
    ('Onepage de arquitetura', 'Objetivo, capacidades, módulos, stack, princípios e números em uma página'),
    ('Desenho conceitual: estratégia e capacidades', 'Value stream da adesão, camadas da estratégia à tecnologia e as 13 capacidades'),
    ('Desenho macro de arquitetura', 'AS-IS → TO-BE, visão de contêineres e decisões de arquitetura'),
    ('Riscos identificados', 'Os riscos de maior probabilidade × impacto, com mitigação e dono'),
    ('Questões em aberto', 'Dúvidas de negócio e técnicas por time, com prazo-limite'),
    ('Roadmap de implementação', 'Fases F0 a F5, marcos, caminho crítico e decisões do roadmap'),
]


def agenda(deck):
    s = deck.slide()
    s.header('AGENDA', 'Seis tópicos, da visão à execução')
    y0, step, sq = 1.62, 0.88, 0.62
    for k, (t, d) in enumerate(AGENDA):
        y = y0 + k * step
        s.rect(M, y, sq, sq, RED)
        s.tx(M, y, sq, sq, [[run(str(k + 1), 22, WHITE, b=True)]], align='ctr', anchor='ctr')
        s.tx(M + 0.85, y + 0.02, 10.5, 0.34, [[run(t, 16, DARK, b=True)]], anchor='ctr')
        s.tx(M + 0.85, y + 0.37, 10.5, 0.24, [[run(d, 10.5, GREY)]], anchor='ctr')
    s.foot()
    s.notes = ('Percurso em seis tópicos: a visão em uma página, o desenho conceitual, a arquitetura macro, '
               'os riscos, as questões em aberto e o roadmap. O pedido ao final é fechar as decisões da F0.')


def divisor(deck, num, title, desc, notes=None):
    s = deck.slide()
    s.notes = notes
    s.rect(0, 0, 4.40, 7.5, RED)
    s.tx(0.60, 2.55, 3.40, 1.60, [[run(num, 96, WHITE, b=True)]], anchor='ctr')
    s.tx(5.00, 2.50, 7.50, 0.32, [[run(f'SEÇÃO {num}', 13, RED, b=True, spc=200)]], anchor='ctr')
    s.tx(5.00, 2.88, 7.73, 0.80, [[run(title, 36, DARK, b=True)]], anchor='ctr')
    s.rect(5.00, 3.84, 0.90, 0.05, RED)
    s.tx(5.00, 4.06, 7.20, 0.90, [[run(desc, 14, GREY)]], anchor='t')
    s.tx(5.00, 7.08, 6.0, 0.30, [[run(FOOT, 9, GREY)]], anchor='ctr')
    s.tx(12.50, 7.08, 0.50, 0.30, [[run(str(s.number), 9, GREY)]], align='r', anchor='ctr')


# ------------------------------------------------------------- tópico 1
def onepage(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    y, h = 1.83, 0.60
    s.rect(M, y, CONTENT_W, h, PINK)
    s.rect(M, y, 0.06, h, RED)
    s.tx(M + 0.22, y, CONTENT_W - 0.40, h,
         [[run('OBJETIVO   ', 9, RED, b=True, spc=100), run(c['objetivo'], 10, DARK)]], anchor='ctr')

    LX, LW = M, 7.95
    RX = 8.78
    RW = X_END - RX

    # capacidades
    s.label(LX, 2.55, LW, 'Capacidades de negócio')
    gap = 0.14
    cw, cy, ch = (LW - 2 * gap) / 3, 2.83, 1.50
    for k, cap in enumerate(c['capacidades']):
        x = LX + k * (cw + gap)
        t = cap['status_tipo']
        bar = {'novo': RED, 'reuso': GREY, 'aberto': LGREY}[t]
        border = {'novo': RED, 'reuso': BORDER, 'aberto': GREY}[t]
        dash = 'dash' if t == 'aberto' else None
        s.rect(x, cy, cw, ch, WHITE, border, dash=dash)
        s.rect(x, cy, cw, 0.34, bar, border if dash else None, dash=dash)
        s.tx(x + 0.10, cy, cw - 0.20, 0.34,
             [[run(cap['titulo'], 10, DARK if dash else WHITE, b=True)]], align='ctr', anchor='ctr')
        s.tx(x + 0.16, cy + 0.44, cw - 0.30, 0.66,
             [dict(runs=[run(b_, 8.5, DARK)], bullet=True, before=1.5 if j else 0)
              for j, b_ in enumerate(cap['bullets'])])
        pf, pl, pt = {'novo': (PINK, None, RED), 'reuso': (LGREY, None, DARK),
                      'aberto': (WHITE, GREY, GREY)}[t]
        s.rect(x + 0.16, cy + ch - 0.33, cw - 0.32, 0.22, pf, pl, adj=50000, dash=dash, lw=9525)
        s.tx(x + 0.16, cy + ch - 0.33, cw - 0.32, 0.22,
             [[run(cap['status'].upper(), 7.6, pt, b=True, spc=100)]], align='ctr', anchor='ctr')

    # módulos
    s.label(LX, 4.44, LW, 'Módulos da solução')
    mg = 0.12
    mw, my, mh = (LW - 3 * mg) / 4, 4.72, 0.74
    for k, m in enumerate(c['modulos']):
        x = LX + k * (mw + mg)
        dash = 'dash' if k == 3 else None
        s.rect(x, my, mw, mh, PINK, RED if dash else None, dash=dash, lw=9525)
        s.tx(x + 0.10, my + 0.06, mw - 0.20, 0.64, [
            [run(m['id'], 7.6, RED, b=True, spc=100)],
            [run(tech(m['nome']), 8, DARK, b=True)],
            dict(runs=[run(m['desc'], 7.6, GREY)], before=1)])

    # stack
    s.label(LX, 5.57, LW, 'Stack e integrações')
    lab_w = 0.62
    for r, items in enumerate(c['stack']):
        yy, hh = 5.85 + r * 0.36, 0.28
        s.tx(LX, yy, lab_w, hh, [[run('entrada' if r == 0 else 'consome', 7.6, GREY, i=True)]], anchor='ctr')
        g = 0.26 if r == 0 else 0.10
        raw = [len(t) * 0.052 + 0.22 for t in items]
        avail = LW - lab_w - g * (len(items) - 1)
        ws = [w_ * avail / sum(raw) for w_ in raw]
        x = LX + lab_w
        for k, (t, w_) in enumerate(zip(items, ws)):
            hl = 'ARO' in t
            s.rect(x, yy, w_, hh, PINK if hl else LGREY, None, adj=50000)
            s.tx(x + 0.04, yy, w_ - 0.08, hh, [[run(t, 7.6, RED if hl else DARK, b=hl)]],
                 align='ctr', anchor='ctr')
            if r == 0 and k < len(items) - 1:
                s.seg(x + w_ + 0.05, yy + hh / 2, x + w_ + g - 0.05, yy + hh / 2, GREY, 9525, head=True)
            x += w_ + g
    s.tx(LX, 6.58, LW, 0.26, [[run(c['nota_stack'], 7.6, GREY, i=True)]], anchor='ctr')

    # princípios
    s.rect(RX, 2.55, RW, 0.34, RED)
    s.tx(RX + 0.14, 2.55, RW - 0.28, 0.34, [[run('Princípios de arquitetura', 10.5, WHITE, b=True)]],
         align='ctr', anchor='ctr')
    s.rect(RX, 2.89, RW, 1.72, WHITE, BORDER)
    s.tx(RX + 0.16, 3.00, RW - 0.32, 1.55,
         [dict(runs=[run(f'{k + 1}.  ', 9, RED, b=True), run(p, 9, DARK)], before=4 if k else 0)
          for k, p in enumerate(c['principios'])])

    # números
    s.label(RX, 4.70, RW, 'Números de contexto')
    ng = 0.12
    nw, nh = (RW - ng) / 2, 0.88
    for k, n in enumerate(c['numeros']):
        x = RX + (k % 2) * (nw + ng)
        y = 4.98 + (k // 2) * (nh + 0.10)
        s.rect(x, y, nw, nh, LGREY)
        s.rect(x, y, 0.06, nh, RED)
        s.tx(x + 0.18, y + 0.05, nw - 0.26, 0.38, [[run(n['valor'], 22, RED, b=True)]], anchor='ctr')
        s.tx(x + 0.18, y + 0.45, nw - 0.26, 0.38, [[run(n['legenda'], 7.6, GREY)]], anchor='t')
    s.foot()
    s.notes = c['notas_orador']


# ------------------------------------------------------------- tópico 2
def caixa_estado(s, x, y, w, h, estado):
    """Caixa no código visual do tópico 02: foco (rosa), reuso (branca) ou definir (tracejada)."""
    if estado == 'foco':
        s.rect(x, y, w, h, PINK, None, lw=9525)
    elif estado == 'definir':
        s.rect(x, y, w, h, WHITE, GREY, dash='dash', lw=9525)
    else:
        s.rect(x, y, w, h, WHITE, BORDER, lw=9525)


def legenda_estados(s, y, itens, x0=M, x1=X_END):
    """Legenda em uma linha com amostras reais das caixas: [{estado, rotulo, texto}, ...]."""
    sw, sh = 0.34, 0.20
    larg = [sw + 0.12 + (len(it['rotulo']) + 3) * 0.058 + len(it['texto']) * 0.052 for it in itens]
    g = (x1 - x0 - sum(larg)) / (len(itens) - 1) if len(itens) > 1 else 0
    x = x0
    for it, w_ in zip(itens, larg):
        caixa_estado(s, x, y + 0.01, sw, sh, it['estado'])
        s.tx(x + sw + 0.12, y, w_ - sw - 0.12, sh + 0.02,
             [[run(it['rotulo'], 8, DARK, b=True), run('  ' + it['texto'], 8, GREY)]], anchor='ctr')
        x += w_ + g


def camadas(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    y0, bh, gap = 1.86, 0.72, 0.07
    lx, lw = M, 1.50
    bx0, bx1 = 2.24, 11.98
    n = 5
    bw = (bx1 - bx0 - (n - 1) * 0.10) / n
    for k, cam in enumerate(c['camadas']):
        y = y0 + k * (bh + gap)
        s.rect(lx, y, bx1 - lx + 0.08, bh, ALT)
        s.rect(lx, y, lw, bh, LGREY)
        s.rect(lx, y, 0.06, bh, RED)
        s.tx(lx + 0.20, y, lw - 0.26, bh, [[run(f'{k + 1}', 16, RED, b=True)],
                                          [run(cam['rotulo'], 10, DARK, b=True)]], anchor='ctr')
        for j, cx in enumerate(cam['caixas'][:n]):
            # caixa = texto simples ou {nome, ids, tracejado}: nome canônico com os IDs
            # numa linha menor e cinza abaixo (faixa Capacidades). "tracejado" na camada
            # lista as caixas a definir (índices), como "destaque" lista as caixas em foco.
            if isinstance(cx, str):
                t, ids, tracejado = cx, None, j in cam.get('tracejado', [])
            else:
                t, ids, tracejado = cx['nome'], cx.get('ids'), cx.get('tracejado', False)
            x = bx0 + j * (bw + 0.10)
            hl = j in cam.get('destaque', [])
            dash = 'dash' if tracejado else None
            s.rect(x, y + 0.06, bw, bh - 0.12, PINK if hl else WHITE,
                   (RED if hl else GREY) if dash else (None if hl else BORDER), dash=dash, lw=9525)
            paras = [idruns(t, 9, RED if hl else GREY, DARK if hl else GREY)]
            if ids:
                paras.append(dict(runs=[run(ids, 7.6, GREY)], before=0.5))
            s.tx(x + 0.08, y + 0.06, bw - 0.16, bh - 0.12, paras, align='ctr', anchor='ctr')
    y_end = y0 + 6 * bh + 5 * gap
    legenda_estados(s, y_end + 0.13, c['legenda'])
    ax, aw = 12.20, 0.50
    s.rect(ax, y0, aw, y_end - y0, PINK, prst='upArrow')
    s.tx(ax, y0 + 0.55, aw, y_end - y0 - 0.65, [[run(c['seta_vertical'], 8.5, RED, b=True)]],
         align='ctr', anchor='ctr', vert='vert270')
    s.foot()
    s.notes = c['notas_orador']


def value_stream(deck, c, legenda):
    """Value stream VS-01 × capacidades (04c §3.1, am-02-estrategia): estágios em chevrons,
    uma coluna de capacidades por estágio e a faixa das transversais embaixo."""
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])

    def cap(x, y, w, h, k):
        caixa_estado(s, x, y, w, h, k['estado'])
        foco = k['estado'] == 'foco'
        s.tx(x + 0.08, y, w - 0.16, h, [
            [run(k['nome'], 9, DARK if foco else GREY, b=foco)],
            dict(runs=[run(k['ids'], 7.6, GREY)], before=0.5)], align='ctr', anchor='ctr')

    # estágios (chevrons) e valor entregue
    vw = 1.85
    w5 = CONTENT_W - vw - 0.22
    n = len(c['estagios'])
    step = w5 / n
    y0, ch, dp = 1.86, 0.66, 0.20            # dp = profundidade da ponta do chevron
    adj = int(dp / ch * 100000)
    for i, e in enumerate(c['estagios']):
        x = M + i * step
        s.rect(x, y0, step + dp - 0.06, ch, LGREY, None, prst='homePlate' if i == 0 else 'chevron', adj=adj)
        # texto no corpo do chevron: do entalhe (ou da borda, no primeiro) até o início da ponta
        tx0, tw_ = (x + dp + 0.06, step - dp - 0.16) if i else (x + 0.12, step - 0.22)
        s.tx(tx0, y0, tw_, ch, [
            [run(e['id'], 7.6, RED, b=True, spc=80)],
            [run(e['nome'], 8.5, DARK, b=True)]], anchor='ctr')
    vx = M + w5 + 0.22
    s.rect(vx, y0, X_END - vx, ch, RED)
    s.tx(vx + 0.12, y0, X_END - vx - 0.20, ch, [
        [run(c['valor']['rotulo'].upper(), 7.3, WHITE, b=True, spc=100)],
        [run(c['valor']['texto'], 8.5, WHITE, b=True)]], anchor='ctr')

    # colunas de capacidades por estágio
    cy0 = y0 + ch + 0.14
    s.tx(M, cy0, 6.0, 0.18, [[run('CAPACIDADES QUE SERVEM CADA ESTÁGIO', 7.6, GREY, b=True, spc=150)]], anchor='ctr')
    ky, kh, kg = cy0 + 0.26, 0.60, 0.08
    cw = step - 0.14
    for i, e in enumerate(c['estagios']):
        x = M + i * step
        y = ky
        for k in e['capacidades']:
            cap(x, y, cw, kh, k)
            y += kh + kg
        if e.get('nota'):
            s.tx(x, y - 0.02, cw, 0.50, [[run(e['nota'], 7.6, GREY, i=True)]], align='ctr')
    s.tx(vx + 0.04, ky, X_END - vx - 0.04, 2.40, [[run(c['leitura'], 8.5, GREY, i=True)]])

    # transversais
    t = c['transversais']
    by, bh = ky + 4 * kh + 3 * kg + 0.16, 0.74
    s.rect(M, by, CONTENT_W, bh, ALT)
    s.rect(M, by, step - 0.14, bh, LGREY)
    s.rect(M, by, 0.06, bh, RED)
    s.tx(M + 0.18, by, step - 0.38, bh, [
        [run(t['rotulo'].upper(), 8, RED, b=True, spc=100)],
        dict(runs=[run(t['texto'], 7.6, GREY)], before=1)], anchor='ctr')
    tx0 = M + step
    tw = (X_END - tx0 - 0.08 - 2 * 0.10) / 3
    for j, k in enumerate(t['capacidades']):
        cap(tx0 + j * (tw + 0.10), by + 0.07, tw, bh - 0.14, k)

    legenda_estados(s, by + bh + 0.14, legenda)
    s.foot()
    s.notes = c['notas_orador']


def capacidades(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    gap = 0.16
    cw = (CONTENT_W - 2 * gap) / 3
    y0, y1 = 1.86, 6.02
    for k, col in enumerate(c['colunas']):
        x = M + k * (cw + gap)
        t = col['status_tipo']
        bar = {'novo': RED, 'reuso': GREY, 'aberto': LGREY}[t]
        border = {'novo': RED, 'reuso': BORDER, 'aberto': GREY}[t]
        dash = 'dash' if t == 'aberto' else None
        tc = DARK if dash else WHITE
        s.rect(x, y0, cw, y1 - y0, WHITE, border, dash=dash)
        s.rect(x, y0, cw, 0.40, bar, border if dash else None, dash=dash)
        s.tx(x + 0.16, y0, cw - 0.32, 0.40, [[run(col['titulo'], 11, tc, b=True)]], anchor='ctr')
        s.tx(x + 0.16, y0, cw - 0.32, 0.40, [[run(col['status'].upper(), 7.3, tc, b=True, spc=100)]],
             align='r', anchor='ctr')
        ix, iw = x + 0.16, cw - 0.32
        s.tx(ix, y0 + 0.52, iw, 0.18, [[run('SUBCAPACIDADES', 7.6, GREY, b=True, spc=150)]], anchor='ctr')
        s.tx(ix, y0 + 0.76, iw, 1.10,
             [dict(runs=idruns(sc, 8.5, DARK, DARK), bullet=True,
                   before=(2.5 if len(col['subcapacidades']) <= 6 else 1.2) if j else 0)
              for j, sc in enumerate(col['subcapacidades'])])
        yh = y0 + 2.02
        s.tx(ix, yh, iw, 0.18, [[run('O QUE EXISTE HOJE', 7.6, GREY, b=True, spc=150)]], anchor='ctr')
        s.rect(ix, yh + 0.22, iw, 0.76, LGREY)
        s.tx(ix + 0.10, yh + 0.22, iw - 0.20, 0.76, [idruns(col['existe_hoje'], 8.5, DARK, DARK)], anchor='ctr')
        yf = yh + 1.08
        s.tx(ix, yf, iw, 0.18, [[run('O QUE FALTA DEFINIR', 7.6, RED, b=True, spc=150)]], anchor='ctr')
        s.rect(ix, yf + 0.22, iw, 0.76, WHITE, GREY, dash='dash', lw=9525)
        s.tx(ix + 0.10, yf + 0.22, iw - 0.20, 0.76, [idruns(col['falta_definir'], 8.5, RED, DARK)], anchor='ctr')
    call = c['callout_decisao']
    ttl, body = call.split(':', 1)
    s.callout(6.14, ttl + ':', body.strip(), h=0.68, fill=PINK)
    s.foot()
    s.notes = c['notas_orador']


# ------------------------------------------------------------- tópico 3
def asis_tobe(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    y0, y1 = 1.86, 6.86
    # AS-IS
    px, pw = M, 5.25
    s.rect(px, y0, pw, y1 - y0, LGREY)
    s.tx(px + 0.20, y0 + 0.08, pw - 0.4, 0.26,
         [[run('AS-IS  ', 10.5, DARK, b=True), run('termo manual, fora do Salesforce', 10.5, GREY)]], anchor='ctr')
    sx, sw = px + 0.20, 2.45
    dx, dw = sx + sw + 0.18, pw - 0.20 - sw - 0.18 - 0.15
    sh, sg, sy0 = 0.56, 0.18, 2.32
    for k, st in enumerate(c['asis']):
        y = sy0 + k * (sh + sg)
        s.rect(sx, y, sw, sh, WHITE, BORDER, lw=9525)
        if st['dor']:
            s.rect(sx, y, 0.05, sh, RED)
        s.tx(sx + 0.14, y, sw - 0.24, sh,
             [[run(f'{k + 1}  ', 8.5, RED if st['dor'] else GREY, b=True), run(st['passo'], 8.5, DARK, b=True)]],
             anchor='ctr')
        if st['dor']:
            s.tx(dx, y, dw, sh, [[run('dor: ', 8.3, RED, b=True, i=True), run(st['dor'], 8.3, RED, i=True)]],
                 anchor='ctr')
        if k < len(c['asis']) - 1:
            s.seg(sx + sw / 2, y + sh, sx + sw / 2, y + sh + sg, GREY, 9525, head=True)
    # seta central
    ax = px + pw + 0.18
    s.rect(ax, 3.80, 0.62, 0.70, RED, prst='rightArrow')
    s.tx(ax - 0.14, 4.58, 0.90, 0.50, [[run('jornada', 8, RED, b=True)], [run('orquestrada', 8, RED, b=True)]],
         align='ctr', anchor='t')
    # TO-BE
    tx0 = 6.78
    tw = X_END - tx0
    s.rect(tx0, y0, tw, y1 - y0, WHITE, RED)
    s.tx(tx0 + 0.18, y0 + 0.08, tw - 0.36, 0.26,
         [[run('TO-BE  ', 10.5, RED, b=True), run('jornada orquestrada no ARO Atacado', 10.5, DARK)]], anchor='ctr')
    hl = {0: {2, 3}, 3: {0, 1, 2}}
    ch_std, ch_aro, rg = 0.40, 0.66, 0.24
    ix, iw = tx0 + 0.18, tw - 0.36
    y = 2.30
    for k, cam in enumerate(c['tobe_camadas']):
        aro = 'papeis' in cam
        chh = ch_aro if aro else ch_std
        s.tx(ix, y, iw, 0.18, [[run(cam['rotulo'].upper(), 7.6, RED if aro else GREY, b=True, spc=120)]],
             anchor='ctr')
        items = cam['itens']
        n = len(items)
        if aro:
            # 3 serviços; termo-documento é módulo interno do COMP-01 (tracejado, recuado)
            ws = [2.20, 1.45, iw - 0.20 - 2.20 - 1.45]
            mi = cam['modulo_interno']
            x = ix
            for j, (it, papel, w_) in enumerate(zip(items, cam['papeis'], ws)):
                comp, nome = it.split(' ', 1)
                s.rect(x, y + 0.20, w_, chh, PINK, None)
                tw_ = w_ - 0.10 if j != mi['de'] else w_ - 1.12
                s.tx(x + 0.07, y + 0.20, tw_ - 0.04, chh, [
                    [run(comp, 7.3, RED, b=True, spc=100)],
                    [run(tech(nome), 7.6, RED, b=True)],
                    [run(papel, 7.3, GREY)]], align='l' if j == mi['de'] else 'ctr', anchor='ctr')
                if j == mi['de']:
                    bx, bw = x + w_ - 1.04, 0.96
                    s.rect(bx, y + 0.29, bw, chh - 0.18, WHITE, RED, dash='dash', lw=9525)
                    s.tx(bx + 0.04, y + 0.29, bw - 0.08, chh - 0.18, [
                        [run(mi['nome'], 7.6, DARK, b=True)], [run(mi['rotulo'], 7.3, GREY, i=True)]],
                        align='ctr', anchor='ctr')
                x += w_ + 0.10
        else:
            cwid = (iw - (n - 1) * 0.10) / n
            for j, it in enumerate(items):
                x = ix + j * (cwid + 0.10)
                h_ = j in hl.get(k, set())
                s.rect(x, y + 0.20, cwid, chh, PINK if h_ else LGREY, None)
                s.tx(x + 0.05, y + 0.20, cwid - 0.10, chh, [[run(it, 7.6, RED if h_ else DARK, b=h_)]],
                     align='ctr', anchor='ctr')
        y += 0.20 + chh
        if k < len(c['tobe_camadas']) - 1:
            cx = tx0 + tw / 2
            s.seg(cx, y + 0.04, cx, y + rg - 0.04, GREY, 9525, head=True)
            y += rg
    s.tx(ix, 6.62, iw, 0.18, [[run('Rosa: criado pela iniciativa  ·  cinza: existente ou reuso', 7.3, GREY, i=True)]],
         anchor='ctr')
    s.foot()
    s.notes = c['notas_orador']


def macro(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    G = {g['id']: g for g in c['grupos']}
    E = {e['id']: e for g in c['grupos'] for e in g['elementos']}
    F = {f['de'] + '>' + f['para']: f for f in c['fluxos']}

    def num(a, b):
        r = F[a + '>' + b]['rotulo']
        return r.split('.')[0] if r[0].isdigit() else ''

    LINE = GREY

    def elem(eid, x, y, w, h, style='ctx', caption=None, dash=None):
        e = E[eid]
        paras = []
        if style == 'foco':
            s.rect(x, y, w, h, PINK, RED, lw=9525)
            comp, nome = e['nome'].split(' ', 1)
            paras.append([run(comp, 7.3, RED, b=True, spc=100)])
            paras.append([run(tech(nome), 7.6, RED, b=True)])
        else:
            s.rect(x, y, w, h, WHITE, GREY if dash else BORDER, lw=9525, dash=dash)
            if caption:
                paras.append([run(caption, 7.3, GREY, b=True, spc=100)])
            paras.append([run(e['nome'], 8, DARK, b=True)])
        paras.append([run(e['sub'].replace('Plano A', 'Plano\u00a0A'), 7.3, GREY)])
        s.tx(x + 0.05, y, w - 0.10, h, paras, align='ctr', anchor='ctr')

    def group(x, y, w, h, title, fill=LGREY, line=None, title_pos='top', color=GREY):
        s.rect(x, y, w, h, fill, line, lw=9525)
        ty = y + 0.04 if title_pos == 'top' else y + h - 0.24
        s.tx(x + 0.08, ty, w - 0.16, 0.20, [[run(title, 8, color, b=True)]], anchor='ctr')

    # colunas
    C1, C1W = 0.60, 1.30
    C2, C2W = 2.16, 1.50
    C3, C3W = 3.92, 3.46
    C4, C4W = 7.90, 1.66
    C5, C5W = 9.76, 1.12
    P = 0.08
    EH = 0.44
    L = [3.14, 3.68, 4.22, 5.06]
    gy0, gy1 = 2.62, 5.40

    # usuários (faixa superior)
    s.rect(M, 1.86, C5 + C5W - M, 0.64, LGREY, None)
    s.tx(C2, 1.86, 3.0, 0.64, [[run(G['g1']['titulo'].upper(), 7.6, GREY, b=True, spc=150)]], anchor='ctr')
    elem('e1', C1 + P, 1.93, C1W - 2 * P, 0.50)
    elem('e2', C5 - 0.36, 1.93, C5W + 0.36, 0.50)

    # salesforce (caixa curta)
    sf_y0, sf_y1 = 2.72, 4.30
    group(C1, gy0, C1W, 4.62 - gy0, G['g2']['titulo'], title_pos='bottom')
    elem('e3', C1 + P, sf_y0, C1W - 2 * P, sf_y1 - sf_y0)

    # borda
    group(C2, gy0, C2W, gy1 - gy0, G['g3']['titulo'])
    for eid, lc in zip(['e4', 'e5', 'e6'], L[:3]):
        elem(eid, C2 + P, lc - EH / 2, C2W - 2 * P, EH)
    elem('e7', C2 + P, L[3] - 0.24, C2W - 2 * P, 0.48)
    bxc = C2 + C2W / 2
    for a, b in [(L[0], L[1]), (L[1], L[2])]:
        s.seg(bxc, a + EH / 2, bxc, b - EH / 2, LINE, 9525, head=True)

    # convênio (porta inativa) acima do ARO
    elem('e19', C3, gy0, C3W, 0.66, caption='CONVÊNIO · INDEFINIDO', dash='dash')

    # ARO (foco)
    ay0 = 3.66
    group(C3, ay0, C3W, gy1 - ay0, G['g4']['titulo'], fill=WHITE, line=RED, color=RED)
    s.tx(C3 + P, ay0 + 0.04, C3W - 2 * P, 0.20,
         [[run('3 serviços · Java 21 / Spring Boot 3', 7.3, GREY, i=True)]], align='r', anchor='ctr')
    wa = 1.76
    wr = C3W - 2 * P - 0.10 - wa
    xa = C3 + P                      # acompanhamento (esquerda)
    xr = xa + wa + 0.10              # receptor (direita)
    elem('e8', C3 + P, L[2] - EH / 2, C3W - 2 * P, EH, 'foco')
    elem('e10', xa, L[3] - 0.24, wa, 0.48, 'foco')
    elem('e9', xr, L[3] - 0.24, wr, 0.48, 'foco')

    # dados
    dy0, dy1 = 5.50, 6.86
    group(C3, dy0, C3W, dy1 - dy0, G['g5']['titulo'], title_pos='bottom')
    elem('e11', C3 + P, 5.58, C3W - 2 * P, 0.44)
    elem('e12', xa, 6.08, wa, 0.46)
    elem('e13', xr, 6.08, wr, 0.46)

    # corporativos
    group(C4, gy0, C4W, 5.08 - gy0, G['g6']['titulo'])
    for eid, lc in zip(['e14', 'e17', 'e15', 'e16'], [L[0], L[1], L[2], 4.76]):
        elem(eid, C4 + P, lc - EH / 2, C4W - 2 * P, EH)

    # canal (abaixo da linha 10, que passa sob os corporativos)
    cy_c = 5.78
    elem('e18', C5, cy_c - 0.34, C5W, 0.68)

    # ------------------------------------------------------------ fluxos
    x1 = C1 + C1W / 2
    s.seg(x1, 2.43, x1, sf_y0, LINE, head=True)
    s.badge(x1 + 0.22, (2.43 + sf_y0) / 2, num('e1', 'e3'))
    xs_r = C1 + C1W - P
    xb_l = C2 + P
    xg12 = (xs_r + xb_l) / 2
    s.seg(xs_r, L[0], xb_l, L[0], LINE, head=True)
    s.badge(xg12, L[0] - 0.17, num('e3', 'e4'))
    xb_r = C2 + C2W - P
    xt_l = C3 + P
    s.seg(xb_r, L[2], xt_l, L[2], LINE, head=True)
    s.badge((xb_r + xt_l) / 2, L[2] - 0.17, num('e6', 'e8'))
    # 11 acompanhamento → firewall → salesforce (cotovelo no vão)
    s.seg(xt_l, L[3], xb_r, L[3], LINE, head=True)
    s.badge((xb_r + xt_l) / 2, L[3] - 0.17, num('e10', 'e3'))
    s.path([(xb_l, L[3]), (xg12, L[3]), (xg12, sf_y1 - 0.20), (xs_r, sf_y1 - 0.20)], LINE)
    # 4,5,6 termo → FIRP / IMPD / GACD
    xt_r = C3 + C3W - P
    xc_l = C4 + P
    bus = C3 + C3W + 0.14
    y6 = L[2] - 0.08
    s.seg(xt_r, y6, xc_l, y6, LINE, head=True)
    s.seg(bus, y6, bus, L[0], LINE)
    s.seg(bus, L[0], xc_l, L[0], LINE, head=True)
    s.seg(bus, L[1], xc_l, L[1], LINE, head=True, dash='dash')
    bxm = (bus + xc_l) / 2 + 0.02
    s.badge(bxm, L[0] - 0.15, num('e8', 'e14'))
    s.badge(bxm, L[1] - 0.15, num('e8', 'e17'))
    s.badge(bxm, y6 - 0.15, num('e8', 'e15'))
    # 9 GACD → receptor
    y8a, y8b, x8 = L[2] + 0.14, L[3] - 0.08, bus + 0.24
    s.path([(xc_l, y8a), (x8, y8a), (x8, y8b), (xt_r, y8b)], LINE)
    s.badge((x8 + xt_r) / 2 - 0.03, y8b - 0.15, num('e15', 'e9'))
    # 7 cliente → canal
    xc5 = C5 + C5W / 2
    s.seg(xc5, 2.43, xc5, cy_c - 0.34, LINE, head=True)
    s.badge(xc5, 3.80, num('e2', 'e18'))
    # 10 receptor → FIRP (revalida): passa sob os corporativos e sobe pela direita deles;
    # 8 canal → GACD (assina): sobe do canal por fora e cruza a 10 uma vez
    xc_r = C4 + C4W - P
    xv10, xv8 = C5 + 0.16, C5 + 0.36
    ya = L[3] + 0.10
    s.path([(xt_r, ya), (xv10, ya), (xv10, L[0]), (xc_r, L[0])], LINE)
    s.badge((xc_r + xv10) / 2, L[0] - 0.15, num('e9', 'e14'))
    s.path([(xv8, cy_c - 0.34), (xv8, L[2]), (xc_r, L[2])], LINE)
    s.badge((xc_r + xv10) / 2, L[2] - 0.15, num('e18', 'e15'))
    # 11 receptor → PostgreSQL ; 12 PostgreSQL → acompanhamento
    xrc = xr + wr / 2
    xac = xa + wa / 2
    s.seg(xrc, L[3] + 0.24, xrc, 5.58, LINE, head=True)
    s.badge(xrc + 0.20, 5.44, num('e9', 'e11'))
    s.seg(xac, 5.58, xac, L[3] + 0.24, LINE, head=True)
    s.badge(xac + 0.20, 5.44, num('e11', 'e10'))

    # ------------------------------------------------------------ fluxos (painel)
    PX = 11.06
    PW = X_END - PX
    s.rect(PX, 1.86, PW, gy1 - 1.86, WHITE, BORDER)
    s.tx(PX + 0.12, 1.94, PW - 0.24, 0.24, [[run('Fluxos', 9.5, RED, b=True)]], anchor='ctr')
    fl = []
    for f in c['fluxos']:
        r = f['rotulo']
        if r[0].isdigit():
            n_, t_ = r.split('.', 1)
            fl.append(dict(runs=[run(f'{n_}  ', 8.5, RED, b=True), run(t_.strip(), 8.5, DARK)], before=3.4))
        else:
            fl.append(dict(runs=[run('–  ', 8.5, GREY, b=True), run(r, 8.5, GREY, i=True)], before=3.4))
    s.tx(PX + 0.12, 2.22, PW - 0.20, 3.10, fl)

    # ------------------------------------------------------------ legenda (canto inferior esquerdo)
    lx, ly0 = M, 5.55
    lw_ = C2 + C2W - M
    s.rect(lx, ly0, lw_, 6.86 - ly0, WHITE, BORDER)
    s.tx(lx + 0.12, ly0 + 0.06, lw_ - 0.24, 0.22, [[run('Legenda', 9.5, RED, b=True)]], anchor='ctr')
    lg = c['legenda']
    ly = ly0 + 0.36
    s.rect(lx + 0.14, ly + 0.03, 0.24, 0.14, PINK, RED, lw=9525)
    s.tx(lx + 0.48, ly, lw_ - 0.60, 0.20, [[run(lg[0], 7.6, DARK)]], anchor='ctr')
    ly += 0.24
    s.seg(lx + 0.14, ly + 0.10, lx + 0.38, ly + 0.10, GREY, 12700, dash='dash')
    s.tx(lx + 0.48, ly, lw_ - 0.60, 0.20, [[run(lg[1], 7.6, DARK)]], anchor='ctr')
    for t in lg[2:]:
        ly += 0.24
        s.rect(lx + 0.23, ly + 0.07, 0.06, 0.06, RED)
        s.tx(lx + 0.48, ly, lw_ - 0.60, 0.20, [[run(t, 7.6, DARK)]], anchor='ctr')
    s.foot()
    s.notes = c['notas_orador']


def decisoes_arq(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    widths = [1.75, 3.85, 2.35, 4.18]
    head = ['Decisão', 'Escolha', 'Alternativa rejeitada', 'Justificativa']
    rows = [(0.32, [dict(p=[[run(h, 9, WHITE, b=True)]], fill=RED) for h in head])]
    for k, l in enumerate(c['linhas']):
        fill = ALT if k % 2 else WHITE
        adr, nome = l['decisao'].split(' ', 1)
        rows.append((0.60, [
            dict(p=[[run(adr, 8.5, RED, b=True)], [run(nome, 8.5, DARK, b=True)]], fill=fill, line=RULE),
            dict(p=[idruns(l['escolha'], 8.3, DARK, DARK)], fill=fill, line=RULE),
            dict(p=[[run(l['alternativa'], 8.3, GREY)]], fill=fill, line=RULE),
            dict(p=[idruns(l['justificativa'], 8.3, DARK, DARK)], fill=fill, line=RULE),
        ]))
    s.table(M, 1.86, widths, rows)
    s.tx(M, 6.52, CONTENT_W, 0.22, [[run('Todas as ADRs vigentes estão em status Proposta; a ADR-09 (alerta do Canal) foi substituída pela ADR-13.', 7.6, GREY, i=True)]],
         anchor='ctr')
    s.foot()
    s.notes = c['notas_orador']


# ------------------------------------------------------------- tópico 4
SEM = {'A': (RED, WHITE, 'Alta', 'Alto'), 'M': (AMBER, DARK, 'Média', 'Médio'), 'B': (GREEN, WHITE, 'Baixa', 'Baixo')}


def riscos(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    widths = [0.98, 3.42, 0.62, 0.72, 4.44, 1.95]
    head = ['ID', 'Risco', 'Prob.', 'Impacto', 'Mitigação', 'Dono']
    rows = [(0.30, [dict(p=[[run(h, 9, WHITE, b=True)]], fill=RED, align='ctr' if h in ('Prob.', 'Impacto') else 'l')
                    for h in head])]
    for k, l in enumerate(c['linhas']):
        fill = ALT if k % 2 else WHITE
        pf, pc, pl, _ = SEM[l['prob']]
        imf, imc, _, iml = SEM[l['impacto']]
        rows.append((0.42, [
            dict(p=[[run(l['id'], 8, DARK, b=True)]], fill=fill, line=RULE),
            dict(p=[[run(l['risco'], 8, DARK)]], fill=fill, line=RULE),
            dict(p=[[run(pl, 8, pc, b=True)]], fill=pf, align='ctr', line=WHITE),
            dict(p=[[run(iml, 8, imc, b=True)]], fill=imf, align='ctr', line=WHITE),
            dict(p=[idruns(l['mitigacao'], 8, DARK, GREY)], fill=fill, line=RULE),
            dict(p=[[run(l['dono'], 8, DARK)]], fill=fill, line=RULE),
        ]))
    s.table(M, 1.86, widths, rows)
    ly = 6.54
    x = M
    for col, lab in [(RED, 'Alta / Alto'), (AMBER, 'Média / Médio'), (GREEN, 'Baixa / Baixo')]:
        s.rect(x, ly + 0.04, 0.20, 0.14, col)
        s.tx(x + 0.26, ly, 1.0, 0.22, [[run(lab, 7.6, GREY)]], anchor='ctr')
        x += 1.20
    s.tx(x + 0.10, ly, X_END - x - 0.10, 0.22, [[run(c['legenda'], 7.6, GREY, i=True)]], anchor='ctr')
    s.foot()
    s.notes = c['notas_orador']


# ------------------------------------------------------------- tópico 5
def questoes(deck, q, notes):
    s = deck.slide()
    s.header(q['kicker'], q['titulo'], q['apoio'])
    gap = 0.16
    cw = (CONTENT_W - gap) / 2
    y0, y1 = 1.86, 6.46
    for k, col in enumerate(q['colunas']):
        x = M + k * (cw + gap)
        s.rect(x, y0, cw, y1 - y0, WHITE, BORDER)
        s.rect(x, y0, cw, 0.38, RED)
        s.tx(x + 0.16, y0, cw - 0.32, 0.38, [[run(col['titulo'], 11, WHITE, b=True)]], anchor='ctr')
        n = len(col['itens'])
        iy0 = y0 + 0.40
        avail = y1 - 0.02 - iy0
        tw_ = cw - 0.32
        # altura por item a partir do texto real (linhas estimadas), sobra distribuída por igual
        hs = []
        for it in col['itens']:
            est = len(it['id'] + '   ') * 0.052 + len(it['texto']) * 0.050
            lines = int(est / (tw_ - 0.06)) + 1
            hs.append(lines * 0.142 + 0.145)
        g = (avail - sum(hs)) / n
        y = iy0 + g / 2
        for j, it in enumerate(col['itens']):
            pitch = hs[j] + 0.05
            if j:
                s.line(x + 0.16, y - g / 2, cw - 0.32, RULE_SOFT)
            team = it['time'] + (f' ({it["apoio"]})' if it.get('apoio') else '')
            meta = [run(team, 7.3, GREY, b=True)]
            if it.get('prazo'):
                meta += [run('   ·   prazo ', 7.3, GREY), run(it['prazo'], 7.3, RED, b=True)]
            else:
                meta += [run('   ·   sem prazo-limite no roadmap', 7.3, GREY, i=True)]
            s.tx(x + 0.16, y, cw - 0.32, pitch - 0.05, [
                [run(it['id'] + '   ', 7.6, RED, b=True), run(it['texto'], 8.3, DARK)],
                dict(runs=meta, before=1.5)])
            y += hs[j] + g
    s.tx(M, 6.54, CONTENT_W, 0.34, [[run(q['rodape'], 7.3, GREY, i=True)]], anchor='ctr')
    s.foot()
    s.notes = notes


# ------------------------------------------------------------- tópico 6
def d(iso):
    return dt.date.fromisoformat(iso)


def gantt(deck, c):
    s = deck.slide()
    s.header(c['kicker'], c['titulo'], c['apoio'])
    t0, t1 = d(c['periodo_inicio']), d(c['periodo_fim']) + dt.timedelta(days=1)
    TLX, TLW = 4.30, X_END - 4.30
    span = (t1 - t0).days

    def X(date):
        return TLX + (date - t0).days / span * TLW

    hy, hh = 1.86, 0.28
    s.tx(M, hy, 3.5, hh, [[run('FASE E ENTREGAS', 7.6, GREY, b=True, spc=150)]], anchor='ctr')
    # trimestres
    qs = []
    y_, m_ = t0.year, t0.month
    for lab in c['periodos']:
        a = dt.date(y_, m_, 1)
        m2, y2 = m_ + 3, y_
        if m2 > 12:
            m2, y2 = m2 - 12, y_ + 1
        b = dt.date(y2, m2, 1)
        qs.append((lab, a, b))
        y_, m_ = y2, m2
    for lab, a, b in qs:
        s.rect(X(a) + 0.015, hy, X(b) - X(a) - 0.03, hh, RED)
        s.tx(X(a), hy, X(b) - X(a), hh, [[run(lab, 9, WHITE, b=True)]], align='ctr', anchor='ctr')
    ry0, rh, rp = 2.20, 0.63, 0.67
    nrows = len(c['fases'])
    yend = ry0 + nrows * rp - (rp - rh)
    for k in range(nrows):
        if k % 2 == 0:
            s.rect(M, ry0 + k * rp, CONTENT_W, rh, ALT)
    # congelamentos (nota do roadmap)
    for a, b in [('2026-12-14', '2027-01-15'), ('2027-12-13', '2028-01-14')]:
        s.rect(X(d(a)), ry0 - 0.02, X(d(b)) - X(d(a)), yend - ry0 + 0.04, None, None, patt=(BORDER, WHITE))
    for lab, a, b in qs[1:]:
        s.seg(X(a), ry0 - 0.02, X(a), yend + 0.02, RULE, 9525)
    colors = {'foco': (RED, WHITE, None), 'evolucao': (BLUE, WHITE, None), 'aberto': (LGREY, DARK, GREY)}
    mk = {}
    for m in c['marcos']:
        mk.setdefault(m['fase'], []).append(m)
    for k, f in enumerate(c['fases']):
        y = ry0 + k * rp
        fc, tc, lc = colors[f['cor']]
        idc = {'foco': RED, 'evolucao': BLUE, 'aberto': GREY}[f['cor']]
        s.tx(M + 0.10, y + 0.04, 3.55, 0.18, [[run(f['id'] + '  ', 9.5, idc, b=True), run(f['nome'], 9.5, DARK, b=True)]],
             anchor='ctr')
        s.tx(M + 0.10, y + 0.23, 3.50, 0.40, [[run(f['descricao'], 7.6, GREY)]])
        xa, xb = X(d(f['inicio'])), X(d(f['fim']) + dt.timedelta(days=1))
        s.rect(xa, y + 0.05, xb - xa, 0.20, fc, lc, dash='dash' if lc else None, lw=9525)
        s.tx(xa + 0.06, y + 0.05, max(xb - xa - 0.08, 0.3), 0.20, [[run(f['id'], 8, tc, b=True)]], anchor='ctr')
        # marcos com escalonamento em duas linhas
        lines_end = [-1.0, -1.0]
        for m in mk.get(f['id'], []):
            xm = X(d(m['data']))
            pw_ = 0.34
            lab_w = len(m['rotulo']) * 0.046 + 0.10
            ln = 0 if xm - pw_ / 2 > lines_end[0] + 0.04 else 1
            ly = y + 0.28 + ln * 0.17
            s.rect(xm - pw_ / 2, ly, pw_, 0.15, WINE, None, adj=50000)
            s.tx(xm - pw_ / 2, ly, pw_, 0.15, [[run(m['id'], 7.3, WHITE, b=True)]], align='ctr', anchor='ctr')
            s.rect(xm + pw_ / 2 + 0.02, ly - 0.01, lab_w + 0.02, 0.17, ALT if k % 2 == 0 else WHITE)
            s.tx(xm + pw_ / 2 + 0.05, ly - 0.01, lab_w, 0.17, [[run(m['rotulo'], 7.3, DARK)]], anchor='ctr')
            lines_end[ln] = xm + pw_ / 2 + 0.05 + lab_w
    by = yend + 0.08
    s.tx(M, by, CONTENT_W, 0.30, [[run('Caminho crítico   ', 8.3, RED, b=True), run(c['caminho_critico'], 8.3, DARK)]],
         anchor='ctr')
    leg = ('Vermelho: fundação e MVP; azul: evolução; tracejado: depende de decisão (D12); '
           'faixas hachuradas: congelamentos.  ')
    s.tx(M, by + 0.32, CONTENT_W, 0.30, [[run(leg, 7.3, GREY, i=True, b=False), run(c['nota'], 7.3, GREY, i=True)]],
         anchor='t')
    s.foot()
    s.notes = c['notas_orador']


def decisoes_roadmap(deck, c, nota_d12):
    q = c['slide_decisoes']
    s = deck.slide()
    s.header(q['kicker'], q['titulo'], q['apoio'])
    widths = [0.55, 3.60, 2.05, 1.05, 4.88]
    head = ['ID', 'Decisão', 'Dono', 'Prazo-limite', 'Impacto do atraso']
    rows = [(0.32, [dict(p=[[run(h, 9, WHITE, b=True)]], fill=RED) for h in head])]
    rh = min(0.50, 3.96 / len(q['linhas']))   # a tabela ocupa a mesma altura com 8 ou 9 linhas
    for k, l in enumerate(q['linhas']):
        fill = ALT if k % 2 else WHITE
        rows.append((rh, [
            dict(p=[[run(l['id'], 9, RED, b=True)]], fill=fill, line=RULE),
            dict(p=[[run(l['decisao'], 8.5, DARK, b=True)]], fill=fill, line=RULE),
            dict(p=[[run(l['dono'], 8.3, DARK)]], fill=fill, line=RULE),
            dict(p=[[run(l['prazo'], 8.5, RED, b=True)]], fill=fill, line=RULE),
            dict(p=[idruns(l['impacto_atraso'], 8.3, DARK, DARK)], fill=fill, line=RULE),
        ]))
    s.table(M, 1.86, widths, rows)
    s.callout(6.30, 'Fora desta lista:', nota_d12, h=0.52, fill=LGREY)
    s.foot()
    s.notes = c['notas_orador']


PROXIMOS = [
    ('D1', 'Decidir o gerenciador de termos (GACD × Open Cash Hub) até 30/10/26'),
    ('D2', 'Concluir o spike do IMPD e decidir Plano A ou B até 06/11/26 (M1)'),
    ('D3 e D7', 'Aprovar PostgreSQL e Blob até 13/11/26 e as rotas de rede até 20/11/26'),
    ('D4, D5 e D6', 'Fechar a autenticação LEAP e os contratos GACD e FIRP até 27/11/26 (M2)'),
]


def encerramento(deck):
    s = deck.slide()
    s.rect(0, 0, 13.333, 7.5, RED)
    s.tx(0.80, 0.80, 8.0, 0.35, [[run('PRÓXIMOS PASSOS  ·  F0 DESTRAVAMENTO', 14, WHITE, b=True, spc=300)]],
         anchor='ctr')
    s.tx(0.80, 1.35, 11.9, 0.80, [[run('Quatro entregas até 27/11 destravam a F0', 40, WHITE, b=True)]],
         anchor='ctr')
    y0, step = 2.55, 0.72
    for k, (ids, t) in enumerate(PROXIMOS):
        y = y0 + k * step
        s.rect(0.80, y, 0.46, 0.46, WHITE)
        s.tx(0.80, y, 0.46, 0.46, [[run(str(k + 1), 16, RED, b=True)]], align='ctr', anchor='ctr')
        s.tx(1.50, y, 11.2, 0.46, [[run(ids + '  ·  ', 15, WHITE, b=True), run(t, 15, WHITE)]], anchor='ctr')
    s.rect(0.80, 5.60, 11.73, 0.02, WHITE)
    s.tx(0.80, 5.78, 11.0, 0.50, [[run('Obrigado', 24, WHITE, b=True)]], anchor='ctr')
    s.tx(0.80, 6.30, 11.0, 0.35,
         [[run('Termo de Adesão Multiproduto  ·  Arquitetura de Solução  ·  Diretoria Comercial Atacado',
               12, WHITE)]], anchor='ctr')
    s.notes = ('As quatro entregas fecham a F0 até 27/11/26 (M2): D1 gerenciador de termos (30/10), D2 IMPD '
               'Plano A ou B (06/11, M1), D3 PostgreSQL e Blob (13/11), D7 rotas de rede (20/11) e D4, D5 e D6 '
               'autenticação e contratos GACD e FIRP (27/11). A revalidação de assinantes ficou no Atacado '
               '(ADR-13), sem contrato de alerta com Canais; por isso a D11 foi cancelada.')


# ------------------------------------------------------------- anexo
GLOSSARIO = os.path.join(ROOT, 'docs-final', '09-glossario-de-siglas.md')
# Seções do 09 que entram no slide. A 3.8 (códigos <CÓD> das SPEC) e a 6 (marcas) ficam só no documento.
GLOS_SECOES = ('3.1', '3.2', '3.3', '3.4', '3.5', '3.6', '3.7', '4', '5')
_SEM_EXPANSAO = ' (expansão não consta nas fontes)'


def load_glossario():
    """[(título do grupo, [(sigla, significado), ...]), ...] a partir das tabelas do 09."""
    grupos, atual = [], None
    with open(GLOSSARIO, encoding='utf-8') as f:
        for ln in f:
            m = re.match(r'#{2,3} (\d+(?:\.\d+)?)\.? (.+)', ln)
            if m:
                sec, titulo = m.groups()
                atual = None
                if sec in GLOS_SECOES:
                    titulo = ('IDs · ' + titulo) if sec.startswith('3.') else titulo
                    atual = (titulo.strip(), [])
                    grupos.append(atual)
                continue
            if atual is None or not ln.startswith('| '):
                continue
            cells = [c.strip() for c in ln.strip().strip('|').split('|')]
            if cells[0] in ('Sigla', '') or set(cells[0]) <= set('-: '):
                continue
            sig = re.sub(r'[*`]+', '', cells[1]).replace(_SEM_EXPANSAO, '').split('; ')[0]
            atual[1].append((re.sub(r'[*`]+', '', cells[0]), sig))
    return grupos


def glossario(deck):
    s = deck.slide()
    s.header('ANEXO · GLOSSÁRIO', 'O que cada sigla significa',
             'Prefixos de ID, sistemas do banco e siglas técnicas. Origem e exemplos em 09-glossario-de-siglas.md.')
    grupos = load_glossario()
    ncol, gap = 4, 0.22
    cw = (CONTENT_W - (ncol - 1) * gap) / ncol
    y0, y1 = 1.80, 6.92
    sz, lh = 7.6, 7.6 * 1.2 / 72            # altura de linha em polegadas
    cpl = int(cw * 72 / (sz * 0.49))        # caracteres por linha (estimativa conservadora)

    def alt(texto, antes):                  # altura estimada de um parágrafo
        return -(-len(texto) // cpl) * lh + antes / 72

    itens = []                              # (altura, parágrafo, é_título)
    for titulo, linhas in grupos:
        itens.append((alt(titulo, 6), titulo, True))
        for sigla, sig in linhas:
            itens.append((alt(f'{sigla}  {sig}', 1.2), (sigla, sig), False))
    alvo = min(y1 - y0, sum(h for h, _, _ in itens) / ncol + 0.15)
    cols, col, usado = [], [], 0.0
    for k, (h, p, tit) in enumerate(itens):
        prox = itens[k + 1][0] if tit and k + 1 < len(itens) else 0
        if col and usado + h + prox > alvo and len(cols) < ncol - 1:
            cols.append(col)
            col, usado = [], 0.0
        col.append((p, tit))
        usado += h
    cols.append(col)
    for c, col in enumerate(cols):
        paras = []
        for j, (p, tit) in enumerate(col):
            if tit:
                paras.append(dict(runs=[run(p.upper(), 7.3, RED, b=True, spc=80)], before=6 if j else 0))
            else:
                sigla, sig = p
                paras.append(dict(runs=[run(sigla.replace(' ', ' ') + '  ', sz, DARK, b=True),
                                        run(sig, sz, GREY)], before=1.2))
        s.tx(M + c * (cw + gap), y0, cw, y1 - y0, paras)
    s.foot()
    s.notes = ('Glossário das siglas usadas nos documentos 01 a 08 e nesta apresentação: prefixos de ID '
               '(DRV, OE, CAP, COMP, ADR, QA, PRM…), sistemas do banco (GACD, FIRP, IMPD, ARO…) e siglas técnicas '
               '(ACL, OHS/PL, mTLS…). O documento 09-glossario-de-siglas.md traz, para cada sigla, o documento de '
               'origem e um exemplo, além dos códigos das SPEC e das marcas FATO, PREMISSA, HIPÓTESE e ABERTO.')


# ================================================================== build
def add_notes(path, notes):
    from pptx import Presentation
    prs = Presentation(path)
    for slide, n in zip(prs.slides, notes):
        if n:
            slide.notes_slide.notes_text_frame.text = n
    prs.save(path)


def export_pdf(pptx, outdir):
    os.makedirs(outdir, exist_ok=True)
    subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', '--outdir', outdir, pptx],
                   check=True, capture_output=True)
    return os.path.join(outdir, os.path.basename(pptx)[:-5] + '.pdf')


def build(out=OUT_PPTX):
    t1, t2, t3, t4, t5, t6 = (load(n) for n in range(1, 7))
    deck = D(out)
    capa(deck)
    agenda(deck)
    onepage(deck, t1)
    divisor(deck, '02', 'Desenho conceitual',
            'Value stream da adesão, camadas da estratégia à tecnologia e capacidades de negócio: '
            'o que se constrói, o que se reusa e o que falta decidir.',
            'Três slides: o value stream VS-01, que mostra em que estágio da jornada cada capacidade atua; '
            'as camadas do desenho conceitual, da estratégia à tecnologia; e as 13 capacidades agrupadas em '
            'construir, reusar e decidir. O ponto de atenção é o Convênio.')
    value_stream(deck, t2['slide_value_stream'], t2['slide_camadas']['legenda'])
    camadas(deck, t2['slide_camadas'])
    capacidades(deck, t2['slide_capacidades'])
    divisor(deck, '03', 'Desenho macro de arquitetura',
            'Da jornada manual à orquestração no ARO Atacado: AS-IS → TO-BE, visão de contêineres '
            'e decisões de arquitetura.',
            'Três slides: de onde partimos e aonde chegamos, a visão de contêineres com os fluxos numerados '
            'e as decisões de arquitetura que dão forma à solução.')
    asis_tobe(deck, t3['slide_asis_tobe'])
    macro(deck, t3['slide_macro'])
    decisoes_arq(deck, t3['slide_decisoes'])
    divisor(deck, '04', 'Riscos',
            'Os riscos de maior probabilidade × impacto, com mitigação e dono.',
            'Os dez riscos de maior probabilidade × impacto. A maioria depende de GACD, Canais e decisões '
            'de negócio; o pedido é priorizar essas entregas já na F0.')
    riscos(deck, t4)
    divisor(deck, '05', 'Questões em aberto',
            'Questões de negócio e técnicas por time, com prazo-limite ligado às decisões do roadmap.',
            'Dois slides: as dúvidas de negócio, concentradas no Convênio, e os contratos e aprovações de '
            'plataforma que travam o caminho crítico. Cada questão tem time dono.')
    for q in t5['slides']:
        questoes(deck, q, t5['notas_orador'])
    divisor(deck, '06', 'Roadmap',
            'Seis fases de out/26 a jan/28, marcos, caminho crítico e decisões com prazo-limite.',
            'O cronograma em seis fases com os marcos M1 a M9 e as decisões com prazo-limite. '
            'Datas indicativas, replanejadas no M2.')
    gantt(deck, t6)
    decisoes_roadmap(deck, t6,
                     'D12 (Convênio) vence em 26/02/27 se opção A (novo serviço) ou 30/04/27 se B/C; quem executa a '
                     'implantação, até 30/04/27. Decide a F5 e não afeta o go-live amplo (M7).')
    encerramento(deck)
    glossario(deck)
    deck.save()
    add_notes(out, [s.notes for s in deck.slides])
    return out


if __name__ == '__main__':
    path = build()
    print('gerado:', path)
    if '--pdf' in sys.argv:
        pdf = export_pdf(path, os.path.dirname(path))
        print('pdf:', pdf)
    if '--render' in sys.argv:
        outdir = sys.argv[sys.argv.index('--render') + 1]
        pdf = export_pdf(path, outdir)
        for f in os.listdir(outdir):
            if f.startswith('slide') and f.endswith('.png'):
                os.remove(os.path.join(outdir, f))
        subprocess.run(['pdftoppm', '-png', '-r', '110', pdf, os.path.join(outdir, 'slide')], check=True)
        print('render:', outdir)
