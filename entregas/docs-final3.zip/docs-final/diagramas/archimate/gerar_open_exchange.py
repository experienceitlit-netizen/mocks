#!/usr/bin/env python3
"""Gera am-modelo-open-exchange.xml (ArchiMate Open Exchange Format 3.x) a partir dos am-*.puml.

Uso: python3 gerar_open_exchange.py   (na pasta diagramas/archimate)

Regras de leitura:
- Elementos: chamadas Motivation_*/Strategy_*/Business_*/Application_*/Technology_*(alias, "rótulo").
- Relações: chamadas Rel_<Tipo>[_Access r/w/rw][_Up|_Down|_Left|_Right|_NR](origem, destino[, "rótulo"]).
- Linhas "'@xml ..." entram no modelo, mas não são desenhadas (ex.: redes e composições representadas por agrupamento).
- Linhas "'@name alias Nome" definem o nome do elemento quando o rótulo quebra a primeira linha só por layout.
- Grouping e arestas "-[hidden]-" são só layout e não entram no modelo.
O mesmo alias em vários diagramas é o mesmo elemento (um único elemento no modelo).
"""
import glob
import re
import sys
import xml.etree.ElementTree as ET
from xml.dom import minidom

ELEM_TYPES = {
    "Motivation_Stakeholder": "Stakeholder", "Motivation_Driver": "Driver",
    "Motivation_Assessment": "Assessment", "Motivation_Goal": "Goal",
    "Motivation_Outcome": "Outcome", "Motivation_Principle": "Principle",
    "Motivation_Requirement": "Requirement", "Motivation_Constraint": "Constraint",
    "Strategy_Capability": "Capability", "Strategy_ValueStream": "ValueStream",
    "Strategy_Resource": "Resource", "Strategy_CourseOfAction": "CourseOfAction",
    "Business_Actor": "BusinessActor", "Business_Role": "BusinessRole",
    "Business_Collaboration": "BusinessCollaboration", "Business_Process": "BusinessProcess",
    "Business_Event": "BusinessEvent", "Business_Object": "BusinessObject",
    "Business_Service": "BusinessService",
    "Application_Component": "ApplicationComponent", "Application_Service": "ApplicationService",
    "Application_Interface": "ApplicationInterface", "Application_DataObject": "DataObject",
    "Technology_Node": "Node", "Technology_SystemSoftware": "SystemSoftware",
    "Technology_CommunicationNetwork": "CommunicationNetwork", "Technology_Artifact": "Artifact",
}
LAYER = {
    "Stakeholder": "Motivation", "Driver": "Motivation", "Assessment": "Motivation", "Goal": "Motivation",
    "Outcome": "Motivation", "Principle": "Motivation", "Requirement": "Motivation", "Constraint": "Motivation",
    "Capability": "Strategy", "ValueStream": "Strategy", "Resource": "Strategy", "CourseOfAction": "Strategy",
    "BusinessActor": "Business", "BusinessRole": "Business", "BusinessCollaboration": "Business",
    "BusinessProcess": "Business", "BusinessEvent": "Business", "BusinessObject": "Business",
    "BusinessService": "Business",
    "ApplicationComponent": "Application", "ApplicationService": "Application",
    "ApplicationInterface": "Application", "DataObject": "Application",
    "Node": "Technology & Physical", "SystemSoftware": "Technology & Physical",
    "CommunicationNetwork": "Technology & Physical", "Artifact": "Technology & Physical",
}
FOLDER_ORDER = ["Strategy", "Business", "Application", "Technology & Physical", "Motivation"]

RE_ELEM = re.compile(r'^\s*(?:\'@xml\s+)?((?:Motivation|Strategy|Business|Application|Technology)_\w+)\(\s*(\w+)\s*,\s*"(.*)"\s*\)')
RE_REL = re.compile(r'^\s*(?:\'@xml\s+)?Rel_(\w+?)\(\s*(\w+)\s*,\s*(\w+)\s*(?:,\s*"(.*?)")?\s*\)')
RE_NAME = re.compile(r"^\s*'@name\s+(\w+)\s+(.+?)\s*$")
DIRS = ("_Up", "_Down", "_Left", "_Right", "_NR")
ACCESS = {"Access_r": "Read", "Access_w": "Write", "Access_rw": "ReadWrite", "Access": "Access"}


def clean(label):
    return label.replace("~_", "_").replace("\\n", "\n")


def main():
    elems, rels, seen_rel, names = {}, [], set(), {}
    files = sorted(glob.glob("am-*.puml"))
    for path in files:
        for n, line in enumerate(open(path, encoding="utf-8"), 1):
            m = RE_NAME.match(line)
            if m:
                names[m.group(1)] = m.group(2)
                continue
            if line.lstrip().startswith("'") and not line.lstrip().startswith("'@xml"):
                continue
            m = RE_ELEM.match(line)
            if m:
                macro, alias, label = m.groups()
                if macro not in ELEM_TYPES:
                    sys.exit(f"{path}:{n}: macro não mapeada {macro}")
                t = ELEM_TYPES[macro]
                label = clean(label)
                if alias in elems:
                    if elems[alias]["type"] != t:
                        sys.exit(f"{path}:{n}: alias {alias} com tipos diferentes")
                    if len(label) > len(elems[alias]["doc"]):
                        elems[alias]["doc"] = label
                    elems[alias]["views"].add(path)
                else:
                    elems[alias] = {"type": t, "name": label.split("\n")[0].strip(), "doc": label, "views": {path}}
                continue
            m = RE_REL.match(line)
            if m:
                kind, src, dst, label = m.groups()
                for d in DIRS:
                    if kind.endswith(d):
                        kind = kind[: -len(d)]
                        break
                access = None
                if kind.startswith("Access"):
                    access = ACCESS[kind]
                    kind = "Access"
                rels.append((path, n, kind, src, dst, clean(label or ""), access))

    for alias, name in names.items():
        if alias not in elems:
            sys.exit(f"'@name com alias desconhecido {alias}")
        elems[alias]["name"] = name

    model = ET.Element("model", {
        "xmlns": "http://www.opengroup.org/xsd/archimate/3.0/",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:schemaLocation": "http://www.opengroup.org/xsd/archimate/3.0/ http://www.opengroup.org/xsd/archimate/3.1/archimate3_Diagram.xsd",
        "identifier": "id-modelo-termo-adesao",
    })
    ET.SubElement(model, "name", {"xml:lang": "pt"}).text = "Termo de Adesão Multiproduto — Aceite Digital Cash (ArchiMate 3.2)"
    ET.SubElement(model, "documentation", {"xml:lang": "pt"}).text = (
        "Modelo gerado a partir de docs-final/diagramas/archimate/am-*.puml por gerar_open_exchange.py. "
        "Fonte de verdade dos nomes: 02-desenho-conceitual.md, 04-desenho-arquitetura-solucao.md e 04a-componentes-e-justificativas.md. "
        "Contém elementos e relações; não contém diagramas (views).")

    el_root = ET.SubElement(model, "elements")
    for alias, e in elems.items():
        x = ET.SubElement(el_root, "element", {"identifier": f"id-{alias}", "xsi:type": e["type"]})
        ET.SubElement(x, "name", {"xml:lang": "pt"}).text = e["name"]
        doc = e["doc"].replace("\n", " ") + " | Diagramas: " + ", ".join(sorted(v[:-5] for v in e["views"]))
        ET.SubElement(x, "documentation", {"xml:lang": "pt"}).text = doc

    rel_root = ET.SubElement(model, "relationships")
    rel_ids = []
    for i, (path, n, kind, src, dst, label, access) in enumerate(rels, 1):
        for a in (src, dst):
            if a not in elems:
                sys.exit(f"{path}:{n}: relação com alias desconhecido {a}")
        key = (kind, src, dst, access)
        if key in seen_rel:
            continue
        seen_rel.add(key)
        rid = f"id-rel-{len(rel_ids) + 1:03d}"
        rel_ids.append(rid)
        attrs = {"identifier": rid, "source": f"id-{src}", "target": f"id-{dst}", "xsi:type": kind}
        if access:
            attrs["accessType"] = access
        if kind == "Influence" and label in ("+", "-", "++", "--"):
            attrs["modifier"] = label
        r = ET.SubElement(rel_root, "relationship", attrs)
        if label:
            ET.SubElement(r, "name", {"xml:lang": "pt"}).text = label

    org = ET.SubElement(model, "organizations")
    for folder in FOLDER_ORDER:
        item = ET.SubElement(org, "item")
        ET.SubElement(item, "label", {"xml:lang": "pt"}).text = folder
        for alias, e in elems.items():
            if LAYER[e["type"]] == folder:
                ET.SubElement(item, "item", {"identifierRef": f"id-{alias}"})
    item = ET.SubElement(org, "item")
    ET.SubElement(item, "label", {"xml:lang": "pt"}).text = "Relations"
    for rid in rel_ids:
        ET.SubElement(item, "item", {"identifierRef": rid})

    xml = minidom.parseString(ET.tostring(model, encoding="utf-8")).toprettyxml(indent="  ", encoding="UTF-8")
    open("am-modelo-open-exchange.xml", "wb").write(xml)
    print(f"{len(files)} diagramas, {len(elems)} elementos, {len(rel_ids)} relações")


if __name__ == "__main__":
    main()
