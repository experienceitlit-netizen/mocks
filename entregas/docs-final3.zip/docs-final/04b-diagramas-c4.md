# 04b — Diagramas C4: Termo de Adesão Multiproduto (Cash Management / Payments)

> Complemento visual de `04-desenho-arquitetura-solucao.md` (seções 4, 6, 7 e 11) e de `04a-componentes-e-justificativas.md`. Os nomes técnicos, os IDs `COMP-xx`, `BC-xx`, os fluxos de rede `N-xx` e as marcações de hipótese seguem esses dois documentos. **Este documento não cria decisões novas.** Quando o diagrama precisa escolher uma posição que o 04 deixa em aberto, a escolha aparece marcada como "a confirmar".

## 1. Controle do documento

| Campo | Conteúdo |
|---|---|
| Documento | 04b — Diagramas C4 |
| Versão | v0.5 |
| Data | 2026-10-16 |
| Notação | Modelo C4 (Simon Brown): Contexto (Nível 1), Containers (Nível 2), Componentes (Nível 3), Dinâmico e Implantação |
| Ferramenta | PlantUML 1.2026.8 com a biblioteca C4-PlantUML 2.13.0 embarcada (`!include <C4/...>`), layout Graphviz `dot` |
| Fontes | `diagramas/c4/*.puml` (fonte de verdade); `*.png` e `*.svg` são renderizações |
| Base | 04 §4 (visão macro), §6 (fluxos), §7 (implantação e rede), §11 (contratos); 04a §2 a §4 (componentes e interfaces) |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: Contexto, Containers, Componentes (COMP-01; COMP-02/03), Dinâmicos e Implantação |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: localização do Axway padronizada como "Hub (localização a confirmar — QA-TEC-09)", igual no 04 e no 04c; nome canônico "Canal Digital PJ" em diagramas e descrições; c4-01, c4-02 e c4-06 re-renderizados com Graphviz |
| v0.3 | 2026-09-24 | Jornada principal (§5.1, c4-04): incluído o passo que faltava — o **Canal Digital PJ revalida os assinantes na FIRP (RN-06) antes** de o cliente assinar e de o Canal registrar a assinatura no GACD (passos 16 a 19; seguintes renumerados até 25). c4-04 re-renderizado |
| v0.4 | 2026-09-27 | Convênio com **etapa de implantação e homologação** feita por pessoas (Gerente de Cash ou backoffice, a definir — QA-CON-24), alinhado ao 04 v0.4 (ADR-11, RSK-18) (`instrucoes-ajustes.md`, item 8). c4-01: novo ator tracejado **Backoffice de Cash** (candidato a executor), relações futuras de implantação do Gerente e do backoffice com o Sistema de Convênio (sistema do produto), e a solução só acompanha o status (não cria o convênio por API). c4-03: a porta `convenio-produto`, quando ativa, abre a implantação (pendência no Salesforce via outbox) e acompanha o status. Leituras, tabela de rastreabilidade (§7) e ponto de atenção 6 (§8) atualizados; c4-01 e c4-03 re-renderizados |
| v0.5 | 2026-10-16 | Rodada 6: a revalidação dos assinantes na FIRP (RN-06) passa ao domínio do Atacado — o COMP-02 `atacado-adesao-receptor` revalida no callback do GACD (ADR-13); o Canal Digital PJ só dá acesso ao termo e coleta a assinatura, e a API de alerta do Canal e a rota `atacado-adesao-alerta-canal` saem. c4-01, c4-02, c4-03b, c4-04 (passos 16 a 21 renumerados), c4-05 (refeito) e c4-06 re-renderizados; ponto de atenção 5 (§8) marcado removido e ponto 9 (QA-NEG-20) incluído. Consolidação: ordem do ACK alinhada ao 05 (DT-21) — o COMP-02 grava o sinal em `AGUARDANDO_REVALIDACAO`, responde o ACK e só depois revalida na FIRP (c4-02, c4-03b, c4-04 com 26 passos, c4-05 com 13 passos); fluxo COMP-02 → Axway → FIRP passa a N-12 (§3, c4-06, §6); imagens regeradas com o PlantUML 1.2026.8 |

### 1.1 Convenções visuais

| Elemento visual | Significado |
|---|---|
| Vermelho `#CC092F` | Sistema, container ou componente **novo** da solução (em foco) |
| Rosa claro com borda vermelha | Configuração nova do Atacado dentro do Salesforce (COMP-06) ou adaptador de porta (Nível 3) |
| Cinza médio | Infraestrutura corporativa consumida (Akamai, Application Gateway, Axway, Firewall, Key Vault, ingress, CSI Driver) |
| Cinza escuro | Sistema corporativo consumido (FIRP, GACD, GCC/Filenet, IMPD) |
| Cinza claro | Externo abstraído, responsabilidade de outro time (Canal Digital PJ) |
| Caixa branca com **borda tracejada** | Hipótese (Emissor LEAP), ator ou sistema indefinido (Backoffice de Cash, Sistema de Convênio), sem integração nesta entrega (Databricks), porta inativa ou nó com localização incerta |
| Linha tracejada cinza | Relação hipotética, futura ou com rota a confirmar |
| Linha pontilhada | Leitura de segredos pelo Secrets Store CSI Driver, ou alternativa de fluxo |
| Linha vermelha contínua (Nível 3) | Chamada in-process entre módulos (porta) |
| Linha vermelha tracejada (Dinâmico) | Passo assíncrono: worker da saga, processamento da inbox ou relay da outbox |

### 1.2 Como regenerar as imagens

```bash
# Pré-requisitos: Java 21 e Graphviz (dot). O plantuml.jar traz a stdlib C4.
cd docs-final/diagramas/c4
java -DPLANTUML_LIMIT_SIZE=8192 -jar plantuml.jar -tpng -tsvg *.puml
```

`PLANTUML_LIMIT_SIZE=8192` evita que os diagramas mais largos (Nível 3) sejam cortados em 4096 px.

---

## 2. Nível 1 — Contexto do Sistema

**Pergunta que responde:** quem usa o sistema "Adesão ao Termo – Atacado" e com quais sistemas ele conversa?

![C4 Nível 1 — Contexto](diagramas/c4/c4-01-contexto.png)

*SVG: [c4-01-contexto.svg](diagramas/c4/c4-01-contexto.svg)*

**Leitura:**

1. O **Gerente de Cash** usa só o **Salesforce**. O Salesforce é o sistema de engajamento: dispara comandos da API Adesão v1 e recebe a projeção de status. Ele **nunca** fala direto com FIRP, GACD ou IMPD (PRI-01, ADR-02).
2. A entrada do Salesforce passa pelo padrão de canal externo (**Akamai → App Gateway WAF → Axway**, ADR-07). A saída para o Salesforce passa pelo **Firewall do Hub** (ADR-06). Os dois caminhos aparecem como tecnologia das relações e são detalhados no Nível 2.
3. O sistema em foco consome **FIRP** e **GACD** via Axway (autenticação LEAP **[HIPÓTESE]**, com usuário sistêmico no passo 2 do GACD) e o **IMPD** API cloud (Plano A com gate, ADR-03). O **GCC/Filenet** só é alcançado pelo GACD.
4. O **Canal Digital PJ** fica abstraído (Time de Canais). Ele só dá acesso ao termo pendente (buscado no GACD) e coleta a assinatura, que registra no GACD. Ele não consulta a FIRP nem chama API do Atacado. Quem revalida os assinantes na FIRP (RN-06) é o domínio do Atacado, no callback de assinatura do GACD (04 §11.3, ADR-13) **[FATO: CG]**.
5. **Sistema de Convênio** (sistema de cada produto, indefinido, QA-CON-02) e **Databricks** (sem integração nesta entrega) aparecem tracejados para marcar a fronteira futura: a porta `convenio-produto` está inativa (ADR-11). O convênio é criado em teste, homologado com o cliente e ativado por pessoas — **Gerente de Cash** ou **Backoffice de Cash** (ator tracejado, executor a definir, QA-CON-24) —, e não pela solução **[PREMISSA: PRM-CON-15 — padrão de mercado]**. Quando a porta for ativada, a solução tende a abrir uma pendência de implantação visível no Salesforce e só acompanhar o status (Em implantação → Convênio ativo), sem criar o convênio por API (04 ADR-11, RSK-18).

```plantuml
@startuml c4-01-contexto
!include <C4/C4_Context>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("person\nexternal_person")
UpdateElementStyle("person", $bgColor="#404040", $borderColor="#262626", $fontColor="#FFFFFF")
UpdateElementStyle("external_person", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Sistema em foco (novo)")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("saas", $bgColor="#595959", $borderColor="#333333", $fontColor="#FFFFFF", $legendText="SaaS configurado pelo Atacado")
AddElementTag("abstraido", $bgColor="#A6A6A6", $borderColor="#6E6E6E", $fontColor="#FFFFFF", $legendText="Externo abstraído (outro time)")
AddElementTag("incerto", $bgColor="#FFFFFF", $borderColor="#8C8C8C", $fontColor="#595959", $borderStyle=DashedLine(), $legendText="Hipótese, indefinido ou sem integração nesta entrega")
AddRelTag("incerto", $textColor="#8C8C8C", $lineColor="#8C8C8C", $lineStyle=DashedLine(), $legendText="Relação hipotética, futura ou fora do escopo")

LAYOUT_TOP_DOWN()

title C4 Nível 1 — Contexto do Sistema: Adesão ao Termo – Atacado

Person(gerente, "Gerente de Cash", "Time do Atacado Cash Payments. Conduz a jornada comercial no Salesforce.")
Person_Ext(cliente, "Cliente PJ Atacado", "Representantes com poderes que assinam o Termo de Adesão.")
Person(backoffice, "Backoffice de Cash", "Candidato a executor da implantação do produto (a definir, QA-CON-24).", $tags="incerto")

System_Ext(sf, "Salesforce", "Salesforce Financial Services Cloud. CRM da jornada; artefatos do Atacado (COMP-06).", $tags="saas")
System(adesao, "Adesão ao Termo – Atacado", "Solicita, gera, envia para assinatura e acompanha o Termo de Adesão multiproduto. ARO Atacado, namespace atacado-core.", $tags="foco")
System_Ext(canal, "Canal Digital PJ", "Canal do cliente (BGS + PDPJ). Só dá acesso ao termo e coleta a assinatura. Abstraído; responsabilidade do Time de Canais.", $tags="abstraido")

System_Ext(firp, "FIRP", "Firmas e Poderes: representantes e poderes vigentes.", $tags="corporativo")
System_Ext(gacd, "GACD", "Aceite Digital: protocolo, prévia, regras e callback.", $tags="corporativo")
System_Ext(gcc, "GCC/Filenet", "Repositório da prévia e do termo (só via GACD).", $tags="corporativo")
System_Ext(impd, "IMPD", "API cloud impd-srv-doc-generator. Renderiza o PDF (Plano A, com gate).", $tags="corporativo")
System_Ext(leap, "Emissor de token LEAP", "Token de workload para APIs via Axway. [HIPÓTESE]", $tags="incerto")
System_Ext(convenio, "Sistema de Convênio", "Sistema de cada produto, indefinido (QA-CON-02). Convênio criado em teste e ativado após a homologação com o cliente. Porta convenio-produto inativa.", $tags="incerto")
System_Ext(databricks, "Databricks", "Pipeline de cadastro de tarifas. Sem integração nesta entrega.", $tags="incerto")

Rel(gerente, sf, "Solicita termo, confere prévia, confirma envio, reemite")
Rel(sf, adesao, "Comandos da API Adesão v1", "HTTPS/REST, OAuth 2.0 + mTLS, via Akamai > App Gateway WAF > Axway")
Rel(adesao, sf, "Status e alertas (upsert)", "HTTPS/REST, OAuth 2.0 JWT Bearer, via Firewall do Hub")

Rel(adesao, firp, "Consulta representantes e poderes; revalida assinantes no callback (RN-06)", "HTTPS/REST via Axway, LEAP (hipótese)")
Rel(adesao, gacd, "Coordenar Contrato, Armazenar Prévia, Coordenar Regra", "HTTPS/REST via Axway, LEAP (hipótese) + usuário sistêmico")
Rel(gacd, adesao, "Callback de assinatura concluída", "HTTPS via Axway interno")
Rel(adesao, impd, "Renderiza o PDF do termo", "HTTPS/REST, rota e auth a confirmar")
Rel(gacd, gcc, "Armazena prévia e termo")
Rel(adesao, leap, "Obtém token de workload", "OAuth 2.0 client credentials", $tags="incerto")

Rel(cliente, canal, "Acessa o termo pendente e assina")
Rel(canal, gacd, "Busca pendências e registra assinatura")

Rel(adesao, convenio, "Futuro: acompanha o status do convênio (Em implantação > Convênio ativo); não cria por API", $tags="incerto")
Rel(gerente, convenio, "Futuro: implanta, homologa e ativa o convênio (executor a definir, QA-CON-24)", $tags="incerto")
Rel(backoffice, convenio, "Futuro: implanta, homologa e ativa o convênio (executor a definir, QA-CON-24)", $tags="incerto")
Rel(convenio, databricks, "Convênio ativo habilita cadastro de tarifas (futuro)", $tags="incerto")

Lay_R(gerente, cliente)
Lay_R(cliente, backoffice)
Lay_R(sf, adesao)
Lay_R(adesao, canal)
Lay_R(firp, gacd)
Lay_R(gacd, gcc)

SHOW_LEGEND()
@enduml
```

---

## 3. Nível 2 — Containers

**Pergunta que responde:** quais unidades implantáveis e armazenamentos formam a solução, onde ficam na rede e como se comunicam (protocolo e autenticação)?

![C4 Nível 2 — Containers](diagramas/c4/c4-02-containers.png)

*SVG: [c4-02-containers.svg](diagramas/c4/c4-02-containers.svg)*

**Leitura:**

1. **Três deployables Java** no ARO Atacado, namespace `atacado-core` (ADR-01): `atacado-adesao-termo` (COMP-01, núcleo e saga), `atacado-adesao-receptor` (COMP-02, borda de entrada de sinais) e `atacado-adesao-acompanhamento` (COMP-03, relay da outbox e entrega ao Salesforce). O corte segue exposição, disponibilidade e credenciais.
2. **Dois armazenamentos novos** no spoke, com acesso privado: `atacado-adesao-db` (COMP-04, PostgreSQL Flexible Server com estado, saga, inbox, outbox e auditoria, ADR-05) e `atacado-adesao-staging` (COMP-05, Blob com lifecycle de 30 dias, ADR-04).
3. **Borda de entrada:** Salesforce → Akamai → Application Gateway WAF → Axway (política `atacado-adesao-sf`) → ingress privado → COMP-01. O callback do GACD entra pela rota **interna** do Axway (`atacado-adesao-callback-gacd`) e chega só ao COMP-02. O COMP-02 grava o sinal na inbox e responde o ACK depois do commit; só depois revalida os assinantes na FIRP via Axway, num worker assíncrono (RN-06, mesmo contrato de consulta do COMP-01), e grava o resultado no sinal (ADR-08, ADR-13). Se a FIRP falhar, o sinal fica `AGUARDANDO_REVALIDACAO` e é reprocessado com retentativa, sem descarte. Quem muda o estado do termo continua sendo o COMP-01.
4. **Saída para o Salesforce:** só o COMP-03 tem a credencial (OAuth 2.0 JWT Bearer, chave no Key Vault) e o egress, pelo Azure Firewall do Hub com allowlist do My Domain (ADR-06, ADR-10).
5. **Localização do Axway:** posição padronizada no 04 §7, neste documento e no 04c como **"Hub (localização a confirmar — QA-TEC-09)"**. O diagrama o coloca no boundary do Hub, junto do Application Gateway e do Firewall, com essa ressalva no próprio elemento.

| Relação | Protocolo | Autenticação | Fluxo de rede (04 §7.1) |
|---|---|---|---|
| COMP-06 → Akamai → AppGW → Axway → COMP-01 | HTTPS/REST 443 | OAuth 2.0 client credentials + mTLS (Named Credential) | N-01 |
| COMP-01 → Axway → FIRP | HTTPS/REST | Token LEAP **[HIPÓTESE]** | N-02 |
| COMP-01 → Axway → GACD (3 APIs) | HTTPS/REST | Token LEAP **[HIPÓTESE]** + usuário sistêmico (passo 2) | N-03 |
| COMP-01 → IMPD `impd-srv-doc-generator` | HTTPS/REST | A definir (QA-TEC-01) | N-04 |
| GACD → Axway interno → COMP-02 | HTTPS | mTLS ou token do GACD (QA-TEC-07) | N-05 |
| COMP-02 → Axway → FIRP | HTTPS/REST | Token LEAP **[HIPÓTESE]**, client do COMP-02 | N-12 (mesma política de consumo FIRP do N-02, com o client do COMP-02) |
| ~~Canal Digital PJ → Axway interno → COMP-02~~ | — | — | N-06 — **Removido na rodada 6 (2026-10-16):** a revalidação passou ao Atacado; não há mais alerta do Canal |
| COMP-03 → Azure Firewall → Salesforce | HTTPS 443 | OAuth 2.0 JWT Bearer | N-07 |
| COMP-01/02/03 → COMP-04 | SQL/TLS 5432 | Usuário por serviço (Key Vault) ou Microsoft Entra ID | N-08 |
| COMP-01 → COMP-05 | HTTPS 443 (Blob REST) | Identidade de workload ou SAS no Key Vault | N-09 |
| Pods (CSI Driver) → Key Vault | HTTPS 443 | Identidade de workload / service principal | N-10 |

```plantuml
@startuml c4-02-containers
!include <C4/C4_Container>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("person\nboundary")
UpdateElementStyle("person", $bgColor="#404040", $borderColor="#262626", $fontColor="#FFFFFF")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Container novo (em foco)")
AddElementTag("config", $bgColor="#E8A3AE", $borderColor="#CC092F", $fontColor="#262626", $legendText="Configuração nova em SaaS")
AddElementTag("plataforma", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF", $legendText="Infraestrutura corporativa consumida")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("abstraido", $bgColor="#A6A6A6", $borderColor="#6E6E6E", $fontColor="#FFFFFF", $legendText="Externo abstraído (outro time)")
AddElementTag("incerto", $bgColor="#FFFFFF", $borderColor="#8C8C8C", $fontColor="#595959", $borderStyle=DashedLine(), $legendText="Hipótese ou rota a confirmar")
AddRelTag("incerto", $textColor="#8C8C8C", $lineColor="#8C8C8C", $lineStyle=DashedLine(), $legendText="Relação hipotética ou a confirmar")
AddRelTag("segredo", $textColor="#8C8C8C", $lineColor="#B0B0B0", $lineStyle=DottedLine(), $legendText="Leitura de segredos (CSI Driver)")
UpdateBoundaryStyle($bgColor="#FFFFFF", $fontColor="#404040", $borderColor="#8C8C8C")

LAYOUT_TOP_DOWN()

title C4 Nível 2 — Containers: Adesão ao Termo – Atacado

Person(gerente, "Gerente de Cash", "Time do Atacado Cash Payments")

Boundary(sfsaas, "Salesforce Financial Services Cloud (SaaS)") {
  Container(comp06, "Artefatos Salesforce do Atacado (COMP-06)", "LWC/Flow, Named Credential, Connected App", "Jornada do Gerente; Adesao_Termo~__c e Alerta_Adesao~__c; notificação ao Gerente", $tags="config")
}

Container_Ext(akamai, "Akamai (COMP-07)", "Borda CDN/WAF", "TLS/mTLS, allowlist de IPs do Salesforce", $tags="plataforma")

Boundary(azure, "Azure – tenant corporativo") {
  Boundary(hub, "vNet Hub") {
    Container_Ext(agw, "Azure Application Gateway WAF v2 (COMP-08)", "L7 LB + WAF", "Balanceamento e WAF entre Akamai e Axway", $tags="plataforma")
    Container_Ext(axway, "Axway API Gateway (COMP-09)", "API Gateway", "Políticas atacado-adesao-sf, atacado-adesao-callback-gacd; saída para FIRP e GACD. Hub (localização a confirmar — QA-TEC-09)", $tags="plataforma")
    Container_Ext(fw, "Azure Firewall – egress (COMP-12)", "Firewall", "Allowlist de FQDN do My Domain Salesforce", $tags="plataforma")
  }
  Boundary(spoke, "vNet Spoke – Plataformas Funcionais") {
    Boundary(aro, "ARO Atacado (COMP-10) – namespace atacado-core") {
      Container(c01, "atacado-adesao-termo (COMP-01)", "Java 21, Spring Boot 3, monólito modular", "API Adesão v1; agregado AdesaoTermo; ACL-FIRP; saga GACD; termo-documento; processa inbox; grava outbox e auditoria", $tags="foco")
      Container(c02, "atacado-adesao-receptor (COMP-02)", "Java 21, Spring Boot 3", "Recebe o callback GACD; valida, traduz e deduplica; grava o sinal na inbox e responde o ACK após o commit; depois, revalida assinantes na FIRP (RN-06) e grava o resultado", $tags="foco")
      Container(c03, "atacado-adesao-acompanhamento (COMP-03)", "Java 21, Spring Boot 3, worker", "Relay da outbox; projeção VisaoJornadaAdesao; alertas ao Gerente; entrega ao Salesforce", $tags="foco")
    }
    ContainerDb(c04, "atacado-adesao-db (COMP-04)", "Azure Database for PostgreSQL Flexible Server, acesso privado", "Estado, saga, inbox, outbox, projeção, auditoria (um schema por BC)", $tags="foco")
    ContainerDb(c05, "atacado-adesao-staging (COMP-05)", "Azure Blob Storage, private endpoint", "Container termos-staging; PDF transitório, lifecycle 30 dias", $tags="foco")
    Container_Ext(kv, "Azure Key Vault (COMP-11)", "Cofre de segredos, private endpoint", "Credenciais LEAP, usuário sistêmico GACD, chave JWT Salesforce, certificados", $tags="plataforma")
  }
}

Boundary(corp, "Sistemas corporativos – via Axway (localização a confirmar, QA-TEC-09)") {
  System_Ext(firp, "FIRP (COMP-13)", "Representantes e poderes", $tags="corporativo")
  System_Ext(gacd, "GACD (COMP-14)", "Protocolo, prévia, regras e callback", $tags="corporativo")
  System_Ext(gcc, "GCC/Filenet (COMP-15)", "Repositório da prévia e do termo", $tags="corporativo")
  System_Ext(impd, "IMPD impd-srv-doc-generator (COMP-16)", "Renderização do PDF, Plano A; Azure, outra vNet", $tags="incerto")
  System_Ext(leap, "Emissor de token LEAP (COMP-17)", "[HIPÓTESE]", $tags="incerto")
}

System_Ext(canal, "Canal Digital PJ (COMP-18)", "Abstraído (Time de Canais). Só dá acesso ao termo e coleta a assinatura", $tags="abstraido")

' ---- Entrada do Salesforce (borda externa) ----
Rel(gerente, comp06, "Usa a jornada", "HTTPS (UI Salesforce)")
Rel(comp06, akamai, "API Adesão v1", "HTTPS/REST, OAuth 2.0 client credentials + mTLS")
Rel(akamai, agw, "Encaminha", "HTTPS")
Rel(agw, axway, "Encaminha", "HTTPS")
Rel(axway, c01, "Rota externa atacado-adesao-sf, ingress privado", "HTTPS/REST")

' ---- Saídas do núcleo ----
Rel(c01, axway, "Chama FIRP e GACD", "HTTPS/REST, LEAP (hipótese)")
Rel(axway, firp, "Consulta representantes e poderes (COMP-01 e COMP-02)", "HTTPS/REST, LEAP (hipótese)")
Rel(axway, gacd, "3 chamadas da saga", "HTTPS/REST, LEAP (hipótese) + usuário sistêmico")
Rel(gacd, gcc, "Armazena prévia")
Rel(c01, impd, "Gera PDF (base64)", "HTTPS/REST, auth a definir (QA-TEC-01)", $tags="incerto")
Rel(c01, leap, "Token de workload", "OAuth 2.0 client credentials", $tags="incerto")
Rel(c01, c04, "Estado, saga, outbox, auditoria; lê inbox", "SQL/TLS 5432")
Rel(c01, c05, "Grava e lê PDF", "HTTPS (Blob REST), private endpoint")

' ---- Sinais de entrada (rota interna) ----
Rel(gacd, axway, "Callback de assinatura", "HTTPS, mTLS ou token GACD (QA-TEC-07)")
Rel(canal, gacd, "Busca pendências e registra a assinatura (fora do escopo do Atacado)")
Rel(axway, c02, "Rota interna atacado-adesao-callback-gacd", "HTTPS/REST")
Rel(c02, axway, "Revalida assinantes na FIRP depois do ACK (RN-06)", "HTTPS/REST, LEAP (hipótese)")
Rel(c02, c04, "INSERT inbox (ON CONFLICT DO NOTHING)", "SQL/TLS 5432")

' ---- Saída para o Salesforce ----
Rel(c03, c04, "Lê outbox; grava projeção e entrega_status", "SQL/TLS 5432")
Rel(c03, fw, "Upsert status e alertas", "HTTPS 443, OAuth 2.0 JWT Bearer")
Rel(fw, comp06, "Egress para My Domain", "HTTPS 443")

' ---- Segredos ----
Rel(c01, kv, "Segredos", "HTTPS, CSI Driver", $tags="segredo")
Rel(c02, kv, "", "", $tags="segredo")
Rel(c03, kv, "", "", $tags="segredo")

Lay_R(c01, c02)
Lay_R(c02, c03)
Lay_D(c01, c04)
Lay_R(c04, c05)
Lay_R(c05, kv)

SHOW_LEGEND()
@enduml
```

---

## 4. Nível 3 — Componentes

### 4.1 COMP-01 `atacado-adesao-termo`

**Pergunta que responde:** como o monólito modular se organiza por dentro (portas e adaptadores, saga, outbox) e qual módulo fala com qual dependência?

![C4 Nível 3 — Componentes do COMP-01](diagramas/c4/c4-03-componentes-adesao-termo.png)

*SVG: [c4-03-componentes-adesao-termo.svg](diagramas/c4/c4-03-componentes-adesao-termo.svg)*

**Leitura:**

1. O módulo **01.1 `adesao-termo`** aparece dividido em cinco componentes: API Adesão v1, API administrativa (`/admin/v1/**`, listener sem Route), domínio `AdesaoTermo` (agregado, políticas e invariantes), consumidor da inbox e **outbox writer + trilha de auditoria**. Estado, eventos e auditoria são gravados **na mesma transação** (ADR-05).
2. O domínio só conhece **portas**: `ElegibilidadePort` (01.5 `acl-registro-contratos`), `ConsultaAssinantesPort` (01.2 `acl-firp`), `AssinaturaDigitalPort` (01.3 `acl-gacd` + saga `ProcessoEnvioAssinatura`), `GeradorDocumentoPort` (01.4 `termo-documento`) e `SolicitacaoConvenioPort` (01.6 `convenio-produto`, **inativa**). Quando ativa, a porta abre a implantação do produto (`ConvenioSolicitado` na outbox, que vira pendência de implantação no Salesforce) e acompanha o status do convênio no sistema do produto; não cria o convênio (04 ADR-11).
3. O módulo **01.4 `termo-documento`** tem a porta interna `RenderizadorDocumento` com dois adaptadores: `RenderizadorImpd` (Plano A, ativo) e `RenderizadorProprio` (Plano B, **desligado** por `termo.renderizador`). A troca não afeta o domínio (ADR-03).
4. A **saga** (01.3) lê o PDF do staging, confere o hash antes do passo 2 e persiste cada etapa. A API administrativa aciona retomada e reconciliação.
5. COMP-02 e COMP-03 aparecem como vizinhos: um só escreve na inbox, o outro só lê a outbox. Não há chamada direta entre os deployables.

```plantuml
@startuml c4-03-componentes-adesao-termo
!include <C4/C4_Component>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("boundary")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Componente novo (módulo do COMP-01)")
AddElementTag("porta", $bgColor="#F4D3D8", $borderColor="#CC092F", $fontColor="#262626", $legendText="Adaptador de porta (ACL / saída)")
AddElementTag("inativo", $bgColor="#FFFFFF", $borderColor="#CC092F", $fontColor="#8A0620", $borderStyle=DashedLine(), $legendText="Porta ou adaptador desligado por flag")
AddElementTag("irmao", $bgColor="#E06A7E", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Outro container da solução")
AddElementTag("plataforma", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF", $legendText="Infraestrutura corporativa consumida")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("incerto", $bgColor="#FFFFFF", $borderColor="#8C8C8C", $fontColor="#595959", $borderStyle=DashedLine(), $legendText="Indefinido ou a confirmar")
AddRelTag("incerto", $textColor="#8C8C8C", $lineColor="#8C8C8C", $lineStyle=DashedLine(), $legendText="Relação inativa, futura ou a confirmar")
AddRelTag("inproc", $textColor="#8A0620", $lineColor="#CC092F", $legendText="Chamada in-process (porta)")
UpdateBoundaryStyle($bgColor="#FFFFFF", $fontColor="#404040", $borderColor="#8C8C8C")

LAYOUT_TOP_DOWN()

title C4 Nível 3 — Componentes do COMP-01 atacado-adesao-termo

Container_Ext(axwayext, "Axway API Gateway (COMP-09)", "Política externa atacado-adesao-sf", "Entrada do Salesforce via Akamai > App Gateway WAF", $tags="plataforma")

Container_Boundary(c01, "atacado-adesao-termo (COMP-01) – Java 21, Spring Boot 3, monólito modular") {
  Component(api, "API Adesão v1 (01.1 adesao-termo)", "Spring Web MVC, OpenAPI", "POST /v1/adesoes, GET /v1/adesoes/{id}, /documento, /confirmacao-envio, /reemissao, /cancelamento", $tags="foco")
  Component(admin, "API administrativa (01.1)", "Listener separado, sem Route", "/admin/v1/** : retomar e reconciliar saga, reprocessar sinais", $tags="foco")
  Component(dominio, "Domínio AdesaoTermo (01.1 adesao-termo)", "Agregado + políticas", "AdesaoTermo, PoliticaElegibilidade, PoliticaTipoTermo; invariantes INV-01..INV-10; comandos do 03", $tags="foco")
  Component(inbox, "Consumidor da inbox (01.1)", "Job agendado, SKIP LOCKED", "Lê adesao_entrada.sinal_externo; aplica INV-07/INV-08; RegistrarConclusaoAssinatura, InvalidarAssinantes", $tags="foco")
  Component(outbox, "Outbox writer + trilha de auditoria (01.1)", "Spring Data / JDBC, Flyway", "Grava estado, outbox_evento e trilha_auditoria na mesma transação", $tags="foco")

  Component(elig, "acl-registro-contratos (01.5)", "Adaptador ElegibilidadePort", "Hoje: indicadores do Salesforce (PRM-TEC-10); futuro: BC-13", $tags="porta")
  Component(firpacl, "acl-firp (01.2)", "Adaptador ConsultaAssinantesPort, RestClient + Resilience4j", "Traduz Representante/Poder em Assinante; descarta CPF", $tags="porta")
  Component(saga, "acl-gacd + saga ProcessoEnvioAssinatura (01.3)", "Adaptador AssinaturaDigitalPort + process manager, ShedLock", "3 passos GACD, retentativa, RESULTADO_INCERTO, compensação, reconciliação", $tags="porta")
  Component(doc, "termo-documento (01.4)", "Porta GeradorDocumentoPort > RenderizadorDocumento", "Catálogo modelo_termo; composição; SHA-256; staging; prévia", $tags="foco")
  Component(rimpd, "RenderizadorImpd (01.4, Plano A)", "Adaptador REST", "Chama impd-srv-doc-generator; saída base64", $tags="porta")
  Component(rprop, "RenderizadorProprio (01.4, Plano B)", "Thymeleaf + OpenHTMLtoPDF/PDFBox", "Desligado: termo.renderizador=impd|proprio", $tags="inativo")
  Component(conv, "convenio-produto (01.6)", "Porta SolicitacaoConvenioPort", "Inativa: convenio.gatilho.habilitado=false. Quando ativa: abre pendência de implantação (Salesforce) e acompanha o status; não cria o convênio", $tags="inativo")
}

ContainerDb(c04, "atacado-adesao-db (COMP-04)", "PostgreSQL Flexible Server", "Schemas adesao_termo, termo_documento, adesao_entrada, adesao_acompanhamento", $tags="irmao")
ContainerDb(c05, "atacado-adesao-staging (COMP-05)", "Azure Blob Storage", "termos-staging/{idAdesao}/{tentativa}/termo.pdf", $tags="irmao")
Container(c02, "atacado-adesao-receptor (COMP-02)", "Java 21", "Grava sinais na inbox", $tags="irmao")
Container(c03, "atacado-adesao-acompanhamento (COMP-03)", "Java 21, worker", "Lê a outbox e entrega ao Salesforce", $tags="irmao")

Container_Ext(axwayint, "Axway API Gateway (COMP-09)", "Saída interna", "Token LEAP (hipótese)", $tags="plataforma")
System_Ext(firp, "FIRP (COMP-13)", "Representantes e poderes", $tags="corporativo")
System_Ext(gacd, "GACD (COMP-14)", "Coordenar Contrato, Armazenar Prévia, Coordenar Regra", $tags="corporativo")
System_Ext(impd, "IMPD impd-srv-doc-generator (COMP-16)", "Plano A, rota a confirmar", $tags="corporativo")
System_Ext(convsys, "Sistema de Convênio", "Sistema do produto, indefinido (QA-CON-02). Convênio criado e ativado pelo executor da implantação (QA-CON-24)", $tags="incerto")

Rel(axwayext, api, "Comandos do Salesforce", "HTTPS/REST, OAuth 2.0 + mTLS na borda")
Rel(api, dominio, "Executa comandos", "in-process", $tags="inproc")
Rel(admin, saga, "Retomar / reconciliar", "in-process", $tags="inproc")
Rel(inbox, dominio, "Aplica sinais externos", "in-process", $tags="inproc")
Rel(dominio, elig, "ElegibilidadePort", "in-process", $tags="inproc")
Rel(dominio, firpacl, "ConsultaAssinantesPort", "in-process", $tags="inproc")
Rel(dominio, doc, "GeradorDocumentoPort (GerarDocumentoTermo)", "in-process", $tags="inproc")
Rel(dominio, saga, "AssinaturaDigitalPort", "in-process", $tags="inproc")
Rel(dominio, conv, "SolicitacaoConvenioPort", "in-process", $tags="incerto")
Rel(dominio, outbox, "Persiste estado + eventos", "in-process", $tags="inproc")
Rel(saga, outbox, "Estado da saga + eventos", "in-process", $tags="inproc")
Rel(doc, rimpd, "RenderizadorDocumento", "in-process", $tags="inproc")
Rel(doc, rprop, "RenderizadorDocumento", "in-process", $tags="incerto")

Rel(outbox, c04, "estado, outbox_evento, trilha_auditoria", "SQL/TLS 5432")
Rel(inbox, c04, "Lê e marca sinal_externo", "SQL/TLS 5432")
Rel(doc, c05, "Grava e lê PDF", "HTTPS (Blob REST)")
Rel(saga, c05, "Lê PDF e confere hash", "HTTPS (Blob REST)")
Rel(c02, c04, "INSERT inbox", "SQL/TLS 5432")
Rel(c03, c04, "Lê outbox", "SQL/TLS 5432")

Rel(firpacl, axwayint, "Consulta representantes", "HTTPS/REST, LEAP (hipótese)")
Rel(saga, axwayint, "3 chamadas GACD", "HTTPS/REST, LEAP (hipótese) + usuário sistêmico")
Rel(axwayint, firp, "Encaminha", "HTTPS/REST")
Rel(axwayint, gacd, "Encaminha", "HTTPS/REST")
Rel(rimpd, impd, "Gera PDF (base64)", "HTTPS/REST, auth a definir")
Rel(conv, outbox, "Futuro: ConvenioSolicitado (abre a implantação)", "in-process", $tags="incerto")
Rel(conv, convsys, "Futuro: acompanha o status do convênio", $tags="incerto")

Lay_R(api, admin)
Lay_R(elig, firpacl)
Lay_R(firpacl, saga)
Lay_R(saga, doc)
Lay_R(rimpd, rprop)

SHOW_LEGEND()
@enduml
```

### 4.2 COMP-02 `atacado-adesao-receptor` e COMP-03 `atacado-adesao-acompanhamento` (complementar)

![C4 Nível 3 — Componentes do COMP-02 e do COMP-03](diagramas/c4/c4-03b-componentes-receptor-acompanhamento.png)

*SVG: [c4-03b-componentes-receptor-acompanhamento.svg](diagramas/c4/c4-03b-componentes-receptor-acompanhamento.svg)*

**Leitura:** o receptor não tem regra de estado do termo. Ele valida, deduplica e grava o `SinalExterno` na inbox com `ON CONFLICT DO NOTHING`, em `AGUARDANDO_REVALIDACAO`, e responde o ACK ao GACD depois do commit. Só depois um worker assíncrono **revalida os assinantes na FIRP (RN-06, ADR-13)** e grava o resultado no sinal (`RECEBIDO`): assinatura confirmada ou `AssinantesInvalidados`. A revalidação compara os assinantes do callback com os poderes vigentes e usa o contrato de consulta da FIRP já usado pelo COMP-01, pela saída interna do Axway. Com a FIRP indisponível, há retentativa com backoff e o sinal continua `AGUARDANDO_REVALIDACAO`; ele é reprocessado, não descartado, e a assinatura não é confirmada sem revalidar (o COMP-01 só lê sinais `RECEBIDO`). As regras INV-07 (protocolo vigente) e INV-08 ficam no COMP-01. O acompanhamento tem uma instância ativa por lock (ShedLock), projeta `VisaoJornadaAdesao`, cria `AlertaGerente` e entrega ao Salesforce com retentativa por até 24 h, estacionando e permitindo reentrega administrativa.

Os nomes internos dos componentes deste diagrama (por exemplo, "Revalidação de assinantes", "Adaptador FIRP", "Gravador da inbox" e "Cliente Salesforce") são **rótulos descritivos** das responsabilidades listadas no 04a. Eles não são nomes técnicos novos.

```plantuml
@startuml c4-03b-componentes-receptor-acompanhamento
!include <C4/C4_Component>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 96
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("boundary")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Componente novo")
AddElementTag("irmao", $bgColor="#E06A7E", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Outro container da solução")
AddElementTag("config", $bgColor="#E8A3AE", $borderColor="#CC092F", $fontColor="#262626", $legendText="Configuração nova em SaaS")
AddElementTag("plataforma", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF", $legendText="Infraestrutura corporativa consumida")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("porta", $bgColor="#F4D3D8", $borderColor="#CC092F", $fontColor="#262626", $legendText="Adaptador de porta (ACL / saída)")
AddRelTag("inproc", $textColor="#8A0620", $lineColor="#CC092F", $legendText="Chamada in-process")
UpdateBoundaryStyle($bgColor="#FFFFFF", $fontColor="#404040", $borderColor="#8C8C8C")

LAYOUT_LEFT_RIGHT()

title C4 Nível 3 — Componentes do COMP-02 atacado-adesao-receptor e do COMP-03 atacado-adesao-acompanhamento

System_Ext(gacd, "GACD (COMP-14)", "Callback de assinatura", $tags="corporativo")
Container_Ext(axway, "Axway API Gateway (COMP-09)", "Rota interna de entrada", "atacado-adesao-callback-gacd", $tags="plataforma")

Container_Boundary(c02, "atacado-adesao-receptor (COMP-02) – Java 21, Spring Boot 3") {
  Component(epcb, "Endpoint de callback GACD", "Spring Web MVC", "POST /v1/callbacks/gacd/assinaturas/{idAdesao}", $tags="foco")
  Component(acl, "ACL de entrada", "Validação de esquema e identidade", "Confere claims do Axway; deduplica; traduz para SinalExterno canônico", $tags="foco")
  Component(inboxw, "Gravador da inbox", "JDBC", "INSERT ... ON CONFLICT DO NOTHING em AGUARDANDO_REVALIDACAO; ACK só após commit", $tags="foco")
  Component(reval, "Revalidação de assinantes (RN-06)", "Worker assíncrono, depois do ACK", "Lê sinais AGUARDANDO_REVALIDACAO; compara os assinantes do callback com os poderes vigentes; grava o resultado no sinal (RECEBIDO): assinatura confirmada ou AssinantesInvalidados; sem regra de estado do termo", $tags="foco")
  Component(firpcli, "Adaptador FIRP (ACL FIRP)", "Porta de consulta de poderes, RestClient + Resilience4j", "Reusa o contrato de consulta do COMP-01; timeout e retentativa com backoff; FIRP indisponível: sinal continua AGUARDANDO_REVALIDACAO, sem descarte", $tags="porta")
}

ContainerDb(c04, "atacado-adesao-db (COMP-04)", "PostgreSQL Flexible Server", "adesao_entrada.sinal_externo; adesao_termo.outbox_evento; adesao_acompanhamento.*", $tags="irmao")
Container(c01, "atacado-adesao-termo (COMP-01)", "Java 21", "Processa a inbox, aplica o estado do termo e grava a outbox", $tags="irmao")
Container_Ext(axwayout, "Axway API Gateway (COMP-09)", "Saída interna", "Consumo FIRP; token LEAP (hipótese)", $tags="plataforma")
System_Ext(firp, "FIRP (COMP-13)", "Representantes e poderes vigentes", $tags="corporativo")

Container_Boundary(c03, "atacado-adesao-acompanhamento (COMP-03) – Java 21, Spring Boot 3, worker") {
  Component(relay, "Relay da outbox", "Polling FOR UPDATE SKIP LOCKED + ShedLock", "Ordem por idAdesao + versaoAgregado; idempotência por idEvento", $tags="foco")
  Component(proj, "Projeção VisaoJornadaAdesao", "Spring Data / JDBC", "Status da jornada; AlertaGerente (ASSINANTES_INVALIDOS, FALHA_GERACAO); entrega_status", $tags="foco")
  Component(sfcli, "Cliente Salesforce", "RestClient + JWT assinado, cache de token", "Upsert Adesao_Termo~__c e Alerta_Adesao~__c; retentativa até 24 h; estacionamento", $tags="foco")
  Component(reent, "Reentrega administrativa", "Listener interno", "/admin/v1/entregas/{id}/reentregar", $tags="foco")
}

Container_Ext(fw, "Azure Firewall – egress (COMP-12)", "Hub", "Allowlist FQDN My Domain", $tags="plataforma")
Container(comp06, "Artefatos Salesforce do Atacado (COMP-06)", "Salesforce FSC", "Adesao_Termo~__c, Alerta_Adesao~__c, Flow de notificação", $tags="config")

Rel(gacd, axway, "Callback", "HTTPS, mTLS ou token GACD")
Rel(axway, epcb, "Encaminha", "HTTPS/REST")
Rel(epcb, acl, "Valida e traduz", "in-process", $tags="inproc")
Rel(acl, inboxw, "SinalExterno canônico", "in-process", $tags="inproc")
Rel(inboxw, c04, "Grava sinal AGUARDANDO_REVALIDACAO", "SQL/TLS 5432")
Rel(reval, c04, "Lê sinais pendentes; grava o resultado (RECEBIDO)", "SQL/TLS 5432")
Rel(reval, firpcli, "Consulta poderes vigentes", "in-process", $tags="inproc")
Rel(firpcli, axwayout, "Consulta representantes e poderes", "HTTPS/REST, LEAP (hipótese)")
Rel(axwayout, firp, "Encaminha", "HTTPS/REST")
Rel(c01, c04, "Consome inbox; grava outbox", "SQL/TLS 5432")
Rel(relay, c04, "Lê outbox_evento; grava projeção e entrega_status (mesma transação)", "SQL/TLS 5432")
Rel(relay, proj, "Evento de domínio", "in-process", $tags="inproc")
Rel(proj, sfcli, "Entrega pendente", "in-process", $tags="inproc")
Rel(reent, sfcli, "Reentrega estacionada", "in-process", $tags="inproc")
Rel(sfcli, fw, "Upsert", "HTTPS 443, OAuth 2.0 JWT Bearer")
Rel(fw, comp06, "Egress", "HTTPS 443")

SHOW_LEGEND()
@enduml
```

---

## 5. Diagramas Dinâmicos

### 5.1 Jornada principal: solicitação → FIRP → documento → GACD → assinatura no Canal → callback → inbox e ACK → revalidação na FIRP (COMP-02) → outbox → Salesforce

Consolida os Fluxos 1 e 2 do 04 (§6.1 e §6.2) em uma única sequência numerada. Os rótulos no diagrama são curtos; protocolo e autenticação de cada passo estão na tabela abaixo.

![C4 Dinâmico — Jornada](diagramas/c4/c4-04-dinamico-jornada.png)

*SVG: [c4-04-dinamico-jornada.svg](diagramas/c4/c4-04-dinamico-jornada.svg)*

| # | De → Para | Interação | Protocolo / autenticação |
|---|---|---|---|
| 1 | Gerente de Cash → COMP-06 | Solicita o Termo de Adesão da Proposta aprovada | UI Salesforce |
| 2 | COMP-06 → COMP-01 | `POST /v1/adesoes` com `Idempotency-Key`; resposta `202` + `idAdesao` | HTTPS/REST via Akamai → AppGW WAF → Axway; OAuth 2.0 + mTLS |
| 3 | COMP-01 → COMP-04 | Elegibilidade e tipo (`ElegibilidadePort`); `AdesaoTermo` Solicitado + outbox `TermoSolicitado` | SQL/TLS |
| 4 | COMP-01 → FIRP | Consulta representantes com poderes | HTTPS/REST via Axway; LEAP **[HIPÓTESE]** |
| 5 | COMP-01 → IMPD | Gera documento (tipo, versão do modelo, variáveis) → PDF base64 | HTTPS/REST; rota e auth a confirmar (QA-TEC-01) |
| 6 | COMP-01 → COMP-05 | Grava PDF em `termos-staging/{idAdesao}/{tentativa}` | HTTPS (Blob REST), private endpoint |
| 7 | COMP-01 → COMP-04 | Gerado: `versaoModelo`, hash SHA-256, referência do blob + outbox `TermoGerado` | SQL/TLS |
| 8 | COMP-03 → COMP-06 | Relay da outbox: upsert `Adesao_Termo__c` = Gerado | HTTPS/REST via Firewall do Hub; OAuth 2.0 JWT Bearer |
| 9 | COMP-06 → COMP-01 | Prévia (`GET /v1/adesoes/{id}/documento`) e confirmação (`POST /v1/adesoes/{id}/confirmacao-envio`) | HTTPS/REST via borda externa |
| 10 | COMP-01 → GACD | Passo 1 Coordenar Contrato (assinantes + `callbackUrl`) → `codigoProtocolo` | HTTPS/REST via Axway; LEAP **[HIPÓTESE]** |
| 11 | COMP-01 → GACD | Passo 2 Armazenar Prévia (base64 do staging, hash conferido) → `IdPrevia`, `CaminhoPrevia` | HTTPS/REST via Axway; LEAP + usuário sistêmico |
| 12 | GACD → GCC/Filenet | Armazena a prévia | Interno ao GACD |
| 13 | COMP-01 → GACD | Passo 3 Coordenar Regra | HTTPS/REST via Axway |
| 14 | COMP-01 → COMP-04 | Saga concluída; Aguardando assinatura + outbox `TermoEnviadoParaAssinatura` | SQL/TLS |
| 15 | COMP-03 → COMP-06 | Upsert Aguardando assinatura + `codigoProtocolo` | HTTPS/REST; OAuth 2.0 JWT Bearer |
| 16 | Cliente PJ Atacado → Canal Digital PJ | Acessa o termo pendente (buscado no GACD) | Fora do escopo do Atacado |
| 17 | Cliente PJ Atacado → Canal Digital PJ | Assina o termo | Fora do escopo do Atacado |
| 18 | Canal Digital PJ → GACD | Registra a assinatura | Fora do escopo do Atacado |
| 19 | GACD → COMP-02 | Callback de assinatura concluída (`POST /v1/callbacks/gacd/assinaturas/{idAdesao}`) | HTTPS via Axway interno; mTLS ou token do GACD (QA-TEC-07) |
| 20 | COMP-02 → COMP-04 | `INSERT` na inbox em `AGUARDANDO_REVALIDACAO` (`ON CONFLICT DO NOTHING`); ACK ao GACD só após o commit, sem esperar a FIRP | SQL/TLS |
| 21 | COMP-02 → FIRP | Depois do ACK, num worker assíncrono: **revalida os assinantes (RN-06)**, comparando os assinantes do callback com os poderes vigentes. Com assinantes inválidos, segue a §5.2. FIRP indisponível: o sinal continua `AGUARDANDO_REVALIDACAO` e é reprocessado com backoff, sem descarte | HTTPS/REST via Axway (N-12); LEAP **[HIPÓTESE]** (R-12, ACL FIRP) |
| 22 | COMP-02 → COMP-04 | Grava o resultado no sinal: `RECEBIDO`, assinatura confirmada | SQL/TLS |
| 23 | COMP-01 → COMP-04 | Processa inbox, só sinais `RECEBIDO` (INV-07): Assinado + outbox `AssinaturaConcluida` + auditoria | SQL/TLS (`SKIP LOCKED`) |
| 24 | COMP-03 → COMP-04 | Lê outbox por `idAdesao` + `versaoAgregado`; projeção e `entrega_status` | SQL/TLS |
| 25 | COMP-03 → COMP-06 | Upsert `Adesao_Termo__c` = Assinado | HTTPS/REST; OAuth 2.0 JWT Bearer |
| 26 | COMP-06 → Gerente de Cash | Notificação de termo assinado | Flow / Custom Notification |

Os passos 4 a 8 e 10 a 15 rodam no worker da saga do COMP-01 depois do `202`. A confirmação do Gerente (passo 9) fica atrás da flag `adesao.confirmacao-gerente.habilitada` (PRM-TEC-14). Com a flag desligada, a saga começa logo depois de `TermoGerado`. Falha e compensação da saga estão no Fluxo 4 do 04 (§6.4). Os passos 16 a 18 são do Canal Digital PJ, que só dá acesso ao termo e coleta a assinatura; ele não consulta a FIRP nem chama API do Atacado. A revalidação na FIRP (21) é do COMP-02 e acontece **depois** de a assinatura ser registrada no GACD (18), do callback (19) e do ACK, que sai logo após o commit na inbox (20) (RN-06, ADR-13; 05 DT-21). O termo só é dado como assinado depois da revalidação (22, 23). O que fazer com o protocolo já assinado quando a revalidação falha está em aberto (QA-NEG-20). Com a FIRP indisponível, o sinal fica `AGUARDANDO_REVALIDACAO` e é reprocessado com backoff, sem descarte.

```plantuml
@startuml c4-04-dinamico-jornada
!include <C4/C4_Dynamic>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("person\nexternal_person\nboundary")
UpdateElementStyle("person", $bgColor="#404040", $borderColor="#262626", $fontColor="#FFFFFF")
UpdateElementStyle("external_person", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Container novo (em foco)")
AddElementTag("config", $bgColor="#E8A3AE", $borderColor="#CC092F", $fontColor="#262626", $legendText="Configuração nova em SaaS")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("abstraido", $bgColor="#A6A6A6", $borderColor="#6E6E6E", $fontColor="#FFFFFF", $legendText="Externo abstraído (outro time)")
AddRelTag("assinc", $textColor="#8A0620", $lineColor="#CC092F", $lineStyle=DashedLine(), $legendText="Passo assíncrono (worker, inbox ou outbox)")
UpdateBoundaryStyle($bgColor="#FFFFFF", $fontColor="#404040", $borderColor="#8C8C8C")

LAYOUT_LEFT_RIGHT()

title C4 Dinâmico — Jornada do Termo de Adesão: solicitação, geração, GACD, assinatura no Canal, callback, revalidação na FIRP pelo Atacado e status

Person(gerente, "Gerente de Cash")
Person_Ext(cliente, "Cliente PJ Atacado")
Container(comp06, "Artefatos Salesforce do Atacado (COMP-06)", "Salesforce FSC", $tags="config")
System_Ext(canal, "Canal Digital PJ (COMP-18)", "Abstraído", $tags="abstraido")

Boundary(aro, "ARO Atacado – namespace atacado-core") {
  Container(c01, "atacado-adesao-termo (COMP-01)", "Java 21", $tags="foco")
  Container(c02, "atacado-adesao-receptor (COMP-02)", "Java 21", $tags="foco")
  Container(c03, "atacado-adesao-acompanhamento (COMP-03)", "Java 21, worker", $tags="foco")
}
ContainerDb(c04, "atacado-adesao-db (COMP-04)", "PostgreSQL Flexible Server", $tags="foco")
ContainerDb(c05, "atacado-adesao-staging (COMP-05)", "Azure Blob Storage", $tags="foco")

System_Ext(firp, "FIRP (COMP-13)", $tags="corporativo")
System_Ext(impd, "IMPD impd-srv-doc-generator (COMP-16)", "Plano A", $tags="corporativo")
System_Ext(gacd, "GACD (COMP-14)", $tags="corporativo")
System_Ext(gcc, "GCC/Filenet (COMP-15)", $tags="corporativo")

' --- Solicitação ---
Rel(gerente, comp06, "Solicita o termo")
Rel(comp06, c01, "POST /v1/adesoes (via borda externa)")
Rel(c01, c04, "Solicitado + outbox")
' --- FIRP e documento (worker da saga no COMP-01) ---
Rel(c01, firp, "Consulta representantes (via Axway)", $tags="assinc")
Rel(c01, impd, "Gera PDF base64", $tags="assinc")
Rel(c01, c05, "Grava PDF no staging", $tags="assinc")
Rel(c01, c04, "Gerado + hash + outbox", $tags="assinc")
Rel(c03, comp06, "Upsert status Gerado", $tags="assinc")
' --- Prévia e confirmação ---
Rel(comp06, c01, "Prévia e confirmação de envio")
' --- Saga GACD (3 passos, via Axway) ---
Rel(c01, gacd, "Passo 1 Coordenar Contrato", $tags="assinc")
Rel(c01, gacd, "Passo 2 Armazenar Prévia", $tags="assinc")
Rel(gacd, gcc, "Armazena a prévia")
Rel(c01, gacd, "Passo 3 Coordenar Regra", $tags="assinc")
Rel(c01, c04, "Aguardando assinatura + outbox", $tags="assinc")
Rel(c03, comp06, "Upsert Aguardando assinatura", $tags="assinc")
' --- Assinatura no Canal: o Canal só dá acesso ao termo e coleta a assinatura ---
Rel(cliente, canal, "Acessa o termo pendente")
Rel(cliente, canal, "Assina o termo")
Rel(canal, gacd, "Registra a assinatura")
' --- Callback -> inbox -> ACK -> revalidação na FIRP (COMP-02) -> outbox -> Salesforce ---
Rel(gacd, c02, "Callback (via Axway interno)")
Rel(c02, c04, "INSERT inbox AGUARDANDO_REVALIDACAO; ACK após commit")
Rel(c02, firp, "Depois do ACK: revalida assinantes (RN-06, via Axway)", $tags="assinc")
Rel(c02, c04, "Grava o resultado: RECEBIDO, assinatura confirmada", $tags="assinc")
Rel(c01, c04, "Processa inbox (RECEBIDO): Assinado + outbox", $tags="assinc")
Rel(c03, c04, "Lê outbox; projeção", $tags="assinc")
Rel(c03, comp06, "Upsert status Assinado", $tags="assinc")
Rel(comp06, gerente, "Notifica termo assinado")

Lay_R(gerente, cliente)
Lay_R(c01, c02)
Lay_R(c02, c03)

SHOW_LEGEND()
@enduml
```

### 5.2 Assinantes inválidos na revalidação do callback (COMP-02)

Corresponde ao Fluxo 3 do 04 (§6.3) e à revalidação na FIRP no callback do §11.3 (RN-06, RN-07, ADR-13). O Canal Digital PJ só dá acesso ao termo e coleta a assinatura: não bloqueia a assinatura nem chama API do Atacado. A invalidez é detectada pelo COMP-02 depois de a assinatura ser registrada no GACD. O destino do protocolo/termo já assinado no GACD (cancelar, invalidar, exigir nova assinatura e quem executa) é questão em aberto (**QA-NEG-20**). Até a resposta, vale o tratamento abaixo: o termo vai para o estado "Assinantes inválidos", o Gerente recebe o alerta no Salesforce e reinicia o envio.

![C4 Dinâmico — Assinantes inválidos](diagramas/c4/c4-05-dinamico-assinantes-invalidos.png)

*SVG: [c4-05-dinamico-assinantes-invalidos.svg](diagramas/c4/c4-05-dinamico-assinantes-invalidos.svg)*

| # | De → Para | Interação | Protocolo / autenticação |
|---|---|---|---|
| 1 | Cliente PJ Atacado → Canal Digital PJ | Acessa o termo pendente e assina | Fora do escopo do Atacado |
| 2 | Canal Digital PJ → GACD | Registra a assinatura | Fora do escopo do Atacado |
| 3 | GACD → Axway | Callback de assinatura concluída | HTTPS via rota interna `atacado-adesao-callback-gacd`; mTLS ou token do GACD (QA-TEC-07) |
| 4 | Axway → COMP-02 | Encaminha `POST /v1/callbacks/gacd/assinaturas/{idAdesao}`; o COMP-02 autentica, valida e deduplica | HTTPS/REST, ingress privado |
| 5 | COMP-02 → COMP-04 | `INSERT` na inbox em `AGUARDANDO_REVALIDACAO` (`GACD` + `codigoProtocolo`; `ON CONFLICT DO NOTHING`); ACK ao GACD só após o commit, sem esperar a FIRP | SQL/TLS |
| 6 | COMP-02 → FIRP | Depois do ACK, num worker assíncrono: **revalida os assinantes (RN-06)**, consultando os poderes vigentes e comparando com os assinantes do callback. FIRP indisponível: retentativa com backoff; o sinal continua `AGUARDANDO_REVALIDACAO` e é reprocessado, sem descarte | HTTPS/REST via Axway (N-12); LEAP **[HIPÓTESE]** (R-12, ACL FIRP; regras em QA-CON-09) |
| 7 | COMP-02 → COMP-04 | Grava o resultado no sinal: `RECEBIDO`, assinantes inválidos (motivo em enum e quantidade, sem dado pessoal) | SQL/TLS |
| 8 | COMP-01 → COMP-04 | Processa inbox, só sinais `RECEBIDO` (INV-07, INV-08): protocolo vigente; estado "Assinantes inválidos" + outbox `AssinantesInvalidados`. Destino do protocolo assinado no GACD: QA-NEG-20 | SQL/TLS |
| 9 | COMP-03 → COMP-04 | Lê outbox; cria `AlertaGerente` | SQL/TLS |
| 10 | COMP-03 → COMP-06 | Upsert de status + `Alerta_Adesao__c` do tipo `ASSINANTES_INVALIDOS` | HTTPS/REST via Azure Firewall; OAuth 2.0 JWT Bearer |
| 11 | COMP-06 → Gerente de Cash | Notificação e tarefa para regularizar poderes | Flow / Custom Notification |
| 12 | Gerente de Cash → COMP-06 | Reemite após regularização na FIRP | UI Salesforce |
| 13 | COMP-06 → COMP-01 | `POST /v1/adesoes/{id}/reemissao` | HTTPS/REST via borda externa |

```plantuml
@startuml c4-05-dinamico-assinantes-invalidos
!include <C4/C4_Dynamic>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("person\nexternal_person\nboundary")
UpdateElementStyle("person", $bgColor="#404040", $borderColor="#262626", $fontColor="#FFFFFF")
UpdateElementStyle("external_person", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Container novo (em foco)")
AddElementTag("config", $bgColor="#E8A3AE", $borderColor="#CC092F", $fontColor="#262626", $legendText="Configuração nova em SaaS")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("abstraido", $bgColor="#A6A6A6", $borderColor="#6E6E6E", $fontColor="#FFFFFF", $legendText="Externo abstraído (outro time)")
AddElementTag("plataforma", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF", $legendText="Infraestrutura corporativa consumida")
AddRelTag("assinc", $textColor="#8A0620", $lineColor="#CC092F", $lineStyle=DashedLine(), $legendText="Passo assíncrono (worker, inbox ou outbox)")
UpdateBoundaryStyle($bgColor="#FFFFFF", $fontColor="#404040", $borderColor="#8C8C8C")

LAYOUT_LEFT_RIGHT()

title C4 Dinâmico — Assinantes inválidos na revalidação do callback: GACD > Axway > COMP-02 > inbox e ACK > FIRP > COMP-01 > outbox > COMP-03 > Salesforce

Person_Ext(cliente, "Cliente PJ Atacado", "Assinante do cliente")
System_Ext(canal, "Canal Digital PJ (COMP-18)", "Abstraído. Só dá acesso ao termo e coleta a assinatura", $tags="abstraido")
System_Ext(gacd, "GACD (COMP-14)", $tags="corporativo")
Container_Ext(axway, "Axway API Gateway (COMP-09)", "Rota interna atacado-adesao-callback-gacd", $tags="plataforma")

Boundary(aro, "ARO Atacado – namespace atacado-core") {
  Container(c02, "atacado-adesao-receptor (COMP-02)", "Java 21", $tags="foco")
  Container(c01, "atacado-adesao-termo (COMP-01)", "Java 21", $tags="foco")
  Container(c03, "atacado-adesao-acompanhamento (COMP-03)", "Java 21, worker", $tags="foco")
}
System_Ext(firp, "FIRP (COMP-13)", $tags="corporativo")
ContainerDb(c04, "atacado-adesao-db (COMP-04)", "PostgreSQL Flexible Server", $tags="foco")
Container(comp06, "Artefatos Salesforce do Atacado (COMP-06)", "Salesforce FSC", $tags="config")
Person(gerente, "Gerente de Cash")

Rel(cliente, canal, "Acessa o termo pendente e assina")
Rel(canal, gacd, "Registra a assinatura")
Rel(gacd, axway, "Callback de assinatura")
Rel(axway, c02, "POST /v1/callbacks/gacd/assinaturas/{idAdesao}")
Rel(c02, c04, "INSERT inbox AGUARDANDO_REVALIDACAO (codigoProtocolo); ACK após commit")
Rel(c02, firp, "Depois do ACK: revalida assinantes (RN-06, via Axway): poderes vigentes x assinantes do callback", $tags="assinc")
Rel(c02, c04, "Grava o resultado: RECEBIDO, assinantes inválidos (motivo, quantidade)", $tags="assinc")
Rel(c01, c04, "Processa inbox: estado Assinantes inválidos + outbox (protocolo assinado: QA-NEG-20)", $tags="assinc")
Rel(c03, c04, "Lê outbox; cria AlertaGerente", $tags="assinc")
Rel(c03, comp06, "Upsert status + Alerta_Adesao~__c ASSINANTES_INVALIDOS (via Azure Firewall)", $tags="assinc")
Rel(comp06, gerente, "Notificação e tarefa: regularizar poderes")
Rel(gerente, comp06, "Reemite após regularização na FIRP")
Rel(comp06, c01, "POST /v1/adesoes/{id}/reemissao (via borda externa)")

SHOW_LEGEND()
@enduml
```

---

## 6. Implantação

**Pergunta que responde:** em que nós de infraestrutura cada container roda, em que vNet e subnet, e por quais fluxos de rede (`N-xx`, 04 §7.1) eles se ligam?

![C4 Implantação](diagramas/c4/c4-06-implantacao.png)

*SVG: [c4-06-implantacao.svg](diagramas/c4/c4-06-implantacao.svg)*

**Leitura:**

1. **Azure, Hub and Spoke.** O **Hub** concentra Application Gateway WAF v2, Azure Firewall (egress) e, **a confirmar**, o Axway. O **Spoke Plataformas Funcionais** hospeda o ARO Atacado, a subnet delegada do PostgreSQL Flexible Server e a subnet de private endpoints (Blob e Key Vault).
2. **Namespace `atacado-core`:** três Deployments com a topologia do 04 §7: COMP-01 com 2 a 4 réplicas e HPA; COMP-02 com 2 a 3 réplicas, PDB e anti-afinidade por zona; COMP-03 com 2 réplicas e 1 ativa por lock. Ingress privado que aceita só o Axway, NetworkPolicy deny-all, EgressFirewall e SCC `restricted-v2`. Os segredos são montados pelo Secrets Store CSI Driver (provider Azure Key Vault).
3. **Fora da Azure do Atacado:** Salesforce (SaaS, Hyperforce, internet) e Akamai (borda internet).
4. **Localização incerta (nós tracejados):** o ambiente corporativo onde vivem FIRP, GACD, GCC/Filenet e o Emissor LEAP pode ser Azure ou on-premise (o ArchiMate do GACD diz "Azure > ON", ambíguo; QA-TEC-09). O IMPD API cloud está "na Azure" **[FATO: 06]**, mas em outra vNet, com rota ARO → IMPD a confirmar (QA-TEC-01). O Canal Digital PJ é abstraído e só registra a assinatura no GACD; não há fluxo de rede do Canal para a solução (o N-06 saiu na rodada 6). O COMP-02 consome a FIRP pelo N-12, com a mesma política de consumo do N-02 do COMP-01 e o client do COMP-02.

```plantuml
@startuml c4-06-implantacao
!include <C4/C4_Deployment>

' ---------- Estilo (paleta discreta Bradesco) ----------
skinparam dpi 110
skinparam defaultFontName "DejaVu Sans"
SetDefaultLegendEntries("")
AddElementTag("foco", $bgColor="#CC092F", $borderColor="#8A0620", $fontColor="#FFFFFF", $legendText="Container novo (em foco)")
AddElementTag("config", $bgColor="#E8A3AE", $borderColor="#CC092F", $fontColor="#262626", $legendText="Configuração nova em SaaS")
AddElementTag("plataforma", $bgColor="#8C8C8C", $borderColor="#5E5E5E", $fontColor="#FFFFFF", $legendText="Infraestrutura corporativa consumida")
AddElementTag("corporativo", $bgColor="#6E6E6E", $borderColor="#4A4A4A", $fontColor="#FFFFFF", $legendText="Sistema corporativo consumido")
AddElementTag("abstraido", $bgColor="#A6A6A6", $borderColor="#6E6E6E", $fontColor="#FFFFFF", $legendText="Externo abstraído (outro time)")
AddElementTag("incerto", $bgColor="#FFFFFF", $borderColor="#8C8C8C", $fontColor="#595959", $borderStyle=DashedLine(), $legendText="Hipótese ou localização a confirmar")
AddNodeTag("noincerto", $bgColor="#FAFAFA", $fontColor="#595959", $borderColor="#8C8C8C", $borderStyle=DashedLine(), $legendText="Nó com localização incerta (QA-TEC-09)")
AddRelTag("incerto", $textColor="#8C8C8C", $lineColor="#8C8C8C", $lineStyle=DashedLine(), $legendText="Rota a confirmar")
AddRelTag("segredo", $textColor="#8C8C8C", $lineColor="#B0B0B0", $lineStyle=DottedLine(), $legendText="Segredos via Secrets Store CSI Driver")

LAYOUT_TOP_DOWN()

title C4 Implantação — Adesão ao Termo – Atacado (Azure Hub and Spoke, ARO atacado-core)

Deployment_Node(sfsaas, "Salesforce", "SaaS, Hyperforce, internet") {
  Container(comp06, "Artefatos Salesforce do Atacado (COMP-06)", "LWC/Flow, Named Credential, Connected App", "My Domain; Adesao_Termo~__c, Alerta_Adesao~__c", $tags="config")
}

Deployment_Node(akam, "Akamai", "Borda internet (COMP-07)") {
  Container_Ext(akamai, "Akamai Edge", "CDN/WAF", "TLS/mTLS, allowlist de IPs do Salesforce", $tags="plataforma")
}

Deployment_Node(azure, "Azure", "Tenant corporativo") {
  Deployment_Node(hub, "vNet Hub", "Plataformas Funcionais") {
    Container_Ext(agw, "Application Gateway WAF v2 (COMP-08)", "Azure Application Gateway", "Listener da API Adesão", $tags="plataforma")
    Container_Ext(axway, "Axway API Gateway (COMP-09)", "API Gateway", "Políticas atacado-adesao-sf, atacado-adesao-callback-gacd. Hub (localização a confirmar — QA-TEC-09)", $tags="plataforma")
    Container_Ext(fw, "Azure Firewall (COMP-12)", "Egress", "Allowlist FQDN https://<mydomain>.my.salesforce.com", $tags="plataforma")
  }
  Deployment_Node(spoke, "vNet Spoke – Plataformas Funcionais", "Peering com o Hub") {
    Deployment_Node(aro, "ARO Atacado (COMP-10)", "Azure Red Hat OpenShift") {
      Deployment_Node(ns, "namespace atacado-core", "OpenShift project; NetworkPolicy deny-all; EgressFirewall; SCC restricted-v2") {
        Container_Ext(ing, "Ingress privado", "Router interno", "Aceita só o Axway; nenhuma Route pública", $tags="plataforma")
        Deployment_Node(dp1, "Deployment atacado-adesao-termo", "2 a 4 réplicas, HPA; UBI 9 + OpenJDK 21") {
          Container(c01, "atacado-adesao-termo (COMP-01)", "Java 21, Spring Boot 3", "API Adesão v1, saga, documento, inbox/outbox", $tags="foco")
        }
        Deployment_Node(dp2, "Deployment atacado-adesao-receptor", "2 a 3 réplicas, PDB, anti-afinidade por zona") {
          Container(c02, "atacado-adesao-receptor (COMP-02)", "Java 21, Spring Boot 3", "Callback GACD; revalidação de assinantes na FIRP", $tags="foco")
        }
        Deployment_Node(dp3, "Deployment atacado-adesao-acompanhamento", "2 réplicas, 1 ativa por lock (ShedLock)") {
          Container(c03, "atacado-adesao-acompanhamento (COMP-03)", "Java 21, Spring Boot 3", "Relay da outbox, entrega ao Salesforce", $tags="foco")
        }
        Container_Ext(csi, "Secrets Store CSI Driver", "Provider Azure Key Vault", "Monta segredos com rotação", $tags="plataforma")
      }
    }
    Deployment_Node(pgsub, "Subnet delegada", "Acesso privado") {
      ContainerDb(c04, "atacado-adesao-db (COMP-04)", "Azure Database for PostgreSQL Flexible Server", "HA com redundância de zona; schemas por BC", $tags="foco")
    }
    Deployment_Node(pesub, "Subnet de private endpoints", "Private Link") {
      ContainerDb(c05, "atacado-adesao-staging (COMP-05)", "Azure Blob Storage via private endpoint", "Container termos-staging; lifecycle 30 dias", $tags="foco")
      Container_Ext(kv, "Azure Key Vault (COMP-11)", "Private endpoint", "Credenciais LEAP, usuário sistêmico GACD, chave JWT Salesforce", $tags="plataforma")
    }
  }
  Deployment_Node(impdvnet, "Outra vNet Azure (IMPD)", "Rota a confirmar: peering, private endpoint ou Axway (QA-TEC-01)", $tags="noincerto") {
    Container_Ext(impd, "IMPD impd-srv-doc-generator (COMP-16)", "API cloud", "Plano A com gate", $tags="corporativo")
  }
}

Deployment_Node(corp, "Ambiente corporativo", "Azure ou on-premise – localização incerta (QA-TEC-09)", $tags="noincerto") {
  Container_Ext(firp, "FIRP (COMP-13)", "Sistema corporativo", "Representantes e poderes", $tags="corporativo")
  Container_Ext(gacd, "GACD (COMP-14)", "Sistema corporativo", "'Azure > ON' no ArchiMate: ambíguo", $tags="corporativo")
  Container_Ext(gcc, "GCC/Filenet (COMP-15)", "Repositório de conteúdo", "Prévia e termo", $tags="corporativo")
  Container_Ext(leap, "Emissor de token LEAP (COMP-17)", "Identidade", "[HIPÓTESE]", $tags="incerto")
}

Deployment_Node(canais, "Canal Digital PJ", "Time de Canais – abstraído", $tags="noincerto") {
  Container_Ext(canal, "Canal Digital PJ (COMP-18)", "BGS + PDPJ", "Dá acesso ao termo e coleta a assinatura", $tags="abstraido")
}

' ---- Entrada do Salesforce (N-01) ----
Rel(comp06, akamai, "N-01 API Adesão", "HTTPS 443, OAuth 2.0 + mTLS")
Rel(akamai, agw, "N-01", "HTTPS")
Rel(agw, axway, "N-01", "HTTPS")
Rel(axway, ing, "N-01, N-05 rotas externa e interna", "HTTPS")
Rel(ing, c01, "API Adesão", "HTTPS")
Rel(ing, c02, "Callback", "HTTPS")

' ---- Saídas ----
Rel(c01, axway, "N-02, N-03 FIRP e GACD", "HTTPS, LEAP (hipótese) + usuário sistêmico")
Rel(c02, axway, "N-12 Revalidação na FIRP (RN-06)", "HTTPS, LEAP (hipótese)")
Rel(axway, firp, "N-02, N-12", "HTTPS")
Rel(axway, gacd, "N-03", "HTTPS")
Rel(gacd, gcc, "Prévia e termo")
Rel(c01, impd, "N-04 Renderização", "HTTPS, auth a definir", $tags="incerto")
Rel(c01, leap, "Token de workload", "OAuth 2.0 client credentials", $tags="incerto")

' ---- Sinais de entrada ----
Rel(gacd, axway, "N-05 Callback", "HTTPS, mTLS ou token GACD")
Rel(canal, gacd, "Registra a assinatura (fora do escopo do Atacado)")

' ---- Dados e segredos ----
Rel(c01, c04, "N-08", "TLS 5432")
Rel(c02, c04, "N-08", "TLS 5432")
Rel(c03, c04, "N-08", "TLS 5432")
Rel(c01, c05, "N-09", "HTTPS 443")
Rel(csi, kv, "N-10", "HTTPS 443", $tags="segredo")

' ---- Saída para o Salesforce (N-07) ----
Rel(c03, fw, "N-07 Upsert status", "HTTPS 443, OAuth 2.0 JWT Bearer")
Rel(fw, comp06, "N-07 Egress", "HTTPS 443")

SHOW_LEGEND()
@enduml
```

---

## 7. Rastreabilidade: elemento do diagrama → COMP-xx / BC-xx

| Elemento nos diagramas | COMP | BC | Status (04a) | Diagramas |
|---|---|---|---|---|
| Adesão ao Termo – Atacado (sistema) | COMP-01 a COMP-06 | BC-01, BC-02, BC-03 (+ BC-05 configurado) | Novo | N1 |
| `atacado-adesao-termo` | COMP-01 | BC-01 (núcleo) + BC-02 (módulo) | Novo | N2, N3, Dinâmicos, Implantação |
| API Adesão v1, API administrativa, Domínio `AdesaoTermo`, Consumidor da inbox, Outbox writer + trilha de auditoria | COMP-01.1 `adesao-termo` | BC-01 | Novo (módulo) | N3 |
| `acl-firp` | COMP-01.2 | BC-01 → BC-06 | Novo (módulo) | N3 |
| `acl-gacd` + saga `ProcessoEnvioAssinatura` | COMP-01.3 | BC-01 → BC-07 | Novo (módulo) | N3 |
| `termo-documento`, `RenderizadorImpd`, `RenderizadorProprio` | COMP-01.4 | BC-02 → BC-09 | Novo (módulo); Plano B desligado | N3 |
| `acl-registro-contratos` | COMP-01.5 | BC-01 → BC-13 | Novo (módulo) | N3 |
| `convenio-produto` | COMP-01.6 | BC-04 (fronteira) | Inativo (quando ativo, abre a implantação e acompanha o status) | N3 |
| `atacado-adesao-receptor` (e seus componentes) | COMP-02 | BC-01 (borda de entrada; revalidação na FIRP no callback) | Novo | N2, N3 (4.2), Dinâmicos, Implantação |
| `atacado-adesao-acompanhamento` (e seus componentes) | COMP-03 | BC-03 | Novo | N2, N3 (4.2), Dinâmicos, Implantação |
| `atacado-adesao-db` | COMP-04 | BC-01, BC-02, BC-03 | Novo (provisionado) | N2, N3, Dinâmicos, Implantação |
| `atacado-adesao-staging` | COMP-05 | BC-02 | Novo (provisionado) | N2, N3, Dinâmico 5.1, Implantação |
| Salesforce / Artefatos Salesforce do Atacado | COMP-06 | BC-05 | Novo (configuração) | Todos |
| Akamai | COMP-07 | — | Corporativo consumido | N2, Implantação |
| Azure Application Gateway WAF v2 | COMP-08 | — | Corporativo consumido | N2, Implantação |
| Axway API Gateway | COMP-09 | — | Corporativo consumido | N2, N3, Implantação |
| ARO Atacado, namespace `atacado-core` (boundary / nó) | COMP-10 | — | Corporativo consumido | N2, Dinâmicos, Implantação |
| Azure Key Vault | COMP-11 | — | Corporativo consumido (cofre da solução) | N2, Implantação |
| vNet Hub / Azure Firewall (egress) | COMP-12 | — | Corporativo consumido | N2, N3 (4.2), Implantação |
| FIRP | COMP-13 | BC-06 | Corporativo consumido | N1, N2, N3, N3 (4.2), Dinâmicos, Implantação |
| GACD | COMP-14 | BC-07 | Corporativo consumido | N1, N2, N3, Dinâmicos, Implantação |
| GCC/Filenet | COMP-15 | BC-08 | Corporativo consumido (indireto) | N1, N2, Dinâmico 5.1, Implantação |
| IMPD `impd-srv-doc-generator` | COMP-16 | BC-09 | Corporativo consumido (Plano A condicionado) | N1, N2, N3, Dinâmico 5.1, Implantação |
| Emissor de token LEAP | COMP-17 | — | **[HIPÓTESE]** | N1, N2, Implantação |
| Canal Digital PJ | COMP-18 | BC-10 | Externo abstraído | N1, N2, Dinâmicos, Implantação |
| Databricks | COMP-20 | BC-11 | Sem integração nesta entrega | N1 |
| Sistema de Convênio | COMP-31 `atacado-convenio-produto` só na opção A; nas opções B/C, sistema externo | BC-04 (candidato BC-12 Open Cash Hub) | Indefinido / adiado | N1, N3 |
| Ingress privado, Secrets Store CSI Driver | Parte da COMP-10 | — | Corporativo consumido | Implantação |
| Gerente de Cash | — (ator) | BC-05 (usuário) | — | N1, N2, Dinâmicos |
| Cliente PJ Atacado | — (ator) | BC-10 (usuário) | — | N1, Dinâmicos |
| Backoffice de Cash | — (ator, ATR-09 do 02) | BC-04 (candidato a executor da implantação) | Indefinido (QA-CON-24) | N1 |

**Fora dos diagramas:** COMP-19 (Observabilidade corporativa, OTLP) foi omitido para legibilidade; o fluxo N-11 está no 04 §7.1. Os descartados COMP-21 a COMP-30 não aparecem, por definição.

---

## 8. Pontos de atenção registrados na modelagem

| # | Ponto | Tratamento no diagrama | Referência |
|---|---|---|---|
| 1 | Localização do Axway: o 04 v0.1 §7 o colocava fora do Hub ("zona de integração, a confirmar") | **Resolvido na Rodada 2:** 04, 04b e 04c usam "Hub (localização a confirmar — QA-TEC-09)" | QA-TEC-09 |
| 2 | FIRP, GACD, GCC/Filenet e LEAP: Azure ou on-premise | Nó "Ambiente corporativo" tracejado na Implantação | QA-TEC-09 |
| 3 | Rota ARO → IMPD | Relação tracejada; nó "Outra vNet Azure (IMPD)" tracejado | QA-TEC-01, RSK-01 |
| 4 | Autenticação LEAP | Rótulo "LEAP (hipótese)" em todas as relações via Axway; emissor tracejado | QA-TEC-03, RSK-05 |
| 5 | ~~Contrato da API de alerta com o Canal~~ — **Removido na rodada 6 (2026-10-16):** a revalidação passou ao Atacado; não há mais alerta do Canal | Relação e boundary "a combinar com Canais" retirados de c4-01, c4-02, c4-03b, c4-05 e c4-06 | QA-TEC-08 (encerrada), ADR-09 (substituída pela ADR-13) |
| 6 | Sistema de Convênio indefinido; executor da implantação a definir (Gerente de Cash ou backoffice) | Sistema e ator Backoffice de Cash tracejados; relações de implantação futuras; porta `convenio-produto` inativa, que só abre a implantação e acompanha o status | QA-CON-02, QA-CON-24, ADR-11, RSK-18 |
| 7 | Nome do Canal: o resumo usa "Canal Digital PJ"; 04/04a v0.1 usavam "Canal Digital do Cliente (Canal Digital PJ)" | **Resolvido na Rodada 2:** nome canônico "Canal Digital PJ" em todos os documentos ("Canal Digital do Cliente" só como sinônimo na primeira menção) | 01 §14 (glossário) |
| 8 | Nome do COMP-06: o resumo usa "Artefatos Salesforce"; 04/04a usam "Artefatos Salesforce do Atacado" | Diagramas usam o nome do 04/04a | 04a §3 |
| 9 | Revalidação depois da assinatura registrada no GACD (janela entre assinar e revalidar) e dependência do COMP-02 em relação à FIRP | c4-04 passos 18 a 22; c4-05 passos 5 a 8 (rótulo "protocolo assinado: QA-NEG-20" no passo 8) | QA-NEG-20, ADR-13, QA-CON-09 |
