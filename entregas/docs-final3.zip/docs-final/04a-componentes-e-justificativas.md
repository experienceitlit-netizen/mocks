# 04a — Componentes e Justificativas: Termo de Adesão Multiproduto (Cash Management / Payments)

> Complemento do `04-desenho-arquitetura-solucao.md`. Traz uma **ficha por componente**, inclusive os corporativos consumidos e os **descartados ou adiados** das orientações recebidas, além das matrizes **Componente × RF** e **Componente × RNF**.
> IDs (RF-xx, RNF-xx, ADR-xx, RSK-xx, QA-TEC-xx, PRM-TEC-xx) são os do 04. BC-xx, CAP-xx e APP-xx vêm do 02 e do 03. Esta lista é a **fonte** para os diagramas C4 (`04b-diagramas-c4.md`) e ArchiMate (`04c-diagramas-archimate.md`).

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 04a — Componentes e Justificativas |
| Versão | v0.6 |
| Data | 2026-10-16 |
| Status | Rascunho |
| Autor | Arquitetura de Soluções — Atacado (Cash Management / Payments) |
| Documento pai | `04-desenho-arquitetura-solucao.md` (v0.5) |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: fichas COMP-01..31 e matrizes Componente × RF e Componente × RNF |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: refinamentos do `05-especificacoes-tecnicas.md` §17 incorporados (Spring Data JDBC + `JdbcClient`; contrato OpenAPI em YAML como fonte; fila de tarefas interna e outbox com consumidor único; unicidade da inbox `(origem, chave_idempotencia)`; tabelas `produto_aderido`, `decisao_elegibilidade`, `tarefa` no modelo; egress do COMP-03 por NetworkPolicy + EgressFirewall do namespace, DT-20; CPF possivelmente exigido pelo GACD, QA-TEC-24); localização do Axway padronizada; nomes canônicos "Canal Digital PJ" e "Artefatos Salesforce do Atacado" |
| v0.3 | 2026-09-24 | Correção pós-entrega: nome residual `convenio-gateway` substituído por `convenio-produto` na tabela de rastreabilidade BC → componente |
| v0.4 | 2026-09-24 | Alerta de assinantes inválidos separado em duas L2 (02 v0.5): COMP-02 atende **CAP-09.5** Recepção de Sinais de Assinantes Inválidos (antes "CAP-09.2 (entrada do alerta)") e COMP-03 atende **CAP-09.2** Alertas ao Gerente (notificação no Salesforce). Fichas COMP-02, COMP-03 e COMP-18 e leitura da matriz Componente × RF atualizadas; COMP-18 explicita que a revalidação na FIRP precede a assinatura no GACD |
| v0.5 | 2026-09-27 | Convênio com **etapa de implantação e homologação** feita por pessoas (Gerente de Cash ou backoffice, a definir — QA-CON-24), alinhado ao 04 v0.4 (ADR-11, RSK-18) (`instrucoes-ajustes.md`, item 8). Ficha COMP-01.6: a porta, quando ativada, tende a **abrir uma pendência de implantação** visível no Salesforce e acompanhar o status (Em implantação → Convênio ativo), sem criar o convênio por API; COMP-20 passa a consumir o convênio **ativo** (EVN-10 Convênio ativado); tabela de componentes (COMP-01.6) ajustada |
| v0.6 | 2026-10-16 | Rodada 6, alinhado ao 04 v0.5 (ADR-13): o **COMP-02 passa a revalidar os assinantes na FIRP** no callback do GACD e atende **CAP-04.2** no lugar da CAP-09.5 (removida); sai a API de alerta do Canal (APP-02.6, endpoints `/v1/alertas/**`, política `atacado-adesao-alerta-canal`). COMP-18 Canal Digital PJ fica só com acesso ao termo e assinatura, sem revalidação e sem chamada ao Atacado **[FATO: CG]**. Fichas COMP-01, COMP-02, COMP-09, COMP-13, COMP-17 e COMP-18 e matrizes revisadas |

### 1.1 Legenda de status do componente

| Status | Significado |
|---|---|
| **Novo** | Construído (código) ou provisionado/configurado pelo Time do Atacado Cash Payments nesta iniciativa |
| **Novo (módulo)** | Parte interna de um deployable novo (componente no nível C4 "Component") |
| **Corporativo consumido** | Existente, de outro dono; a solução só consome ou configura rotas e políticas |
| **Externo abstraído** | Fora da responsabilidade do Atacado; só o contrato de integração é definido |
| **Descartado** | Avaliado e rejeitado (motivo registrado) |
| **Adiado** | Não construído agora; condição de ativação registrada |

### 1.2 Stack-padrão dos microsserviços novos (vale para COMP-01, COMP-02 e COMP-03)

| Item | Escolha | Justificativa |
|---|---|---|
| Linguagem / runtime | **Java 21 (LTS)**, virtual threads nas chamadas bloqueantes | RST-05 (Java prioritário); LTS; virtual threads simplificam I/O sem programação reativa |
| Framework | **Spring Boot 3.x** (Web MVC, Validation, Actuator, Security OAuth2 Resource Server/Client, Data JDBC + `JdbcClient` — refinado em 05 DT-04) | Padrão de mercado, suporte a OAuth2, observabilidade nativa |
| Persistência | PostgreSQL JDBC + **Flyway** (migrações só no COMP-01) | Um dono das migrações; expand/contract |
| Resiliência | **Resilience4j** (timeout, retry, circuit breaker, bulkhead) | ADR-12 |
| Agendamento e lock | Spring Scheduling + **ShedLock** (PostgreSQL) | Uma instância ativa no relay e nos jobs de saga |
| Observabilidade | **OpenTelemetry** (agente Java), **Micrometer/Prometheus**, logs JSON (Logback + encoder) | ADR-12, PRM-TEC-12 |
| Contratos | **OpenAPI 3.1 em YAML versionado** (contrato primeiro), publicado no Axway; **springdoc-openapi** só em teste, para detectar divergência entre código e contrato (refinado em 05 DT-03) | OHS/PL (R-01) |
| Fronteiras de módulo | **ArchUnit** ou **Spring Modulith** (verificação de dependências entre módulos) | 03 §8.2 (monólito modular com fronteiras explícitas) |
| Testes | JUnit 5, **Testcontainers** (PostgreSQL), WireMock (FIRP, GACD, IMPD, Salesforce), testes de contrato | Dependências sem ambiente de homologação garantido |
| Imagem | **UBI 9 OpenJDK 21** (Red Hat), usuário não root, SCC `restricted-v2` | ARO/OpenShift |
| Repositório | Um repositório multi-módulo Maven `atacado-adesao` → 3 imagens com a mesma versão | ADR-01, RSK-17 |

---

## 2. Visão geral dos componentes

| ID | Nome técnico | Tipo | Status | Hospedagem | BC | Interfaces principais |
|---|---|---|---|---|---|---|
| COMP-01 | `atacado-adesao-termo` | Microsserviço Java (monólito modular) | Novo | ARO Atacado, `atacado-core` | BC-01 (núcleo), BC-02 | Entrada: API Adesão v1 (REST, Salesforce via borda externa); saída: FIRP e GACD (REST via Axway), IMPD (REST), Blob, PostgreSQL |
| COMP-01.1 | `adesao-termo` (módulo) | Módulo de domínio + API | Novo (módulo) | dentro de COMP-01 | BC-01 | API Adesão; consumo da inbox; outbox; auditoria |
| COMP-01.2 | `acl-firp` (módulo) | Adaptador ACL | Novo (módulo) | dentro de COMP-01 | BC-01 → BC-06 | `ConsultaAssinantesPort` → REST FIRP via Axway |
| COMP-01.3 | `acl-gacd` (módulo) | Adaptador ACL + process manager (saga) | Novo (módulo) | dentro de COMP-01 | BC-01 → BC-07 | `AssinaturaDigitalPort` → 3 APIs GACD via Axway |
| COMP-01.4 | `termo-documento` (módulo) | Módulo BC-02 + porta `RenderizadorDocumento` (adaptador IMPD e adaptador próprio desligado) | Novo (módulo) | dentro de COMP-01 | BC-02 → BC-09 | `GerarDocumentoTermo` (in-process) → IMPD REST; Blob |
| COMP-01.5 | `acl-registro-contratos` (módulo) | Adaptador ACL (`ElegibilidadePort`) | Novo (módulo) | dentro de COMP-01 | BC-01 → BC-13 | Hoje: indicadores do Salesforce; futuro: fonte de contrato vigente |
| COMP-01.6 | `convenio-produto` (módulo) | Porta `SolicitacaoConvenioPort` desativada | Novo (módulo), **inativo** | dentro de COMP-01 | BC-04 (fronteira) | Nenhuma ativa; contrato `ConvenioSolicitado` (abertura da implantação, EVN-13) |
| COMP-02 | `atacado-adesao-receptor` | Microsserviço Java | Novo | ARO Atacado, `atacado-core` | BC-01 (borda) | Entrada: callback GACD (REST via Axway interno); saída: inbox no PostgreSQL e revalidação na FIRP (REST via Axway) |
| COMP-03 | `atacado-adesao-acompanhamento` | Microsserviço Java (worker) | Novo | ARO Atacado, `atacado-core` | BC-03 | Entrada: outbox (polling SQL); saída: Salesforce REST (upsert), PostgreSQL |
| COMP-04 | `atacado-adesao-db` | Azure Database for PostgreSQL Flexible Server | Novo (provisionado) | Spoke Plataformas Funcionais, acesso privado | BC-01, BC-02, BC-03 | SQL/TLS 5432 |
| COMP-05 | `atacado-adesao-staging` | Azure Blob Storage (container `termos-staging`) | Novo (provisionado) | Spoke, private endpoint | BC-02 | HTTPS (Blob REST / SDK) |
| COMP-06 | Artefatos Salesforce do Atacado | Configuração em SaaS | Novo (configuração) | Salesforce FSC | BC-05 | Saída: API Adesão (Named Credential); entrada: REST sObjects (upsert) |
| COMP-07 | Akamai | Borda / CDN / WAF | Corporativo consumido | Internet (borda) | — | HTTPS |
| COMP-08 | Azure Application Gateway (WAF v2) | Load balancer L7 + WAF | Corporativo consumido | vNet Hub | — | HTTPS |
| COMP-09 | Axway API Gateway | API Gateway | Corporativo consumido | Hub (localização a confirmar — QA-TEC-09) | — | HTTPS (políticas por consumidor) |
| COMP-10 | ARO Atacado (`atacado-core`) | Plataforma de contêineres (OpenShift) | Corporativo consumido | Spoke Plataformas Funcionais | — | — |
| COMP-11 | Azure Key Vault | Cofre de segredos | Corporativo consumido (cofre da solução) | Spoke, private endpoint | — | HTTPS (CSI Driver) |
| COMP-12 | vNet Hub — Azure Firewall / egress | Rede / segurança | Corporativo consumido | vNet Hub | — | HTTPS (egress) |
| COMP-13 | FIRP | Sistema corporativo | Corporativo consumido | Via Axway (localização a confirmar) | BC-06 | REST |
| COMP-14 | GACD | Sistema corporativo | Corporativo consumido | Via Axway ("Azure > ON") | BC-07 | REST (3 APIs) + callback |
| COMP-15 | GCC/Filenet | Repositório de conteúdo | Corporativo consumido (indireto) | Corporativo | BC-08 | Só via GACD |
| COMP-16 | IMPD API cloud `impd-srv-doc-generator` | Serviço estrutural de documentos | Corporativo consumido (Plano A, condicionado) | Azure (rota a confirmar) | BC-09 | REST, saída base64 |
| COMP-17 | Emissor de token LEAP | Serviço de identidade | Corporativo consumido **[HIPÓTESE]** | Corporativo | — | OAuth2/token |
| COMP-18 | Canal Digital PJ | Canal do cliente | Externo abstraído | Canais | BC-10 | Só com o GACD (pendências e registro da assinatura); nenhuma interface com o Atacado |
| COMP-19 | Observabilidade corporativa | Plataforma de logs, métricas e traces | Corporativo consumido | A confirmar | — | OTLP / Prometheus |
| COMP-20 | Databricks (Tarifas) | Plataforma de dados | Corporativo consumido (fora do escopo desta entrega) | Azure | BC-11 | Nenhuma nesta entrega |
| COMP-21 | `integrador-firp` (microsserviço dedicado) | Microsserviço | **Descartado** | — | — | Absorvido por COMP-01.2 |
| COMP-22 | `gerador-termo-pdf` (microsserviço dedicado) | Microsserviço | **Descartado** | — | — | Absorvido por COMP-01.4 |
| COMP-23 | `integrador-gacd` (microsserviço dedicado) | Microsserviço | **Descartado** | — | — | Absorvido por COMP-01.3 |
| COMP-24 | Callback que chama o Salesforce e grava a outbox no mesmo fluxo | Microsserviço | **Descartado** (ajustado) | — | — | Substituído por COMP-02 + COMP-01 + COMP-03 |
| COMP-25 | Azure Functions como relay da outbox | Serverless | **Descartado** | — | — | Relay no COMP-03 |
| COMP-26 | IMPD mainframe (legado) | Serviço legado | **Descartado** | — | — | — |
| COMP-27 | Geração de documento no Salesforce | SaaS | **Descartado** | — | — | — |
| COMP-28 | CDC Debezium / Kafka Connect para a outbox | Middleware | **Descartado** | — | — | Relay por polling |
| COMP-29 | Salesforce Private Connect | Conectividade privada | **Descartado** | — | — | Padrão Akamai → AppGW → Axway |
| COMP-30 | Platform Events como canal principal de entrega | Mensageria Salesforce | **Descartado** (mantido como alternativa) | — | — | Upsert REST |
| COMP-31 | `atacado-convenio-produto` | Microsserviço | **Adiado** (só na opção A) | ARO Atacado | BC-04 | Consumidor da outbox |

### 2.1 Correspondência com os nomes do 03

| 03 | 04 / 04a |
|---|---|
| DU-01 `adesao-termo` | COMP-01 `atacado-adesao-termo` + COMP-02 `atacado-adesao-receptor` |
| DU-02 `adesao-outbox-relay` | COMP-03 `atacado-adesao-acompanhamento` (BC-03 `adesao-acompanhamento`) |
| BC-02 `termo-documento` | COMP-01.4 (módulo) |
| BC-04 `convenio-produto` (antes `convenio-gateway` no 03) | COMP-01.6 (porta inativa); COMP-31 (adiado, opção A) |
| "PostgreSQL — schemas por BC + outbox" | COMP-04 `atacado-adesao-db` |

---

## 3. Componentes novos

### COMP-01 — `atacado-adesao-termo`

| Campo | Conteúdo |
|---|---|
| Tipo | Microsserviço Java 21 / Spring Boot 3 — monólito modular (módulos COMP-01.1 a COMP-01.6) |
| Status | Novo |
| BC / sub-blocos (02) | **BC-01** (APP-02.1, 02.2, 02.3, 02.7 e processamento de 02.4) + **BC-02** como módulo (APP-03, lado Atacado) |
| CAP atendidas | CAP-02.1*, 02.2*, 02.3, 03.1, 03.2, 03.3, 04.1 (consumo), 05.1..05.3 (consumo), 08.1, 10.1, 12.1 |
| Responsabilidade | Expor a **API Adesão v1** ao Salesforce; manter o agregado `AdesaoTermo` e suas invariantes (INV-01..INV-10); aplicar elegibilidade e tipo de termo; identificar assinantes (FIRP); gerar o documento; conduzir a **saga** do GACD (3 passos, retentativa, compensação, reconciliação); **consumir a inbox** (callback já revalidado pelo COMP-02) e aplicar INV-07/INV-08; gravar **outbox** e **trilha de auditoria** na mesma transação do estado; disparar as próprias etapas assíncronas pela **fila de tarefas interna** `adesao_termo.tarefa` (o COMP-01 **não** consome a própria outbox — refinado em 05 DT-05, §17 I-01); expor endpoints administrativos internos |
| Tecnologia | Stack-padrão (§1.2); Azure SDK for Java (`azure-storage-blob`, `azure-identity`); cliente OAuth2 (client credentials) com cache de token; Thymeleaf + OpenHTMLtoPDF só no adaptador do Plano B |
| Hospedagem / rede | ARO Atacado, namespace `atacado-core`; Deployment com 2 a 4 réplicas (HPA por CPU e latência); Service interno; exposto **só** pelo ingress privado atrás do Axway (política externa `atacado-adesao-sf`); egress liberado para Axway interno, IMPD, Blob (PE), PostgreSQL, Key Vault (CSI) |
| Interfaces de entrada | `POST /v1/adesoes`, `GET /v1/adesoes/{id}`, `GET /v1/adesoes/{id}/documento`, `POST /v1/adesoes/{id}/confirmacao-envio`, `/reemissao`, `/cancelamento` (REST/JSON, OpenAPI; §11.1 do 04); `/admin/v1/**` em listener separado sem Route; leitura da tabela `adesao_entrada.sinal_externo` (SQL) |
| Interfaces de saída | FIRP (REST via Axway); GACD `gacd-srv-coordenar-ass-sformatador`, `cgcc_conteudo_gacd/rest/v1/conteudo/armazenar`, `gacd-srv-coordenar-regra` (REST via Axway; nomes em QA-TEC-06); IMPD `impd-srv-doc-generator` (REST); Blob (HTTPS); PostgreSQL (SQL) |
| Dados manipulados | CNPJ, razão social, produtos (confidencial); assinantes: id FIRP, nome, papel (**dado pessoal**, mínimo); PDF (pessoal + confidencial, só em trânsito e no staging); `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia`; matrícula do Gerente (pessoal, auditoria) |
| Justificativa | Concentra num único deployable o que muda junto e precisa de **transação local**: agregado, saga, outbox e auditoria (03 §8.1). Um time, volume baixo, sem broker. Os módulos mantêm fronteiras de BC e permitem extração futura (03 §8.3) |
| Alternativas descartadas | Um microsserviço por etapa (COMP-21, 22, 23): serviços anêmicos, saga distribuída, 4 pipelines. Orquestração no Salesforce: limites de Apex e violação de PRI-02 (ADR-02) |
| RF atendidos | RF-01, RF-02, RF-03, RF-04, RF-05, RF-06, RF-07 (regra), RF-08 (regra), RF-10, RF-11, RF-12, RF-13, RF-14 |
| RNF atendidos | RNF-01, RNF-02, RNF-04, RNF-05, RNF-07, RNF-09, RNF-10, RNF-11, RNF-12, RNF-13, RNF-14, RNF-15, RNF-16 |
| Dono | Atacado Cash Payments |
| Questões / riscos | QA-TEC-01..06, QA-TEC-10, QA-TEC-11; RSK-01, 02, 04, 05, 07, 08, 12, 17 |

#### COMP-01.1 — módulo `adesao-termo` (BC-01)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Módulo de domínio + camada de API — Novo (módulo) |
| Responsabilidade | Agregado `AdesaoTermo`, `PoliticaElegibilidade`, `PoliticaTipoTermo`, repositório (índice único parcial por CNPJ não terminal → INV-01), comandos do 03 (`SolicitarTermoAdesao`, `ConfirmarAssinantes` refinado, `ReemitirTermo`, `EncerrarTermo`, `RegistrarConclusaoAssinatura`, `InvalidarAssinantes`), consumidor da inbox, gravação de outbox e auditoria |
| Interfaces | API Adesão v1 (entrada); portas `ConsultaAssinantesPort`, `AssinaturaDigitalPort`, `GeradorDocumentoPort` (in-process para COMP-01.4), `ElegibilidadePort`, `SolicitacaoConvenioPort` (saídas) |
| BC / CAP | BC-01; CAP-02.3, 03.1, 03.2, 10.1, 10.3 (processamento), 12.1 |
| RF / RNF | RF-01, 02, 05, 07, 08, 10, 11, 13, 14 / RNF-05, 10, 13 |
| Justificativa | Núcleo do core (SD-01); linguagem do 03 §3.2 preservada; nenhuma dependência de modelo externo (ACLs isolam FIRP e GACD) |

#### COMP-01.2 — módulo `acl-firp`

| Campo | Conteúdo |
|---|---|
| Tipo / status | Adaptador ACL — Novo (módulo) |
| Responsabilidade | Implementar `ConsultaAssinantesPort`: chamar a FIRP via Axway, traduzir Representante/Poder para `Assinante` (id FIRP, nome, papel), **descartar CPF e demais campos** não necessários, mapear erros (indisponível × sem assinantes, QA-DDD-12) |
| Interfaces | Saída: REST FIRP via Axway interno, token LEAP **[HIPÓTESE]**; entrada: chamada in-process |
| Tecnologia | Spring `RestClient` + Resilience4j (timeout 2 s/5 s, retry 3×, circuit breaker); contrato mockado com WireMock até QA-TEC-05 |
| Dados | Dados pessoais de representantes (minimizados na fronteira) |
| BC / CAP | BC-01 → BC-06 (R-04); CAP-04.1 |
| RF / RNF | RF-03 / RNF-01, RNF-04, RNF-09 |
| Justificativa | ACL pertence ao BC downstream (PRM-DDD-04). Microsserviço dedicado (COMP-21) não traria isolamento útil: mesmo time, mesma cadência, sem consumidores próprios |
| Riscos | RSK-07; QA-TEC-05; QA-DDD-04 (se o GACD resolver os assinantes, este módulo só serve para exibir e confirmar); **QA-TEC-24**: o GACD pode exigir a identificação dos assinantes (possivelmente CPF) no passo 1, horas ou dias depois da consulta. Refinado em 05 §17 I-08: a porta do GACD usa identificador opaco e a FIRP é reconsultada no passo 1, com o CPF só em memória |

#### COMP-01.3 — módulo `acl-gacd` (ACL + saga)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Adaptador ACL + process manager `ProcessoEnvioAssinatura` — Novo (módulo) |
| Responsabilidade | Executar Coordenar Contrato (com `callbackUrl` por adesão), Armazenar Prévia (lê o PDF do Blob, confere o hash, envia base64 com **usuário sistêmico**) e Coordenar Regra; persistir o estado de cada etapa em `saga_envio_assinatura`; retentativa imediata e agendada; tratar RESULTADO_INCERTO no passo 1; compensação (cancelamento do protocolo, se a API existir); abrir `reconciliacao_manual`; traduzir retornos em `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada` (internos) e `TermoEnviadoParaAssinatura` / `GeracaoDoTermoFalhou` |
| Interfaces | Saída: 3 APIs GACD via Axway (REST, token LEAP + usuário sistêmico); entrada: in-process e job agendado (ShedLock) |
| Dados | Assinantes (pessoal), PDF base64 (em trânsito), `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia` |
| BC / CAP | BC-01 → BC-07 (R-05); CAP-05.1, 05.2, 05.3 |
| RF / RNF | RF-06, RF-14 / RNF-01, 02, 05, 09, 13, 15 |
| Justificativa | A saga exige estado local e transação com o agregado. Um integrador GACD separado (COMP-23) moveria a saga para chamadas remotas, sem ganho. A ACL permite trocar o GACD pelo Open Cash Hub (PRI-13, R-20) |
| Riscos | RSK-03, RSK-04, RSK-05; QA-TEC-04, QA-TEC-06 |

#### COMP-01.4 — módulo `termo-documento` (BC-02)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Módulo BC-02 com porta `RenderizadorDocumento` e dois adaptadores — Novo (módulo) |
| Responsabilidade | Catálogo `modelo_termo` (tipo, versão, vigência, `referenciaTemplate`, aprovação); montar `DadosComposicao`; renderizar; calcular SHA-256; gravar o PDF no staging (COMP-05); servir a prévia |
| Adaptadores | **(a) `RenderizadorImpd`** — Plano A: REST para `impd-srv-doc-generator`, saída base64 **[FATO: 06]**; **(b) `RenderizadorProprio`** — Plano B, **desligado** por flag (`termo.renderizador=impd\|proprio`): Thymeleaf (HTML/CSS) + OpenHTMLtoPDF/PDFBox, PDF/A-2b, fontes embutidas, template versionado em Git com aprovação do Jurídico via PR |
| Interfaces | Entrada: `GerarDocumentoTermo` (in-process, R-09); saída: IMPD REST, Blob HTTPS |
| Dados | Dados da adesão e dos assinantes (pessoal); PDF |
| BC / CAP | BC-02 (R-09, R-10); CAP-03.3, CAP-08.1 |
| RF / RNF | RF-04, RF-05 (prévia), RF-11 / RNF-04, 07, 13, 14, 15 |
| Justificativa | Com IMPD, o BC-02 é catálogo + ACL e não justifica deployable (03 §3.3). A porta torna a decisão IMPD × geração própria reversível (ADR-03) |
| Alternativas descartadas | Microsserviço gerador dedicado (COMP-22); IMPD mainframe (COMP-26); Salesforce (COMP-27) |
| Riscos | RSK-01, RSK-02, RSK-08; QA-TEC-01, QA-TEC-02, QA-CON-19 |

#### COMP-01.5 — módulo `acl-registro-contratos`

| Campo | Conteúdo |
|---|---|
| Tipo / status | Adaptador ACL (`ElegibilidadePort`) — Novo (módulo) |
| Responsabilidade | Fornecer "possui contrato vigente" e "possui acesso ao Canal Digital" à política de domínio. **Hoje:** usa os indicadores enviados pelo Salesforce e audita a origem (PRM-TEC-10). **Futuro:** consulta BC-13 (Registro de Contratos) e a fonte de acesso ao Canal |
| BC / CAP | BC-01 → BC-13 (R-19); CAP-02.1, CAP-02.2 |
| RF / RNF | RF-02 / RNF-13 |
| Justificativa | Mantém a regra no core (proposta do 03, QA-DDD-10) sem bloquear o MVP pela falta de fonte (QA-CON-21) |

#### COMP-01.6 — módulo `convenio-produto` (inativo)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Porta `SolicitacaoConvenioPort` + contrato do evento `ConvenioSolicitado` — **inativo** (`convenio.gatilho.habilitado=false`) |
| Responsabilidade | Nenhuma em execução. Documenta o ponto de extensão: reagir a `AssinaturaConcluida` / `AdesaoDispensada` e **abrir a implantação** de cada produto (EVN-13). Quando ativada, tende a abrir uma **pendência de implantação** (tarefa para o Gerente ou o backoffice, visível no Salesforce) e acompanhar o status (Em implantação → Convênio ativo), e não a criar o convênio direto por API. O convênio é criado em teste, homologado com o cliente e ativado por pessoas no sistema do produto (RN-17) **[PREMISSA: PRM-CON-15 — padrão de mercado]** |
| BC / CAP | Fronteira do BC-04 (R-15); CAP-06.1, 06.2, 07.2 |
| RF / RNF | RF-12 / RNF-13 |
| Justificativa | ADR-11: sem sistema de registro definido (QA-CON-02), construir seria especulativo e arriscaria duplicar um sistema existente |
| Questões / riscos | QA-TEC-11; QA-CON-02, QA-CON-24, QA-CON-25; RSK-13, RSK-18 |
| Ativação | Opção B/C → implementar o adaptador (ACL) aqui; opção A → COMP-31; opção D → rejeitada. Em todas, a implantação tem executor humano (Gerente de Cash ou backoffice, QA-CON-24) |

### COMP-02 — `atacado-adesao-receptor`

| Campo | Conteúdo |
|---|---|
| Tipo | Microsserviço Java 21 / Spring Boot 3 (leve, sem regra de estado do termo) |
| Status | Novo |
| BC / sub-blocos (02) | **BC-01**, borda de entrada (ACL-Callback, com a revalidação na FIRP); APP-02.4. A APP-02.6 (API de alerta) foi removida na rodada 6 |
| CAP atendidas | CAP-05.5 (receptor), **CAP-04.2** (revalidação de assinantes na assinatura, no callback), CAP-10.3. A CAP-09.5 foi removida na rodada 6 |
| Responsabilidade | Receber o **callback do GACD**; conferir a identidade do chamador (claims propagados pelo Axway / certificado); validar o esquema; traduzir para `SinalExterno` canônico; gravar na **inbox** com chave de idempotência (`GACD + codigoProtocolo + tipoSinal`) em `AGUARDANDO_REVALIDACAO`; responder **ACK só depois do commit**, sem depender da FIRP. Em seguida, **revalidar os assinantes na FIRP** (RN-06, CAP-04.2): consultar a FIRP via Axway com o mesmo contrato de poderes do COMP-01, comparar os assinantes do callback com os poderes vigentes e gravar o resultado no sinal (`RECEBIDO`, válidos ou inválidos, com motivo e quantidade). Se a FIRP falhar, o sinal fica pendente e é revalidado de novo com backoff, sem descarte. **Sem regra de estado do termo**: a transição é do COMP-01 e a notificação ao Gerente, do COMP-03 (ADR-13) |
| Tecnologia | Stack-padrão (§1.2), sem Flyway (usa o schema criado pelo COMP-01); Resilience4j e cliente HTTP padronizado para a FIRP; sem dependência dos módulos de domínio (só do contrato da inbox e do cliente/tradutor FIRP compartilhado, sem regra de domínio) |
| Hospedagem / rede | ARO Atacado, `atacado-core`; 2 a 3 réplicas, PodDisruptionBudget (mínimo 1), anti-afinidade por zona; exposto **só** pelo ingress privado atrás do Axway interno (política `atacado-adesao-callback-gacd`); egress para PostgreSQL, Key Vault e **Axway interno (só a FIRP, N-12)** |
| Interfaces de entrada | `POST /v1/callbacks/gacd/assinaturas/{idAdesao}` (payload do GACD, QA-TEC-07; §11.2 do 04). Os endpoints `/v1/alertas/**` foram removidos na rodada 6 |
| Interfaces de saída | PostgreSQL (`INSERT … ON CONFLICT DO NOTHING` em `adesao_entrada.sinal_externo` e atualização só do resultado da revalidação); FIRP (REST via Axway interno, token de workload próprio; §11.3 do 04) |
| Dados manipulados | `codigoProtocolo`, CNPJ, identificação dos assinantes do callback, resultado da revalidação (motivo em enum e quantidade), hash do payload bruto. A resposta da FIRP (que pode trazer CPF) fica **só em memória** e é descartada após a comparação; nada de CPF ou nome no sinal, em logs ou eventos. O payload do GACD é guardado só como hash + campos traduzidos, salvo se a auditoria exigir o bruto (QA-TEC-17) |
| Justificativa | Separar a borda de entrada garante **disponibilidade ≥ 99,9%** e ACK rápido, independente de deploys, picos de memória (geração de PDF) ou falhas do núcleo, da FIRP e do Salesforce (RNF-08). O receptor já é o ponto de entrada do sinal de assinatura, por isso a revalidação fica nele e o núcleo não ganha chamada síncrona extra no consumo da inbox (ADR-13). Sem regra de estado aqui, o BC-01 não se divide logicamente (INV-07/08 ficam no COMP-01) |
| Alternativas descartadas | Callback que chama o Salesforce e grava a outbox (COMP-24: *dual write*, ACK dependente do SaaS); endpoints no próprio COMP-01 (acoplamento de disponibilidade); revalidação pelo Canal com API de alerta para o Atacado (ADR-09, substituída pela ADR-13); revalidação no COMP-01 ao consumir a inbox (ADR-13 b); revalidação antes do ACK (ACK dependente da FIRP) |
| RF atendidos | RF-07 (recepção), RF-08 (revalidação na FIRP e registro do resultado), RF-13 (registro do sinal), RF-14 (reprocessamento de sinal, apoio) |
| RNF atendidos | RNF-01, RNF-02, RNF-03, RNF-04, RNF-05, RNF-08, RNF-09, RNF-10, RNF-11 |
| Dono | Atacado Cash Payments |
| Questões / riscos | QA-TEC-05, QA-TEC-07, QA-TEC-09, QA-CON-09, QA-NEG-20; RSK-03, RSK-16, RSK-17, RSK-19, RSK-20 |

### COMP-03 — `atacado-adesao-acompanhamento`

| Campo | Conteúdo |
|---|---|
| Tipo | Microsserviço Java 21 / Spring Boot 3 (worker, sem API de negócio) |
| Status | Novo |
| BC / sub-blocos (02) | **BC-03** Acompanhamento da Jornada; APP-02.5 |
| CAP atendidas | CAP-09.1, CAP-09.2 (notificação de alertas ao Gerente no Salesforce), CAP-09.4 (dados), CAP-10.4, CAP-12.1 (projeção) |
| Responsabilidade | **Relay da outbox** (polling `FOR UPDATE SKIP LOCKED`, uma instância ativa via ShedLock, ordem por `idAdesao` + `versaoAgregado`); consumo idempotente por `idEvento` (`evento_consumido`); projeção `VisaoJornadaAdesao` e status da jornada (PRI-12); criação de `AlertaGerente` (ASSINANTES_INVALIDOS, FALHA_GERACAO) a partir dos eventos lidos da outbox (ex.: `AssinantesInvalidados`) e upsert em `Alerta_Adesao__c` — notificação ao Gerente, CAP-09.2; **entrega ao Salesforce** por upsert REST com OAuth 2.0 JWT Bearer; retentativa até 24 h; estacionamento e reentrega administrativa |
| Tecnologia | Stack-padrão (§1.2); cliente REST do Salesforce (Spring `RestClient`) com geração de JWT assinado (chave do Key Vault) e cache de token |
| Hospedagem / rede | ARO Atacado, `atacado-core`; 2 réplicas (1 ativa por lock, 1 em espera); **sem ingress de negócio**; egress **exclusivo** para o My Domain do Salesforce via Firewall do Hub, PostgreSQL e Key Vault. A exclusividade é garantida por **NetworkPolicy de egress no pod**; o EgressFirewall (allowlist de FQDN) vale para o namespace inteiro, e um **EgressIP** dedicado, se disponível, permite regra por IP de origem no Firewall (refinado em 05 DT-20, §17 I-07) |
| Interfaces de entrada | Leitura de `adesao_termo.outbox_evento` como **consumidor único** (SQL, role só com SELECT/UPDATE da coluna de consumo); `/admin/v1/entregas/{id}/reentregar` (listener interno) |
| Interfaces de saída | Salesforce REST: `PATCH /services/data/vXX.X/sobjects/Adesao_Termo__c/Id_Adesao__c/{idAdesao}`, `PATCH …/Alerta_Adesao__c/Id_Alerta__c/{idAlerta}`; `POST /services/oauth2/token` (JWT Bearer) |
| Dados manipulados | `idProposta`, `idAdesao`, estados, `codigoProtocolo`, alertas (sem dado pessoal); **resumo de assinantes** (nome e papel) entregue ao Salesforce só se a UI da prévia exigir (QA-TEC-15) |
| Justificativa | Isola a **credencial e o egress para a internet** (Salesforce) num pod sem entrada de negócio; isola limites de API e indisponibilidade do Salesforce do restante; materializa o BC-03 como contexto próprio (03 §3.4). O próprio 03 previa o relay como processo separado (DU-02) |
| Alternativas descartadas | Azure Functions como relay (COMP-25: outro runtime, VNet integration, sem ganho); CDC Debezium (COMP-28: exige Kafka); Platform Events como canal principal (COMP-30: risco de perda no subscriber); relay dentro do COMP-01 (a credencial do Salesforce ficaria no pod exposto à entrada) |
| RF atendidos | RF-09, RF-14 (reentrega); apoio: RF-07, RF-08 (alerta ao Gerente), RF-13 |
| RNF atendidos | RNF-01, RNF-02, RNF-03, RNF-05, RNF-06, RNF-09, RNF-10, RNF-11, RNF-16 |
| Dono | Atacado Cash Payments |
| Questões / riscos | QA-TEC-09, QA-TEC-15; RSK-09, RSK-11, RSK-14 |

### COMP-04 — `atacado-adesao-db`

| Campo | Conteúdo |
|---|---|
| Tipo | Azure Database for PostgreSQL **Flexible Server** (PostgreSQL 16) |
| Status | Novo (provisionado) — **fora do `stack-tech.md`** (PRM-TEC-01, QA-TEC-12) |
| BC | BC-01, BC-02, BC-03 (um schema por BC; futuro `convenio_produto`) |
| CAP atendidas | CAP-03.2, CAP-10.4, CAP-12.1 (APP-02.7) |
| Responsabilidade | Estado do agregado, saga, inbox, outbox, projeção da jornada, entregas, catálogo de modelos, trilha de auditoria, reconciliação manual |
| Tecnologia / configuração | Tier General Purpose (2 vCores iniciais, PRM-TEC-03); **HA com redundância de zona** (réplica síncrona); backup com PITR de 35 dias; TLS obrigatório; criptografia em repouso (chave gerenciada ou CMK, conforme política); roles por serviço e por schema; `pg_cron` ou job da aplicação para expurgo por retenção |
| Hospedagem / rede | Spoke Plataformas Funcionais, **acesso privado** (subnet delegada / VNet integration), sem endpoint público; DNS privado |
| Interfaces | SQL/TLS 5432: COMP-01 (dono das migrações, leitura e escrita em `adesao_termo`, `termo_documento`, leitura e atualização em `adesao_entrada`); COMP-02 (INSERT/SELECT em `adesao_entrada`); COMP-03 (SELECT/UPDATE de consumo em `adesao_termo.outbox_evento`; leitura e escrita em `adesao_acompanhamento`) |
| Dados | Dados pessoais mínimos de assinantes; matrícula do Gerente; dados empresariais; nenhum PDF (fica no Blob) |
| Justificativa | Transação local estado + outbox (PRI-05, INV-10) sem broker; volume baixo; recurso gerenciado com HA e PITR; aderente à orientação recebida (ADR-05) |
| Alternativas descartadas | Azure SQL (sem vantagem para o padrão; a orientação e PRM-CON-05 indicam PostgreSQL); Cosmos DB (transação multi-documento e modelo relacional com índice único parcial ficam mais complexos); banco dentro do ARO (operação de estado no cluster, sem necessidade) |
| RF | Apoio a RF-01, 05, 06, 07, 08, 09, 10, 12, 13, 14 |
| RNF | RNF-03, RNF-04, RNF-05, RNF-08, RNF-10, RNF-12 |
| Dono | Atacado Cash Payments (dados) / Plataformas Funcionais (provisionamento) |
| Questões / riscos | QA-TEC-12, QA-TEC-14, QA-TEC-17; RSK-10 |

**Modelo de dados (indicativo)**

```mermaid
erDiagram
  ADESAO_TERMO ||--|{ PRODUTO_ADERIDO : "adere"
  ADESAO_TERMO ||--o{ ASSINANTE : "lista"
  ADESAO_TERMO ||--o{ TAREFA : "agenda"
  ADESAO_TERMO ||--o{ PROTOCOLO_ASSINATURA : "historico"
  ADESAO_TERMO ||--o{ DOCUMENTO_TERMO : "gera"
  ADESAO_TERMO ||--o{ SAGA_ENVIO_ASSINATURA : "coordena"
  ADESAO_TERMO ||--o{ OUTBOX_EVENTO : "publica"
  ADESAO_TERMO ||--o{ TRILHA_AUDITORIA : "registra"
  MODELO_TERMO ||--o{ DOCUMENTO_TERMO : "versiona"
  SAGA_ENVIO_ASSINATURA ||--o{ RECONCILIACAO_MANUAL : "abre"
  VISAO_JORNADA ||--o{ ALERTA_GERENTE : "contem"
  VISAO_JORNADA ||--o{ ENTREGA_STATUS : "entrega"

  ADESAO_TERMO {
    uuid id_adesao PK
    string id_proposta
    string cnpj
    string tipo_termo
    string status
    int tentativas
    string matricula_solicitante
    bigint versao
  }
  PRODUTO_ADERIDO {
    uuid id_adesao FK
    string codigo_produto
  }
  DECISAO_ELEGIBILIDADE {
    uuid id_decisao PK
    string id_proposta
    string cnpj
    string decisao
  }
  TAREFA {
    uuid id PK
    uuid id_adesao FK
    string tipo
    string situacao
    timestamp proxima_execucao
  }
  ASSINANTE {
    uuid id PK
    uuid id_adesao FK
    string id_representante_firp
    string nome
    string papel
  }
  PROTOCOLO_ASSINATURA {
    string codigo_protocolo PK
    uuid id_adesao FK
    string id_previa
    string caminho_previa
    string situacao
  }
  DOCUMENTO_TERMO {
    uuid id PK
    uuid id_adesao FK
    string versao_modelo
    string hash_sha256
    string ref_blob
  }
  MODELO_TERMO {
    string id_modelo PK
    string tipo_termo
    string versao
    string referencia_template
    string status
  }
  SAGA_ENVIO_ASSINATURA {
    uuid id PK
    uuid id_adesao FK
    string etapa
    string estado
    int tentativas
    timestamp proxima_execucao
  }
  OUTBOX_EVENTO {
    uuid id_evento PK
    uuid id_agregado
    bigint versao_agregado
    string tipo_evento
    string correlation_id
    string chave_correlacao_negocio
    string situacao
  }
  SINAL_EXTERNO {
    uuid id PK
    string origem UK "UNIQUE (origem, chave_idempotencia)"
    string chave_idempotencia UK
    string codigo_protocolo
    string tipo_sinal
    string situacao "AGUARDANDO_REVALIDACAO, RECEBIDO..."
    string resultado_revalidacao "VALIDOS ou INVALIDOS"
  }
  TRILHA_AUDITORIA {
    uuid id PK
    uuid id_adesao
    string ator
    string acao
    string origem
    timestamp ocorrido_em
  }
  RECONCILIACAO_MANUAL {
    uuid id PK
    string codigo_protocolo
    string motivo
    string situacao
  }
  VISAO_JORNADA {
    string id_proposta PK
    uuid id_adesao
    string status_termo
    string status_jornada
    bigint ultima_versao
  }
  ALERTA_GERENTE {
    uuid id_alerta PK
    string id_proposta FK
    string tipo
    string situacao
  }
  ENTREGA_STATUS {
    uuid id PK
    string id_proposta FK
    int tentativas
    string situacao
  }
```

Schemas: `adesao_termo` (ADESAO_TERMO, PRODUTO_ADERIDO, DECISAO_ELEGIBILIDADE, TAREFA, ASSINANTE, PROTOCOLO_ASSINATURA, DOCUMENTO_TERMO, SAGA_ENVIO_ASSINATURA, OUTBOX_EVENTO, TRILHA_AUDITORIA, RECONCILIACAO_MANUAL); `termo_documento` (MODELO_TERMO); `adesao_entrada` (SINAL_EXTERNO — sem FK física para o agregado; a correlação por `codigo_protocolo` é resolvida pelo COMP-01); `adesao_acompanhamento` (VISAO_JORNADA, ALERTA_GERENTE, ENTREGA_STATUS, EVENTO_CONSUMIDO). As relações que cruzam schemas são lógicas (sem joins entre schemas). Refinado em `05-especificacoes-tecnicas.md` §6.2 e §17 (I-05, I-06, I-09): `PRODUTO_ADERIDO` materializa `produtos[]` do agregado; `DECISAO_ELEGIBILIDADE` registra a adesão dispensada, que não cria agregado (o `id_decisao` é o `Id_Adesao__c` do registro "Não requerido" no Salesforce); a unicidade da inbox é **composta** `(origem, chave_idempotencia)`, como no 04 §10; `TAREFA` é a fila interna do COMP-01 (DT-05). O modelo físico completo (DDL) está no 05 §6.2.

### COMP-05 — `atacado-adesao-staging`

| Campo | Conteúdo |
|---|---|
| Tipo | Azure Blob Storage (StorageV2, redundância de zona), container privado `termos-staging` |
| Status | Novo (provisionado) — fora do `stack-tech.md` (PRM-TEC-02, QA-TEC-12) |
| BC / CAP | BC-02; CAP-08.1 (apoio), CAP-12.1 (integridade por hash) |
| Responsabilidade | Guarda **transitória** do PDF entre geração, prévia do Gerente e envio ao GACD, inclusive nas retentativas da saga. **Não** é repositório oficial (o oficial é o GCC/Filenet via GACD) |
| Configuração | Private endpoint; acesso público desabilitado; chave compartilhada desabilitada quando houver identidade de workload (QA-TEC-14); criptografia em repouso (chave gerenciada ou CMK); **lifecycle: exclusão em 30 dias**; exclusão explícita pelo COMP-01 ao chegar a Assinado/Encerrado; soft delete de 7 dias; sem versionamento; caminho `{idAdesao}/{tentativa}/termo.pdf` |
| Interfaces | HTTPS (Blob REST via Azure SDK) só a partir do COMP-01 |
| Dados | PDF com dados pessoais (assinantes) e empresariais |
| Justificativa | Viabiliza a prévia (RF-05) e o reprocessamento com o **mesmo** documento auditado (hash), sem inchar o banco nem trafegar o PDF pelo Salesforce (ADR-04) |
| Alternativas descartadas | Sem staging (sem prévia, hash divergente em retentativas); PDF no Salesforce Files (documento passa pelo SaaS). **Plano B:** `bytea` no COMP-04 se o Blob não for aprovado |
| RF / RNF | RF-04, RF-05, RF-06, RF-11 (apoio) / RNF-03, RNF-04, RNF-14, RNF-15 |
| Dono | Atacado Cash Payments / Plataformas Funcionais (provisionamento) |
| Riscos | RSK-10, RSK-12 |

### COMP-06 — Artefatos Salesforce do Atacado

| Campo | Conteúdo |
|---|---|
| Tipo | Configuração e desenvolvimento em SaaS (Salesforce Financial Services Cloud) |
| Status | Novo (configuração) |
| BC / CAP | BC-05; CAP-01, CAP-09.1/09.2 (visualização), CAP-09.4 (relatórios) |
| Responsabilidade | UI da jornada do Gerente (LWC/Flow: solicitar, ver assinantes e prévia, confirmar, reemitir, cancelar); **Named Credential + External Credential** `Atacado_Adesao_API` (OAuth 2.0 client credentials + certificado de cliente mTLS) para chamar a API Adesão; **Connected App / External Client App** `atacado-adesao-acompanhamento` (JWT Bearer) + **usuário de integração** com permission set mínimo; objetos `Adesao_Termo__c` (External ID `Id_Adesao__c`, `Versao_Evento__c`) e `Alerta_Adesao__c` (External ID `Id_Alerta__c`); Flow de notificação ao Gerente (Custom Notification / tarefa); regra defensiva contra versão antiga |
| Interfaces | Saída: API Adesão v1 (HTTPS via Akamai → AppGW → Axway); entrada: REST sObjects (upsert) e OAuth token endpoint |
| Dados | Proposta (sistema de registro), projeção de status, alertas, resumo de assinantes (se exibido) |
| Justificativa | O Salesforce é o sistema de engajamento (PRM-NEG-02, PRM-CON-09): só dispara comandos e exibe a projeção; nenhuma regra de adesão em Apex (PRI-02, 03 §2.3 item 6) |
| Alternativas descartadas | Orquestração em Apex (ADR-02); geração de documento no Salesforce (COMP-27); Platform Events como canal principal (COMP-30) |
| RF / RNF | RF-01, RF-05, RF-09, RF-10, RF-11 (origem ou destino) / RNF-01, RNF-02, RNF-06 |
| Dono | Atacado Cash Payments (com Experiência para a UX) |
| Questões / riscos | QA-TEC-15; RSK-11, RSK-14 |

---

## 4. Componentes corporativos consumidos

### COMP-07 — Akamai

| Campo | Conteúdo |
|---|---|
| Tipo / status | Borda de entrada (CDN/WAF/mTLS) — Corporativo consumido |
| Papel | Porta de entrada do Salesforce (RST-04): terminação TLS/mTLS, WAF, proteção DDoS, allowlist dos IPs do Salesforce |
| Interfaces | Entrada HTTPS do Salesforce; saída HTTPS para o Application Gateway |
| Configuração da solução | Hostname da API Adesão; validação do certificado de cliente do Salesforce (se suportado na borda) ou repasse ao Axway; allowlist gerenciada |
| Justificativa | Padrão obrigatório para canal externo; Salesforce Private Connect não se aplica (COMP-29) |
| RF / RNF | RF-01, 05, 10, 11 (apoio) / RNF-01, RNF-03 |
| Dono | Plataformas Funcionais / Segurança |
| Riscos | RSK-14; QA-TEC-10 |

### COMP-08 — Azure Application Gateway (WAF v2)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Load balancer L7 + WAF — Corporativo consumido |
| Papel | Balanceamento e WAF entre o Akamai e o Axway (RST-04) |
| Configuração da solução | Listener e regra de roteamento para a API Adesão; limite de corpo compatível com as requisições (pequenas; a prévia é resposta) |
| RF / RNF | RF-01, 05, 10, 11 (apoio) / RNF-01, RNF-03, RNF-15 |
| Dono | Plataformas Funcionais |
| Riscos | RSK-08; QA-TEC-10 |

### COMP-09 — Axway API Gateway

| Campo | Conteúdo |
|---|---|
| Tipo / status | API Gateway corporativo — Corporativo consumido |
| Papel | **Entrada:** política externa `atacado-adesao-sf` (Salesforce: validação de token/mTLS, esquema, rate limit); política interna `atacado-adesao-callback-gacd` (a política `atacado-adesao-alerta-canal` foi removida na rodada 6). **Saída:** consumo de FIRP (pelo COMP-01 e pelo COMP-02, na revalidação do callback, cada um com seu client) e GACD (e do IMPD, se a rota exigir) com token de workload |
| Configuração da solução | Publicação dos OpenAPI (API Adesão, callback); roteamento para o ingress privado do ARO; propagação de `X-Correlation-ID` e `traceparent`; limites de payload |
| Justificativa | PRI-07, RST-03, RST-04 |
| RF / RNF | RF-01, 03, 05, 06, 07, 08, 10, 11 (apoio) / RNF-01, RNF-03, RNF-11, RNF-15 |
| Dono | Plataformas Funcionais |
| Riscos | RSK-05, RSK-08, RSK-09; QA-TEC-03, QA-TEC-09, QA-TEC-10 |

### COMP-10 — ARO Atacado (namespace `atacado-core`)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Azure Red Hat OpenShift — Corporativo consumido |
| Papel | Hospeda COMP-01, COMP-02 e COMP-03; ingress privado; NetworkPolicy, EgressFirewall, HPA, PDB; Secrets Store CSI Driver; monitoramento de workloads de usuário |
| Configuração da solução | Deployments, Services, Routes privadas, ServiceAccounts, quotas, NetworkPolicies, EgressFirewall, SecretProviderClass, ServiceMonitors |
| RF / RNF | Apoio a todos / RNF-03, RNF-08, RNF-12 |
| Dono | Plataformas Funcionais |
| Questões | QA-TEC-14, QA-TEC-16; PRM-TEC-08, PRM-TEC-09 |

### COMP-11 — Azure Key Vault

| Campo | Conteúdo |
|---|---|
| Tipo / status | Cofre de segredos — Corporativo consumido (cofre dedicado à solução, RBAC) |
| Papel | Credenciais LEAP, usuário sistêmico do GACD, chave privada JWT do Salesforce, credenciais de banco e Blob (se não houver identidade de workload), certificados |
| Interfaces | HTTPS via private endpoint; montagem por Secrets Store CSI Driver com rotação |
| Justificativa | RST-06, PRI-08, ADR-10 |
| RF / RNF | Apoio a RF-03, 06, 09 / RNF-02, RNF-03 |
| Dono | Atacado Cash Payments (conteúdo) / Segurança (política) |

### COMP-12 — vNet Hub (Azure Firewall / egress)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Rede e segurança do Hub — Corporativo consumido |
| Papel | Saída controlada do spoke para o Salesforce (allowlist de FQDN do My Domain) e demais destinos externos; inspeção e registro |
| RF / RNF | Apoio a RF-09 / RNF-03 |
| Dono | Plataformas Funcionais |
| Premissa / questões | PRM-TEC-06; QA-TEC-09; RSK-09, RSK-14 |

### COMP-13 — FIRP

| Campo | Conteúdo |
|---|---|
| Tipo / status | Sistema corporativo de Firmas e Poderes — Corporativo consumido (BC-06) |
| Papel | Fonte da verdade de representantes e poderes, consultada pelo COMP-01.2 (identificação dos assinantes) e pelo COMP-02 (revalidação no callback de assinatura, RN-06, CAP-04.2). O Canal não consulta a FIRP nesta jornada **[FATO: CG]** |
| Interfaces | REST via Axway (contrato não documentado) |
| Dados | Dados pessoais de representantes |
| RF / RNF | RF-03, RF-08 (fonte) / — |
| Dono | FIRP |
| Questões / riscos | QA-TEC-05, QA-DDD-04, QA-CON-09; RSK-07, RSK-20 |

### COMP-14 — GACD

| Campo | Conteúdo |
|---|---|
| Tipo / status | Serviço corporativo de Aceite Digital — Corporativo consumido (BC-07) |
| Papel | Coordenar Contrato (`codigoProtocolo`), Armazenar Prévia (GCC/Filenet, `IdPrevia`, `CaminhoPrevia`), Coordenar Regra; callback de conclusão; fonte da verdade da assinatura (PRM-DDD-02) |
| Interfaces | 3 APIs REST via Axway **[FATO: 04]**; callback HTTP para o COMP-02 |
| Dados | Termo, assinantes, protocolo |
| RF / RNF | RF-06, RF-07, RF-11 (fonte) / RNF-14 (evidência) |
| Dono | GACD |
| Questões / riscos | QA-TEC-04, 06, 07, 18; RSK-03, RSK-04 |

### COMP-15 — GCC/Filenet

| Campo | Conteúdo |
|---|---|
| Tipo / status | Repositório de conteúdo — Corporativo consumido **indiretamente** (BC-08) |
| Papel | Armazena a prévia e o termo (evidência de aceite, retenção) — só via GACD (R-07) |
| RF / RNF | RF-06, RF-11 (apoio) / RNF-14 |
| Dono | GACD (consumo) |
| Questões | QA-TEC-18, QA-NEG-17 |

### COMP-16 — IMPD API cloud `impd-srv-doc-generator`

| Campo | Conteúdo |
|---|---|
| Tipo / status | Serviço estrutural de formatação de documentos — Corporativo consumido (**Plano A condicionado**, ADR-03) |
| Papel | Renderizar o Termo a partir de template CSF Designer v21 e devolver base64 **[FATO: 05, 06]** |
| Interfaces | REST (Swagger não disponível no repositório); rota do ARO Atacado a confirmar |
| Dados | Dados de composição do termo (inclui nomes de assinantes) |
| Justificativa | Reuso corporativo (PRI-03), governança de template com esteira e RDM, saída no formato do GACD; análise completa no 04 §12 |
| RF / RNF | RF-04 (apoio) / RNF-13, RNF-14 |
| Dono | IMPD |
| Questões / riscos | QA-TEC-01, QA-TEC-02; RSK-01, RSK-02 |

### COMP-17 — Emissor de token LEAP **[HIPÓTESE]**

| Campo | Conteúdo |
|---|---|
| Tipo / status | Serviço de identidade corporativo — Corporativo consumido (hipótese, PRM-CON-03) |
| Papel | Emitir tokens de workload para chamadas via Axway (COMP-01 → FIRP/GACD; COMP-02 → FIRP; eventualmente Salesforce → API Adesão) |
| RF / RNF | Apoio a RF-01, 03, 06, 08 / RNF-01 |
| Dono | Segurança |
| Questões / riscos | QA-TEC-03; RSK-05 |

### COMP-18 — Canal Digital PJ

| Campo | Conteúdo |
|---|---|
| Tipo / status | Canal do cliente (BGS + PDPJ; futuro canal unificado) — **Externo abstraído** (BC-10) |
| Papel | Buscar pendências no GACD, **dar a opção de acessar o termo e assiná-lo** e registrar a assinatura no GACD; notificar o cliente. **Não** revalida assinantes na FIRP, não bloqueia a assinatura e não chama nenhuma API do Atacado **[FATO: CG]**. A revalidação é do COMP-02, no callback (ADR-13) |
| Interfaces | Só com o GACD (fora do escopo do Atacado); nenhuma interface com componentes do Atacado |
| RF / RNF | — (a assinatura registrada no GACD dispara o callback de RF-07) / — |
| Dono | Canais (com Experiência) |
| Questões / riscos | QA-CON-07; RSK-15. QA-TEC-08 e RSK-06 encerrados na rodada 6 |

### COMP-19 — Observabilidade corporativa

| Campo | Conteúdo |
|---|---|
| Tipo / status | Plataforma de logs, métricas e traces — Corporativo consumido (ferramenta a confirmar) |
| Papel | Receber OTLP e métricas Prometheus; painéis e alertas da §9.4 do 04 |
| RF / RNF | Apoio a RF-13 / RNF-10, RNF-11 |
| Dono | Plataformas Funcionais |
| Questões | QA-TEC-16; PRM-TEC-12 |

### COMP-20 — Databricks (Tarifas)

| Campo | Conteúdo |
|---|---|
| Tipo / status | Plataforma de dados — Corporativo consumido, **sem integração nesta entrega** |
| Papel | Pipeline existente de cadastro de tarifas; futuro consumidor do convênio **ativo** (EVN-10 Convênio ativado, após a homologação; R-16) e possível destino da trilha para KPIs (QA-TEC-17) |
| Dono | Atacado Cash Payments |
| Questões | QA-DDD-11, QA-TEC-11 |

---

## 5. Componentes descartados e adiados

| ID | Componente avaliado | Origem | Status | Motivo | Onde a responsabilidade ficou |
|---|---|---|---|---|---|
| COMP-21 | `integrador-firp` — microsserviço chamado pelo Salesforce para buscar assinantes | Orientação recebida | **Descartado** | ACL pertence ao BC-01 (PRM-DDD-04); serviço anêmico; se o Salesforce chamar direto, a orquestração se espalha pelo SaaS; não há consumidor próprio que justifique ciclo de vida separado | COMP-01.2 |
| COMP-22 | `gerador-termo-pdf` — microsserviço chamado pelo Salesforce que grava no staging | Orientação recebida | **Descartado** | BC-02 é fino (catálogo + ACL do IMPD, 03 §3.3); gerar fora do fluxo exigiria que o Salesforce coordenasse PDF e staging. **Gatilho de extração (03 §8.3):** cadência de release de templates própria no Plano B, ou outros documentos do Atacado | COMP-01.4 (+ COMP-05 aceito) |
| COMP-23 | `integrador-gacd` — microsserviço chamado pelo Salesforce que envia base64 + assinantes | Orientação recebida | **Descartado** | Saga dos 3 passos precisa de estado e transação locais com o agregado; o Salesforce não deve conter o PDF nem a compensação. **Gatilho de extração:** outros produtos do Atacado passarem a usar o GACD → serviço genérico `aceite-digital-atacado` (03 §8.3) | COMP-01.3 |
| COMP-24 | Microsserviço de callback que atualiza o Salesforce e grava a outbox | Orientação recebida | **Descartado (ajustado)** | *Dual write*: ACK ao GACD ficaria dependente do Salesforce; risco de perda ou duplicação. Mantido o **espírito** (callback fora do Salesforce + outbox) | COMP-02 (inbox) → COMP-01 (estado + outbox) → COMP-03 (entrega) |
| COMP-25 | Azure Functions como relay da outbox ou como receptor | Stack (item 11) | **Descartado** | Outro runtime e outra operação fora do ARO; exige VNet integration e plano Premium para alcançar PostgreSQL privado; nenhum ganho de escala no volume previsto. Reavaliar para tarefas de plataforma fora do ARO, se surgirem | COMP-03 |
| COMP-26 | IMPD via mainframe (legado) | Fonte [06] | **Descartado** | Legado; fluxo BCM; integração on-premise; o próprio IMPD recomenda a API cloud | COMP-16 (Plano A) / COMP-01.4 (Plano B) |
| COMP-27 | Geração do documento no Salesforce (ex.: OmniStudio Document Generation, Visualforce `renderAs=pdf`) | Alternativa avaliada | **Descartado** | Viola PRI-02 (documento jurídico no SaaS); PDF precisaria voltar ao banco pelo WAF; lock-in; nota 2,35 na matriz | COMP-01.4 |
| COMP-28 | CDC (Debezium / Kafka Connect) para publicar a outbox | Alternativa avaliada | **Descartado** | Exige Kafka e replicação lógica; volume de dezenas por hora; sem broker (QA-TEC-13) | Relay por polling no COMP-03 |
| COMP-29 | Salesforce Private Connect | Alternativa avaliada | **Descartado** | Baseado em AWS PrivateLink; não conecta a vNets Azure; fora do padrão RST-04 | COMP-07 → COMP-08 → COMP-09 |
| COMP-30 | Platform Events publicados pelo ARO como canal principal de status | Alternativa avaliada | **Descartado (alternativa futura)** | Sem retentativa garantida se o subscriber falhar; exige automação extra para materializar registros; upsert por External ID já é idempotente e persistente | COMP-03 (upsert REST) |
| COMP-31 | `atacado-convenio-produto` — microsserviço do BC-04 | 03 §4.3 opção A | **Adiado** | QA-CON-02 sem resposta; risco de duplicar sistema de registro. Ativação só se a opção A for escolhida | Porta COMP-01.6 (inativa) |

---

## 6. Matriz Componente × Requisito Funcional

Legenda: **P** = responsável principal; **A** = apoio ou dependência; vazio = não participa.

| Componente | RF-01 | RF-02 | RF-03 | RF-04 | RF-05 | RF-06 | RF-07 | RF-08 | RF-09 | RF-10 | RF-11 | RF-12 | RF-13 | RF-14 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| COMP-01 `atacado-adesao-termo` | P | P | P | P | P | P | P | P | A | P | P | P | P | P |
| COMP-01.1 `adesao-termo` | P | P |  |  | P |  | P | P | A | P | P | A | P | P |
| COMP-01.2 `acl-firp` |  |  | P |  |  |  |  |  |  |  |  |  |  |  |
| COMP-01.3 `acl-gacd` |  |  |  |  |  | P |  |  |  |  |  |  |  | P |
| COMP-01.4 `termo-documento` |  |  |  | P | P |  |  |  |  |  | P |  |  |  |
| COMP-01.5 `acl-registro-contratos` |  | P |  |  |  |  |  |  |  |  |  |  |  |  |
| COMP-01.6 `convenio-produto` (inativo) |  |  |  |  |  |  |  |  |  |  |  | P |  |  |
| COMP-02 `atacado-adesao-receptor` |  |  |  |  |  |  | P | P |  |  |  |  | A | A |
| COMP-03 `atacado-adesao-acompanhamento` |  |  |  |  |  |  | A | A | P |  |  |  | A | P |
| COMP-04 `atacado-adesao-db` | A |  |  |  | A | A | A | A | A | A |  | A | A | A |
| COMP-05 `atacado-adesao-staging` |  |  |  | A | A | A |  |  |  |  | A |  |  |  |
| COMP-06 Artefatos Salesforce do Atacado | P |  |  |  | P |  |  |  | P | P | A |  |  |  |
| COMP-07 Akamai | A |  |  |  | A |  |  |  |  | A | A |  |  |  |
| COMP-08 Application Gateway | A |  |  |  | A |  |  |  |  | A | A |  |  |  |
| COMP-09 Axway | A |  | A |  | A | A | A | A |  | A | A |  |  |  |
| COMP-10 ARO Atacado | A | A | A | A | A | A | A | A | A | A | A | A | A | A |
| COMP-11 Key Vault | A |  | A | A |  | A | A | A | A |  |  |  |  |  |
| COMP-12 Hub / Firewall |  |  |  |  |  |  |  |  | A |  |  |  |  |  |
| COMP-13 FIRP |  |  | A |  |  |  |  | A |  |  |  |  |  |  |
| COMP-14 GACD |  |  |  |  |  | A | A | A |  |  | A |  |  |  |
| COMP-15 GCC/Filenet |  |  |  |  |  | A |  |  |  |  | A |  |  |  |
| COMP-16 IMPD API cloud |  |  |  | A |  |  |  |  |  |  |  |  |  |  |
| COMP-17 Emissor LEAP | A |  | A |  |  | A |  | A |  |  |  |  |  |  |
| COMP-18 Canal Digital PJ |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| COMP-19 Observabilidade |  |  |  |  |  |  |  |  |  |  |  |  | A | A |
| COMP-20 Databricks |  |  |  |  |  |  |  |  |  |  |  | A |  |  |

Leitura: todo RF tem ao menos um responsável principal entre os componentes novos. RF-12 fica atendido só no nível de contrato (porta inativa), por decisão (ADR-11).

No tratamento de assinantes inválidos, **COMP-02 e COMP-03 não fazem o mesmo trabalho**: o COMP-02 é P em RF-08 pela **detecção** (CAP-04.2: recebe o callback, grava na inbox, responde o ACK, revalida na FIRP e grava o resultado no sinal, sem regra de estado do termo); o COMP-01 é P em RF-08 pela **regra de domínio** (INV-08, estado Assinantes inválidos); o COMP-03 é A em RF-08 e P em RF-09 pela **notificação ao Gerente** (CAP-09.2: lê `AssinantesInvalidados` da outbox, cria o `AlertaGerente` e faz o upsert em `Alerta_Adesao__c`, com retentativa). A FIRP é A em RF-08 como fonte da revalidação. O Canal Digital PJ não participa de RF-08 desde a rodada 6 (ADR-13).

---

## 7. Matriz Componente × Requisito Não Funcional

| Componente | RNF-01 | RNF-02 | RNF-03 | RNF-04 | RNF-05 | RNF-06 | RNF-07 | RNF-08 | RNF-09 | RNF-10 | RNF-11 | RNF-12 | RNF-13 | RNF-14 | RNF-15 | RNF-16 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| COMP-01 `atacado-adesao-termo` | P | P | A | P | P |  | P | A | P | P | P | P | P | P | P | P |
| COMP-02 `atacado-adesao-receptor` | P | P | A | P | P |  |  | P | P | P | P | A |  |  | A | A |
| COMP-03 `atacado-adesao-acompanhamento` | P | P | A | A | P | P |  | A | P | P | P | A |  |  |  | P |
| COMP-04 `atacado-adesao-db` |  | A | P | P | P |  |  | P |  | P |  | P |  |  |  |  |
| COMP-05 `atacado-adesao-staging` |  | A | P | P |  |  |  |  |  |  |  |  |  | P | P |  |
| COMP-06 Artefatos Salesforce do Atacado | P | P |  |  |  | P |  |  |  |  |  |  |  |  |  |  |
| COMP-07 Akamai | P |  | P |  |  |  |  |  |  |  |  |  |  |  | A |  |
| COMP-08 Application Gateway | A |  | P |  |  |  |  |  |  |  |  |  |  |  | A |  |
| COMP-09 Axway | P |  | P |  |  |  |  |  |  |  | A |  |  |  | P |  |
| COMP-10 ARO Atacado |  | A | P |  |  |  |  | P |  |  |  | P |  |  |  |  |
| COMP-11 Key Vault |  | P | A |  |  |  |  |  |  |  |  |  |  |  |  |  |
| COMP-12 Hub / Firewall |  |  | P |  |  |  |  |  |  |  |  |  |  |  |  |  |
| COMP-14 GACD |  |  |  |  |  |  |  |  |  |  |  |  |  | A |  |  |
| COMP-15 GCC/Filenet |  |  |  |  |  |  |  |  |  |  |  |  |  | A |  |  |
| COMP-16 IMPD API cloud |  |  |  |  |  |  |  |  |  |  |  |  | A | A |  |  |
| COMP-17 Emissor LEAP | P |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| COMP-19 Observabilidade |  |  |  |  |  |  |  |  |  | A | P |  |  |  |  |  |

Legenda dos RNF (04 §3.3): RNF-01 Segurança de integração · RNF-02 Segredos · RNF-03 Segmentação de rede · RNF-04 LGPD · RNF-05 Entrega confiável e idempotência · RNF-06 Latência de status · RNF-07 Desempenho da jornada · RNF-08 Disponibilidade e recuperação · RNF-09 Resiliência · RNF-10 Rastreabilidade · RNF-11 Observabilidade · RNF-12 Capacidade · RNF-13 Evolutividade · RNF-14 Conformidade documental · RNF-15 Limites de payload · RNF-16 Operabilidade.
