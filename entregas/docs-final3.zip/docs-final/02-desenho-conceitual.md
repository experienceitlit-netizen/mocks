# 02 — Desenho Conceitual: Termo de Adesão Multiproduto (Cash Management / Payments)

> Ponte entre o negócio e a arquitetura. Este documento descreve **todas as camadas** (estratégia, negócio, capacidades, aplicação e tecnologia/integração) da iniciativa de Aceite Digital Cash e é a **base do documento 03 (DDD)**.
> Os nomes de camadas, capacidades, processos, eventos, objetos e blocos de aplicação definidos aqui são **estáveis** e devem ser reutilizados, sem alteração, em todos os documentos seguintes.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 02 — Desenho Conceitual |
| Versão | v0.8 |
| Data | 2026-10-16 |
| Status | Rascunho |
| Autor | Arquitetura Corporativa — Atacado (Cash Management / Payments) |
| Documentos relacionados | `01-contexto-de-negocio.md` (negócio e estratégia), `03-*` (DDD — deriva deste documento) |
| Público | Time do Atacado Cash Payments, Time de Canais, Time de Experiência, Time do GACD, Arquitetura |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial |
| v0.2 | 2026-09-23 | Alinhamento de nomenclatura de capacidades (CAP-xx) e cruzamento de questões |
| v0.3 | 2026-09-24 | Consolidação Rodada 2: drivers DRV-01..05 alinhados ao 01 (mestre) e DRV-06 (reuso) acrescentado nos dois documentos; OE-04 com o texto do 01; regras RN1..RN5 substituídas pela numeração RN-xx do 01; nome canônico "Canal Digital PJ" (CAP-13 passa a "Gestão do Canal Digital PJ") |
| v0.4 | 2026-09-24 | Correção pós-entrega: opções do Convênio em DEC-CON-02 reordenadas para as letras canônicas A/B/C/D (A novo serviço, B legado + ACL, C Open Cash Hub, D Salesforce), iguais às do 03, 04 e 06 |
| v0.5 | 2026-09-24 | Alerta de assinantes inválidos separado em duas L2: **CAP-09.2 Alertas ao Gerente** redefinida como notificação de alertas ao Gerente no Salesforce (APP-02.5) e nova **CAP-09.5 Recepção de Sinais de Assinantes Inválidos** (APP-02.6, entrada do Canal via Axway interno, contrato a combinar). Revisados: mapa L1/L2 (§3.3), sub-blocos de APP-02 (§3.4.1), mapa de capacidades (§4.2), matriz capacidade × processo × sistema × time (§6), QA-CON-08 e insumos para o 03 (§9) |
| v0.6 | 2026-09-27 | Ordem das camadas alinhada ao ArchiMate (`instrucoes-ajustes.md`, item 6): **CAM-2 passa a ser a Camada de Capacidades e CAM-3 a Camada de Negócio** (antes o inverso), porque o processo de negócio realiza a capacidade. A seção de Capacidades passa a §3.2 e a de Negócio a §3.3 (subseções §3.3.1–§3.3.6). Revisados: tabela de camadas (§3, com nota da ordem e perguntas da CAM-3 e da CAM-4), §3.1.3, referências internas à antiga seção 3.2.6 e diagrama da visão em camadas (§4.1). Conteúdo das camadas inalterado |
| v0.7 | 2026-09-27 | Convênio com **etapa de implantação e homologação** (`instrucoes-ajustes.md`, item 8), executada pelo **Gerente de Cash ou pelo backoffice** (a definir — QA-CON-24), no lugar da geração automática na assinatura **[PREMISSA — padrão de mercado]**. Revisados: ATR-01 e nova **ATR-09 Backoffice de Cash**; PN-10 passa a **"Implantar produto e gerar Convênio"** (PN-10.1 a PN-10.4); EVN-10 passa a **"Convênio ativado"** e novo **EVN-13 "Implantação iniciada"**; OBJ-07 com os estados do convênio (em teste, ativo); RN-13 e nova RN-17 na referência de regras; status da jornada "Em implantação" e "Convênio ativo" (§3.3.6); APP-09 = sistema de cada produto; CAP-06.1 e CAP-07.1; visão em camadas (§4.1) e fluxo ponta a ponta (§4.3) com o executor e a homologação; matriz (§5); PRI-12; nota em DEC-CON-02 (a etapa de implantação existe em todas as opções); QA-CON-03 revista, novas **QA-CON-24** e **QA-CON-25**; PRM-CON-08 e PRM-CON-14 revistas e nova PRM-CON-15 |
| v0.8 | 2026-10-16 | Rodada 6: a revalidação dos assinantes na FIRP passa ao **domínio do Atacado** (APP-02.4, receptor do callback, `atacado-adesao-receptor`), no callback de assinatura do GACD; o Canal Digital PJ só dá a opção de acessar o termo e assiná-lo. **CAP-09.5** e **APP-02.6** removidas (não há mais API de alerta do Canal); CAP-04.2 passa ao Atacado; PN-07 e PN-08 renomeados; QA-CON-08 encerrada e QA-CON-09 revista. Revisados: escopo (§2), RN-06, ATR-05, APP-02, APP-07, nota das "duas metades" (§3.2), diagramas (§4.1–§4.4), matriz (§5), PRI-07, PRI-10, DEC-CON-06 e insumos para o 03 (§9). Consolidação: ordem do ACK alinhada ao 05 (DT-21) — o receptor grava o sinal na inbox, responde o ACK e só depois revalida na FIRP (§3.2, APP-02.4, §4.3); EVN-07 e EVN-08 passam a ser gerados em PN-08 (§3.3.3) |

### 1.1 Fontes

| ID | Fonte | Conteúdo usado |
|---|---|---|
| [01] | PRD Aceite Digital Cash — Resumo executivo e fluxo (v1.0, 07/05/2026, Rascunho) | Objetivo, escopo de responsabilidades, fluxo de processo parcial |
| [02] | PRD Aceite Digital Cash — Contexto (Canal Digital, GACD, Open Cash Hub) | Termo único multiproduto, tipos de termo, candidatos a gerenciador, convênio por produto |
| [03] | PRD Aceite Digital Cash — Problema, impacto e objetivos | Declaração do problema, impacto, metas/KPIs |
| [04] | Confluence GACD — Jornada de armazenamento da prévia do contrato | 3 chamadas ao GACD, callback, `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia`, GCC/Filenet |
| [05] | IMPD — Visão geral, objetivo, CSF | Gerador estrutural de documentos, saída base64, CSF Designer v21 |
| [06] | IMPD — Esteira de publicação e como usar | API cloud `impd-srv-doc-generator` na Azure, esteira, RDM, ambientes |
| [stack] | `stack-tech.md` | Stack corporativa (Salesforce, Azure, Java, ARO, Axway, App Gateway, Akamai, Key Vault, Azure Functions, Databricks) |
| [CG] | Contexto Geral informado pelo usuário (reuniões) | FIRP → GACD, callback na Azure, ARO Atacado `atacado-core`, Hub and Spoke, hipótese LEAP, Java |

### 1.2 Convenção de marcação

| Marca | Significado |
|---|---|
| **[FATO: xx]** | Afirmação suportada pela fonte `xx` (ou `CG`, reuniões) |
| **[PREMISSA: PRM-CON-xx]** | Suposição assumida para seguir com o desenho — precisa de validação (seção 8.2) |
| **[HIPÓTESE]** | Hipótese técnica ainda não confirmada por nenhuma fonte (ex.: token LEAP) |
| **[ABERTO: QA-CON-xx]** | Ponto dependente de resposta registrada em Questões em aberto (seção 8.1) |

---

## 2. Objetivo e escopo do desenho conceitual

### 2.1 Objetivo

Descrever, de forma independente de tecnologia detalhada, **o que** o banco precisa ser capaz de fazer para que o Gerente de Cash gere, acompanhe e conclua o **Termo de Adesão** multiproduto a partir do **Salesforce**, e para que, após a assinatura, seja aberta a **implantação** de cada produto, com os **Convênios** por produto homologados e ativados, que viabilizam o cadastro de **Tarifas** — incorporando as restrições de integração já conhecidas (Salesforce → ARO Atacado → Axway API Gateway → FIRP/GACD; callback na Azure).

### 2.2 Em escopo

- Jornada do Gerente de Cash no Salesforce: solicitar, acompanhar e receber o resultado do Termo de Adesão **[FATO: 01]**.
- Descoberta de assinantes/representantes com poderes na **FIRP** e envio ao **GACD** **[FATO: CG]**.
- Geração do Termo de Adesão em PDF (base64) e registro no GACD nas 3 etapas (Coordenar Contrato, Armazenar Prévia, Coordenar Regra) **[FATO: 04]**.
- Recebimento do **callback** do GACD fora do Salesforce, nos **Serviços de Integração do Atacado** no **ARO Atacado**, e atualização do Salesforce **[FATO: CG]**.
- **Revalidação dos assinantes na FIRP pelo domínio do Atacado** (receptor do callback, `atacado-adesao-receptor`) ao receber o callback de assinatura do GACD, antes de o termo ser dado como assinado (RN-06), e tratamento de assinantes inválidos com alerta ao Gerente **[FATO: CG]**.
- Posicionamento conceitual do **Convênio** (por produto) e do cadastro de **Tarifas** (Databricks) como consequência da assinatura **[FATO: 01, 02]**.

### 2.3 Fora de escopo

- **Canal Digital PJ** (BGS + PDPJ, futuro canal unificado): fica **abstraído** sob esse nome canônico (sinônimo aceito: "Canal Digital do Cliente"). Visualização do termo, assinatura e experiência do cliente são responsabilidade do **Time de Canais** e do **Time de Experiência** **[FATO: 01, CG]**. O Canal só dá a opção de acessar o termo e assiná-lo: não consulta a FIRP, não bloqueia a assinatura e não chama API do Atacado **[FATO: CG]**.
- Evolução interna do GACD, da FIRP e do GCC/Filenet (componentes corporativos consumidos, não alterados).
- Implementação do pipeline de tarifas no Databricks (processo já existente **[FATO: 01, 02]**).
- Escolha tecnológica detalhada (linguagem de cada serviço, banco, bibliotecas, topologia de deploy): tratada no Desenho de Arquitetura de Solução (documento 04).
- Definição de qual sistema gera o Convênio: apenas levantada como ponto de decisão (seção 7) **[ABERTO: QA-CON-02]**.

---

## 3. Visão em camadas

Nomes estáveis das camadas (reutilizar em todos os documentos, inclusive nas camadas ArchiMate do documento 04):

| ID | Camada | Pergunta que responde |
|---|---|---|
| **CAM-1** | **Camada de Estratégia** | Por que fazer e como medir? |
| **CAM-2** | **Camada de Capacidades** | O que o banco precisa ser capaz de fazer (estável no tempo)? |
| **CAM-3** | **Camada de Negócio** | Quem faz o quê, com quais processos, eventos e objetos, para realizar as capacidades? |
| **CAM-4** | **Camada de Aplicação** | Quais blocos lógicos de aplicação servem aos processos e realizam as capacidades? |
| **CAM-5** | **Camada de Tecnologia e Integração** | Onde rodam e como se conectam (rede, gateway, segurança)? |

> A ordem segue o ArchiMate: a capacidade (camada de Estratégia do ArchiMate) diz **o que** o banco precisa ser capaz de fazer e é realizada pelos processos de negócio, que dizem **como** isso acontece; as aplicações servem aos processos. Por isso Capacidades (CAM-2) vem antes de Negócio (CAM-3). Mapeamento completo em `04c-diagramas-archimate.md` §2.

### 3.1 CAM-1 — Camada de Estratégia

#### 3.1.1 Drivers

| ID | Driver | Evidência |
|---|---|---|
| DRV-01 | Contratação de produtos Cash bloqueada por dependência de termo manual | Termo hoje assinado manualmente, sem fluxo integrado ao Salesforce; cliente bloqueado até assinar **[FATO: 01, 03]** |
| DRV-02 | Falta de rastreabilidade e evidência de aceite | Meta de 100% de conformidade; processo atual sem rastreabilidade **[FATO: 03]** |
| DRV-03 | Tarifas negociadas não cadastradas por ausência de convênio | Tarifas não podem ser cadastradas sem convênio **[FATO: 01, 03]** |
| DRV-04 | Baixa visibilidade do gerente sobre o status da adesão | Meta de 100% dos Gerentes de Cash com status em tempo real indica ausência atual **[FATO: 03]** |
| DRV-05 | Fragmentação de canais (BGS sem GACD) | Roadmap BGS + PDPJ → canal único integrado ao GACD **[FATO: 02]** |
| DRV-06 | Reuso de componentes corporativos (GACD, FIRP, GCC/Filenet, IMPD, Databricks) em vez de soluções paralelas | GACD (com integração FIRP), GCC/Filenet, IMPD, Databricks já existem **[FATO: 02, 04, 06]** |

> Drivers com ID e texto idênticos aos do `01-contexto-de-negocio.md` §5.2 (documento mestre de estratégia). Até a v0.2, este documento usava outra redação e outra ordem para DRV-04/DRV-05; o DRV-06 veio daqui e foi acrescentado também ao 01.

#### 3.1.2 Objetivos estratégicos e KPIs

| ID | Objetivo | KPI | Meta | Origem |
|---|---|---|---|---|
| OE-01 | Digitalizar a geração de termos | KPI-01 — % de termos gerados via Salesforce | ≥ 90% em 6 meses | **[FATO: 03]** |
| OE-02 | Reduzir o tempo de ciclo de contratação | KPI-02 — Tempo médio entre negociação e assinatura | −50% vs. baseline (baseline não definido **[ABERTO: QA-CON-18]**) | **[FATO: 03]** |
| OE-03 | Aumentar a conversão de contratações | KPI-03 — % de termos gerados que são assinados | ≥ 80% | **[FATO: 03]** |
| OE-04 | Melhorar a visibilidade do Gerente de Cash | KPI-04 — % de Gerentes de Cash com status do termo em tempo real | 100% | **[FATO: 03]** |
| OE-05 | Garantir compliance | KPI-05 — % de termos em conformidade regulatória | 100% (requisitos não detalhados **[ABERTO: QA-CON-17]**) | **[FATO: 03]** |

#### 3.1.3 Capacidades estratégicas (diferenciadoras para os objetivos)

| Capacidade estratégica | Capacidades (CAM-2) | Objetivos suportados |
|---|---|---|
| Formalização digital da adesão na jornada comercial | CAP-02, CAP-03, CAP-05 | OE-01, OE-02, OE-03 |
| Visibilidade de ponta a ponta para o Gerente | CAP-09, CAP-12 | OE-04, OE-05 |
| Habilitação da receita pós-assinatura | CAP-06, CAP-07 | OE-02 |
| Integração segura e desacoplada Salesforce ↔ Banco | CAP-10, CAP-11 | Todos (habilitadora) |

### 3.2 CAM-2 — Camada de Capacidades

Mapa de capacidades L1/L2. "Provedor" é o sistema (bloco da CAM-4) que realiza a capacidade; "Time dono" é o responsável pela capacidade.

| ID L1 | Capacidade L1 | ID L2 | Capacidade L2 | Provedor (CAM-4) | Time dono | Situação |
|---|---|---|---|---|---|---|
| CAP-01 | Gestão de Relacionamento Comercial | CAP-01.1 | Gestão de Propostas e Pipeline | APP-01 Salesforce | Atacado Cash Payments | Existente |
| | | CAP-01.2 | Negociação e Aprovação de Tarifas | APP-01 Salesforce | Atacado Cash Payments | Existente |
| | | CAP-01.3 | Gestão de Carteira do Cliente PJ Atacado | APP-01 Salesforce | Atacado Cash Payments | Existente |
| CAP-02 | Gestão de Adesão a Produtos Cash | CAP-02.1 | Verificação de Contrato Vigente | APP-01 Salesforce + fonte a definir | Atacado Cash Payments | Nova **[ABERTO: QA-CON-21]** |
| | | CAP-02.2 | Determinação do Tipo de Termo | APP-01 Salesforce | Atacado Cash Payments | Nova |
| | | CAP-02.3 | Orquestração da Jornada de Adesão | APP-02 Serviços de Integração do Atacado | Atacado Cash Payments | Nova |
| CAP-03 | Gestão do Termo de Adesão | CAP-03.1 | Composição do Termo (dados e produtos) | APP-02 Serviços de Integração do Atacado | Atacado Cash Payments | Nova |
| | | CAP-03.2 | Controle de Ciclo de Vida e Status do Termo | APP-02 (estado de integração) + APP-01 (visão) | Atacado Cash Payments | Nova |
| | | CAP-03.3 | Gestão de Modelos do Termo (conteúdo jurídico e versões) | APP-03 Geração de Documento | Atacado Cash Payments | Nova **[ABERTO: QA-CON-19]** |
| CAP-04 | Gestão de Representantes e Poderes | CAP-04.1 | Consulta de Assinantes e Poderes | APP-04 FIRP (consumida por APP-02) | Dono da FIRP (fora dos 4 times) / consumo: Atacado Cash Payments | Reuso |
| | | CAP-04.2 | Revalidação de Assinantes na Assinatura (no callback de assinatura do GACD) | APP-02.4 (receptor do callback) → TEC-04 Axway → APP-04 FIRP | Atacado Cash Payments | Nova (Atacado) + reuso FIRP |
| | | CAP-04.3 | Regras de Assinatura (isolada/conjunta) | APP-04 FIRP / APP-05 GACD | A confirmar **[ABERTO: QA-CON-15]** | A confirmar |
| CAP-05 | Gestão de Assinatura Digital | CAP-05.1 | Coordenação de Contrato e Protocolo | APP-05 GACD | GACD | Reuso |
| | | CAP-05.2 | Armazenamento de Prévia | APP-05 GACD + APP-06 GCC/Filenet | GACD | Reuso |
| | | CAP-05.3 | Coordenação de Regras | APP-05 GACD | GACD | Reuso |
| | | CAP-05.4 | Coleta de Assinatura do Cliente | APP-07 Canal Digital PJ | Canais / Experiência | Reuso (PDPJ) / lacuna (BGS) |
| | | CAP-05.5 | Notificação de Conclusão de Assinatura (callback) | APP-05 GACD → APP-02 | GACD (emissor) / Atacado Cash Payments (receptor) | Nova (receptor) |
| CAP-06 | Gestão de Convênios | CAP-06.1 | Geração de Convênio por Produto (implantação, homologação com o cliente e ativação — executada por pessoas: ATR-01 ou ATR-09) | APP-09 Sistema de Convênio (sistema de cada produto; indefinido) | Indefinido **[ABERTO: QA-CON-02, QA-CON-24]** | Indefinida |
| | | CAP-06.2 | Registro e Consulta de Convênios | APP-09 Sistema de Convênio (indefinido) | Indefinido | Indefinida |
| CAP-07 | Gestão de Tarifas | CAP-07.1 | Cadastro de Tarifas Negociadas (após o convênio ativo) | APP-08 Databricks (Tarifas) | Atacado Cash Payments | Existente |
| | | CAP-07.2 | Vinculação Tarifa × Convênio | APP-08 + APP-09 | Indefinido | Indefinida |
| CAP-08 | Gestão Documental | CAP-08.1 | Renderização de Documento PDF (base64) | APP-03 Geração de Documento | Atacado Cash Payments (candidato IMPD: dono do IMPD) | Nova/Reuso **[ABERTO: DEC-CON-03]** |
| | | CAP-08.2 | Armazenamento e Retenção de Documentos | APP-06 GCC/Filenet (via GACD) | GACD | Reuso |
| CAP-09 | Notificação e Acompanhamento de Status | CAP-09.1 | Atualização de Status no Salesforce | APP-02 → APP-01 | Atacado Cash Payments | Nova |
| | | CAP-09.2 | Alertas ao Gerente — notificação de alertas ao Gerente no Salesforce (assinantes inválidos, falhas) | APP-02.5 → APP-01 | Atacado Cash Payments | Nova |
| | | CAP-09.3 | Notificação ao Cliente (pendência de assinatura) | A definir (APP-07 ou APP-01) | Canais / Experiência **[ABERTO: QA-CON-10]** | Indefinida |
| | | CAP-09.4 | Indicadores da Jornada (KPI-01 a KPI-05) | APP-01 Salesforce (+ dados de APP-02) | Atacado Cash Payments | Nova |
| | | CAP-09.5 | Recepção de Sinais de Assinantes Inválidos — **Removida na rodada 6 (2026-10-16):** a revalidação passou ao Atacado (CAP-04.2); não há mais alerta do Canal | — | — | Removida |
| CAP-10 | Integração e Exposição de APIs | CAP-10.1 | Mediação Salesforce ↔ Banco (camada anticorrupção) | APP-02 Serviços de Integração do Atacado | Atacado Cash Payments | Nova |
| | | CAP-10.2 | Exposição e Consumo de APIs Corporativas | TEC-04 Axway API Gateway | Dono do Axway (corporativo) | Reuso |
| | | CAP-10.3 | Recepção de Callbacks e Notificações Externas | APP-02 Serviços de Integração do Atacado | Atacado Cash Payments | Nova |
| | | CAP-10.4 | Entrega Confiável de Eventos (outbox) | APP-02 Serviços de Integração do Atacado | Atacado Cash Payments | Nova |
| CAP-11 | Segurança e Identidade de Integração | CAP-11.1 | Autenticação e Autorização de Integração (token LEAP **[HIPÓTESE]**, usuário sistêmico **[FATO: 04]**) | TEC-04 Axway + TEC-08 | Atacado Cash Payments + GACD | A confirmar **[ABERTO: QA-CON-14]** |
| | | CAP-11.2 | Gestão de Segredos e Certificados | TEC-07 Azure Key Vault | Atacado Cash Payments | Reuso |
| | | CAP-11.3 | Segmentação e Controle de Rede | TEC-02 Hub and Spoke | Plataforma Azure (corporativo) | Reuso |
| CAP-12 | Rastreabilidade, Auditoria e Conformidade | CAP-12.1 | Trilha de Auditoria Ponta a Ponta (correlação por `codigoProtocolo`) | APP-02 + APP-05 + APP-01 | Atacado Cash Payments | Nova |
| | | CAP-12.2 | Evidência de Aceite e Conformidade Regulatória | APP-05 GACD + APP-06 GCC/Filenet | GACD + Atacado Cash Payments | Reuso/A confirmar **[ABERTO: QA-CON-17]** |
| CAP-13 | Gestão do Canal Digital PJ (**externa**) | CAP-13.1 | Gestão de Pendências de Assinatura | APP-07 Canal Digital PJ (BGS/PDPJ) | Canais (Experiência na jornada) | Externa — fora do escopo de implementação do Atacado (PDPJ parcial; BGS lacuna **[ABERTO: QA-CON-07]**) |
| | | CAP-13.2 | Adesão ao Canal Digital (Termo de Adesão – Produtos + Canal) | APP-07 Canal Digital PJ (BGS/PDPJ) | Canais (Experiência na jornada) | Externa — fora do escopo de implementação do Atacado (processo atual não documentado **[ABERTO: QA-CON-11]**) |

> CAP-04.2 e CAP-09.2 são as **duas metades** do alerta de assinantes inválidos, realizadas por blocos diferentes. **CAP-04.2 (detecção):** ao receber o callback de assinatura do GACD, APP-02.4 autentica, valida e deduplica o callback, grava o sinal na inbox e responde o ACK ao GACD; depois do ACK, revalida os assinantes na FIRP (via Axway, com o mesmo contrato de consulta da APP-02.2) e grava no sinal o resultado — assinatura confirmada ou `AssinantesInvalidados` —, sem regra de estado do termo. O termo só é dado como assinado depois da revalidação. A revalidação acontece depois de a assinatura ser registrada no GACD, e não antes. **Entre as duas:** APP-02.1 aplica a regra de domínio e leva o Termo a "Assinado" ou a "Assinantes inválidos" (RN-06, RN-07). **CAP-09.2 (notificação):** APP-02.5 lê o evento `AssinantesInvalidados` da outbox, cria o alerta ao Gerente e o entrega no Salesforce (`Alerta_Adesao__c`), com retentativa. Até a v0.7 a detecção vinha do Canal (CAP-09.5, removida na rodada 6).
>
> CAP-12 foi adicionada à lista inicial porque KPI-05 (100% de conformidade) e o problema "processo sem rastreabilidade" **[FATO: 03]** exigem uma capacidade explícita, e não apenas implícita nas demais.
>
> CAP-13 é capacidade **externa**: provedor Canal Digital PJ (BGS/PDPJ), dono Time de Canais, com o Time de Experiência na jornada; fica **fora do escopo de implementação do Atacado** e aparece no mapa apenas para explicitar a dependência (alinhada ao `01-contexto-de-negocio.md`, seção 9).

### 3.3 CAM-3 — Camada de Negócio

#### 3.3.1 Atores e papéis

| ID | Ator | Papel no processo | Time | Origem |
|---|---|---|---|---|
| ATR-01 | Gerente de Cash | Conduz a jornada comercial, solicita e acompanha o Termo de Adesão no Salesforce; **pode executar a implantação** do produto (parâmetros, convênio em teste, homologação e ativação) **[ABERTO: QA-CON-24]** | Time do Atacado Cash Payments | **[FATO: 01, CG]**; implantação **[PREMISSA — padrão de mercado]** |
| ATR-02 | Cliente PJ Atacado | Empresa contratante sem contrato vigente | — | **[FATO: 01, 03]** |
| ATR-03 | Assinante/Representante | Pessoa com poder de assinatura pelo Cliente PJ Atacado; assina o termo no Canal Digital PJ | — | **[FATO: 02, CG]** |
| ATR-04 | Aprovador da Proposta | Aprova a proposta ("Envia para aprovação") | Não identificado **[ABERTO: QA-CON-23]** | **[FATO: 01]** |
| ATR-05 | Time de Canais | Dono do Canal Digital PJ (visualização do termo e assinatura) | Time de Canais | **[FATO: 01, CG]** |
| ATR-06 | Time de Experiência | Experiência do cliente na jornada de assinatura **[PREMISSA: PRM-CON-10]** | Time de Experiência | **[FATO: CG]** (envolvimento) |
| ATR-07 | Time do GACD | Dono do serviço corporativo de Aceite Digital | Time do GACD | **[FATO: 01, CG]** |
| ATR-08 | Time do Atacado Cash Payments | Dono da jornada do Gerente no Salesforce e dos Serviços de Integração do Atacado **[PREMISSA: PRM-CON-02]** | Time do Atacado Cash Payments | **[FATO: 01, CG]** |
| ATR-09 | Backoffice de Cash | **Candidato a executor da implantação** do produto (parâmetros com o cliente, convênio em teste no sistema do produto, homologação e ativação) e da manutenção posterior do convênio; se existir uma área de implantação de Cash, ela ocupa este papel **[ABERTO: QA-CON-24, QA-CON-25]** | Atacado Cash Payments (a confirmar) | **[PREMISSA — padrão de mercado]** (não vem das fontes) |

#### 3.3.2 Processos de negócio

| ID | Processo | Descrição | Ator principal | Situação |
|---|---|---|---|---|
| PN-01 | Negociar e aprovar Proposta | Proposta com tarifas negociadas e previamente aprovadas no pipeline do Salesforce | Gerente de Cash | Existente **[FATO: 01]** |
| PN-02 | Verificar elegibilidade e definir tipo de termo | Verificar contrato vigente (RN-02) e definir "Produtos" ou "Produtos + Canal" (RN-03) | Gerente de Cash | Novo **[FATO: 01, 02]** |
| PN-03 | Identificar assinantes | Consultar na FIRP os representantes com poderes do cliente | Serviços de Integração do Atacado | Novo **[FATO: CG]** |
| PN-04 | Gerar Termo de Adesão | Compor e renderizar o termo único multiproduto em PDF (base64) | Serviços de Integração do Atacado | Novo **[FATO: 04]** (base64) |
| PN-05 | Registrar termo para assinatura | Coordenar Contrato → Armazenar Prévia → Coordenar Regra no GACD | Serviços de Integração do Atacado | Novo **[FATO: 04]** |
| PN-06 | Disponibilizar termo e notificar o cliente | Termo aparece como pendência no Canal; e-mail ao cliente (dono indefinido) | Canal Digital PJ | Parcial **[FATO: 01, 02]** **[ABERTO: QA-CON-10]** |
| PN-07 | Acessar e assinar o termo | O Canal só dá a opção de acessar o termo e assiná-lo; a assinatura é registrada no GACD | Assinante/Representante (Canal Digital PJ) | Responsabilidade de Canais **[FATO: CG]** |
| PN-08 | Revalidar assinantes e tratar inválidos | Ao receber o callback de assinatura do GACD, o Atacado (APP-02.4) revalida os assinantes na FIRP (RN-06); se forem inválidos, o Termo vai para "Assinantes inválidos" e o Salesforce alerta o Gerente | Serviços de Integração do Atacado / Gerente de Cash | Novo **[FATO: CG]**; destino do termo já assinado **[ABERTO: QA-NEG-20 do 01]** |
| PN-09 | Confirmar assinatura e atualizar status | Callback do GACD recebido no ARO Atacado, assinantes confirmados na revalidação (PN-08) e status refletido no Salesforce | Serviços de Integração do Atacado | Novo **[FATO: 04, CG]** |
| PN-10 | Implantar produto e gerar Convênio | Um convênio por produto Cash aderido, criado na implantação aberta pelo termo assinado (EVN-08) ou pelo contrato vigente: **PN-10.1** definir parâmetros com o cliente (layout CNAB 240/400 ou API, canal de transmissão, contas, carteira) → **PN-10.2** criar o convênio em modo teste no sistema do produto → **PN-10.3** homologar com o cliente (remessa e retorno) → **PN-10.4** ativar o convênio | Gerente de Cash **ou** Backoffice de Cash (ATR-01 ou ATR-09, a definir); Cliente PJ Atacado na homologação | Novo, indefinido **[FATO: 01, 02]** (necessidade do convênio) **[PREMISSA — padrão de mercado]** (implantação e homologação) **[ABERTO: QA-CON-02, QA-CON-03, QA-CON-24]** |
| PN-11 | Cadastrar Tarifas | Cadastro das tarifas negociadas; depende do **convênio ativo** (EVN-10) | Databricks (pipeline) | Existente **[FATO: 01, 02]** |
| PN-12 | Acompanhar status e indicadores | Gerente acompanha status em tempo real; gestão acompanha KPIs | Gerente de Cash | Novo **[FATO: 03]** |

> Fluxo de negócio resumido: **PN-01 → PN-02 → (sem contrato vigente) PN-03 → PN-04 → PN-05 → PN-06 → PN-07 → PN-08 (revalidação no callback) → PN-09 → PN-10 → PN-11**. Quando os assinantes forem inválidos, o fluxo para em **PN-08**, que leva o Termo a "Assinantes inválidos" e alerta o Gerente para reemitir. Com contrato vigente, o fluxo vai de PN-02 direto para PN-10/PN-11 **[FATO: 01]** (ramo "SIM → Cadastra Tarifas"), com a ressalva da contradição da seção 3.3.6.

#### 3.3.3 Eventos de negócio

| ID | Evento | Gerado em | Consumidores conceituais |
|---|---|---|---|
| EVN-01 | Proposta aprovada | PN-01 | PN-02 |
| EVN-02 | Termo de Adesão solicitado | PN-02 | PN-03 |
| EVN-03 | Assinantes identificados | PN-03 | PN-04, PN-05 |
| EVN-04 | Termo de Adesão gerado | PN-04 | PN-05 |
| EVN-05 | Protocolo de assinatura emitido (`codigoProtocolo`) | PN-05 | PN-09, PN-12 |
| EVN-06 | Termo disponibilizado para assinatura | PN-05/PN-06 | Canal Digital PJ, PN-12 |
| EVN-07 | Assinantes invalidados (na revalidação do callback) | PN-08 | PN-02 (o Gerente, alertado no Salesforce, regulariza e reemite), PN-12 |
| EVN-08 | Termo de Adesão assinado | PN-08 (assinantes válidos na revalidação do callback, depois da assinatura em PN-07) | PN-09, PN-10 |
| EVN-09 | Status do termo atualizado no Salesforce | PN-09 | PN-12 |
| EVN-10 | Convênio ativado (por produto), após a homologação | PN-10 (PN-10.4) | PN-11, PN-12 |
| EVN-11 | Tarifas cadastradas | PN-11 | PN-12 |
| EVN-12 | Termo recusado / expirado / cancelado | GACD / Canal | PN-12 — **[HIPÓTESE]**: nenhum estado além de "assinatura concluída" é descrito nas fontes **[ABERTO: QA-CON-12]** |
| EVN-13 | Implantação iniciada (por produto) | PN-10 (aberta por EVN-08 ou pelo contrato vigente) | Executor da implantação (ATR-01 ou ATR-09), PN-12 **[PREMISSA — padrão de mercado]** |

#### 3.3.4 Objetos de negócio

| ID | Objeto | Definição | Sistema de registro (conceitual) | Origem |
|---|---|---|---|---|
| OBJ-01 | Proposta | Oferta comercial com produtos e tarifas negociadas e aprovadas | Salesforce | **[FATO: 01]** |
| OBJ-02 | Termo de Adesão | Termo de aceite digital **único e multiproduto** para todos os produtos Cash; tipos "Termo de Adesão – Produtos" e "Termo de Adesão – Produtos + Canal"; exigido só de quem não tem contrato vigente | Documento: GCC/Filenet (via GACD); status de assinatura: GACD; visão comercial: Salesforce **[PREMISSA: PRM-CON-09]** | **[FATO: 01, 02]** |
| OBJ-03 | Assinante/Representante | Pessoa que representa o Cliente PJ Atacado e assina o termo | FIRP | **[FATO: CG]** |
| OBJ-04 | Poder de assinatura | Poder/alçada do representante (isolado, conjunto — regras não documentadas) | FIRP | **[FATO: 02]** **[ABERTO: QA-CON-15]** |
| OBJ-05 | Protocolo de assinatura | Processo de assinatura no GACD identificado por `codigoProtocolo` | GACD | **[FATO: 04]** |
| OBJ-06 | Prévia do documento | PDF do termo armazenado no GCC/Filenet (`IdPrevia`, `CaminhoPrevia`) | GCC/Filenet | **[FATO: 04]** |
| OBJ-07 | Convênio | Registro **por produto**, criado na implantação após o termo, pré-requisito do cadastro de tarifas. Estados: **Em teste** (homologação com o cliente) → **Ativo** (RN-17) | Sistema de cada produto (APP-09); Salesforce mostra só número e status **[ABERTO: QA-CON-02]** | **[FATO: 01, 02]**; estados **[PREMISSA — padrão de mercado]** |
| OBJ-08 | Tarifa | Valor negociado por produto a ser cadastrado | Databricks (pipeline de cadastro) → sistemas de destino | **[FATO: 01]** |
| OBJ-09 | Produto Cash | Produto de Cash Management / Payments objeto da adesão | Não identificado (lista ausente) **[ABERTO: QA-CON-06]** | **[FATO: 02]** |
| OBJ-10 | Contrato vigente | Contrato de Cash existente que dispensa o termo (RN-02) | Não identificado **[ABERTO: QA-CON-21]** | **[FATO: 01, 02]** |

#### 3.3.5 Regras de negócio (referência)

Numeração e texto do `01-contexto-de-negocio.md` §8.1 (lista mestre RN-01..RN-17). Aqui aparecem só as regras que estruturam a camada de negócio.

| ID (01) | Regra | Origem |
|---|---|---|
| RN-01 | O Termo de Adesão é **único e multiproduto**: cobre todos os produtos Cash e resguarda o banco para utilização futura; não é por produto | **[FATO: 02]** |
| RN-02 | O Termo de Adesão é exigido **apenas** de clientes **sem contrato vigente** | **[FATO: 01, 02]** |
| RN-03 | Há dois tipos de termo: "Termo de Adesão – Produtos" (cliente já possui acesso ao Canal Digital) e "Termo de Adesão – Produtos + Canal" (cliente novo, adere ao canal e aos produtos) | **[FATO: 02]** |
| RN-05 | Os assinantes do termo são os representantes com poderes registrados na **FIRP** | **[FATO: 02, CG]** |
| RN-06 | O domínio do Atacado (COMP-02 `atacado-adesao-receptor`) deve **revalidar os assinantes na FIRP** ao receber o callback de assinatura do GACD, antes de o termo ser dado como assinado | **[FATO: CG]** |
| RN-11 | O Convênio é gerado **por produto** (cada produto Cash requer seu convênio) | **[FATO: 01, 02]** |
| RN-12 | O Convênio é **pré-requisito** para o cadastro das tarifas negociadas | **[FATO: 01, 02]** (contradição no diagrama — QA-CON-05) |
| RN-13 | A implantação do produto (e a geração do Convênio) só pode ser aberta após o termo assinado ou com contrato vigente comprovado; a assinatura abre a implantação, não cria o convênio | **[INFERÊNCIA]** (01) |
| RN-17 | O Convênio só fica **ativo** após a **homologação** com o cliente; antes disso fica em modo teste | **[PREMISSA — padrão de mercado]** (PRM-CON-15) |

> Até a v0.2 este documento numerava as regras como RN1..RN5, com sentidos diferentes dos da numeração do 01. Equivalência: RN1 → RN-01; RN2 → RN-03; RN3 → RN-02; RN4 → RN-11 + RN-12; RN5 → RN-05 + RN-06.

#### 3.3.6 Ciclo de vida conceitual do Termo de Adesão

Estados propostos para o objeto OBJ-02 (visão do Atacado). Somente "assinatura concluída" é descrito pelas fontes **[FATO: 04]**; os demais são **[PREMISSA: PRM-CON-13]**.

```mermaid
stateDiagram-v2
  state "Assinantes identificados" as AssinantesIdentificados
  state "Aguardando assinatura" as AguardandoAssinatura
  state "Assinantes inválidos" as AssinantesInvalidos
  state "Falha na geração" as FalhaNaGeracao
  state "Encerrado (recusado, expirado ou cancelado)" as Encerrado
  [*] --> Solicitado: EVN-02 Termo solicitado
  Solicitado --> AssinantesIdentificados: EVN-03
  AssinantesIdentificados --> Gerado: EVN-04
  Gerado --> AguardandoAssinatura: EVN-05 e EVN-06 protocolo emitido
  AguardandoAssinatura --> Assinado: EVN-08 callback do GACD
  AguardandoAssinatura --> AssinantesInvalidos: EVN-07 revalidação no callback
  AssinantesInvalidos --> Solicitado: Gerente regulariza e reemite
  AguardandoAssinatura --> Encerrado: EVN-12 recusado ou expirado ou cancelado
  Solicitado --> FalhaNaGeracao: erro FIRP ou documento ou GACD
  FalhaNaGeracao --> Solicitado: nova tentativa
  Assinado --> [*]
  Encerrado --> [*]
```

Estados canônicos do Termo (mesmos da seção 7.4 do `01-contexto-de-negocio.md`, PRM-NEG-16): **Solicitado**, **Assinantes identificados**, **Gerado**, **Aguardando assinatura**, **Assinantes inválidos**, **Assinado**, **Falha na geração** e **Encerrado** (recusado / expirado / cancelado). "Não requerido" (contrato vigente), "Em implantação" (convênio em teste e homologação com o cliente), "Convênio ativo" e "Tarifas cadastradas", estes três por produto, são status da **jornada de adesão** projetados no Salesforce (CAP-09.1), e não estados do Termo (PRI-12). Ficam entre "Assinado" e o fim da jornada, na ordem Assinado → Em implantação → Convênio ativo → Tarifas cadastradas **[PREMISSA — padrão de mercado]**.

> Contradição registrada: o diagrama do PRD mostra "Gera convênio" **depois** do cadastro de tarifas, enquanto o texto diz que o convênio é **pré-requisito** das tarifas **[FATO: 01]**. Este desenho adota o texto (convênio antes das tarifas) **[PREMISSA: PRM-CON-08]** **[ABERTO: QA-CON-05]**.

### 3.4 CAM-4 — Camada de Aplicação (conceitual)

Blocos lógicos, sem escolha de tecnologia detalhada. Os nomes abaixo são os **nomes canônicos de blocos de aplicação**.

| ID | Bloco de aplicação | Responsabilidade conceitual | Tipo | Time | Origem |
|---|---|---|---|---|---|
| APP-01 | **Salesforce** (Salesforce Financial Services Cloud) | Jornada do Gerente de Cash: Proposta, solicitação do termo, visão de status, alertas, indicadores | Existente (SaaS) | Atacado Cash Payments | **[FATO: 01, stack]** |
| APP-02 | **Serviços de Integração do Atacado** (no ARO Atacado) | Camada anticorrupção entre Salesforce e componentes do banco: orquestração da adesão, integração FIRP, integração GACD, recepção do callback com revalidação dos assinantes na FIRP, entrega de status ao Salesforce (outbox) | Novo | Atacado Cash Payments **[PREMISSA: PRM-CON-02]** | **[FATO: CG]** |
| APP-03 | **Geração de Documento** | Renderizar o Termo de Adesão (2 tipos) em PDF base64 a partir de modelo | Novo ou reuso (IMPD candidato) | Atacado Cash Payments | **[FATO: 04, 05, 06]** |
| APP-04 | **FIRP** | Fonte de assinantes/representantes e poderes | Existente (corporativo) | Dono da FIRP | **[FATO: 02, CG]** |
| APP-05 | **GACD** | Aceite Digital: coordenação do contrato, prévia, regras, protocolo e callback | Existente (corporativo) | Time do GACD | **[FATO: 02, 04]** |
| APP-06 | **GCC/Filenet** | Repositório de conteúdo onde o GACD armazena a prévia | Existente (corporativo) | Time do GACD (consumo) | **[FATO: 04]** |
| APP-07 | **Canal Digital PJ** (abstraído) | Pendências de assinatura, acesso ao termo e assinatura (sem revalidação na FIRP) | Existente (PDPJ integra GACD; BGS não) | Canais / Experiência | **[FATO: 02, CG]** |
| APP-08 | **Databricks (Tarifas)** | Pipeline existente de cadastro de tarifas | Existente | Atacado Cash Payments **[PREMISSA: PRM-CON-14]** | **[FATO: 01, 02]** |
| APP-09 | **Sistema de Convênio (indefinido)** | Sistema de cada produto Cash, onde o convênio é criado em teste, homologado e ativado pelo executor da implantação (ATR-01 ou ATR-09) e registrado; o Salesforce mostra só número e status | Indefinido (Open Cash Hub possui processo) | Indefinido | **[FATO: 02]** **[PREMISSA — padrão de mercado]** **[ABERTO: QA-CON-02, QA-CON-24]** |
| APP-10 | **Open Cash Hub** | Canal para ERPs com módulo de termos e convênios — **alternativa** a APP-05 e candidato a APP-09 | Existente (alternativa) | Não identificado | **[FATO: 02]** |

#### 3.4.1 Sub-blocos lógicos de APP-02 (Serviços de Integração do Atacado)

Decomposição **lógica** (não implica um microsserviço por sub-bloco; o recorte físico é decisão do documento 04).

| ID | Sub-bloco | Responsabilidade | Capacidades |
|---|---|---|---|
| APP-02.1 | Orquestração da Adesão | Receber a solicitação do Salesforce e conduzir PN-03 → PN-05; manter estado de integração | CAP-02.3, CAP-03.1, CAP-03.2 |
| APP-02.2 | Integração FIRP (Consulta de Assinantes) | Consultar assinantes/poderes e traduzir para o modelo do Atacado | CAP-04.1, CAP-10.1 |
| APP-02.3 | Integração GACD (Coordenação de Assinatura) | Executar as 3 chamadas (Coordenar Contrato, Armazenar Prévia, Coordenar Regra) | CAP-05.1–05.3, CAP-10.1 |
| APP-02.4 | Recepção de Callback de Assinatura | Endpoint informado ao GACD no passo 1; autenticar, validar e deduplicar o callback; gravar o sinal na inbox, de forma idempotente, e responder o ACK ao GACD; depois do ACK, **revalidar os assinantes na FIRP** (via Axway, mesmo contrato de consulta da APP-02.2) e gravar no sinal o resultado (assinatura confirmada ou `AssinantesInvalidados`), sem regra de estado do termo (RN-06). Se a FIRP falhar, o sinal fica pendente de revalidação e é reprocessado com retentativa, sem descarte | CAP-05.5, CAP-04.2, CAP-10.3 |
| APP-02.5 | Entrega de Status ao Salesforce (outbox) | Publicar no Salesforce, com consistência eventual e retentativa, as mudanças de status e os alertas ao Gerente (ex.: `AssinantesInvalidados` → alerta) | CAP-09.1, CAP-09.2, CAP-10.4 |
| APP-02.6 | API de Alerta de Assinantes Inválidos — **Removida na rodada 6 (2026-10-16):** a revalidação passou ao Atacado, no receptor do callback (APP-02.4); não há mais alerta do Canal | — | — |
| APP-02.7 | Repositório de Estado e Outbox | Estado de integração do termo, correlação (`codigoProtocolo`) e outbox **[PREMISSA: PRM-CON-05]** | CAP-10.4, CAP-12.1 |

### 3.5 CAM-5 — Camada de Tecnologia e Integração (conceitual)

| ID | Elemento | Papel conceitual | Origem |
|---|---|---|---|
| TEC-01 | Azure Cloud | Nuvem onde residem ARO Atacado e serviços de apoio | **[FATO: stack, CG]** |
| TEC-02 | Hub and Spoke | Topologia de rede: vNet Hub (entrada/saída compartilhada) e vNets spoke por domínio | **[FATO: CG]** |
| TEC-03 | ARO Atacado (namespace `atacado-core`) | Azure RedHat OpenShift do Atacado, no domínio **Plataformas Funcionais**, vNet spoke própria; hospeda APP-02 | **[FATO: CG, stack]** |
| TEC-04 | Axway API Gateway | Exposição das APIs de FIRP e GACD; padrão de entrada Akamai → Load balance → Axway → Microsserviços | **[FATO: CG, stack]** |
| TEC-05 | Akamai | Porta de entrada para canais externos | **[FATO: stack]** |
| TEC-06 | Azure Application Gateway | Load balance na entrada | **[FATO: stack]** |
| TEC-07 | Azure Key Vault | Segredos, credenciais sistêmicas e certificados | **[FATO: stack]** |
| TEC-08 | Token LEAP | Autenticação padrão do banco nas APIs via Axway | **[HIPÓTESE]** **[PREMISSA: PRM-CON-03]** |
| TEC-09 | Azure Functions | Disponível na stack; sem papel previsto neste desenho conceitual | **[FATO: stack]** |
| TEC-10 | Banco relacional para estado/outbox | PostgreSQL gerenciado (Azure Database for PostgreSQL Flexible Server) — **não consta** do `stack-tech.md` | **[PREMISSA: PRM-CON-05]** |
| TEC-11 | Databricks | Plataforma analítica/ETL onde roda o cadastro de tarifas | **[FATO: stack, 01]** |
| TEC-12 | IMPD API Cloud (`impd-srv-doc-generator`) | Candidato a APP-03, "disponível na Azure"; mainframe é legado | **[FATO: 06]** |

Observações factuais relevantes:

- O diagrama ArchiMate do GACD o posiciona em "Azure > ON" — localização (Azure vs. on-premise) **ambígua** **[FATO: 04]** **[ABERTO: QA-CON-13]**.
- O `stack-tech.md` não cita firewall/egress no Hub; qualquer controle de saída desenhado é **[PREMISSA: PRM-CON-11]**.
- Hipótese inicial de "IMPD só on-premise" é **parcialmente contraditada**: existe API cloud na Azure **[FATO: 06]**; conectividade ARO Atacado ↔ IMPD não confirmada.

---

## 4. Diagramas

### 4.1 (a) Visão em camadas

```mermaid
flowchart TB
  subgraph CAM1["CAM-1 Camada de Estratégia"]
    direction LR
    DRV["Drivers<br/>DRV-01 Contratação bloqueada<br/>DRV-02 Rastreabilidade<br/>DRV-03 Tarifas sem convênio<br/>DRV-04 Visibilidade do gerente<br/>DRV-05 Canais fragmentados<br/>DRV-06 Reuso corporativo"]
    OE["Objetivos<br/>OE-01 a OE-05"]
    KPI["KPIs<br/>KPI-01 90% via Salesforce<br/>KPI-02 -50% ciclo<br/>KPI-03 80% conversão<br/>KPI-04 100% status<br/>KPI-05 100% compliance"]
    DRV --> OE --> KPI
  end

  subgraph CAM2["CAM-2 Camada de Capacidades"]
    direction LR
    CN["Núcleo da adesão<br/>CAP-02 Adesão<br/>CAP-03 Termo<br/>CAP-05 Assinatura"]
    CP["Suporte<br/>CAP-01 Relacionamento<br/>CAP-04 Representantes<br/>CAP-06 Convênios<br/>CAP-07 Tarifas<br/>CAP-08 Documental<br/>CAP-09 Status"]
    CT["Transversais<br/>CAP-10 Integração<br/>CAP-11 Segurança<br/>CAP-12 Rastreabilidade"]
    CE["Externa (Canais)<br/>CAP-13 Canal Digital PJ"]
  end

  subgraph CAM3["CAM-3 Camada de Negócio"]
    direction LR
    ATR["Atores<br/>Gerente de Cash<br/>Cliente PJ Atacado<br/>Assinante/Representante<br/>Backoffice de Cash"]
    PRC["Processos<br/>PN-01 a PN-12"]
    EVN["Eventos<br/>EVN-01 a EVN-13"]
    OBJ["Objetos<br/>Proposta, Termo de Adesão,<br/>Assinante, Poder de assinatura,<br/>Protocolo, Convênio, Tarifa"]
    ATR --> PRC --> EVN
    PRC --> OBJ
  end

  subgraph CAM4["CAM-4 Camada de Aplicação"]
    direction LR
    A01["APP-01 Salesforce"]
    A02["APP-02 Serviços de Integração<br/>do Atacado"]
    A03["APP-03 Geração de Documento"]
    A04["APP-04 FIRP"]
    A05["APP-05 GACD"]
    A06["APP-06 GCC/Filenet"]
    A07["APP-07 Canal Digital PJ<br/>(abstraído)"]
    A08["APP-08 Databricks (Tarifas)"]
    A09["APP-09 Sistema de Convênio<br/>(indefinido)"]
    A01 --> A02
    A02 --> A03
    A02 --> A04
    A02 --> A05
    A05 --> A06
    A07 --> A05
    A05 -. callback .-> A02
    A02 -. status .-> A01
    A01 -. abre implantação (executor a definir) .-> A09
    A09 -. convênio ativo .-> A08
  end

  subgraph CAM5["CAM-5 Camada de Tecnologia e Integração"]
    direction LR
    T1["Azure Cloud<br/>Hub and Spoke"]
    T2["ARO Atacado<br/>ns atacado-core<br/>Plataformas Funcionais"]
    T3["Akamai + App Gateway"]
    T4["Axway API Gateway<br/>token LEAP (hipótese)"]
    T5["Azure Key Vault"]
    T6["Outbox relacional<br/>(premissa)"]
  end

  CAM1 --> CAM2 --> CAM3 --> CAM4 --> CAM5

  classDef indef fill:#fde2e2,stroke:#c0392b,color:#000
  classDef novo fill:#e3f2fd,stroke:#1565c0,color:#000
  classDef reuso fill:#e8f5e9,stroke:#2e7d32,color:#000
  class A09 indef
  class A02,A03 novo
  class A01,A04,A05,A06,A07,A08 reuso
```

Legenda: verde = existente/reuso; azul = novo; vermelho = indefinido.

### 4.2 (b) Mapa de capacidades

```mermaid
flowchart TB
  subgraph G1["Relacionamento e Adesão"]
    direction TB
    subgraph CAP01["CAP-01 Gestão de Relacionamento Comercial"]
      C011["CAP-01.1 Propostas e Pipeline"]
      C012["CAP-01.2 Negociação e Aprovação de Tarifas"]
      C013["CAP-01.3 Carteira do Cliente PJ Atacado"]
    end
    subgraph CAP02["CAP-02 Gestão de Adesão a Produtos Cash"]
      C021["CAP-02.1 Verificação de Contrato Vigente"]
      C022["CAP-02.2 Determinação do Tipo de Termo"]
      C023["CAP-02.3 Orquestração da Jornada de Adesão"]
    end
  end

  subgraph G2["Formalização"]
    direction TB
    subgraph CAP03["CAP-03 Gestão do Termo de Adesão"]
      C031["CAP-03.1 Composição do Termo"]
      C032["CAP-03.2 Ciclo de Vida e Status do Termo"]
      C033["CAP-03.3 Modelos do Termo"]
    end
    subgraph CAP04["CAP-04 Gestão de Representantes e Poderes"]
      C041["CAP-04.1 Consulta de Assinantes e Poderes"]
      C042["CAP-04.2 Revalidação de Assinantes"]
      C043["CAP-04.3 Regras de Assinatura"]
    end
    subgraph CAP05["CAP-05 Gestão de Assinatura Digital"]
      C051["CAP-05.1 Coordenação de Contrato e Protocolo"]
      C052["CAP-05.2 Armazenamento de Prévia"]
      C053["CAP-05.3 Coordenação de Regras"]
      C054["CAP-05.4 Coleta de Assinatura do Cliente"]
      C055["CAP-05.5 Notificação de Conclusão"]
    end
    subgraph CAP08["CAP-08 Gestão Documental"]
      C081["CAP-08.1 Renderização de PDF base64"]
      C082["CAP-08.2 Armazenamento e Retenção"]
    end
  end

  subgraph G3["Pós-assinatura e Receita"]
    direction TB
    subgraph CAP06["CAP-06 Gestão de Convênios"]
      C061["CAP-06.1 Geração de Convênio por Produto"]
      C062["CAP-06.2 Registro e Consulta de Convênios"]
    end
    subgraph CAP07["CAP-07 Gestão de Tarifas"]
      C071["CAP-07.1 Cadastro de Tarifas Negociadas"]
      C072["CAP-07.2 Vinculação Tarifa x Convênio"]
    end
    subgraph CAP09["CAP-09 Notificação e Acompanhamento de Status"]
      C091["CAP-09.1 Atualização de Status no Salesforce"]
      C092["CAP-09.2 Alertas ao Gerente"]
      C093["CAP-09.3 Notificação ao Cliente"]
      C094["CAP-09.4 Indicadores da Jornada"]
    end
  end

  subgraph G4["Transversais"]
    direction TB
    subgraph CAP10["CAP-10 Integração e Exposição de APIs"]
      C101["CAP-10.1 Mediação Salesforce x Banco"]
      C102["CAP-10.2 APIs Corporativas via Gateway"]
      C103["CAP-10.3 Recepção de Callbacks"]
      C104["CAP-10.4 Entrega Confiável de Eventos"]
    end
    subgraph CAP11["CAP-11 Segurança e Identidade de Integração"]
      C111["CAP-11.1 Autenticação de Integração"]
      C112["CAP-11.2 Gestão de Segredos"]
      C113["CAP-11.3 Segmentação de Rede"]
    end
    subgraph CAP12["CAP-12 Rastreabilidade, Auditoria e Conformidade"]
      C121["CAP-12.1 Trilha de Auditoria"]
      C122["CAP-12.2 Evidência de Aceite"]
    end
  end

  subgraph G5["Externas - fora do escopo do Atacado"]
    direction TB
    subgraph CAP13["CAP-13 Gestão do Canal Digital PJ (Canais)"]
      C131["CAP-13.1 Gestão de Pendências de Assinatura"]
      C132["CAP-13.2 Adesão ao Canal Digital"]
    end
  end

  G1 --> G2 --> G3
  G4 -.-> G1
  G4 -.-> G2
  G4 -.-> G3
  G5 -.-> G2

  classDef existente fill:#e8f5e9,stroke:#2e7d32,color:#000
  classDef nova fill:#e3f2fd,stroke:#1565c0,color:#000
  classDef indef fill:#fde2e2,stroke:#c0392b,color:#000
  classDef confirmar fill:#fff8e1,stroke:#f9a825,color:#000
  class C011,C012,C013,C041,C051,C052,C053,C054,C071,C082,C102,C112,C113 existente
  class C021,C022,C023,C031,C032,C033,C042,C055,C081,C091,C092,C094,C101,C103,C104,C121 nova
  class C061,C062,C072,C093 indef
  class C043,C111,C122 confirmar
  classDef externa fill:#eeeeee,stroke:#616161,stroke-dasharray:4 3,color:#000
  class C131,C132 externa
```

Legenda: verde = existente/reuso; azul = nova; amarelo = a confirmar; vermelho = indefinida; cinza tracejado = externa (fora do escopo de implementação do Atacado).

### 4.3 (c) Fluxo de integração conceitual ponta a ponta

```mermaid
sequenceDiagram
  autonumber
  actor GC as Gerente de Cash
  participant SF as Salesforce
  participant ARO as Serviços de Integração do Atacado (ARO Atacado)
  participant DOC as Geração de Documento
  participant FIRP as FIRP
  participant GACD as GACD
  participant GCC as GCC/Filenet
  participant CAN as Canal Digital PJ (abstraído)
  actor CLI as Assinante do Cliente PJ Atacado
  actor EXE as Executor da implantação (Gerente de Cash ou backoffice - QA-CON-24)
  participant CONV as Sistema de Convênio (sistema do produto, indefinido)
  participant DBX as Databricks (Tarifas)

  Note over ARO,GACD: Toda chamada do ARO Atacado para FIRP e GACD passa pelo Axway API Gateway - autenticação token LEAP (hipótese)
  GC->>SF: Solicita Termo de Adesão da Proposta aprovada (sem contrato vigente)
  SF->>ARO: Solicitação do termo (Proposta, cliente, produtos, tipo de termo)
  ARO->>FIRP: Consulta assinantes e poderes do cliente
  FIRP-->>ARO: Assinantes/representantes com poderes
  opt Confirmação de assinantes pelo Gerente (DEC-CON-07)
    ARO-->>SF: Assinantes identificados
    SF-->>GC: Exibe assinantes para conferência
    GC->>SF: Confirma assinantes
    SF->>ARO: Assinantes confirmados
  end
  ARO->>DOC: Gera Termo de Adesão (tipo, dados, produtos)
  DOC-->>ARO: PDF em base64
  ARO->>GACD: Passo 1 - Coordenar Contrato (contrato, assinantes, endpoint de callback)
  GACD-->>ARO: codigoProtocolo
  ARO->>GACD: Passo 2 - Armazenar Prévia (PDF base64, usuário sistêmico)
  GACD->>GCC: Armazena prévia do termo
  GACD-->>ARO: IdPrevia e CaminhoPrevia
  ARO->>GACD: Passo 3 - Coordenar Regra (confirma prévia e regras)
  GACD-->>ARO: Prévia e regras confirmadas
  ARO-->>SF: Status Aguardando assinatura e codigoProtocolo
  SF-->>GC: Termo enviado para assinatura

  CLI->>CAN: Acessa pendências de assinatura
  CAN->>GACD: Busca termos pendentes
  GACD-->>CAN: Termos pendentes do cliente
  CLI->>CAN: Acessa e assina o Termo de Adesão
  CAN->>GACD: Registra assinatura
  GACD->>ARO: Callback de assinatura (codigoProtocolo)
  ARO->>ARO: Grava o sinal na inbox, pendente de revalidação
  ARO-->>GACD: Recebimento confirmado (ACK)
  ARO->>FIRP: Depois do ACK, revalida os assinantes do callback (RN-06, via Axway)
  FIRP-->>ARO: Poderes vigentes dos assinantes
  ARO->>ARO: Grava no sinal o resultado da revalidação
  Note over ARO,FIRP: Se a FIRP estiver indisponível, o sinal fica pendente de revalidação e é reprocessado com retentativa, sem descarte. A assinatura não é confirmada sem revalidar

  alt Assinantes válidos
    ARO->>ARO: Termo Assinado - persiste estado e outbox na mesma transação
    ARO->>SF: Atualiza status do termo para Assinado (via outbox, consistência eventual)
    SF-->>GC: Notifica termo assinado
    opt Implantação do produto - por produto (QA-CON-02, QA-CON-03 e QA-CON-24)
      Note over SF,CONV: O evento Termo assinado abre a implantação - não cria o convênio. Onde a pendência nasce é indefinido
      SF-->>EXE: Pendência de implantação aberta (status Em implantação)
      EXE->>CLI: Define parâmetros com o cliente (layout CNAB ou API, canal, contas)
      EXE->>CONV: Cria o convênio em modo teste
      CLI->>CONV: Homologação - envia remessa de teste
      CONV-->>CLI: Retorno de teste (ajustes até funcionar)
      EXE->>CONV: Ativa o convênio após a homologação (RN-17)
      CONV-->>SF: Número e status do convênio (Convênio ativo)
      SF->>DBX: Tarifas negociadas liberadas para cadastro (pipeline existente)
      DBX-->>SF: Tarifas cadastradas
    end
  else Assinantes inválidos na revalidação (QA-CON-09)
    ARO->>ARO: Termo em Assinantes inválidos - persiste estado e outbox
    ARO->>SF: Alerta de assinantes inválidos no termo
    SF-->>GC: Alerta para regularizar assinantes e reemitir o termo
    Note over ARO,GACD: Destino do protocolo já assinado no GACD em aberto (QA-NEG-20 do 01)
  end
```

Leitura do diagrama:

- Passos de 1 a 3 no GACD e seus retornos (`codigoProtocolo`, `IdPrevia`, `CaminhoPrevia`) são **[FATO: 04]**; a ordem "gerar PDF antes do passo 1" é **[PREMISSA: PRM-CON-06]** (evita abrir protocolo sem documento).
- Consulta à FIRP pelo Atacado e callback na Azure/ARO Atacado são **[FATO: CG]**.
- Revalidação dos assinantes na FIRP pelo Atacado, no callback de assinatura, e o ramo de assinantes inválidos são **[FATO: CG]**. O Canal só exibe o termo e coleta a assinatura. A revalidação acontece **depois** de a assinatura ser registrada no GACD e depois do ACK do callback (o sinal fica pendente de revalidação na inbox até o resultado); as regras da revalidação estão em **[ABERTO: QA-CON-09]** e o destino do termo já assinado quando os assinantes forem inválidos em **[ABERTO: QA-NEG-20 do 01]**.
- Tratamento de falha parcial entre os 3 passos (compensação) não está descrito **[ABERTO: QA-CON-16]**.
- As interações de Convênio e Tarifas são **ilustrativas**: sistema, gatilho e integração são indefinidos. A implantação (parâmetros, convênio em teste, homologação com o cliente e ativação) é executada por pessoas — Gerente de Cash ou backoffice **[ABERTO: QA-CON-24]** — e o tempo de homologação depende do cliente **[PREMISSA — padrão de mercado]**.

### 4.4 (d) Visão de rede Hub and Spoke (conceitual)

```mermaid
flowchart LR
  subgraph SAAS["SaaS externo"]
    SF["Salesforce<br/>(Financial Services Cloud)"]
  end

  subgraph BORDA["Borda"]
    AK["Akamai"]
  end

  subgraph AZ["Azure Cloud"]
    subgraph HUB["vNet Hub"]
      AGW["Azure Application Gateway"]
      EGR["Saída controlada para SaaS<br/>(premissa PRM-CON-11)"]
    end
    subgraph SPK["vNet Spoke - Plataformas Funcionais"]
      subgraph AROATC["ARO Atacado - namespace atacado-core"]
        SVC["Serviços de Integração do Atacado<br/>(APP-02.1 a APP-02.3)"]
        CBK["Recepção de Callback e<br/>revalidação de assinantes<br/>(APP-02.4)"]
        OUTB["Entrega de Status<br/>(APP-02.5)"]
      end
      DB[("Estado e Outbox<br/>(premissa PRM-CON-05)")]
      KV["Azure Key Vault"]
    end
    IMPD["IMPD API Cloud<br/>(candidato - conectividade a confirmar)"]
  end

  subgraph APIM["Camada de APIs corporativa"]
    AX["Axway API Gateway<br/>token LEAP (hipótese)"]
  end

  subgraph CORP["Componentes corporativos (localização do GACD a confirmar)"]
    FIRP["FIRP"]
    GACD["GACD"]
    GCC["GCC/Filenet"]
  end

  CAN["Canal Digital PJ<br/>(abstraído - Canais)"]

  SF -->|"requisições do Gerente"| AK
  AK --> AGW
  AGW -->|"rota de entrada a confirmar (PRM-CON-11)"| AX
  AX --> SVC
  SVC --> AX
  AX --> FIRP
  AX --> GACD
  GACD --> GCC
  GACD -.->|"callback (rota interna ou externa a confirmar)"| AX
  AX -.-> CBK
  CBK -->|"revalidação na FIRP (RN-06)"| AX
  CBK --> DB
  SVC --> DB
  DB --> OUTB
  OUTB --> EGR
  EGR -->|"atualiza status"| SF
  SVC -.-> IMPD
  SVC -.-> KV
  CBK -.-> KV
  CAN --> GACD
```

Leitura do diagrama:

- **FATO [CG]**: Salesforce só conversa com serviços no ARO Atacado; ARO Atacado (namespace `atacado-core`, domínio Plataformas Funcionais) é uma vNet spoke em Hub and Spoke; FIRP e GACD são expostos via Axway.
- **FATO [stack]**: padrão de entrada Akamai → Load balance → Axway → Microsserviços.
- **PREMISSA**: Salesforce entra pelo mesmo padrão de canal externo (PRM-CON-11); o callback do GACD chega ao ARO Atacado via Axway, não exposto diretamente (PRM-CON-04); a saída do ARO Atacado para o Salesforce passa por controle de egress no Hub (PRM-CON-11).
- Linhas tracejadas indicam caminhos hipotéticos ou a combinar.

---

## 5. Matriz Capacidade × Processo × Sistema × Time

| Capacidade (L2) | Processo(s) | Sistema(s) / bloco | Time responsável | Status |
|---|---|---|---|---|
| CAP-01.1 Propostas e Pipeline | PN-01 | APP-01 Salesforce | Atacado Cash Payments | Existente |
| CAP-01.2 Negociação e Aprovação de Tarifas | PN-01 | APP-01 Salesforce | Atacado Cash Payments | Existente |
| CAP-02.1 Verificação de Contrato Vigente | PN-02 | APP-01 + fonte a definir | Atacado Cash Payments | Aberto (QA-CON-21) |
| CAP-02.2 Determinação do Tipo de Termo | PN-02 | APP-01 Salesforce | Atacado Cash Payments | Nova |
| CAP-02.3 Orquestração da Jornada de Adesão | PN-03, PN-04, PN-05 | APP-02.1 | Atacado Cash Payments | Nova |
| CAP-03.1 Composição do Termo | PN-04 | APP-02.1 | Atacado Cash Payments | Nova |
| CAP-03.2 Ciclo de Vida e Status do Termo | PN-05, PN-09, PN-12 | APP-02.7 + APP-01 | Atacado Cash Payments | Nova |
| CAP-03.3 Modelos do Termo | PN-04 | APP-03 Geração de Documento | Atacado Cash Payments | Aberto (QA-CON-19) |
| CAP-04.1 Consulta de Assinantes e Poderes | PN-03 | APP-02.2 → Axway → APP-04 FIRP | Atacado Cash Payments (consumo) | Reuso |
| CAP-04.2 Revalidação de Assinantes (no callback) | PN-08 | APP-02.4 → TEC-04 Axway → APP-04 FIRP | Atacado Cash Payments | Nova (Atacado) + reuso FIRP |
| CAP-04.3 Regras de Assinatura | PN-03, PN-07 | APP-04 / APP-05 | A confirmar (GACD) | Aberto (QA-CON-15) |
| CAP-05.1 Coordenação de Contrato e Protocolo | PN-05 | APP-02.3 → Axway → APP-05 GACD | GACD (provedor) / Atacado Cash Payments (consumidor) | Reuso |
| CAP-05.2 Armazenamento de Prévia | PN-05 | APP-05 GACD → APP-06 GCC/Filenet | GACD | Reuso |
| CAP-05.3 Coordenação de Regras | PN-05 | APP-05 GACD | GACD | Reuso |
| CAP-05.4 Coleta de Assinatura do Cliente | PN-06, PN-07 | APP-07 Canal Digital PJ | Canais / Experiência | Reuso (PDPJ) / lacuna BGS (QA-CON-07) |
| CAP-05.5 Notificação de Conclusão | PN-09 | APP-05 → APP-02.4 | GACD / Atacado Cash Payments | Nova (receptor) |
| CAP-06.1 Geração de Convênio por Produto (implantação, homologação e ativação) | PN-10 | APP-09 (sistema do produto, indefinido); executor ATR-01 ou ATR-09 | Indefinido (Atacado Cash Payments decide — QA-CON-24) | Indefinida |
| CAP-06.2 Registro e Consulta de Convênios | PN-10, PN-11 | APP-09 (indefinido) | Indefinido | Indefinida |
| CAP-07.1 Cadastro de Tarifas Negociadas | PN-11 | APP-08 Databricks | Atacado Cash Payments | Existente |
| CAP-07.2 Vinculação Tarifa × Convênio | PN-10, PN-11 | APP-08 + APP-09 | Indefinido | Indefinida |
| CAP-08.1 Renderização de PDF base64 | PN-04 | APP-03 (IMPD candidato) | Atacado Cash Payments | Decisão (DEC-CON-03) |
| CAP-08.2 Armazenamento e Retenção | PN-05 | APP-06 GCC/Filenet | GACD | Reuso |
| CAP-09.1 Atualização de Status no Salesforce | PN-09, PN-12 | APP-02.5 → APP-01 | Atacado Cash Payments | Nova |
| CAP-09.2 Alertas ao Gerente (notificação no Salesforce) | PN-08 | APP-02.5 → APP-01 | Atacado Cash Payments | Nova |
| CAP-09.3 Notificação ao Cliente | PN-06 | APP-07 ou APP-01 | Canais / Experiência | Aberto (QA-CON-10) |
| CAP-09.4 Indicadores da Jornada | PN-12 | APP-01 (+ APP-02) | Atacado Cash Payments | Nova |
| CAP-09.5 Recepção de Sinais de Assinantes Inválidos | — | — | — | **Removida na rodada 6 (2026-10-16):** a revalidação passou ao Atacado (CAP-04.2); não há mais alerta do Canal |
| CAP-10.1 Mediação Salesforce × Banco | PN-03 a PN-09 | APP-02 | Atacado Cash Payments | Nova |
| CAP-10.2 APIs Corporativas via Gateway | PN-03, PN-05, PN-09 | TEC-04 Axway | Corporativo (Axway) | Reuso |
| CAP-10.3 Recepção de Callbacks | PN-08, PN-09 | APP-02.4 | Atacado Cash Payments | Nova |
| CAP-10.4 Entrega Confiável de Eventos | PN-08, PN-09 | APP-02.5 + APP-02.7 | Atacado Cash Payments | Nova |
| CAP-11.1 Autenticação de Integração | Todos os integrados | TEC-04 + TEC-08 | Atacado Cash Payments + GACD | Aberto (QA-CON-14) |
| CAP-11.2 Gestão de Segredos | Todos os integrados | TEC-07 Key Vault | Atacado Cash Payments | Reuso |
| CAP-11.3 Segmentação de Rede | Todos os integrados | TEC-02 Hub and Spoke | Plataforma Azure (corporativo) | Reuso |
| CAP-12.1 Trilha de Auditoria | PN-02 a PN-11 | APP-02.7 + APP-05 + APP-01 | Atacado Cash Payments | Nova |
| CAP-12.2 Evidência de Aceite | PN-07, PN-09 | APP-05 + APP-06 | GACD + Atacado Cash Payments | Aberto (QA-CON-17) |
| CAP-13.1 Gestão de Pendências de Assinatura | PN-06, PN-07 | APP-07 Canal Digital PJ (BGS/PDPJ) | Canais (Experiência na jornada) | Externa — fora do escopo do Atacado |
| CAP-13.2 Adesão ao Canal Digital | — (disparada por EVN-08 no Termo de Adesão – Produtos + Canal) | APP-07 Canal Digital PJ (BGS/PDPJ) | Canais (Experiência na jornada) | Externa — fora do escopo do Atacado (QA-CON-11) |

---

## 6. Princípios de arquitetura conceituais

| ID | Princípio | Justificativa | Implicação | Base |
|---|---|---|---|---|
| PRI-01 | **Salesforce nunca integra diretamente com componentes do banco** | Diretriz das reuniões; SaaS externo não deve acoplar a APIs internas | Toda interação Salesforce ↔ FIRP/GACD passa por APP-02 no ARO Atacado | **[FATO: CG]** |
| PRI-02 | **ARO Atacado como camada anticorrupção** | Isola o modelo do Salesforce dos modelos de FIRP e GACD e absorve mudanças (ex.: troca GACD ↔ Open Cash Hub) | APP-02 traduz modelos; Salesforce conhece apenas o contrato do Atacado | Derivado de PRI-01 |
| PRI-03 | **Reuso de componentes corporativos antes de construir** | GACD, FIRP, GCC/Filenet, Databricks e IMPD já existem | Construir apenas integração, orquestração e o que não existir (ex.: callback, outbox) | **[FATO: 02, 04, 06]** |
| PRI-04 | **Fonte da verdade única por objeto** | Evitar divergência de dados | FIRP = assinantes/poderes; GACD = estado da assinatura e protocolo; GCC/Filenet = documento; Salesforce = Proposta e visão comercial (projeção de status) | **[PREMISSA: PRM-CON-09]** |
| PRI-05 | **Consistência eventual com outbox transacional** | Callback e atualização do Salesforce cruzam fronteiras de rede e sistemas | Evento persistido junto do estado antes de ser entregue ao Salesforce; reentrega garantida | **[FATO: CG]** (callback na Azure) + orientação de outbox |
| PRI-06 | **Callbacks e notificações idempotentes e correlacionáveis** | Callbacks podem ser repetidos; retry do GACD não documentado | Correlação por `codigoProtocolo` + identificador da Proposta/Termo; deduplicação no recebimento | **[PREMISSA: PRM-CON-12]** |
| PRI-07 | **APIs corporativas somente via Axway API Gateway** | Padrão corporativo de exposição | APP-02 consome FIRP/GACD pelo Axway (inclusive a revalidação no callback); o callback entra pelo Axway | **[FATO: CG, stack]** |
| PRI-08 | **Segredos e credenciais no Azure Key Vault** | Usuário sistêmico e tokens não podem ficar em código ou configuração | Nenhuma credencial em código; rotação gerenciada | **[FATO: stack, 04]** |
| PRI-09 | **Java preferencial para microsserviços transacionais** | Diretriz corporativa | Serviços de APP-02 em Java; Python apenas para dados/ETL | **[FATO: CG, stack]** |
| PRI-10 | **Canal abstraído e desacoplado por contrato** | Canal não é responsabilidade do Atacado | O Canal só dá a opção de acessar o termo e assiná-lo, integrado ao GACD; o Atacado não expõe API ao Canal nem depende da implementação dele (a revalidação é do Atacado, no callback — rodada 6) | **[FATO: CG, 01]** |
| PRI-11 | **Rastreabilidade ponta a ponta por padrão** | KPI-05 e ausência atual de rastreabilidade | Cada passo da jornada registra evento auditável e correlacionado | **[FATO: 03]** |
| PRI-12 | **Separação de ciclos de vida Termo × Convênio** | Termo é único e multiproduto; convênio é por produto e processo distinto | Modelar como objetos e capacidades distintos, ligados por evento (EVN-08 abre a implantação em PN-10; EVN-10 Convênio ativado libera PN-11) | **[FATO: 02]** |
| PRI-13 | **Gerenciador de termos substituível** | Escolha entre GACD e Open Cash Hub ainda em aberto | Contrato interno de APP-02.3 não expõe detalhes do GACD ao Salesforce | **[FATO: 02]** |

---

## 7. Pontos de decisão conceituais e alternativas

> Apenas levantamento. A decisão é tomada no **Desenho de Arquitetura de Solução (documento 04)** ou com o negócio.

| ID | Decisão | Alternativas | Considerações conceituais | Indicação preliminar |
|---|---|---|---|---|
| DEC-CON-01 | Gerenciador de termos | (a) **GACD**; (b) **Open Cash Hub**; (c) outro | GACD é corporativo, integrado à FIRP e ao PDPJ, alinhado ao roadmap de canal unificado **[FATO: 02]**; Open Cash Hub já tem termos e convênios, mas é canal para ERPs **[FATO: 02]** | GACD como referência deste desenho **[PREMISSA: PRM-CON-01]** |
| DEC-CON-02 | Onde gerar o Convênio | **A** novo serviço no ARO Atacado; **B** sistemas legados de cada produto Cash / "Sistemas (BD)", via ACL; **C** **Open Cash Hub** (processo já existe); **D** registro no Salesforce com efetivação em sistema legado. *Letras canônicas, iguais às do 03 §4.3, do 04 (ADR-11) e do 06 (D12)* | Precisa respeitar RN-12 (antes das tarifas) e ser por produto; gatilho mais provável é EVN-08 (termo assinado) ou EVN-01 (quando já há contrato vigente) | Nenhuma — depende do negócio **[ABERTO: QA-CON-02, QA-CON-03, QA-CON-04]**. **Em todas as opções (A–D) existe a etapa de implantação com executor humano** (Gerente de Cash ou backoffice — QA-CON-24): a opção escolhida define onde o convênio é registrado e onde a pendência de implantação nasce, não elimina a homologação com o cliente **[PREMISSA — padrão de mercado]** |
| DEC-CON-03 | Geração do PDF do Termo | (a) **IMPD** via API cloud `impd-srv-doc-generator`; (b) geração própria no ARO Atacado (modelo + biblioteca de PDF); (c) geração no Salesforce | IMPD: reuso e padrão corporativo, mas template CSF Designer v21 é nicho, alteração complexa exige terceiros, publicação com RDM, saída só base64 e conectividade ARO ↔ IMPD não confirmada **[FATO: 05, 06]**; geração própria dá autonomia, mas cria componente a manter; Salesforce viola parcialmente PRI-02 | Avaliar criticamente no documento 04 |
| DEC-CON-04 | Rota de entrada do callback do GACD | (a) Interna (GACD → Axway → ARO Atacado via Hub and Spoke); (b) Externa (Akamai → App Gateway → Axway) | Depende da localização do GACD ("Azure > ON") **[FATO: 04]** | (a) **[PREMISSA: PRM-CON-04]** |
| DEC-CON-05 | Mecanismo de atualização do Salesforce | (a) Push do ARO Atacado para API do Salesforce; (b) Salesforce consulta periodicamente o ARO Atacado; (c) eventos de plataforma do Salesforce | KPI-04 (status em tempo real) favorece push; outbox garante reentrega | (a) com outbox |
| DEC-CON-06 | Comunicação de assinantes inválidos | (a) Canal chama API no ARO Atacado; (b) Canal sinaliza ao GACD, que avisa via callback; (c) Atacado consulta FIRP periodicamente; (d) Atacado revalida os assinantes na FIRP ao receber o callback de assinatura | (a) era a proposta das reuniões; (b) centralizaria no GACD mas depende de evolução do GACD; (d) elimina o contrato com Canais e deixa a regra com o Atacado, mas a revalidação ocorre depois da assinatura registrada no GACD **[ABERTO: QA-NEG-20 do 01]** | **Revista na rodada 6 (2026-10-16): (d)**, decisão do negócio **[FATO: CG]** — ADR-13 do 04. A indicação anterior era (a), sujeita a acordo (QA-CON-08, encerrada) |
| DEC-CON-07 | Estilo de orquestração da jornada | (a) Salesforce aciona passos unitários (FIRP, gerar termo, GACD) e o Gerente confirma assinantes; (b) ARO Atacado orquestra ponta a ponta a partir de um único comando | (a) dá controle ao Gerente mas espalha estado; (b) concentra compensação (3 passos do GACD) no Atacado | Levar ao documento 04 |
| DEC-CON-08 | Assinatura para clientes do BGS | (a) Aguardar canal unificado; (b) usar PDPJ para assinatura; (c) fluxo de contingência | BGS não integra GACD **[FATO: 02]** | Nenhuma **[ABERTO: QA-CON-07]** |

---

## 8. Questões em aberto e premissas

### 8.1 Questões em aberto

| ID | Questão | Time responsável | Impacto |
|---|---|---|---|
| QA-CON-01 | Qual é o gerenciador de termos oficial: GACD, Open Cash Hub ou outro? | Atacado Cash Payments (com GACD) | DEC-CON-01, APP-05 |
| QA-CON-02 | **Onde o Convênio é gerado** e qual é o sistema de registro? (ver QA-CONV-01 no 01) | Atacado Cash Payments | CAP-06, APP-09 |
| QA-CON-03 | **Quem gera/dispara o Convênio** e qual é o gatilho (assinatura do termo, aprovação da proposta, ação manual)? Hipótese revista: o gatilho **abre a implantação**; a ativação depende da homologação (ver QA-CONV-02 e QA-CONV-03 no 01) | Atacado Cash Payments | PN-10, EVN-13, fluxo 4.3 |
| QA-CON-04 | **Qual a relação Termo × Convênio**: 1 termo para N convênios (um por produto)? Cliente com contrato vigente também gera convênio? Novo produto após o termo exige novo convênio sem novo termo? (ver QA-CONV-04 e QA-CONV-08 no 01) | Atacado Cash Payments | OBJ-02, OBJ-07, RN-02, RN-11, RN-12 |
| QA-CON-05 | Ordem correta entre convênio e cadastro de tarifas (diagrama × texto do PRD) (ver QA-CONV-07 no 01) | Atacado Cash Payments | PN-10, PN-11 |
| QA-CON-06 | Quais produtos de Cash Management / Payments estão no escopo? | Atacado Cash Payments | OBJ-09, conteúdo do termo |
| QA-CON-07 | Como assinam os clientes do BGS, que não integra com o GACD? | Canais | CAP-05.4, DEC-CON-08 |
| QA-CON-08 | **Encerrada — não se aplica (rodada 6, 2026-10-16):** a API de alerta do Canal deixou de existir; a revalidação passou ao Atacado. Texto original: contrato da API de alerta de assinantes inválidos (Canal → ARO Atacado): payload, autenticação, momento, responsabilidade | Canais | APP-02.6, CAP-09.5 (removidas) |
| QA-CON-09 | Regras da revalidação de assinantes na FIRP pelo Atacado no callback (revista na rodada 6): o que invalida, assinatura parcial, poderes alterados entre o envio e a assinatura | FIRP + Negócio (Atacado Cash Payments) | CAP-04.2, RN-06, PN-08, APP-02.4 |
| QA-CON-10 | Quem notifica o cliente (e-mail) sobre termo pendente: Canal, GACD ou Salesforce? | Experiência | CAP-09.3, PN-06 |
| QA-CON-11 | Experiência do cliente novo no "Termo de Adesão – Produtos + Canal": como ele acessa o Canal para assinar antes de ter acesso? | Experiência | RN-03, PN-06, PN-07 |
| QA-CON-12 | Contrato do callback do GACD: payload, estados possíveis (assinado, recusado, expirado, parcial), autenticação, retry | GACD | APP-02.4, EVN-12 |
| QA-CON-13 | Localização do GACD ("Azure > ON") e rota de rede do callback até o ARO Atacado | GACD | DEC-CON-04, CAM-5 |
| QA-CON-14 | Autenticação no Axway: token LEAP (hipótese) ou usuário sistêmico (citado no Armazenar Prévia)? Vale igual para a FIRP? | GACD (e dono da FIRP via Atacado Cash Payments) | CAP-11.1 |
| QA-CON-15 | FIRP: API, modelo de assinantes/poderes e regras de assinatura conjunta; o GACD já resolve assinantes pela sua integração com a FIRP? | GACD (e dono da FIRP via Atacado Cash Payments) | CAP-04, PN-03 |
| QA-CON-16 | Atomicidade e compensação das 3 chamadas ao GACD; nomes oficiais dos serviços (`gacd-srv-coordenar-ass-sformatador` × `gacd-srv-coordenador-ass-sformatador`; `cgcc_conteudo_gacd` × `cgcc-conteudo-gacd`) | GACD | APP-02.3 |
| QA-CON-17 | Requisitos regulatórios e de retenção do termo (validade jurídica, prazo de guarda, LGPD) | Atacado Cash Payments | KPI-05, CAP-12 |
| QA-CON-18 | Baseline do tempo entre negociação e assinatura (KPI-02) | Atacado Cash Payments | OE-02 |
| QA-CON-19 | Dono e versionamento do conteúdo jurídico dos 2 modelos de termo | Atacado Cash Payments | CAP-03.3, DEC-CON-03 |
| QA-CON-20 | Como o Salesforce acessa o ARO Atacado (Akamai/App Gateway/Axway ou conectividade privada) e como o ARO Atacado chama o Salesforce | Atacado Cash Payments | CAM-5, PRM-CON-11 |
| QA-CON-21 | Qual sistema é a fonte de "contrato vigente" (RN-02)? | Atacado Cash Payments | CAP-02.1, OBJ-10 |
| QA-CON-22 | Cliente com termo já assinado que adere a novo produto precisa de novo termo? | Atacado Cash Payments | RN-01, RN-02 |
| QA-CON-23 | Quem é o aprovador da proposta e se a aprovação precede a solicitação do termo | Atacado Cash Payments | ATR-04, PN-01 |
| QA-CON-24 | **Quem executa a implantação do produto (Gerente de Cash ou backoffice)?** Parâmetros com o cliente, convênio em teste, homologação e ativação (ver QA-CONV-12 no 01) | Atacado Cash Payments | ATR-01, ATR-09, PN-10, CAP-06.1, DEC-CON-02 |
| QA-CON-25 | **Quais produtos Cash exigem homologação e existe hoje uma área de implantação de Cash?** Se existir, ela é candidata natural a executora (ver QA-CONV-13 no 01) | Atacado Cash Payments | ATR-09, PN-10.3, RN-17, OBJ-09 |

### 8.2 Premissas

| ID | Premissa | Validar com |
|---|---|---|
| PRM-CON-01 | GACD é o gerenciador de termos de referência deste desenho; Open Cash Hub é alternativa | Atacado Cash Payments, GACD |
| PRM-CON-02 | Os Serviços de Integração do Atacado rodam no ARO Atacado (`atacado-core`) e pertencem ao Time do Atacado Cash Payments | Atacado Cash Payments |
| PRM-CON-03 | A autenticação nas APIs via Axway usa token LEAP | GACD, Atacado Cash Payments |
| PRM-CON-04 | O callback do GACD entra no ARO Atacado via Axway por rota interna (Hub and Spoke), sem exposição direta do serviço | GACD |
| PRM-CON-05 | O estado de integração e a outbox ficam em banco relacional gerenciado (PostgreSQL — Azure Database for PostgreSQL Flexible Server), fora do `stack-tech.md` | Atacado Cash Payments (arquitetura) |
| PRM-CON-06 | O Atacado gera o PDF antes de abrir o protocolo no GACD; o GACD não formata o documento (reforçado pelo envio de base64 no passo 2) | GACD |
| PRM-CON-07 | O Canal Digital PJ busca termos pendentes diretamente no GACD (fato para o PDPJ; premissa para o canal unificado) | Canais |
| PRM-CON-08 | A implantação do produto (e a geração do Convênio) é aberta após a assinatura do termo (ou após aprovação, com contrato vigente) e o convênio fica ativo antes do cadastro de tarifas (o texto do PRD prevalece sobre o diagrama) | Atacado Cash Payments |
| PRM-CON-09 | O Salesforce é o sistema de registro da Proposta e mantém uma projeção do status do termo; não é fonte de assinantes nem do estado da assinatura | Atacado Cash Payments |
| PRM-CON-10 | O Time de Experiência responde, com Canais, pela experiência do cliente na jornada de assinatura | Experiência, Canais |
| PRM-CON-11 | O Salesforce entra no Azure pelo padrão de canal externo (Akamai → Application Gateway → Axway); a saída do ARO Atacado para o Salesforce passa por controle de egress no Hub | Atacado Cash Payments (plataforma) |
| PRM-CON-12 | A correlação ponta a ponta usa `codigoProtocolo` + identificador da Proposta/Termo | GACD |
| PRM-CON-13 | Ciclo de vida do termo com estados além de "assinado" (seção 3.3.6); estados canônicos compartilhados com a seção 7.4 do 01 (PRM-NEG-16) | GACD, Atacado Cash Payments |
| PRM-CON-14 | O pipeline de tarifas no Databricks é mantido pelo Time do Atacado Cash Payments e consome convênios **ativos** | Atacado Cash Payments |
| PRM-CON-15 | **Padrão de mercado:** entre a assinatura e o convênio ativo há implantação e homologação com o cliente, executadas por pessoas (Gerente de Cash ou backoffice); o convênio nasce em teste e só é ativado após a homologação (RN-17). Não vem das fontes (PRM-NEG-18 no 01) | Atacado Cash Payments |

---

## 9. Insumos para o documento 03 (DDD)

Agrupamento **indicativo** de capacidades que o documento 03 deve refinar em domínios e bounded contexts:

| Agrupamento candidato | Capacidades | Natureza provável | Observação |
|---|---|---|---|
| Adesão e Termo de Adesão | CAP-02, CAP-03, CAP-04.2 | Núcleo (core) do Atacado | Dono: Atacado Cash Payments; realizado em APP-02 e APP-01. CAP-04.2 (revalidação no callback) fica na borda de entrada do núcleo (APP-02.4), consumindo a FIRP |
| Relacionamento Comercial | CAP-01 | Suporte (Salesforce) | Proposta é upstream da adesão |
| Representantes e Poderes | CAP-04.1, CAP-04.3 | Genérico/externo (FIRP) | Consumido via camada anticorrupção, também pela revalidação no callback (CAP-04.2) |
| Assinatura Digital | CAP-05, CAP-08.2 | Genérico/externo (GACD) | Relação cliente-fornecedor; conformista ao contrato do GACD |
| Convênios e Tarifas | CAP-06, CAP-07 | Suporte, dono indefinido | Downstream de EVN-08, que abre a implantação (EVN-13); a ativação (EVN-10) depende da homologação com o cliente e de executor humano (QA-CON-24) |
| Notificação e Status | CAP-09 | Suporte | Projeção de status e alertas no Salesforce (CAP-09.2); a detecção de assinantes inválidos (CAP-04.2) é feita na borda de entrada do núcleo de Adesão, no callback |
| Integração, Segurança e Auditoria | CAP-10, CAP-11, CAP-12 | Transversal (não é domínio de negócio) | Tratado como plataforma/infra |
| Canal do Cliente | CAP-13, CAP-05.4 | Externo (Canais) | CAP-13 é capacidade externa (Canal Digital PJ; Time de Canais, com Experiência na jornada), fora do escopo de implementação do Atacado. O Canal só exibe o termo e coleta a assinatura; não há contrato do Canal com o Atacado (rodada 6) |
