# Contexto de Negócio — Motor de Precificação Cash (MPC): visão para Precificação e Produtos

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Revisão 1.1 (2026-09-18) | Preço sugerido passa a ser lido da BRP Cash por cenário |
| Público | Gestores e analistas de Precificação e de Produtos de Cash |
| Fontes | `anexos/A0-brief-decisoes.md`; `docs-precificacao/00-doc-negocio.md`; `docs-precificacao/01` a `07`; `anexos/A1-analise-fluxos-produtos.md`; `anexos/A2-analise-fluxos-consolidacao.md` |

Convenções: referências no formato `docs-precificacao/<arquivo>:L<linha>` (abreviadas para `NN:L<linha>` quando o arquivo é um dos fluxos 01-07). Inferências do redator estão marcadas **(inferido)**. Nenhum número de ganho foi inventado: onde couber quantificação, o texto diz "métrica a medir".

---

## 1. Sumário executivo

O modelo de precificação de cash do Atacado já está formalizado em código para os passos 1 e 2 do business case (clusterização e tarifa-alvo por cluster), mas os passos 3 e 4 (relacionamento e gradação) vivem em macro Excel, premissas em planilha e no Motor da Calculadora (SQL 010), sem documentação (`anexos/A2`, Síntese transversal). A cadeia de distribuição até a Calculadora Salesforce é manual em pelo menos quatro pontos e depende de datas e listas escritas no código. O projeto **Motor de Precificação Cash (MPC)** propõe um motor online, parametrizável e auditável que classifica o cliente (tier, cluster), lê do cenário correspondente o preço praticado, alvo e sugerido, expõe os cenários vizinhos e calcula alçada, alimentado por uma **Base de Referência de Preços Cash (BRP Cash)** versionada por ciclo e gerada no Databricks. O preço sugerido é produzido no pipeline, por cenário (produto x região x segmento x tier), e não calculado online. A capacidade **C1 (Cálculo, Simulação e Entrega)** é prioritária e substitui o que funciona hoje. **C2 (Onda de Reprecificação)** e **C3 (Gestão de Reciprocidade)** são evoluções com pouco detalhamento de negócio e exigem discovery próprio. O maior risco não é técnico: é a ausência de definição formal de preço sugerido, alçada, elegibilidade e reciprocidade. Este documento organiza a estratégia embutida no modelo atual, os pontos de dor, as capacidades, as oportunidades e as decisões pendentes que o negócio precisa tomar na fase F0.

## 2. Objetivo de negócio, escopo e premissas

**Objetivo** (`00-doc-negocio.md:L3`): motor automático que parametriza, controla e fornece tarifas de payments (contas a pagar e a receber) e permite que canais consultem e simulem online preço-alvo, sugerido, vigente e histórico.

**Escopo** (`00-doc-negocio.md:L7-22`), em síntese:

- Retorno de preço-alvo, vigente e histórico por cliente x produto no Atacado (L7); parametrização e modelagem de novos produtos (L8-9).
- Simulação sem efetivação de tarifa (L10); consulta ao legado para vigente e histórico (L11-12).
- Interfaces de parametrização com versionamento (L13); auditoria de execuções e de alterações de parâmetros (L14).
- APIs para canais, plataformas e integradores, com a informação mais atual disponível (L15-16); staging antes da produção (L17); controle de acesso por perfil e alçada (L18); validação de entradas e monitoramento (L19-20).
- Alçadas para simulações abaixo do preço sugerido e contratação sem alçada no preço sugerido, com jornada a definir com o OPCH (L22). A L21 registra dúvida do próprio negócio sobre a calculadora de alçadas estar no escopo.

**Premissas** (`00-doc-negocio.md:L26-42`), em síntese: Precificação é dona das regras (L26, L33, L35); bases via Databricks, exceto bases de negócio como RFP e acordos (L27); preço vigente com versão atual e 12 meses de histórico no Databricks (L29); motor não substitui as bases (L30); canais cuidam das próprias interfaces (L31-32); fase inicial em payments Atacado (L34); staging obrigatório e governança de publicação (L36-37); contingência para motor offline (L39); implantação gradual por pilotos (L41); vigência agendada de parametrizações (L42).

## 3. Estratégia de precificação embutida no modelo atual

O modelo atual codifica uma estratégia clara: **padronizar preço por cluster e capturar uplift sem nunca reduzir tarifa**. Os elementos abaixo estão em código nos notebooks 01-05 e 06.

**Clusterização (tier x segmento x região).** Tier de volume com cortes empíricos por produto (`01:L61`, `L63-79`; `02:L30`; `03:L52-56`; `04:L45-48`). Cluster 1 = Tier 1; 2 = Tier 2; Tier 3 separado por segmento (ULTRA/GLOBAL = 3, LARGE = 4, AGRO = 10) e, para CORPORATE, por região (SP 5, SE ex-SP 6, S 7, CO 8, NNE 9) (`02:L31`; `05:L60-73`). No consolidado existem três grupos de regra de cluster por produto: Grupo 1 com região, Grupo 2 (DEBITO DE COBRANCA C/C) sem distinção Tier 2/3 nem região, Grupo 3 sem região (`05:L60-94`). A base de volume é média mensal em Multipag e PIX e total anual em Arrecadação **(inferido)** (`04:L26`, `L29`).

**Percentis com referência corporate e monotonicidade.** P35/P40/P50/P60/P90 calculados diretamente por cluster; P25 e P75 partem de uma referência ponderada por volume dos clusters "corporate" ([5,6,7,8,9] em Multipag/PIX, [5] em Arrecadação, ilegível em Cobrança) e recebem mínimo acumulado (cummin) na ordem corporate ≥ 10 ≥ 4 ≥ 3 ≥ 2 ≥ 1, garantindo que cliente maior nunca tenha referência maior que cliente menor (`01:L96-102`; `02:L50`; `04:L72-73`).

**Preço-alvo e uplift.** PREÇO_ALVO = max(TARIFA, P75) em todos os produtos (`01:L112`; `02:L52`; `03:L62`; `04:L78`). Uplift com limiar 1.000: tarifa < 1.000 usa (alvo − tarifa) × quantidade anual; tarifa ≥ 1.000 usa (alvo / tarifa − 1) × receita (`01:L116`). N < 15 grupos no cluster reverte ao preço atual e zera uplift (`01:L120`; `02:L52`).

**Exclusões.** Poder público em todos os fluxos (`01:L9`; `02:L22-24`; `03:L22`; `04:L21`); grupo 616 em Multipag, PIX e Arrecadação e "grupo Bradesco" em Cobrança, sem motivo documentado (`02:L25`; `01:L14`); CD_GRUPO = 0 no consolidado (`05:L37`); receita negativa em PIX (`03:L25`); apenas Tipo_Documento DIVERSOS no uplift de Arrecadação (`04:L35`).

**Diferenças entre produtos** (`anexos/A1`, "Diferenças relevantes"):

| Dimensão | Cobrança | Multipag | PIX | Arrecadação |
|---|---|---|---|---|
| Tarifa praticada | tarifa média calculada (`01:L15`) | tarifa de **contrato** vigente; receita = tarifa × qtde (`02:L19-21`) | RCTA / QTDE (`03:L26`) | RECEITA / QTDE (`04:L25`) |
| Base de volume do tier | QT_MENSAL | média mensal | média mensal | total anual (inferido) |
| Faixas de tier | 13 tabelas por modalidade | 4.000 / 50.000 | 100 / 500 | 200k/5M; 70k/750k |
| Região no cluster | sim (texto cortado) | sim | sim | não |
| Clusters corporate | ilegível | [5,6,7,8,9] | [5,6,7,8,9] | [5] |
| Cluster 3 / 4 | ULTRA-GLOBAL / LARGE | idem | idem | LARGE-INSTITUCIONAL / CORPORATE |
| Ordenação antes de "última tarifa" | não descrita | não (risco) | sim | sim |

**Matriz Stickiness x Impacto** (`06:L62-123`). Stickiness = max(score de cash, score de crédito), com faixas de share 0,1 / 0,4 / 0,7 → scores 1-4 e materialidade mínima de crédito por segmento (ULTRA 500 MM; LARGE e GLOBAL 40 MM; CORPORATE e AGRO 2 MM). Impacto = max(score de ROB, score de receita de cash), scores 1-3 com faixas por segmento (ROB: ULTRA/GLOBAL ≥ 12,6 MM → 3, ≥ 1,38 MM → 2; LARGE ≥ 6,3 MM / 1,38 MM; CORPORATE/AGRO ≥ 525 k / 93 k; receita cash: ULTRA/GLOBAL ≥ 2,25 MM / 300 k; LARGE ≥ 1,5 MM / 300 k; CORPORATE/AGRO ≥ 102 k / 9 k). Rótulos: Stickiness Baixo a Alto; Impacto Baixo/Médio/Alto. O fluxo produz a classificação, mas **não** define como ela se converte em percentual ou cadência de reajuste (`anexos/A2`, Fluxo 06 §9).

**Indicadores de reciprocidade.** Saldo médio de Invest Fácil e DAV por grupo (`06:L44-51`), SoW de boletos = QTDE_COB_BRAD / QTDE_COB_TOTAL (`06:L55`), share de cash (`06:L32`) e Emissões L3M (`07:L24`). O business case prevê "preço alvo → desconto por saldo de IF → preço de referência do cliente" (`06:L137`), mas a tabela de desconto está em `premissas_desconto.xlsx` sem conteúdo documentado (`07:L79`). Onde esse desconto é aplicado, ele entra no preço sugerido por cenário que a macro publica na Planilha Ano 1 (`07:L30`); não é uma conta feita na Calculadora nem, no TO-BE, no motor online.

## 4. Cadeia de valor AS-IS e pontos de dor

Encadeamento (`anexos/A2`, Síntese): extração SQL/Databricks → 7 notebooks → `base_total` e `tabela_precos` (05) + `matriz`, `saldo`, `sow_cobranca` (06) → Planilha Ano 1 → macro → Saída 1 (reprecificação manual) e Saída 2 (11 Excel → SAS `SIMUL_*_AAAAMM` → SQL 010 → Calculadora Salesforce) (`07:L17-42`).

Pontos de dor, com evidência:

- **Manualidade.** Cópia manual de saídas para abas, preenchimento de abas manuais, execução manual de macro e de query SAS, cópia manual para a pasta da calculadora (`07:L21-37`). Cada ciclo repete esse ritual.
- **Datas e listas hard-coded.** `REF >= 202506`, REF ∈ {2026-03, 04, 05} (`06:L17`, `L26`); janela LTM 01/05/2025-01/05/2026 (`02:L17`; `03:L16`; `04:L23`); listas de 18 produtos, 6 segmentos, 5 regiões (`05:L45-54`); limiares monetários da matriz (`06:L73`, `L99-113`).
- **Macro não documentada.** "Preço por Produto" e "Resumo por GE" nascem na macro (`07:L29-31`); é onde o preço sugerido por cenário é derivado e publicado (`SIMUL_PRECO_POR_PRODUTO`, `07:L112`) **(inferido)**.
- **SAS e SQL 010.** O Motor da Calculadora "contém regra de negócio" (`07:L41`, `L114`) e não está documentado; cadência mensal para tudo, semestral para preço por produto (`07:L112`), sem regra de convivência entre as duas.
- **Abas manuais.** Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos (`07:L48-56`) funcionam como filtros de elegibilidade e exceções de preço **(inferido)**, sem versionamento.
- **Ausência de versionamento e auditoria.** As premissas de `00-doc-negocio.md:L13-14` não têm contrapartida no AS-IS (`anexos/A2`, Fluxo 07 §9).
- **Fragilidades de dado.** Produto sem cluster descartado silenciosamente no inner merge (`05:L96`); filtro de contrato Multipag sobrescrito (`02:L19`); "última tarifa" sem ordenação cronológica em Multipag (`02:L26`); share de crédito sem agregação por grupo, com risco de duplicar linhas (`06:L30`); `fillna(0)` que iguala "sem dado" a "baixo relacionamento" (`06:L32`).

## 5. Capacidades e o que cada uma muda para o negócio

IDs conforme `anexos/A0`, §3.

**C1 — Cálculo, Simulação e Entrega de Preços (prioritária; funciona hoje).** Substitui Planilha + SAS + SQL 010 como fonte da Calculadora. O que muda: (C1.1) praticado, alvo e sugerido lidos do cenário do cliente na BRP Cash (o motor classifica tier e cluster e consulta o cenário, sem fórmula de desconto online) e devolvidos por API com definição única; (C1.2) cenários explícitos por percentil P25…P90 e cenários vizinhos por tier, hoje calculados mas não expostos (`02:L54`; `05:L20`), todos lidos da BRP; a única conta online é o uplift por cenário; (C1.3) alçada calculada pelo motor com desvio em % e R$ de uplift perdido e indicação do aprovador; (C1.4) preço vigente e histórico 12 meses via Adaptador de Legado; (C1.5) APIs para Salesforce e outros canais; (C1.6) cada preço rastreável à versão de parâmetro e de BRP Cash que o gerou.

**C2 — Onda de Reprecificação [EVOLUÇÃO — a detalhar com o negócio].** Formaliza a Saída 1 da planilha (`07:L33`): planejamento da onda com metas de uplift, seleção de elegíveis (entrada de C3 + negociações recentes, datas de reprecificação, RFPs, nichos, associações religiosas, poder público, N mínimo), cálculo em lote reusando C1 com gradação Stickiness x Impacto, aprovação, efetivação e acompanhamento. Hoje o processo está na "onda 4" (`07:L18`) e nada disso tem regra escrita.

**C3 — Gestão de Reciprocidade [EVOLUÇÃO — a detalhar com o negócio].** Registro do acordo na negociação (volumetria, saldo, produtos), monitoramento do realizado (Emissões L3M, saldo IF/DAV, SoW, share de cash), detecção de desvio com tolerâncias parametrizáveis e geração de elegibilidade para C2 e alertas ao gerente. Hoje só existe o realizado; não há acordo registrado (`anexos/A1`, Lacunas transversais).

**Posição sobre C3 ser capacidade própria.** O brief decidiu manter C3 separada de C2 (`anexos/A0`, §3): tem ciclo de vida próprio (começa na contratação e roda continuamente, com ou sem onda); serve a outros consumidores (gerente, manutenção de descontos, alertas); e, em desenho de domínios, publica o evento "cliente elegível" que C2 consome. A dependência C2 → C3 é de dados, não de estrutura. Para o negócio, isso significa que a reciprocidade pode entregar valor antes da onda automatizada existir.

**M1 Parametrização.** As 34 famílias de parâmetros dos fluxos de produto (`anexos/A1`, Lista consolidada) e as do consolidado (`anexos/A2`, Lista consolidada) passam a tabelas versionadas com staging, vigência agendada e auditoria. Novo produto ou segmento sem alteração de código (`00-doc-negocio.md:L8`).

**M2 Preparação de Dados.** Os 7 notebooks viram Databricks Workflows e geram a BRP Cash por ciclo (`anomes`), com validação antes da publicação. As entidades (MPA, PPC, Matriz de Relacionamento, Indicadores de Reciprocidade, Premissas, Exceções, Ciclo) estão em `anexos/A2`, "Entidades de dados candidatas". A MPA (Matriz de Cenários de Preço) carrega alvo, sugerido e percentis por cenário; a PPC carrega praticado, alvo e sugerido do cenário em que cada cliente caiu no ciclo. A regra que hoje gera o sugerido na macro "Preço por Produto" (`07:L30`) passa a ser etapa do pipeline.

**M3 Legado e Base Histórica.** Preço vigente e histórico, contratos e cadastro via Adaptador; desligamento de SAS/SQL 010/Planilha por produto após shadow run.

**M4 Governança.** Auditoria imutável, perfis, alçadas de quem parametriza, monitoramento, contingência com versão anterior da BRP Cash para rollback.

## 6. Oportunidades e ganhos

Quantificáveis (todos "métrica a medir"; o AS-IS não registra linha de base):

- **Uplift consolidado como métrica de gestão.** Hoje a soma de UPLIFT é exibida no notebook e não persistida (`05:L39`). No motor, o uplift potencial por ciclo, por produto e por cluster vira indicador rastreável, e o uplift **capturado** (diferença entre tarifa antes e depois da onda) vira resultado mensurável de C2.
- **Tempo de ciclo.** Da extração à publicação na Calculadora, hoje com ao menos sete passos manuais. Métrica a medir: dias de calendário e horas de esforço por ciclo, antes e depois.
- **Redução de retrabalho.** Ajuste de datas e listas a cada ciclo, correção de abas, reexecução de SAS. Métrica a medir: número de intervenções manuais e de reexecuções por ciclo.
- **Uplift perdido em negociação.** O motor passa a registrar o desvio entre preço sugerido e negociado por simulação (C1.3). Métrica a medir: R$ de uplift cedido por alçada, por gerente e por segmento.
- **Cobertura de clusters representativos.** Clusters com N < 15 hoje ficam fora sem visibilidade. Métrica a medir: percentual de receita em clusters sem referência.

Qualitativos:

- **Autonomia do comercial com alçada controlada.** Contratação sem alçada no preço sugerido e alçada objetiva abaixo dele (`00-doc-negocio.md:L22`), com cenários por percentil e tier para negociar com transparência.
- **Governança de parâmetros.** Quem mudou o quê, quando, com vigência e staging (`00-doc-negocio.md:L13-14`, `L17`, `L42`). Fim do "qual versão da planilha gerou esse preço".
- **Novos canais.** APIs permitem que jornadas digitais, integradores e processos internos consultem preço (`00-doc-negocio.md:L15`), hoje impossível porque o preço vive em tabelas do SQL 010.
- **Novos produtos e segmentos sem código.** O caso de `NA BAIXA POR PAGAMENTO Banco`, descartado por falta de regra de cluster (`05:L96`), e de CANAIS DIGITAIS e DÉBITO AUTOMÁTICO sem fonte declarada (`anexos/A2`, Fluxo 05 §9) deixam de existir com catálogo parametrizado.
- **Consistência entre produtos.** Regras hoje divergentes (cluster de Arrecadação, base de volume, chave de UF) passam a ser decisões explícitas em tabela, não acidentes de implementação.
- **Base para reciprocidade.** Registrar o acordo na negociação (C3.1) cria o dado que hoje não existe e habilita renegociação baseada em evidência.

## 7. Decisões de negócio pendentes

Formuladas a partir de `anexos/A0`, §8. Cada uma tem dono natural no time de Precificação/Produtos.

| # | Pergunta objetiva | Impacto se não decidir |
|---|---|---|
| 1 | Qual é a regra exata da macro "Preço por Produto" / "Resumo por GE" e do Motor da Calculadora (SQL 010)? | O motor não consegue reproduzir o preço sugerido atual; o shadow run (AD-14) não tem contra o que comparar. Bloqueia C1. |
| 2 | Quais são as colunas, faixas e valores de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto` e `regiao_por_ge`? | Sem isso o pipeline não reproduz o preço sugerido por cenário (`premissas_desconto` é insumo da macro, não do motor) e C1.3 fica sem regra de alçada. |
| 3 | Como o pipeline deriva o preço sugerido de cada cenário a partir do alvo (desconto por relacionamento, premissas, custos, RFP, nichos)? Ajustes de relacionamento que hoje ficam fora da BRP (saldo IF/DAV, Stickiness x Impacto) viram dimensão adicional do cenário ou exceção parametrizada? Quais níveis de alçada e quais aprovadores por produto/segmento/faixa de desvio? | A definição de trabalho do brief (§2) vira definição oficial por omissão; risco de contestação em produção. |
| 4 | Para C2: quais critérios de elegibilidade, qual gradação por célula da matriz Stickiness x Impacto e o motor efetiva a tarifa no legado ou só recomenda? Para C3: o que é "acordo de reciprocidade" e onde é registrado hoje? | C2 e C3 não podem ser desenhados além do esqueleto; a fase F3 começa sem insumo. |
| 5 | INSTITUCIONAL está no Atacado? A regra de cluster de Arrecadação (3 = LARGE/INSTITUCIONAL, 4 = CORPORATE, sem região) é intencional? Por que o grupo 616 / Bradesco é excluído? `NA BAIXA POR PAGAMENTO Banco` deve existir? Qual a fonte de CANAIS DIGITAIS e DÉBITO AUTOMÁTICO? | O catálogo de parâmetros nasce com inconsistências herdadas e o motor as perpetua com aparência de regra. |
| 6 | Quais janelas temporais (LTM 13 meses, ROB 6 meses, share 3 meses, IF/DAV 3 meses, boletos 12 meses) são política e quais são acidente das extrações? | Datas hard-coded viram parâmetros com valores não validados. |
| 7 | Qual latência é aceitável para o preço vigente: foto do ciclo via Databricks ou consulta online ao legado? | Define o Adaptador de Legado (AD-10); sem decisão, o piloto pode exibir preço defasado. |
| 8 | Quem detém os trechos truncados dos docs fonte (clusters "demais" e página 10 de Cobrança; fluxo 06 após L138; captura SAS cortada)? | Regras de cluster de Cobrança e evidência do passo 4 ficam incompletas. |
| 9 | O campo N é contagem de grupos por cluster em todos os produtos? QTDE_CASH_CONC e QTDE_COB_CONC devem entrar em alguma fórmula? | Indicadores de reciprocidade podem nascer com semântica errada. |
| 10 | Percentil-alvo continua P75 para todos os produtos, ou passa a ser parâmetro por produto/segmento? | O motor fixa P75 como constante e perde a flexibilidade que justifica a parametrização. |
| 11 | Como convivem a cadência mensal da matriz de cluster e a semestral do preço por produto (`07:L112`)? | Regras de versionamento da BRP Cash ficam ambíguas; dois preços válidos ao mesmo tempo. |

## 8. Indicadores de sucesso propostos (KPIs)

Propostos pelo redator a partir do escopo e das premissas; valores-meta a definir com o negócio.

| KPI | Definição | Capacidade | Linha de base |
|---|---|---|---|
| Uplift potencial por ciclo | Soma de (alvo − praticado) × volume anual por produto/cluster, persistida por `anomes` | C1 / M2 | Não persistida hoje (`05:L39`); métrica a medir |
| Uplift capturado | Receita incremental efetivada após onda versus uplift planejado | C2 | Métrica a medir |
| Aderência ao preço sugerido | % de simulações contratadas ≥ preço sugerido (sem alçada) | C1.3 | Métrica a medir |
| Uplift cedido por alçada | R$ e % de desvio aprovados abaixo do sugerido, por nível de alçada | C1.3 | Métrica a medir |
| Tempo de ciclo de publicação | Dias entre extração e ativação da versão da BRP Cash | M2 | Métrica a medir |
| Intervenções manuais por ciclo | Contagem de passos manuais (hoje ≥ 7) | M2 / M3 | Métrica a medir |
| Cobertura de referência | % da receita em clusters com N ≥ 15 e percentil disponível | M2 | Métrica a medir |
| Paridade no shadow run | % de consultas em que motor e SQL 010 divergem acima da tolerância | C1 / AD-14 | Zero até o piloto |
| Parâmetros publicados via staging | % de alterações que passaram por staging e aprovação antes da produção | M1 / M4 | Sem processo hoje |
| Rastreabilidade | % de preços entregues com versão de parâmetro e de BRP Cash identificadas | C1.6 / RNF-09 | Zero hoje |
| Desvios de reciprocidade detectados | Acordos com realizado abaixo da tolerância, e % tratados | C3 | Sem acordo registrado hoje |
| Disponibilidade e latência | Disponibilidade do motor e p95 da consulta/simulação (meta de trabalho < 500 ms, `anexos/A0` RNF-02) | RNF-01/02 | Métrica a medir |
