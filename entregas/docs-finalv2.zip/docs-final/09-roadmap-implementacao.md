# 09 — Roadmap de Implementação do Motor de Precificação Cash

| Campo | Valor |
|---|---|
| Versão | 1.1 |
| Data | 2026-09-18 |
| Revisão 1.1 (2026-09-18) | preço sugerido passa a ser lido da BRP Cash por cenário (brief §2); a engenharia reversa do sugerido na F0 mira o pipeline, não o motor |
| Status | Rascunho para validação |
| Fontes | `anexos/A0-brief-decisoes.md` (§2, §3, §6, §7, §8, §9, §10); `docs-precificacao/00-doc-negocio.md:L17`, `L41-42`; `anexos/A2-analise-fluxos-consolidacao.md` (Fluxo 07 e Síntese transversal) |

---

## 1. Sumário executivo

Este roadmap organiza a construção do **Motor de Precificação Cash (MPC)** em seis fases canônicas (F0 a F5, conforme `A0 §9`), do fechamento de lacunas em outubro de 2026 até a escala contínua em 2028. O objetivo é substituir, de forma gradual e auditável, a cadeia atual Planilha Ano 1 → SAS `SIMUL_*` → Motor da Calculadora (SQL 010) → Calculadora Salesforce por um motor online parametrizável, alimentado pela **Base de Referência de Preços Cash (BRP Cash)** gerada no Databricks.

Princípios que governam todas as decisões de sequenciamento:

1. **C1 primeiro, em paralelo ao legado.** A capacidade de Cálculo, Simulação e Entrega de Preços já funciona hoje e é a única com regras observáveis. O novo motor nasce em *shadow* ao lado do SQL 010 (AD-14, RNF-08) e só assume o canal quando a divergência medida estiver dentro do critério de corte por produto.
2. **Parametrização desde o início.** O módulo M1 não é uma fase posterior: catálogo, tiers, regra de cluster, percentis e premissas entram versionados na F1, ainda que com telas mínimas. Isso evita reescrever o motor quando a governança de parâmetros amadurecer (RF-05, RF-06, RNF-07, RNF-09).
3. **C2 e C3 só após discovery.** As capacidades de Onda de Reprecificação e Gestão de Reciprocidade estão **[EVOLUÇÃO — a detalhar com o negócio]** (R2, lacuna 4). A F3 começa por discovery e event storming; nenhum microsserviço de C2/C3 entra em construção antes de critérios de elegibilidade, gradação e efetivação estarem escritos.
4. **Desligamento gradual do legado.** SAS, SQL 010 e Planilha são desligados produto a produto, com histórico preservado, nunca em big bang.

Marcos principais (marcos M1 a M7, não confundir com os módulos M1 a M4 do brief §3): marco M1 arquitetura aprovada (13/11/2026), marco M2 BRP Cash v1 publicada (15/01/2027), marco M3 piloto C1 em shadow (12/02/2027), marco M4 go-live C1 (31/03/2027), marco M5 desligamento SAS/SQL 010 (30/06/2027), marco M6 MVP C3 (30/09/2027) e marco M7 MVP C2 (31/01/2028).

Convenção de referências: `A0 §n` é `anexos/A0-brief-decisoes.md`; `A2 Fluxo 07 §n` é `anexos/A2-analise-fluxos-consolidacao.md`; `00-doc-negocio.md:L<linha>` (e `L<linha>` isolado no mesmo parágrafo) é `docs-precificacao/00-doc-negocio.md`; "lacuna n" é o brief §8; R1-R10 são os riscos do brief §10.

## 2. Visão geral (Gantt)

Datas são metas de trabalho a validar com a capacidade das equipes na F0 (`A0 §9`).

```mermaid
gantt
  title Motor de Precificacao Cash - Roadmap F0 a F5
  dateFormat YYYY-MM-DD
  axisFormat %b/%y
  todayMarker off

  section F0 Mobilizacao
  Decisoes de negocio e engenharia reversa SQL 010   :f0a, 2026-10-01, 2026-11-13
  Contrato de dados BRP Cash e catalogo de parametros :f0b, 2026-10-12, 2026-11-13
  Arquitetura, ambientes e validacao Service Bus      :f0c, 2026-10-05, 2026-11-13
  M1 Arquitetura aprovada                             :milestone, m1, 2026-11-13, 0d

  section F1 MVP C1
  Sprints 1-2 Pipeline dbx-ppp e fundacoes            :f1a, 2026-11-16, 2026-12-11
  Sprints 3-4 svc-parametros e svc-pricing            :f1b, 2026-12-14, 2027-01-15
  M2 BRP Cash v1 publicada                            :milestone, m2, 2027-01-15, 0d
  Sprints 5-6 svc-alcada, legado adapter, APIs Axway  :f1c, 2027-01-18, 2027-02-12
  M3 Piloto C1 em shadow                              :milestone, m3, 2027-02-12, 0d
  Sprints 7-8 Salesforce em shadow e comparador       :f1d, 2027-02-15, 2027-03-12
  Estabilizacao e corte do primeiro produto           :f1e, 2027-03-15, 2027-03-31
  M4 Go-live C1                                       :milestone, m4, 2027-03-31, 0d

  section F2 Parametrizacao e desligamento
  Telas Salesforce de parametrizacao e staging        :f2a, 2027-04-01, 2027-05-28
  Validacao de dados e APIs para outros canais        :f2b, 2027-04-15, 2027-06-18
  Corte por produto e desligamento SAS SQL 010        :f2c, 2027-04-01, 2027-06-30
  M5 Desligamento SAS e SQL 010                       :milestone, m5, 2027-06-30, 0d

  section F3 Discovery C2 C3 e MVP C3
  Discovery e event storming C2 C3                    :f3a, 2027-07-01, 2027-07-30
  svc-reciprocidade acordo monitoramento desvio       :f3b, 2027-08-02, 2027-09-24
  Eventos e alertas ao gerente                        :f3c, 2027-08-30, 2027-09-30
  M6 MVP C3 Reciprocidade                             :milestone, m6, 2027-09-30, 0d

  section F4 MVP C2
  Onda e elegiveis                                    :f4a, 2027-10-01, 2027-11-12
  Calculo em lote e aprovacao                         :f4b, 2027-11-15, 2027-12-23
  Efetivacao e acompanhamento                         :f4c, 2028-01-03, 2028-01-31
  M7 MVP C2 Reprecificacao                            :milestone, m7, 2028-01-31, 0d

  section F5 Escala
  Novos produtos segmentos canais e avaliacoes        :f5a, 2028-02-01, 2028-12-31
```

## 3. Detalhamento por fase

### F0 — Mobilização e fechamento de lacunas (out–nov/2026, 4-6 semanas)

**Objetivo.** Transformar as lacunas do `A0 §8` em decisões registradas e aprovar a arquitetura antes de qualquer linha de código do motor.

**Escopo.** Sem entrega de capacidade funcional. Trabalho de descoberta sobre C1 e os módulos M1, M2 e M3, e preparação do módulo M4.

**Entregáveis.**
- Engenharia reversa documentada da macro "Preço por Produto"/"Resumo por GE" e do Motor da Calculadora no SQL 010 (lacuna 1, R1), com casos de teste reais que servirão de oráculo ao shadow run. O resultado vira regra do **pipeline** (`dbx-ppp`, geração do preço sugerido por cenário na BRP Cash) e da parametrização; o motor online apenas consulta o cenário (`A0 §2`, Revisão 1.1).
- Conteúdo de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto` e `regiao_por_ge` transcrito para o **catálogo de parâmetros** (lacuna 2), com decisões sobre INSTITUCIONAL, cluster de Arrecadação, grupo 616 e produtos sem cluster (lacuna 5, R9).
- Definição formal de preço praticado, alvo e sugerido e da regra de alçada (`A0 §2`, lacuna 3), assinada por Precificação.
- **Contrato de dados da BRP Cash** (entidades da Síntese transversal de `A2`), com chaves, tipos, regras de qualidade e versionamento por `anomes`.
- Arquitetura aprovada (AD-01 a AD-14), incluindo validação do Azure Service Bus ou fallback outbox (AD-09, lacuna 9, R5) e decisão de latência do preço vigente (AD-10, lacuna 7, R4).
- Ambientes: workspace Databricks, Azure SQL de desenvolvimento e homologação, namespaces no ARO, rotas no Axway, sandbox Salesforce.
- Plano de capacidade e formação dos squads (R8).

**Critérios de entrada.** Patrocínio executivo formalizado; time de Precificação alocado para as sessões de engenharia reversa; acesso de leitura ao SQL 010, ao SAS e ao workbook `Preço ano 1.xlsx`.

**Critérios de saída (DoD).** As dez lacunas do `A0 §8` têm decisão registrada ou dono e prazo; contrato de dados e catálogo de parâmetros aprovados; arquitetura aprovada em comitê (marco M1); ambientes provisionados e testados com um *hello world* de ponta a ponta (Salesforce → Axway → ARO → Azure SQL).

**Dependências.** Disponibilidade do time de Precificação; área de dados para acesso ao Databricks; arquitetura corporativa para o Service Bus.

**Equipe sugerida.** Arquitetura/QA (2), dados/Databricks (1), backend Java (1), Salesforce (0,5). Negócio: Precificação (dono das regras), Produtos, OPCH (jornada de contratação sem alçada, `00-doc-negocio.md:L22`).

**Riscos da fase.** R1 (maior exposição em todo o programa), R9, R5, R4, R8.

**Decisões de negócio necessárias.** Todas as lacunas 1 a 10. As bloqueantes para a F1 são as lacunas 1, 2, 3, 5 e 7.

### F1 — MVP C1: motor online em paralelo ao legado (nov/2026–mar/2027, ~4 meses)

**Objetivo.** Entregar C1 completo (C1.1 a C1.6) em shadow ao lado do SQL 010, com um grupo de gerentes em piloto e corte do primeiro produto até o marco M4.

**Escopo.** Capacidades C1.1 a C1.6; módulo M1 com versionamento básico; módulo M2 completo para os quatro macroprodutos; módulo M3 na estratégia (a) foto via Databricks; módulo M4 com auditoria e observabilidade padrão. Componentes canônicos: `dbx-ppp`, `dbx-brp`, `sql-motor`, `svc-publicacao`, `svc-parametros`, `svc-pricing`, `svc-alcada` (regras mínimas), `svc-legado-adapter` (foto), `apigw-axway`, `sf-calculadora` em shadow.

**Plano de sprints (8 sprints de 2 semanas + 3 semanas de estabilização).**

| Sprint | Período | Tema | Resultado verificável |
|---|---|---|---|
| S1 | 16/11–27/11/2026 | Fundações | Esqueleto dos serviços Java no ARO, pipeline CI/CD, modelo de dados do `sql-motor`, notebooks 01-02 (Cobrança) portados para Databricks Workflows. |
| S2 | 30/11–11/12/2026 | Pipeline completo | Notebooks 03-07 portados; tabelas Delta da BRP Cash versionadas por `anomes`; validações de qualidade (RF-08); datas hard-coded viram parâmetros (lacuna 6, R3). |
| S3 | 14/12–24/12/2026 | Parametrização básica | `svc-parametros` com catálogo, domínios, tiers, regra de cluster, percentis e premissas versionados (rascunho → publicado); carga inicial a partir do catálogo da F0. |
| S4 | 04/01–15/01/2027 | Cálculo de preço e publicação | `svc-pricing` classifica o cliente e devolve praticado/alvo/sugerido lidos do cenário da BRP Cash (RF-01, sem cálculo do sugerido no motor); pipeline publica o sugerido por cenário (provisório até a lacuna 1 fechar); reverse ETL JDBC + procedure de ativação (AD-03); **marco M2: BRP Cash v1 publicada** e ativada no `sql-motor`. |
| S5 | 18/01–29/01/2027 | Cenários e alçada | Cenários por percentil, tier e relacionamento (RF-02, `A0 §2`); `svc-alcada` com faixas de desvio e papel aprovador parametrizados (RF-03). |
| S6 | 01/02–12/02/2027 | Legado, APIs e auditoria | `svc-legado-adapter` com foto do preço vigente e histórico 12 meses (RF-04); APIs publicadas no Axway com OAuth2 (RF-07, AD-12); trilha de execução com versão de parâmetro e de BRP (RF-09, RNF-09); **marco M3: piloto em shadow** iniciado com o comparador automático. |
| S7 | 15/02–26/02/2027 | Salesforce em shadow | LWC da Calculadora chamando o motor via Named Credentials em paralelo ao SQL 010 (AD-05); nenhuma lógica em Apex (R6); grupo piloto de gerentes vê o resultado do legado e registra o do motor. |
| S8 | 01/03–12/03/2027 | Convergência | Análise das divergências por produto, ajustes de parâmetros e regras; cache Caffeine (AD-11); testes de carga contra RNF-02; contingência com versão anterior da BRP (AD-13). |
| Estabilização | 15/03–31/03/2027 | Corte do primeiro produto | Produto que atingir o critério de corte passa a ser respondido pelo motor; **marco M4: go-live C1**. |

**Critérios de entrada.** Marco M1 atingido; lacunas bloqueantes decididas; squads formados.

**Critérios de saída (DoD).** Pipeline executa um ciclo de precificação completo no Databricks sem intervenção manual; BRP Cash v1 ativada e reproduzível; APIs de C1.1 a C1.5 em produção com auditoria (C1.6); comparador automático rodando para os quatro macroprodutos; pelo menos um produto cortado para o motor com divergência dentro do critério (§4); rollback de versão de BRP e de parâmetro testado em homologação.

**Dependências.** Área de dados (workflows e permissões); Axway e ARO; sandbox e release Salesforce; time de Precificação para arbitrar divergências do shadow.

**Equipe sugerida.** Dados/Databricks (2-3), backend Java (3-4), Salesforce (1-2), arquitetura/QA (2). Negócio: Precificação (diário durante S7-S8), OPCH, Produtos.

**Riscos da fase.** R1 e R7 (shadow como mitigação), R3, R6, R8, R4.

**Decisões de negócio.** Critério de corte por produto (§4); composição do grupo piloto; latência aceitável do preço vigente se a foto não bastar (lacuna 7).

### F2 — Parametrização completa e desligamento do legado de distribuição (abr–jun/2027, ~3 meses)

**Objetivo.** Dar ao time de Precificação autonomia para operar o motor sem TI e desligar SAS, SQL 010 e Planilha Ano 1 como caminho de distribuição.

**Escopo.** Módulo M1 completo: `sf-parametrizacao` (LWC), staging, vigência agendada, perfis e alçadas de quem parametriza, auditoria de mudança (RF-05, RF-06, RF-10, AD-06). Módulo M3: desligamento por produto. C1.5: APIs para outros canais e integradores. Módulo M4: perfis via AD/Salesforce, monitoramento de integrações (RNF-05).

**Entregáveis.** Telas de parametrização com fluxo rascunho → staging → aprovação → publicado; endpoint de simulação "em staging" para o negócio testar uma parametrização antes de publicar (`00-doc-negocio.md:L17`, `L42`); vigência agendada; validação de dados de entrada com alertas aos canais (RF-08, `L38`); catálogo de APIs para canais externos; desligamento executado para os quatro macroprodutos (marco M5); runbooks operacionais.

**Critérios de entrada.** Marco M4 atingido; primeiro produto estável no motor por pelo menos duas semanas; catálogo de parâmetros completo.

**Critérios de saída (DoD).** Precificação publica um ciclo completo de parâmetros pelo Salesforce sem apoio de TI; 100% das simulações da Calculadora respondidas pelo motor; SAS `SIMUL_*` e SQL 010 sem novas cargas há um ciclo; Planilha Ano 1 usada apenas como histórico; ao menos um canal além do Salesforce consumindo as APIs ou contrato assinado.

**Dependências.** Governança de publicação definida (§6, R10); disponibilidade do time de Precificação para homologar telas; canais externos interessados.

**Equipe sugerida.** Salesforce (2), backend Java (2-3), dados/Databricks (1-2), arquitetura/QA (1,5). Negócio: Precificação (dono), Produtos.

**Riscos da fase.** R10, R7 (cortes restantes), R6, R3.

**Decisões de negócio.** Perfis e alçadas de parametrização (`00-doc-negocio.md:L35`); processo de governança de publicação (`L37`); ordem final dos cortes.

### F3 — Discovery C2/C3 + MVP Reciprocidade [EVOLUÇÃO — a detalhar com o negócio] (jul–set/2027, ~3 meses)

**Objetivo.** Fechar a definição de negócio de C2 e C3 e entregar o MVP de Gestão de Reciprocidade.

**A fase começa obrigatoriamente por discovery.** As quatro primeiras semanas são de event storming com Precificação, Produtos, OPCH e comercial para responder à lacuna 4: o que é um acordo de reciprocidade e onde é registrado hoje; indicadores e tolerâncias que caracterizam desvio; critérios de elegibilidade para a onda; gradação por Stickiness x Impacto; se o motor efetiva tarifa no legado ou apenas recomenda. O escopo do MVP só é congelado após o discovery aprovado.

**Escopo (após discovery).** C3.1 a C3.4 com `svc-reciprocidade`, job periódico via Control-M (AD-07), eventos `DesvioReciprocidade` e `ClienteElegivelParaReprecificacao` no `sb-eventos` ou outbox (AD-09), alertas ao gerente no Salesforce.

**Entregáveis.** Documento de discovery C2/C3 (glossário, eventos de domínio, regras, políticas); modelo de acordo; monitoramento acordado x realizado sobre os Indicadores de Reciprocidade da BRP Cash; regras de desvio parametrizadas no módulo M1; alertas e fila de elegíveis (marco M6).

**Critérios de entrada.** Marco M5 atingido; motor estável; patrocínio para o discovery com presença de negócio.

**Critérios de saída (DoD).** Discovery aprovado; acordos registrados para o grupo piloto; job de monitoramento rodando por ciclo; eventos publicados e consumidos por um assinante de teste; alertas visíveis ao gerente; regras de desvio alteráveis por parâmetro sem deploy.

**Equipe sugerida.** Arquitetura/QA (2, lideram o discovery), backend Java (2-3), dados/Databricks (1), Salesforce (1). Negócio: Precificação, Produtos, OPCH, representantes comerciais.

**Riscos da fase.** R2 (maior exposição), R5, R10.

**Decisões de negócio.** Lacuna 4 integral; semântica do campo N e de `QTDE_CASH_CONC`/`QTDE_COB_CONC` (lacuna 10).

### F4 — MVP Onda de Reprecificação [EVOLUÇÃO — a detalhar com o negócio] (out/2027–jan/2028, ~4 meses)

**Objetivo.** Substituir a "Saída 1" manual do Fluxo 07 por uma onda orquestrada, aprovada e acompanhada.

**Escopo (condicionado ao discovery da F3).** C2.1 a C2.5 com `svc-reprecificacao` (AD-08): planejamento da onda, seleção de elegíveis (entrada de C3 + filtros de Negociações Recentes, Datas de Reprecificação, RFPs, Nichos, Associações Religiosas, Poder Público, N mínimo), cálculo em lote reusando `svc-pricing`, aprovação via `svc-alcada`, `sf-reprecificacao` (LWC), efetivação no legado conforme decisão de escopo, acompanhamento do uplift realizado.

**Entregáveis.** Onda piloto executada de ponta a ponta para um subconjunto de clientes; listas de exceção migradas de abas manuais para parâmetros (`A2 Fluxo 07 §5`); relatório de uplift previsto x realizado (marco M7).

**Critérios de entrada.** Marco M6 atingido; discovery de C2 aprovado; decisão sobre efetivação no legado.

**Critérios de saída (DoD).** Uma onda completa com aprovação registrada e trilha de auditoria; ao menos um grupo de clientes com tarifa efetivada (ou recomendação entregue, conforme escopo) e acompanhamento por três meses planejado; Precificação não usa mais o workbook para decidir a onda.

**Equipe sugerida.** Backend Java (3), Salesforce (1-2), dados/Databricks (1-2, pré-computação de elegíveis), arquitetura/QA (1,5). Negócio: Precificação, Produtos, OPCH, comercial.

**Riscos da fase.** R2, R10, R7 (efetivação em produção sem paralelo), R5.

**Decisões de negócio.** Efetivação x recomendação (lacuna 4); gradação do reajuste; avaliação de FICO apenas se a gradação se mostrar complexa demais para tabelas (AD-04).

### F5 — Escala e otimização (2028, contínuo)

**Objetivo.** Ampliar cobertura e otimizar por evidência.

**Escopo.** Novos produtos e segmentos via parametrização sem código (RNF-07), inclusive INSTITUCIONAL se decidido; outros canais; estratégia (b) do Adaptador de Legado se a latência exigir; avaliação com dados de produção de Redis (AD-11), MongoDB para histórico de simulações (AD-02) e FICO (AD-04); evolução dos modelos analíticos.

**Critérios de saída.** Não se aplica; operação contínua com backlog priorizado pelo Comitê de Produto.

**Equipe sugerida.** Squad de sustentação e evolução (Java 2, dados 1-2, Salesforce 1, QA 1).

**Riscos.** R8 (retenção de conhecimento), R3.

## 4. Estratégia de transição e piloto

**Shadow run.** A partir do marco M3, a Calculadora Salesforce envia cada simulação ao motor e ao SQL 010. O gerente vê a resposta do legado; a do motor é gravada com a mesma chave de execução. Um comparador automático (job diário no Databricks sobre a trilha de auditoria) calcula, por produto, segmento, tier e cluster, a divergência de preço alvo e sugerido, a divergência de alçada e a cobertura.

**Critérios de corte por produto.** Um produto migra para o motor quando, em janela de duas semanas consecutivas: divergência de preço sugerido ≤ 1% em pelo menos 98% das simulações; divergência de alçada nula; 100% das divergências residuais explicadas e classificadas como erro do legado, decisão de negócio ou arredondamento; p95 de latência dentro do RNF-02; rollback ensaiado. Os valores numéricos são metas iniciais a confirmar com Precificação na F0.

**Grupos de teste.** Piloto com 10 a 20 gerentes de duas ou três regionais, escolhidos com Produtos e OPCH para cobrir os cinco segmentos do Atacado. Expansão em três ondas: piloto, regionais adicionais, rede completa. Cada onda só avança com os KPIs da anterior verdes.

**Rollback.** Três níveis independentes: (1) chave de roteamento por produto no Salesforce, que devolve o canal ao SQL 010 sem deploy; (2) reativação da versão anterior da BRP Cash (AD-03, AD-13); (3) reversão de versão de parâmetro. Até o desligamento, o SQL 010 continua recebendo cargas mensais para que o nível (1) seja sempre possível.

**Ordem de produtos recomendada.**

| Ordem | Produto | Papel | Justificativa |
|---|---|---|---|
| 1 | Multipag (Fornecedores TED) | Canário técnico | Um produto, tarifa de contrato, sem cluster complexo. Valida a cadeia ponta a ponta com o menor número de variáveis e converge rápido no shadow. |
| 2 | PIX (recebimento e pagamentos) | Canário técnico | Dois produtos, tiers simples. Confirma que a parametrização de tier e cluster generaliza além do primeiro produto. |
| 3 | Cobrança | Primeiro corte de valor | Treze modalidades, maior uplift e maior maturidade documental (fluxos 01 e 02 em `A1`). É onde o negócio ganha e onde a divergência é mais informativa. Entra no shadow desde o início, mas só corta depois que os canários provaram a plataforma. |
| 4 | Arrecadação | Último | Regra de cluster divergente e produtos sem cluster (lacuna 5, R9); depende de decisões de negócio que podem atrasar. |

A recomendação é, portanto, **shadow simultâneo para os quatro macroprodutos desde o marco M3, corte técnico por Multipag e PIX, e corte de valor por Cobrança como marco M4**. Começar direto por Cobrança concentraria R1 e R7 no produto com mais regras; adiar Cobrança perderia a janela de validação com Precificação. A combinação captura os dois benefícios.

## 5. Plano de desligamento do legado de distribuição

**Condições para desligar um produto.** Produto cortado para o motor há pelo menos um ciclo de precificação completo; nenhum consumidor além da Calculadora lendo as tabelas `SIMUL_*` daquele produto (inventário feito na F0); Precificação confirma que não usa mais a aba correspondente para decisão; histórico exportado e catalogado.

**Sequência.**

1. **Planilha Ano 1 como insumo do motor (F1).** A partir do marco M2, o pipeline gera a BRP Cash diretamente; a planilha deixa de alimentar o SAS. Continua como ferramenta de conferência do negócio até o marco M5.
2. **SAS `SIMUL_*` (F2).** Após o corte de cada produto, a carga mensal do SAS para aquele produto para. Última carga de todos os produtos é o marco M5. `SIMUL_PRECO_POR_PRODUTO` (semestral) é substituída pela publicação de preço por produto na BRP Cash com vigência.
3. **Motor da Calculadora SQL 010 (F2).** Desligado após o último produto cortado, mantido em leitura por um ciclo adicional para auditoria retroativa e depois arquivado. Sua lógica já terá sido transcrita para parâmetros e código na F0/F1.
4. **Planilha como decisão de onda (F4).** A "Saída 1" manual é substituída por `svc-reprecificacao`; a planilha sai de uso operacional no marco M7.

**O que fica como histórico.** Snapshot imutável das tabelas `SIMUL_*_AAAAMM` dos últimos 24 meses como tabela Delta no Databricks; versões do workbook por ciclo arquivadas com hash; documentação da engenharia reversa do SQL 010 (RNF-03).

## 6. Governança do programa

| Instância | Composição | Cadência | Decide |
|---|---|---|---|
| Comitê Executivo | Patrocinador, líder de Precificação, Produtos, OPCH, TI (arquitetura, dados) | Mensal e nos marcos M1-M7 | Passagem de fase, orçamento, escopo de C2/C3, desligamento do legado |
| Comitê de Produto | Product owner do MPC, Precificação, arquitetura, líderes de squad | Quinzenal | Priorização de backlog, critérios de corte, aceite de entregáveis |
| Fórum de Parâmetros e Versões | Precificação (dono), Produtos, TI (parametrização e dados) | Semanal em ciclo de publicação; sob demanda | Aprovação de versão da BRP Cash e de parâmetros para produção |
| Sincronização de squads | Líderes técnicos | Diária/semanal | Dependências técnicas, integrações |

**Papéis de aprovação.** Precificação é dona das regras e parâmetros (`00-doc-negocio.md:L26`) e aprova cada versão de parâmetro após teste em staging; a versão da BRP Cash é aprovada por Precificação com base no relatório de validação de qualidade do pipeline; TI aprova releases de software; o Comitê Executivo aprova cada corte de produto e cada desligamento. A cadeia rascunho → staging → aprovação → produção fica registrada em `svc-parametros` e `svc-publicacao` (RF-06, RF-09, RF-10, R10).

**Gestão de mudanças com Precificação.** O time de Precificação participa como coautor: engenharia reversa na F0, arbitragem das divergências do shadow na F1, homologação das telas na F2 e liderança de negócio no discovery da F3. Treinamento em parametrização ocorre antes do marco M5. Toda mudança de regra passa a exigir registro no catálogo de parâmetros, encerrando as abas manuais.

## 7. Capacidade e estimativa de esforço

Ordem de grandeza inicial, em pessoas x mês por squad, **a refinar na F0** com o dimensionamento real (R8).

| Fase | Dados/Databricks | Backend Java | Salesforce | Arquitetura/QA | Negócio (dedicação parcial) | Total aprox. |
|---|---|---|---|---|---|---|
| F0 (1,5 mês) | 1,5 | 1,5 | 1 | 3 | 3 | 10 |
| F1 (4,5 meses) | 11 | 16 | 7 | 9 | 6 | 49 |
| F2 (3 meses) | 4,5 | 7,5 | 6 | 4,5 | 4,5 | 27 |
| F3 (3 meses) | 3 | 7,5 | 3 | 6 | 6 | 25,5 |
| F4 (4 meses) | 6 | 12 | 6 | 6 | 6 | 36 |
| F5 (por ano) | 18 | 24 | 12 | 12 | 6 | 72 |

Total F0 a F4: aproximadamente 150 pessoas x mês em 16 meses. As estimativas de F3 e F4 têm incerteza maior porque dependem do discovery (R2).

## 8. KPIs do programa e de negócio

| Fase | KPI | Meta de trabalho |
|---|---|---|
| F0 | Lacunas do `A0 §8` com decisão registrada | 10 de 10 |
| F0 | Casos de teste extraídos do SQL 010 para oráculo | ≥ 500 simulações reais cobrindo os 4 macroprodutos |
| F1 | Tempo de ciclo do pipeline (extração → BRP Cash ativada) | < 1 dia útil, sem passo manual |
| F1 | Divergência shadow de preço sugerido | ≤ 1% em ≥ 98% das simulações por produto cortado |
| F1 | Latência p95 de consulta/simulação | < 500 ms (RNF-02) |
| F1 | Simulações atendidas pelo motor | ≥ 1 produto em 100% até o marco M4 |
| F2 | Simulações atendidas pelo motor | 100% dos 4 macroprodutos até o marco M5 |
| F2 | Parâmetros de negócio sem código | 100% dos itens da lista consolidada de `A2` |
| F2 | Tempo de ciclo de publicação de parâmetro (rascunho → produção) | < 5 dias úteis, incluindo staging e aprovação |
| F2 | Mudanças de regra que exigiram deploy | 0 |
| F3 | Acordos registrados no grupo piloto | 100% das contratações do piloto |
| F3 | Desvios detectados com alerta entregue ao gerente | ≥ 95% no ciclo |
| F4 | Uplift previsto x realizado da onda piloto | Desvio ≤ 10% |
| F4 | Tempo de ciclo da onda (elegíveis → aprovação) | < 10 dias úteis |
| Todos | Disponibilidade do motor | ≥ 99,5% em horário comercial (RNF-01) |
| Todos | Execuções com versão de parâmetro e de BRP rastreável | 100% (RNF-09) |

## 9. Riscos e mitigação

| ID | Risco | Fase de maior exposição | Dono sugerido | Mitigação (conforme `A0 §10`) |
|---|---|---|---|---|
| R1 | Regras do preço sugerido não documentadas | F0, F1 | Precificação + arquitetura | Engenharia reversa na F0 (regra portada para o pipeline, não para o motor); oráculo de casos reais; shadow run na F1 |
| R2 | C2/C3 sem definição de negócio | F3, F4 | Produtos + Precificação | Discovery obrigatório antes de codificar; arquitetura por eventos e reuso do motor |
| R3 | Qualidade das bases de origem | F1, F5 | Dados/Databricks | Contrato de dados, validações e alertas no pipeline (RF-08) |
| R4 | Latência do preço vigente | F0, F1 | Arquitetura + Precificação | Adaptador com duas estratégias; decisão na F0 |
| R5 | Service Bus fora da stack | F0, F3 | Arquitetura corporativa | Validar na F0; fallback outbox + polling |
| R6 | Lógica vazando para Apex | F1, F2 | Squad Salesforce + arquitetura | Diretriz AD-05; revisão de código obrigatória |
| R7 | Erro de preço em produção na transição | F1, F2, F4 | Product owner + QA | Shadow, comparador, critérios de corte, rollback em três níveis |
| R8 | Capacidade das equipes | F0, F1 | Patrocinador + líderes de squad | Dimensionamento na F0; squads por capacidade; contratação antecipada |
| R9 | Inconsistências entre fluxos | F0 | Precificação | Decisões registradas no catálogo de parâmetros |
| R10 | Governança de publicação | F2 | Precificação + Comitê de Produto | Fluxo staging → aprovação → produção com alçadas (RF-06, RF-10) |

## 10. Premissas e dependências externas

- **Stack corporativa** conforme `A0 §6`: Salesforce FSC, Azure SQL, ARO, Axway, Databricks, Control-M (RNF-10). Nenhum componente novo além do Service Bus, que precisa de validação na F0 (AD-09).
- **Acesso ao Databricks** com as bases de origem já ingeridas e governadas (`00-doc-negocio.md:L27-30`); bases de negócio (RFP, acordos) continuam fora e entram por parametrização.
- **Preço vigente e histórico de 12 meses** disponíveis no Databricks (`L29`); a estratégia online do Adaptador depende de acesso ao sistema de tarifas.
- **Licenças e cotas**: Azure SQL zona-redundante, capacidade no ARO, licenças Salesforce para os perfis de parametrização; nenhuma licença de engine de regras prevista (AD-04).
- **Capacidade de times**: disponibilidade de desenvolvedores Java e Salesforce e de engenheiros de dados nas quantidades do §7; time de Precificação com dedicação parcial contínua.
- **Ambientes**: sandbox Salesforce e homologação Azure espelhando produção para o shadow.
- **Canais externos** definem e mantêm suas próprias interfaces (`L32`).

## 11. Próximos passos imediatos (30 dias)

1. Aprovar este roadmap e o `A0` no Comitê Executivo; nomear patrocinador, product owner e dono de negócio (Precificação).
2. Agendar as sessões de engenharia reversa do SQL 010 e da macro com Precificação; obter acesso de leitura ao servidor, ao SAS e ao workbook.
3. Extrair a primeira amostra de simulações reais da Calculadora para compor o oráculo do shadow run.
4. Abrir com arquitetura corporativa a validação do Azure Service Bus e, em paralelo, desenhar o fallback outbox.
5. Solicitar workspace Databricks, Azure SQL de desenvolvimento, namespaces no ARO, rotas no Axway e sandbox Salesforce.
6. Fechar com Precificação as definições de preço praticado, alvo e sugerido e a regra de alçada (`A0 §2`, lacuna 3).
7. Dimensionar os squads e confirmar disponibilidade para o início da F1 em 16/11/2026.
8. Definir com Produtos e OPCH o grupo piloto de gerentes e as regionais participantes.
