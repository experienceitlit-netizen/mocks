# 04 — Capacidades do Motor de Precificação Cash: descrição e rastreabilidade

| Campo | Valor |
|---|---|
| Título | Documento de capacidades: descrição e onde cada capacidade foi identificada nos documentos de negócio |
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Revisão 1.1 (2026-09-18) | Preço sugerido passa a ser lido da BRP Cash por cenário |
| Fontes | `docs-precificacao/00-doc-negocio.md`, `00-etapas-geracao-planilha-ano1.md`, `01-cobrança-fluxo.md`, `02-multipag-fluxo.md`, `03-pix-fluxo.md`, `04-arrecadação-fluxo.md`, `05-uplift-consolidado-fluxo.md`, `06-matriz-stickiness-impacto-fluxo.md`, `07-planilha-ano1-fluxo.md`; consolidação em `anexos/A0`, `anexos/A1` e `anexos/A2` |

---

## 1. Como ler este documento

Cada capacidade (C1, C2, C3), sub-capacidade (C1.1 a C1.6, C2.1 a C2.5, C3.1 a C3.4) e módulo transversal (M1 a M4) tem uma ficha com: identificação, descrição, status, atores, entradas, saídas, regras de negócio principais com os valores documentados, uma **tabela de rastreabilidade** e o grau de maturidade da definição de negócio. Na tabela de rastreabilidade, a coluna "Fonte" usa o formato `docs-precificacao/<arquivo>:L<linhas>` abreviado para `<nn>:L<linhas>` (por exemplo, `01:L112` é `docs-precificacao/01-cobrança-fluxo.md:L112`; `00-neg` é `00-doc-negocio.md` e `00-etapas` é `00-etapas-geracao-planilha-ano1.md`). O tipo de evidência é **explícita** quando o documento afirma o fato, e **inferida** quando o analista deduziu a relação com a capacidade. Status possíveis: **Prioritária / AS-IS funcional**, **Evolução** e **Transversal**. Maturidade: **Definida**, **Parcial** ou **Não definida**. A convenção do brief `anexos/A0` §11 vale aqui: C2 e C3 estão sempre marcadas como **[EVOLUÇÃO — a detalhar com o negócio]**.

## 2. Capacidade C1 — Cálculo, Simulação e Entrega de Preços

**Status:** Prioritária / AS-IS funcional (Calculadora Salesforce + SAS + SQL 010 + Planilha Preço Ano 1). **Bounded context:** Cálculo de Preço e Alçada e Aprovação (brief §5).

**Descrição.** Dado cliente, produto, volumetria e contexto, o motor classifica o cliente (tier pela volumetria, cluster por tier + segmento + região), consulta o cenário correspondente na BRP Cash e devolve o preço praticado (vigente), o preço alvo e o preço sugerido daquele cenário, os cenários vizinhos e o uplift, e, quando o preço negociado fica abaixo do sugerido, o nível de alçada e o papel aprovador. O sugerido não é calculado online: é produzido pelo pipeline por cenário e lido da BRP. É a capacidade que já opera hoje, com o cálculo espalhado entre notebooks Python, macro de planilha, premissas em Excel e o Motor da Calculadora no SQL 010.

**Atores:** gerente comercial (consome), aprovadores de alçada, time de Precificação (define regras), canais e integradores (consomem APIs).

**Entradas:** identificação do cliente ou grupo econômico, produto, volumetria informada ou observada, preço negociado; BRP Cash do ciclo ativo; parâmetros vigentes; preço vigente e histórico do legado.

**Saídas:** preço praticado, alvo e sugerido do cenário do cliente; cenários por percentil e por tier vizinho; uplift anual estimado (única conta online); nível de alçada e aprovador; registro auditável da execução.

### C1.1 Consulta de preço alvo, sugerido e praticado

| Item | Conteúdo |
|---|---|
| Descrição | Retornar, por cliente x produto, os três preços de referência. Alvo é o P75 do cluster com piso na tarifa atual; praticado é a tarifa observada ou de contrato; sugerido é o preço recomendado do cenário do cliente (produto x região x segmento x tier), pré-calculado no pipeline e publicado na BRP Cash (definição de trabalho, `anexos/A0` §2). O motor classifica o cliente e consulta o cenário; não calcula o sugerido. |
| Status | Prioritária / AS-IS funcional |
| Atores | Gerente comercial, Calculadora Salesforce, integradores |
| Entradas | Faixas de tier e regra de cluster (M1); Matriz de Cenários de Preço (MPA: alvo, sugerido e percentis por cenário); PPC (praticado, alvo e sugerido do cenário do cliente) |
| Saídas | Preço praticado, alvo e sugerido, com versão de BRP e de parâmetros |
| Regras principais | PREÇO_ALVO = max(TARIFA, P75 do cluster); nunca reduzir; N < 15 mantém tarifa atual; sugerido lido do cenário na BRP, gerado no pipeline pela macro "Preço por Produto" e premissas (`07:L30`, `L77-79`, `L112`); a derivação do sugerido a partir do alvo (desconto por saldo de IF, `06:L137`, custos, RFP, nichos) não está documentada e é regra do pipeline, não do motor |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L3` | Canais devem consultar online preço-alvo, sugerido, preço vigente e histórico | Explícita |
| `00-neg:L7` | Motor retorna sugestão de preço-alvo, preço vigente e histórico para clientes do Atacado | Explícita |
| `00-etapas:L1` | Planilha Ano 1 contém preço alvo, sugerido e praticado, dados por região, segmento, volumetria e produto | Explícita |
| `01:L108-116` | Regra de preço-alvo (max com P75) e fórmulas de uplift | Explícita |
| `01:L112`, `01:L133` | PREÇO_ALVO = P75 do cluster se maior que a tarifa atual; modelo nunca reduz | Explícita |
| `01:L19` | TARIFA_PRATICADA por grupo e produto como preço praticado | Explícita |
| `02:L19` | Tarifa vigente por contrato (mais recente por `dinic_vgcia`) como praticado em Multipag | Explícita |
| `02:L33`, `02:L52` | PRECO_ALVO e UPLIFT por grupo econômico | Explícita |
| `03:L26` | Tarifa praticada efetiva = RCTA / QTDE, última com QTDE > 0 | Explícita |
| `03:L33`, `03:L62` | Preço-alvo e uplift em PIX | Explícita |
| `03:L78` | PREÇO_ALVO bruto "sem nenhum abatimento por saldo de IF": o preço final tem desconto por relacionamento | Inferida |
| `04:L25-26`, `04:L76-80` | Tarifa praticada (RECEITA / QTDE) e preço-alvo por grupo, produto e tipo de documento | Explícita |
| `05:L5`, `05:L28-29` | `tabela_precos.xlsx` é a matriz de preços-alvo por produto, tier, segmento, região e cluster | Explícita |
| `05:L15-19`, `05:L38` | `base_total.xlsx` consolida TARIFA, PREÇO_ALVO e UPLIFT por cliente x produto | Explícita |
| `05:L100` | Os dois arquivos "servem de referência final para o Motor de Precificação" | Explícita |
| `06:L137` | "Preço alvo → Desconto por saldo de IF → Preço referência do cliente"; o desconto é calculado fora do notebook (etapa do pipeline/macro, não do motor) | Explícita |
| `07:L22-23` | Abas Tabela de Preços e Base Pricing | Explícita |
| `07:L30` | Macro atualiza "Preço por Produto" com preços consolidados por produto: origem do preço sugerido por cenário publicado na BRP Cash | Explícita (existência) / Inferida (como sugerido) |
| `07:L77-79` | `preco_alvo_por_cluster`, `preco_por_produto`, `premissas_alcada`, `premissas_desconto` enviados ao SAS: alvo e sugerido chegam à Calculadora já calculados, por cenário | Explícita |
| `07:L112` | `SIMUL_PRECO_POR_PRODUTO` atualizado a cada 6 meses: o sugerido por cenário tem cadência própria de publicação | Explícita |
| `07:L41`, `07:L114` | Motor da Calculadora (SQL 010) "contém regra de negócio" e alimenta a Calculadora | Explícita |

**Maturidade:** Parcial. Preço alvo está definido; praticado tem quatro origens diferentes por produto; sugerido existe por cenário na Planilha Ano 1 (`00-etapas:L1`; `07:L30`), mas a regra que o gera não está documentada. **Perguntas em aberto:** qual a regra exata da macro e do SQL 010; qual a tabela de desconto por saldo e se ela entra como dimensão do cenário ou exceção; se o praticado deve vir da BRP (foto) ou do legado online.

### C1.2 Simulação e cenários

| Item | Conteúdo |
|---|---|
| Descrição | Simular um preço para o cliente sem efetivar tarifa e expor cenários lidos da BRP Cash: cenário do cliente, faixas por percentil do cluster, cenários vizinhos por tier e uplift anual por cenário (única conta online). |
| Status | Prioritária / AS-IS funcional (simulação existe; cenários são extensão) |
| Atores | Gerente comercial |
| Entradas | Volumetria e preço negociado; MPA (cenários do ciclo ativo, `07:L30`, `L77-79`, `L112`); faixas de tier; regra de cluster |
| Saídas | Tabela de cenários com preço, receita e uplift |
| Regras principais | Cenários consultados na MPA (sem cálculo de preço online); uplift = (preço do cenário − tarifa) × quantidade anual se tarifa < 1.000, senão (preço do cenário / tarifa − 1) × receita; tiers por produto (ex.: Multipag ≤ 4.000 / ≤ 50.000 / > 50.000; PIX ≤ 100 / ≤ 500 / > 500) |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L3` | "possibilitar que outros canais consultem e simulem de forma online" | Explícita |
| `00-neg:L10` | Motor executa cálculos e permite simulações sem efetivação da tarifa | Explícita |
| `00-neg:L22` | Oferta ao cliente com valor de tarifa, tiers de volume e cluster conforme a jornada | Explícita |
| `07:L5`, `07:L40-42` | Calculadora Salesforce consulta preço, cluster, saldo e share para a equipe comercial | Explícita |
| `05:L20` | Sete percentis por cluster (P25 a P90) disponíveis como faixas | Inferida |
| `02:L54`, `04:L82` | Percentis alternativos calculados e mantidos, mas não usados no cálculo | Inferida |
| `01:L59-79`, `02:L30`, `03:L52-56`, `04:L45-48` | Faixas de tier por produto: base da sensibilidade a tier | Inferida |
| `01:L114-116`, `02:L52`, `03:L62`, `04:L79` | Fórmulas de uplift com limiar 1.000 | Explícita |
| `07:L30`, `07:L77`, `07:L112` | "Preço por Produto" / `preco_alvo_por_cluster` / `SIMUL_PRECO_POR_PRODUTO`: cenários por produto x tier x segmento x região de onde o motor lê o cenário do cliente e os vizinhos | Explícita (existência) / Inferida (uso como cenário) |
| `06:L137` | Desconto por saldo de IF: aplicado no pipeline dentro do sugerido por cenário, não como cenário calculado online | Inferida |

**Maturidade:** Parcial. A simulação é escopo explícito; os quatro cenários são proposta do brief §2 a validar. **Perguntas:** quais cenários a jornada de contratação sem alçada deve exibir; se o gerente pode alterar volumetria na simulação.

### C1.3 Cálculo de alçada e indicação do aprovador

| Item | Conteúdo |
|---|---|
| Descrição | Quando o preço negociado é menor que o sugerido, calcular o desvio (% e R$) e devolver o nível de alçada e o papel aprovador; se igual ou maior, contratação sem alçada. |
| Status | Prioritária / AS-IS funcional (existe `premissas_alcada`; regra não documentada) |
| Atores | Gerente comercial, aprovadores por nível |
| Entradas | Preço negociado, preço sugerido, `premissas_alcada` por produto, segmento e faixa de desvio |
| Saídas | Nível de alçada, papel aprovador, pedido de aprovação registrado |
| Regras principais | Não documentadas; definição de trabalho no brief §2 |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L21` | "Caso a funcionalidade de simulação de alçadas/calculadora faça parte do escopo" (dúvida registrada pelo negócio) | Explícita |
| `00-neg:L22` | Motor suporta níveis de aprovação (alçadas) para simulações da área comercial; fluxo acionado "sempre que houver relação ao preço sugerido"; cliente pode contratar sem alçada | Explícita |
| `00-neg:L35` | Perfis de acesso e alçadas definidos pelo time de Precificação | Explícita |
| `07:L79` | `premissas_alcada.xlsx` importado pelo SAS | Explícita |
| `07:L64` | Aba "Premissas" como regra de negócio | Inferida |

**Maturidade:** Parcial. O requisito é explícito; níveis, faixas e aprovadores não estão documentados. **Perguntas:** quantos níveis; critério (percentual, valor absoluto de uplift perdido ou ambos); se a alçada também vale para C2.

### C1.4 Consulta de preço vigente e histórico de 12 meses (legado)

| Item | Conteúdo |
|---|---|
| Descrição | Exibir o preço efetivamente vigente e a série dos últimos 12 meses do cliente no produto, vindos do legado. |
| Status | Prioritária / AS-IS funcional (foto no ciclo; sem consulta online) |
| Atores | Gerente comercial, integradores |
| Entradas | Cliente ou grupo, produto; foto no Databricks ou consulta online ao sistema de tarifas |
| Saídas | Tarifa vigente com data, série mensal de 12 meses |
| Regras principais | Versão mais atual e histórico de 12 meses disponíveis no Databricks |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L11` | Motor consultará a base legada para exibir o preço vigente | Explícita |
| `00-neg:L12` | Motor consultará a base legada para exibir o histórico de preços | Explícita |
| `00-neg:L29` | Preços vigentes com a versão mais atual no Databricks e histórico de 12 meses | Explícita |
| `00-neg:L16` | APIs fornecem a informação mais atualizada disponível no momento da requisição | Explícita |
| `02:L18-19` | Tarifa vigente vem de `contratos_multipag.csv`, contrato mais recente por vigência | Explícita |
| `01:L17` | Histórico LTM de 13 meses depende de base histórica | Inferida |
| `07:L89`, `07:L112` | Tabelas SAS versionadas por mês (`_AAAAMM`): histórico implícito | Inferida |

**Maturidade:** Definida quanto ao requisito; Parcial quanto ao mecanismo. **Pergunta:** latência aceitável (foto x online), brief §8 item 7.

### C1.5 APIs para canais (Salesforce e outros)

| Item | Conteúdo |
|---|---|
| Descrição | Expor consulta e simulação como APIs para a Calculadora Salesforce e para outros canais, plataformas, integradores e processos, com a informação mais atual disponível. |
| Status | Prioritária / AS-IS funcional (só Salesforce, via SAS e SQL 010) |
| Atores | Salesforce FSC, canais e integradores |
| Entradas | Requisições autenticadas | 
| Saídas | Respostas de C1.1 a C1.4 |
| Regras principais | Canais são responsáveis pelas próprias interfaces; lógica fica no motor |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L15` | Disponibilização de APIs para canais, plataformas, sistemas integradores e processos usuários | Explícita |
| `00-neg:L16` | APIs com a informação mais atualizada disponível | Explícita |
| `00-neg:L31-32` | Consumidores usarão as APIs e cuidam das próprias interfaces | Explícita |
| `07:L114` | Arquitetura atual: Salesforce → Motor da Calculadora (SQL 010) → tabelas SAS | Explícita |
| `07:L34-36` | Distribuição atual por cópia manual e query SAS manual | Explícita |

**Maturidade:** Definida. **Pergunta:** quais outros canais serão os primeiros consumidores além do Salesforce.

### C1.6 Rastreabilidade das execuções

| Item | Conteúdo |
|---|---|
| Descrição | Registrar cada consulta, simulação e pedido de alçada com entradas, saídas, usuário, versão de parâmetros e de BRP Cash usadas. |
| Status | Prioritária / AS-IS inexistente |
| Atores | Auditoria, time de Precificação |
| Entradas | Eventos de execução do motor |
| Saídas | Trilha imutável consultável |
| Regras principais | Rastreabilidade completa das execuções e dos responsáveis por alterações de parâmetros |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L14` | Registrar rastreabilidade completa das execuções (logs de auditoria) e responsáveis pelas alterações de parâmetros | Explícita |
| `00-neg:L20` | Monitoramento das execuções, integrações e falhas | Explícita |
| `00-neg:L40` | Requisitos de segurança, auditoria e conformidade seguem padrões institucionais | Explícita |
| `07:L18-42` | Processo manual em planilha sem versionamento nem log (ausência registrada em `anexos/A2` §Fluxo 07 item 9) | Inferida |

**Maturidade:** Definida quanto ao requisito. **Pergunta:** prazo de retenção da trilha.

## 3. Capacidade C2 — Onda de Reprecificação [EVOLUÇÃO — a detalhar com o negócio]

**Status:** Evolução. **Bounded context:** Reprecificação (brief §5).

**Descrição.** Ciclo periódico em que o time de Precificação seleciona clientes elegíveis, calcula o novo preço por cliente reusando o motor de C1 com gradação por Stickiness x Impacto, submete à alçada, comunica e efetiva a tarifa, e acompanha o uplift realizado. Hoje existe como "Onda" (a documentação está na quarta) e como a Saída 1 manual do fluxo 07.

**Atores:** time de Precificação (planeja e executa), aprovadores, gerente comercial (comunica), cliente.

**Entradas:** PPC com uplift potencial, Matriz de Relacionamento, elegibilidade de C3, listas de exceção, calendário.

**Saídas:** lista de novos preços aprovados, comunicação, tarifa efetivada (ou recomendação), acompanhamento.

### C2.1 Planejamento da onda

| Item | Conteúdo |
|---|---|
| Descrição | Definir escopo (produtos, segmentos, regiões), calendário e metas de uplift do ciclo. |
| Status | Evolução |
| Atores | Time de Precificação, diretoria |
| Entradas | Soma de uplift potencial por produto e cluster; cadência dos insumos |
| Saídas | Plano da onda (escopo, datas, meta) |
| Regras principais | Não documentadas |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `01:L124` | Arquivo de uplift "serve de insumo para a decisão de repreficação de cobrança da Onda 3 do Pricing Cash" | Explícita |
| `02:L5`, `02:L58`; `03:L5`, `03:L68`; `04:L5`, `04:L86` | Bases finais são insumo para reprecificação da Onda 3 em Multipag, PIX e Arrecadação | Explícita |
| `07:L18` | Pasta `03_modelo_onda_4`: o processo é executado por ondas | Explícita |
| `05:L38-39` | UPLIFT por cliente e soma total: quantificação do potencial da onda | Inferida |
| `07:L112` | Preço por produto atualizado a cada 6 meses: cadência candidata do ciclo | Inferida |
| `07:L53` | Aba "Datas de Reprecificação" | Explícita |

**Maturidade:** Não definida. **Perguntas:** periodicidade; quem define meta e escopo.

### C2.2 Seleção de elegíveis

| Item | Conteúdo |
|---|---|
| Descrição | Selecionar clientes x produtos que entram na onda: entrada de C3 (desvio de reciprocidade) mais filtros de exclusão e contexto comercial. |
| Status | Evolução |
| Atores | Time de Precificação; C3 (evento) |
| Entradas | PPC, eventos de C3, listas de exceção (M1) |
| Saídas | Lista de elegíveis com motivo |
| Regras principais | Exclusões já aplicadas no pipeline: poder público; grupo 616 ou Bradesco; CD_GRUPO = 0; N < 15; QTD_MENSAL > 0 (Cobrança); RCTA ≥ 0 e CD_TARF em {5518, 5517, 5534, 5563} (PIX); Tipo_Documento = DIVERSOS (Arrecadação). Listas manuais sem regra documentada. |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `01:L120`; `02:L52`; `03:L62`; `04:L80` | N < 15 mantém tarifa atual e zera uplift: cluster pouco representativo fica fora | Explícita |
| `01:L9`; `02:L22-24`; `03:L20-22`; `04:L19-21` | Exclusão de poder público | Explícita |
| `01:L14`; `02:L25`; `03:L23`; `04:L27` | Exclusão do grupo Bradesco / grupo 616 | Explícita |
| `01:L26` | Gateway QTD_MENSAL > 0 | Explícita |
| `03:L24-25` | Escopo de tarifa PIX Pagamentos e exclusão de receita negativa | Explícita |
| `04:L35` | Recorte DIVERSOS como público da onda | Inferida |
| `05:L37` | Exclusão de CD_GRUPO = 0 | Explícita |
| `06:L33` | Segmentos de atacado elegíveis (5, sem INSTITUCIONAL) | Explícita |
| `07:L52-56` | Listas manuais: Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos | Explícita (existência) / Inferida (papel de filtro) |
| `07:L58-60` | Associações Religiosas via extração | Explícita (existência) / Inferida (papel) |
| `00-neg:L27` | Bases de negócio (RFP, acordos de parceria) ficam fora do Databricks | Explícita |

**Maturidade:** Parcial (exclusões técnicas definidas; critérios comerciais não). **Perguntas:** papel de cada lista; prazo de "negociação recente"; se nichos e associações religiosas são exclusão ou preço diferenciado.

### C2.3 Cálculo do novo preço por cliente

| Item | Conteúdo |
|---|---|
| Descrição | Reusar `svc-pricing` em lote para os elegíveis e aplicar gradação por Stickiness x Impacto ("reajustes graduais"). |
| Status | Evolução |
| Atores | Time de Precificação |
| Entradas | Elegíveis, PPC, Matriz de Relacionamento, parâmetros de gradação |
| Saídas | Novo preço por cliente x produto, uplift esperado, parcelas ou etapas |
| Regras principais | Stickiness = max(score cash, score crédito) com faixas 0,1 / 0,4 / 0,7 e rótulos Baixo a Alto; Impacto = max(score ROB, score receita cash) com faixas por segmento e rótulos Baixo/Médio/Alto; a tradução da matriz em gradação não está documentada |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `03:L79`; `05:L111` | Passo 4 da metodologia: "Planejar reajustes graduais (matriz Probabilidade de retenção x Impacto)" | Explícita |
| `06:L131`, `06:L138` | Fluxo 06 evidencia o passo 4 via Stickiness como probabilidade de retenção (texto truncado) | Explícita |
| `06:L5`, `06:L127` | As três bases são "insumos de priorização e diagnóstico de relacionamento para o Motor" | Explícita |
| `06:L62-93` | Scores de crédito e cash, stickiness e rótulos | Explícita |
| `06:L95-123` | Scores de ROB e receita de cash, impacto e rótulos | Explícita |
| `07:L25` | Aba "Stikiness e Impacto" na planilha | Explícita |
| `05:L38` | UPLIFT como valor único por registro, sem gradação | Explícita |
| `03:L81`; `05:L113` | Passos 3 e 4 "fazem parte de etapas subsequentes do processo de negócio" | Explícita |

**Maturidade:** Parcial (classificação definida; uso não). **Perguntas:** função gradação(stickiness, impacto) → percentual ou parcelas; teto de reajuste por ciclo.

### C2.4 Aprovação (alçada) e comunicação

| Item | Conteúdo |
|---|---|
| Descrição | Submeter a onda (ou exceções por cliente) à alçada, registrar decisões e comunicar cliente e gerente. |
| Status | Evolução |
| Atores | Aprovadores, time de Precificação, gerente comercial |
| Entradas | Novos preços, regra de alçada |
| Saídas | Preços aprovados, comunicações emitidas |
| Regras principais | Não documentadas |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `03:L81`; `05:L113` | "Comunicar e implementar novos preços" como etapa manual/comercial posterior | Explícita |
| `07:L33` | Saída 1: ações de reprecificação decididas manualmente pela equipe de Precificação | Explícita |
| `00-neg:L22` | Alçada definida para simulações comerciais; extensão à onda | Inferida |
| `00-neg:L37` | Aprovação e publicação seguem processo de governança | Inferida |

**Maturidade:** Não definida. **Perguntas:** quem aprova a onda; canal de comunicação ao cliente.

### C2.5 Efetivação no legado e acompanhamento do resultado

| Item | Conteúdo |
|---|---|
| Descrição | Registrar a nova tarifa no sistema de tarifas ou contratos e acompanhar uplift realizado x estimado e churn. |
| Status | Evolução |
| Atores | Time de Precificação, operações, legado |
| Entradas | Preços aprovados |
| Saídas | Tarifa efetivada ou recomendação; indicadores de resultado |
| Regras principais | Não documentadas; premissa atual é simulação sem efetivação |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `07:L33` | Ações de reprecificação "dependentes de intervenção manual" encerram o fluxo | Explícita |
| `03:L81` | "Implementar novos preços" fora do escopo dos notebooks | Explícita |
| `00-neg:L10` | Motor permite simulação **sem efetivação** da tarifa (delimita o escopo atual) | Explícita |
| `02:L19` | Tarifa vive em contrato com vigência: efetivar implica alterar contrato | Inferida |
| `07:L53` | Datas de Reprecificação como registro de quando cada cliente foi reprecificado | Inferida |
| `05:L39` | Soma de UPLIFT como estimativa, sem contrapartida de realizado | Inferida |

**Maturidade:** Não definida. **Pergunta central:** o motor efetiva ou só recomenda (brief §8 item 4).

## 4. Capacidade C3 — Gestão de Reciprocidade [EVOLUÇÃO — a detalhar com o negócio]

**Status:** Evolução. **Bounded context:** Reciprocidade (brief §5). Capacidade própria, não sub-capacidade de C2 (avaliação em `03-desenho-conceitual.md` §6.4).

**Descrição.** Registrar a contrapartida acordada com o cliente na negociação (volumetria, saldo, produtos), monitorar o realizado com os Indicadores de Reciprocidade, detectar desvios conforme tolerâncias parametrizáveis e gerar elegibilidade para C2 e alertas ao gerente. Nenhum documento fonte descreve o acordo; só os indicadores realizados existem.

**Atores:** gerente comercial (dono do acordo), time de Precificação, C2 (consumidor do evento).

**Entradas:** acordo registrado; Indicadores de Reciprocidade por ciclo; regras e tolerâncias.

**Saídas:** situação acordado x realizado; eventos de desvio e elegibilidade; alertas.

### C3.1 Registro do acordo

| Item | Conteúdo |
|---|---|
| Descrição | Guardar, na contratação (C1) ou na onda (C2), a contrapartida acordada: tier de volume, saldo IF/DAV mínimo, produtos contratados, preço concedido e vigência. |
| Status | Evolução |
| Atores | Gerente comercial |
| Entradas | Resultado da negociação |
| Saídas | Acordo versionado por cliente x produto |
| Regras principais | Não documentadas |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L22` | Contratação oferece tarifa, tiers de volume e cluster: o tier assumido é candidato a "volumetria acordada" | Inferida |
| `00-neg:L27` | Bases de negócio como "RFP, acordos de parceria" existem fora do Databricks | Explícita (existência) / Inferida (como acordo) |
| `02:L19` | Contrato com tarifa (`vtarif`) e vigência (`dinic_vgcia`): ponto de ligação com o acordo comercial | Inferida |
| `07:L54` | Aba RFPs: preços acordados em concorrência | Inferida |

**Maturidade:** Não definida. **Perguntas:** o que compõe o acordo e onde é registrado hoje.

### C3.2 Monitoramento do realizado

| Item | Conteúdo |
|---|---|
| Descrição | Acompanhar por grupo econômico e produto a volumetria e o relacionamento efetivamente entregues. |
| Status | Evolução (indicadores já são calculados) |
| Atores | Pipeline (M2), gerente comercial |
| Entradas | Emissões L3M, saldo médio IF e DAV, SoW de boletos, share de cash, tier realizado |
| Saídas | Indicadores de Reciprocidade por ciclo |
| Regras principais | SOW_BOLETOS = QTDE_COB_BRAD / QTDE_COB_TOTAL; SHARE_CASH = QTDE_CASH_BRAD / QTDE_CASH_TOTAL (−1 se total = 0); saldo médio IF/DAV por segmento e grupo; janelas 3 meses (IF/DAV, share de cash) e 12 meses (boletos) |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `06:L44-51` | Saldo médio de Invest Fácil e DAV por grupo (`saldo.xlsx`) | Explícita |
| `06:L52-56` | Share of wallet de boletos por grupo, com quantidade na concorrência | Explícita |
| `06:L23-27`, `06:L32` | Share de cash Bradesco x concorrência | Explícita |
| `06:L127` | Bases servem como "diagnóstico de relacionamento" | Explícita |
| `07:L24`, `07:L75` | Emissões L3M enviadas à Calculadora: volumetria realizada recente | Explícita |
| `07:L83-85` | Saldo DAV, saldo IF e share de boletos por GE consultados na simulação | Explícita |
| `00-etapas:L5-8` | Janelas: IF 3 meses, DAV 3 meses, share de boletos 12 meses | Explícita |
| `01:L16-17` | Indicadores L3M e LTM permitem acompanhar evolução de volume | Inferida |
| `02:L26`, `02:L30`; `03:L26`, `03:L30`; `04:L26`, `04:L29` | Volume médio mensal ou anual realizado por grupo como base de tier | Inferida |
| `03:L78` | Saldo médio de Invest Fácil como medida de relacionamento (contrapartida) | Inferida |

**Maturidade:** Parcial (indicadores definidos; uso como "realizado do acordo" não). **Pergunta:** QTDE_CASH_CONC e QTDE_COB_CONC devem entrar no monitoramento (brief §8 item 10).

### C3.3 Detecção de desvio

| Item | Conteúdo |
|---|---|
| Descrição | Comparar acordado x realizado com regras e tolerâncias parametrizáveis (por exemplo, queda de tier ou saldo abaixo do mínimo por N meses consecutivos). |
| Status | Evolução |
| Atores | Job periódico de C3, time de Precificação (parametriza) |
| Entradas | Acordo, Indicadores de Reciprocidade, tolerâncias |
| Saídas | Desvios classificados |
| Regras principais | Não documentadas |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `05:L50`, `05:L62-94` | Tier é dimensão primária do cluster: mudança de volumetria altera tier, cluster e preço-alvo | Inferida |
| `07:L65`, `07:L76` | Tears de Volume / `tier_por_produto`: faixas de volume acordadas x realizadas | Inferida |
| `06:L32` | Sentinela −1 para cliente sem cash: sinal de ausência de relacionamento | Inferida |
| `anexos/A1` síntese (L647) | "Não há evidência direta de gestão de reciprocidade (volumetria acordada x realizada)" | Explícita (ausência) |

**Maturidade:** Não definida. **Perguntas:** tolerâncias, persistência, periodicidade.

### C3.4 Geração de elegibilidade para C2 e alertas ao gerente

| Item | Conteúdo |
|---|---|
| Descrição | Publicar o evento ClienteElegivelParaReprecificacao e alertar o gerente para renegociar ou retirar o desconto por relacionamento. |
| Status | Evolução |
| Atores | Gerente comercial, C2 |
| Entradas | Desvios de C3.3 |
| Saídas | Eventos, alertas, sugestão de ação |
| Regras principais | Não documentadas |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `06:L5`, `06:L127` | Bases do fluxo 06 como "insumos de priorização" para o Motor | Explícita |
| `00-neg:L38` | Integrações geram alertas aos canais, jornadas e processos consumidores | Explícita (genérica) |
| `07:L52` | Negociações Recentes: impede reprecificar quem acabou de negociar (regra de supressão de alerta) | Inferida |
| `06:L137` | Desconto por saldo de IF: consequência natural do desvio é rever o desconto | Inferida |

**Maturidade:** Não definida. **Pergunta:** consequência do desvio (onda, desconto, alerta).

## 5. Módulos transversais

### M1 Parametrização

| Item | Conteúdo |
|---|---|
| Descrição | Manter, versionar, testar em staging, aprovar e publicar (imediato ou agendado) todos os parâmetros de negócio do motor e do pipeline: catálogo, domínios, tiers, cluster, percentis, premissas, exceções e janelas. |
| Status | Transversal (necessário desde C1) |
| Atores | Analistas e aprovadores do time de Precificação |
| Entradas | Alterações de parâmetro, resultados de simulação em staging |
| Saídas | Versões publicadas com vigência, trilha de auditoria |
| Regras principais | Rascunho → staging → aprovado → publicado/agendado → expirado; controle de acesso por perfil e alçada |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L8` | Capacidade de parametrização e modelo de novos produtos e serviços | Explícita |
| `00-neg:L9` | Funcionalidades de parametrização para calibração e ajuste de regras | Explícita |
| `00-neg:L13` | Interfaces de parametrização com versionamento e controle | Explícita |
| `00-neg:L17` | Ambiente de staging para testar parametrizações antes da produção | Explícita |
| `00-neg:L18` | Controle de acesso à parametrização por perfis e alçadas | Explícita |
| `00-neg:L26`, `L33`, `L35` | Time de Precificação define regras, produtos, segmentos, perfis e alçadas | Explícita |
| `00-neg:L36-37` | Teste em staging obrigatório; aprovação e publicação por governança | Explícita |
| `00-neg:L42` | Publicação imediata ou vigência agendada | Explícita |
| `01:L61`, `01:L63-79` | Limites de tier "definidos empiricamente por produto" | Explícita |
| `01:L85-92`; `05:L56-96` | Regra de cluster em código, com produto sem cluster | Explícita |
| `01:L96-100`, `01:L116`, `01:L120` | Percentis, precedência do cummin, limiar 1.000 e N < 15 | Explícita |
| `02:L15`, `L17`, `L30-31`, `L40-46`, `L50-52` | Listas, datas, faixas, de-para e thresholds no notebook Multipag | Explícita |
| `03:L16`, `L19`, `L24`, `L52-56`, `L60-62` | Janela, listas, códigos de tarifa, faixas e thresholds em PIX | Explícita |
| `04:L22`, `L28`, `L45-48`, `L54-61`, `L67`, `L79-80` | De-para mídia, produtos, faixas e thresholds em Arrecadação | Explícita |
| `05:L25`, `L45-54` | Listas fixas de produtos, tiers, segmentos e regiões | Explícita |
| `06:L17`, `L26` | Datas literais de janela (202506; 2026-03 a 05) | Explícita |
| `06:L19`, `L73`, `L99-113`, `L68-71`, `L79-82` | Lista de produtos cash, limiares monetários por segmento, faixas de score | Explícita |
| `07:L62-65` | Abas Premissas e Tears de Volume como regra de negócio em planilha | Explícita |
| `07:L78-80` | Premissas de alçada, desconto e remuneração em arquivos separados | Explícita |
| `07:L48-60` | Listas manuais de exceção | Explícita |
| `07:L89`, `L112` | Mês de referência e cadência mensal/semestral | Explícita |

**Maturidade:** Definida quanto ao requisito; Parcial quanto ao conteúdo (premissas desconhecidas). **Perguntas:** matriz de aprovação por tipo de parâmetro; granularidade de vigência (por produto, por ciclo).

### M2 Preparação de Dados (Pipeline → BRP Cash)

| Item | Conteúdo |
|---|---|
| Descrição | Portar os sete notebooks para Databricks Workflows, gerar a BRP Cash versionada por ciclo (MPA, PPC, Matriz de Relacionamento, Indicadores de Reciprocidade), validar qualidade e publicar por reverse ETL na base de serviço do motor. |
| Status | Transversal (necessário desde C1) |
| Atores | Engenharia de dados, time de Precificação (valida o ciclo) |
| Entradas | Bases no Databricks; parâmetros de M1 |
| Saídas | BRP Cash ativa por `anomes` |
| Regras principais | Encadeamento dos fluxos 01 a 07; fallback para combinação sem cluster (lacuna); validações antes da ativação |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L27` | Dados para cálculo e consulta disponibilizados pelo Databricks (exceto bases de negócio) | Explícita |
| `00-neg:L28`, `L30` | Governança de ingestão; motor não substitui as bases | Explícita |
| `00-neg:L19` | Validações das informações recebidas e alertas na leitura das bases | Explícita |
| `00-etapas:L3-20` | Lista das 14 bases e janelas usadas para montar a planilha | Explícita |
| `07:L17-20` | Extração SQL/Databricks e execução sequencial dos 7 scripts | Explícita |
| `07:L21-27` | Cópia manual das saídas para abas (a eliminar) | Explícita |
| `05:L98-100` | `tabela_precos` e `base_total` como referência final para o Motor | Explícita |
| `06:L127` | Três bases de relacionamento como insumo do Motor | Explícita |
| `05:L28`, `L96` | Merge inner descarta combinações sem percentil: exige regra de fallback | Explícita |
| `05:L17`, `L21`, `L31` | Percentis da Arrecadação completa; uplift da Diversos; divisor 12 | Explícita |
| `07:L89`, `L112` | Versionamento mensal por `anomes` | Explícita |

**Maturidade:** Parcial (etapas definidas; contrato de dados e validações a especificar). **Perguntas:** fallback de cluster; fonte de CANAIS DIGITAIS e DÉBITO AUTOMÁTICO; INSTITUCIONAL.

### M3 Legado e Base Histórica

| Item | Conteúdo |
|---|---|
| Descrição | Manter no legado o preço vigente, o histórico de 12 meses, as tarifas de contrato e o cadastro de segmentos e grupo econômico; acessar via Adaptador de Legado; desligar gradualmente SAS, SQL 010 e Planilha. |
| Status | Transversal (necessário desde C1) |
| Atores | Sistemas de origem, engenharia de dados |
| Entradas | Bases dos sistemas de origem |
| Saídas | Preço vigente e histórico; cadastro; contratos |
| Regras principais | Versão mais atual no Databricks com 12 meses; implantação gradual em paralelo |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L11-12`, `L29` | Preço vigente e histórico de 12 meses no legado via Databricks | Explícita |
| `00-neg:L41` | Implantação gradual por pilotos | Explícita |
| `00-etapas:L5-18` | Bases de origem: IF, DAV, segmentos, share de boletos, movimento e eventos tarifados por produto, ROB, regionalidade | Explícita |
| `01:L5`, `L55`; `01:L7`, `L18`; `01:L17` | Eventos tarifados com nomenclatura do sistema bancário; bases de segmentos e UF; histórico de 13 meses | Explícita |
| `02:L15-18`, `L22`, `L27`; `02:L19` | Cinco CSVs legados; base de contratos e vigência | Explícita |
| `03:L15`, `L17`, `L20`, `L27` | Quatro CSVs legados; código morto indica layout instável | Explícita |
| `04:L15-16`, `L17`, `L19` | Base com colunas legadas (GERCTA, GERCASH) e formatação brasileira | Explícita |
| `05:L15-19`, `L30-33` | Bases `*_vats` derivadas de movimento 12 meses; TARIFA como preço vigente | Inferida |
| `06:L15`, `L23`, `L29`, `L44-45`, `L52`; `06:L30`, `L47` | ROB histórico, shares e saldos; trechos comentados por layouts instáveis | Explícita |
| `07:L17-18`; `07:L37-42`, `L100-114` | Extração de todas as bases; cadeia SAS → SQL 010 → Salesforce como legado de distribuição | Explícita |

**Maturidade:** Definida quanto ao que continua; Parcial quanto ao mecanismo de acesso (latência).

### M4 Governança, Auditoria e Segurança

| Item | Conteúdo |
|---|---|
| Descrição | Logs de auditoria de execuções e parâmetros, perfis e alçadas de usuário, monitoramento de execuções e integrações, contingência para o motor offline, conformidade institucional. |
| Status | Transversal |
| Atores | Segurança, auditoria, operações, time de Precificação |
| Entradas | Eventos do motor, do pipeline e da parametrização |
| Saídas | Trilhas, alertas, planos de contingência |
| Regras principais | Padrões institucionais vigentes |

Rastreabilidade:

| Fonte | Trecho / evidência resumida | Tipo |
|---|---|---|
| `00-neg:L14` | Rastreabilidade completa das execuções e responsáveis por alterações | Explícita |
| `00-neg:L18` | Controle de acesso por perfis e alçadas | Explícita |
| `00-neg:L20` | Monitoramento de execuções, integrações e falhas | Explícita |
| `00-neg:L35` | Usuários, perfis e alçadas definidos pelo time de Precificação | Explícita |
| `00-neg:L37` | Governança de aprovação e publicação | Explícita |
| `00-neg:L38` | Alertas aos consumidores quando integrações falham | Explícita |
| `00-neg:L39` | Estratégia de contingência com o motor offline | Explícita |
| `00-neg:L40` | Segurança, auditoria e conformidade conforme padrões institucionais | Explícita |
| `00-neg:L41` | Implantação gradual, pilotos e grupos de teste | Explícita |
| `07:L18`, `L21`, `L37` | Caminhos de rede e cópia manual sem controle de acesso ou trilha (ausência) | Inferida |

**Maturidade:** Definida quanto ao requisito. **Pergunta:** SLA de contingência e o que a Calculadora exibe quando o motor está fora (AD-13).

## 6. Matriz resumo: capacidade x documento fonte

"X" indica ao menos uma evidência explícita; "(x)" indica apenas evidência inferida.

| Capacidade | 00-neg | 00-etapas | 01 Cobrança | 02 Multipag | 03 PIX | 04 Arrecadação | 05 Uplift Cons. | 06 Stickiness | 07 Planilha |
|---|---|---|---|---|---|---|---|---|---|
| C1.1 Consulta alvo/sugerido/praticado | X | X | X | X | X | X | X | X | X |
| C1.2 Simulação e cenários | X | | (x) | (x) | (x) | (x) | (x) | (x) | X |
| C1.3 Alçada e aprovador | X | | | | | | | | X |
| C1.4 Preço vigente e histórico | X | | (x) | X | | | | | (x) |
| C1.5 APIs para canais | X | | | | | | | | X |
| C1.6 Rastreabilidade | X | | | | | | | | (x) |
| C2.1 Planejamento da onda | | | X | X | X | X | (x) | | X |
| C2.2 Seleção de elegíveis | X | | X | X | X | X | X | X | X |
| C2.3 Novo preço com gradação | | | | | X | | X | X | X |
| C2.4 Aprovação e comunicação | (x) | | | | X | | X | | X |
| C2.5 Efetivação e acompanhamento | X | | | (x) | X | | (x) | | X |
| C3.1 Registro do acordo | X | | | (x) | | | | | (x) |
| C3.2 Monitoramento do realizado | | X | (x) | (x) | (x) | (x) | | X | X |
| C3.3 Detecção de desvio | | | | | | | (x) | (x) | (x) |
| C3.4 Elegibilidade e alertas | X | | | | | | | X | (x) |
| M1 Parametrização | X | | X | X | X | X | X | X | X |
| M2 Preparação de dados | X | X | | | | | X | X | X |
| M3 Legado e histórico | X | X | X | X | X | X | (x) | X | X |
| M4 Governança e auditoria | X | | | | | | | | (x) |

Leitura: C1 e os módulos transversais têm base explícita no documento de negócio; C2 tem evidência de existência (a "Onda") em todos os fluxos de produto, mas de regra apenas nos fluxos 03, 05 e 06 e de forma truncada; C3 é a única capacidade cuja evidência é quase toda inferida, o que confirma seu status de evolução e a necessidade do discovery da fase F3.

## 7. Requisitos do brief §7 mapeados para capacidades

| Requisito | Descrição resumida | Fonte | Capacidade principal | Capacidades de apoio |
|---|---|---|---|---|
| RF-01 | Retornar preço alvo, sugerido e praticado por cliente x produto | `00-neg:L7` | C1.1 | M2, M3 |
| RF-02 | Simular sem efetivar; expor cenários | `00-neg:L10`; brief §2 | C1.2 | C1.1, M1 |
| RF-03 | Calcular alçada e indicar aprovador; contratação sem alçada no sugerido | `00-neg:L22` | C1.3 | C2.4, M4 |
| RF-04 | Consultar preço vigente e histórico de 12 meses no legado | `00-neg:L11-12`, `L29` | C1.4 | M3 |
| RF-05 | Parametrizar regras com versionamento e controle | `00-neg:L8-9`, `L13` | M1 | M4 |
| RF-06 | Staging; publicação imediata ou agendada | `00-neg:L17`, `L42` | M1 | M4 |
| RF-07 | APIs para canais com informação mais atual | `00-neg:L15-16` | C1.5 | C1.4, M3 |
| RF-08 | Validar dados de entrada e alertar problemas nas bases | `00-neg:L19` | M2 | M4 |
| RF-09 | Auditoria de execuções e de alterações de parâmetros | `00-neg:L14` | C1.6 | M1, M4 |
| RF-10 | Controle de acesso por perfil e alçada na parametrização | `00-neg:L18` | M4 | M1 |
| RF-11 | Onda de reprecificação: elegibilidade, cálculo, aprovação, efetivação, acompanhamento | Evolução | C2.1 a C2.5 | C1, C3, M1 |
| RF-12 | Reciprocidade: acordo, monitoramento, desvio, elegibilidade | Evolução | C3.1 a C3.4 | M2, C2 |
| RF-13 | Pipeline gerando a BRP Cash versionada por ciclo | `00-neg:L27`; `00-etapas` | M2 | M1, M3 |
| RNF-01 | Disponibilidade e contingência | `00-neg:L39` | M4 | C1.5 |
| RNF-02 | Desempenho da consulta online (p95 < 500 ms, a validar) | Meta de trabalho | C1.1, C1.2 | M2 (reverse ETL) |
| RNF-03 | Rastreabilidade e auditoria imutável | `00-neg:L14`, `L40` | C1.6, M4 | M1 |
| RNF-04 | Segurança e conformidade institucional | `00-neg:L40` | M4 | C1.5 |
| RNF-05 | Monitoramento de execuções, integrações e falhas | `00-neg:L20` | M4 | M2 |
| RNF-06 | Governança de dados (Databricks; não substituir origens) | `00-neg:L28`, `L30` | M2 | M3 |
| RNF-07 | Escalabilidade a novos produtos e segmentos sem código | `00-neg:L8` | M1 | M2 |
| RNF-08 | Implantação gradual com execução paralela ao legado | `00-neg:L41` | M3 | C1, M4 |
| RNF-09 | Versionamento e reprodutibilidade dos cálculos | Derivado de `00-neg:L13-14` | M1, M2 | C1.6 |
| RNF-10 | Aderência à stack corporativa | `stack-tech.md` | Todas | — |

## 8. Síntese de maturidade

| Capacidade / módulo | Maturidade | Principal lacuna |
|---|---|---|
| C1.1 | Parcial | Regra do pipeline que gera o sugerido por cenário (macro "Preço por Produto", SQL 010, `premissas_desconto`); o motor só faz lookup |
| C1.2 | Parcial | Cenários a validar |
| C1.3 | Parcial | Conteúdo de `premissas_alcada` |
| C1.4 | Definida (requisito) | Latência foto x online |
| C1.5 | Definida | Canais além do Salesforce |
| C1.6 | Definida (requisito) | Retenção |
| C2.1 a C2.5 | Não definida / Parcial | Elegibilidade comercial, gradação, efetivação |
| C3.1 a C3.4 | Não definida / Parcial | Conceito de acordo, tolerâncias, consequência |
| M1 | Definida (requisito), Parcial (conteúdo) | Premissas desconhecidas; INSTITUCIONAL; cluster de Arrecadação |
| M2 | Parcial | Contrato de dados, fallback de cluster, fontes de CANAIS DIGITAIS e DÉBITO AUTOMÁTICO |
| M3 | Definida (escopo) | Estratégia do Adaptador de Legado |
| M4 | Definida (requisito) | SLA de contingência |
