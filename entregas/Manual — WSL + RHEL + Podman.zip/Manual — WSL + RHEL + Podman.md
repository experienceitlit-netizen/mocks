# Manual — WSL + RHEL + Podman no Bradesco

Nov 9, 2026 · @Italo

## 1. Visão geral

Stack: Windows 11 → WSL 2 (2.4.11, loja interna) → **RHEL** (imagem do banco) → **Podman** rootless → imagens do **JFrog** (`artefatos.bradesco.com.br`). Docker Hub, quay, ghcr etc. estão bloqueados no `registries.conf` do banco.

Toda a config fica em 3 arquivos no meu usuário. Não mexi em nada gerenciado pelo banco.

| Arquivo | Para quê |
| --- | --- |
| `~/.config/containers/containers.conf` | Podman sem depender de systemd (cgroupfs) |
| `~/.config/containers/registries.conf.d/50-search.conf` | Registry de busca para nomes curtos |
| `~/.config/containers/registries.conf.d/60-aliases.conf` | Aliases `redis`, `python`, `nginx`… → caminho completo no JFrog |

Credencial do JFrog: `~/.config/containers/auth.json`, gerado pelo `podman login`.

&#91;embedded content: arquitetura · Windows → WSL 2 → RHEL/Podman → container, imagens do JFrog\]

Em cima: `localhost:8080` no Windows cai no nginx dentro do container. Embaixo: de onde o Podman lê config e de onde puxa imagem.

## 2. Instalação (loja de aplicativos interna)

Motor primeiro, distro depois, reboot entre os dois. Não usar `wsl --install -d Ubuntu`: a distro homologada é a RHEL do banco.

1. Confirme a virtualização: Gerenciador de Tarefas → Desempenho → CPU → **Virtualização: Habilitado**. Se estiver desabilitado, abra chamado no ServiceNow (Estação de Trabalho CORP → Falha de Software) pedindo ativação na BIOS; sem isso a imagem não sobe.
2. Na loja interna, instale **WSL 2.4.11** e reinicie quando pedir.
3. Instale **Red Hat Enterprise Linux WSL image 1.2.0** (Red Hat). O download é pequeno porque o instalador busca a imagem depois; exige 16 GB livres.
4. Reinicie a estação de novo — obrigatório para o WSL registrar a distro.
5. No PowerShell, `wsl -l -v` deve listar a distro RHEL com `VERSION 2`.

## 3. WSL no dia a dia

PowerShell / Windows Terminal:

| Comando | Efeito |
| --- | --- |
| `wsl` | Abre a distro padrão |
| `wsl -d <nome>` | Abre uma distro específica |
| `wsl -l -v` | Lista distros, versão e se estão rodando |
| `wsl --set-default <nome>` | Faz o RHEL abrir só com `wsl` |
| `wsl --shutdown` | Desliga a VM inteira (necessário após mexer em `.wslconfig` ou `wsl.conf`) |
| `wsl --unregister <nome>` | **Apaga** a distro e todos os dados — só use de propósito |

`exit` volta pro PowerShell. C: está em `/mnt/c`; arquivos do Linux aparecem no Explorer em `\\wsl$\<nome>`. Pacotes: `dnf`, não `apt`.

Home, `~/.config`, pacotes e imagens persistem após `wsl --shutdown` e reboot. Processos não: container rodando para e tem que subir de novo.

Se a VPN derrubar a rede do WSL (DNS não resolve, `dnf` não baixa): 1) `%USERPROFILE%\.wslconfig` com `[wsl2] networkingMode=mirrored`, `dnsTunneling=true`, `autoProxy=true` + `wsl --shutdown`; 2) se a política bloquear mirrored, **wsl-vpnkit** importado como segunda distro e rodando em outro terminal (`wsl.exe -d wsl-vpnkit --cd /app wsl-vpnkit`). Até agora não precisei de nenhum.

## 4. Podman — cgroups sem systemd

O Podman já vem na imagem (`podman --version`). No primeiro `podman run` saem 4 `WARN` de cgroupv2/systemd e ele cai pra `cgroupfs` sozinho. Funciona, mas pra tirar o aviso:

```bash
mkdir -p ~/.config/containers
cat > ~/.config/containers/containers.conf <<'EOF'
[engine]
cgroup_manager = "cgroupfs"
events_logger = "file"
EOF
```

`~/.config/containers/podman/machine` já existia vazia — é do `podman machine`, pode ignorar.

Alternativa que não usei: `[boot] systemd=true` em `/etc/wsl.conf` + `wsl --shutdown`. Funciona no WSL 2.4, mas é arquivo de sistema e pode ser gerenciado pelo banco.

## 5. Registries — o arquivo do banco e os drop-ins

`/etc/containers/registries.conf` vem de `build/customization/02-security/005-set-registry-whitelist.sh` — **não editar**. Tem um bug de TOML: `unqualified-search-registries` e `short-name-mode` estão **abaixo** de `[registries.block]`, então o Podman lê como chave dessa seção e ignora. Resultado: o bloqueio de `docker.io` funciona, mas nenhum nome curto resolve (`short-name "nginx" did not resolve to an alias…`). Abrir chamado pro time da imagem: as duas linhas têm que ir pra cima de `[registries.block]`.

Correção no meu usuário: dois drop-ins em `~/.config/containers/registries.conf.d/`. O Podman mescla com o arquivo do sistema sem alterar ele.

**50-search.conf** — só host. `unqualified-search-registries` não aceita path:

```bash
mkdir -p ~/.config/containers/registries.conf.d
printf 'unqualified-search-registries = ["artefatos.bradesco.com.br"]\nshort-name-mode = "enforcing"\n' > ~/.config/containers/registries.conf.d/50-search.conf
```

**60-aliases.conf** — um alias por imagem. As imagens ficam em path longo no JFrog e `redis` vira `library/redis`, que não existe no espelho:

```bash
cat > ~/.config/containers/registries.conf.d/60-aliases.conf <<'EOF'
[aliases]
"redis"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/redis"
"python"     = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/python"
"postgres"   = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/postgres"
"mongo"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/mongo"
"grafana"    = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/grafana"
"loki"       = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/loki"
"tempo"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/tempo"
"fluent-bit" = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/fluent/fluent-bit"
"localstack" = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/localstack/localstack-azure"
"ubi10"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/redhat/ubi10"
"nginx"      = "artefatos.bradesco.com.br/devtools-docker-central/base-images/ubi8/nginx-126"
EOF
```

`podman run redis:7` passa a resolver direto. Alias é nome exato: pra aceitar `library/redis` também, declarar os dois. Alias ganha da busca, então `enforcing` não pergunta nada.

Descartei `[[registry]] prefix="docker.io" location=…` apontando pro espelho: sobrepõe a entrada bloqueada pelo banco e quebra nas oficiais por causa do `library/`.

## 6. JFrog Artifactory

Host: `artefatos.bradesco.com.br` (Artifactory no domínio do banco, UI também no SaaS). Repos Docker que importam:

| Repo key | Conteúdo | Caminho das imagens |
| --- | --- | --- |
| `public-external-images` | Espelho curado de imagens públicas (redis, python, postgres, mongo, grafana/loki/tempo, fluent-bit, localstack-azure, redhat/ubi10, servicebus-emulator…) | `…/public-external-images/external-images/<registry-origem>/<imagem>` |
| `devtools-docker-central` | Imagens de base construídas pelo banco sobre UBI (ex.: `base-images/ubi8/nginx-120`, `-121`, `-126`) | `…/devtools-docker-central/<caminho>` |

Nenhum espelha o Docker Hub inteiro. `devtools-docker-central/nginx` não existe → `manifest unknown`.

**Credencial.** Senha de rede não funciona no `podman login` (SSO). Usar **Identity Token**: UI → usuário (canto superior direito) → Edit Profile → Generate an Identity Token. *Set Me Up* → Docker → repositório mostra host, path de pull e pode embutir o token. Username é o da conta no Artifactory; na dúvida, decodificar o campo `auth` do JSON do Set Me Up: `echo '<auth>' | base64 -d` → `usuario:token`.

```bash
podman login artefatos.bradesco.com.br
# Username: <usuario do JFrog>
# Password: <identity token>
```

Salvo em `~/.config/containers/auth.json`. Só reloga se o token expirar, for revogado ou a distro for recriada. `podman logout artefatos.bradesco.com.br` remove.

**Catálogo pela API.** `curl -u '<usuario>'` sem senha pede interativo e não grava token no histórico:

```bash
# imagens de um repositório
curl -u '<usuario>' https://artefatos.bradesco.com.br/artifactory/api/docker/public-external-images/v2/_catalog
# tags de uma imagem
curl -u '<usuario>' https://artefatos.bradesco.com.br/artifactory/api/docker/devtools-docker-central/v2/base-images/ubi8/nginx-126/tags/list
```

## 7. Teste ponta a ponta (Windows → container)

Objetivo: confirmar que o Windows alcança container rodando no WSL. Testado com redis:

```bash
# dentro do RHEL
podman pull redis
podman run -d --name testeredis -p 6379:6379 redis
podman exec testeredis redis-cli ping     # PONG
```

```powershell
# no PowerShell
Test-NetConnection localhost -Port 6379  # TcpTestSucceeded : True
```

Por HTTP, com o nginx do banco:

```bash
podman run -d --name testenginx -p 8080:8080 nginx
curl -I http://localhost:8080
```

```powershell
curl.exe -I http://localhost:8080
```

Atenção:

- As imagens nginx da Red Hat (UBI) rodam **sem root e escutam na 8080**, não na 80. `-p 8080:80` mapeia uma porta vazia e parece erro de rede.
- São imagens S2I; sem conteúdo o nginx pode responder 403/404. Qualquer resposta HTTP já prova a conectividade. Para servir algo: `-v ~/site:/opt/app-root/src:Z`.

Funciona porque o WSL 2 encaminha `localhost` do Windows pra VM quando o processo escuta em `0.0.0.0` (o `-p` garante). Se `localhost` falhar: testar pelo IP da VM (`hostname -I` no RHEL); se só o IP funcionar, conferir que `.wslconfig` não tem `localhostForwarding=false`. Limpeza: `podman rm -f testeredis testenginx`.

## 8. Segurança

- [ ] **Revogar e regenerar o Identity Token.** Ele apareceu em fotos de tela e na linha de comando durante a configuração. Edit Profile → Identity Tokens → revoke → gerar novo → `podman login` de novo.
- [ ] **Limpar o histórico do bash.** O token foi passado em `curl -u 'usuario:token'`, que ficou em `~/.bash_history`. Edite o arquivo e remova as linhas, ou `history -c && history -w`.

* Gere tokens **com expiração** (90 dias é um bom padrão) em vez de permanentes.
* `~/.config/containers/auth.json` guarda o token em base64, não criptografado. Não copie para `/mnt/c`, para repositório nem para backup compartilhado.
* Para a API, prefira `curl -u '<usuario>'` (pede a senha sem gravar) ou um `~/.netrc` com permissão `600` e `curl -n`.
* Não edite `/etc/containers/registries.conf` nem use `insecure = true` para contornar erros de certificado: a política de bloqueio de registries externos é intencional. Drop-ins no usuário respeitam ela.
* A imagem RHEL roda Podman **rootless** e as imagens UBI escutam em portas altas — mantenha assim; não rode containers como root para "resolver" porta 80.

## 9. Troubleshooting

| Mensagem | Causa | Ação |
| --- | --- | --- |
| `WARN The cgroupv2 manager is set to systemd but there is no systemd user session` | Podman tentando usar systemd no WSL | `containers.conf` com `cgroup_manager = "cgroupfs"` (seção 4) |
| `short-name "X" did not resolve to an alias and no unqualified-search registries are defined` | Bug de TOML no `registries.conf` do banco | Nome completo da imagem, ou drop-ins (seção 5) |
| `invalid registry` ao definir `unqualified-search-registries` | Caminho no lugar de host | Só `host[:porta]`; caminhos vão em `[aliases]` |
| `invalid username/password` no `podman login` | Senha de rede em vez de token, ou username errado | Identity Token; username via `base64 -d` do campo `auth` |
| `manifest unknown: The named manifest is not known to the registry` | Imagem/tag não existe nesse caminho | Consultar `_catalog` e `tags/list` pela API (seção 6) |
| `x509: certificate signed by unknown authority` | CA interna não confiada no RHEL | `sudo cp ca.crt /etc/pki/ca-trust/source/anchors/ && sudo update-ca-trust` |
| `dial tcp … i/o timeout` / `no such host` | Rede do WSL caída pela VPN | `.wslconfig` mirrored ou wsl-vpnkit (seção 3) |
| Windows não alcança `localhost:<porta>` | Processo não escuta em `0.0.0.0`, porta errada (UBI usa 8080), ou `localhostForwarding=false` | Conferir `podman ps`, mapear a porta certa, testar pelo IP de `hostname -I` |
| `wsl -l -v` vazio após instalar a imagem | Faltou reiniciar a estação | Reiniciar o Windows |

Rede, de dentro do RHEL, nessa ordem: `ping -c 3 8.8.8.8` (rota) → `ping -c 3 google.com` (DNS) → `curl -I https://artefatos.bradesco.com.br/artifactory/api/system/ping` (JFrog).

## 10. Backup e recriação

Reinstalar a imagem pela loja pode ser `unregister` + import novo, e a home vai junto. Guardar os 3 arquivos fora da distro — `/mnt/c/Users/<matrícula>/wsl-config/` ou repo de dotfiles — **sem** o `auth.json`:

```bash
mkdir -p /mnt/c/Users/$USER/wsl-config
cp ~/.config/containers/containers.conf /mnt/c/Users/$USER/wsl-config/
cp ~/.config/containers/registries.conf.d/50-search.conf /mnt/c/Users/$USER/wsl-config/
cp ~/.config/containers/registries.conf.d/60-aliases.conf /mnt/c/Users/$USER/wsl-config/
```

(Se `$USER` no RHEL não for a matrícula, trocar pelo path real.)

Recriar numa RHEL nova:

```bash
#!/usr/bin/env bash
set -euo pipefail
SRC=/mnt/c/Users/<matrícula>/wsl-config
mkdir -p ~/.config/containers/registries.conf.d
cp "$SRC/containers.conf" ~/.config/containers/
cp "$SRC/50-search.conf" "$SRC/60-aliases.conf" ~/.config/containers/registries.conf.d/
podman login artefatos.bradesco.com.br   # usuário + Identity Token
podman pull redis && echo "ok"
```

Checklist: `wsl -l -v` lista o RHEL · `podman --version` · `podman run redis` sem WARN e sem erro de short-name · `Test-NetConnection localhost -Port 6379` no PowerShell.
