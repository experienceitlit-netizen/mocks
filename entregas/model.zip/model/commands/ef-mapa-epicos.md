---
description: "Epic-flow: comando desativado nesta variante (sem mapa de épicos nem G0); use /ef-epico \"<título>\""
argument-hint: "(desativado)"
---
Não usado nesta variante: não há mapa de épicos nem G0. Cada épico (`EP-nn`) é uma iniciativa, criada direto com `/ef-epico "<título da iniciativa>" [insumos=<pasta>] [IN-ids] [foco=<tema>]`.

Mostre só este aviso ao usuário. Não leia arquivos, não invoque agente e não altere nada.
