---
description: "Epic-flow: devolve um artefato em revisão para rascunho com o motivo do gate (reprovação ou ajustes)"
argument-hint: "<ID> <motivo>"
---
Você é o orquestrador do epic-flow. Este comando registra uma decisão **do usuário humano** no gate.

Argumentos: `$ARGUMENTS`

1. Localize o artefato pelo ID (mesma regra de `/ef-aprovar`). Ele deve estar `em-revisao`.
2. Mude `status` para `rascunho`, atualize `data` e acrescente ao fim do artefato uma seção "Registro de gate" com data, gate e motivo.
3. Informe qual comando reexecutar para o agente dono ajustar (ex.: `/ef-epico EP-01 [insumos=<pasta>]`, `/ef-epico EP-01 business-case` (devolução do G1 restrito à §4/§10), `/ef-features EP-01 feature=FT-01.02 [insumos=<pasta>]`, `/ef-features EP-01 historia=US-01.02.03 [insumos=<pasta>]`), lembrando que o agente deve ler o "Registro de gate".
