# Implementação e Migração (cap. 12) e elementos compostos (§4.5)

## Implementação e Migração

| Elemento | ID | Definição (ArchiMate 3.2) | Nome |
|---|---|---|---|
| Work Package | `IMP-W` | §12.2.1: série de ações identificadas e desenhadas para alcançar resultados específicos dentro de restrições de tempo e recursos. Processo único, "uma vez só"; pode modelar uma iteração ágil (sprint) | verbo + substantivo da entrega ("Implantar check-in sem balcão") ou nome da iteração |
| Deliverable | `IMP-DL` | §12.2.2: resultado precisamente definido de um work package | substantivo ("Check-in sem balcão em produção na unidade-piloto", "Plano de migração da recepção") |
| Implementation Event | `IMP-EV` | §12.2.3: mudança de estado relacionada à implementação ou migração | particípio ("Piloto concluído") |
| Plateau | `IMP-PL` | §12.2.4: estado relativamente estável da arquitetura durante um período limitado | estado nomeado ("Atual", "Transição: piloto", "Alvo MVP") |
| Gap | `IMP-GAP` | §12.2.5: declaração da diferença entre dois plateaus | o que muda ("Chegada registrada em papel → check-in digital") |

**Teste do tipo:**
- Work Package é **trabalho** com começo e fim; Deliverable é o **resultado** dele.
- Plateau é um **estado** da arquitetura; Gap só existe entre dois plateaus.

**Relações típicas:**
- Business Actor/Role **atribuído a** Work Package; Work Package **dispara** Work Package; Implementation Event **dispara** ou é disparado por Work Package e Plateau.
- Work Package **acessa** Deliverable (a realização de Deliverable por Work Package ainda é aceita, mas está **depreciada** na 3.2: não use).
- Deliverable **realiza** qualquer elemento do núcleo (o componente entregue) e o Plateau; Deliverable e Work Package realizam ou influenciam Requirement.
- Plateau **agrega ou compõe** elementos do núcleo e também Goal, Outcome e Requirement; Gap **associa-se** aos dois plateaus e aos elementos do núcleo que mudam; Plateau pode **realizar** Capability (o incremento de capacidade válido naquele período).

No epic-flow, as features do PRD (§10) e as tasks não são elementos ArchiMate. Na AS, a feature pode aparecer como Work Package e o que ela coloca em produção como Deliverable.

## Elementos compostos

| Elemento | ID | Definição (ArchiMate 3.2) | Uso |
|---|---|---|---|
| Grouping | `GRP` | §4.5.1: agrega ou compõe conceitos que pertencem juntos por alguma característica comum | agrupar elementos de tipos diferentes; não confundir com "criar uma visão" |
| Location | `LOC` | §4.5.2: lugar conceitual ou físico onde conceitos ficam ou são executados | Location **agrega** os elementos que estão nela ("Unidade Centro") |

**Junction** (§5.5.1) junta relações do mesmo tipo (e/ou). Não cria relação que não seria permitida sem ela.
