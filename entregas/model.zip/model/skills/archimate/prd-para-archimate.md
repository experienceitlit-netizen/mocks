# Do PRD e dos insumos para elementos ArchiMate

O tipo de um elemento é decidido pelo **conceito**, nunca pela palavra que o insumo usa. "Dor", "problema", "risco", "objetivo", "necessidade", "premissa" são rótulos do documento de origem; cada um pode virar tipos diferentes de elemento, ou nenhum.

Todos os exemplos usam o mesmo domínio fictício: uma rede de clínicas que quer reduzir o tempo de espera dos pacientes. Eles não têm relação com nenhum projeto real.

## 1. Separe antes de classificar

Um enunciado de insumo costuma misturar conceitos. Quebre-o nas partes que respondem a perguntas diferentes:

| Pergunta | Tipo |
|---|---|
| Sobre que tema ou condição estamos preocupados? | Driver |
| O que constatamos hoje sobre esse tema? | Assessment |
| Aonde queremos chegar (direção, qualitativo)? | Goal |
| Que resultado concreto, mensurável ou datado, esperamos? | Outcome |
| Que caminho escolhemos para chegar lá? | Course of Action |
| Que propriedade o sistema precisa ter para chegar lá? | Requirement |
| O que limita a forma de chegar lá? | Constraint |

Exemplo. Insumo: *"Nossos pacientes esperam em média 50 minutos além do horário marcado, porque a recepção registra a chegada em papel. Queremos baixar a espera média para menos de 15 minutos até dezembro de 2027, começando por uma unidade-piloto, com check-in sem passar pelo balcão, usando só a base de pacientes do prontuário atual."*

| Parte | Tipo | Nome |
|---|---|---|
| tema | Driver | Tempo de espera no atendimento |
| constatação, com evidência | Assessment | Pacientes esperam em média 50 min além do horário |
| constatação, com evidência | Assessment | Recepção registra a chegada em papel |
| direção | Goal | Reduzir o tempo de espera |
| meta com número e prazo | Outcome | Espera média abaixo de 15 min até dez/2027 |
| caminho escolhido | Course of Action | Implantar primeiro em uma unidade-piloto |
| propriedade do sistema | Requirement | Check-in do paciente sem passar pelo balcão |
| limitação imposta | Constraint | Base de pacientes só no prontuário atual |

## 2. Árvore de decisão

Percorra na ordem; pare na primeira resposta "sim" e confirme com o **teste do tipo** no arquivo da camada.

1. É uma pessoa, grupo ou organização **com interesse no resultado** da arquitetura? → **Stakeholder**. Se também executa trabalho nos processos → além disso, **Business Actor** ou **Business Role** na camada de Negócio, atribuído ao Stakeholder.
2. É um **tema ou condição**, interno ou externo, que motiva a organização a mudar, e que se nomeia com um substantivo sem verbo de ação e sem juízo ("Tempo de espera no atendimento", "Legislação de proteção de dados", "Concorrência")? → **Driver**.
3. É uma **constatação sobre a situação atual** da organização ou do seu ambiente, em relação a um Driver, com evidência no insumo (§6), verdadeira hoje, antes de a solução existir? → **Assessment**.
4. É um **evento futuro incerto que causaria perda** (o insumo costuma dizer "pode", "risco de", "se ... então")? → **Risco**: siga a §4. Nunca Assessment simples.
5. É uma **direção ou estado desejado, qualitativo**? → **Goal**.
6. É um **resultado concreto**, alcançado ou esperado num ponto definido do futuro, possivelmente com número e prazo (meta de KPI com alvo), ou um efeito, inclusive indesejado? → **Outcome**.
7. É uma **abordagem ou plano** para usar capacidades e recursos rumo a um objetivo (estratégia ou tática escolhida)? Diz **como vamos chegar**, não **o que deve valer**? → **Course of Action**. É elemento de Estratégia (`STR-CoA`): entra na visão de Estratégia, com as relações para Outcome e Requirement desenhadas lá.
8. É uma **regra geral** que vale para qualquer sistema do contexto e não um plano, vinda de uma fonte que a declara como regra geral (§7)? → **Principle**.
9. É uma **propriedade necessária deste sistema** (funcional ou de qualidade)? → **Requirement**.
10. É uma **limitação** sobre a arquitetura, sua implementação ou realização (tecnologia imposta, canal único, prazo, orçamento, lei)? → **Constraint**.
11. É **o que o negócio é capaz de fazer**, estável, independente de como e de quem faz? → **Capability**.
12. É uma **sequência de estágios que entrega um resultado de valor** a um cliente, stakeholder ou usuário? → **Value Stream** (estágios também são Value Streams).
13. É um **ativo** possuído ou controlado (informação, pessoas, dinheiro, marca, conhecimento)? → **Resource**.
14. É **trabalho ordenado no tempo para um caso** (verbo: "fazer check-in")? → **Business Process**. Agrupamento por competência, sem ordem ("gestão da agenda")? → **Business Function**. Mudança de estado ("paciente chegou")? → **Business Event**. Comportamento oferecido para fora ("check-in de pacientes")? → **Business Service**. Conceito de informação do domínio ("ficha de chegada")? → **Business Object**.
15. Nada acima? Provavelmente não é elemento desta visão: pode ser texto (escopo, não-escopo, premissa sem efeito arquitetural) ou pertence a outra etapa. Não force um tipo.

## 3. Seções do PRD

O mapeamento é ponto de partida, não regra fixa: cada enunciado ainda passa pela árvore.

| Seção do PRD | O que costuma conter | Tipos prováveis |
|---|---|---|
| §1 Contexto e problema | tema da preocupação, situação atual, meta de negócio, abordagem escolhida | Driver + Assessment (separar) + Goal; a abordagem é Course of Action (visão de Estratégia) |
| §2 Necessidades de negócio e de tecnologia | o que é preciso ter ou resolver | Driver (tema), Requirement (propriedade), Constraint (limitação) |
| §3 Objetivos, metas e KPIs | objetivo qualitativo; KPI com linha de base, alvo e prazo | Goal (objetivo) + um Outcome por KPI com alvo (alvo `[a definir: Q-nnn]` continua Outcome, com a Q-nnn no nome) |
| §4 Business case | benefício esperado, premissas | Outcome (benefício como resultado); Value (§5 abaixo); premissa vira texto ou Constraint |
| §5 Personas e stakeholders | quem tem interesse; quem atua | Stakeholder (um por papel de interesse); Business Actor/Role na visão de Negócio |
| §6 Escopo | o que a iniciativa entrega | Requirement; insumo para Capability e Process |
| §7 Não-escopo | o que fica de fora | Em geral **não vira elemento** (fica na introdução da arquitetura). Só é Constraint se for uma limitação imposta à solução que está dentro do escopo |
| §8 Requisitos `RF`/`RNF` | propriedades do sistema | Requirement, **um por RF/RNF** (§6); Constraint quando o RNF impõe tecnologia, norma, prazo ou custo; «Medida de controle» quando o RNF mitiga um risco modelado |
| §9 Interdependências e premissas | sistemas, áreas e plataformas existentes | Business Actor, Role, Resource; na AS, Application Component existente; limitação → Constraint |
| §10 Mapa de features | features candidatas | **Não são elementos da AR**. Indicam Capabilities e Processes a modelar; no E4 viram Work Package/Deliverable |
| §12 Riscos | eventos incertos com perda | §4 abaixo |
| Premissas "a validar" | hipóteses sobre o futuro | texto; se descreverem a situação atual, Assessment com "(hipótese a validar)" (§6) |
| §13 Questões abertas | lacunas | Não viram elementos; citadas onde afetam |

## 4. Riscos

A especificação **não tem elemento de risco**. Ela oferece duas formas:

- **Especialização «Risco» de Assessment** (ArchiMate 3.2 §14.2.5, exemplos de especializações de motivação, *Risk & Security Overlay*): "a frequência provável e a magnitude provável de uma perda futura". A mitigação é um Requirement com especialização **«Medida de controle»**.
- **Outcome indesejado** (§6.3.2: outcomes "também podem modelar efeitos potencialmente indesejados, por exemplo para projetar medidas de mitigação").

**Convenção do fluxo** (as regras valem na ordem; a primeira que se aplica decide):

1. Um risco nunca é Assessment **simples**. Assessment simples constata o presente; risco é hipótese sobre o futuro. Ex.: "O check-in online pode ficar fora do ar", quando o check-in online ainda não existe, não é constatação de nada.
2. **Risco aceito** (decisão registrada em `Q-nnn` de conviver com ele): texto, com a `Q-nnn` citada; não modele, mesmo que exista mitigação parcial.
3. Se o "risco" é só o contrário de um Goal (ex.: "risco de a espera não cair"), não é elemento novo: já está no Driver, no Assessment, no Goal e no Outcome.
4. **Modele o risco só se as fontes trouxerem a medida de controle** (um RF/RNF ou uma decisão registrada em `Q-nnn` que o mitiga). Sem medida de controle nas fontes, o risco fica em texto, na seção de riscos do artefato; não invente a mitigação.
5. Forma padrão: Assessment **«Risco»**, nome "Risco de <perda>", ligado por associação ao Driver que ameaça (sem Driver correspondente, ao Goal ou Requirement ameaçado; não crie Driver só para isso); a «Medida de controle» exerce `influência (-)` sobre ele. Ex.: `MOT-A3 «Risco» Risco de dado de saúde exposto no check-in` ← `influência (-)` ← `MOT-R4 «Medida de controle» Confirmação de identidade no check-in`.
6. Use **Outcome indesejado** em vez de «Risco» só quando a fonte trata o efeito como algo a medir (um KPI negativo com linha de base ou alvo).
7. **«Medida de controle»** vai no Requirement ou na Constraint (subtipo de Requirement) que a fonte apresenta como mitigação daquele risco. Uma função principal que só ajuda indiretamente não recebe o estereótipo.
8. Fato atual que é ameaça externa (ex.: "a legislação passou a exigir consentimento explícito") é Assessment simples (SWOT: ameaça), porque é verdadeiro hoje.

## 5. Stakeholders e Value

- **Um Stakeholder por papel de interesse**, não por persona: personas são exemplos do mesmo papel e vão na descrição. A mesma pessoa em dois papéis gera dois Stakeholders; o nome da pessoa, se o insumo citar, vai só na descrição.
- Interessado que só aparece no não-escopo não é modelado; se aparece no escopo e no não-escopo, é modelado (com a ressalva na descrição).
- Um Driver compartilhado por dois Stakeholders é um elemento só, associado aos dois; se as preocupações forem diferentes, são dois Drivers.
- **Value:** modele quando a fonte declara um benefício para um Stakeholder (proposta de valor). Associe ao Stakeholder e, se houver, ao Outcome ou elemento que o entrega; sem esse elemento nas fontes, só ao Stakeholder.

## 6. Evidência e granularidade

- **Evidência de um Assessment:** dado, observação, pesquisa ou relato da situação atual no insumo, citado com `IN-nnn:L<linha>`. O relato do próprio autor do insumo conta. Se a fonte declara que não houve validação (hipótese, sem pesquisa), o Assessment continua válido, mas a descrição diz "(hipótese a validar, IN-nnn:L<linha>)"; se for decisivo para a arquitetura, abra `Q-nnn`. Um Assessment por constatação: vários concorrentes com a mesma constatação são um elemento só.
- **Requirements na AR:** um elemento por RF/RNF do PRD, com o ID do RF/RNF na origem. Não junte RFs diferentes num elemento. Se a visão ficar grande, divida o diagrama (por Goal ou por Capability); a tabela continua completa.
- **Requirement → Outcome/Goal:** ligue (realização) só quando a fonte sustenta o vínculo: o próprio RF/RNF, ou o mapa de features do PRD, que pode ser usado como rastreio (a feature cita o KPI e os RFs). Sem vínculo nas fontes, deixe o Requirement sem essa relação e anote "(sem vínculo na fonte)"; não invente.
- **Requirement com termo de tecnologia** (§8): o nome descreve a propriedade de negócio, o ID do RF/RNF fica na origem e a parte técnica é anotada na descrição como "(forma de implantação na AS)".
- **Goal × Outcome:** cada direção do PRD é um Goal; cada alvo mensurável é um Outcome que o realiza. Dois Goals com o mesmo estado final desejado são um só. Goal que a fonte apresenta como parte (decomposição) de outro se liga por agregação; Goal que só contribui para outro, por `influência (+)`.
- **Goal × Requirement:** se o enunciado pode ser atendido por soluções diferentes, é Goal; se nomeia uma característica do produto, é Requirement.
- **Outcome sem prazo definido:** o nome leva o prazo pendente, "[prazo: Q-nnn]".

## 7. Contexto de um Principle

"Contexto" é a organização ou a iniciativa inteira: todos os sistemas, atuais e futuros, a que a regra se aplicaria.
- Só é Principle o que vem da referência `arquitetura-corporativa` ou o que a fonte declara explicitamente como princípio ou regra geral, além deste sistema. Numa iniciativa de um produto só, isso costuma ser raro.
- Um RNF ou uma regra de produto do PRD é Requirement, mesmo quando soa geral, porque foi escrito para este sistema. Ele **realiza** o Principle correspondente, se houver um.

## 8. Tecnologia na Arquitetura de Referência

A AR (Motivação, Estratégia, Negócio) não cita **produto, biblioteca, framework, plataforma, fornecedor ou forma de implantação** (banco de dados, biblioteca, provedor de nuvem, tipo de aplicativo). Esses entram na Arquitetura de Solução.

Ficam na AR os conceitos de negócio, ainda que de natureza tecnológica:
- canal ("telefone", "balcão");
- método ("triagem por prioridade");
- recurso ("base histórica de atendimentos");
- concorrentes citados num Assessment sobre o ambiente externo.

## 9. Erros de classificação recorrentes

| Errado | Por quê | Certo |
|---|---|---|
| Driver "Marcar consulta", "Ser atendido rápido" | verbo de ação é tarefa ou desejo, não condição | Driver é o tema ("Tempo de espera no atendimento"); a ação vira Goal ou Requirement |
| Driver "Queda das vendas", "Perda de clientes" | constatação de situação é Assessment | Driver "Receita"; Assessment "Vendas caíram 12% no ano" |
| Assessment "X pode falhar", "Y pode ser pesado" | hipótese, não constatação | Risco (§4) ou só texto |
| Assessment sobre funcionalidade ainda não construída | não descreve a situação atual | Risco (§4), Requirement ou Constraint |
| Goal "Espera abaixo de 15 min até 2027" | número e prazo | Outcome; o Goal é "Reduzir o tempo de espera" |
| Goal "Check-in pelo celular" | descreve uma solução, não uma direção | Goal "Facilitar a chegada do paciente"; o check-in é Requirement |
| Principle "Começar por uma unidade-piloto" | é caminho, não regra | Course of Action |
| Principle "O sistema X usa fila" | vale para um sistema só | Requirement ou Constraint |
| Constraint "Cadastrar paciente" | é função | Requirement |
| Constraint "Telemedicina fora do escopo" | não-escopo não é limitação da solução | texto na introdução |
| Stakeholder com nome de pessoa | Stakeholder é papel de interesse | papel ("Diretoria clínica"); a pessoa fica na descrição |
| Capability "Calcular horários livres" | passo de processo | Business Process; a capacidade é "Gestão de agenda" |
| Requirement que junta várias telas e regras | agregado demais | um Requirement por RF/RNF (§6) |
| Biblioteca, framework ou produto na AR | tecnologia é da Arquitetura de Solução | §8 |
