# Camada de Motivação (ArchiMate 3.2, cap. 6)

Os elementos de motivação explicam **por que** a arquitetura existe e o que ela precisa atender. Eles não executam nada: nenhum elemento de motivação serve, acessa, dispara, realiza ou é atribuído a um elemento do núcleo (negócio, aplicação, tecnologia). Da motivação para fora só existe associação (ex.: Meaning e Value associados a elementos do núcleo); do núcleo para a motivação, realização, influência e associação (`relacoes.md` §2).

Exemplos no domínio fictício da rede de clínicas (`prd-para-archimate.md` §1).

## Stakeholder — `MOT-SK`

- **Definição (§6.2.1):** o papel de um indivíduo, equipe ou organização (ou de classes deles) que representa seus interesses nos efeitos da arquitetura.
- **Teste do tipo:** tem **interesse** no resultado? Não importa se executa trabalho.
- **Nome:** substantivo, de preferência o papel de interesse. Bom: "Paciente", "Diretoria clínica", "Órgão regulador". Ruim: "Maria Souza" (pessoa; o papel é que importa), "Fazer check-in" (ação). Um Stakeholder por papel de interesse (`prd-para-archimate.md` §5).
- **Relações típicas:** associação com Driver, Value e Meaning. Um Business Actor, Role ou Collaboration pode ser **atribuído** ao Stakeholder para dizer que quem atua na operação também é interessado.

## Driver — `MOT-D`

- **Definição (§6.2.2):** uma condição externa ou interna que motiva a organização a definir seus objetivos e implementar as mudanças necessárias para alcançá-los. Drivers associados a um stakeholder costumam ser chamados de "concerns" (preocupações).
- **Exemplos da especificação:** internos, "satisfação do cliente" e "lucratividade"; externos, "mudanças econômicas" e "mudança na legislação".
- **Teste do tipo:** cabe na frase "a organização precisa agir por causa de <___>" sendo <___> um **tema ou condição**, neutro, sem verbo de ação e sem avaliação. Se tiver verbo de ação, é Goal ou Requirement. Se já afirmar como a situação está ("queda de", "perda de", "falta de"), é Assessment.
- **Nome:** substantivo ou sintagma nominal neutro (a especificação: "preferably a noun"). Bom: "Tempo de espera no atendimento", "Custo por atendimento", "Legislação de proteção de dados", "Concorrência de clínicas digitais". Ruim: "Reduzir a espera" (Goal), "Espera excessiva" (Assessment), "Fazer check-in pelo celular" (Requirement).
- **Origem típica no PRD:** §1 contexto e problema, §2 necessidades, preocupações dos stakeholders da §5.
- **Relações típicas:** associação com Stakeholder, Assessment e Goal; influência entre drivers.

## Assessment — `MOT-A`

- **Definição (§6.2.3):** o resultado de uma análise do estado das coisas (*state of affairs*) da organização em relação a algum driver. Pode revelar forças, fraquezas, oportunidades ou ameaças (SWOT); forças e fraquezas são internas, oportunidades e ameaças são externas. Fraquezas e ameaças são problemas a tratar por objetivos que os "neguem"; forças e oportunidades podem virar objetivos diretamente.
- **Exemplos da especificação:** "Market Share Is Declining", "Customers complain about the helpdesk".
- **Teste do tipo:** é uma **constatação** sobre a situação atual da organização ou do seu ambiente, verdadeira hoje, antes de a solução existir, com evidência no insumo, e está ligada a um Driver identificável. Três "nãos": não é hipótese ("pode", "poderia", "se"), não é sobre a solução que ainda vai ser construída, não é desejo.
- **Nome:** substantivo ou frase muito curta, afirmativa, no presente (a especificação: "a noun or a (very) short sentence"). Bom: "Pacientes esperam em média 50 min além do horário", "Recepção registra a chegada em papel", "Clínicas concorrentes já oferecem check-in online". Ruim: "Check-in online pode ficar fora do ar" (risco hipotético sobre solução que não existe), "Espera ruim" (vago; diga o que foi constatado).
- **Especialização «Risco»:** ver `prd-para-archimate.md` §4. Rótulo sempre com «Risco».
- **Evidência:** ver `prd-para-archimate.md` §6 (relato do autor conta; hipótese declarada é marcada "(hipótese a validar)").
- **Origem típica no PRD:** §1 (situação atual, dados de base), pesquisas e relatos nos insumos; concorrentes (ameaça/oportunidade externa).
- **Relações típicas:** associação com Driver e Goal; Outcome pode ser associado a Assessment; influência entre assessments.

## Goal — `MOT-G`

- **Definição (§6.3.1):** uma declaração de alto nível de intenção, direção ou estado final desejado para a organização e seus stakeholders. Goals são geralmente expressos com palavras qualitativas, como "aumentar", "melhorar" ou "mais fácil". Podem ser decompostos ("aumentar o lucro" em "reduzir custos" e "aumentar vendas").
- **Teste do tipo:** é **direção**, qualitativa, sem número nem prazo, e não descreve a solução. "Um goal é o que você quer; um outcome é o que você obtém" (§6.3.2).
- **Nome:** verbo no infinitivo que expressa direção ou estado desejado + objeto: aumentar, reduzir, melhorar, facilitar, manter, garantir, ampliar, ou validar (meta de aprendizado: "Validar se pacientes aceitam o check-in sem balcão"). Bom: "Reduzir o tempo de espera", "Melhorar a experiência de chegada". Ruim: "Espera abaixo de 15 min até 2027" (Outcome), "Check-in pelo celular" (solução: Requirement), "Qualidade do atendimento" (substantivo vago; diga a direção).
- **Origem típica no PRD:** meta de negócio (§1), objetivos (§3).
- **Relações típicas:** realizado por Outcome; associação com Driver e Assessment; agregação para decompor (o sub-goal é parte do goal); `influência (+)` quando um goal só contribui para outro.

## Outcome — `MOT-O`

- **Definição (§6.3.2):** um resultado final, efeito ou consequência de um certo estado das coisas. Outcomes são tangíveis, possivelmente quantitativos e relacionados ao tempo, e podem ser associados a assessments. Também podem modelar efeitos indesejados, por exemplo para projetar medidas de mitigação.
- **Exemplos da especificação:** "First-place customer satisfaction ranking achieved", "10% year-over-year quarterly profits increase in 2018".
- **Teste do tipo:** dá para dizer, numa data, se foi ou não atingido.
- **Nome:** o resultado como estado alcançado (particípio ou frase nominal), com métrica e prazo quando houver. Bom: "Espera média abaixo de 15 min até dez/2027", "Check-in sem balcão disponível em todas as unidades". Alvo sem insumo: "Espera média no alvo [a definir: Q-nnn]". Ruim: "Reduzir a espera" (Goal).
- **Origem típica no PRD:** KPIs com linha de base, alvo e prazo (§3); benefício do business case (§4).
- **Relações típicas:** realiza Goal; é realizado por Principle, Requirement, Course of Action; associação com Value e Assessment; influência.

## Principle — `MOT-P`

- **Definição (§6.3.3):** uma declaração de intenção que define uma propriedade geral aplicável a **qualquer** sistema num certo contexto da arquitetura. Princípios são mais amplos e abstratos que requisitos.
- **Exemplo da especificação:** "Data should be stored only once".
- **Teste do tipo:** troque o sistema em construção por outro do mesmo contexto (a organização ou a iniciativa inteira, `prd-para-archimate.md` §7); a frase continua valendo? Se sim, Principle. Se só faz sentido para este sistema, Requirement. Se diz como chegar (plano), Course of Action.
- **Nome:** frase normativa geral. Bom: "Toda informação clínica tem um único sistema de registro", "Dados do paciente registrados uma única vez". Ruim: "Usar só a base do prontuário atual" (Constraint deste sistema), "Começar por uma unidade-piloto" (Course of Action).
- **Relações típicas:** realiza Outcome (e, por derivação, Goal); é realizado por Requirement; influência.

## Requirement — `MOT-R`

- **Definição (§6.3.4):** uma declaração de necessidade que define uma propriedade aplicável a um sistema **específico**, como descrito pela arquitetura. Requisitos são os "meios" para realizar goals.
- **Exemplo da especificação:** "Use a single CRM system".
- **Teste do tipo:** é uma propriedade, funcional ou de qualidade, que o sistema em construção precisa ter.
- **Nome:** frase curta da propriedade necessária, um conceito por elemento. Bom: "Check-in do paciente sem passar pelo balcão", "Fila de atendimento visível ao paciente", "Check-in confirmado em até 2 s". Ruim: um único Requirement que lista telas, regras e relatórios. Na AR, um Requirement por RF/RNF (`prd-para-archimate.md` §6).
- **Especialização «Medida de controle»:** mitigação de um «Risco» (`prd-para-archimate.md` §4).
- **Origem típica no PRD:** escopo (§6), `RF-nn` e `RNF-nn` de qualidade (§8).
- **Relações típicas:** realiza Outcome, Principle (e Goal por derivação); é realizado ou influenciado por elementos do núcleo, Capability, Value Stream, Course of Action, Resource, Work Package e Deliverable.

## Constraint — `MOT-K`

- **Definição (§6.3.5):** uma limitação sobre aspectos da arquitetura, do seu processo de implementação ou da sua realização. É um subtipo de requirement: não prescreve funcionalidade, impõe uma restrição ao modo como o sistema opera ou pode ser realizado.
- **Exemplos da especificação:** uso de uma tecnologia específica, restrições de prazo ou de orçamento, restrições legais.
- **Teste do tipo:** reduz as opções de **como** fazer, sem dizer **o que** o sistema faz.
- **Nome:** a limitação, de forma direta. Bom: "Base de pacientes só no prontuário atual", "Orçamento de implantação até R$ [a definir: Q-nnn]", "Dados de saúde tratados conforme a LGPD". Ruim: "Cadastrar paciente" (função: Requirement), "Telemedicina fora do escopo" (não-escopo: texto).
- **Relações típicas:** as mesmas de Requirement.

## Meaning — `MOT-M`

- **Definição (§6.4.1):** o conhecimento ou a interpretação dada a um conceito num contexto particular.
- **Nome:** substantivo ou sintagma nominal. Uso raro; só quando o insumo traz uma interpretação que importa para a arquitetura (ex.: o que "consulta confirmada" significa para o faturamento).
- **Relações:** associação com qualquer elemento de estrutura ou comportamento, e com Stakeholder.

## Value — `MOT-V`

- **Definição (§6.4.2):** o valor, a utilidade ou a importância relativa de um conceito. Valor funcional se expressa como ação ou estado alcançável graças ao elemento.
- **Quando modelar:** a fonte declara um benefício para um Stakeholder (`prd-para-archimate.md` §5).
- **Nome:** o benefício para alguém. Bom: "Menos tempo perdido na sala de espera", "Recepção liberada para casos complexos". Ruim: valor monetário sem insumo (vira `[a definir: Q-nnn]`).
- **Relações:** associação com Stakeholder, Outcome e qualquer elemento de estrutura ou comportamento.

## Não confundir

| Par | Distinção |
|---|---|
| Driver × Assessment | Driver é o tema ("Tempo de espera no atendimento"); Assessment é o que se constatou sobre ele ("Pacientes esperam em média 50 min além do horário"). |
| Assessment × Risco | Assessment constata o presente; «Risco» estima uma perda futura incerta. |
| Driver × Goal | Driver é a condição que motiva; Goal é a direção escolhida em resposta. |
| Goal × Outcome | Goal é o que se quer (qualitativo); Outcome é o que se obtém (verificável, com prazo). |
| Principle × Requirement | Principle vale para qualquer sistema do contexto; Requirement, para este sistema. |
| Requirement × Constraint | Requirement diz o que o sistema precisa ter; Constraint limita como pode ser feito. |
| Principle × Course of Action | Principle diz o que deve valer; Course of Action diz o caminho para chegar. |
| Stakeholder × Business Actor/Role | Stakeholder tem interesse; Actor/Role executa comportamento. Quem faz as duas coisas aparece nas duas camadas, ligado por atribuição. |
