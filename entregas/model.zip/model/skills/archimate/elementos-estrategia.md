# Camada de Estratégia (ArchiMate 3.2, cap. 7)

A Estratégia descreve **o que** a organização é capaz de fazer e com que recursos, sem dizer como. Value streams e capabilities refletem o **modelo de negócio**; processos e funções refletem o **modelo operacional** (§7.3).

Exemplos no domínio fictício da rede de clínicas (`prd-para-archimate.md` §1).

## Resource — `STR-RES`

- **Definição (§7.2.1):** um ativo possuído ou controlado por um indivíduo ou organização. Resources são realizados por elementos de estrutura ativa e passiva.
- **Teste do tipo:** é algo que a organização **tem** e usa (informação, pessoas, dinheiro, marca, conhecimento, infraestrutura), não algo que ela faz.
- **Nome:** substantivo (a especificação: "preferably a noun"). Bom: "Histórico clínico dos pacientes", "Equipe de recepção", "Base de contatos". Ruim: "Gerenciar contatos" (comportamento); nome de produto de software na Arquitetura de Referência (o conceito é o recurso; o produto entra na AS).
- **Relações típicas:** atribuído a Capability e a Value Stream; realizado por elementos de estrutura ativa ou passiva (Business Actor, Business Object, Application Component, Data Object...), Product e Location; realiza ou influencia Requirement.

## Capability — `STR-CAP`

- **Definição (§7.3.1):** uma habilidade que um elemento de estrutura ativa (organização, pessoa ou sistema) possui. Capabilities representam o comportamento **potencial**, independente da implementação na estrutura organizacional.
- **Teste do tipo:** responde "o que fazemos", não "como fazemos" nem "em que ordem". Continua verdadeira se o processo, o sistema ou a área responsável mudarem.
- **Nome:** substantivo composto ou substantivo de ação, enfatizando "o que fazemos" (a especificação: "compound noun or gerund... 'Risk Management', 'Market Development'"). Bom: "Gestão de agenda", "Recepção de pacientes", "Faturamento de convênios". Ruim: "Calcular horários livres" (passo: Business Process), "Tela de agenda" (sistema).
- **No epic-flow:** cada Capability tem um `CAP-nn` no rótulo; as regras de numeração e reuso estão em `epic-flow/processo/04-convencoes.md` §5.1.
- **Relações típicas:** serve a Value Stream (a capability "habilita" um estágio); realiza ou serve Course of Action; realizada por Business Function, Business Process, outros comportamentos do núcleo e Plateau; Resource atribuído a ela; realiza ou influencia Requirement (e, por derivação, Principle e Goal); composição e agregação para decompor (nível 1 e 2).

## Value Stream — `STR-VS`

- **Definição (§7.3.2):** uma sequência de atividades que cria um resultado global para um cliente, stakeholder ou usuário final. Os estágios do value stream também são value streams, normalmente ligados por fluxo.
- **Teste do tipo:** é a jornada de valor do ponto de vista de quem recebe o resultado, em estágios; não é a sequência de tarefas de um caso (isso é Business Process).
- **Nome:** verbo + substantivo na voz ativa (a especificação: "Acquire Insurance Product"). Bom: "Obter atendimento" (value stream), com estágios "Marcar consulta", "Fazer check-in", "Ser atendido", "Fazer acompanhamento". Ruim: "Jornada do paciente" (sem verbo), "Sistema de agendamento".
- **Relações típicas:** composição do value stream nos seus estágios; fluxo entre estágios; servido por Capability; realizado por Business Process; realiza ou serve Course of Action; associação com Value (o valor entregue em cada estágio); realiza ou influencia Requirement.

## Course of Action — `STR-CoA`

- **Definição (§7.3.3):** uma abordagem ou plano para configurar capacidades e recursos da organização, adotado para atingir um objetivo. Pode ser classificado como estratégia ou tática.
- **Teste do tipo:** é uma **escolha de caminho** ("vamos fazer assim") que usa capacidades e recursos, não um resultado nem uma tarefa.
- **Nome:** frase da abordagem, com verbo. Bom: "Implantar primeiro em uma unidade-piloto", "Digitalizar a recepção por etapas". Ruim: "Reduzir o tempo de espera" (Goal), "Espera abaixo de 15 min" (Outcome), "Toda informação clínica num único registro" (regra: Principle).
- **Relações típicas:** realiza ou influencia Outcome (e, por derivação, Goal); realiza ou influencia Requirement; é realizado ou servido por Capability e Value Stream; triggering, fluxo e serving entre courses of action.

## Não confundir

| Par | Distinção |
|---|---|
| Capability × Business Process | Capability é o que se faz, estável e sem ordem; Process é como se faz um caso, em sequência. |
| Capability × Business Function | Function descreve a atividade do dia a dia, ligada à estrutura atual; Capability é o potencial, independente da estrutura (§7.3). |
| Value Stream × Business Process | Value Stream é a jornada de valor em estágios, sem ordem de tarefas; Process é a sequência de tarefas de um caso (§7.3.2). Value streams são normalmente realizados por processos. |
| Course of Action × Goal | Course of Action é o caminho escolhido; Goal é aonde se quer chegar. |
| Resource × Business Object | Resource é o ativo do ponto de vista estratégico; o Business Object (ou o Data Object) que o representa no núcleo o realiza. |
