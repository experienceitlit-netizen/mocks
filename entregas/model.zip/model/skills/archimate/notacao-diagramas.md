# Notação: IDs, tabelas e diagramas

## 1. IDs locais

Todo elemento tem um ID local com o prefixo da camada e o código do tipo, numerado a partir de 1 dentro do documento (convenção do fluxo, `epic-flow/processo/04-convencoes.md` §6). Nunca use IDs soltos (`G1`, `D1`, `R1`): colidem com gates e siglas dos insumos.

| Camada | Tipo → código |
|---|---|
| `MOT-` Motivação | Stakeholder `SK` · Driver `D` · Assessment `A` (inclusive «Risco») · Goal `G` · Outcome `O` · Principle `P` · Requirement `R` (inclusive «Medida de controle») · Constraint `K` · Meaning `M` · Value `V` |
| `STR-` Estratégia | Capability `CAP` · Value Stream `VS` · Resource `RES` · Course of Action `CoA` |
| `BUS-` Negócio | Actor `ACT` · Role `RL` · Collaboration `COL` · Interface `IF` · Process `PR` · Function `FN` · Interaction `IX` · Event `EV` · Service `SV` · Object `OB` · Contract `CT` · Representation `REP` · Product `PD` |
| `APP-` Aplicação | Component `AC` · Collaboration `COL` · Interface `AI` · Function `AF` · Interaction `AIX` · Process `AP` · Event `AE` · Service `AS` · Data Object `DO` |
| `TEC-` Tecnologia | Node `N` · Device `DEV` · System Software `SS` · Collaboration `COL` · Interface `TI` · Path `PTH` · Communication Network `NET` · Function `TF` · Process `TP` · Interaction `TIX` · Event `TE` · Service `T` · Artifact `ART` · Equipment `EQ` · Facility `FAC` · Distribution Network `DN` · Material `MAT` |
| `IMP-` Implementação e Migração | Work Package `W` · Deliverable `DL` · Implementation Event `EV` · Plateau `PL` · Gap `GAP` |
| Compostos | Grouping `GRP-` · Location `LOC-` |

Especializações aparecem no rótulo com o estereótipo: `MOT-A3 «Risco» Risco de dado de saúde exposto no check-in`, `MOT-R4 «Medida de controle» Confirmação de identidade no check-in`.

## 2. Tabelas

Tabela de elementos de cada visão: `ID | Tipo | Nome | Descrição | Origem`. O **Tipo** é o nome ArchiMate em inglês (Driver, Assessment, Goal, Outcome...), com a especialização quando houver (`Assessment «Risco»`). A **Origem** cita a fonte (`EP-nn §n`, `RF-nn`, `IN-nnn:L<linha>`, `Q-nnn`) ou "(inferido)".

Tabela de relações de cada visão: `Origem | Relação | Destino | Justificativa`, com o rótulo de relação de `relacoes.md`. Uma relação por linha. Para não repetir, várias origens com o mesmo tipo de relação e o mesmo destino podem ir numa linha (`MOT-R1, MOT-R2 | realização | MOT-O6`); nunca vários destinos numa célula, nem linha sem o tipo de relação.

As tabelas são a fonte da verdade da visão: o diagrama é um recorte delas. Se um diagrama divergir da tabela, vale a tabela e o diagrama é corrigido.

## 3. Arquivos de diagrama

Os diagramas são escritos **só em PlantUML**, cada um num arquivo `.puml` no workspace do fluxo. O documento de arquitetura mostra a imagem `.svg` gerada a partir dele e não traz código de diagrama.

**Pasta.** `epic-flow/workspace/<camada>-layer/<pasta do artefato>/`, onde a pasta do artefato é a mesma do documento:

| Seção do documento | Pasta |
|---|---|
| AR §2 Motivação | `motivation-layer/EP-nn-<slug>/` |
| AR §3 Estratégia | `strategy-layer/EP-nn-<slug>/` |
| AR §4 Negócio (e §5, se o mapa tiver diagrama) | `business-layer/EP-nn-<slug>/` |
| AS Aplicação | `application-layer/FT-nn.nn-<slug>/` |
| AS Tecnologia | `technology-layer/FT-nn.nn-<slug>/` |
| AS Implantação e Migração | `implementation-migration-layer/FT-nn.nn-<slug>/` |

Um diagrama que mistura camadas fica na pasta da seção do documento em que aparece (ex.: "capabilities realizam requirements", na §3, vai para `strategy-layer/`).

**Nome.** `<ID do artefato>-<nn>-<recorte>.puml`: `nn` numera os diagramas do artefato em ordem de aparição no documento, de 01 em diante, sem reiniciar por camada; `<recorte>` em minúsculas, sem acento, palavras separadas por hífen. Ex.: `AR-01-01-stakeholders-e-drivers.puml`, `AR-01-05-capabilities-e-recursos.puml`, `AS-01.02-01-componentes-da-agenda.puml`. Um diagrama por arquivo.

**Referência no documento.** No lugar de cada diagrama, a imagem e o link para o fonte, com caminho relativo ao documento (da AR: `../../workspace/...`; da AS: `../../../../workspace/...`):

```markdown
![AR-01 Motivação: stakeholders e drivers](../../workspace/motivation-layer/EP-01-<slug>/AR-01-01-stakeholders-e-drivers.svg)

Fonte: [`AR-01-01-stakeholders-e-drivers.puml`](../../workspace/motivation-layer/EP-01-<slug>/AR-01-01-stakeholders-e-drivers.puml)
```

O texto alternativo da imagem repete o `title` do diagrama.

**Geração do SVG.** O agente escreve só os `.puml`; nunca escreve nem edita `.svg`. Depois da escrita, o orquestrador roda `epic-flow/scripts/render-diagramas.sh <documento>`, que gera cada `.svg` ao lado do `.puml` e confere as referências. Se o script devolver erro (`<arquivo>:<linha>: <mensagem>`, imagem citada sem `.puml`, `.puml` sem imagem no documento), corrija o `.puml` ou a referência e devolva. Diagrama que deixou de existir: liste o caminho do `.puml` em "Diagramas removidos" no relatório final, e o orquestrador apaga o `.puml` e o `.svg`.

**Governança.** Os `.puml` e `.svg` pertencem ao artefato que os referencia e seguem o status dele: depois do gate, mudar um diagrama é mudar o artefato (`proposta-mudanca`).

## 4. PlantUML

Cada arquivo começa com `@startuml`, a biblioteca e o cabeçalho de §5, e termina com `@enduml`. Biblioteca padrão do PlantUML: `!include <archimate/Archimate>` (versão 3.2 da notação). Cada elemento é uma macro `<Camada>_<Tipo>(alias, "rótulo")`, sem terceiro argumento de descrição.

- **Alias:** o ID com `_` (`MOT_D1`). **Rótulo:** `"MOT-D1 Tempo de espera no atendimento"`; especialização logo depois do ID: `"MOT-A3 «Risco» Risco de dado de saúde exposto no check-in"`.
- **Macros por tipo** (grafia exata):
  - Motivação: `Motivation_Stakeholder`, `Motivation_Driver`, `Motivation_Assessment`, `Motivation_Goal`, `Motivation_Outcome`, `Motivation_Principle`, `Motivation_Requirement`, `Motivation_Constraint`, `Motivation_Meaning`, `Motivation_Value`
  - Estratégia: `Strategy_Resource`, `Strategy_Capability`, `Strategy_ValueStream`, `Strategy_CourseOfAction`
  - Negócio: `Business_Actor`, `Business_Role`, `Business_Collaboration`, `Business_Interface`, `Business_Process`, `Business_Function`, `Business_Interaction`, `Business_Event`, `Business_Service`, `Business_Object`, `Business_Contract`, `Business_Representation`, `Business_Product`
  - Aplicação: `Application_Component`, `Application_Collaboration`, `Application_Interface`, `Application_Function`, `Application_Interaction`, `Application_Process`, `Application_Event`, `Application_Service`, `Application_DataObject`
  - Tecnologia: `Technology_Node`, `Technology_Device`, `Technology_SystemSoftware`, `Technology_Collaboration`, `Technology_Interface`, `Technology_Path`, `Technology_CommunicationNetwork`, `Technology_Function`, `Technology_Process`, `Technology_Interaction`, `Technology_Event`, `Technology_Service`, `Technology_Artifact`; físicos `Physical_Equipment`, `Physical_Facility`, `Physical_DistributionNetwork`, `Physical_Material`
  - Implementação e Migração: `Implementation_WorkPackage`, `Implementation_Deliverable`, `Implementation_Event`, `Implementation_Plateau`, `Implementation_Gap`
  - Compostos: `Grouping(alias, "rótulo") { ... }`, `Other_Location`, `Junction_And`, `Junction_Or`
- **Relações:** `Rel_<Tipo>(origem, destino, "rótulo")`, sempre com o rótulo da relação em português de `relacoes.md` §1 (`"realização"`, `"serve"`, `"acesso (le)"`...): a seta já tem a forma ArchiMate do tipo, e o rótulo deixa o diagrama legível para quem não conhece a notação. Variantes de direção de desenho `_Up`, `_Down`, `_Left`, `_Right` (ex.: `Rel_Realization_Up`). Tipos: `Composition`, `Aggregation`, `Assignment`, `Realization`, `Serving`, `Access`, `Access_r`, `Access_w`, `Access_rw`, `Influence`, `Association`, `Association_dir`, `Triggering`, `Flow`, `Specialization`. No `Rel_Influence`, o rótulo leva o sinal quando houver (`"influência (+)"`, `"influência (-)"`).
- **Não existem** (erros comuns): `Rel_UsedBy`, `Rel_Used_By`, `Rel_Specialisation`, `Rel_Access_Read`, `Application_Data_Object`, `Strategy_Value_Stream`, `Technology_Network`, `Motivation_Concern`, e direções `_U`, `_D` (essas só existem em `Lay_U`, `Lay_D`... para alinhar sem desenhar relação).

- **Sequência** (AS, visão de cooperação e fluxo): diagrama de sequência do PlantUML, sem a biblioteca `archimate`, no mesmo esquema de arquivo e nome (pasta `application-layer/`). Participantes com o ID e o nome do elemento (`participant "APP-AC1 Serviço de agenda" as APP_AC1`), mensagens com o serviço ou o dado trocado, e o cabeçalho com `skinparam backgroundColor #FFFFFF` e `title`.

## 5. Tamanho e layout dos diagramas

A imagem é encolhida até caber na largura da página do documento: um diagrama largo fica ilegível (e o preview em PNG do PlantUML corta tudo além de 4096 px). Desenhe para caber em pé:

1. **No máximo 15 elementos e 25 relações por diagrama.** Passou disso, quebre a visão em mais diagramas por tema, cada um com um título que diga o recorte. Recortes típicos:
   - Motivação: stakeholders → drivers → assessments → goals; goals → outcomes; requirements e constraints → outcomes (um diagrama por outcome ou grupo de outcomes, quando a relação for muitos-para-muitos); riscos e medidas de controle.
   - Estratégia: capabilities e recursos; value stream e seus estágios; capabilities → requirements (por grupo de capabilities).
   - Negócio e núcleo: um diagrama por processo ou por estágio do value stream.

   Um elemento pode aparecer em mais de um diagrama. As tabelas continuam completas, e toda relação das tabelas aparece em pelo menos um diagrama.
2. **Direção do desenho:**
   - **Da esquerda para a direita** (`LAYOUT_LEFT_RIGHT()`) em Motivação, Estratégia e diagramas de rastreabilidade, e sempre que muitos elementos se ligam a poucos (vários requirements realizando um outcome). Assim os elementos de mesmo nível ficam empilhados numa coluna, e não lado a lado.
   - **De cima para baixo** (padrão do PlantUML, sem macro) em Negócio, Aplicação e Tecnologia, onde a cadeia de processos e as camadas se leem de cima para baixo.
   - Se a direção escolhida deixaria mais de 6 elementos lado a lado numa fileira (de cima para baixo) ou mais de 5 colunas encadeadas (da esquerda para a direita), use a outra ou quebre o diagrama.
3. **Cabeçalho PlantUML fixo**, logo depois do `!include` (acrescente aos `skinparam` exigidos pelas referências corporativas, se houver). `LAYOUT_LEFT_RIGHT()` só quando a regra 2 pede. `backgroundColor` garante fundo branco atrás das setas e rótulos (que são escuros) também em visualizador de tema escuro; não use `!theme` nem troque as cores da biblioteca. `wrapWidth` quebra os nomes longos em várias linhas e deixa o elemento estreito; não quebre o nome à mão com `\n`.

```
LAYOUT_LEFT_RIGHT()
skinparam backgroundColor #FFFFFF
skinparam wrapWidth 180
skinparam nodesep 12
skinparam ranksep 60
title <ID do artefato> <Visão>: <recorte>
```

## 6. Exemplo completo (domínio fictício)

Arquivo `epic-flow/workspace/motivation-layer/EP-01-<slug>/AR-01-01-espera-no-atendimento.puml`:

```plantuml
@startuml
!include <archimate/Archimate>
LAYOUT_LEFT_RIGHT()
skinparam backgroundColor #FFFFFF
skinparam wrapWidth 180
skinparam nodesep 12
skinparam ranksep 60
title AR-01 Motivação: espera no atendimento
Motivation_Stakeholder(MOT_SK1, "MOT-SK1 Paciente")
Motivation_Driver(MOT_D1, "MOT-D1 Tempo de espera no atendimento")
Motivation_Assessment(MOT_A1, "MOT-A1 Pacientes esperam em média 50 min além do horário")
Motivation_Goal(MOT_G1, "MOT-G1 Reduzir o tempo de espera")
Motivation_Outcome(MOT_O1, "MOT-O1 Espera média abaixo de 15 min até dez/2027")
Motivation_Requirement(MOT_R1, "MOT-R1 Check-in do paciente sem passar pelo balcão")
Motivation_Constraint(MOT_K1, "MOT-K1 Base de pacientes só no prontuário atual")
Motivation_Assessment(MOT_A2, "MOT-A2 «Risco» Risco de dado de saúde exposto no check-in")
Motivation_Requirement(MOT_R2, "MOT-R2 «Medida de controle» Confirmação de identidade no check-in")
Rel_Association(MOT_SK1, MOT_D1, "associação")
Rel_Association(MOT_D1, MOT_A1, "associação")
Rel_Association(MOT_A1, MOT_G1, "associação")
Rel_Realization(MOT_O1, MOT_G1, "realização")
Rel_Realization(MOT_R1, MOT_O1, "realização")
Rel_Influence(MOT_K1, MOT_R1, "influência")
Rel_Association(MOT_A2, MOT_D1, "associação")
Rel_Influence(MOT_R2, MOT_A2, "influência (-)")
@enduml
```

Na §2 do documento, depois das tabelas de elementos e relações:

```markdown
![AR-01 Motivação: espera no atendimento](../../workspace/motivation-layer/EP-01-<slug>/AR-01-01-espera-no-atendimento.svg)

Fonte: [`AR-01-01-espera-no-atendimento.puml`](../../workspace/motivation-layer/EP-01-<slug>/AR-01-01-espera-no-atendimento.puml)
```
