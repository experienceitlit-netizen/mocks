# Relações (ArchiMate 3.2, cap. 5, 6.6, 7.6, 11, 12 e apêndice B)

## 1. Tipos de relação

A direção é sempre **origem → destino**, como na tabela. O rótulo em português é o que vai nas arestas dos diagramas (`notacao-diagramas.md`).

| Relação | Rótulo | Definição (ArchiMate 3.2) | Direção | PlantUML |
|---|---|---|---|---|
| Composição | `composição` | §5.1.1: um elemento consiste de um ou mais conceitos (a parte não existe sem o todo) | todo → parte | `Rel_Composition` |
| Agregação | `agregação` | §5.1.2: um elemento combina um ou mais conceitos (a parte existe sozinha) | todo → parte | `Rel_Aggregation` |
| Atribuição | `atribuição` | §5.1.3: alocação de responsabilidade, execução de comportamento, armazenamento ou execução | estrutura ativa → comportamento; comportamento → passiva; ativa → passiva | `Rel_Assignment` |
| Realização | `realização` | §5.1.4: um elemento tem papel crítico na criação, alcance, sustentação ou operação de um elemento mais abstrato | concreto → abstrato | `Rel_Realization` |
| Serve | `serve` | §5.2.1: um elemento fornece sua funcionalidade a outro (o antigo "used by" está depreciado) | provedor → consumidor | `Rel_Serving` |
| Acesso | `acesso (l)`, `acesso (e)`, `acesso (le)` | §5.2.2: comportamento ou estrutura ativa observa ou age sobre estrutura passiva | sempre de quem acessa → objeto; leitura/escrita só muda a ponta | `Rel_Access_r`, `Rel_Access_w`, `Rel_Access_rw`, `Rel_Access` |
| Influência | `influência (+)`, `influência (-)`, `influência` | §5.2.3: um elemento afeta a implementação ou o alcance de um elemento de **motivação** | qualquer → motivação | `Rel_Influence` |
| Associação | `associação` | §5.2.4: relação não especificada, ou que nenhuma outra relação representa; sempre permitida entre dois elementos | sem direção (ou com direção, se informada) | `Rel_Association`, `Rel_Association_dir` |
| Disparo | `dispara` | §5.3.1: relação temporal ou causal | antes → depois | `Rel_Triggering` |
| Fluxo | `fluxo: <o quê>` | §5.3.2: transferência de um elemento a outro, sem implicar causalidade | origem → destino da transferência | `Rel_Flow` |
| Especialização | `especialização` | §5.4.1: um elemento é um tipo particular de outro (só entre elementos do mesmo tipo) | específico → geral | `Rel_Specialization` |

**Realização × influência (§5.2.3).** Realização quando o elemento é **crítico** para a existência ou o alcance do alvo; influência quando o efeito é parcial ou não crítico. Influência só aponta para elemento de motivação.

**Associação × influência na Motivação** (convenção do fluxo; a especificação também permite influência entre quaisquer elementos de motivação). Use o par da tabela da §3: Stakeholder, Driver, Assessment e Goal se ligam por **associação** (é o que o metamodelo define entre eles). Use **influência** só para dizer que um elemento contribui (+) ou atrapalha (-) o alcance de outro, quando não há realização: Goal que contribui para Goal, Constraint que condiciona Requirement, «Medida de controle» sobre «Risco».

**Junção (§5.5.1).** Liga relações do mesmo tipo (e/ou). Não pode criar uma relação que seria proibida sem ela.

## 2. Restrições de domínio (apêndice B.4)

Valem para qualquer relação, direta ou derivada:

| De | Para | Só são permitidas |
|---|---|---|
| Núcleo, Estratégia, Implementação e Migração | Motivação | atribuição (só de estrutura ativa de negócio para Stakeholder), realização, influência, associação |
| Motivação | qualquer elemento fora da Motivação | associação |
| Núcleo, Implementação e Migração | Estratégia | realização, associação |
| Estratégia | Núcleo, Implementação e Migração | associação |
| Estrutura passiva | Estrutura passiva | realização, associação (além de composição, agregação e especialização entre elementos do mesmo tipo) |
| qualquer | elemento fora da Motivação | **nunca** influência |

Consequências práticas:
- Elemento de motivação nunca serve, dispara, acessa nem realiza elemento do núcleo ou da estratégia.
- Capability não serve nem realiza Business Process: é o Process (ou a Function) que **realiza** a Capability.
- Elemento de estratégia só chega ao núcleo por associação.

## 3. Pares permitidos mais usados

Lista verificada nos metamodelos da especificação. Todo elemento admite composição, agregação e especialização com elementos do mesmo tipo; associação é sempre permitida (use só quando nada abaixo se aplica).

### Dentro da Motivação (metamodelo de motivação)

| Origem | Relação | Destino |
|---|---|---|
| Stakeholder | associação | Driver, Value, Meaning |
| Driver | associação | Assessment, Goal |
| Assessment | associação | Goal, Outcome |
| Outcome | realização | Goal |
| Principle | realização | Outcome (e Goal, por derivação) |
| Requirement, Constraint | realização | Outcome, Principle (e Goal, por derivação) |
| Value | associação | Outcome |
| qualquer elemento de motivação | influência | qualquer elemento de motivação |

### Motivação com o núcleo (§6.6)

| Origem | Relação | Destino |
|---|---|---|
| Elemento de estrutura ou comportamento (negócio, aplicação, tecnologia) | realização ou influência | Requirement, Constraint (e, por derivação, Principle, Outcome, Goal) |
| Business Actor, Role, Collaboration | atribuição | Stakeholder |
| Meaning, Value | associação | qualquer elemento de estrutura ou comportamento |

### Estratégia (metamodelo de estratégia e §7.6)

| Origem | Relação | Destino |
|---|---|---|
| Resource | atribuição | Capability, Value Stream |
| Capability | serve | Value Stream, Capability |
| Capability, Value Stream | realização ou serve | Course of Action |
| Capability, Value Stream | dispara, fluxo, serve | Capability, Value Stream |
| Course of Action | dispara, fluxo, serve | Course of Action |
| Capability, Value Stream, Course of Action, Resource | realização ou influência | Requirement, Constraint (e, por derivação, Principle, Goal) |
| Course of Action | realização ou influência | Outcome (e, por derivação, Goal) |
| Business Process, Function, Interaction, Service (e comportamentos de aplicação e tecnologia) | realização | Capability, Value Stream |
| Elemento de estrutura ativa ou passiva, Product, Location | realização | Resource |
| Plateau | realização | Capability |

### Negócio (cap. 8)

| Origem | Relação | Destino |
|---|---|---|
| Business Actor | atribuição | Business Role |
| Actor, Role, Collaboration | atribuição | Process, Function, Interaction |
| Business Interface | atribuição | Business Service |
| Actor, Role | composição | Business Interface |
| Process, Function, Interaction | realização | Business Service |
| Business Service | serve | Process, Function, Interaction, Actor, Role |
| Process, Function, Interaction | acesso | Business Object |
| Business Event | dispara | Process, Function, Interaction |
| Process, Function, Interaction | dispara, fluxo | Process, Function, Interaction, Event |
| Representation | realização | Business Object |
| Product | agregação ou composição | Service, Business Object, Contract |

### Aplicação e Tecnologia (cap. 9, 10 e 11)

| Origem | Relação | Destino |
|---|---|---|
| Application Component | composição | Application Interface |
| Application Component | atribuição | Application Function, Process, Interaction |
| Application Interface | atribuição | Application Service |
| Application Function, Process | realização | Application Service |
| comportamento de aplicação | acesso | Data Object |
| Application Event | dispara | comportamento de aplicação |
| Application Service | serve | comportamento de negócio, Business Actor/Role, comportamento de aplicação |
| Application Interface | serve | Business Role |
| Data Object | realização | Business Object |
| Application Process, Function, Interaction | realização | Business Process, Function, Interaction |
| Application Event | realização | Business Event |
| Node, Device, System Software | atribuição | Artifact |
| Device, System Software | atribuição | System Software |
| Node | composição ou agregação | Device, System Software |
| Communication Network | realização | Path |
| Artifact | realização | Application Component, Data Object |
| Technology Service | serve | comportamento de aplicação |
| Technology Interface | serve | Application Component |
| Technology Process, Function | realização | Application Process, Function |

Nenhum elemento de aplicação ou tecnologia realiza Business Actor, Role ou Collaboration: pessoas não são realizadas por sistemas (§11).

### Implementação e Migração (cap. 12)

| Origem | Relação | Destino |
|---|---|---|
| Business Actor, Role | atribuição | Work Package |
| Work Package | dispara | Work Package, Implementation Event |
| Implementation Event | dispara | Work Package, Plateau |
| Work Package | acesso | Deliverable (não use realização: depreciada) |
| Deliverable | realização | qualquer elemento do núcleo, Plateau |
| Work Package, Deliverable | realização ou influência | Requirement, Constraint |
| Plateau | agregação ou composição | elementos do núcleo, Goal, Outcome, Requirement |
| Plateau | realização | Capability |
| Gap | associação | Plateau, elementos do núcleo |

## 4. Quando o par não está aqui

1. Confira as restrições de domínio (§2). Se proibido, a relação não existe: reveja a classificação dos elementos (o erro costuma estar no tipo, não na relação).
2. Se permitido pelo domínio mas ausente das listas, a relação específica pode existir na tabela completa da especificação (apêndice B), que esta skill não reproduz. Não a use sem verificar: use associação (sempre válida), com a justificativa na tabela de relações.
