# Camada de Negócio (ArchiMate 3.2, cap. 8)

Elementos de **estrutura ativa** (quem faz: substantivos), **comportamento** (o que se faz: verbos) e **estrutura passiva** (sobre o que se faz: substantivos). A camada descreve a operação, não os sistemas.

Exemplos no domínio fictício da rede de clínicas (`prd-para-archimate.md` §1).

## Estrutura ativa

### Business Actor — `BUS-ACT`
- **Definição (§8.2.1):** uma entidade de negócio capaz de executar comportamento. Pode ser específica ("João Silva") ou genérica ("cliente").
- **Teste do tipo:** é uma pessoa, organização ou unidade que **existe** e age.
- **Nome:** substantivo. Bom: "Paciente", "Clínica", "Operadora de convênio".
- **Relações típicas:** atribuído a Business Role e a comportamento; atribuído a Stakeholder; atribuído a Work Package.

### Business Role — `BUS-RL`
- **Definição (§8.2.2):** a responsabilidade por executar um comportamento específico, à qual um actor pode ser atribuído, ou o papel que um actor desempenha numa ação ou evento.
- **Distinção da especificação:** o actor "Fornecedor" é a entidade; o role "Fornecedor" é a responsabilidade.
- **Nome:** substantivo da responsabilidade. Bom: "Recepcionista", "Profissional de saúde", "Responsável pelo agendamento".
- **Relações típicas:** Actor atribuído ao Role; Role atribuído a Process, Function, Interaction; servido por Business Service e Application Service/Interface.

### Business Collaboration — `BUS-COL`
- **Definição (§8.2.3):** um agregado de dois ou mais elementos de estrutura ativa interna de negócio que trabalham juntos para executar comportamento coletivo. Nome: substantivo (é comum deixar sem nome).

### Business Interface — `BUS-IF`
- **Definição (§8.2.4):** um ponto de acesso onde serviços de negócio ficam disponíveis ao ambiente. Frequentemente um canal (telefone, internet, balcão).
- **Nome:** substantivo do canal. Bom: "Central telefônica", "Balcão de atendimento".
- **Relações típicas:** atribuída a Business Service; composta em Actor/Role.

## Comportamento

### Business Process — `BUS-PR`
- **Definição (§8.3.1):** uma sequência de comportamentos de negócio que alcança um resultado específico, como um conjunto definido de produtos ou serviços de negócio.
- **Teste do tipo:** tem início, passos em ordem e fim, para um caso.
- **Nome:** verbo ou verbo + substantivo (a especificação: "adjudicate claim"). Bom: "Fazer check-in do paciente", "Marcar consulta". Ruim: "Agendamento" (substantivo: Service ou Function), "Agenda" (Object).
- **Relações típicas:** realiza Business Service; realiza Value Stream e Capability; Role/Actor atribuído a ele; acessa Business Object; disparado por Business Event e dispara outros processos; servido por Application Service.

### Business Function — `BUS-FN`
- **Definição (§8.3.2):** uma coleção de comportamento de negócio baseada num conjunto de critérios escolhidos (recursos ou competências necessários), gerida ou executada como um todo.
- **Teste do tipo:** agrupa atividades por competência, sem ordem nem caso.
- **Nome:** substantivo de área de atuação (a especificação: "customer management", "claims administration"). Bom: "Gestão da agenda", "Atendimento ao paciente".
- **Relações típicas:** realiza Capability e Business Service; composta de processos; Role atribuído a ela.

### Business Interaction — `BUS-IX`
- **Definição (§8.3.3):** uma unidade de comportamento coletivo executada por dois ou mais actors, roles ou collaborations. Nome: verbo no presente (ex.: "Negociar reembolso").

### Business Event — `BUS-EV`
- **Definição (§8.3.4):** uma mudança de estado relacionada ao negócio. Instantâneo.
- **Nome:** verbo no particípio (a especificação: "claim received"). Bom: "Consulta marcada", "Paciente chegou", "Horário da consulta atingido". Ruim: "Agendar consulta" (Process).
- **Relações típicas:** dispara Process/Function/Interaction; é disparado por eles; realizado por Application/Technology Event.

### Business Service — `BUS-SV`
- **Definição (§8.3.5):** comportamento explicitamente definido que um role, actor ou collaboration expõe ao seu ambiente. É o comportamento visto de fora; para o consumidor, o processo que o realiza é uma caixa-preta.
- **Nome:** substantivo de ação (equivalente ao "-ing" da especificação) ou nome com a palavra "serviço". Bom: "Check-in de pacientes", "Serviço de marcação de consultas". Ruim: "Fazer check-in do paciente" (Process: é a parte interna), "Agendar consulta" (Process: é a parte interna).
- **Relações típicas:** realizado por Process/Function/Interaction; serve Role/Actor e comportamentos; Business Interface atribuída a ele; agregado em Product.

## Estrutura passiva

### Business Object — `BUS-OB`
- **Definição (§8.4.1):** um conceito usado num domínio de negócio específico.
- **Nome:** substantivo. Bom: "Consulta", "Agenda do profissional", "Ficha do paciente".
- **Relações típicas:** acessado por comportamento; realizado por Data Object e por Representation.

### Contract — `BUS-CT`
- **Definição (§8.4.2):** especificação formal ou informal de um acordo entre provedor e consumidor, com direitos e obrigações associados a um produto e parâmetros de interação. Especialização de Business Object. Ex.: "Contrato com operadora de convênio".

### Representation — `BUS-REP`
- **Definição (§8.4.3):** uma forma perceptível da informação carregada por um Business Object. Ex.: "Comprovante de check-in", "Painel de chamada".
- **Relações típicas:** realiza Business Object.

### Product — `BUS-PD`
- **Definição (§8.5.1):** uma coleção coerente de serviços e/ou elementos de estrutura passiva, acompanhada de um contrato, oferecida como um todo a clientes internos ou externos. Ex.: "Plano de acompanhamento mensal".
- **Relações típicas:** agrega ou compõe Business/Application/Technology Service, Business/Data Object, Contract.

## Não confundir

| Par | Distinção |
|---|---|
| Process × Function | Process é fluxo ordenado de um caso; Function agrupa por competência (relação muitos-para-muitos entre eles). |
| Process × Service | Service é o comportamento visto de fora; Process é a parte interna que o realiza. |
| Process × Event | Process tem duração e verbo ativo; Event é instantâneo e no particípio. |
| Actor × Role | Actor é a entidade; Role é a responsabilidade que ela assume. |
| Actor/Role × Stakeholder | Stakeholder é interesse (Motivação); Actor/Role é quem executa (Negócio). |
| Business Object × Data Object | Business Object é o conceito do negócio; Data Object é o dado estruturado para processamento automático, que o realiza (AS). |
