# Camadas de Aplicação (cap. 9) e Tecnologia (cap. 10)

Usadas na Arquitetura de Solução (E4). A mesma lógica da camada de Negócio: estrutura ativa (substantivo), comportamento (verbo), estrutura passiva (substantivo); serviço é o comportamento visto de fora, interface é o ponto de acesso a ele.

No epic-flow, componentes aparecem pelo **nome canônico** de `transversal/catalogo-componentes.md`, e plataformas só as da referência `stack`.

## Aplicação

| Elemento | ID | Definição (ArchiMate 3.2) | Nome |
|---|---|---|---|
| Application Component | `APP-AC` | §9.2.1: encapsulamento de funcionalidade de aplicação alinhado à estrutura de implementação, modular e substituível | substantivo; nome canônico do catálogo ("Serviço de agenda", "Portal do paciente") |
| Application Collaboration | `APP-COL` | §9.2.2: agregado de dois ou mais componentes que trabalham juntos em comportamento coletivo | substantivo |
| Application Interface | `APP-AI` | §9.2.3: ponto de acesso onde serviços de aplicação ficam disponíveis a um usuário, outro componente ou um nó | substantivo do ponto de acesso ("API de agendamento", "Tela de agenda") |
| Application Function | `APP-AF` | §9.3.1: comportamento automatizado que um componente pode executar | substantivo de ação ("Cálculo de disponibilidade") |
| Application Interaction | `APP-AIX` | §9.3.2: comportamento coletivo de dois ou mais componentes | verbo no presente |
| Application Process | `APP-AP` | §9.3.3: sequência de comportamentos de aplicação que alcança um resultado específico | verbo + substantivo ("Atualizar a fila de atendimento") |
| Application Event | `APP-AE` | §9.3.4: mudança de estado da aplicação | particípio ("Check-in registrado") |
| Application Service | `APP-AS` | §9.3.5: comportamento de aplicação explicitamente definido e exposto | substantivo de ação ou com "serviço" ("Consulta de horários livres") |
| Data Object | `APP-DO` | §9.4.1: dados estruturados para processamento automatizado | substantivo ("Registro de consulta") |

Relações típicas na Aplicação:
- Component **composto de** Interface; Component **atribuído a** Function/Process; Interface **atribuída a** Service.
- Function/Process **realiza** Application Service; comportamento **acessa** Data Object; Event **dispara** comportamento.
- Para cima: Application Service **serve** Business Process/Function/Role; Application Interface **serve** Business Role; Data Object **realiza** Business Object; Application Process/Function **realiza** Business Process/Function; Application Event **realiza** Business Event.
- Pessoas não são realizadas por aplicação: nenhum elemento de aplicação realiza Business Actor ou Role (§11).

## Tecnologia

| Elemento | ID | Definição (ArchiMate 3.2) | Nome |
|---|---|---|---|
| Node | `TEC-N` | §10.2.1: recurso computacional ou físico que hospeda, manipula ou interage com outros recursos | substantivo ("Servidor de aplicação", "Ambiente de produção") |
| Device | `TEC-DEV` | §10.2.2: recurso físico de TI onde software de sistema e artefatos são armazenados ou implantados | tipo de hardware ("Smartphone do paciente") |
| System Software | `TEC-SS` | §10.2.3: software que fornece ambiente para armazenar, executar e usar software ou dados implantados nele | produto ou tipo ("PostgreSQL", "Node.js 24") |
| Technology Collaboration | `TEC-COL` | §10.2.4: agregado de elementos de tecnologia que trabalham juntos | substantivo |
| Technology Interface | `TEC-TI` | §10.2.5: ponto de acesso a serviços de tecnologia | substantivo ("Porta HTTPS", "Endpoint SMTP") |
| Path | `TEC-PTH` | §10.2.6: ligação entre elementos de tecnologia pela qual trocam dados, energia ou material | substantivo |
| Communication Network | `TEC-NET` | §10.2.7: estruturas que conectam dispositivos ou software de sistema para transmitir dados; realiza paths | substantivo ("Internet", "Rede interna") |
| Technology Function | `TEC-TF` | §10.3.1: coleção de comportamento de tecnologia | substantivo de ação ("Replicação de dados") |
| Technology Process | `TEC-TP` | §10.3.2: sequência de comportamentos de tecnologia com resultado específico | verbo + substantivo ("Fazer backup noturno") |
| Technology Interaction | `TEC-TIX` | §10.3.3: comportamento coletivo de elementos de tecnologia | verbo no presente |
| Technology Event | `TEC-TE` | §10.3.4: mudança de estado de tecnologia | particípio ("Mensagem recebida") |
| Technology Service | `TEC-T` | §10.3.5: comportamento de tecnologia explicitamente definido e exposto | substantivo de ação ("Envio de e-mail", "Armazenamento de arquivos") |
| Artifact | `TEC-ART` | §10.4.1: dado usado ou produzido no desenvolvimento de software, ou na implantação e operação de um sistema | nome do arquivo ou pacote ("agenda-api.jar", "imagem agenda-api:1.4") |
| Equipment, Facility, Distribution Network, Material | `TEC-EQ`, `TEC-FAC`, `TEC-DN`, `TEC-MAT` | §10.6–10.7: elementos físicos | substantivo; raros em software |

Relações típicas na Tecnologia:
- Node/Device/System Software **atribuído a** Artifact (implantação); Device ou System Software **atribuído a** System Software; Node **composto de** Device e System Software.
- Communication Network **realiza** Path.
- Para cima: Artifact **realiza** Application Component e Data Object; Technology Service **serve** comportamento de aplicação; Technology Interface **serve** Application Component; Technology Process/Function **realiza** Application Process/Function.

## Não confundir

| Par | Distinção |
|---|---|
| Component × Service | Component é a peça substituível; Service é o comportamento que ela expõe. |
| Service × Interface | Service é o quê; Interface é por onde se acessa. |
| Function × Process | Function agrupa comportamento; Process é sequência com resultado. |
| Data Object × Artifact | Data Object é o dado lógico; Artifact é o arquivo físico que o realiza. |
| Node × System Software | Node é o recurso que hospeda; System Software é o software de ambiente que roda nele. |
