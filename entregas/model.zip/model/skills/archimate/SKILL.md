---
name: archimate
description: Modelagem em ArchiMate 3.2 fiel à especificação da The Open Group. Use ao escrever ou revisar arquiteturas (Arquitetura de Referência no E2, Arquitetura de Solução no E4 do epic-flow) — classificar enunciados do PRD e dos insumos no tipo de elemento correto (Driver, Assessment, Goal, Outcome, Requirement, Constraint, Capability, Process, Service, Component...), nomear cada elemento pela convenção do seu tipo, escolher só relações permitidas e desenhar os diagramas em PlantUML (arquivos `.puml` no workspace do fluxo, referenciados no documento pela imagem `.svg`).
---

# Modelagem ArchiMate 3.2

Fonte normativa: *ArchiMate® 3.2 Specification*, The Open Group (C226, outubro de 2022). As definições desta skill são traduções da especificação, com a seção citada. Quando esta skill e um costume local divergirem, vale a especificação; quando a especificação não decide, vale a convenção marcada aqui como **convenção do fluxo**.

Os exemplos desta skill são de um domínio fictício (uma rede de clínicas que quer reduzir o tempo de espera). Servem para mostrar o padrão; **nunca** copie nomes, números ou elementos deles para um artefato. O conteúdo vem só das fontes permitidas do projeto.

Esta skill trata só da notação e da semântica. Processo, IDs de artefato, `CAP-nn`, gates e isolamento de fontes continuam definidos em `epic-flow/processo/`; os códigos de tipo dos IDs locais (`04-convencoes.md` §6) cobrem todos os elementos desta skill, inclusive Outcome, Meaning e Value.

## Arquivos de apoio

Leia o arquivo da camada antes de modelá-la. Não modele de memória.

| Arquivo | Quando ler |
|---|---|
| [prd-para-archimate.md](prd-para-archimate.md) | **Sempre, primeiro.** Como ler o PRD e os insumos e decidir o tipo de cada enunciado |
| [elementos-motivacao.md](elementos-motivacao.md) | Visão de Motivação (E2) |
| [elementos-estrategia.md](elementos-estrategia.md) | Visão de Estratégia (E2) |
| [elementos-negocio.md](elementos-negocio.md) | Visão de Negócio (E2) |
| [elementos-aplicacao-tecnologia.md](elementos-aplicacao-tecnologia.md) | Visões de Aplicação e Tecnologia (E4) |
| [elementos-implementacao-migracao.md](elementos-implementacao-migracao.md) | Implantação e Migração (E4), Grouping e Location |
| [relacoes.md](relacoes.md) | Sempre que ligar dois elementos |
| [notacao-diagramas.md](notacao-diagramas.md) | Ao escrever IDs, tabelas, arquivos de diagrama (pastas, nomes, referência no documento) e PlantUML |

## Procedimento

1. **Inventário de enunciados.** Liste os enunciados do PRD e das fichas de insumo que serão modelados, cada um com a fonte (`EP-nn §n`, `RF-nn`, `IN-nnn:L<linha>`). Um enunciado pode conter mais de um conceito: uma "dor" costuma ser um Driver (o tema) mais um Assessment (a constatação) mais um Goal (o que se quer). Separe antes de classificar.
2. **Classificação.** Para cada conceito, percorra a árvore de decisão de `prd-para-archimate.md` e aplique o **teste do tipo** no arquivo da camada. Se dois tipos parecerem possíveis, a distinção está na seção "Não confundir" do arquivo da camada; se mesmo assim não houver base no insumo, registre `Q-nnn` em vez de escolher.
3. **Nome.** Escreva o nome pela convenção do tipo (tabela "Nome" de cada elemento). O nome sozinho deve deixar claro o tipo: um Goal nunca tem cara de tarefa, um Assessment nunca tem cara de hipótese, um Process nunca é um substantivo solto.
4. **Relações.** Ligue os elementos só com relações permitidas (`relacoes.md`). Prefira a relação mais específica; `associação` só quando nenhuma outra se aplica. Nunca crie relação que a especificação não permite, nem por junção.
5. **Diagramas.** Escreva cada diagrama em PlantUML, num arquivo `.puml` na pasta da camada e do artefato, e referencie no documento a imagem `.svg` e o fonte, conforme `notacao-diagramas.md` §3. Toda aresta tem o tipo de relação escrito; todo elemento usa a macro do seu tipo. Cada diagrama respeita o tamanho, a direção e o cabeçalho de §5, para ficar legível na largura da página. Os `.svg` são gerados pelo orquestrador; erros que ele devolver, você corrige no `.puml`.
6. **Verificação.** Rode o checklist abaixo item a item e corrija antes de entregar.

## Checklist antes de entregar

- [ ] Cada elemento passou no teste do tipo da sua ficha; nenhum foi classificado só pela palavra usada no insumo ("dor", "risco", "objetivo", "necessidade" não determinam o tipo).
- [ ] Cada nome segue a convenção do tipo.
- [ ] Driver é um tema ou condição (substantivo), sem verbo de ação e sem juízo de valor.
- [ ] Assessment é uma constatação sobre a situação da organização ou do seu ambiente, com evidência no insumo; nenhum Assessment simples fala de algo que ainda não existe nem usa "pode", "poderia" ou "risco de".
- [ ] Goal é qualitativo; meta com número, alvo ou prazo é Outcome.
- [ ] Principle vale para qualquer sistema do contexto; o que vale só para o sistema em construção é Requirement; limitação imposta à solução é Constraint.
- [ ] Riscos seguem a regra de `prd-para-archimate.md` (§ Riscos), sempre com o estereótipo «Risco» visível.
- [ ] Capability é o que o negócio faz (substantivo), nunca o passo de um processo nem uma função de sistema.
- [ ] Process tem verbo; Service é o comportamento visto de fora; Event está no particípio.
- [ ] A Arquitetura de Referência (Motivação, Estratégia, Negócio) não cita tecnologia, biblioteca nem produto de software; isso pertence à Arquitetura de Solução.
- [ ] Toda relação existe em `relacoes.md` para o par de tipos, com a direção correta.
- [ ] Diagramas só em PlantUML, um por arquivo `.puml` na pasta `epic-flow/workspace/<camada>-layer/<pasta do artefato>/`, com o nome `<ID do artefato>-<nn>-<recorte>.puml`; no documento, cada diagrama é a imagem `.svg` com o link `Fonte:` para o `.puml`, sem código de diagrama no documento (`notacao-diagramas.md` §3).
- [ ] Toda relação dos diagramas tem o rótulo em português de `relacoes.md` §1; todo elemento usa a macro do seu tipo, com a especialização no rótulo; os diagramas batem com as tabelas.
- [ ] Cada diagrama tem no máximo 15 elementos e 25 relações, a direção da regra de layout e o cabeçalho completo de `notacao-diagramas.md` §5 (`backgroundColor`, `wrapWidth`, espaçamento, `title`); nenhuma fileira com mais de 6 elementos lado a lado nem mais de 5 colunas encadeadas.
- [ ] IDs locais com o prefixo da camada (`notacao-diagramas.md`).
- [ ] Toda inferência está marcada "(inferido)"; o que o insumo não sustenta virou `Q-nnn`.
