# Anexo A1 — Análise dos fluxos de produto (Cobrança, Multipag, PIX, Arrecadação)

**Fontes analisadas:** `docs-precificacao/01-cobrança-fluxo.md`, `02-multipag-fluxo.md`, `03-pix-fluxo.md`, `04-arrecadação-fluxo.md`. Contexto: `00-doc-negocio.md` e `00-etapas-geracao-planilha-ano1.md`.

**Convenções deste anexo**

- Referências de linha no formato `arquivo:Lxx-yy` apontam para o arquivo fonte na pasta `docs-precificacao`.
- Tudo que não está escrito explicitamente nos documentos e foi deduzido pelo analista está marcado como **(inferido)**.
- "Onda 3 do Pricing Cash" é o nome que os quatro documentos dão ao ciclo de reprecificação que consome os arquivos `*_vats.xlsx` gerados pelos fluxos.
- As capacidades citadas na seção 8 de cada produto: **C1** Cálculo/Simulação de preços; **C2** Onda de Reprecificação; **C3** Gestão de Reciprocidade; além de **PAR** (Parametrização) e **LEG** (dependência de legado/base histórica).

---

## Cobrança (fonte: `01-cobrança-fluxo.md`)

### 1. Objetivo do fluxo

O fluxo tem duas etapas. A Etapa 1 carrega os eventos tarifados de cobrança, trata, enriquece com segmento e UF, exclui poder público e o grupo Bradesco, e gera uma "base de cobrança tratada" com indicadores anuais (LTM, 13 meses) e a tarifa praticada por grupo econômico e produto (`01-cobrança-fluxo.md:L3-19`). A Etapa 2 calcula o potencial de uplift (aumento) de tarifa, segmentando clientes por tier de volume e cluster, estimando percentis de tarifa por cluster e aplicando a regra de preço-alvo (`01-cobrança-fluxo.md:L21-33`). O resultado alimenta a decisão de reprecificação de cobrança da Onda 3 do Pricing Cash (`01-cobrança-fluxo.md:L124`).

### 2. Bases de entrada

| Base | Janela temporal | Campos-chave usados | Observações |
|---|---|---|---|
| Eventos tarifados de Cobrança | "atual" (`00-etapas-geracao-planilha-ano1.md:L12`) | CNPJ/CPF, DESCR_TARIFA (`01:L55`), quantidade tarifada mensal (QT_MENSAL/QTD_MENSAL), valor tarifado | Fonte primária da Etapa 1 (`01:L5`). O doc 01 não nomeia o arquivo físico. |
| Cobrança Movimento | últimos 12 meses (`00-etapas:L11`) | **(inferido)** volumes mensais | Não citada explicitamente no doc 01; a consolidação LTM de 13 meses (`01:L17`) sugere uso de histórico de movimento **(inferido)**. |
| Segmentos (atual) | atual (`00-etapas:L7`) | CNPJ/CPF, SEGMENTO, CD_GRUPO | Enriquecimento por CNPJ/CPF (`01:L7`). |
| Poder Público | não informada | CNPJ/CPF | Usada para ignorar clientes de poder público (`01:L9`). Nome do arquivo não citado no doc 01. |
| Base de UF / regionalidade | não informada (`00-etapas:L18`) | CPF/CNPJ, UF | Cruzamento por **CPF/CNPJ** (`01:L18`), diferente dos demais fluxos, que cruzam por CD_GRUPO. |
| Cadastro de grupo econômico | não informada | CD_GRUPO | Usado no gateway que "basicamente exclui grupo Bradesco" (`01:L14`). Código do grupo não informado. |

### 3. Etapas do fluxo

**Etapa 1 — Base de cobrança tratada** (`01-cobrança-fluxo.md:L3-19`)

1. **Carregar eventos tarifados** — leitura da base de eventos tarifados de cobrança (`01:L5`).
2. **Tratar e normalizar** — ajuste de campos e normalização; sem regra detalhada (`01:L6`).
3. **Enriquecer com segmentos** — junção com a base de segmentos pelo CNPJ/CPF (`01:L7`).
4. **Classificar emissor** — regra não descrita no documento (`01:L8`).
5. **Identificar poder público** — clientes de poder público são ignorados na análise (`01:L9`). Filtro: exclusão.
6. **Classificar produto** — mapeamento dos eventos (DESCR_TARIFA) para as 13 modalidades de cobrança, nas visões "Cliente" e "Banco" (`01:L10`, `01:L35-57`) **(inferido: o doc descreve as modalidades, mas não a regra de mapeamento)**.
7. **Gateway de cobrança segregada de impressão/postagem** — separa (ou exclui) tarifas de impressão/postagem; regra não detalhada (`01:L11`).
8. **Gateway de segmentos** — filtro de segmentos; lista não informada no doc 01 **(inferido: segmentos de atacado, como nos demais fluxos)** (`01:L12`).
9. **Consolidar volume e receita** — agregação de quantidade e receita, granularidade não explicitada **(inferido: por grupo econômico e produto, dado o layout de saída em L19)** (`01:L13`).
10. **Gateway de grupo econômico** — "basicamente exclui grupo Bradesco" (`01:L14`).
11. **Calcular tarifa média** — fórmula não explicitada **(inferido: receita tarifada / quantidade, como nos demais fluxos)** (`01:L15`).
12. **Gerar indicadores L3M** — indicadores dos últimos 3 meses; finalidade não descrita (`01:L16`).
13. **Consolidar indicadores anuais** — histórico LTM com 13 meses (`01:L17`).
14. **Carregar base de UF** — cruzamento com CPF/CNPJ (`01:L18`).
15. **Gerar base tratada** — campos: SEGMENTO, CD_GRUPO, PRODUTO, QTD_MENSAL, QTD_TOTAL, VALOR_TARIFADO (total anual), TARIFA_PRATICADA, mais UF e região comercial (`01:L19`).

**Etapa 2 — Uplift de Cobrança** (`01-cobrança-fluxo.md:L21-33`)

1. **Carregar base tratada** da Etapa 1 (`01:L25`).
2. **Gateway quantidade mensal > 0** — registros com QTD_MENSAL zero são desconsiderados (`01:L26`).
3. **Classificar tier de volume** — por QT_MENSAL, com faixas por produto/modalidade (`01:L27`, `01:L59-79`).
4. **Classificar cluster de precificação** — combina tier, segmento e, em alguns casos, região (`01:L28`, `01:L81-92`).
5. **Calcular percentis de tarifa por cluster** — P35/P40/P50/P60/P90 diretos; P25/P75 com referência corporate ponderada e ajuste de monotonicidade; contagem N de grupos por cluster (`01:L29`, `01:L94-106`).
6. **Determinar preço-alvo e uplift** — PREÇO_ALVO = max(TARIFA, P75); uplift por limiar de tarifa; N < 15 zera uplift (`01:L30`, `01:L108-120`).
7. **Gateway "ainda há modalidades a processar"** — laço sobre as 13 modalidades (`01:L31`).
8. **Consolidar bases de uplift por modalidade** (`01:L32`).
9. **Gerar arquivo de uplift** — `COBRANCA_vats.xlsx` (`01:L33`, `01:L124`).

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Exclusão de poder público | Clientes de poder público ignorados na análise | lista/base de PP | `01:L9` |
| Exclusão de grupo econômico | Exclui "grupo Bradesco" | código não informado | `01:L14` |
| Janela LTM | Indicadores anuais em histórico de 13 meses | 13 referências mensais | `01:L17` |
| Janela L3M | Indicadores dos últimos 3 meses | 3 meses | `01:L16` |
| Gateway de volume | Só processa registros com quantidade mensal > 0 | QTD_MENSAL > 0 | `01:L26` |
| Modalidades em escopo | 13 modalidades (9 nomes de tarifa, algumas em visão Cliente e Banco) | ver tabela L63-77 | `01:L35-57`, `01:L63-77` |
| Tier de volume | Faixas por modalidade sobre QT_MENSAL; Tier 3 = menor, Tier 1 = maior | ex.: NA BAIXA POR COMPENSACAO Cliente: ≤25.500 / ≤150.000 / >150.000; QUANDO DO REGISTRO Cliente: ≤17.000 / ≤100.000 / >100.000; demais linhas em L65-77 | `01:L59-79` |
| Exceção de tier | DEBITO DE COBRANCA C/C (Banco e Cliente) não têm Tier 3; tudo abaixo do limite de Tier 2 é Tier 2 | limites ≤75.000 (Banco) e ≤30.000 (Cliente) | `01:L67`, `01:L71`, `01:L79` |
| Cluster de precificação | 1 = Tier 1; 2 = Tier 2 (só onde a variante considera Tier 2 separado); 3 = ULTRA/GLOBAL CORPORATE no menor tier; 4 = LARGE CORPORATE no menor tier; 10 = AGRO CORPORATE no menor tier; demais = CORPORATE/INSTITUCIONAL no menor tier (texto cortado) | códigos 1, 2, 3, 4, 10, "demais" | `01:L81-92` |
| Percentis diretos | P35, P40, P50, P60, P90 da TARIFA por cluster | percentis 35/40/50/60/90 | `01:L96` |
| Referência corporate (P25/P75) | Média ponderada por QT_MENSAL do percentil entre os clusters "corporate" do produto | quais clusters são "corporate" não está legível (seção cortada) | `01:L97` |
| Monotonicidade (cummin) | Clusters não-corporate ordenados do maior para o menor código recebem mínimo acumulado, partindo da referência corporate | ordem: corporate ≥ 10 ≥ 4 ≥ 3 ≥ 2 ≥ 1 | `01:L98-102` |
| Representatividade N | N = quantidade de CD_GRUPO distintos por cluster | — | `01:L106` |
| Preço-alvo | PREÇO_ALVO = max(TARIFA atual, P75 do cluster); nunca reduz tarifa | percentil 75 | `01:L112`, `01:L133` |
| Uplift (tarifa baixa) | Se TARIFA < 1.000: UPLIFT = (PREÇO_ALVO − TARIFA) × QT_TOTAL | limiar 1.000 | `01:L116` |
| Uplift (tarifa alta) | Se TARIFA ≥ 1.000: UPLIFT = (PREÇO_ALVO / TARIFA − 1) × VLR_TARIFADO | limiar 1.000 | `01:L116` |
| Representatividade mínima | Se N < 15, mantém tarifa atual e zera uplift | N mínimo = 15 | `01:L120` |
| Aderência à metodologia | Fluxo cobre passos 1 e 2 dos 4 passos do business case | — | `01:L126-135` |

### 5. Parâmetros que deveriam ser parametrizáveis

- Lista de modalidades de cobrança em escopo e visão (Cliente/Banco) (`01:L35-57`, `01:L63-77`).
- Mapeamento DESCR_TARIFA → modalidade/produto **(inferido)** (`01:L55`).
- Faixas de tier por modalidade: 13 linhas × 2 limites (`01:L63-77`), inclusive a flag "sem Tier 3" (`01:L79`).
- Regra de cluster: mapeamento (tier, segmento, região) → código (`01:L85-92`).
- Lista de segmentos considerados em cada cluster (ULTRA/GLOBAL, LARGE, AGRO, CORPORATE/INSTITUCIONAL) (`01:L89-92`).
- Conjunto de clusters "corporate" usados como referência de P25/P75 (`01:L97`).
- Ordem de precedência para o cummin (`01:L100`).
- Lista de percentis calculados e o percentil escolhido como preço-alvo (P75) (`01:L96`, `01:L112`).
- Campo de ponderação da média ponderada (QT_MENSAL) (`01:L97`).
- Limiar de tarifa que separa as fórmulas de uplift (1.000) (`01:L116`).
- N mínimo de representatividade (15) (`01:L120`).
- Janelas temporais: LTM (13 meses) e L3M (3 meses) (`01:L16-17`).
- Lista de grupos econômicos excluídos (grupo Bradesco) (`01:L14`).
- Base/lista de poder público (`01:L9`).
- Lista de segmentos do gateway de segmentos (`01:L12`).
- Regra do gateway impressão/postagem (`01:L11`).
- Regra de classificação de emissor (`01:L8`).
- Gateway de volume mínimo (QTD_MENSAL > 0) (`01:L26`).
- Mapeamento UF → região comercial **(inferido; a tabela só aparece nos docs 02 e 03)** (`01:L19`).

### 6. Saídas

- **Base de cobrança tratada** (Etapa 1): SEGMENTO, CD_GRUPO, PRODUTO, QTD_MENSAL, QTD_TOTAL, VALOR_TARIFADO (total anual), TARIFA_PRATICADA, UF, região comercial (`01:L19`).
- **Bases de uplift por modalidade** (13), consolidadas (`01:L32`).
- **`COBRANCA_vats.xlsx`**: por grupo econômico e produto, preço-alvo sugerido (nunca inferior à tarifa atual), uplift estimado, tier, cluster, percentis e N **(inferido pelo padrão dos outros fluxos)** (`01:L124`).

### 7. Conceitos de domínio / glossário

- **Eventos tarifados**: registros de cobrança de tarifa por evento (ex.: registro, baixa) na base de origem; campo DESCR_TARIFA identifica o evento (`01:L5`, `01:L55`).
- **Modalidade (produto de cobrança)**: cada tipo de tarifa de cobrança registrada de boletos, ex.: NA BAIXA POR COMPENSAÇÃO, QUANDO DO REGISTRO (`01:L35-55`).
- **Visão Cliente / visão Banco**: quem é o responsável/lado tarifado da modalidade (`01:L57`).
- **Tier de volume**: faixa de quantidade tarifada mensal (QT_MENSAL) por produto; Tier 3 menor volume, Tier 1 maior; limites definidos empiricamente (`01:L61`).
- **Cluster de precificação**: grupo de clientes comparáveis para definição do preço-alvo, combinando tier, segmento e, em alguns casos, região (`01:L83`).
- **Clusters "corporate"**: clusters usados como referência para P25/P75; representam o patamar de tarifa dos clusters de maior relevância comercial (Corporate/Institucional) (`01:L97`).
- **Percentil de tarifa**: estatística da TARIFA dos registros de um cluster (`01:L96`).
- **Ajuste de monotonicidade (cummin)**: mínimo acumulado que garante percentil não crescente conforme o código de cluster diminui (`01:L98-102`).
- **N (representatividade)**: número de grupos econômicos distintos no cluster (`01:L106`).
- **Preço-alvo**: max(tarifa atual, P75 do cluster) (`01:L112`).
- **Uplift**: ganho anual estimado de receita ao levar a tarifa ao preço-alvo (`01:L114-116`).
- **Tarifa praticada (TARIFA_PRATICADA)**: tarifa média efetivamente cobrada do cliente no período (`01:L15`, `01:L19`).
- **LTM / L3M**: últimos 13 meses / últimos 3 meses (`01:L16-17`).
- **Onda 3 do Pricing Cash**: ciclo de reprecificação que consome o arquivo de uplift (`01:L124`).
- **Grupo econômico (CD_GRUPO)**: unidade de consolidação do cliente (`01:L19`).

### 8. Evidências de capacidades

| Cap. | Fonte | Resumo |
|---|---|---|
| C1 | `01:L108-116` | Regra de preço-alvo (max com P75) e duas fórmulas de uplift: núcleo do cálculo de preço sugerido. |
| C1 | `01:L133` | "PREÇO_ALVO = P75 do cluster (se maior que a tarifa atual)" como proposta de tarifa alvo por cluster. |
| C1 | `01:L19` | TARIFA_PRATICADA como preço praticado por grupo/produto, base de comparação. |
| C1 | `01:L112` | Modelo nunca sugere redução: piso do preço sugerido é a tarifa atual. |
| C2 | `01:L124` | Arquivo de uplift "serve de insumo para a decisão de repreficação de cobrança da Onda 3". |
| C2 | `01:L120` | Clusters pouco representativos ficam fora da reprecificação (elegibilidade). |
| C2 | `01:L26` | Gateway QTD_MENSAL > 0 filtra quem entra no cálculo. |
| C3 | `01:L61` | Tier por volume mensal realizado é a base de comparação (volumetria realizada) **(inferido como insumo de reciprocidade)**. |
| C3 | `01:L16-17` | Indicadores L3M e LTM permitem acompanhar evolução de volume **(inferido)**. |
| PAR | `01:L61`, `01:L63-79` | Limites de tier "definidos empiricamente por produto": tabela candidata a parametrização. |
| PAR | `01:L85-92` | Tabela de códigos de cluster. |
| PAR | `01:L96-100` | Lista de percentis e ordem de precedência. |
| PAR | `01:L116`, `01:L120` | Thresholds 1.000 e N < 15. |
| LEG | `01:L5`, `01:L55` | Eventos tarifados vêm da base de origem com nomenclatura do sistema bancário. |
| LEG | `01:L7`, `01:L18` | Dependência de bases de segmentos e UF. |
| LEG | `01:L17` | Histórico LTM de 13 meses depende de base histórica. |

### 9. Dúvidas, ambiguidades e lacunas

- **Texto cortado na regra de cluster** (`01:L92`): a linha "(demais)" está incompleta; não se sabe se os clusters regionais 5-9 (SP, SE ex-SP, S, CO, demais) existem em cobrança como nos docs 02 e 03. A menção a "região" em `01:L23` e `01:L83` sugere que sim **(inferido)**.
- **Quais clusters são "corporate"** para a referência de P25/P75 (`01:L97` remete a "seção anterior", que está cortada).
- **Texto cortado sobre uso de N** (`01:L106`).
- **Página 10 não transcrita** (`01:L135`): passos 3 e 4 da metodologia.
- **Etapas sem regra descrita**: classificar emissor (`01:L8`), classificar produto (`01:L10`), gateway impressão/postagem (`01:L11`), gateway de segmentos (`01:L12`), tarifa média (`01:L15`), indicadores L3M e sua finalidade (`01:L16`).
- **Grupo Bradesco**: código não informado (`01:L14`); nos demais fluxos exclui-se o grupo 616 sem motivo declarado. Não é possível afirmar que sejam o mesmo grupo.
- **Variante com/sem Tier 2 separado** (`01:L88`): não há lista de quais modalidades tratam o Tier 2 como cluster próprio.
- **INSTITUCIONAL** aparece nos "demais" clusters (`01:L92`), mas nos outros fluxos não é segmento de atacado.
- **Ausência de mapeamento UF → região** no doc 01, embora a saída tenha "região comercial" (`01:L19`).
- **Regra de tier usa QT_MENSAL** (`01:L61`), enquanto a saída da Etapa 1 nomeia o campo QTD_MENSAL (`01:L19`): nomenclatura inconsistente.
- Nomes de arquivos físicos das bases de entrada não citados.
- Semântica de "TR CONS SDO DEBAUT" a confirmar com Produtos (`01:L55`).

---

## Multipag (fonte: `02-multipag-fluxo.md`)

### 1. Objetivo do fluxo

Preparar a base de pagamentos a fornecedores via TED do Multipag e calcular o potencial de uplift de tarifa para clientes corporativos da Onda 3 do Pricing Cash. O processo consolida volume e receita por grupo econômico, exclui Poder Público e o grupo econômico 616, enriquece com localidade, classifica por tier e cluster, e usa percentis de tarifa por cluster para definir preço-alvo e uplift (`02-multipag-fluxo.md:L3-5`). Código de referência: `03_Multipag.ipynb` (`02:L9`).

### 2. Bases de entrada

| Base | Janela temporal | Campos-chave usados | Observações |
|---|---|---|---|
| `segmentos_atualizados.csv` | atual | CNPJCPF, SEGMENTO, CD_GRUPO | Remove duplicidades pela combinação dos três campos (`02:L15`). |
| `multipag_atualizado.csv` | LTM 01/05/2025 a 01/05/2026, 13 referências (`02:L17`) | REF, MES, CNPJCPF, CONTRATO, VALOR, QTDE | REF convertida em data e MES YYYY-MM (`02:L16`). |
| `contratos_multipag.csv` | vigência (dinic_vgcia) | nseq_contr_negoc (→CONTRATO), vtarif (→TARIFA), rservc, rmodld, dinic_vgcia | Separador `;`, latin-1 (`02:L18`). Tarifa vem do **contrato**, não da receita observada. |
| `poder_publico.csv` | não informada | CNPJCPF | Indicador PP = 1 (`02:L22`). |
| `rob_uf.csv` | não informada | CD_GRUPO, UF | UF por **grupo econômico**; nome sugere origem na base de ROB **(inferido)** (`02:L27`; `00-etapas:L17-18`). |

### 3. Etapas do fluxo

(`02-multipag-fluxo.md:L13-34`)

1. **Carregar segmentação** — CNPJCPF, SEGMENTO, CD_GRUPO; dedup; define os 5 segmentos de atacado (CORPORATE, LARGE, ULTRA, GLOBAL, AGRO CORPORATE) (`02:L15`).
2. **Carregar movimentações Multipag** — REF → data; MES YYYY-MM (`02:L16`).
3. **Recorte LTM e consolidação por contrato** — mantém REF na lista LTM (13 refs); soma VALOR e QTDE por MES, CNPJCPF e CONTRATO → volume_ted (`02:L17`).
4. **Carregar contratos Multipag** (`02:L18`).
5. **Selecionar tarifa vigente por contrato** — o código filtra rservc = PAGAMENTO VIA TED e rmodld = FORNECEDORES, mas o filtro é sobrescrito pela base completa ordenada por dinic_vgcia decrescente; mantém a primeira ocorrência (mais recente) de cada contrato; renomeia para CONTRATO e TARIFA; cruza por CONTRATO (`02:L19`).
6. **Associar segmento e grupo** — junção por CNPJCPF (`02:L20`).
7. **Selecionar atacado e calcular receita** — mantém os 5 segmentos; RECEITA = TARIFA × QTDE (`02:L21`).
8. **Carregar Poder Público** — PP = 1, dedup (`02:L22`).
9. **Associar PP e gerar base intermediária** — junção por CNPJCPF; grava `df_int.csv` antes de preencher; PP nulo → 0 (`02:L23`).
- **G1 Poder Público?** — PP = 1 exclui (`02:L24`).
- **G2 Grupo 616?** — exclui; motivo não indicado no código (`02:L25`).
10. **Consolidar por grupo** — soma QTDE e RECEITA por MES, SEGMENTO, CD_GRUPO; TARIFA = RECEITA / QTDE; por SEGMENTO e CD_GRUPO: QTDE = média mensal, RECEITA e QTDE_TOTAL = somas; TARIFA = última com QTDE > 0 na ordem corrente da base (sem ordenação explícita por mês) (`02:L26`).
11. **Carregar UF por grupo** — `rob_uf.csv`; CD_GRUPO formatado (`02:L27`).
12. **Associar UF e região** — junção por CD_GRUPO; mapeia UF → REGIAO (`02:L28`, `02:L38-46`).
- **G3 Grupo 616? (repetido)** — mesma exclusão, agora com CD_GRUPO em texto (`02:L29`).
13. **Classificar tier** — por QTDE média mensal: Tier 3 ≤ 4.000; Tier 2 > 4.000 e ≤ 50.000; Tier 1 > 50.000 (`02:L30`).
14. **Classificar cluster** — Tier 1 → 1; Tier 2 → 2; Tier 3: ULTRA/GLOBAL → 3, LARGE → 4, AGRO → 10, demais por região: SP → 5, SE ex-SP → 6, S → 7, CO → 8, demais → 9 (`02:L31`).
15. **Percentis por cluster** — P35/P40/P50/P60/P90; P25/P75 com referência ponderada por QTDE dos clusters corporate [5, 6, 7, 8, 9] e cummin nos demais; N por cluster (`02:L32`, `02:L48-50`).
16. **Preço-alvo e uplift** — PRECO_ALVO = max(P75, TARIFA); TARIFA < 1.000: (PRECO_ALVO − TARIFA) × QTDE_TOTAL; senão (PRECO_ALVO / TARIFA − 1) × RECEITA; N < 15 reverte e zera (`02:L33`, `02:L52`).
17. **Gerar `MULTIPAG_vats.xlsx`** — exporta; somas de RECEITA e UPLIFT exibidas, não exportadas (`02:L34`).

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Segmentos de atacado | Filtro de público | CORPORATE, LARGE CORPORATE, ULTRA CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE | `02:L15`, `02:L21` |
| Janela LTM | Referências mantidas | 01/05/2025 a 01/05/2026, 13 refs | `02:L17` |
| Tarifa vigente | Contrato mais recente por nseq_contr_negoc (ordem dinic_vgcia desc) | filtro serviço/modalidade previsto mas sobrescrito | `02:L19` |
| Receita | RECEITA = TARIFA × QTDE | — | `02:L21` |
| Exclusão PP | PP = 1 desconsiderado | base poder_publico | `02:L22-24` |
| Exclusão grupo 616 | CD_GRUPO = 616 desconsiderado (2 vezes) | 616 | `02:L25`, `02:L29` |
| Consolidação anual | QTDE média mensal; RECEITA e QTDE_TOTAL somas; TARIFA última com QTDE > 0 | — | `02:L26` |
| UF → região | Tabela de-para | S; CO; SP; SE ex-SP; NNE | `02:L40-46` |
| Tier | Sobre QTDE média mensal | ≤4.000 / ≤50.000 / >50.000 | `02:L30` |
| Cluster | Tier × segmento × região | 1, 2, 3, 4, 10, 5, 6, 7, 8, 9 | `02:L31` |
| Clusters corporate | Referência ponderada para P25/P75 | [5, 6, 7, 8, 9]; peso QTDE; cluster temporário 9999 | `02:L32`, `02:L50` |
| Percentis | P25, P35, P40, P50, P60, P75, P90; só P75 e N entram no cálculo | — | `02:L32`, `02:L54` |
| Preço-alvo | max(P75, TARIFA); nunca reduz | P75 | `02:L33`, `02:L52` |
| Uplift | Limiar de tarifa separa fórmulas | 1.000 | `02:L33`, `02:L52` |
| Representatividade | N < 15 → sem reajuste | 15 | `02:L33`, `02:L52` |
| Aderência à metodologia | Cobre passos 1 e 2; passo 3 "Não" | — | `02:L60-68` |

### 5. Parâmetros que deveriam ser parametrizáveis

- Lista de segmentos de atacado (`02:L15`).
- Datas de início/fim e número de referências da janela LTM (`02:L17`).
- Filtros de serviço e modalidade de contrato (PAGAMENTO VIA TED, FORNECEDORES) e critério de vigência (`02:L19`).
- Lista de grupos econômicos excluídos (616) (`02:L25`).
- Base de Poder Público (`02:L22`).
- Regra de tarifa de referência (última com QTDE > 0; critério de ordenação) (`02:L26`).
- Tabela UF → região comercial (`02:L40-46`).
- Limites de tier (4.000 e 50.000) e base de volume (média mensal) (`02:L30`).
- Regra de cluster: códigos por tier/segmento/região (`02:L31`).
- Conjunto de clusters corporate [5, 6, 7, 8, 9] e campo de peso (QTDE) (`02:L50`).
- Lista de percentis e percentil de preço-alvo (P75) (`02:L32`, `02:L54`).
- Limiar 1.000 da fórmula de uplift (`02:L52`).
- N mínimo 15 (`02:L52`).
- Código do cluster auxiliar (9999) — parâmetro técnico (`02:L50`).

### 6. Saídas

- **`df_int.csv`**: base intermediária de atacado com indicador PP antes do preenchimento (`02:L23`).
- **`MULTIPAG_vats.xlsx`**: por segmento e grupo econômico: QTDE (média mensal), QTDE_TOTAL, RECEITA, TARIFA, MES, UF, REGIAO, TIER, CLUSTER, P25-P90, N, PRECO_ALVO, UPLIFT (`02:L34`, `02:L58`).
- Somas de RECEITA e UPLIFT exibidas no notebook, não exportadas (`02:L34`).

### 7. Conceitos de domínio / glossário

- **Multipag / pagamentos a fornecedores via TED**: produto de contas a pagar cujo serviço é "PAGAMENTO VIA TED" na modalidade "FORNECEDORES" (`02:L5`, `02:L19`).
- **Contrato (nseq_contr_negoc)**: unidade contratual com tarifa (vtarif) e vigência (dinic_vgcia) (`02:L19`).
- **Tarifa vigente**: tarifa do contrato mais recente (`02:L19`); é o "preço praticado" deste fluxo **(inferido)**.
- **Receita calculada**: TARIFA × QTDE, não receita observada (`02:L21`).
- **PP (Poder Público)**: indicador binário de exclusão (`02:L22-24`).
- **Grupo 616**: grupo econômico excluído sem motivo declarado (`02:L25`).
- **Região comercial**: S, CO, SP, SE ex-SP, NNE (`02:L40-46`).
- **Tier, cluster, clusters corporate, cummin, N, preço-alvo, uplift**: mesmas definições do fluxo de Cobrança (`02:L30-33`, `02:L50-52`).
- **Cluster 9999**: cluster temporário que carrega a referência corporate ponderada (`02:L50`).
- **vats**: sufixo dos arquivos de saída; significado não explicado nos documentos.

### 8. Evidências de capacidades

| Cap. | Fonte | Resumo |
|---|---|---|
| C1 | `02:L33`, `02:L52` | Cálculo de PRECO_ALVO e UPLIFT por grupo econômico. |
| C1 | `02:L19` | Tarifa vigente por contrato como preço praticado de referência. |
| C1 | `02:L54` | Percentis alternativos (P25-P60) calculados e mantidos, mas não usados: potenciais cenários **(inferido)**. |
| C2 | `02:L5`, `02:L58` | Base final é insumo para reprecificação da Onda 3. |
| C2 | `02:L24-25`, `02:L52` | Elegibilidade: exclui PP, grupo 616 e clusters com N < 15. |
| C3 | `02:L26`, `02:L30` | Volume médio mensal e total por grupo como base de tier; volumetria realizada **(inferido)**. |
| C3 | `02:L19` | Contrato com tarifa e vigência: ponto de ligação com acordo comercial **(inferido)**. |
| PAR | `02:L15`, `02:L17`, `02:L30-31`, `02:L40-46`, `02:L50-52` | Listas, datas, faixas, de-para e thresholds embutidos no notebook. |
| LEG | `02:L15-18`, `02:L22`, `02:L27` | Cinco CSVs extraídos de sistemas legados, com codificação e separadores específicos. |
| LEG | `02:L19` | Depende da base de contratos e sua vigência. |

### 9. Dúvidas, ambiguidades e lacunas

- **Filtro de serviço/modalidade sobrescrito** (`02:L19`): a intenção de negócio era restringir a PAGAMENTO VIA TED / FORNECEDORES? O comportamento efetivo usa todos os contratos.
- **Tarifa de referência sem ordenação por mês** (`02:L26`): "última com QTDE > 0" depende da ordem corrente da base; resultado potencialmente não determinístico.
- **Grupo 616**: motivo e origem da exclusão não documentados (`02:L25`); gateway duplicado (`02:L29`).
- **Receita calculada vs. observada**: RECEITA = TARIFA × QTDE (`02:L21`) assume que a tarifa de contrato foi efetivamente cobrada.
- **Limites de tier** (4.000 / 50.000) sem racional documentado (`02:L30`).
- **Passo 3 da metodologia** truncado (`02:L68`).
- **INSTITUCIONAL** não está na lista de atacado, embora apareça no fluxo de Cobrança.
- **`df_int.csv`**: finalidade do arquivo intermediário não descrita (`02:L23`).
- **Base `rob_uf.csv`**: origem (ROB?) e atualização não descritas (`02:L27`).

---

## PIX (fonte: `03-pix-fluxo.md`)

### 1. Objetivo do fluxo

Preparar a base de PIX Pagamentos e calcular o potencial de uplift de tarifa para clientes corporativos da Onda 3 do Pricing Cash. O processo recorta o período LTM, enriquece com segmentação e localidade, exclui Poder Público e o grupo 616, restringe o escopo às tarifas de PIX Pagamentos, consolida volume e receita por grupo econômico e usa percentis de tarifa por cluster para definir preço-alvo e uplift (`03-pix-fluxo.md:L3-5`). Código de referência: `04_Pix.ipynb` (`03:L9`).

### 2. Bases de entrada

| Base | Janela temporal | Campos-chave usados | Observações |
|---|---|---|---|
| `pix.csv` | LTM 01/05/2025 a 01/05/2026, 13 refs (`03:L16`) | CNPJCPF, REF, CD_TARF, QTDE, RCTA | Separador `,`, latin-1; bloco comentado de conversão de RCTA/TARF_MEDIA não executa (`03:L15`). |
| `segmentos_atualizados.csv` | atual | CNPJCPF, SEGMENTO, CD_GRUPO | Separador `;`; dedup (`03:L17`). |
| `poder_publico.csv` | não informada | CNPJCPF | PP = 1 (`03:L20`). |
| `rob_uf.csv` | não informada | CD_GRUPO, UF | UF por grupo (`03:L27`). |

### 3. Etapas do fluxo

(`03-pix-fluxo.md:L13-34`)

1. **Carregar base PIX** (`03:L15`).
2. **Recorte LTM** — mantém REF na lista LTM; CNPJCPF → texto (`03:L16`).
3. **Carregar segmentação** (`03:L17`).
4. **Associar segmento e grupo** — junção por CNPJCPF (`03:L18`).
- **G1 Segmento de atacado?** — mantém os 5 segmentos de atacado (`03:L19`).
5. **Carregar Poder Público** (`03:L20`).
6. **Associar PP** — PP nulo → 0 (`03:L21`).
- **G2 Poder Público?** — exclui PP = 1 (`03:L22`).
- **G3 Grupo 616?** — exclui (`03:L23`).
- **G4 Tarifa é de PIX Pagamentos?** — mantém CD_TARF em {5518, 5517, 5534, 5563} (`03:L24`).
- **G5 Receita negativa?** — mantém RCTA ≥ 0 (`03:L25`).
7. **Consolidar por grupo** — soma QTDE e RCTA por REF, SEGMENTO, CD_GRUPO; TARIFA = RCTA / QTDE (0 se QTDE = 0); ordena por MES; por SEGMENTO e CD_GRUPO: QTDE média mensal, RCTA e QTDE_TOTAL somas; TARIFA = última média mensal com QTDE > 0 em ordem cronológica (`03:L26`).
8. **Carregar UF por grupo** (`03:L27`).
9. **Associar UF e região** (`03:L28`, `03:L38-46`).
10. **Gerar `uf_por_grupo.xlsx`** — exporta CD_GRUPO, UF, REGIAO da base de UF (`03:L29`).
11. **Classificar tier** — QTDE média mensal: Tier 3 ≤ 100; Tier 2 > 100 e ≤ 500; Tier 1 > 500 (`03:L30`, `03:L48-56`).
12. **Classificar cluster** — mesma regra do Multipag (`03:L31`).
13. **Percentis por cluster** — idem Multipag; corporate [5, 6, 7, 8, 9] (`03:L32`, `03:L58-60`).
14. **Preço-alvo e uplift** — idem, com RCTA no lugar de RECEITA (`03:L33`, `03:L62`).
15. **Gerar `PIX_vats.xlsx`** (`03:L34`).

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Janela LTM | REF mantidas | 01/05/2025 a 01/05/2026, 13 refs | `03:L16` |
| Segmentos de atacado | Gateway G1 | CORPORATE, LARGE, ULTRA, GLOBAL, AGRO CORPORATE | `03:L19` |
| Exclusão PP | G2 | PP = 1 | `03:L20-22` |
| Exclusão grupo 616 | G3 | 616 | `03:L23` |
| Escopo de tarifa PIX Pagamentos | G4 | CD_TARF ∈ {5518, 5517, 5534, 5563} | `03:L24` |
| Receita negativa | G5 | RCTA ≥ 0 | `03:L25` |
| Tarifa média mensal | TARIFA = RCTA / QTDE; 0 se QTDE = 0 | — | `03:L26` |
| Consolidação anual | QTDE média; RCTA e QTDE_TOTAL somas; TARIFA última com QTDE > 0 (ordem cronológica) | — | `03:L26` |
| UF → região | Tabela de-para | S; CO; SP; SE ex-SP; NNE | `03:L40-46` |
| Tier | QTDE média mensal | ≤100 / ≤500 / >500 | `03:L30`, `03:L52-56` |
| Cluster | Tier × segmento × região | 1, 2, 3, 4, 10, 5-9 | `03:L31` |
| Clusters corporate | Referência ponderada P25/P75 | [5, 6, 7, 8, 9]; peso QTDE; cluster 9999 | `03:L32`, `03:L60` |
| Preço-alvo | max(P75, TARIFA) | P75 | `03:L33`, `03:L62` |
| Uplift | Limiar 1.000; base QTDE_TOTAL ou RCTA | 1.000 | `03:L33`, `03:L62` |
| Representatividade | N < 15 → sem reajuste | 15 | `03:L33`, `03:L62` |
| Metodologia | Passos 1-2 sim; 3 (saldo médio Invest Fácil) e 4 (matriz Stickiness × Impacto) não | — | `03:L70-81` |

### 5. Parâmetros que deveriam ser parametrizáveis

- Datas e número de referências da janela LTM (`03:L16`).
- Lista de segmentos de atacado (`03:L19`).
- Base de Poder Público (`03:L20`).
- Lista de grupos excluídos (616) (`03:L23`).
- Lista de códigos de tarifa (CD_TARF) que definem "PIX Pagamentos" (`03:L24`).
- Regra de tratamento de receita negativa (`03:L25`).
- Regra de tarifa de referência (última com QTDE > 0) (`03:L26`).
- Tabela UF → região (`03:L40-46`).
- Limites de tier (100, 500) e base de volume (`03:L52-56`).
- Regra de cluster (`03:L31`).
- Clusters corporate [5, 6, 7, 8, 9], peso, cluster auxiliar 9999 (`03:L60`).
- Lista de percentis e percentil de preço-alvo (`03:L32`, `03:L64`).
- Limiar 1.000 e N mínimo 15 (`03:L62`).

### 6. Saídas

- **`PIX_vats.xlsx`**: por segmento e grupo econômico: QTDE média mensal, QTDE_TOTAL, RCTA, TARIFA, REF, UF, REGIAO, TIER, CLUSTER, P25-P90, N, PREÇO_ALVO, UPLIFT (`03:L34`, `03:L68`).
- **`uf_por_grupo.xlsx`**: CD_GRUPO, UF, REGIAO (`03:L29`, `03:L68`).

### 7. Conceitos de domínio / glossário

- **PIX Pagamentos**: subconjunto de tarifas PIX identificado pelos códigos CD_TARF 5518, 5517, 5534, 5563 (`03:L24`).
- **CD_TARF**: código de tarifa na base de origem (`03:L15`).
- **RCTA**: receita tarifada observada (`03:L15`).
- **Tarifa média mensal**: RCTA / QTDE por grupo e mês; é o preço praticado efetivo (`03:L26`).
- **Receita negativa**: registros com RCTA < 0, excluídos (estornos, **inferido**) (`03:L25`).
- **Saldo médio de Invest Fácil**: indicador de nível de relacionamento do cliente com o banco; passo 3 da metodologia, não coberto (`03:L78`).
- **Stickiness (probabilidade de retenção) × Impacto para Bradesco**: matriz do passo 4 da metodologia, usada para planejar reajustes graduais; calculada em outro fluxo ("Matriz de Stickiness x Impacto"), não coberto aqui (`03:L78-79`).
- **Comunicar e implementar novos preços**: etapa manual/comercial posterior, fora do escopo (`03:L81`).
- **Tier, cluster, corporate, cummin, N, preço-alvo, uplift, região, grupo 616, PP**: mesmas definições do Multipag (`03:L30-33`, `03:L60-62`).

### 8. Evidências de capacidades

| Cap. | Fonte | Resumo |
|---|---|---|
| C1 | `03:L33`, `03:L62` | Cálculo de PREÇO_ALVO e UPLIFT por grupo. |
| C1 | `03:L26` | Tarifa praticada efetiva derivada de RCTA / QTDE. |
| C1 | `03:L78` | Preço-alvo bruto "sem abatimento por saldo de IF": indica que o preço final pode ter desconto por relacionamento **(inferido)**. |
| C2 | `03:L5`, `03:L68` | Insumo para reprecificação de PIX Pagamentos na Onda 3. |
| C2 | `03:L79` | Passo 4 prevê "reajustes graduais" via matriz retenção × impacto: reprecificação por ondas/priorização. |
| C2 | `03:L81` | Comunicação e implementação de novos preços como etapa posterior. |
| C2 | `03:L22-25`, `03:L62` | Elegibilidade: PP, 616, escopo de tarifa, receita negativa, N < 15. |
| C3 | `03:L26`, `03:L30` | Volume médio mensal realizado por grupo como base de tier **(inferido)**. |
| C3 | `03:L78` | Saldo médio de Invest Fácil como medida de relacionamento: contrapartida de reciprocidade **(inferido)**. |
| PAR | `03:L16`, `03:L19`, `03:L24`, `03:L52-56`, `03:L60-62` | Janela, listas, códigos, faixas e thresholds embutidos. |
| LEG | `03:L15`, `03:L17`, `03:L20`, `03:L27` | Quatro CSVs legados com encodings e separadores próprios. |
| LEG | `03:L15` | Código morto (bloco comentado) indica variações de layout da base de origem. |

### 9. Dúvidas, ambiguidades e lacunas

- **Significado de cada CD_TARF** (5518, 5517, 5534, 5563) não descrito (`03:L24`).
- **Origem da receita negativa** (estorno? ajuste?) e se deveria ser líquida em vez de excluída (`03:L25`).
- **Limites de tier** muito baixos (100 / 500) comparados aos demais produtos; racional não documentado (`03:L52-56`).
- **Grupo 616** sem motivo (`03:L23`).
- **`uf_por_grupo.xlsx`**: consumidor do arquivo auxiliar não informado (`03:L29`).
- **Passos 3 e 4** dependem de outro fluxo (Matriz de Stickiness × Impacto) não incluído no conjunto analisado (`03:L78-81`).
- Bloco comentado de TARF_MEDIA sugere que a base traz tarifa média pronta; não se sabe por que não é usada (`03:L15`).

---

## Arrecadação (fonte: `04-arrecadação-fluxo.md`)

### 1. Objetivo do fluxo

Preparar a base de Arrecadação (Multipag) e calcular o potencial de uplift de tarifa para clientes corporativos da Onda 3 do Pricing Cash. O processo enriquece com segmentação e grupo econômico, exclui Poder Público, recorta período LTM e público de atacado, remove o grupo 616, classifica os canais (mídia) em produtos, consolida volume e receita por grupo e usa percentis por cluster para definir preço-alvo e uplift, gerando a base completa e um recorte de documentos "DIVERSOS" (`04-arrecadação-fluxo.md:L3-5`). Código de referência: `05_Arrecadacao.ipynb` (`04:L9`).

### 2. Bases de entrada

| Base | Janela temporal | Campos-chave usados | Observações |
|---|---|---|---|
| `arrecadacao.csv` | LTM 01/05/2025 a 01/05/2026, 13 refs (`04:L23`) | CNPJCPF, AGENCIA, REF, MÍDIA, Tipo_Documento, QTDE_ARRECADADO, RECEITA (VLR_ARRECADADO e FLOATING convertidos, não usados) | Separador `;`; remove SEGMENTO, NM_GRUPO, GERCTA, GERCASH da origem (`04:L15-16`). |
| `segmentos_atualizados.csv` | atual | CNPJCPF, SEGMENTO, CD_GRUPO | Dedup (`04:L17`). |
| `poder_publico.csv` | não informada | CNPJCPF | PP = 1 (`04:L19`). |
| (não há base de UF/região) | — | — | O cluster de arrecadação não usa região (`04:L52-61`). |

### 3. Etapas do fluxo

(`04-arrecadação-fluxo.md:L13-35`)

1. **Carregar base de arrecadação** (`04:L15`).
2. **Tratar tipos** — CNPJCPF e AGENCIA em texto; VLR_ARRECADADO, RECEITA, FLOATING em float com troca de separadores (`04:L16`).
3. **Carregar segmentação** (`04:L17`).
4. **Associar segmento e grupo** — junção por CNPJCPF (`04:L18`).
5. **Carregar Poder Público** (`04:L19`).
6. **Associar PP** — nulo → 0 (`04:L20`).
- **G1 Poder Público?** — exclui PP = 1 (`04:L21`).
7. **Classificar produto pela mídia** — MOBILE BANKING, NET EMPRESA, INTERNET BANKING → CANAIS DIGITAIS; demais mídias mantêm o nome (ex.: DÉBITO AUTOMÁTICO) (`04:L22`).
- **G2 Referência no LTM?** — mantém REF na lista LTM (`04:L23`).
- **G3 Segmento de atacado?** — ULTRA, CORPORATE, LARGE, GLOBAL, AGRO CORPORATE (`04:L24`).
8. **Consolidar por mês** — soma QTDE_ARRECADADO e RECEITA por REF, SEGMENTO, CD_GRUPO, PRODUTO, Tipo_Documento; TARIFA = RECEITA / QTDE_ARRECADADO (0 se QTDE = 0); ordena por MES (`04:L25`).
9. **Consolidar anual por grupo** — agrupa por SEGMENTO, CD_GRUPO, PRODUTO, Tipo_Documento; soma QTDE_ARRECADADO e RECEITA (totais anuais); TARIFA da última referência (ordem cronológica); última REF (`04:L26`).
- **G4 Grupo 616?** — exclui (`04:L27`).
10. **Selecionar produto do escopo** — laço sobre CANAIS DIGITAIS e DÉBITO AUTOMÁTICO (`04:L28`).
11. **Classificar tier** — por QTDE_ARRECADADO, faixas por produto (`04:L29`, `04:L41-48`). Como a base já está consolidada anualmente na etapa 9, o volume usado é o **total anual** **(inferido)**, diferente da média mensal dos fluxos 02 e 03.
12. **Classificar cluster** — tier × segmento, sem região (`04:L30`, `04:L50-63`).
13. **Percentis, preço-alvo e uplift** — função `regra_de_negocio(df_sp, cluster_corp)` com cluster_corp = [5] (`04:L31`, `04:L65-82`).
- **G5 Ainda há produtos?** — repete 10-13 para os 2 produtos (`04:L32`).
14. **Consolidar bases de uplift por produto** — concatenação (`04:L33`).
15. **Gerar `ARRECADACAO_COMPLETA_vats.xlsx`** (`04:L34`).
16. **Filtrar Tipo_Documento = DIVERSOS e gerar `ARRECADACAO_vats.xlsx`** (`04:L35`).

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Tratamento de tipos | Conversão de identificadores e valores monetários | formato `.0f`; remove `.` de milhar; `,` → `.` | `04:L16` |
| Exclusão PP | G1 | PP = 1 | `04:L19-21` |
| Produto pela mídia | De-para mídia → produto | MOBILE BANKING, NET EMPRESA, INTERNET BANKING → CANAIS DIGITAIS; demais mantêm nome | `04:L22` |
| Janela LTM | G2 | 01/05/2025 a 01/05/2026, 13 refs | `04:L23` |
| Segmentos de atacado | G3 | ULTRA, CORPORATE, LARGE, GLOBAL, AGRO CORPORATE | `04:L24` |
| Tarifa mensal | RECEITA / QTDE_ARRECADADO; 0 se QTDE = 0 | — | `04:L25` |
| Consolidação anual | Totais anuais; TARIFA da última referência | granularidade: segmento, grupo, produto, tipo de documento | `04:L26` |
| Exclusão grupo 616 | G4 | 616 | `04:L27` |
| Produtos em escopo | Laço por produto | CANAIS DIGITAIS, DÉBITO AUTOMÁTICO | `04:L28` |
| Tier CANAIS DIGITAIS | Sobre QTDE_ARRECADADO | ≤200.000 / >200.000 e ≤5.000.000 / >5.000.000 | `04:L47` |
| Tier DÉBITO AUTOMÁTICO | Sobre QTDE_ARRECADADO | ≤70.000 / >70.000 e ≤750.000 / >750.000 | `04:L48` |
| Cluster | Tier 1 → 1; Tier 2 → 2; Tier 3: LARGE ou INSTITUCIONAL → 3; CORPORATE → 4; AGRO → 10; demais → 5 | 1, 2, 3, 4, 10, 5 | `04:L54-61` |
| Nota INSTITUCIONAL | Tratado no cluster, mas não passa por G3 | — | `04:L63` |
| Clusters corporate | Referência ponderada por QTDE_ARRECADADO | [5]; cluster 9999 | `04:L67`, `04:L72-73` |
| Percentis | P25, P35, P40, P50, P60, P75, P90; cummin em P25/P75 | — | `04:L71-73` |
| N | CD_GRUPO distintos por cluster | — | `04:L74` |
| Preço-alvo | max(P75, TARIFA) | P75 | `04:L78` |
| Uplift | TARIFA < 1.000: (PA − TARIFA) × QTDE_ARRECADADO; senão (PA / TARIFA − 1) × RECEITA | 1.000 | `04:L79` |
| Representatividade | N < 15 → reverte e zera | 15 | `04:L80` |
| Recorte de saída | ARRECADACAO_vats só com Tipo_Documento = DIVERSOS | DIVERSOS | `04:L35` |

### 5. Parâmetros que deveriam ser parametrizáveis

- Regras de conversão de tipos/formatos da base de origem (`04:L16`).
- Base de Poder Público (`04:L19`).
- De-para mídia → produto (lista de mídias digitais) (`04:L22`).
- Datas e número de referências LTM (`04:L23`).
- Lista de segmentos de atacado (`04:L24`).
- Critério de tarifa de referência (última referência) (`04:L26`).
- Lista de grupos excluídos (616) (`04:L27`).
- Lista de produtos em escopo (`04:L28`).
- Faixas de tier por produto (2 produtos × 2 limites) e base de volume (total anual) (`04:L45-48`).
- Regra de cluster tier × segmento (`04:L54-61`), inclusive lista de segmentos por código.
- Clusters corporate [5], peso (QTDE_ARRECADADO), cluster auxiliar 9999 (`04:L67`, `04:L72-73`).
- Lista de percentis e percentil de preço-alvo (`04:L71`, `04:L78`).
- Limiar 1.000 e N mínimo 15 (`04:L79-80`).
- Tipo_Documento do recorte de saída (DIVERSOS) (`04:L35`).

### 6. Saídas

- **`ARRECADACAO_COMPLETA_vats.xlsx`**: por segmento, grupo, produto e tipo de documento: QTDE_ARRECADADO total, RECEITA total, TARIFA, REF, TIER, CLUSTER, percentis, N, PREÇO_ALVO, UPLIFT (`04:L34`, `04:L86`).
- **`ARRECADACAO_vats.xlsx`**: mesmo layout, restrito a Tipo_Documento = DIVERSOS (`04:L35`, `04:L86`).

### 7. Conceitos de domínio / glossário

- **Arrecadação (Multipag)**: produto de recebimento de contas/documentos por canal (mídia) (`04:L5`).
- **Mídia / canal de arrecadação**: origem da arrecadação (MOBILE BANKING, NET EMPRESA, INTERNET BANKING, DÉBITO AUTOMÁTICO etc.) (`04:L22`).
- **Produto (CANAIS DIGITAIS, DÉBITO AUTOMÁTICO)**: agrupamento de mídias para precificação (`04:L22`, `04:L28`).
- **Tipo_Documento / DIVERSOS**: tipo do documento arrecadado; DIVERSOS é o recorte principal de saída (`04:L15`, `04:L35`).
- **FLOATING**: campo da base de origem, convertido mas não usado; significado não descrito (`04:L16`).
- **QTDE_ARRECADADO / VLR_ARRECADADO**: quantidade e valor arrecadados (`04:L15`).
- **regra_de_negocio(df, cluster_corp)**: função que encapsula percentis, N, preço-alvo e uplift (`04:L67`).
- **Tier, cluster, corporate, cummin, N, preço-alvo, uplift, PP, grupo 616**: mesmas definições dos fluxos anteriores, com cluster sem dimensão regional (`04:L41-82`).

### 8. Evidências de capacidades

| Cap. | Fonte | Resumo |
|---|---|---|
| C1 | `04:L76-80` | Preço-alvo e uplift por grupo, produto e tipo de documento. |
| C1 | `04:L25-26` | Tarifa praticada efetiva (RECEITA / QTDE) como preço praticado. |
| C1 | `04:L82` | Percentis alternativos mantidos na saída (cenários potenciais, **inferido**). |
| C2 | `04:L5`, `04:L86` | Insumo para reprecificação de Arrecadação na Onda 3. |
| C2 | `04:L21`, `04:L27`, `04:L80` | Elegibilidade: PP, grupo 616, N < 15. |
| C2 | `04:L35` | Recorte DIVERSOS como público da onda **(inferido)**. |
| C3 | `04:L26`, `04:L29` | Volume anual realizado por grupo como base de tier **(inferido)**. |
| PAR | `04:L22`, `04:L28`, `04:L45-48`, `04:L54-61`, `04:L67`, `04:L79-80` | De-para, listas, faixas e thresholds embutidos. |
| LEG | `04:L15-16` | Base de origem com colunas legadas (GERCTA, GERCASH, NM_GRUPO) e formatação numérica brasileira. |
| LEG | `04:L17`, `04:L19` | Dependência das bases de segmentação e poder público. |

### 9. Dúvidas, ambiguidades e lacunas

- **Regra de cluster diverge dos demais fluxos**: aqui cluster 3 = LARGE ou INSTITUCIONAL e cluster 4 = CORPORATE (`04:L58-59`); nos fluxos 02 e 03, cluster 3 = ULTRA/GLOBAL e cluster 4 = LARGE. ULTRA/GLOBAL CORPORATE caem em "demais → 5" na arrecadação (`04:L61`). Confirmar se é intencional.
- **INSTITUCIONAL** nunca chega ao cluster (`04:L63`).
- **Base de volume do tier**: total anual vs. média mensal nos demais fluxos **(inferido)** (`04:L26`, `04:L29`).
- **Somente 2 produtos** em escopo; outras mídias descartadas sem regra explícita (`04:L28`).
- **Motivo do recorte DIVERSOS** não descrito (`04:L35`).
- **FLOATING e VLR_ARRECADADO** convertidos mas não usados (`04:L16`): há intenção de uso futuro?
- **Grupo 616** sem motivo (`04:L27`).
- **Texto cortado** no gateway G4 (`04:L27`) e seção de metodologia sem tabela (`04:L88-90`).
- **Ausência de região**: por que arrecadação não usa regionalidade, diferentemente dos outros produtos?

---

## Síntese transversal

### Padrão comum de etapas (os 4 fluxos)

1. **Carregar base de movimento/eventos do produto** (`01:L5`; `02:L16`; `03:L15`; `04:L15`).
2. **Tratar tipos e normalizar** (`01:L6`; `02:L16`; `03:L16`; `04:L16`).
3. **Enriquecer com segmento e grupo econômico** via CNPJ/CPF (`01:L7`; `02:L20`; `03:L18`; `04:L18`).
4. **Excluir Poder Público** (`01:L9`; `02:L24`; `03:L22`; `04:L21`).
5. **Restringir aos segmentos de atacado** (`01:L12`; `02:L21`; `03:L19`; `04:L24`).
6. **Recortar janela LTM de 13 referências** (`01:L17`; `02:L17`; `03:L16`; `04:L23`).
7. **Excluir grupo econômico específico** (Bradesco em 01; 616 em 02, 03, 04).
8. **Consolidar mês → ano por grupo**: quantidade (média mensal ou total), receita total, tarifa de referência (`01:L13-17`; `02:L26`; `03:L26`; `04:L25-26`).
9. **Enriquecer com UF e região** (01, 02, 03; não em 04).
10. **Classificar tier de volume** com faixas por produto (`01:L59-79`; `02:L30`; `03:L52-56`; `04:L45-48`).
11. **Classificar cluster** (tier × segmento [× região]) (`01:L81-92`; `02:L31`; `03:L31`; `04:L54-61`).
12. **Percentis por cluster** com referência corporate ponderada e cummin em P25/P75; contagem N (`01:L94-106`; `02:L50`; `03:L60`; `04:L69-74`).
13. **Preço-alvo = max(TARIFA, P75)**; uplift com limiar 1.000; N < 15 zera (`01:L108-120`; `02:L52`; `03:L62`; `04:L76-80`).
14. **Laço por produto/modalidade** e consolidação (01: 13 modalidades; 04: 2 produtos).
15. **Exportar `<PRODUTO>_vats.xlsx`** como insumo da Onda 3.

Todos os fluxos cobrem apenas os passos 1 e 2 da metodologia de 4 passos (clusterizar; propor tarifas alvo). Os passos 3 (relacionamento via saldo Invest Fácil) e 4 (matriz Stickiness × Impacto, reajustes graduais) estão fora dos notebooks (`01:L126-135`; `02:L60-68`; `03:L70-81`; `04:L88-90`).

### Diferenças relevantes

| Dimensão | Cobrança (01) | Multipag (02) | PIX (03) | Arrecadação (04) |
|---|---|---|---|---|
| Origem da tarifa praticada | tarifa média calculada (`01:L15`) | tarifa de **contrato** vigente; receita = tarifa × qtde (`02:L19-21`) | RCTA / QTDE observado (`03:L26`) | RECEITA / QTDE observado (`04:L25`) |
| Base de volume do tier | QT_MENSAL (`01:L61`) | QTDE média mensal (`02:L30`) | QTDE média mensal (`03:L30`) | QTDE_ARRECADADO anual (inferido) (`04:L29`) |
| Faixas de tier | 13 tabelas por modalidade | 4.000 / 50.000 | 100 / 500 | 200k/5M e 70k/750k |
| Cluster usa região | sim, "em alguns casos" (texto cortado) | sim (5-9) | sim (5-9) | não |
| Clusters corporate (ref. P25/P75) | não legível | [5, 6, 7, 8, 9] | [5, 6, 7, 8, 9] | [5] |
| Cluster 3 / 4 | ULTRA-GLOBAL / LARGE | ULTRA-GLOBAL / LARGE | ULTRA-GLOBAL / LARGE | LARGE-INSTITUCIONAL / CORPORATE |
| Filtros adicionais | QTD_MENSAL > 0; impressão/postagem; emissor | filtro de contrato (sobrescrito) | CD_TARF; RCTA ≥ 0 | mídia → produto; Tipo_Documento DIVERSOS |
| UF cruzada por | CPF/CNPJ | CD_GRUPO | CD_GRUPO | — |
| Granularidade de saída | grupo × modalidade | segmento × grupo | segmento × grupo | segmento × grupo × produto × tipo doc |
| Arquivos de saída | COBRANCA_vats.xlsx | MULTIPAG_vats.xlsx, df_int.csv | PIX_vats.xlsx, uf_por_grupo.xlsx | ARRECADACAO_COMPLETA_vats.xlsx, ARRECADACAO_vats.xlsx |
| Ordenação cronológica antes de "última tarifa" | não descrita | não (risco) | sim | sim |
| Grupo excluído | "grupo Bradesco" | 616 | 616 | 616 |

### Lista consolidada de parâmetros identificados

**Escopo e elegibilidade**

1. Lista de segmentos de atacado (5 segmentos) — 01, 02, 03, 04.
2. Lista de grupos econômicos excluídos (Bradesco / 616) — 01, 02, 03, 04.
3. Base/lista de clientes Poder Público — 01, 02, 03, 04.
4. Volume mínimo para entrar na análise (QTD_MENSAL > 0) — 01.
5. Tratamento de receita negativa (excluir RCTA < 0) — 03.
6. Lista de códigos de tarifa em escopo (CD_TARF PIX Pagamentos) — 03.
7. Lista de modalidades de cobrança em escopo (13) e visão Cliente/Banco — 01.
8. Mapeamento DESCR_TARIFA → modalidade — 01 (inferido).
9. Filtros de serviço/modalidade de contrato (PAGAMENTO VIA TED / FORNECEDORES) — 02.
10. De-para mídia → produto de arrecadação — 04.
11. Lista de produtos de arrecadação em escopo — 04.
12. Tipo_Documento do recorte de saída (DIVERSOS) — 04.
13. Regra do gateway impressão/postagem — 01 (não detalhada).
14. Regra de classificação de emissor — 01 (não detalhada).

**Janelas temporais**

15. Janela LTM (data início, data fim, 13 referências) — todos.
16. Janela L3M (3 meses) — 01.

**Consolidação e tarifa de referência**

17. Critério de tarifa de referência (última com QTDE > 0; ordenação cronológica) — 02, 03, 04.
18. Critério de tarifa vigente de contrato (dinic_vgcia mais recente) — 02.
19. Base de volume usada no tier (média mensal vs. total anual) — 02/03 vs. 04.
20. Granularidade de consolidação (grupo; grupo × produto; grupo × produto × tipo doc) — todos.

**Regionalidade**

21. Tabela UF → região comercial (5 regiões) — 02, 03 (e 01 inferido).
22. Chave de cruzamento de UF (CPF/CNPJ vs. CD_GRUPO) — 01 vs. 02/03.

**Clusterização**

23. Faixas de tier por produto/modalidade (13 em 01; 1 em 02; 1 em 03; 2 em 04) e flag "sem Tier 3" — todos.
24. Regra de cluster: mapeamento (tier, segmento, região) → código, por produto — todos.
25. Listas de segmentos por código de cluster (ULTRA/GLOBAL, LARGE, AGRO, CORPORATE, INSTITUCIONAL) — todos, com divergência em 04.
26. Conjunto de clusters "corporate" de referência ([5,6,7,8,9]; [5]; ilegível em 01) — todos.
27. Ordem de precedência para o cummin — 01 (explícita), demais (ordem decrescente de código).
28. Código do cluster auxiliar (9999) — 02, 03, 04 (técnico).

**Cálculo de preço-alvo e uplift**

29. Lista de percentis calculados (25, 35, 40, 50, 60, 75, 90) — todos.
30. Percentil usado como preço-alvo (P75) — todos.
31. Campo de peso da média ponderada (QT_MENSAL / QTDE / QTDE_ARRECADADO) — todos.
32. Regra "nunca reduzir" (piso = tarifa atual) — todos.
33. Limiar de tarifa que separa as fórmulas de uplift (1.000) — todos.
34. N mínimo de representatividade (15) — todos.

**Total: 34 famílias de parâmetros**, das quais 12 são comuns aos quatro fluxos e 3 (13, 14 e 8) ainda não têm regra documentada.

### Lacunas transversais críticas

- Nenhum fluxo trata preço **sugerido** distinto do preço **alvo**, nem alçada para preço abaixo do sugerido; os docs só produzem PREÇO_ALVO e UPLIFT. A distinção alvo/sugerido/praticado da Planilha Ano 1 (`00-etapas:L1`) não aparece nos fluxos.
- Nenhum fluxo cobre os passos 3 e 4 da metodologia (relacionamento/Invest Fácil; Stickiness × Impacto), que definem a gradação do reajuste.
- Não há evidência direta de **gestão de reciprocidade** (volumetria acordada × realizada); os fluxos só medem volumetria realizada.
- Exclusão do grupo 616 / Bradesco sem motivo documentado.
- Regra de cluster inconsistente entre Arrecadação e os demais produtos.
- Trechos cortados no doc de Cobrança (clusters "demais", uso de N, página 10).
- Bases de Invest Fácil, DAV, Share de boletos, TED e ROB listadas em `00-etapas:L5-18` não são usadas nos quatro fluxos analisados (exceto `rob_uf.csv`, inferido como derivado de ROB).
