#!/usr/bin/env python3
"""
Gera a apresentação executiva do Motor de Precificação Cash (MPC).
Saída: /home/itl/Projects/CASH/docs-final/10-apresentacao-executiva.pptx
Uso: python3 build_deck.py  (usa bradesco_style.py do mesmo diretório)
"""
import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bradesco_style import (Deck, RED, RED_DARK, RED_LIGHT, GRAY, GRAY_MID, GRAY_LIGHT, GRAY_BG,
                            WHITE, BLUE, BLUE_LIGHT, GREEN, AMBER, FONT, SLIDE_W, SLIDE_H)
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

OUT = "/home/itl/Projects/CASH/docs-final/10-apresentacao-executiva.pptx"
I = Inches
AMBER_DARK = RGBColor(0x7A, 0x55, 0x00)

d = Deck()


# ---------------------------------------------------------------- helpers
def dash(sh, color=GRAY_MID, w=1.25):
    sh.line.color.rgb = color
    sh.line.width = Pt(w)
    sh.line.dash_style = MSO_LINE.DASH


def group(s, x, y, w, h, title, fill=GRAY_BG, line=GRAY_LIGHT, title_color=GRAY, size=10, dashed=False):
    """Retângulo de fundo com título no canto superior esquerdo (subgraph)."""
    r = d.rect(s, I(x), I(y), I(w), I(h), fill=fill, line=line)
    if dashed:
        dash(r, color=line)
    d.text(s, I(x + 0.05), I(y + 0.02), I(w - 0.1), I(0.28), title, size=size, bold=True, color=title_color)
    return r


def node(s, x, y, w, h, txt, fill=WHITE, line=GRAY_MID, size=9, bold=False, color=GRAY, dashed=False,
         align=PP_ALIGN.CENTER, shape=MSO_SHAPE.RECTANGLE):
    """Caixa simples com texto centralizado (txt pode ser lista de parágrafos)."""
    r = d.rect(s, I(x), I(y), I(w), I(h), fill=fill, line=line, shape=shape)
    if dashed:
        dash(r, color=line)
    d.text(s, I(x), I(y), I(w), I(h), txt, size=size, bold=bold, color=color, align=align,
           anchor=MSO_ANCHOR.MIDDLE)
    return r


def node2(s, x, y, w, h, title, sub, fill=WHITE, line=GRAY_MID, size=9, subsize=8, color=GRAY,
          subcolor=GRAY_MID, dashed=False, bold=True):
    """Caixa com título em negrito e subtítulo menor, centralizados."""
    r = d.rect(s, I(x), I(y), I(w), I(h), fill=fill, line=line)
    if dashed:
        dash(r, color=line)
    tb = s.shapes.add_textbox(I(x), I(y), I(w), I(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = I(0.05)
    tf.margin_top = tf.margin_bottom = I(0.02)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r1 = p.add_run()
    r1.text = title
    r1.font.name = FONT
    r1.font.size = Pt(size)
    r1.font.bold = bold
    r1.font.color.rgb = color
    if sub:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        r2 = p2.add_run()
        r2.text = sub
        r2.font.name = FONT
        r2.font.size = Pt(subsize)
        r2.font.color.rgb = subcolor
    return r


def chip(s, x, y, w, h, txt, fill=RED, color=WHITE, size=8, dashed=False, line=None):
    sh = d.chip(s, I(x), I(y), I(w), I(h), txt, fill=fill, color=color, size=size, line=line)
    if dashed:
        dash(sh, color=line or BLUE)
    return sh


def varrow(s, x, y1, y2, color=GRAY_MID, width=1.5):
    return d.arrow(s, I(x), I(y1), I(x), I(y2), color=color, width=width)


def harrow_line(s, x1, x2, y, color=GRAY_MID, width=1.5):
    return d.arrow(s, I(x1), I(y), I(x2), I(y), color=color, width=width)


def label(s, x, y, w, h, txt, size=8, color=GRAY_MID, bold=False, align=PP_ALIGN.CENTER, italic=False,
          anchor=MSO_ANCHOR.MIDDLE):
    return d.text(s, I(x), I(y), I(w), I(h), txt, size=size, bold=bold, color=color, align=align,
                  italic=italic, anchor=anchor)


def big_number(s, x, y, w, h, num, txt):
    d.rect(s, I(x), I(y), I(w), I(h), fill=GRAY_BG, line=GRAY_LIGHT)
    d.rect(s, I(x), I(y), I(0.06), I(h), fill=RED)
    d.text(s, I(x + 0.1), I(y + 0.02), I(w - 0.15), I(0.48), num, size=24, bold=True, color=RED,
           anchor=MSO_ANCHOR.MIDDLE)
    d.text(s, I(x + 0.1), I(y + 0.48), I(w - 0.15), I(h - 0.5), txt, size=8.5, color=GRAY)


def colored_table(s, x, y, w, h, header, rows, col_widths, size=9, color_cols=()):
    """Tabela Bradesco com células coloridas (Alta/Alto=vermelho, Média/Médio=âmbar, Baixa/Baixo=verde)."""
    tbl = d.table(s, I(x), I(y), I(w), I(h), header, rows, col_widths=col_widths, size=size,
                  first_col_bold=True)
    palette = {
        "alta": (RED, WHITE), "alto": (RED, WHITE),
        "média": (AMBER, AMBER_DARK), "médio": (AMBER, AMBER_DARK),
        "baixa": (GREEN, WHITE), "baixo": (GREEN, WHITE),
    }
    for i in range(1, len(rows) + 1):
        for j in color_cols:
            c = tbl.cell(i, j)
            key = c.text_frame.text.strip().lower()
            if key in palette:
                fill, fg = palette[key]
                c.fill.solid()
                c.fill.fore_color.rgb = fill
                for p in c.text_frame.paragraphs:
                    p.alignment = PP_ALIGN.CENTER
                    for r in p.runs:
                        r.font.color.rgb = fg
                        r.font.bold = True
                c.vertical_anchor = MSO_ANCHOR.MIDDLE
    return tbl


# ============================================================ 1. CAPA
d.cover("Motor de Precificação Cash",
        "Arquitetura de solução, capacidades e roadmap",
        ["Payments Atacado  |  Precificação  |  Arquitetura de Soluções",
         "18/09/2026",
         "Rascunho para validação"])

# ============================================================ 2. AGENDA
s = d.content("Agenda")
items = [
    ("1", "Onepage de arquitetura", "Objetivo, capacidades, stack e princípios em uma página"),
    ("2", "Desenho conceitual", "Estratégia, camadas e capacidades C1, C2 e C3"),
    ("3", "Arquitetura macro", "AS-IS e TO-BE, contêineres e decisões de arquitetura"),
    ("4", "Riscos", "Riscos identificados, mitigação e donos sugeridos"),
    ("5", "Roadmap", "Fases F0 a F5, marcos, próximos passos e decisões pedidas"),
]
y = 1.6
for num, t, sub in items:
    d.rect(s, I(0.9), I(y), I(0.8), I(0.8), fill=RED)
    d.text(s, I(0.9), I(y), I(0.8), I(0.8), num, size=28, bold=True, color=WHITE,
           align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    d.text(s, I(1.9), I(y + 0.02), I(9), I(0.42), t, size=20, bold=True, color=GRAY)
    d.text(s, I(1.9), I(y + 0.42), I(9), I(0.38), sub, size=12, color=GRAY_MID)
    y += 1.02

# ============================================================ 3. ONEPAGE
s = d.content("Onepage de arquitetura",
              "Motor de Precificação Cash (MPC) em uma página", section="Onepage")

# objetivo
d.rect(s, I(0.45), I(1.4), I(12.43), I(0.55), fill=RED_LIGHT)
d.rect(s, I(0.45), I(1.4), I(0.08), I(0.55), fill=RED)
d.text(s, I(0.6), I(1.4), I(12.2), I(0.55),
       "Objetivo: substituir a cadeia manual Planilha Ano 1 → SAS → SQL 010 → Calculadora por um motor online, "
       "parametrizável e auditável, que devolve preço praticado, alvo e sugerido, cenários, uplift e alçada "
       "para o Atacado, alimentado pela BRP Cash gerada no Databricks.",
       size=10.5, color=GRAY, anchor=MSO_ANCHOR.MIDDLE)

# --- coluna esquerda: capacidades
label(s, 0.45, 2.02, 7.6, 0.25, "Capacidades de negócio", size=10, bold=True, color=RED, align=PP_ALIGN.LEFT)
cy, ch = 2.3, 1.5
d.box(s, I(0.45), I(cy), I(2.4), I(ch), "C1 Cálculo e Simulação",
      ["Preço praticado, alvo e sugerido", "Cenários, uplift e alçada", "Preço vigente e histórico",
       "APIs para canais; auditoria"], body_size=9, title_size=10, line=RED)
chip(s, 0.55, cy + ch - 0.32, 2.2, 0.26, "PRIORITÁRIA — FUNCIONA HOJE", fill=RED, size=7.5)
d.box(s, I(3.05), I(cy), I(2.4), I(ch), "C2 Onda de Reprecificação",
      ["Planejamento e elegíveis", "Novo preço em lote (reusa C1)", "Aprovação e efetivação"],
      body_size=9, title_size=10, title_fill=BLUE, line=BLUE, dashed=True)
chip(s, 3.15, cy + ch - 0.32, 2.2, 0.26, "EVOLUÇÃO — A DETALHAR", fill=BLUE, size=7.5)
d.box(s, I(5.65), I(cy), I(2.4), I(ch), "C3 Gestão de Reciprocidade",
      ["Registro do acordo", "Monitoramento e desvio", "Elegibilidade para C2 e alertas"],
      body_size=9, title_size=10, title_fill=BLUE, line=BLUE, dashed=True)
chip(s, 5.75, cy + ch - 0.32, 2.2, 0.26, "EVOLUÇÃO — A DETALHAR", fill=BLUE, size=7.5)

# módulos transversais
label(s, 0.45, 3.92, 7.6, 0.25, "Módulos transversais (necessários desde C1)", size=10, bold=True, color=RED,
      align=PP_ALIGN.LEFT)
my, mh, mw = 4.18, 0.8, 1.8
mods = [("M1 Parametrização", "versões, staging, vigência, perfis"),
        ("M2 Preparação de Dados", "Databricks → BRP Cash por ciclo"),
        ("M3 Legado", "preço vigente e histórico; desligar SAS/SQL 010"),
        ("M4 Governança", "auditoria, perfis, monitoramento, contingência")]
for k, (t, b) in enumerate(mods):
    d.box(s, I(0.45 + k * (mw + 0.133)), I(my), I(mw), I(mh), t, b, body_size=8.5, title_size=9,
          title_fill=GRAY, line=GRAY_LIGHT)

# stack
label(s, 0.45, 5.08, 7.6, 0.25, "Stack (aderente à stack corporativa)", size=10, bold=True, color=RED,
      align=PP_ALIGN.LEFT)
ra, rb, chh = 5.35, 5.9, 0.42
chip(s, 0.45, ra, 1.6, chh, "Salesforce FSC (canal)", fill=GRAY, size=8)
harrow_line(s, 2.07, 2.43, ra + chh / 2)
chip(s, 2.45, ra, 1.6, chh, "Akamai · App Gateway · Axway", fill=GRAY, size=8)
harrow_line(s, 4.07, 4.43, ra + chh / 2)
chip(s, 4.45, ra, 1.6, chh, "Java (Spring Boot) no ARO", fill=RED, size=8)
harrow_line(s, 6.07, 6.43, ra + chh / 2)
chip(s, 6.45, ra, 1.6, rb + chh - ra, "Azure SQL (sql-motor)", fill=RED_DARK, size=8)
chip(s, 0.45, rb, 1.6, chh, "Control-M (dispara jobs)", fill=GRAY_MID, size=8)
harrow_line(s, 2.07, 2.43, rb + chh / 2)
chip(s, 2.45, rb, 1.6, chh, "Databricks: dbx-ppp → BRP Cash", fill=BLUE, size=8)
d.harrow(s, I(4.1), I(rb + 0.03), I(2.33), I(chh - 0.06), fill=GRAY_MID, txt="reverse ETL (JDBC)", size=8)
label(s, 0.45, 6.4, 7.6, 0.45,
      "Mensageria entre contextos: Azure Service Bus (não está na stack — a validar; fallback outbox + polling). "
      "Segurança: OAuth2 no Axway, perfis via AD/Salesforce.",
      size=8.5, color=GRAY_MID, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP)

# --- coluna direita: princípios e números
d.box(s, I(8.3), I(2.02), I(4.58), I(2.6), "Princípios de arquitetura",
      ["**1. Salesforce é canal, não motor**: nenhuma regra de preço em Apex (AD-05).",
       "**2. Regras como dados versionados**: tiers, clusters, percentis e premissas em tabelas com vigência (AD-04, AD-06).",
       "**3. BRP Cash versionada por ciclo**: ativação atômica e rollback sempre disponível (AD-01, AD-03, AD-13).",
       "**4. Legado atrás de camada anticorrupção** e transição em shadow, sem big bang (AD-10, AD-14)."],
      body_size=9, title_size=10, title_fill=RED, line=GRAY_LIGHT)
label(s, 8.3, 4.72, 4.58, 0.25, "Números de contexto", size=10, bold=True, color=RED, align=PP_ALIGN.LEFT)
big_number(s, 8.3, 5.0, 2.2, 0.9, "4", "macroprodutos: Cobrança, Arrecadação, Multipag e PIX")
big_number(s, 10.68, 5.0, 2.2, 0.9, "18", "produtos/eventos tarifados no catálogo de preços")
big_number(s, 8.3, 5.98, 2.2, 0.9, "34", "famílias de parâmetros hoje em código, listas e abas")
big_number(s, 10.68, 5.98, 2.2, 0.9, "7", "notebooks Python a portar para Databricks Workflows")

# ============================================================ 4. SEÇÃO 2
d.section("2", "Desenho conceitual",
          "Estratégia de negócio, canais, capacidades e módulos transversais do Motor de Precificação Cash.")

# ============================================================ 5. CAMADAS
s = d.content("Desenho conceitual em camadas",
              "Seis camadas de negócio; C2 e C3 tracejadas como evolução a detalhar com o negócio",
              section="Desenho conceitual")
LX, LW = 0.45, 1.85          # coluna de rótulo
IX, IW = 2.45, 9.55          # área dos itens
AX = 12.2                     # faixa da seta de fluxo
layers = [("1", "Estratégia de negócio", 0.72),
          ("2", "Canais e jornadas", 0.78),
          ("3", "Capacidades de negócio", 1.15),
          ("4", "Módulos transversais", 0.62),
          ("5", "Dados e inteligência", 0.85),
          ("6", "Legado e fontes", 0.85)]
ly = {}
y = 1.4
for num, name, h in layers:
    ly[num] = (y, h)
    d.rect(s, I(LX), I(y), I(IW + LW + 0.15), I(h), fill=GRAY_BG, line=GRAY_LIGHT)
    d.rect(s, I(LX), I(y), I(LW), I(h), fill=RED if num not in ("4",) else GRAY)
    d.text(s, I(LX), I(y), I(LW), I(h), [num, name], size=9.5, bold=True, color=WHITE,
           align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    y += h + 0.1


def row_items(s, y, h, items, gap=0.12, pad=0.08):
    """Distribui caixas de mesma largura na área de itens."""
    n = len(items)
    w = (IW - gap * (n - 1)) / n
    out = []
    for k, it in enumerate(items):
        x = IX + k * (w + gap)
        out.append((x, w))
        node(s, x, y + pad, w, h - 2 * pad, it["t"], size=it.get("size", 8.5), dashed=it.get("dashed", False),
             line=it.get("line", GRAY_MID), fill=it.get("fill", WHITE), bold=it.get("bold", False),
             color=it.get("color", GRAY))
    return out


# 1 Estratégia
y1, h1 = ly["1"]
row_items(s, y1, h1, [
    {"t": "Monetizar payments no Atacado: uplift com política nunca reduzir"},
    {"t": "Padronizar preço por cluster (tier x segmento x região)"},
    {"t": "Autonomia comercial com alçada controlada"},
    {"t": "Reter clientes e garantir reciprocidade dos acordos"},
    {"t": "Governança e auditoria dos parâmetros"},
])
# 2 Canais
y2, h2 = ly["2"]
pos2 = row_items(s, y2, h2, [
    {"t": "Calculadora Salesforce FSC (gerente e comercial)", "bold": True},
    {"t": "Jornada de contratação sem alçada no preço sugerido"},
    {"t": "Telas de parametrização (time de Precificação)"},
    {"t": "Telas de onda e aprovação [EVOLUÇÃO]", "dashed": True, "line": BLUE, "color": BLUE},
    {"t": "APIs para outros canais, plataformas e integradores (Axway)"},
])
# 3 Capacidades
y3, h3 = ly["3"]
cw1, cw2 = 3.55, 2.85
chip_y = y3 + h3 - 0.07 - 0.26
d.box(s, I(IX), I(y3 + 0.07), I(cw1), I(h3 - 0.14), "C1 Cálculo, Simulação e Entrega de Preços",
      "Preço alvo/sugerido/praticado; simulação e cenários; alçada; preço vigente; APIs; rastreabilidade",
      body_size=8, title_size=9, line=RED)
chip(s, IX + cw1 - 1.75, chip_y, 1.7, 0.22, "PRIORITÁRIA — FUNCIONA HOJE", fill=RED_DARK, size=7)
x_c2 = IX + cw1 + 0.15
d.box(s, I(x_c2), I(y3 + 0.07), I(cw2), I(h3 - 0.14), "C2 Onda de Reprecificação",
      "Planejamento, elegíveis, novo preço (reusa C1), aprovação, efetivação",
      body_size=8, title_size=9, title_fill=BLUE, line=BLUE, dashed=True)
chip(s, x_c2 + cw2 - 0.95, chip_y, 0.9, 0.22, "EVOLUÇÃO", fill=BLUE, size=7)
x_c3 = x_c2 + cw2 + 0.15
d.box(s, I(x_c3), I(y3 + 0.07), I(cw2), I(h3 - 0.14), "C3 Gestão de Reciprocidade",
      "Acordo, monitoramento, desvio, elegibilidade para C2 (evento) e alertas",
      body_size=8, title_size=9, title_fill=BLUE, line=BLUE, dashed=True)
chip(s, x_c3 + cw2 - 0.95, chip_y, 0.9, 0.22, "EVOLUÇÃO", fill=BLUE, size=7)
# seta C3 -> C2 (evento ClienteElegivelParaReprecificacao)
harrow_line(s, x_c3, x_c2 + cw2, y3 + h3 / 2, color=BLUE)

# 4 Módulos transversais
y4, h4 = ly["4"]
mw = (IW - 0.15) / 2
node2(s, IX, y4 + 0.07, mw, h4 - 0.14, "M1 Parametrização",
      "catálogo, tiers, cluster, percentis, premissas, exceções; versões, staging, vigência, perfis, auditoria",
      subsize=7.5, line=GRAY)
node2(s, IX + mw + 0.15, y4 + 0.07, mw, h4 - 0.14, "M4 Governança, Auditoria e Segurança",
      "trilhas de execução e de mudança de parâmetro, perfis, alçadas, monitoramento, contingência",
      subsize=7.5, line=GRAY)
# 5 Dados e inteligência
y5, h5 = ly["5"]
w5 = (IW - 2 * 0.45) / 3
node2(s, IX, y5 + 0.08, w5, h5 - 0.16, "M2 Pipeline de Preparação de Preços",
      "Databricks Workflows (dbx-ppp): porte dos 7 notebooks, validações de qualidade", subsize=7.5, line=BLUE)
d.harrow(s, I(IX + w5 + 0.05), I(y5 + h5 / 2 - 0.12), I(0.35), I(0.24), fill=GRAY_MID)
node2(s, IX + w5 + 0.45, y5 + 0.08, w5, h5 - 0.16, "Modelos analíticos",
      "tier, cluster, percentis P25-P90, preço-alvo, uplift, stickiness x impacto", subsize=7.5, line=BLUE)
d.harrow(s, I(IX + 2 * w5 + 0.5), I(y5 + h5 / 2 - 0.12), I(0.35), I(0.24), fill=GRAY_MID)
node2(s, IX + 2 * (w5 + 0.45), y5 + 0.08, w5, h5 - 0.16, "BRP Cash (versão por ciclo anomes)",
      "MPA, PPC, Matriz de Relacionamento, Indicadores de Reciprocidade; reverse ETL para o motor",
      subsize=7.5, line=BLUE, fill=BLUE_LIGHT)
# 6 Legado e fontes
y6, h6 = ly["6"]
row_items(s, y6, h6, [
    {"t": "Sistemas de origem: eventos tarifados, movimento, contratos, segmentos, ROB, IF/DAV, share BACEN/cash/boletos", "size": 8},
    {"t": "M3 Adaptador de Legado: preço vigente e histórico de 12 meses, tarifas de contrato, cadastro de grupo econômico", "size": 8},
    {"t": "SAS SIMUL_* + Motor da Calculadora SQL 010 + Planilha Ano 1: a desligar por produto (shadow run)", "size": 8, "dashed": True, "line": GRAY_MID},
], gap=0.3)

# setas verticais: parametrização atravessa (M1 -> C1 e M1 -> M2)
xm1 = IX + mw / 2
varrow(s, xm1, y4 + 0.07, y3 + h3 - 0.07, color=RED)
varrow(s, xm1, y4 + h4 - 0.07, y5 + 0.08, color=RED)
label(s, xm1 + 0.05, y4 - 0.13, 1.6, 0.2, "parâmetros vigentes", size=6.5, color=RED, align=PP_ALIGN.LEFT)
# fluxo de dados (faixa direita)
fy_top, fy_bot = y2 + 0.1, y6 + h6 - 0.1
up = d.rect(s, I(AX), I(fy_top), I(0.55), I(fy_bot - fy_top), fill=RED_LIGHT, line=None, shape=MSO_SHAPE.UP_ARROW)
tb = d.text(s, I(AX + 0.275 - 2.2), I((fy_top + fy_bot) / 2 - 0.15), I(4.4), I(0.3),
            "Fluxo de dados: fontes → pipeline → BRP Cash → motor → canais", size=8, bold=True, color=RED,
            align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
tb.rotation = 270.0
# seta fontes -> pipeline (legado para dados) e BRP -> C1
varrow(s, IX + w5 / 2, y6 + 0.08, y5 + h5 - 0.08, color=BLUE)
varrow(s, IX + 2 * (w5 + 0.45) + w5 / 2, y5 + 0.08, y4 + h4 - 0.07, color=BLUE)

# ============================================================ 6. CAPACIDADES
s = d.content("Capacidades de negócio",
              "C1 prioritária e funcional hoje; C2 e C3 são evolução a detalhar com o negócio",
              section="Desenho conceitual")
cols = [
    {"id": "C1", "t": "C1 Cálculo, Simulação e Entrega de Preços", "status": "PRIORITÁRIA — FUNCIONA HOJE",
     "fill": RED, "line": RED, "dashed": False,
     "subs": ["C1.1 Consulta de preço alvo, sugerido e praticado",
              "C1.2 Simulação e cenários (percentis, tier, relacionamento)",
              "C1.3 Cálculo de alçada e indicação do aprovador",
              "C1.4 Preço vigente e histórico 12 meses (legado)",
              "C1.5 APIs para canais (Salesforce e outros)",
              "C1.6 Rastreabilidade das execuções"],
     "hoje": "Calculadora Salesforce alimentada por Planilha Ano 1, SAS (SIMUL_*) e Motor da Calculadora no SQL 010. "
             "Regras do preço sugerido em macro e procedimento não documentados; sem staging, versão nem log.",
     "falta": "Definição formal de preço sugerido x alvo; níveis e aprovadores da alçada; latência aceitável do "
              "preço vigente (foto x online); decisões sobre INSTITUCIONAL e cluster de Arrecadação."},
    {"id": "C2", "t": "C2 Onda de Reprecificação", "status": "EVOLUÇÃO — A DETALHAR COM O NEGÓCIO",
     "fill": BLUE, "line": BLUE, "dashed": True,
     "subs": ["C2.1 Planejamento da onda (escopo, calendário, metas)",
              "C2.2 Seleção de elegíveis (entrada de C3 + filtros)",
              "C2.3 Novo preço por cliente (reusa C1 + gradação)",
              "C2.4 Aprovação (alçada) e comunicação",
              "C2.5 Efetivação no legado e acompanhamento"],
     "hoje": "Onda decidida manualmente na Planilha (Saída 1). Uplift por cliente x produto e listas de exceção "
             "em abas; Matriz de Relacionamento (stickiness x impacto) pronta como insumo.",
     "falta": "Critérios de elegibilidade e papel de cada lista; gradação do reajuste por Stickiness x Impacto; "
              "periodicidade; quem aprova a onda; o motor efetiva a tarifa no legado ou só recomenda."},
    {"id": "C3", "t": "C3 Gestão de Reciprocidade", "status": "EVOLUÇÃO — A DETALHAR COM O NEGÓCIO",
     "fill": BLUE, "line": BLUE, "dashed": True,
     "subs": ["C3.1 Registro do acordo (volumetria, saldo, produtos)",
              "C3.2 Monitoramento do realizado (L3M, IF/DAV, SoW, share)",
              "C3.3 Detecção de desvio (regras e tolerâncias)",
              "C3.4 Elegibilidade para C2 e alertas ao gerente"],
     "hoje": "Só indicadores realizados: emissões L3M, saldo Invest Fácil/DAV, SoW de boletos, share de cash. "
             "Nenhum acordo registrado em sistema; comparação acordado x realizado inexistente.",
     "falta": "O que é o acordo de reciprocidade e onde é registrado; tolerâncias e persistência do desvio; "
              "periodicidade; consequência (onda, retirada do desconto, alerta); dono do acordo."},
]
cx0, cwid, cgap, cy0, chgt = 0.45, 4.01, 0.2, 1.4, 5.0
for k, c in enumerate(cols):
    x = cx0 + k * (cwid + cgap)
    outer = d.rect(s, I(x), I(cy0), I(cwid), I(chgt), fill=WHITE, line=c["line"])
    if c["dashed"]:
        dash(outer, color=c["line"], w=1.5)
    d.rect(s, I(x), I(cy0), I(cwid), I(0.38), fill=c["fill"])
    d.text(s, I(x), I(cy0), I(cwid), I(0.38), c["t"], size=10.5, bold=True, color=WHITE,
           align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    chip(s, x + 0.3, cy0 + 0.47, cwid - 0.6, 0.26, c["status"], fill=c["fill"], size=7.5)
    label(s, x + 0.1, cy0 + 0.8, cwid - 0.2, 0.22, "Sub-capacidades", size=9, bold=True, color=c["fill"],
          align=PP_ALIGN.LEFT)
    d.bullets(s, I(x + 0.1), I(cy0 + 1.02), I(cwid - 0.2), I(1.55), c["subs"], size=8.5, spacing=2)
    d.box(s, I(x + 0.1), I(cy0 + 2.62), I(cwid - 0.2), I(1.1), "O que existe hoje", c["hoje"],
          body_size=8, title_size=9, title_fill=GRAY, line=GRAY_LIGHT)
    d.box(s, I(x + 0.1), I(cy0 + 3.8), I(cwid - 0.2), I(1.12), "O que falta o negócio definir", c["falta"],
          body_size=8, title_size=9, title_fill=GRAY_MID if k == 0 else BLUE, line=GRAY_LIGHT)
# rodapé de decisão
d.rect(s, I(0.45), I(6.5), I(12.43), I(0.5), fill=RED_LIGHT)
d.rect(s, I(0.45), I(6.5), I(0.08), I(0.5), fill=RED)
d.text(s, I(0.6), I(6.5), I(12.2), I(0.5),
       "Decisão: C3 é capacidade própria e publica elegibilidade para C2 (evento ClienteElegivelParaReprecificacao). "
       "Motivos: ciclo de vida próprio desde a contratação; outros consumidores (gerente, desconto por relacionamento em C1); "
       "bounded context separado. A dependência C2 → C3 é de dados, não de estrutura.",
       size=9, color=GRAY, anchor=MSO_ANCHOR.MIDDLE)

# ============================================================ 7. SEÇÃO 3
d.section("3", "Arquitetura macro",
          "Do AS-IS manual ao TO-BE: contêineres, integrações e decisões de arquitetura.")

# ============================================================ 8. AS-IS -> TO-BE
s = d.content("AS-IS → TO-BE",
              "Da cadeia manual de distribuição a um motor online alimentado pela BRP Cash",
              section="Arquitetura macro")
# painel AS-IS
group(s, 0.45, 1.4, 5.7, 5.55, "AS-IS: cadeia manual (Planilha → SAS → SQL 010 → Calculadora)", fill=GRAY_BG,
      title_color=GRAY)
asis = [("Extração SQL / Databricks", "exportação de CSVs para a pasta 'entradas'", "cópia de arquivos"),
        ("7 notebooks Python locais", "01-05 produtos, 06 uplift consolidado, 07 stickiness x impacto",
         "datas e listas hard-coded"),
        ("Planilha Preço Ano 1.xlsx", "abas manuais + macro Preço por Produto / Resumo por GE",
         "macro VBA não documentada"),
        ("SAS: tabelas SIMUL_*_AAAAMM", "importa 11 xlsx copiados à mão", "cópia manual de 11 arquivos"),
        ("Motor da Calculadora (SQL 010)", "regra de negócio do preço sugerido", "não auditável nem versionado"),
        ("Calculadora Salesforce", "gerente comercial simula e negocia", "defasagem mensal do preço")]
ay, ah, agap = 1.78, 0.62, 0.24
for k, (t, sub, pain) in enumerate(asis):
    yy = ay + k * (ah + agap)
    red = k in (2, 4)
    node2(s, 0.65, yy, 3.1, ah, t, sub, line=RED if red else GRAY_MID, fill=RED_LIGHT if red else WHITE,
          subsize=7.5, size=9)
    label(s, 3.85, yy, 2.2, ah, "dor: " + pain, size=8, color=RED, italic=True, align=PP_ALIGN.LEFT)
    if k < len(asis) - 1:
        varrow(s, 2.2, yy + ah, yy + ah + agap)
# seta central
d.harrow(s, I(6.25), I(3.7), I(0.75), I(0.7), fill=RED)
label(s, 6.15, 4.45, 0.95, 0.9, "Transição em shadow por produto (AD-14)", size=7.5, color=RED, bold=True)
# painel TO-BE
group(s, 7.1, 1.4, 5.78, 5.55, "TO-BE: Motor de Precificação Cash", fill=WHITE, title_color=RED, line=RED)
tx, tw = 7.3, 5.4
# Salesforce (topo) -> ... ordem de cima para baixo: canais, borda, ARO, Azure SQL, Databricks
node2(s, tx, 1.78, tw, 0.66, "Salesforce FSC (canal, LWC + Named Credentials)",
      "Calculadora  |  Parametrização  |  Reprecificação [EVOLUÇÃO]", size=9, subsize=8, line=GRAY_MID)
varrow(s, 10.0, 2.44, 2.66)
label(s, 10.1, 2.44, 2.5, 0.22, "REST/JSON, OAuth2", size=7.5, align=PP_ALIGN.LEFT)
node2(s, tx, 2.66, tw, 0.5, "Borda: Akamai → App Gateway → Axway (API Gateway)", None, size=9, line=GRAY_MID)
varrow(s, 10.0, 3.16, 3.38)
label(s, 10.1, 3.16, 2.5, 0.22, "APIs /v1/precos, /alcadas, /parametros", size=7.5, align=PP_ALIGN.LEFT)
aro = group(s, tx, 3.38, tw, 1.36, "Plataforma ARO (OpenShift) — microsserviços Java Spring Boot", fill=GRAY_BG,
            size=9)
svcs = [("svc-pricing", False), ("svc-alcada", False), ("svc-parametros", False), ("svc-legado-adapter", False),
        ("svc-publicacao", False), ("svc-reciprocidade [EVOL]", True), ("svc-reprecificacao [EVOL]", True)]
sw, sg = 1.28, 0.09
for k, (n, ev) in enumerate(svcs):
    r_, c_ = divmod(k, 4)
    xx = tx + 0.1 + c_ * (sw + sg)
    yy = 3.72 + r_ * 0.47
    chip(s, xx, yy, sw, 0.36, n, fill=WHITE if ev else RED, color=BLUE if ev else WHITE, size=7.5,
         dashed=ev, line=BLUE if ev else None)
varrow(s, 10.0, 4.74, 4.96)
label(s, 10.1, 4.74, 2.5, 0.22, "JDBC (BRP ativa, parâmetros, cotações)", size=7.5, align=PP_ALIGN.LEFT)
node2(s, tx, 4.96, tw, 0.5, "Azure SQL (sql-motor): BRP Cash ativa, parâmetros, alçada, auditoria", None,
      size=9, line=RED_DARK, fill=RED_LIGHT)
varrow(s, 10.0, 5.98, 5.46)
label(s, 10.1, 5.5, 2.5, 0.22, "reverse ETL (JDBC) + ativação atômica", size=7.5, align=PP_ALIGN.LEFT)
node2(s, tx, 5.98, tw, 0.82, "Databricks: dbx-ppp (Workflows) → BRP Cash (Delta por anomes)",
      "porte dos 7 notebooks; MPA, PPC, Matriz de Relacionamento, Indicadores; Control-M dispara o job",
      size=9, subsize=8, line=BLUE, fill=BLUE_LIGHT)

# ============================================================ 9. DESENHO MACRO
s = d.content("Desenho macro de arquitetura",
              "Visão de contêineres (C4 nível 2): canais, borda, plataforma ARO, dados, mensageria, analítica e legado",
              section="Arquitetura macro")
# Canais
group(s, 0.45, 1.4, 7.4, 1.0, "Canais")
d.rect(s, I(0.6), I(1.68), I(4.95), I(0.62), fill=WHITE, line=GRAY_MID)
label(s, 0.65, 1.69, 1.2, 0.6, "Salesforce FSC (LWC)", size=8, bold=True, color=GRAY, align=PP_ALIGN.LEFT)
chip(s, 1.9, 1.8, 1.1, 0.36, "Calculadora", fill=RED, size=7.5)
chip(s, 3.08, 1.8, 1.15, 0.36, "Parametrização", fill=RED, size=7.5)
chip(s, 4.31, 1.8, 1.18, 0.36, "Reprecificação [EVOL]", fill=WHITE, color=BLUE, size=7, dashed=True, line=BLUE)
node(s, 5.7, 1.68, 2.0, 0.62, "Outros canais, plataformas e integradores", size=8)
varrow(s, 4.1, 2.4, 2.65)
label(s, 4.2, 2.42, 2.0, 0.2, "HTTPS / Named Credential", size=7, align=PP_ALIGN.LEFT)
# Borda
group(s, 0.45, 2.65, 7.4, 0.55, "Borda")
chip(s, 1.25, 2.75, 1.5, 0.34, "Akamai", fill=GRAY, size=8)
d.harrow(s, I(2.8), I(2.82), I(0.7), I(0.2), fill=GRAY_MID)
chip(s, 3.55, 2.75, 1.7, 0.34, "Azure Application Gateway", fill=GRAY, size=7.5)
d.harrow(s, I(5.3), I(2.82), I(0.7), I(0.2), fill=GRAY_MID)
chip(s, 6.05, 2.75, 1.6, 0.34, "Axway API Gateway (OAuth2)", fill=GRAY, size=7.5)
varrow(s, 4.1, 3.2, 3.45)
# ARO
group(s, 0.45, 3.45, 7.4, 1.5, "Plataforma ARO (OpenShift) — microsserviços Java Spring Boot")
svcs = [("svc-pricing", "Cálculo de Preço", False), ("svc-alcada", "Alçada e Aprovação", False),
        ("svc-parametros", "Parametrização", False), ("svc-publicacao", "Ativação de versão BRP", False),
        ("svc-legado-adapter", "Adaptador de Legado (ACL)", False),
        ("svc-reciprocidade", "C3 [EVOLUÇÃO]", True), ("svc-reprecificacao", "C2 [EVOLUÇÃO]", True)]
sw, sg = 1.72, 0.13
for k, (n, sub, ev) in enumerate(svcs):
    r_, c_ = divmod(k, 4)
    xx = 0.6 + c_ * (sw + sg)
    yy = 3.75 + r_ * 0.58
    node2(s, xx, yy, sw, 0.5, n, sub, size=8, subsize=7, line=BLUE if ev else RED, dashed=ev,
          color=BLUE if ev else RED_DARK, fill=WHITE)
varrow(s, 2.0, 4.95, 5.2)
label(s, 2.08, 4.97, 1.5, 0.2, "eventos de domínio", size=7, align=PP_ALIGN.LEFT)
varrow(s, 5.85, 4.95, 5.2)
label(s, 5.93, 4.97, 1.5, 0.2, "JDBC", size=7, align=PP_ALIGN.LEFT)
# Mensageria / Dados de serviço / Databricks
group(s, 0.45, 5.2, 3.15, 1.1, "Mensageria")
node2(s, 0.6, 5.5, 2.85, 0.68, "Azure Service Bus (sb-eventos) — a validar",
      "tópicos: VersaoPublicada, ClienteElegivel, DesvioReciprocidade; fallback outbox + polling",
      size=8, subsize=7, line=AMBER, fill=WHITE, color=AMBER_DARK)
group(s, 3.85, 5.2, 4.0, 1.1, "Dados de serviço")
node2(s, 4.0, 5.5, 3.7, 0.68, "Azure SQL Database (sql-motor)",
      "BRP Cash ativa e anterior, parâmetros versionados, alçada, cotações, auditoria; zona-redundante",
      size=8, subsize=7, line=RED_DARK, fill=RED_LIGHT, color=RED_DARK)
group(s, 8.35, 5.2, 4.53, 1.1, "Plataforma analítica — Databricks")
node2(s, 8.5, 5.5, 1.3, 0.68, "Fontes", "movimento, eventos tarifados, IF/DAV, ROB, share", size=8, subsize=6.5,
      line=BLUE)
d.harrow(s, I(9.83), I(5.76), I(0.22), I(0.16), fill=GRAY_MID)
node2(s, 10.08, 5.5, 1.3, 0.68, "dbx-ppp", "Workflows PySpark: 7 notebooks, validações", size=8, subsize=6.5,
      line=BLUE)
d.harrow(s, I(11.41), I(5.76), I(0.22), I(0.16), fill=GRAY_MID)
node2(s, 11.66, 5.5, 1.1, 0.68, "BRP Cash", "Delta gold por anomes (dbx-brp)", size=8, subsize=6.5, line=BLUE,
      fill=BLUE_LIGHT)
harrow_line(s, 8.35, 7.85, 5.84, color=BLUE, width=2)
label(s, 7.55, 5.98, 1.1, 0.3, "reverse ETL (JDBC, staging)", size=6.5, color=BLUE)
# Legado
group(s, 8.1, 1.4, 2.3, 3.5, "Legado")
node2(s, 8.2, 1.72, 2.1, 0.85, "Sistema de tarifas e contratos", "preço vigente, histórico 12 meses, tarifa de contrato",
      size=8, subsize=7, line=GRAY_MID)
node2(s, 8.2, 2.67, 2.1, 0.75, "Cadastro / grupo econômico", "segmentos, CNPJ → grupo, região", size=8,
      subsize=7, line=GRAY_MID)
node2(s, 8.2, 3.52, 2.1, 1.25, "SAS SIMUL_* / SQL 010 / Planilha Ano 1",
      "a desligar por produto após shadow run (AD-14)", size=8, subsize=7, line=GRAY_MID, dashed=True,
      color=GRAY_MID)
harrow_line(s, 8.1, 7.85, 2.15, color=GRAY_MID)
label(s, 7.86, 1.86, 1.05, 0.28, "consulta online (opcional)", size=6.5, color=GRAY_MID)
varrow(s, 9.25, 4.9, 5.2, color=BLUE)
label(s, 9.32, 4.93, 1.4, 0.25, "foto mensal + cadastro", size=6.5, color=BLUE, align=PP_ALIGN.LEFT)
# Orquestração
group(s, 10.65, 3.9, 2.23, 1.0, "Orquestração")
node2(s, 10.78, 4.2, 1.98, 0.6, "Control-M", "dispara dbx-ppp, job de reciprocidade e lote de C2",
      size=8, subsize=7, line=GRAY_MID)
varrow(s, 11.77, 4.9, 5.2)
# Legenda
group(s, 10.65, 1.4, 2.23, 2.3, "Legenda e fluxos", fill=WHITE)
d.bullets(s, I(10.7), I(1.7), I(2.15), I(2.0),
          ["Tracejado = evolução (C2/C3)",
           "1 Canais → borda → serviços",
           "2 Fontes → dbx-ppp → BRP Cash → reverse ETL → Azure SQL",
           "3 Eventos entre contextos via Service Bus (a validar)",
           "4 Control-M dispara jobs",
           "5 Legado via Adaptador (foto ou online)"], size=7.5, spacing=2)

# ============================================================ 10. DECISÕES
s = d.content("Decisões de arquitetura chave",
              "Escolhas, alternativas rejeitadas e justificativa (detalhes no documento 06 e no brief A0)",
              section="Arquitetura macro")
rows = [
    ["AD-01 Preparação de dados",
     "Databricks Workflows (PySpark/Delta) portando os 7 notebooks; BRP Cash em tabelas Delta por anomes; Control-M só dispara o job",
     "Microsserviços Python schedulados por Control-M",
     "As bases já estão no Databricks; extrair dezenas de milhões de linhas duplicaria dado e governança; versionamento e lineage nativos"],
    ["AD-02 / AD-04 Núcleo do motor",
     "Microsserviços Java (Spring Boot) no ARO + Azure SQL; regras como parâmetros versionados em tabelas e estratégias em código",
     "FICO (Blaze / Decision Modeler) + MongoDB",
     "Regras atuais são tabelas de faixas (tier, cluster, percentil, desconto); FICO tem licença cara, skill escasso e lock-in; modelo é relacional"],
    ["AD-05 Front-end",
     "Salesforce FSC (LWC + Named Credentials → App Gateway → Axway); nenhuma regra de negócio em Apex",
     "Front próprio (React) para parametrização",
     "Um só front e um só modelo de acesso; outros canais consomem as mesmas APIs (RF-07); mitiga R6"],
    ["AD-06 Parametrização",
     "Serviço Java + Azure SQL com versionamento, fluxo rascunho → staging → publicado, vigência agendada e auditoria",
     "Parâmetros em arquivo / configmap",
     "Sem auditoria nem vigência; o negócio precisa testar em staging antes de publicar (RF-06, RF-09)"],
    ["AD-09 Mensageria",
     "Azure Service Bus (tópicos) para eventos de domínio; fallback outbox + polling",
     "Chamadas REST síncronas entre C3 e C2",
     "Desacoplamento temporal entre contextos; Service Bus não está na stack: validar na F0 (R5)"],
    ["AD-10 Legado",
     "Adaptador de Legado (ACL) com duas estratégias: foto do preço vigente via Databricks e consulta online ao sistema de tarifas",
     "Somente foto, ou somente consulta online",
     "Só foto: preço vigente defasado; só online: dependência do legado. Latência aceitável é decisão do negócio (R4)"],
    ["AD-14 Transição",
     "Shadow run: motor responde ao lado do SQL 010 no piloto, comparador automático e corte por produto",
     "Big bang",
     "Divergência medida antes do corte; rollback em três níveis (roteamento, versão da BRP, versão de parâmetro); mitiga R7"],
]
d.table(s, I(0.45), I(1.4), I(12.43), I(5.2), ["Decisão", "Escolha", "Alternativa rejeitada", "Por quê"], rows,
        col_widths=[1.7, 4.0, 2.3, 4.4], size=8.5, first_col_bold=True)

# ============================================================ 11. SEÇÃO 4
d.section("4", "Riscos", "Riscos identificados, probabilidade, impacto, mitigação e dono sugerido.")

# ============================================================ 12. RISCOS
s = d.content("Riscos identificados",
              "Dez riscos canônicos do programa (brief A0 §10 e roadmap §9)", section="Riscos")
risks = [
    ["R1", "Regras do preço sugerido (macro + SQL 010) não documentadas", "Alta", "Alto",
     "Engenharia reversa na F0 com Precificação; oráculo de casos reais; shadow run na F1", "Precificação + arquitetura"],
    ["R2", "C2/C3 sem definição de negócio", "Alta", "Alto",
     "Discovery dedicado na F3 antes de codificar; arquitetura por eventos e reuso do motor", "Produtos + Precificação"],
    ["R3", "Qualidade e instabilidade das bases de origem (layouts, datas hard-coded)", "Média", "Alto",
     "Contratos de dados, validações no pipeline e alertas (RF-08)", "Dados / Databricks"],
    ["R4", "Latência do preço vigente (foto x online)", "Média", "Médio",
     "Adaptador com duas estratégias; decisão do negócio na F0", "Arquitetura + Precificação"],
    ["R5", "Dependência de componente fora da stack (Service Bus)", "Média", "Médio",
     "Validar cedo com arquitetura corporativa; fallback outbox + polling", "Arquitetura corporativa"],
    ["R6", "Lógica de negócio vazando para Apex / Salesforce", "Média", "Médio",
     "Diretriz AD-05; revisão de código obrigatória", "Squad Salesforce + arquitetura"],
    ["R7", "Transição sem paralelismo gera erro de preço em produção", "Baixa", "Alto",
     "Shadow run, comparador automático, critérios de corte, rollback em três níveis", "Product owner + QA"],
    ["R8", "Capacidade das equipes (Java, Databricks, Salesforce)", "Média", "Médio",
     "Squads por capacidade; dimensionamento na F0; contratação antecipada", "Patrocinador + líderes de squad"],
    ["R9", "Inconsistências entre fluxos (INSTITUCIONAL, cluster Arrecadação, grupo 616)", "Alta", "Médio",
     "Decisões registradas no catálogo de parâmetros na F0", "Precificação"],
    ["R10", "Governança de publicação (quem aprova versão de parâmetro / BRP)", "Média", "Médio",
     "Fluxo staging → aprovação → produção com alçadas (RF-06, RF-10)", "Precificação + Comitê de Produto"],
]
colored_table(s, 0.45, 1.4, 12.43, 5.3, ["ID", "Risco", "Prob.", "Impacto", "Mitigação", "Dono sugerido"], risks,
              col_widths=[0.5, 3.4, 0.7, 0.8, 4.3, 2.1], size=8.5, color_cols=(2, 3))
label(s, 0.45, 6.75, 12.43, 0.25, "Legenda: vermelho = alta/alto, âmbar = média/médio, verde = baixa/baixo.",
      size=8, color=GRAY_MID, align=PP_ALIGN.LEFT)

# ============================================================ 13. SEÇÃO 5
d.section("5", "Roadmap", "Fases F0 a F5, marcos M1 a M7, próximos passos e decisões pedidas ao comitê.")

# ============================================================ 14. ROADMAP
s = d.content("Roadmap de implementação",
              "Seis fases de out/2026 a 2028; datas são metas de trabalho a validar na F0 com a capacidade das equipes",
              section="Roadmap")
TX0, TW = 4.05, 8.83           # área da linha do tempo
MPM = TW / 21.0                # polegadas por mês (out/2026 = 0 ... dez/2028 comprimido)
quarters = ["Q4/2026", "Q1/2027", "Q2/2027", "Q3/2027", "Q4/2027", "Q1/2028", "2028 (Q2-Q4)"]
qy = 1.42
for k, q in enumerate(quarters):
    x = TX0 + k * 3 * MPM
    d.rect(s, I(x), I(qy), I(3 * MPM - 0.02), I(0.3), fill=RED if k < 6 else GRAY_MID)
    d.text(s, I(x), I(qy), I(3 * MPM), I(0.3), q, size=8.5, bold=True, color=WHITE, align=PP_ALIGN.CENTER,
           anchor=MSO_ANCHOR.MIDDLE)
label(s, 0.45, qy, 3.5, 0.3, "Fase e entregas-chave", size=9, bold=True, color=RED, align=PP_ALIGN.LEFT)
# grade
for k in range(1, 7):
    x = TX0 + k * 3 * MPM
    d.rect(s, I(x - 0.005), I(1.75), I(0.01), I(5.2), fill=GRAY_LIGHT)

phases = [
    ("F0", "Mobilização e fechamento de lacunas", "out–nov/2026",
     "Decisões de negócio, engenharia reversa do SQL 010, contrato de dados da BRP Cash, catálogo de parâmetros, arquitetura aprovada, ambientes",
     0.0, 1.43, RED, [("M1", 1.43, "arquitetura aprovada")]),
    ("F1", "MVP C1: motor online em paralelo ao legado", "nov/2026–mar/2027",
     "dbx-ppp portado, BRP Cash v1, reverse ETL, svc-pricing, svc-alcada, adaptador (foto), APIs Axway, Calculadora em shadow, piloto com gerentes",
     1.5, 6.0, RED, [("M2", 3.5, "BRP Cash v1"), ("M3", 4.4, "piloto shadow"), ("M4", 6.0, "go-live C1")]),
    ("F2", "Parametrização e desligamento do legado", "abr–jun/2027",
     "Telas Salesforce de parametrização, staging, vigência agendada, perfis; validação de dados; APIs para outros canais; desligamento SAS/SQL 010 por produto",
     6.0, 9.0, RED, [("M5", 9.0, "desligamento SAS/SQL 010")]),
    ("F3", "Discovery C2/C3 + MVP C3 [EVOLUÇÃO]", "jul–set/2027",
     "Event storming com o negócio; svc-reciprocidade (acordo, monitoramento, desvio), eventos, alertas ao gerente",
     9.0, 12.0, BLUE, [("M6", 12.0, "MVP C3")]),
    ("F4", "MVP Onda de Reprecificação [EVOLUÇÃO]", "out/2027–jan/2028",
     "svc-reprecificacao: onda, elegíveis (C3 + filtros), cálculo em lote, aprovação, efetivação (decisão de escopo), acompanhamento",
     12.0, 16.0, BLUE, [("M7", 16.0, "MVP C2")]),
    ("F5", "Escala e otimização", "2028, contínuo",
     "Novos produtos e segmentos por parametrização, outros canais, avaliação de FICO/Redis/MongoDB por evidência, modelos evoluídos",
     16.0, 21.0, GRAY_MID, []),
]
ry, rh = 1.85, 0.84
for k, (fid, name, when, deliv, m0, m1, color, marks) in enumerate(phases):
    y = ry + k * rh
    if k % 2 == 0:
        d.rect(s, I(0.45), I(y - 0.03), I(12.43), I(rh), fill=GRAY_BG)
    d.text(s, I(0.45), I(y), I(3.5), I(0.24), f"{fid}  {name}", size=9, bold=True,
           color=color if color != GRAY_MID else GRAY)
    d.text(s, I(0.45), I(y + 0.22), I(3.5), I(0.6), f"{when}. {deliv}", size=7.5, color=GRAY)
    x0, x1 = TX0 + m0 * MPM, TX0 + m1 * MPM
    d.harrow(s, I(x0), I(y + 0.03), I(x1 - x0), I(0.34), fill=color, txt=fid if (x1 - x0) > 0.8 else None, size=8)
    if (x1 - x0) <= 0.8:
        label(s, x1 + 0.02, y + 0.03, 0.4, 0.34, fid, size=8, bold=True, color=color, align=PP_ALIGN.LEFT)
    for mid, mm, mtxt in marks:
        mx = TX0 + mm * MPM
        chip(s, mx - 0.19, y + 0.44, 0.38, 0.24, mid, fill=RED_DARK if color != BLUE else BLUE, size=7)
        # rótulo do marco à direita (ou à esquerda quando próximo de outro marco)
        if mid in ("M2",):
            label(s, mx - 1.25, y + 0.44, 1.05, 0.24, mtxt, size=6.5, color=GRAY, align=PP_ALIGN.RIGHT)
        elif mid == "M3":
            label(s, mx + 0.2, y + 0.44, 0.7, 0.24, "", size=6.5)
            label(s, mx - 0.65, y + 0.66, 1.3, 0.16, mtxt, size=6.5, color=GRAY)
        else:
            label(s, mx + 0.2, y + 0.44, 1.6, 0.24, mtxt, size=6.5, color=GRAY, align=PP_ALIGN.LEFT)
label(s, 0.45, 6.92, 12.43, 0.2,
      "Vermelho = C1 e fundações; azul = capacidades de evolução (C2/C3) condicionadas ao discovery da F3; "
      "cinza = operação contínua. Esforço F0-F4: ~150 pessoas x mês em 16 meses (a refinar na F0).",
      size=7.5, color=GRAY_MID, align=PP_ALIGN.LEFT)

# ============================================================ 15. PRÓXIMOS PASSOS
s = d.content("Próximos passos e decisões pedidas",
              "Ações dos próximos 30 dias e o que o comitê precisa decidir para destravar a F1", section="Roadmap")
d.box(s, I(0.45), I(1.4), I(6.1), I(5.5), "Próximos passos (30 dias)",
      ["**1.** Aprovar este roadmap e o brief A0 no Comitê Executivo; nomear patrocinador, product owner e dono de negócio (Precificação).",
       "**2.** Agendar as sessões de engenharia reversa do SQL 010 e da macro com Precificação; obter acesso de leitura ao servidor, ao SAS e ao workbook.",
       "**3.** Extrair a primeira amostra de simulações reais da Calculadora para compor o oráculo do shadow run.",
       "**4.** Abrir com arquitetura corporativa a validação do Azure Service Bus e desenhar o fallback outbox.",
       "**5.** Solicitar workspace Databricks, Azure SQL de desenvolvimento, namespaces no ARO, rotas no Axway e sandbox Salesforce.",
       "**6.** Fechar com Precificação as definições de preço praticado, alvo e sugerido e a regra de alçada.",
       "**7.** Dimensionar os squads e confirmar disponibilidade para o início da F1 em 16/11/2026.",
       "**8.** Definir com Produtos e OPCH o grupo piloto de gerentes e as regionais participantes."],
      body_size=10, title_size=11, line=GRAY_LIGHT)
d.box(s, I(6.78), I(1.4), I(6.1), I(5.5), "Decisões de negócio pendentes (brief A0 §8)",
      ["**D1.** Regras da macro Preço por Produto / Resumo por GE e do Motor da Calculadora (SQL 010): onde o preço sugerido nasce hoje.",
       "**D2.** Conteúdo de premissas_alcada, premissas_desconto, premissas_remuneracao, tier_por_produto e regiao_por_ge.",
       "**D3.** Definição formal de preço sugerido x alvo e da regra de alçada (níveis, aprovadores).",
       "**D4.** Escopo de C2 e C3: elegibilidade, gradação do reajuste, o que é acordo de reciprocidade e se o motor efetiva tarifa no legado.",
       "**D5.** Inconsistências entre fluxos: INSTITUCIONAL, cluster de Arrecadação, grupo 616, produtos sem cluster.",
       "**D6.** Latência aceitável do preço vigente: foto via Databricks ou consulta online ao legado.",
       "**D7.** Mensageria: aprovar Azure Service Bus ou adotar o fallback outbox + polling.",
       "**D8.** Governança de publicação: quem aprova versão de parâmetro e da BRP Cash."],
      body_size=10, title_size=11, title_fill=RED_DARK, line=GRAY_LIGHT)

# ============================================================ 16. ENCERRAMENTO
s = d._slide()
d.rect(s, 0, 0, SLIDE_W, SLIDE_H, fill=RED)
d.rect(s, 0, I(5.2), SLIDE_W, I(2.3), fill=RED_DARK)
d.text(s, I(0.7), I(0.6), I(6), I(0.5), "Bradesco", size=28, bold=True, color=WHITE)
d.text(s, I(0.7), I(2.4), I(11.5), I(1.2), "Obrigado", size=44, bold=True, color=WHITE)
d.text(s, I(0.7), I(3.5), I(11.5), I(0.8), "Motor de Precificação Cash — rascunho para validação", size=18,
       color=WHITE)
d.text(s, I(0.7), I(5.5), I(11.5), I(1.5),
       ["Arquitetura de Soluções  |  Payments Atacado",
        "Contato: [nome do arquiteto responsável]  |  [e-mail corporativo]  |  [ramal]",
        "Documentos de referência: 01 a 09 em docs-final e brief A0 em anexos"],
       size=12, color=WHITE)

d.save(OUT)
print(f"gerado: {OUT} ({d.n} slides)")


# ============================================================ VALIDAÇÃO HEURÍSTICA
def validate(path):
    prs = Presentation(path)
    sw, sh_ = prs.slide_width / 914400, prs.slide_height / 914400
    problems = []

    def need_height(tf, w):
        total = 0.0
        for p in tf.paragraphs:
            txt = "".join(r.text for r in p.runs)
            sizes = [r.font.size.pt for r in p.runs if r.font.size is not None]
            size = max(sizes) if sizes else 12.0
            cpl = max(1.0, w * 72.0 / (size * 0.55))
            lines = max(1, math.ceil(len(txt) / cpl)) if txt else 1
            total += lines * size * 1.2 / 72.0
            if p.space_after is not None:
                total += p.space_after.pt / 72.0
        return total

    for idx, slide in enumerate(prs.slides, 1):
        n = len(slide.shapes)
        over = 0
        for shp in slide.shapes:
            x, y = shp.left / 914400, shp.top / 914400
            w, h = shp.width / 914400, shp.height / 914400
            if getattr(shp, "rotation", 0) in (0, 0.0) and (x + w > sw + 0.01 or y + h > sh_ + 0.01 or x < -0.01 or y < -0.01):
                problems.append(f"slide {idx}: forma fora do slide ({x:.2f},{y:.2f},{w:.2f},{h:.2f})")
            if shp.has_text_frame and shp.text_frame.text.strip():
                tf = shp.text_frame
                ml = (tf.margin_left or 0) / 914400 + (tf.margin_right or 0) / 914400
                mt = (tf.margin_top or 0) / 914400 + (tf.margin_bottom or 0) / 914400
                need = need_height(tf, w - ml)
                if need > (h - mt) * 1.05 + 0.02:
                    over += 1
                    problems.append(f"slide {idx}: texto estoura caixa ({w:.2f}x{h:.2f} in, precisa {need:.2f} in): "
                                    f"'{tf.text[:60]}...'")
            if shp.has_table:
                tbl = shp.table
                total_h = 0.0
                for r_i, row in enumerate(tbl.rows):
                    row_need = 0.0
                    for c_i, col in enumerate(tbl.columns):
                        cell = tbl.cell(r_i, c_i)
                        cw = col.width / 914400 - 0.1
                        row_need = max(row_need, need_height(cell.text_frame, cw) + 0.04)
                    total_h += max(row_need, row.height / 914400)
                bottom = y + total_h
                if bottom > sh_ - 0.35:
                    problems.append(f"slide {idx}: tabela pode ultrapassar o rodapé (fim estimado {bottom:.2f} in)")
                else:
                    print(f"slide {idx}: tabela ok, fim estimado {bottom:.2f} in")
        print(f"slide {idx}: {n} shapes, {over} textos com estouro estimado")
    print("---")
    if problems:
        for p in problems:
            print("AVISO:", p)
    else:
        print("nenhum estouro detectado pela heurística")
    return problems


if __name__ == "__main__":
    validate(OUT)
