# Anexo A2 — Análise dos fluxos de consolidação (05, 06 e 07)

Escopo deste anexo: os três fluxos que consolidam os insumos gerados pelos fluxos de produto (Cobrança, Arrecadação, Multipag/TED, PIX) até a "Planilha Ano 1" e sua distribuição para a Calculadora Salesforce.

Fontes analisadas (leitura integral):

| Arquivo | Fluxo | Artefato de referência original |
|---|---|---|
| `docs-precificacao/05-uplift-consolidado-fluxo.md` | Uplift Consolidado | `06_Uplift_consolidado.ipynb` |
| `docs-precificacao/06-matriz-stickiness-impacto-fluxo.md` | Matriz de Stickiness vs. Impacto | `07_Matriz de Stickiness vs Impacto.ipynb` |
| `docs-precificacao/07-planilha-ano1-fluxo.md` | Planilha Preço Ano 1 e Calculadora Salesforce | `08.[AS IS]_Planilha Preço ano 1_Calculadora Salesforce.png` (processo manual) |
| `docs-precificacao/00-doc-negocio.md` e `00-etapas-geracao-planilha-ano1.md` | Contexto (objetivo, premissas, bases) | — |

Convenções: referências de linha no formato `arquivo:Lxx-yy`. Tudo que não está literalmente no documento fonte está marcado como **(inferido)**. Nenhuma regra foi inventada.

Ressalva de leitura: o arquivo `06-matriz-stickiness-impacto-fluxo.md` está truncado na linha 138 (a última célula da tabela de aderência, sobre "Planejar reajustes graduais", termina em "[...]"). O conteúdo que viria depois não foi analisado.

---

## Fluxo 05 — Uplift Consolidado (fonte: `05-uplift-consolidado-fluxo.md`)

### 1. Objetivo do fluxo

Consolidar as quatro bases de uplift geradas pelos fluxos de produto (Cobrança, Arrecadação, Multipag/TED e PIX) em uma única base padronizada por segmento, grupo econômico, produto e macroproduto (`base_total.xlsx`). Em paralelo, construir a matriz de preços-alvo de referência (`tabela_precos.xlsx`), que cruza todas as combinações de produto x tier x segmento x região com o cluster de precificação e os percentis de tarifa observados por produto/cluster. É a etapa final de consolidação do Pricing Cash antes da montagem da planilha (`05-uplift-consolidado-fluxo.md:L3-5`, `L98-100`).

### 2. Bases de entrada

| Base | Origem | Janela temporal | Campos-chave | Observações |
|---|---|---|---|---|
| `COBRANCA_vats.xlsx` | Fluxo Uplift de Cobrança (02) | Não declarada no fluxo 05; (inferido) 12 meses de movimento + eventos tarifados atuais, conforme `00-etapas-geracao-planilha-ano1.md:L11-12` | SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, TIER, QT_MENSAL, QT_TOTAL, VLR_TARIFADO, TARIFA, P25..P90, PREÇO_ALVO, UPLIFT, N | Já chega com TIER, CLUSTER, percentis, PREÇO_ALVO e UPLIFT calculados (`L15`). Única base com coluna PRODUTO e TIER explícitos. |
| `ARRECADACAO_vats.xlsx` | Fluxo Arrecadação (recorte `Tipo_Documento = 'DIVERSOS'`) | Não declarada; (inferido) 12 meses (`00-etapas:L13`) | SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, QTDE_ARRECADADO, RECEITA, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N | Usada para o **uplift consolidado** (`L16`, `L31`). |
| `ARRECADACAO_COMPLETA_vats.xlsx` | Fluxo Arrecadação (todos os tipos de documento) | Idem | PRODUTO, CLUSTER, P25, P35, P40, P50, P60, P75, P90 | Usada **somente para os percentis** por produto/cluster da tabela de preços, não para o uplift (`L17`, `L21`). |
| `PIX_vats.xlsx` | Fluxo PIX (04) | Idem (`00-etapas:L9-10`) | SEGMENTO, CD_GRUPO, CLUSTER, QTDE, QTDE_TOTAL, RCTA, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N | Sem coluna PRODUTO; recebe PRODUTO fixo `'PIX PAGAMENTOS'` (`L18`, `L23`, `L33`). |
| `MULTIPAG_vats.xlsx` | Fluxo Multipag (03) | Idem (`00-etapas:L15-16`) | SEGMENTO, CD_GRUPO, CLUSTER, QTDE, QTDE_TOTAL, RECEITA, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N | Sem coluna PRODUTO; recebe PRODUTO fixo `'FORNECEDORES TED'` (`L19`, `L22`, `L32`). |
| Listas fixas do esqueleto | Hard-coded no notebook | — | PRODUTO (18), TIER (3), SEGMENTO (6), REGIAO (5) | Definem o universo de 1.620 combinações (`L25`, `L45-54`). |
| `esqueleto_tabela_precos.xlsx` | Gerado pelo próprio fluxo (etapa 11) e recarregado (etapa 12) | — | PRODUTO, TIER, SEGMENTO, REGIAO | Recarga redundante do ponto de vista do dado (`L26`). |

### 3. Etapas do fluxo

1. **Carregar as cinco bases de uplift** (Cobrança, Arrecadação Diversos, Arrecadação Completa, PIX, Multipag). Sem filtros; leitura integral. `05-uplift-consolidado-fluxo.md:L15-19`.
2. **Extrair percentis únicos por PRODUTO + CLUSTER** de cada base. Seleciona PRODUTO, CLUSTER, P25, P35, P40, P50, P60, P75, P90 e remove duplicidades mantendo a primeira ocorrência (cada par produto/cluster repete o mesmo percentil em todas as linhas de clientes). Para Multipag e PIX, que não têm PRODUTO, cria o campo fixo (`'FORNECEDORES TED'`, `'PIX PAGAMENTOS'`). Para Arrecadação usa a base **completa**, não a Diversos. `L20-23`.
3. **Consolidar percentis** empilhando as quatro tabelas em `tabela_precos` (intermediária): uma linha por par PRODUTO/CLUSTER existente nos dados reais. Esta variável é sobrescrita na etapa 6 abaixo. `L24`.
4. **Gerar esqueleto** com o produto cartesiano 18 produtos x 3 tiers x 6 segmentos x 5 regiões = 1.620 combinações, exportado em `esqueleto_tabela_precos.xlsx` e recarregado como `base_clusters`. `L25-26`, `L45-54`.
5. **Classificar cluster do esqueleto**: aplica a função `cluster()` linha a linha combinando PRODUTO, TIER, SEGMENTO e REGIAO, com três regras conforme o grupo do produto (ver seção 4). `L27`, `L56-96`.
6. **Cruzar esqueleto com percentis** via merge **inner** por PRODUTO + CLUSTER. Exclusão: combinações do esqueleto sem par produto/cluster na base de percentis são descartadas, incluindo todo o produto `NA BAIXA POR PAGAMENTO Banco` (CLUSTER = None). O resultado sobrescreve `tabela_precos`. `L28`, `L96`.
7. **Exportar `tabela_precos.xlsx`**: matriz de preços-alvo por produto, tier, segmento, região e cluster com percentis. `L29`.
8. **Recortar as bases de uplift aos campos padrão** (SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, quantidades, receita, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N). Para Arrecadação (base **Diversos**), calcula `QTDE_MENSAL = QTDE_ARRECADADO / 12`. Para Multipag e PIX cria PRODUTO fixo. `L30-33`.
9. **Atribuir MACROPRODUTO** a cada base: `'COBRANCA'`, `'ARRECADACAO'`, `'MULTIPAG'`, `'PIX'`. `L34`.
10. **Padronizar nomes de colunas** para o esquema comum QTDE_MENSAL, QTDE_ANUAL, RECEITA (de-para na seção 4). `L35`.
11. **Empilhar as quatro bases** em `df_total` (granularidade segmento x grupo econômico x produto). `L36`.
12. **Gateway G1 — excluir CD_GRUPO = 0**: mantém somente registros com grupo econômico diferente de 0. `L37`.
13. **Exportar `base_total.xlsx`** com SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, MACROPRODUTO, QTDE_MENSAL, QTDE_ANUAL, RECEITA, TARIFA, percentis, PREÇO_ALVO, UPLIFT e N. `L38`.
14. **Checagem**: soma do campo UPLIFT da base consolidada, exibida no notebook e não persistida. `L39`.

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Deduplicação de percentis | Um percentil por par PRODUTO + CLUSTER; mantém a primeira ocorrência | Percentis: P25, P35, P40, P50, P60, P75, P90 | `05:L20-23` |
| Produto fixo para bases sem coluna PRODUTO | Multipag → `'FORNECEDORES TED'`; PIX → `'PIX PAGAMENTOS'` | 2 constantes | `05:L22-23`, `L32-33` |
| Fonte dos percentis de Arrecadação | Percentis vêm da base **completa** (todos os tipos de documento); uplift vem da base **Diversos** | — | `05:L17`, `L21`, `L31` |
| Esqueleto de combinações | Produto cartesiano PRODUTO x TIER x SEGMENTO x REGIAO | 18 x 3 x 6 x 5 = 1.620 | `05:L25`, `L45-54` |
| Lista de produtos (18) | NA BAIXA POR COMPENSACAO Cliente/Banco, NA BAIXA POR PAGAMENTO Cliente/Banco, NA BAIXA SEM PAGAMENTO Cliente/Banco, QUANDO DO REGISTRO Cliente/Banco, DEBITO DE COBRANCA C/C Cliente/Banco, TR TIT BX DEC PRAZO, TR CONS SDO DEBAUT, POR MOTIVO DE DEVOLUCAO, DECURSO PRAZO > 60 DIAS, FORNECEDORES TED, PIX PAGAMENTOS, CANAIS DIGITAIS, DÉBITO AUTOMÁTICO | 18 itens | `05:L49` |
| Tiers | Tier 1, Tier 2, Tier 3 | 3 | `05:L50` |
| Segmentos | LARGE CORPORATE, ULTRA CORPORATE, INSTITUCIONAL, CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE | 6 | `05:L51` |
| Regiões | S, CO, NNE, SE ex-SP, SP | 5 | `05:L52` |
| Cluster — Grupo 1 (8 produtos: NA BAIXA POR COMPENSACAO Cliente, QUANDO DO REGISTRO Cliente/Banco, NA BAIXA POR PAGAMENTO Cliente, NA BAIXA SEM PAGAMENTO Cliente, TR TIT BX DEC PRAZO, FORNECEDORES TED, PIX PAGAMENTOS) | Tier 1 → 1; Tier 2 → 2; Tier 3 + ULTRA/GLOBAL → 3; Tier 3 + LARGE → 4; Tier 3 + AGRO → 10; Tier 3 + demais (CORPORATE, INSTITUCIONAL) por região: SP → 5, SE ex-SP → 6, S → 7, CO → 8, NNE (else) → 9 | Clusters 1-10 | `05:L60-73` |
| Cluster — Grupo 2 (DEBITO DE COBRANCA C/C Banco e Cliente) | Tier 1 → 1; Tier 2 ou 3 + ULTRA/GLOBAL → 2; + LARGE → 3; + AGRO → 10; demais → 4. Não distingue Tier 2 de Tier 3 nem região | Clusters 1-4, 10 | `05:L75-83` |
| Cluster — Grupo 3 (NA BAIXA POR COMPENSACAO Banco, TR CONS SDO DEBAUT, POR MOTIVO DE DEVOLUCAO, DECURSO PRAZO > 60 DIAS, NA BAIXA SEM PAGAMENTO Banco, CANAIS DIGITAIS, DÉBITO AUTOMÁTICO) | Tier 1 → 1; Tier 2 → 2; Tier 3 + ULTRA/GLOBAL → 3; Tier 3 + LARGE → 4; Tier 3 + AGRO → 10; Tier 3 + demais → 5. Não distingue região | Clusters 1-5, 10 | `05:L85-94` |
| Lacuna de cluster | `NA BAIXA POR PAGAMENTO Banco` não pertence a nenhum grupo; sem `else` final → CLUSTER = None → descartado no merge inner | — | `05:L96` |
| Cruzamento esqueleto x percentis | Merge inner por PRODUTO + CLUSTER; sem correspondência → descarte | — | `05:L28` |
| Quantidade mensal de Arrecadação | `QTDE_MENSAL = QTDE_ARRECADADO / 12` | Divisor 12 | `05:L31` |
| Macroproduto | Cobrança → `COBRANCA`; Arrecadação → `ARRECADACAO`; Multipag → `MULTIPAG`; PIX → `PIX` | De-para 4 itens | `05:L34` |
| De-para de colunas | Cobrança: QT_MENSAL→QTDE_MENSAL, QT_TOTAL→QTDE_ANUAL, VLR_TARIFADO→RECEITA; Multipag: QTDE→QTDE_MENSAL, QTDE_TOTAL→QTDE_ANUAL; PIX: RCTA→RECEITA, QTDE→QTDE_MENSAL, QTDE_TOTAL→QTDE_ANUAL; Arrecadação: QTDE_ARRECADADO→QTDE_ANUAL | — | `05:L35` |
| Exclusão de grupo econômico | `CD_GRUPO = 0` é desconsiderado | 0 | `05:L37` |
| Verificação agregada | Soma de UPLIFT (checagem, não persistida) | — | `05:L39` |

### 5. Parâmetros que deveriam ser parametrizáveis

- **Catálogo de produtos precificáveis** (lista de 18) e seu vínculo com o **macroproduto** (`L34`, `L49`). Hoje é lista fixa no código; a inclusão de um produto exige alteração de código (o caso `NA BAIXA POR PAGAMENTO Banco` mostra o risco).
- **Domínios de tier, segmento e região** (`L50-52`), incluindo a região especial `SE ex-SP`.
- **Tabela de-para produto → grupo de regra de cluster** (Grupo 1/2/3) (`L60`, `L75`, `L85`).
- **Matriz de cluster por grupo**: tier x segmento x região → cluster numérico, incluindo o `else` de região (NNE) e o cluster 10 reservado para AGRO em todos os grupos (`L62-94`).
- **Conjunto de percentis** calculados e exportados (P25, P35, P40, P50, P60, P75, P90) e o subconjunto carregado na base de uplift (P25, P75, P90) (`L20`, `L30`).
- **Constantes de nome de produto** para bases sem coluna PRODUTO (`'FORNECEDORES TED'`, `'PIX PAGAMENTOS'`) (`L22-23`).
- **Fonte dos percentis por produto** (ex.: Arrecadação completa vs. Diversos) (`L17`, `L21`).
- **Divisor de anualização/mensalização** (12) (`L31`).
- **Regra de exclusão de grupo econômico** (`CD_GRUPO = 0`) (`L37`).
- **De-para de nomes de colunas** por base de origem (`L35`), caso as bases de produto continuem gerando layouts distintos.
- **Comportamento do cruzamento** (inner vs. left) e tratamento de combinações sem percentil (descartar vs. manter com marcação) (`L28`).

### 6. Saídas

| Saída | Granularidade | Colunas | Uso posterior |
|---|---|---|---|
| `esqueleto_tabela_precos.xlsx` | 1 linha por combinação (1.620) | PRODUTO, TIER, SEGMENTO, REGIAO | Interno ao fluxo (`L25-26`) |
| `tabela_precos.xlsx` | 1 linha por PRODUTO x TIER x SEGMENTO x REGIAO com cluster e percentil disponível (< 1.620 após o inner) | PRODUTO, TIER, SEGMENTO, REGIAO, CLUSTER, P25, P35, P40, P50, P60, P75, P90 (inferido a partir de `L20` + `L25` + `L28`) | Aba "Tabela de Preços" da Planilha Ano 1 (`07:L22`); (inferido) origem de `preco_alvo_por_cluster.xlsx` (`07:L77`) |
| `base_total.xlsx` | 1 linha por SEGMENTO x CD_GRUPO x PRODUTO (x MACROPRODUTO) | SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, MACROPRODUTO, QTDE_MENSAL, QTDE_ANUAL, RECEITA, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N (`L38`) | Aba "Base Pricing" da Planilha Ano 1 (`07:L23`) |
| Soma de UPLIFT | Escalar | — | Verificação no notebook, não persistida (`L39`) |

Observação sobre `base_total.xlsx`: não carrega TIER nem REGIAO do cliente; a posição do cliente fica codificada apenas no CLUSTER, calculado nos fluxos de produto. TARIFA é o preço efetivamente cobrado hoje **(inferido: corresponde ao "preço praticado")** e PREÇO_ALVO é o preço proposto pelo modelo.

### 7. Conceitos de domínio / glossário

| Termo | Definição conforme o doc |
|---|---|
| Uplift | Resultado de receita incremental calculado por produto nos fluxos individuais e consolidado aqui; existe um valor por registro (segmento x grupo x produto) e é somado como verificação (`L5`, `L38-39`). (inferido) diferença entre receita ao PREÇO_ALVO e receita à TARIFA atual. |
| Tier | Faixa de volume do cliente no produto (Tier 1, 2, 3); calculada nos fluxos de produto e usada como primeira dimensão do cluster (`L50`, `L62-94`). O critério de corte dos tiers não está neste fluxo (ver aba "Tears de Volume" em `07:L65`). |
| Cluster (de precificação) | Código numérico 1 a 10 que resume tier + segmento + região para um produto, definido pela função `cluster()` (`L56-94`). É a chave de ligação entre o esqueleto e os percentis de tarifa. |
| Percentis (P25...P90) | Distribuição da tarifa praticada por produto e cluster, calculada nos fluxos de produto; servem de referência de preço por cluster (`L20`, `L29`). |
| Preço-alvo (PREÇO_ALVO) | Tarifa proposta por cluster, já calculada nos fluxos de produto e consolidada aqui (`L15`, `L38`). A "tabela de preços-alvo" é a matriz de percentis por cluster (`L5`). |
| Tarifa (TARIFA) | Tarifa atual do cliente no produto (`L30-33`). (inferido) = preço praticado. |
| Macroproduto | Família de produto: COBRANCA, ARRECADACAO, MULTIPAG, PIX (`L34`). |
| Produto | Evento tarifado dentro de um macroproduto, ex.: `QUANDO DO REGISTRO Cliente` (`L49`). Sufixo Cliente/Banco distingue quem paga o evento (inferido). |
| Grupo econômico (CD_GRUPO) | Chave de consolidação do cliente; 0 significa sem grupo e é excluído (`L37`). |
| Segmento | Classificação comercial do cliente (LARGE, ULTRA, INSTITUCIONAL, CORPORATE, GLOBAL, AGRO CORPORATE) (`L51`). |
| Região | S, CO, NNE, SE ex-SP, SP (`L52`); só diferencia cluster em Tier 3 de CORPORATE/INSTITUCIONAL no Grupo 1. |
| N | Campo carregado nas bases de uplift (`L30-33`); significado não definido no doc (inferido: contagem de observações/clientes do cluster usada no cálculo do percentil). |
| Esqueleto | Universo completo de combinações possíveis, gerado por produto cartesiano (`L25`). |

### 8. Evidências de capacidades

**C1 — Cálculo/Simulação de preços**
- `05:L5` e `L28-29` — a `tabela_precos.xlsx` é a matriz de preço-alvo de referência por produto/tier/segmento/região/cluster; é o insumo direto de qualquer cálculo de preço sugerido.
- `05:L15-19`, `L38` — PREÇO_ALVO, TARIFA (praticado) e UPLIFT consolidados por cliente/produto: base para comparar preço alvo x praticado.
- `05:L20` — sete percentis por cluster permitem cenários de preço (P25 a P90) (inferido como uso).

**C2 — Onda de Reprecificação**
- `05:L38-39` — UPLIFT por cliente/produto e soma total do uplift: quantificação do potencial de uma onda de reprecificação.
- `05:L111-113` — o doc afirma que o planejamento de reajustes graduais (passo 4) não está neste fluxo; o uplift é um valor único por registro, sem gradação.

**C3 — Gestão de Reciprocidade**
- `05:L50`, `L62-94` — o tier de volume é dimensão primária do cluster e portanto do preço; mudança de volumetria altera tier, cluster e preço-alvo (inferido como consequência).
- `05:L110` — reconhece que o nível de relacionamento (saldo IF) não é tratado neste fluxo.

**Parametrização**
- `05:L25`, `L45-54` — listas fixas de produtos, tiers, segmentos e regiões hard-coded.
- `05:L56-96` — regra de cluster em código, com lacuna (produto sem grupo) que uma tabela parametrizada evitaria.

**Legado / base histórica**
- `05:L15-19` — bases `*_vats.xlsx` geradas pelos fluxos de produto a partir de movimento 12 meses e eventos tarifados atuais (`00-etapas:L9-16`).
- `05:L30-33` — TARIFA por cliente é o preço vigente extraído do legado (inferido).

### 9. Dúvidas, ambiguidades e lacunas

- **Produto sem cluster**: `NA BAIXA POR PAGAMENTO Banco` está no esqueleto mas não em nenhum grupo da função `cluster()`; some da tabela final (`L96`). Falta decidir se é omissão ou intenção.
- **Produtos sem fluxo gerador de percentis**: `CANAIS DIGITAIS` e `DÉBITO AUTOMÁTICO` estão no esqueleto e no Grupo 3, mas nenhum dos cinco arquivos de entrada é declarado como fonte deles. (inferido) Se não existirem na base de Cobrança, são descartados no inner merge.
- **Percentil que vira preço-alvo**: o fluxo não diz qual percentil (P50? P75?) é o PREÇO_ALVO; isso é decidido nos fluxos de produto e não está documentado aqui.
- **Arrecadação Diversos vs. Completa**: os percentis (tabela de preços) usam a base completa e o uplift usa a Diversos (`L17`, `L31`). O negócio não explicita o motivo.
- **INSTITUCIONAL** aparece nas listas de segmento do esqueleto (`L51`) mas é excluído do atacado no fluxo 06 (`06:L33`); há inconsistência entre os dois fluxos.
- **Critério de tier** (cortes de volume) não está no fluxo 05; depende dos fluxos de produto e da aba "Tears de Volume".
- **Janela temporal** das bases de entrada não é declarada em 05; só inferível de `00-etapas`.
- **Significado de N** não é definido.
- **Cluster 10 (AGRO)** é único em todos os grupos, independente de região; não há justificativa documentada.
- **Sobrescrita da variável `tabela_precos`** (`L24`, `L28`) e recarga redundante do esqueleto (`L26`) são artefatos de implementação que o motor não deve reproduzir.
- **Merge inner** descarta silenciosamente combinações sem percentil; o motor precisa de regra explícita de fallback (ex.: cluster vizinho, preço de lista) — não definida.

---

## Fluxo 06 — Matriz de Stickiness vs. Impacto (fonte: `06-matriz-stickiness-impacto-fluxo.md`)

### 1. Objetivo do fluxo

Classificar cada grupo econômico do atacado em dois eixos: **Stickiness** (grau de relacionamento/dependência com o banco, a partir de share de cash e share de crédito) e **Impacto** (relevância financeira, a partir de ROB e receita de cash). Gera também duas bases auxiliares por grupo: saldo médio de Invest Fácil e DAV, e share of wallet (SoW) de boletos. As três bases são insumos de priorização e de diagnóstico de relacionamento para o motor (`06-matriz-stickiness-impacto-fluxo.md:L3-5`, `L125-127`).

### 2. Bases de entrada

| Base | Origem | Janela temporal | Campos-chave | Observações |
|---|---|---|---|---|
| `rob_historico.csv` | Extração SQL/Databricks (`07:L18`); base externa de ROB | Filtro hard-coded `REF >= 202506` ("últimos 6 meses") | REF (AAAAMM), SEGMENTO, CD_GRUPO, DESCRICAO_GDAD_MACRO, RESULTADO | RESULTADO convertido para float (`L15-17`) |
| `cashxcred.csv` (dash Cash vs. Crédito) | Base externa | Filtro hard-coded REF em {2026-03-01, 2026-04-01, 2026-05-01} ("últimos 3 meses") | REF, CNPJCPF, QTDE_CASH_BRAD, QTDE_CASH_CONC, QTDE_CASH_TOTAL | Granularidade CNPJ; agregada a grupo via segmentos (`L23`, `L25-27`) |
| `segmentos_atualizados.csv` | Base externa de segmentação (atual) | Atual (`00-etapas:L7`) | CNPJCPF, SEGMENTO, CD_GRUPO | Deduplicada pelas 3 colunas; reutilizada nas etapas 31 e 36 (`L24`) |
| `SHARE_CREDITO.csv` (latin-1) | Base externa (BACEN/crédito) | Não declarada | cgrp_econm→CD_GRUPO, isgmto_atcdo→SEGMENTO, vtot_mercd_bacen, vperc_ccren, vperc_bdsco | Agregação por grupo prevista mas **comentada**; segue na granularidade original (`L29-30`) |
| `saldo_invest.csv` | Base externa (Invest Fácil) | Sem filtro no código; comentário indica "últimos 3 meses" (`L50`; `00-etapas:L5`) | REF, CNPJCPF, SALDO_INVEST | Lido com `decimal=','` (`L47`) |
| `saldo_dav.csv` | Base externa (DAV) | Idem (`00-etapas:L6`) | REF, CNPJCPF, SALDO_DAV | Idem |
| `share_boletos.csv` | Base externa (SoW de cobrança) | Sem filtro no código; `00-etapas:L8` indica 12 meses | REF, CNPJCPF, QTDE_COB_BRAD, QTDE_COB_CONC, QTDE_COB_TOTAL | Agregada a grupo (`L52-54`) |

### 3. Etapas do fluxo

**Bloco A — Impacto (ROB e receita de cash)**
1. Carregar `rob_historico.csv` e converter RESULTADO para float. `06:L15-16`.
2. **Gateway G1**: manter apenas `REF >= 202506` (últimos 6 meses). `L17`.
3. Somar RESULTADO por SEGMENTO + CD_GRUPO → `RESULTADO_OPERACIONAL` (`ro_L6M`). `L18`.
4. Definir lista de macroprodutos "cash": Arrecadação, Cobrança, Folha de Pagamento, Fornecedores, Tarifas de Conta Corrente, Pix. `L19`.
5. Filtrar ROB onde DESCRICAO_GDAD_MACRO ∈ lista cash e somar por SEGMENTO + CD_GRUPO → `RECEITA_CASH` (`ro_cash_L6M`). `L20-21`.
6. Merge **outer** ROB x receita de cash por SEGMENTO + CD_GRUPO → `base_impacto`. `L22`.

**Bloco B — Stickiness (share de cash e crédito)**
7. Carregar `cashxcred.csv` (REF, CNPJCPF, QTDE_CASH_BRAD/CONC/TOTAL). `L23`.
8. Carregar e deduplicar `segmentos_atualizados.csv` por CNPJCPF + SEGMENTO + CD_GRUPO. `L24`.
9. Merge **left** share de cash x segmentos por CNPJCPF (traz SEGMENTO, CD_GRUPO). `L25`.
10. **Gateway G2**: manter apenas REF em {2026-03-01, 2026-04-01, 2026-05-01}. `L26`.
11. Somar QTDE_CASH_* por SEGMENTO + CD_GRUPO (`share_cash_L3M`). `L27`.
12. Merge **outer** `base_impacto` x `share_cash_L3M` por SEGMENTO + CD_GRUPO. `L28`.
13. Carregar `SHARE_CREDITO.csv` e renomear chaves (cgrp_econm→CD_GRUPO, isgmto_atcdo→SEGMENTO). Agregação por grupo permanece comentada. `L29-30`.
14. Merge **outer** com share de crédito por SEGMENTO + CD_GRUPO. `L31`.
15. Tratar e calcular: `fillna(0)`; `SHARE_CASH = QTDE_CASH_BRAD / QTDE_CASH_TOTAL` (−1 se total = 0); `SALDO_MERCADO = vtot_mercd_bacen × (vperc_ccren / 100)`; `SHARE_CREDITO = vperc_bdsco / 100`. `L32`.
16. **Gateway G3**: manter apenas SEGMENTO ∈ {ULTRA CORPORATE, LARGE CORPORATE, CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE}. `L33`.
17. `SCORE_CREDITO = score_credito(SEGMENTO, SALDO_MERCADO, SHARE_CREDITO)` (regra na seção 4). `L34`, `L62-73`.
18. `SCORE_CASH = score_cash(SHARE_CASH)`. `L35`, `L75-82`.
19. `SCORE_STICKINESS = max(SCORE_CASH, SCORE_CREDITO)`. `L36`, `L84-86`.
20. Classificar STICKINESS por merge left com tabela 1→Baixo, 2→Médio Baixo, 3→Médio Alto, 4→Alto. `L37`, `L88-93`.
21. `SCORE_ROB = score_ROB(SEGMENTO, RESULTADO_OPERACIONAL)`. `L38`, `L95-103`.
22. `SCORE_RECEITA_CASH = score_receita_cash(SEGMENTO, RECEITA_CASH)`. `L39`, `L105-113`.
23. `SCORE_IMPACTO = max(SCORE_ROB, SCORE_RECEITA_CASH)`. `L40`, `L115-117`.
24. Classificar IMPACTO: 1→Baixo, 2→Médio, 3→Alto. `L41`, `L119-123`.
25. Selecionar campos finais e exportar `matriz.xlsx`. `L42-43`.

**Bloco C — Saldo médio Invest Fácil / DAV**
26. Carregar `saldo_invest.csv` e `saldo_dav.csv`; merge **outer** por REF + CNPJCPF; `fillna(0)`. `L44-47`.
27. Merge left com `segmentos_atualizados` por CNPJCPF. `L48`.
28. Somar SALDO_INVEST e SALDO_DAV por REF + SEGMENTO + CD_GRUPO. `L49`.
29. Média de SALDO_INVEST e SALDO_DAV por SEGMENTO + CD_GRUPO entre as referências disponíveis (sem filtro de data explícito). `L50`.
30. Exportar `saldo.xlsx`. `L51`.

**Bloco D — Share of wallet de boletos**
31. Carregar `share_boletos.csv`; merge left com segmentos por CNPJCPF. `L52-53`.
32. Somar QTDE_COB_BRAD/CONC/TOTAL por SEGMENTO + CD_GRUPO. `L54`.
33. `SOW_BOLETOS = QTDE_COB_BRAD / QTDE_COB_TOTAL`; se nulo → texto `'sem cobrança'`. `L55`.
34. Exportar `sow_cobranca.xlsx`. `L56`.

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Janela ROB | `REF >= 202506` (6 meses) | 202506 (hard-coded) | `06:L17` |
| Lista de produtos cash | DESCRICAO_GDAD_MACRO ∈ lista | Arrecadação, Cobrança, Folha de Pagamento, Fornecedores, Tarifas de Conta Corrente, Pix | `06:L19` |
| RESULTADO_OPERACIONAL | Soma de RESULTADO L6M por segmento e grupo | — | `06:L18` |
| RECEITA_CASH | Soma de RESULTADO L6M dos produtos cash | — | `06:L21` |
| Janela share de cash | REF ∈ {2026-03-01, 2026-04-01, 2026-05-01} (3 meses) | Datas hard-coded | `06:L26` |
| SHARE_CASH | `QTDE_CASH_BRAD / QTDE_CASH_TOTAL`; −1 se `QTDE_CASH_TOTAL = 0` | Sentinela −1 | `06:L32` |
| SALDO_MERCADO | `vtot_mercd_bacen × (vperc_ccren / 100)` | — | `06:L32` |
| SHARE_CREDITO | `vperc_bdsco / 100` | — | `06:L32` |
| Segmentos de atacado (G3) | ULTRA CORPORATE, LARGE CORPORATE, CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE | 5 (INSTITUCIONAL fora) | `06:L33` |
| Materialidade de crédito por segmento | Se SALDO_MERCADO < limiar → SCORE_CREDITO = 1 | ULTRA 500.000.000; LARGE 40.000.000; GLOBAL 40.000.000; CORPORATE 2.000.000; AGRO 2.000.000 | `06:L66`, `L73` |
| Score de crédito (com materialidade) | Por SHARE_CREDITO | ≥0,7 → 4; ≥0,4 → 3; ≥0,1 → 2; senão 1 | `06:L67-71` |
| Score de cash | Por SHARE_CASH | ≥0,7 → 4; ≥0,4 → 3; ≥0,1 → 2; senão (inclui −1) 1 | `06:L77-82` |
| Score de stickiness | `max(SCORE_CASH, SCORE_CREDITO)` | 1-4 | `06:L86` |
| Rótulo de stickiness | 1 Baixo; 2 Médio Baixo; 3 Médio Alto; 4 Alto | — | `06:L88-93` |
| Score de ROB | Por segmento e RESULTADO_OPERACIONAL | ULTRA/GLOBAL: ≥12.600.000 → 3, ≥1.380.000 → 2; LARGE: ≥6.300.000 → 3, ≥1.380.000 → 2; CORPORATE/AGRO: ≥525.000 → 3, ≥93.000 → 2; senão 1 | `06:L99-103` |
| Score de receita de cash | Por segmento e RECEITA_CASH | ULTRA/GLOBAL: ≥2.250.000 → 3, ≥300.000 → 2; LARGE: ≥1.500.000 → 3, ≥300.000 → 2; CORPORATE/AGRO: ≥102.000 → 3, ≥9.000 → 2; senão 1 | `06:L109-113` |
| Score de impacto | `max(SCORE_ROB, SCORE_RECEITA_CASH)` | 1-3 | `06:L117` |
| Rótulo de impacto | 1 Baixo; 2 Médio; 3 Alto | — | `06:L119-123` |
| Saldo médio IF/DAV | Média por segmento e grupo das somas mensais | Sem filtro de data no código | `06:L49-50` |
| SOW_BOLETOS | `QTDE_COB_BRAD / QTDE_COB_TOTAL`; nulo → `'sem cobrança'` | Texto sentinela | `06:L55` |
| Tratamento de nulos | `fillna(0)` antes dos cálculos (impacto/stickiness e saldo) | 0 | `06:L32`, `L47` |

### 5. Parâmetros que deveriam ser parametrizáveis

- **Janelas temporais**: 6 meses de ROB (`L17`), 3 meses de share de cash (`L26`), 3 meses de saldo (`L50`), e a janela de SoW de boletos (não declarada). Hoje são datas literais (202506, 2026-03..05) que quebram a cada ciclo.
- **Lista de macroprodutos considerados "cash"** (`L19`).
- **Lista de segmentos de atacado elegíveis** (`L33`), a ser alinhada com a lista do fluxo 05 (`05:L51`).
- **Limiares de materialidade de crédito por segmento** (`L73`).
- **Faixas de score de share** (0,1 / 0,4 / 0,7) para crédito e cash (`L68-71`, `L79-82`).
- **Faixas de score de ROB por segmento** (`L99-103`) e de **receita de cash por segmento** (`L109-113`).
- **Função de combinação dos scores** (hoje `max`) para stickiness e impacto (`L86`, `L117`).
- **Tabelas de rótulos** de stickiness (4 níveis) e impacto (3 níveis) (`L88-93`, `L119-123`).
- **Sentinelas**: −1 para SHARE_CASH sem mercado, texto `'sem cobrança'` para SoW (`L32`, `L55`).
- **Tratamento de nulos** (`fillna(0)`) e política para grupos ausentes em alguma base (merges outer) (`L22`, `L28`, `L31`).
- **Agrupamento de segmentos** nas faixas (ULTRA/GLOBAL juntos, CORPORATE/AGRO juntos) (`L101-103`).

### 6. Saídas

| Saída | Granularidade | Colunas | Uso posterior |
|---|---|---|---|
| `matriz.xlsx` | 1 linha por SEGMENTO x CD_GRUPO (atacado) | CD_GRUPO, SEGMENTO, RESULTADO_OPERACIONAL, RECEITA_CASH, SHARE_CREDITO, SALDO_MERCADO, SHARE_CASH, STICKINESS, IMPACTO (`L42`) | Aba "Stikiness e Impacto" (`07:L25`) |
| `saldo.xlsx` | 1 linha por SEGMENTO x CD_GRUPO | SEGMENTO, CD_GRUPO, SALDO_INVEST (médio), SALDO_DAV (médio) (`L50-51`) | Aba "Saldo" (`07:L26`); (inferido) origem de `saldo_if_por_ge.xlsx` e `saldo_dav_por_ge.xlsx` (`07:L83-84`) |
| `sow_cobranca.xlsx` | 1 linha por SEGMENTO x CD_GRUPO | SEGMENTO, CD_GRUPO, QTDE_COB_BRAD, QTDE_COB_CONC, QTDE_COB_TOTAL, SOW_BOLETOS (`L54-56`) | Aba "SOW Cobrança" (`07:L27`); (inferido) origem de `share_boletos_por_GE.xlsx` (`07:L85`) |

Os campos SCORE_* intermediários não são exportados (`L42`); apenas os rótulos.

### 7. Conceitos de domínio / glossário

| Termo | Definição conforme o doc |
|---|---|
| Stickiness | Nível de relacionamento/dependência do cliente com o Bradesco, medido pelo maior entre score de share de cash e score de share de crédito; rótulos Baixo a Alto (`L5`, `L84-93`). O doc de aderência a chama de "Probabilidade de retenção do cliente" (`L138`). |
| Impacto | Relevância financeira do cliente para o banco, medido pelo maior entre score de ROB e score de receita de cash; rótulos Baixo/Médio/Alto (`L5`, `L115-123`). |
| ROB (RESULTADO_OPERACIONAL) | Resultado operacional bruto do grupo econômico, somado nos últimos 6 meses, por macroproduto (`L15-18`). |
| Receita de cash | Parcela do ROB restrita aos macroprodutos da lista cash (`L19-21`). |
| Share de cash | Participação do Bradesco na quantidade de cash do cliente (`QTDE_CASH_BRAD / QTDE_CASH_TOTAL`) (`L32`). |
| Share de crédito | `vperc_bdsco / 100`: participação do Bradesco no crédito do grupo (`L32`). |
| Saldo de mercado | Volume de crédito do grupo no mercado ponderado por `vperc_ccren` (`L32`); usado como gatilho de materialidade. |
| Materialidade de crédito | Limiar mínimo de SALDO_MERCADO por segmento para que o share de crédito diferencie o relacionamento (`L66`, `L73`). |
| Invest Fácil (IF) | Produto de investimento; seu saldo médio é o insumo de "nível de relacionamento" da política de descontos do business case (`L44`, `L137`). |
| DAV | Saldo em conta corrente (depósito à vista) por cliente e referência (`L45`). |
| SoW de boletos (SOW_BOLETOS) | Share of wallet de cobrança: `QTDE_COB_BRAD / QTDE_COB_TOTAL` (`L55`). |
| Preço de referência do cliente | Conceito do business case: Preço alvo → desconto por saldo de IF → preço de referência (`L137`). O desconto **não** é calculado neste fluxo. |
| Matriz Probabilidade de retenção x Impacto | Matriz do business case usada para planejar reajustes graduais (`05:L111`, `06:L138`). |

### 8. Evidências de capacidades

**C1 — Cálculo/Simulação de preços**
- `06:L137` — o saldo médio de IF é o insumo do desconto sobre o preço-alvo que gera o preço de referência do cliente; o cálculo do desconto está fora deste notebook.

**C2 — Onda de Reprecificação**
- `06:L131`, `L138` — o fluxo evidencia o passo 4 ("Planejar reajustes graduais") via Stickiness como probabilidade de retenção; é o critério de priorização/gradação de uma onda (texto truncado).
- `06:L5` — as três bases são "insumos de priorização" para o motor.

**C3 — Gestão de Reciprocidade**
- `06:L44-51` — saldo médio de Invest Fácil e DAV por grupo: medida de reciprocidade de relacionamento (saldo acordado x realizado, inferido).
- `06:L52-56` — SoW de boletos por grupo: volumetria de cobrança no Bradesco versus concorrência (QTDE_COB_CONC) — base para monitorar volumetria realizada.
- `06:L23-27`, `L32` — share de cash (Bradesco x concorrência) como medida de dependência.

**Parametrização**
- `06:L17`, `L26` — datas literais de janela (202506; 2026-03/04/05).
- `06:L19` — lista fixa de produtos cash.
- `06:L73`, `L99-113` — limiares monetários por segmento em código.
- `06:L68-71`, `L79-82` — faixas 0,1/0,4/0,7.

**Legado / base histórica**
- `06:L15` — `rob_historico.csv` (histórico de ROB por AAAAMM).
- `06:L23`, `L29`, `L44-45`, `L52` — bases externas de share de cash, share de crédito (BACEN), saldos e SoW; todas extraídas via SQL/Databricks (`07:L17`).
- `06:L30`, `L47` — trechos comentados no código (agregação de crédito; conversão decimal) indicam layouts instáveis das bases de origem.

### 9. Dúvidas, ambiguidades e lacunas

- **Arquivo truncado** em `L138`: a evidência do passo 4 e qualquer conteúdo posterior não foram lidos.
- **Como a matriz é usada**: o doc classifica os grupos, mas não define a regra que traduz Stickiness x Impacto em percentual/gradação de reajuste ou em elegibilidade para reprecificação.
- **Desconto por saldo de IF**: o business case prevê "Preço alvo → desconto por saldo de IF → preço de referência" (`L137`), mas a tabela de desconto não está em nenhum dos três fluxos (existe `premissas_desconto.xlsx` em `07:L80`, sem conteúdo documentado).
- **INSTITUCIONAL** é excluído do atacado aqui (`L33`) mas incluído no esqueleto de preços (`05:L51`).
- **Share de crédito sem agregação**: a base segue na granularidade do arquivo de origem (`L30`); se houver mais de uma linha por grupo, o merge outer pode duplicar registros da matriz.
- **`fillna(0)` antes da regra do −1** (`L32`): grupos sem base de cash ficam com QTDE_CASH_TOTAL = 0 → SHARE_CASH = −1 → score 1; grupos sem crédito ficam com SALDO_MERCADO = 0 → score 1. Não está claro se "sem dado" deve ser tratado igual a "baixo relacionamento".
- **Janelas sem filtro**: saldo IF/DAV (`L50`) e SoW de boletos dependem de as extrações já virem recortadas; `00-etapas:L8` diz 12 meses para share de boletos, mas o fluxo não confirma.
- **QTDE_CASH_CONC** e **QTDE_COB_CONC** são carregados e somados mas não entram em nenhuma fórmula.
- **Chave por CNPJ x grupo**: a segmentação deduplica por CNPJ + SEGMENTO + CD_GRUPO, o que ainda permite um CNPJ com dois grupos; não há regra de desempate.
- **`'sem cobrança'` como texto** numa coluna numérica (`L55`) exige tratamento no consumo.
- **Origem do ROB por macroproduto** (`DESCRICAO_GDAD_MACRO`) e sua relação com os macroprodutos do fluxo 05 (COBRANCA, ARRECADACAO, MULTIPAG, PIX) não estão mapeadas (ex.: "Fornecedores" ↔ MULTIPAG é inferido).

---

## Fluxo 07 — Planilha Preço Ano 1 e Calculadora Salesforce (fonte: `07-planilha-ano1-fluxo.md`)

### 1. Objetivo do fluxo

Consolidar em um único workbook (`Preço ano 1.xlsx`) as saídas dos fluxos anteriores (tabela de preços-alvo, base de uplift, emissões L3M, matriz Stickiness x Impacto, saldo IF/DAV, SoW de cobrança), recalcular via macro os resumos "Preço por Produto" e "Resumo por GE" e distribuir o resultado em dois caminhos: ações manuais de reprecificação pela equipe de Precificação e atualização da Calculadora Salesforce via SAS e Servidor SQL 010. É um processo manual/orquestrado, sem script Python (`07-planilha-ano1-fluxo.md:L3-5`, `L11`, `L116-118`).

### 2. Bases de entrada

| Base | Origem | Janela temporal | Campos-chave | Observações |
|---|---|---|---|---|
| Arquivos da pasta `entradas` (arrecadacao.csv, associacoes_religiosas.csv, contratos_dbto.csv, eventos_tarifados.csv, multipag_atualizado.csv, poder_publico.csv, rob_historico.csv, rob_uf.csv, saldo_dav.csv, saldo_invest.csv, segmentos_atualizados.csv, share_boletos.csv, entre outros) | Fluxo "Extração Base de Dados" (SQL/Databricks) | Conforme `00-etapas:L5-18` (3 meses IF/DAV; 12 meses movimento; eventos tarifados atual) | — | Alimentam os 7 scripts Python (`L17-18`) |
| `tabela_precos.xlsx` | Fluxo 05 | — | PRODUTO, TIER, SEGMENTO, REGIAO, CLUSTER, percentis | → aba "Tabela de Preços" (`L22`) |
| `base_total.xlsx` | Fluxo 05 | — | SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, MACROPRODUTO, QTDE_*, RECEITA, TARIFA, percentis, PREÇO_ALVO, UPLIFT, N | → aba "Base Pricing" (`L23`) |
| `df_qtde_L3M.csv` | Fluxo Base Cobrança (01) | Últimos 3 meses (L3M) | Não detalhado no doc (inferido: CD_GRUPO/CNPJ x produto x quantidade emitida) | → aba "Emissões L3M" (`L24`) |
| `matriz.xlsx` | Fluxo 06 | — | CD_GRUPO, SEGMENTO, ..., STICKINESS, IMPACTO | → aba "Stikiness e Impacto" (`L25`) |
| `saldo.xlsx` | Fluxo 06 | — | SEGMENTO, CD_GRUPO, SALDO_INVEST, SALDO_DAV | → aba "Saldo" (`L26`) |
| `sow_cobranca.xlsx` | Fluxo 06 | — | SEGMENTO, CD_GRUPO, QTDE_COB_*, SOW_BOLETOS | → aba "SOW Cobrança" (`L27`) |
| Listas manuais: Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos | Mantidas manualmente | — | Não detalhado | Abas do workbook (`L48-56`) |
| `associacoes_religiosas.csv` | Fluxo "Extração Base de Dados" (etapa B18) | — | Não detalhado | Aba "Associações Religiosas"; deixou de ser manual (`L58-60`) |
| Abas de regra de negócio: Premissas, Tears de Volume | Mantidas no workbook | — | Não detalhado | (`L62-65`) |

### 3. Etapas do fluxo

1. **Extração SQL/Databricks** das bases brutas para a pasta `entradas` (`L17-18`).
2. **Execução sequencial dos 7 scripts Python** (01_Base_cobranca, 02_Uplift_cobranca, 03_Multipag, 04_Pix, 05_Arrecadacao, 06_Uplift_consolidado, 07_Matriz de Stickiness vs Impacto), cada um gerando saídas na pasta `saidas` (`L19-20`).
3. **Cópia manual das saídas para abas** do `Preço ano 1.xlsx`: Tabela de Preços, Base Pricing, Emissões L3M, Stikiness e Impacto, Saldo, SOW Cobrança (`L21-27`).
4. **Preenchimento das demais abas**: listas manuais (Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos), Associações Religiosas (via extração) e abas de regra (Premissas, Tears de Volume) (`L28`, `L44-65`).
5. **Executar macro** do workbook, que recalcula e atualiza as abas "Preço por Produto" e "Resumo por GE" (`L29-31`). A lógica da macro não está documentada.
6. **Bifurcação** em duas saídas (`L32`):
   - **Saída 1**: ações de reprecificação dependentes de intervenção manual da equipe de Precificação; encerra o fluxo (`L33`).
   - **Saída 2**: cópia manual das abas para os arquivos da pasta `calculadora salesforce` (`L34`).
7. **Execução manual de query SAS** que dispara o subprocesso de atualização da Calculadora (`L35-36`).
8. **Importação SAS** dos 11 arquivos Excel da pasta calculadora salesforce (`L37`, `L71-85`).
9. **Programa SAS** grava as tabelas `SIMUL_*_AAAAMM` do mês de referência (`L38`, `L87-98`).
10. **Motor da Calculadora (Servidor SQL 010)** consulta `DCPS_EXP.SIMUL_*_anomes`, processa (contém regra de negócio) e carrega em tabelas de dados próprias que alimentam a Calculadora Salesforce (`L40-42`, `L100-114`).

Filtros/exclusões explícitos: nenhum neste fluxo; as exclusões vêm dos fluxos anteriores. Cadência: mensal para todas as tabelas SIMUL_*, exceto `SIMUL_PRECO_POR_PRODUTO`, atualizada a cada 6 meses (`L112`).

### 4. Regras, fórmulas e thresholds

| Regra | Descrição | Valores/parâmetros | Fonte |
|---|---|---|---|
| Mapeamento arquivo → aba | tabela_precos→Tabela de Preços; base_total→Base Pricing; df_qtde_L3M→Emissões L3M; matriz→Stikiness e Impacto; saldo→Saldo; sow_cobranca→SOW Cobrança | 6 de-para | `07:L22-27` |
| Macro de recálculo | Atualiza "Preço por Produto" e "Resumo por GE" | Lógica não documentada | `07:L29-31` |
| Abas de regra de negócio | "Premissas" e "Tears de Volume" (cortes de tier) | Conteúdo não documentado | `07:L62-65` |
| Arquivos para o SAS | emissoes_lm, tier_por_produto, preco_alvo_por_cluster, preco_por_produto, premissas_alcada, premissas_desconto, premissas_remuneracao, regiao_por_ge, saldo_dav_por_ge, saldo_if_por_ge, share_boletos_por_GE | 11 arquivos | `07:L73-85` |
| Tabelas SIMUL_* | SIMUL_EMISSOES_LM, SIMUL_PRC_ALVO_CLUSTER, SIMUL_REGIAO, SIMUL_SALDO_DAV, SIMUL_SALDO_IF, SIMUL_SHARE_BOLETOS (+ SIMUL_PRECO_POR_PRODUTO nas finais); sufixo `_AAAAMM` | Mês de referência (ex. 202605) | `07:L87-110` |
| Cadência | Mensal, exceto SIMUL_PRECO_POR_PRODUTO (semestral) | 1 mês / 6 meses | `07:L112` |
| Arquitetura de consumo | Salesforce → Motor da Calculadora (SQL 010) → DCPS_EXP.SIMUL_* (SAS); Calculadora não lê o SAS diretamente | — | `07:L114` |

### 5. Parâmetros que deveriam ser parametrizáveis

- **Premissas de alçada** (`premissas_alcada.xlsx`, `L78`): regras de aprovação quando o preço proposto se afasta do sugerido (`00-doc-negocio.md:L22`).
- **Premissas de desconto** (`premissas_desconto.xlsx`, `L79`): (inferido) tabela de desconto por saldo de IF/DAV que leva do preço-alvo ao preço de referência (`06:L137`).
- **Premissas de remuneração** (`premissas_remuneracao.xlsx`, `L80`): conteúdo não documentado.
- **Tiers de volume por produto** (`tier_por_produto.xlsx`, `L76`; aba "Tears de Volume", `L65`): cortes de volumetria que definem Tier 1/2/3.
- **Região por grupo econômico** (`regiao_por_ge.xlsx`, `L82`): de-para GE → região (S, CO, NNE, SE ex-SP, SP).
- **Aba "Premissas"** (`L64`): parâmetros gerais, conteúdo não documentado.
- **Listas de exceção/contexto**: Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos, Associações Religiosas (`L52-60`). (inferido) funcionam como filtros de elegibilidade e exceções de preço.
- **Mês de referência** (`anomes`) das tabelas SIMUL_* (`L89`, `L104-110`).
- **Cadência de atualização** por tabela (mensal vs. semestral) (`L112`).
- **Caminhos de pastas** (`entradas`, `saidas`, `calculadora salesforce`) (`L18`, `L20`, `L37`), a serem substituídos por integração via Databricks.

### 6. Saídas

#### 6.1 Workbook `Preço ano 1.xlsx` — layout por aba

| Aba | Origem | Colunas (conforme fonte; inferidas quando marcado) | Papel |
|---|---|---|---|
| Tabela de Preços | `tabela_precos.xlsx` (fluxo 05) | PRODUTO, TIER, SEGMENTO, REGIAO, CLUSTER, P25, P35, P40, P50, P60, P75, P90 | Matriz de preço-alvo de referência por cluster |
| Base Pricing | `base_total.xlsx` (fluxo 05) | SEGMENTO, CD_GRUPO, PRODUTO, CLUSTER, MACROPRODUTO, QTDE_MENSAL, QTDE_ANUAL, RECEITA, TARIFA, P25, P75, P90, PREÇO_ALVO, UPLIFT, N | Situação atual e alvo por cliente x produto |
| Emissões L3M | `df_qtde_L3M.csv` (fluxo 01) | Não detalhado (inferido: chave de cliente/GE x produto x quantidade dos últimos 3 meses) | Volumetria realizada recente |
| Stikiness e Impacto | `matriz.xlsx` (fluxo 06) | CD_GRUPO, SEGMENTO, RESULTADO_OPERACIONAL, RECEITA_CASH, SHARE_CREDITO, SALDO_MERCADO, SHARE_CASH, STICKINESS, IMPACTO | Priorização/gradação |
| Saldo | `saldo.xlsx` (fluxo 06) | SEGMENTO, CD_GRUPO, SALDO_INVEST, SALDO_DAV | Relacionamento (desconto por IF) |
| SOW Cobrança | `sow_cobranca.xlsx` (fluxo 06) | SEGMENTO, CD_GRUPO, QTDE_COB_BRAD, QTDE_COB_CONC, QTDE_COB_TOTAL, SOW_BOLETOS | Reciprocidade em cobrança |
| Negociações Recentes | Manual | Não detalhado | Exceções/contexto comercial |
| Datas de Reprecificação | Manual | Não detalhado | Controle de ciclos de reprecificação |
| RFPs | Manual | Não detalhado | Preços acordados em concorrência (inferido) |
| Custos | Manual | Não detalhado | Piso de custo (inferido) |
| Nichos | Manual | Não detalhado | Tratamento diferenciado por nicho (inferido) |
| Associações Religiosas | `associacoes_religiosas.csv` (extração) | Não detalhado | Lista de exceção (inferido) |
| Premissas | Regra de negócio | Não detalhado | Parâmetros gerais |
| Tears de Volume | Regra de negócio | Não detalhado | Cortes de tier por produto |
| Preço por Produto | Macro | Não detalhado | Preços consolidados por produto; publicada semestralmente como SIMUL_PRECO_POR_PRODUTO |
| Resumo por GE | Macro | Não detalhado | Resumo por grupo econômico/gerência |

#### 6.2 Arquivos exportados para a Calculadora Salesforce e tabelas SAS

| Arquivo (pasta calculadora salesforce) | Tabela SAS (`SIMUL_*_AAAAMM`) | Tabela final (`DCPS_EXP.`) | Origem provável na planilha (inferido) |
|---|---|---|---|
| emissoes_lm.xlsx | SIMUL_EMISSOES_LM | SIMUL_EMISSOES_LM_anomes | Emissões L3M |
| tier_por_produto.xlsx | (não listada; captura cortada, `L98`) | — | Tears de Volume |
| preco_alvo_por_cluster.xlsx | SIMUL_PRC_ALVO_CLUSTER | SIMUL_PRC_ALVO_CLUSTER_anomes | Tabela de Preços |
| preco_por_produto.xlsx | (não listada) | SIMUL_PRECO_POR_PRODUTO_anomes (semestral) | Preço por Produto |
| premissas_alcada.xlsx | (não listada) | — | Premissas |
| premissas_desconto.xlsx | (não listada) | — | Premissas |
| premissas_remuneracao.xlsx | (não listada) | — | Premissas |
| regiao_por_ge.xlsx | SIMUL_REGIAO | SIMUL_REGIAO_anomes | Resumo por GE / cadastro |
| saldo_dav_por_ge.xlsx | SIMUL_SALDO_DAV | SIMUL_SALDO_DAV_anomes | Saldo |
| saldo_if_por_ge.xlsx | SIMUL_SALDO_IF | SIMUL_SALDO_IF_anomes | Saldo |
| share_boletos_por_GE.xlsx | SIMUL_SHARE_BOLETOS | SIMUL_SHARE_BOLETOS_anomes | SOW Cobrança |

Depois do SAS, o Motor da Calculadora (SQL 010) carrega essas tabelas em base própria que alimenta a Calculadora Salesforce (`L40-42`, `L114`).

#### 6.3 Nome sugerido para a "base final"

Sugestão: **Base de Referência de Preços Cash (BRP Cash)**, versionada por **ciclo de precificação** (`anomes`), com as seguintes entidades internas: Matriz de Preço-Alvo por Cluster, Posição de Preço por Cliente-Produto, Matriz de Relacionamento (Stickiness x Impacto), Indicadores de Reciprocidade (saldo IF/DAV, SoW, emissões L3M) e Premissas (tiers, alçada, desconto, remuneração, exceções).

Justificativa:
- "Ano 1" é um marco do business case (primeiro ano de reprecificação) e perde sentido nos ciclos seguintes; o nome atual não indica versão nem vigência, enquanto o SAS já versiona por `anomes` (`L89`).
- "Planilha" descreve o meio (Excel com macro) e não o conteúdo; o motor consumirá uma base publicada no Databricks, não um arquivo (`00-doc-negocio.md:L27`, `L30`).
- "Referência" reflete o papel de fonte de verdade consultada pelas APIs de preço-alvo/sugerido (`00-doc-negocio.md:L7`), sem confundir com o preço vigente, que continua no legado (`L11-12`).
- Alternativa mais curta, se o negócio preferir: **Tabela de Preços de Referência (TPR)** para a matriz por cluster, e **Base de Precificação Cash** para o conjunto.

### 7. Conceitos de domínio / glossário

| Termo | Definição conforme o doc |
|---|---|
| Planilha Preço Ano 1 | Workbook que consolida todas as saídas dos fluxos e serve à equipe de Precificação e à Calculadora Salesforce (`L5`). |
| Calculadora Salesforce | Ferramenta comercial no Salesforce que consulta preço/cluster/saldo/share via Motor da Calculadora (`L40-42`). |
| Motor da Calculadora | Componente no Servidor SQL 010 que consulta as tabelas DCPS_EXP.SIMUL_* e contém regra de negócio (`L41`, `L114`). |
| SIMUL_* | Tabelas SAS de simulação, uma por insumo e por mês de referência (`L87-110`). |
| Emissões L3M | Quantidades emitidas nos últimos 3 meses, geradas pelo fluxo Base Cobrança (`L24`). |
| Preço por Produto | Aba recalculada pela macro com preços consolidados por produto; cadência semestral no SAS (`L30`, `L112`). (inferido) corresponde ao preço sugerido/lista por produto. |
| Resumo por GE | Aba recalculada pela macro com resumo por grupo econômico/gerência (`L31`). |
| Onda | Ciclo de reprecificação; a pasta do modelo é `03_modelo_onda_4` (`L18`), indicando que o processo está na quarta onda. |
| Alçada | Nível de aprovação para preço fora do sugerido (`premissas_alcada.xlsx`, `L78`; `00-doc-negocio.md:L22`). |
| RFP | Lista manual de propostas/concorrências com preços acordados (`L54`); conteúdo não detalhado. |
| Nichos / Associações Religiosas / Poder Público | Listas de segmentos especiais tratadas à parte (`L56`, `L60`; `poder_publico.csv` em `L18`). |

### 8. Evidências de capacidades

**C1 — Cálculo/Simulação de preços**
- `07:L5`, `L40-42` — a Calculadora Salesforce simula preços para a equipe comercial a partir de preço-alvo por cluster, saldo e share.
- `07:L77-80` — `preco_alvo_por_cluster`, `preco_por_produto`, `premissas_alcada`, `premissas_desconto`: insumos de cálculo do preço sugerido, do desconto e da alçada.
- `07:L41`, `L114` — o Motor da Calculadora "contém regra de negócio" (cálculo do preço final), hoje fora do modelo Python.
- `00-doc-negocio.md:L22` — alçada acionada quando o preço simulado difere do sugerido.

**C2 — Onda de Reprecificação**
- `07:L33` — Saída 1: ações de reprecificação decididas manualmente pela equipe de Precificação.
- `07:L53` — aba "Datas de Reprecificação": controle das datas em que cada cliente foi/será reprecificado.
- `07:L18` — `03_modelo_onda_4`: o processo é executado por ondas.
- `07:L112` — cadência semestral do preço por produto versus mensal dos demais insumos.

**C3 — Gestão de Reciprocidade**
- `07:L24`, `L75` — Emissões L3M enviadas à Calculadora: volumetria realizada recente.
- `07:L65`, `L76` — Tears de Volume / tier_por_produto: faixas de volume acordadas versus realizadas (inferido).
- `07:L83-85` — saldo DAV, saldo IF e share de boletos por GE: indicadores de reciprocidade consultados na simulação.
- `07:L52` — Negociações Recentes: (inferido) impede reprecificar quem acabou de negociar.

**Parametrização**
- `07:L62-65` — abas Premissas e Tears de Volume como regra de negócio em planilha.
- `07:L78-80` — premissas de alçada, desconto e remuneração como arquivos separados.
- `07:L48-60` — listas manuais de exceção.

**Legado / base histórica**
- `07:L17-18` — extração SQL/Databricks de todas as bases brutas.
- `07:L37-42`, `L100-114` — cadeia SAS → SQL 010 → Salesforce como legado de distribuição.
- `07:L112` — versionamento mensal por `anomes` das tabelas SIMUL_* (histórico implícito).
- `00-doc-negocio.md:L11-12`, `L29` — preço vigente e histórico de 12 meses devem vir do legado via Databricks.

### 9. Dúvidas, ambiguidades e lacunas

- **Lógica da macro** ("Preço por Produto", "Resumo por GE") não está documentada; é onde o preço sugerido por produto provavelmente é derivado (inferido).
- **Regra de negócio do Motor da Calculadora (SQL 010)** não está documentada; é o cálculo efetivo do preço simulado para o comercial.
- **Conteúdo de premissas_alcada, premissas_desconto, premissas_remuneracao, tier_por_produto, regiao_por_ge** não está descrito: colunas, faixas e valores desconhecidos.
- **Preço sugerido e preço praticado** não aparecem nomeados em nenhuma saída; a leitura é: praticado = TARIFA (Base Pricing), alvo = PREÇO_ALVO/percentil por cluster, sugerido = resultado da macro/Calculadora após desconto e premissas (inferido).
- **Layout de `df_qtde_L3M.csv`** (Emissões L3M) não está descrito.
- **Origem de `regiao_por_ge.xlsx`**: nenhum fluxo analisado gera região por GE; (inferido) vem de `rob_uf.csv` ou cadastro.
- **Tabelas SIMUL_* incompletas**: a captura está cortada (`L98`); tier_por_produto, premissas_* não têm tabela SAS listada.
- **Semestral vs. mensal**: não está claro quem decide quando o preço por produto muda nem como conviver com a matriz mensal de cluster.
- **Critérios de elegibilidade para reprecificação** (Saída 1) não estão formalizados: o papel de Negociações Recentes, RFPs, Nichos, Associações Religiosas e Datas de Reprecificação é inferido.
- **Sem versionamento/auditoria** da planilha: as premissas de `00-doc-negocio.md:L13-14` (versionamento, logs) não têm contrapartida no AS IS.
- **Abas manuais** são pontos de risco operacional e de inconsistência entre ciclos.

---

## Síntese transversal

### Encadeamento end-to-end

1. **Extração (Databricks/SQL)** gera as bases brutas: movimento e eventos tarifados por produto (12 meses / atual), segmentos, ROB histórico, saldos IF/DAV (3 meses), share de cash/crédito/boletos, listas especiais (`07:L17-18`, `00-etapas:L5-18`).
2. **Fluxos de produto (01-05 Python)** calculam por cliente x produto: tier, cluster, percentis de tarifa, PREÇO_ALVO, UPLIFT e geram as bases `*_vats.xlsx` e `df_qtde_L3M.csv` (`05:L15-19`, `07:L19`).
3. **Fluxo 05 (Uplift Consolidado)** unifica os quatro produtos em `base_total.xlsx` e constrói a matriz de referência `tabela_precos.xlsx` (esqueleto x cluster x percentis).
4. **Fluxo 06 (Stickiness x Impacto)**, em paralelo, classifica os grupos econômicos (`matriz.xlsx`) e calcula saldo médio IF/DAV (`saldo.xlsx`) e SoW de boletos (`sow_cobranca.xlsx`).
5. **Fluxo 07 (Planilha Ano 1)** cola tudo em abas, adiciona listas manuais e premissas, roda a macro (Preço por Produto, Resumo por GE) e bifurca: reprecificação manual (Saída 1) e publicação para a Calculadora Salesforce via SAS e SQL 010 (Saída 2).

Os passos 1 e 2 da metodologia (clusterizar, propor tarifa por cluster) estão nos fluxos 01-05; o passo 3 (relacionamento via saldo IF) e o passo 4 (reajustes graduais via Stickiness x Impacto) têm os **insumos** no fluxo 06, mas a **aplicação** (desconto e gradação) fica na macro, nas premissas e no Motor da Calculadora, sem documentação (`05:L102-113`, `06:L129-138`, `07:L120-122`).

### Diagrama do pipeline

```mermaid
flowchart LR
  subgraph EXT["Extração SQL / Databricks"]
    E1[Movimento e eventos tarifados<br/>Cobrança, Arrecadação, Multipag, PIX, TED]
    E2[segmentos_atualizados]
    E3[rob_historico]
    E4[saldo_invest / saldo_dav]
    E5[cashxcred / SHARE_CREDITO / share_boletos]
    E6[associacoes_religiosas, poder_publico, rob_uf ...]
  end

  subgraph PROD["Fluxos de produto 01-05"]
    P1[01 Base Cobrança<br/>df_qtde_L3M]
    P2[02 Uplift Cobrança<br/>COBRANCA_vats]
    P3[03 Multipag<br/>MULTIPAG_vats]
    P4[04 PIX<br/>PIX_vats]
    P5[05 Arrecadação<br/>ARRECADACAO_vats + COMPLETA_vats]
  end

  subgraph F05["Fluxo 05 Uplift Consolidado"]
    U1[Percentis por produto x cluster]
    U2[Esqueleto 18x3x6x5 + cluster()]
    U3[(tabela_precos.xlsx)]
    U4[(base_total.xlsx)]
  end

  subgraph F06["Fluxo 06 Stickiness x Impacto"]
    S1[(matriz.xlsx)]
    S2[(saldo.xlsx)]
    S3[(sow_cobranca.xlsx)]
  end

  subgraph F07["Fluxo 07 Planilha Ano 1"]
    W1[Abas: Tabela de Preços, Base Pricing,<br/>Emissões L3M, Stikiness e Impacto,<br/>Saldo, SOW Cobrança]
    W2[Abas manuais + Premissas + Tears de Volume]
    W3[Macro: Preço por Produto / Resumo por GE]
    O1[Saída 1: reprecificação manual]
    O2[Saída 2: pasta calculadora salesforce]
  end

  subgraph DIST["Distribuição"]
    D1[SAS: SIMUL_*_anomes]
    D2[Motor da Calculadora SQL 010]
    D3[Calculadora Salesforce]
  end

  E1 --> P1 & P2 & P3 & P4 & P5
  E2 --> P2 & P3 & P4 & P5 & F06
  E3 & E4 & E5 --> F06
  P2 & P3 & P4 & P5 --> U1 --> U3
  U2 --> U3
  P2 & P3 & P4 & P5 --> U4
  U3 & U4 & P1 & S1 & S2 & S3 --> W1
  E6 --> W2
  W1 & W2 --> W3 --> O1 & O2
  O2 --> D1 --> D2 --> D3
```

### Lista consolidada de parâmetros

| Grupo | Parâmetro | Fonte |
|---|---|---|
| Catálogo | Lista de produtos (18) e vínculo com macroproduto | `05:L34`, `L49` |
| Catálogo | Constantes de produto para bases sem PRODUTO (FORNECEDORES TED, PIX PAGAMENTOS) | `05:L22-23` |
| Domínios | Tiers (3), segmentos (6), regiões (5) | `05:L50-52` |
| Domínios | Segmentos de atacado elegíveis (5, sem INSTITUCIONAL) | `06:L33` |
| Cluster | De-para produto → grupo de regra (1/2/3) | `05:L60`, `L75`, `L85` |
| Cluster | Matriz tier x segmento x região → cluster (1-10) por grupo | `05:L62-94` |
| Cluster | Fallback para combinações sem cluster/percentil | `05:L28`, `L96` (lacuna) |
| Tier | Cortes de volume por produto (Tears de Volume / tier_por_produto) | `07:L65`, `L76` |
| Preço | Conjunto de percentis (P25..P90) e percentil que define o preço-alvo | `05:L20`, lacuna |
| Preço | Fonte de percentis por produto (ex.: Arrecadação completa vs Diversos) | `05:L17`, `L21` |
| Preço | Premissas de desconto (por saldo IF/DAV), alçada e remuneração | `07:L78-80`, `06:L137` |
| Volumetria | Divisor de mensalização (12) | `05:L31` |
| Exclusões | CD_GRUPO = 0 | `05:L37` |
| Janelas | ROB 6 meses; share de cash 3 meses; saldo IF/DAV 3 meses; boletos 12 meses; movimento 12 meses; Emissões L3M 3 meses | `06:L17`, `L26`, `L50`; `00-etapas:L5-16` |
| Relacionamento | Lista de macroprodutos cash | `06:L19` |
| Relacionamento | Limiares de materialidade de crédito por segmento | `06:L73` |
| Relacionamento | Faixas de score de share (0,1 / 0,4 / 0,7) | `06:L68-71`, `L79-82` |
| Relacionamento | Faixas de ROB e receita de cash por segmento | `06:L99-113` |
| Relacionamento | Função de combinação (max) e rótulos de stickiness (4) e impacto (3) | `06:L86-93`, `L117-123` |
| Relacionamento | Sentinelas (−1, 'sem cobrança') e tratamento de nulos | `06:L32`, `L55` |
| Exceções | Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos, Associações Religiosas | `07:L52-60` |
| Publicação | Mês de referência (anomes) e cadência por tabela (mensal/semestral) | `07:L89`, `L112` |

### Entidades de dados candidatas para a base final (BRP Cash)

| Entidade | Chave | Atributos principais | Origem |
|---|---|---|---|
| **Produto** | cod_produto | nome_produto, macroproduto, grupo_regra_cluster, quem_paga (Cliente/Banco), ativo | `05:L34`, `L49`, `L60-85` |
| **Segmento** | cod_segmento | nome, elegivel_atacado, agrupamento_faixas (ULTRA/GLOBAL, LARGE, CORPORATE/AGRO) | `05:L51`, `06:L33`, `L101` |
| **Região** | cod_regiao | nome (S, CO, NNE, SE ex-SP, SP) | `05:L52` |
| **Tier de Volume** | produto, tier | limite_inferior, limite_superior, unidade, vigência | `05:L50`, `07:L65`, `L76` |
| **Regra de Cluster** | grupo_regra, tier, segmento, região | cluster, vigência | `05:L62-94` |
| **Matriz de Preço-Alvo por Cluster** (hoje `tabela_precos`) | ciclo, produto, tier, segmento, região | cluster, P25, P35, P40, P50, P60, P75, P90, preco_alvo (percentil escolhido), vigência | `05:L28-29` |
| **Preço por Produto** (hoje aba/SIMUL_PRECO_POR_PRODUTO) | ciclo_semestral, produto | preco_sugerido/lista (inferido), vigência | `07:L30`, `L112` |
| **Posição de Preço Cliente-Produto** (hoje `base_total`) | ciclo, cd_grupo, segmento, produto | cluster, macroproduto, qtde_mensal, qtde_anual, receita, tarifa_praticada, P25, P75, P90, preco_alvo, uplift, n | `05:L38` |
| **Grupo Econômico** | cd_grupo | segmento, região (regiao_por_ge), lista de CNPJs | `06:L24`, `07:L82` |
| **Matriz de Relacionamento** (hoje `matriz`) | ciclo, cd_grupo, segmento | resultado_operacional, receita_cash, share_credito, saldo_mercado, share_cash, score_credito, score_cash, score_rob, score_receita_cash, stickiness, impacto | `06:L42` (scores inferidos como úteis para auditoria) |
| **Indicadores de Reciprocidade** (hoje `saldo`, `sow_cobranca`, Emissões L3M) | ciclo, cd_grupo, segmento (+ produto para emissões) | saldo_invest_medio, saldo_dav_medio, qtde_cob_brad, qtde_cob_conc, qtde_cob_total, sow_boletos, emissoes_l3m | `06:L50-56`, `07:L24` |
| **Premissas** | tipo (alçada, desconto, remuneração, geral), chave | faixas/valores, vigência, versão, responsável | `07:L64`, `L78-80`; `00-doc-negocio.md:L13-14` |
| **Exceções e Contexto Comercial** | tipo (negociação recente, data de reprecificação, RFP, custo, nicho, associação religiosa, poder público), cd_grupo/CNPJ | data, valor/observação, vigência | `07:L52-60`, `L18` |
| **Ciclo de Precificação** | anomes / onda | data_publicacao, versão dos parâmetros, status (staging/produção) | `07:L18`, `L89`, `L112`; `00-doc-negocio.md:L17`, `L42` |
| **Preço Vigente e Histórico** (legado, consultado e não gerado) | cd_grupo/CNPJ, produto, data | tarifa_vigente, histórico 12 meses | `00-doc-negocio.md:L11-12`, `L29` |
