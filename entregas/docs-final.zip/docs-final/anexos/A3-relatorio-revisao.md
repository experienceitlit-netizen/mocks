# A3 — Relatório da revisão de consistência (docs 00 a 09)

Data: 2026-09-18. Fonte de verdade: `A0-brief-decisoes.md`. Escopo: consistência, nomenclatura, IDs, referências cruzadas e erros objetivos. Nenhuma decisão ou conteúdo substantivo foi alterado; a pasta `fotos/` não foi aberta.

## 1. O que foi verificado

| Item | Resultado |
|---|---|
| Nomes canônicos (brief §1): "Motor de Precificação Cash", "Base de Referência de Preços Cash (BRP Cash)" | Docs 01-09 já usam o nome e a sigla canônicos; nenhuma ocorrência de "BRP-Cash" ou "Base de Referência de Precificação" nos docs finais. Única ocorrência de "BRP-Cash" está no título de seção do anexo `A2` (fora do escopo desta revisão; não alterado). |
| Componentes canônicos (`svc-*`, `dbx-*`, `sql-motor`, `sb-eventos`, `sf-*`, `apigw-axway`, `appgw-azure`) | Grafia idêntica em todos os docs; sem variantes. |
| IDs C1..C3, C1.1-C1.6, C2.1-C2.5, C3.1-C3.4, M1-M4, AD-01..AD-14, RF-01..RF-13, RNF-01..RNF-10, F0-F5, R1-R10 | Mesmo significado em todos os docs (RF-06 = staging/publicação agendada; AD-09 = mensageria; RNF-08 = implantação gradual etc.). |
| Ambiguidade marco M1-M7 x módulo M1-M4 | Só o doc 09 mistura os dois; corrigido (ver §2). |
| Definições de preço (brief §2) | Praticado/alvo/sugerido/negociado idênticos nos docs 01-08; alvo = max(tarifa atual, P75); alçada quando negociado < sugerido. Doc 06 §5.2 tinha fórmula de uplift sem o limiar 1.000; corrigida. |
| Fases e datas (doc 09 como referência de datas; brief §9 para escopo) | Datas dos marcos e das fases consistentes entre 09, README e brief. Divergências de escopo por fase listadas em §3. |
| C2 e C3 marcados como evolução | Presentes nos títulos/seções de todos os docs (01-09) e tracejados nos diagramas. |
| Referências cruzadas entre docs | Todas apontam para seções existentes, exceto o cabeçalho do doc 06 (numeração errada dos docs relacionados), corrigido. Referências `doc 06 §5.1/§5.2/§5.3/§5.4/§7/§10`, `doc 07 §4.2`, `03 §6.4` conferidas. |
| Legenda de referências curtas (`01:L112`, `00-neg:L7`, `00-etapas:L1`) | Docs 02 e 04 já tinham; adicionada nos docs 01, 03, 05, 06, 07, 08 e 09. |
| README | Descrições dos docs 01-09 corretas; adicionada a linha do anexo A3. |
| Números | 18 produtos, 3 tiers, 6 segmentos, 5 regiões, 1.620 combinações, 34 famílias, 7 notebooks, N < 15, limiar 1.000, faixas 0,1/0,4/0,7: consistentes. Contagens internas (55 SPECs no doc 08; 21 componentes no doc 07; 150 pessoas x mês no doc 09) recalculadas e corretas. |
| Tabelas/endpoints (padrão doc 06) | Endpoints do doc 03 e do doc 05 alinhados a `/mpc/v1/precos/simulacoes` e `/precos/{grupo}/{produto}/referencia`. Nomes de eventos e de datasets do doc 05 (nível de domínio) mapeados para os nomes de implementação dos docs 06-08 por nota. `stg.*`/`v_brp_ativa_*` (doc 08) mapeados para `stg_*`/`v_brp_ativa` (docs 06-07) por nota. |
| Mermaid | Não alterado, exceto texto de mensagens em diagramas de sequência (docs 03, 05, 06), sem mudança de sintaxe. |

## 2. Correções por documento

- **00-README.md**: adicionada linha do anexo `A3-relatorio-revisao.md` na tabela de anexos.
- **01-contexto-negocio-introdutorio.md**: adicionada nota de convenção de referências curtas (`NN:L<linha>`, `anexos/A0-A2`).
- **02-contexto-negocio-especialista.md**: sem alterações (já tinha convenção; IDs e definições corretos).
- **03-desenho-conceitual.md**: convenção ampliada para abreviações `NN:L`, `00-etapas:L`, `A1`, `A2`; diagrama de sequência §4.3: `POST /simulacoes` corrigido para `POST /mpc/v1/precos/simulacoes`.
- **04-capacidades-rastreabilidade.md**: sem alterações (convenção presente; referência a `03 §6.4` válida).
- **05-dominios-bounded-contexts-context-mapping.md**: adicionada convenção de referências; endpoints `/precos/consulta` e `/precos/simulacao` corrigidos para os do doc 06 §7 (§5 tabela e §6.1 diagrama); adicionada nota em §7 mapeando nomes de domínio (`VersaoBRPAtivada`, `PedidoDeAprovacaoAberto`, `PrecoReprovado`, `AcordoReciprocidadeRegistrado`, datasets `mpa`/`ppc`) aos nomes de implementação dos docs 06-08.
- **06-arquitetura-solucao.md**: cabeçalho "Documentos relacionados" corrigido (antes listava "02 Desenho conceitual; 03 DDD"); convenção de referências e legenda D1-D7/P1-P10 adicionadas; §5.2 diagrama: `/v1/precos/simulacoes` → `/mpc/v1/precos/simulacoes`; §5.2 passo 6: fórmula de uplift por cenário passa a incluir o limiar 1.000, como nos docs 03 e 08.
- **07-componentes-definicao-justificativa.md**: adicionada legenda explicando "lacuna n", D1-D7, P1-P10, R1-R10 e `NN:L`; matriz §10: alertas de C3 na `sf-calculadora` movidos de F4 para F3 (brief §9 e doc 09 colocam alertas ao gerente na F3).
- **08-especificacoes-tecnicas.md**: §0.1 ganhou linha de convenção de referências (incluindo distinção entre dores D1-D7 do doc 06 e dúvidas D1-D15 do próprio doc) e nota sobre `stg.*` = `stg_*` e `v_brp_ativa_*` = `v_brp_ativa`.
- **09-roadmap-implementacao.md**: todas as menções ambíguas a M1-M7 passaram a "marco Mn" e as de M1-M4 do brief a "módulo Mn" (§1, §3 F0/F1/F2/F3/F4, §4, §5, §6, §8); linha de marcos do §1 agora traz as datas exatas do Gantt; adicionada convenção de referências (`A0 §n`, `A2 Fluxo 07 §n`, `L<linha>`, lacunas, riscos).

## 3. Divergências substantivas pendentes (exigem decisão humana; não alteradas)

1. **Corte do primeiro produto: F1 ou F2.** Doc 09 coloca o corte do primeiro produto no marco M4 (fim da F1, 31/03/2027) e o DoD da F1 exige "pelo menos um produto cortado". Brief §9 (F1 = shadow + piloto; F2 = desligamento por produto), doc 06 §5.4, doc 07 (sf-calculadora "F2 corte por produto") e doc 08 (SPEC-TRN-03 na F2) colocam todo corte na F2.
2. **Ordem de corte por produto.** Doc 06 §5.4 e doc 08 SPEC-TRN-03: Multipag, PIX, Arrecadação, Cobrança. Doc 09 §4: Multipag, PIX, Cobrança, Arrecadação (Arrecadação por último, por causa da lacuna 5), com justificativa própria.
3. **Estratégia online do Adaptador de Legado.** Docs 07 e 08 (SPEC-LEG-02) prevêem o conector online na F2 "se decidido"; doc 09 F5 prevê "estratégia (b) se a latência exigir". Brief §9 não fixa a fase.
4. **Telas básicas de parametrização na F1.** Docs 07 (sf-parametrizacao "F1 versionamento básico e ativação de BRP") e 08 (SPEC-SF-04 F1/F2) iniciam a LWC na F1; brief §9 e doc 09 listam `sf-parametrizacao` apenas na F2 (F1 só `svc-parametros` via API).
5. **Preço por Produto (semestral): entidade da BRP Cash ou parâmetro.** Docs 03 §9.2, 05 §4.4 e 09 §5 tratam como dataset/publicação da BRP Cash; docs 06 §5.1 e 08 (PAR-02 `parametro_item_sugerido` PRECO_POR_PRODUTO) tratam como versão de parâmetro. Depende da lacuna 1.
6. **Política "nunca reduzir" aplicada ao sugerido.** Doc 05 (invariante I2, glossário) e doc 08 (ajuste `PisoNuncaReduzir`, marcado inferido) estendem a política ao preço sugerido; o brief §2 só a define para o alvo. Manter como hipótese a validar (lacuna 3).
7. **Anexo A2** usa "BRP-Cash" no título da seção "Entidades de dados candidatas"; padronizar para "BRP Cash" se o anexo for editado.
