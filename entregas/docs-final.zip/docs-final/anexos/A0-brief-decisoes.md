# A0 — Brief mestre de decisões (fonte única para todos os documentos)

Data: 2026-09-18. Este brief consolida a análise dos anexos A1 (fluxos de produto) e A2 (fluxos de consolidação) e fixa nomes, definições, decisões e identificadores que TODOS os documentos finais devem usar de forma idêntica. Quando um documento precisar de detalhe de regra, consultar A1/A2 (que têm referência de linha aos docs fonte em `docs-precificacao/`).

---

## 1. Nomes canônicos

| Conceito | Nome canônico | Sigla | Observação |
|---|---|---|---|
| A solução como um todo | **Motor de Precificação Cash** | MPC | Substitui "Calculadora" como nome do produto de TI; a Calculadora Salesforce passa a ser um *canal* do motor. |
| Base final consumida pelo motor (hoje "Planilha Ano 1") | **Base de Referência de Preços Cash** | BRP Cash | Versionada por **ciclo de precificação** (`anomes`). "Ano 1" é marco do business case; "Planilha" descreve o meio. Ver A2 §6.3. |
| Matriz preço-alvo por produto x tier x segmento x região x cluster (hoje `tabela_precos`) | **Matriz de Preço-Alvo por Cluster** | MPA | Entidade da BRP Cash. |
| Posição atual e alvo por cliente x produto (hoje `base_total`) | **Posição de Preço Cliente-Produto** | PPC | Entidade da BRP Cash. |
| Classificação stickiness x impacto (hoje `matriz.xlsx`) | **Matriz de Relacionamento** | — | Entidade da BRP Cash. |
| Saldos IF/DAV, SoW boletos, emissões L3M | **Indicadores de Reciprocidade** | — | Entidade da BRP Cash. |
| Pipeline analítico que gera a BRP Cash | **Pipeline de Preparação de Preços** | PPP | Roda no Databricks. |
| Camada de acesso ao legado (preço vigente, histórico, tarifas contratadas) | **Adaptador de Legado** | — | Anti-corruption layer. |
| Ciclo mensal/semestral de publicação | **Ciclo de Precificação** | — | Chave `anomes`; substitui "onda" quando falamos de publicação de dados. "Onda" fica reservado para C2. |
| Ciclo de reprecificação de clientes | **Onda de Reprecificação** | — | Capacidade C2. |

Segmento em escopo: **Atacado** (ULTRA CORPORATE, LARGE CORPORATE, CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE; INSTITUCIONAL aparece em alguns fluxos e está em aberto). Produtos de Payments: contas a receber (Cobrança, Arrecadação, PIX recebimento quando aplicável) e contas a pagar (Multipag/Fornecedores TED, PIX Pagamentos). Macroprodutos: COBRANCA, ARRECADACAO, MULTIPAG, PIX.

## 2. Definições de trabalho dos três preços (a validar com o negócio — os docs fonte não nomeiam "sugerido")

| Preço | Definição de trabalho | Origem no AS-IS | Quem calcula no TO-BE |
|---|---|---|---|
| **Preço praticado (vigente)** | Tarifa efetivamente cobrada hoje do cliente no produto. | `TARIFA` na Base Pricing (média/última tarifa observada, ou tarifa de contrato em Multipag); no motor deve vir do **legado** (`00-doc-negocio.md:L11`). | Legado via Adaptador; BRP Cash traz a foto do ciclo. |
| **Preço alvo** | Preço de referência do cluster do cliente: **max(tarifa atual, P75 do cluster)** — política "nunca reduzir". Depende de produto, tier de volume, segmento e região. | `PREÇO_ALVO` (fluxos 01-05) e percentis da MPA. | Pipeline (Databricks); motor consulta. |
| **Preço sugerido** | Preço que o motor recomenda para aquele cliente: preço alvo ajustado por relacionamento (desconto por saldo Invest Fácil/DAV — `premissas_desconto`), premissas (custos, RFP, nichos, exceções) e gradação (Stickiness x Impacto). É o piso de negociação sem alçada. | Macro "Preço por Produto" + Motor da Calculadora no SQL 010 (regras não documentadas). | Motor (Java) em tempo real, com parâmetros versionados. |
| **Preço negociado / simulado** | Valor informado pelo gerente na simulação. | Calculadora Salesforce. | Canal. |

Regra de alçada (definição de trabalho): se preço negociado < preço sugerido, o motor calcula o desvio (% e R$ de uplift perdido) e devolve o **nível de alçada** e o **papel aprovador** conforme `premissas_alcada` (conteúdo não documentado → parametrizável por produto/segmento/faixa de desvio). Se preço negociado ≥ sugerido: contratação sem alçada.

**Cenários** que o motor deve expor: (a) preços por percentil do cluster (P25…P90) como faixas de negociação; (b) sensibilidade a tier (o que acontece se a volumetria mudar de faixa); (c) efeito do relacionamento (com/sem desconto por saldo); (d) receita/uplift anual estimado por cenário.

## 3. Capacidades (usar exatamente estes IDs)

| ID | Capacidade | Status | Sub-capacidades |
|---|---|---|---|
| **C1** | Cálculo, Simulação e Entrega de Preços | **Prioritária — funciona hoje** (Calculadora Salesforce + SAS + SQL 010 + Planilha). | C1.1 Consulta de preço alvo/sugerido/praticado; C1.2 Simulação e cenários (percentis, tier, relacionamento); C1.3 Cálculo de alçada e indicação do aprovador; C1.4 Consulta de preço vigente e histórico 12 meses (legado); C1.5 APIs para canais (Salesforce e outros); C1.6 Rastreabilidade das execuções. |
| **C2** | Onda de Reprecificação | **Evolução — pouco detalhada pelo negócio.** Destacar como "fase futura / a detalhar". | C2.1 Planejamento da onda (escopo, calendário, metas de uplift); C2.2 Seleção de elegíveis (entrada de C3 + filtros: negociações recentes, datas de reprecificação, RFPs, nichos, associações religiosas, poder público, N mínimo); C2.3 Cálculo do novo preço por cliente (reuso do motor C1 + gradação Stickiness x Impacto); C2.4 Aprovação (alçada) e comunicação; C2.5 Efetivação no legado de tarifas e acompanhamento do resultado. |
| **C3** | Gestão de Reciprocidade | **Evolução — pouco detalhada pelo negócio.** Destacar. | C3.1 Registro do acordo (volumetria/saldo/produtos contratados na negociação); C3.2 Monitoramento do realizado (emissões L3M, saldo IF/DAV, SoW boletos, share de cash); C3.3 Detecção de desvio (regras e tolerâncias parametrizáveis); C3.4 Geração de elegibilidade para C2 e alertas ao gerente. |
| **M1** | Parametrização (módulo transversal) | Necessário desde C1. | Catálogo de produtos/macroprodutos; domínios (segmentos, regiões, tiers); faixas de tier por produto; regra de cluster; percentis e percentil-alvo; premissas de desconto/alçada/remuneração; listas de exceção; janelas temporais; versionamento, staging, vigência agendada, perfis/alçadas de quem parametriza, auditoria. |
| **M2** | Preparação de Dados (Pipeline → BRP Cash) | Necessário desde C1. | Portar os 7 notebooks para Databricks Workflows; gerar BRP Cash versionada por ciclo; validações de qualidade; publicação (reverse ETL) para a base de serviço do motor. |
| **M3** | Legado e Base Histórica | Necessário desde C1. | Preço vigente e histórico 12 meses; tarifas de contrato; cadastro de segmentos/grupo econômico; desligamento gradual de SAS + SQL 010 + Planilha. |
| **M4** | Governança, Auditoria e Segurança | Transversal. | Logs de auditoria, perfis, alçadas, monitoramento, contingência. |

**Decisão sobre C3 ser sub-capacidade de C2**: manter **C3 como capacidade própria**. Justificativa: (1) tem ciclo de vida próprio, começa na contratação (acordo) e roda continuamente, independentemente de haver onda; (2) serve a outros consumidores (gerente comercial, manutenção de descontos, alertas), não só à reprecificação; (3) em DDD fica como bounded context separado que **publica** o evento "desvio de reciprocidade / cliente elegível", consumido por C2. A dependência C2 → C3 é de dados (elegibilidade), não de estrutura. Registrar essa avaliação nos documentos 2 e 3.

## 4. Camadas do desenho conceitual (usar esta ordem, de cima para baixo)

1. **Estratégia de negócio**: monetizar payments no Atacado (uplift de tarifas com política "nunca reduzir"), padronizar preço por cluster, dar autonomia ao comercial com alçada controlada, reter clientes (stickiness) e garantir reciprocidade dos acordos, governança/auditoria dos parâmetros.
2. **Canais e jornadas**: Calculadora Salesforce (FSC) para gerente/comercial; jornada de contratação sem alçada; telas de parametrização; telas de onda/aprovação; APIs para outros canais/plataformas/integradores.
3. **Capacidades de negócio**: C1 (prioritária), C2 e C3 (evolução — destacar visualmente como tracejado/"fase 2+").
4. **Módulos transversais**: M1 Parametrização, M4 Governança/Auditoria/Segurança.
5. **Dados e inteligência**: M2 Pipeline de Preparação (Databricks) → BRP Cash; modelos (tier, cluster, percentis, uplift, stickiness x impacto).
6. **Legado e fontes**: M3 — sistemas de origem (eventos tarifados, movimento, contratos, segmentos, ROB, IF/DAV, share BACEN/cash/boletos), preço vigente/histórico, SAS/SQL 010 (a desligar).

## 5. DDD — domínios e bounded contexts (usar estes nomes)

| Bounded Context | Tipo | Capacidade | Responsabilidade |
|---|---|---|---|
| **Cálculo de Preço** (Pricing Engine) | Core | C1 | Dado cliente+produto+volumetria+contexto, devolve praticado/alvo/sugerido, cenários e uplift; aplica premissas e parâmetros vigentes. |
| **Alçada e Aprovação** | Core (compartilhado C1/C2) | C1.3, C2.4 | Calcula nível de alçada, papel aprovador; registra pedidos/decisões de aprovação. |
| **Parametrização** | Supporting | M1 | Versões de parâmetros, staging/produção, vigência agendada, auditoria de quem mudou. |
| **Modelagem de Preço** (analítico) | Supporting | M2 | Pipeline Databricks: clusterização, percentis, preço-alvo, uplift, stickiness x impacto, indicadores de reciprocidade → BRP Cash. |
| **Publicação de Referência** (BRP Cash) | Supporting | M2 | Versionamento por ciclo, validação, reverse ETL para base de serviço, ativação de versão. |
| **Reprecificação** | Core (evolução) | C2 | Onda, elegibilidade, novo preço por cliente, aprovação, efetivação, acompanhamento. |
| **Reciprocidade** | Core (evolução) | C3 | Acordo, monitoramento, desvio, elegibilidade. |
| **Preço Vigente e Histórico** (Legado) | External / ACL | M3 | Sistemas legados de tarifas e contratos; acessados via Adaptador de Legado. |
| **Cadastro de Cliente e Grupo Econômico** | External | — | Segmentos, CNPJ→grupo, região. |
| **Identidade e Acesso** | Generic | M4 | Perfis, papéis, alçadas de usuário (Salesforce/AD corporativo). |
| **Auditoria e Observabilidade** | Generic | M4 | Trilhas de execução e de mudança de parâmetro; monitoramento. |

Context mapping (padrões): Canais (Salesforce/outros) → Cálculo de Preço: **Open Host Service + Published Language** (APIs REST). Cálculo de Preço ← Parametrização: **Customer/Supplier** (Cálculo é cliente). Cálculo de Preço ← Publicação de Referência: **Published Language** (contrato de dados da BRP Cash). Modelagem → Publicação: **Customer/Supplier**. Cálculo de Preço ← Legado: **Anti-Corruption Layer**. Reprecificação → Cálculo de Preço: **Customer/Supplier** (reusa simulação). Reciprocidade → Reprecificação: **Published Language via eventos** (ClienteElegivelParaReprecificacao). Reprecificação → Legado (efetivação de tarifa): **ACL** — lacuna: negócio não definiu se o motor efetiva ou só recomenda. Cadastro → todos: **Conformist**. Alçada ← Cálculo/Reprecificação: **Shared Kernel** pequeno (modelo de nível de alçada) ou Customer/Supplier — escolher Customer/Supplier para evitar acoplamento.

## 6. Decisões de arquitetura (com a posição crítica)

Stack corporativa (`stack-tech.md`): Salesforce FSC, Azure, Java prioritário para transações, Python para dados/ETL, Databricks, ARO (OpenShift) para containers, Axway API Gateway, Azure Application Gateway, Akamai (externo). Fluxo de entrada: Akamai → App Gateway → Axway → microsserviços.

| # | Decisão | Escolha | Alternativa rejeitada e porquê |
|---|---|---|---|
| AD-01 | Preparação de dados (M2) | **Databricks Workflows (PySpark/Delta)**, portando os 7 notebooks; tabelas Delta versionadas por `anomes`; Control-M apenas como **disparador corporativo** do job (via API/Jobs) quando a governança de scheduling exigir. | Microsserviços Python schedulados por Control-M: as bases já estão no Databricks (premissa do negócio), exigiria extrair dezenas de milhões de linhas para fora, duplicar governança, sem ganho. Mais complexo e menos elegante. |
| AD-02 | Base de serviço do motor online | **Azure SQL Database** (relacional: MPA, PPC, parâmetros, alçada, auditoria) carregada por **reverse ETL** a partir do Databricks. | MongoDB: modelo é tabular/relacional (matrizes por chave composta, joins com parâmetros e vigências); Azure SQL é padrão da stack; documentos aninhados não trazem vantagem. Pode ser reavaliado para o histórico de simulações (append-only) se o volume exigir. |
| AD-03 | Mecanismo de reverse ETL | Job Databricks escreve via **JDBC em tabelas de staging** no Azure SQL + procedure de **ativação de versão** (swap atômico por `anomes`); validações antes da ativação. | Azure Data Factory: adiciona componente; aceitável se já for padrão de integração da área de dados — registrar como alternativa equivalente. |
| AD-04 | Núcleo do motor online | **Microsserviços Java (Spring Boot) no ARO** atrás do Axway; regras expressas como **parâmetros versionados em tabelas** + estratégias em código; expressões simples (faixas/tabelas) sem engine externo. | **FICO (Blaze/DM)**: forte para regras editáveis por negócio e alçadas complexas, mas licença cara, skill escasso, lock-in, e as regras atuais são tabelas de faixas (tier, cluster, percentil, desconto) que cabem em parametrização de dados. Reavaliar FICO **apenas** se em C2 surgirem políticas de gradação muito complexas. |
| AD-05 | Front-end | **Salesforce FSC** (LWC + Named Credentials → App Gateway → Axway → APIs) para Calculadora, Parametrização, Reprecificação. Lógica de negócio **nunca** em Apex; Salesforce é canal. | Front próprio (React) para parametrização: viável, mas cria segundo front e segundo modelo de acesso; só se o Salesforce não comportar UX de administração. |
| AD-06 | Parametrização (M1) | Serviço Java + Azure SQL com **versionamento, status (rascunho → staging → publicado), vigência agendada, trilha de auditoria**; endpoint de simulação "em staging". | Parâmetros em arquivo/configmap: sem auditoria nem vigência. |
| AD-07 | Reciprocidade (C3) | Microsserviço Java + **job periódico** (Control-M) que compara acordado (Azure SQL) x realizado (Indicadores de Reciprocidade da BRP Cash) e **publica eventos**. | Colocar dentro do pipeline Databricks: perde o acordo (transacional) e a integração com o gerente. Indicadores continuam vindo do Databricks. |
| AD-08 | Reprecificação (C2) | Microsserviço Java (orquestração da onda, aprovação, efetivação) + **cálculo em lote** reusando o serviço de Cálculo de Preço; seleção analítica de elegíveis pode ser pré-computada no Databricks. | Tudo em Databricks: sem workflow de aprovação/alçada nem integração com Salesforce. |
| AD-09 | Mensageria entre contextos | **Azure Service Bus** (tópicos) para eventos de domínio (VersaoPublicada, ClienteElegivel, DesvioReciprocidade, PrecoAprovado). **Não está na stack — validar**; fallback: tabela outbox + polling. | Chamadas REST síncronas entre C3 e C2: acoplamento temporal. |
| AD-10 | Legado (M3) | **Adaptador de Legado** (Java) com duas estratégias: (a) foto do preço vigente/histórico vinda via Databricks → Azure SQL (premissa do negócio, `00-doc-negocio.md:L29`); (b) consulta online ao sistema de tarifas quando o canal exigir "informação mais atualizada" (`L16`). Decisão de latência aceitável fica com o negócio. | Só (a): risco de preço vigente defasado; só (b): dependência de disponibilidade do legado. |
| AD-11 | Cache | Cache em memória por instância (Caffeine) para parâmetros e MPA; sem Redis (não está na stack). | Redis: adicionar só se latência exigir. |
| AD-12 | Observabilidade/segurança | Padrão ARO (logs centralizados, métricas, tracing), OAuth2 no Axway, perfis via AD/Salesforce, auditoria em tabela append-only. | — |
| AD-13 | Contingência | Azure SQL zona-redundante, múltiplas réplicas no ARO, versão anterior da BRP Cash sempre disponível para rollback; Salesforce exibe "última cotação conhecida" com carimbo de data. | — |
| AD-14 | Transição | **Execução paralela (shadow)**: novo motor responde ao lado do SQL 010 durante o piloto; comparação de resultados; desligamento de SAS/SQL 010/Planilha por produto. | Big bang. |

Componentes (nomes canônicos para diagramas):
- `svc-pricing` (Cálculo de Preço), `svc-alcada` (Alçada e Aprovação), `svc-parametros` (Parametrização), `svc-reciprocidade` (C3), `svc-reprecificacao` (C2), `svc-legado-adapter` (Adaptador de Legado), `svc-publicacao` (ativação de versão da BRP Cash / catálogo de versões).
- `dbx-ppp` (Pipeline de Preparação de Preços, Databricks Workflows), `dbx-brp` (tabelas Delta da BRP Cash), `sql-motor` (Azure SQL de serviço), `sb-eventos` (Service Bus), `sf-calculadora`, `sf-parametrizacao`, `sf-reprecificacao` (LWC), `apigw-axway`, `appgw-azure`, `akamai`, `controlm`, `aro`.

## 7. Catálogo de requisitos (IDs fixos; derivados de `00-doc-negocio.md`)

Funcionais:
- RF-01 Retornar preço alvo, sugerido e praticado por cliente x produto (L7).
- RF-02 Simular preço sem efetivar tarifa; expor cenários (L10, §2).
- RF-03 Calcular alçada e indicar aprovador quando preço abaixo do sugerido; contratação sem alçada no preço sugerido (L22).
- RF-04 Consultar preço vigente e histórico de 12 meses no legado (L11-12, L29).
- RF-05 Parametrizar regras (catálogo, tiers, clusters, percentis, premissas) com versionamento e controle (L8-9, L13).
- RF-06 Ambiente de staging para testar parametrizações antes da publicação; publicação imediata ou agendada (L17, L42).
- RF-07 APIs para canais/plataformas/integradores com a informação mais atual disponível (L15-16).
- RF-08 Validar dados de entrada e alertar problemas nas bases (L19).
- RF-09 Registrar auditoria completa de execuções e de alterações de parâmetros (L14).
- RF-10 Controle de acesso por perfil e alçada nas funções de parametrização (L18).
- RF-11 Onda de reprecificação: elegibilidade, cálculo, aprovação, efetivação, acompanhamento (C2 — evolução).
- RF-12 Reciprocidade: registro de acordo, monitoramento, desvio, elegibilidade (C3 — evolução).
- RF-13 Pipeline de preparação gerando a BRP Cash versionada por ciclo a partir das bases no Databricks (L27, `00-etapas`).

Não funcionais:
- RNF-01 Disponibilidade e contingência para o motor offline (L39).
- RNF-02 Desempenho da consulta online (meta de trabalho: p95 < 500 ms para consulta/simulação; a validar).
- RNF-03 Rastreabilidade/auditoria imutável (L14, L40).
- RNF-04 Segurança e conformidade institucional (L40); autenticação/autorização via gateway e perfis.
- RNF-05 Monitoramento de execuções, integrações e falhas (L20).
- RNF-06 Governança de dados (ingestão via Databricks; não substituir bases de origem) (L28, L30).
- RNF-07 Escalabilidade para novos produtos/segmentos sem alteração de código (parametrização) (L8).
- RNF-08 Implantação gradual por pilotos, com execução paralela ao legado (L41).
- RNF-09 Versionamento e reprodutibilidade dos cálculos (qual versão de parâmetro e de BRP gerou cada preço).
- RNF-10 Aderência à stack corporativa (`stack-tech.md`).

## 8. Lacunas críticas a destacar em todos os docs (lista única)

1. Regras da macro "Preço por Produto"/"Resumo por GE" e do Motor da Calculadora (SQL 010) não documentadas — é onde o preço sugerido nasce hoje.
2. Conteúdo de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto`, `regiao_por_ge` desconhecido.
3. Definição formal de preço sugerido x alvo e da regra de alçada (níveis, aprovadores).
4. C2 e C3 sem detalhamento de negócio: critérios de elegibilidade, gradação do reajuste, o que é "acordo de reciprocidade" e onde é registrado hoje, se o motor efetiva tarifa no legado.
5. Inconsistências entre fluxos: INSTITUCIONAL (in/out), regra de cluster em Arrecadação diferente, grupo 616/Bradesco sem justificativa, produto sem cluster (`NA BAIXA POR PAGAMENTO Banco`), CANAIS DIGITAIS e DÉBITO AUTOMÁTICO sem fonte.
6. Datas hard-coded (202506, 2026-03..05) e listas fixas no código.
7. Latência aceitável do preço vigente (foto via Databricks x consulta online ao legado).
8. Trechos truncados nos docs fonte (01 clusters "demais", página 10; 06 após L138; 07 captura SAS cortada).
9. Mensageria (Service Bus) não está na stack — validar.
10. Semântica do campo N e do uso de QTDE_CASH_CONC/QTDE_COB_CONC.

## 9. Roadmap (fases canônicas — usar estes nomes e ordem)

| Fase | Nome | Duração alvo | Entregas principais |
|---|---|---|---|
| F0 | Mobilização e fechamento de lacunas | 4-6 semanas (out–nov/2026) | Decisões de negócio (§8), contrato de dados da BRP Cash, catálogo de parâmetros, arquitetura aprovada, ambientes. |
| F1 | MVP C1 — motor online em paralelo ao legado | ~4 meses (nov/2026–mar/2027) | dbx-ppp portado, BRP Cash v1, reverse ETL, svc-pricing, svc-alcada (regras mínimas), svc-legado-adapter (foto), svc-parametros (versionamento básico), APIs no Axway, Calculadora Salesforce apontando para o motor em shadow, auditoria. Piloto com grupo de gerentes. |
| F2 | Parametrização completa e desligamento do legado de distribuição | ~3 meses (abr–jun/2027) | Telas Salesforce de parametrização, staging, vigência agendada, perfis; validação de dados; desligamento de SAS/SQL 010/Planilha por produto; APIs para outros canais. |
| F3 | Discovery C2/C3 + MVP Reciprocidade | ~3 meses (jul–set/2027) | Detalhamento de negócio de C2 e C3; svc-reciprocidade (acordo + monitoramento + desvio), eventos, alertas ao gerente. |
| F4 | MVP Onda de Reprecificação | ~4 meses (out/2027–jan/2028) | svc-reprecificacao: onda, elegíveis (C3 + filtros), cálculo em lote, aprovação, efetivação (decisão de escopo), acompanhamento. |
| F5 | Escala e otimização | contínuo (2028) | Novos produtos/segmentos, outros canais, avaliação de FICO/Redis/MongoDB por evidência, modelos analíticos evoluídos. |

Datas são metas de trabalho a validar com capacidade das equipes.

## 10. Riscos canônicos (usar na apresentação e no roadmap)

| ID | Risco | Prob. | Impacto | Mitigação |
|---|---|---|---|---|
| R1 | Regras do preço sugerido (macro + SQL 010) não documentadas | Alta | Alto | Engenharia reversa na F0 com o time de Precificação; shadow run na F1. |
| R2 | C2/C3 sem definição de negócio | Alta | Alto | Discovery dedicado (F3); arquitetura preparada por eventos e reuso do motor. |
| R3 | Qualidade/instabilidade das bases de origem (layouts, datas hard-coded) | Média | Alto | Contratos de dados, validações no pipeline, alertas (RF-08). |
| R4 | Latência do preço vigente (foto x online) | Média | Médio | Adaptador com duas estratégias; decisão do negócio na F0. |
| R5 | Dependência de componente fora da stack (Service Bus) | Média | Médio | Validar cedo; fallback outbox. |
| R6 | Lógica vazando para Apex/Salesforce | Média | Médio | Diretriz de arquitetura; revisões. |
| R7 | Transição sem paralelismo → erro de preço em produção | Baixa | Alto | Shadow run, comparação automática, rollback de versão. |
| R8 | Capacidade das equipes (Java, Databricks, Salesforce) | Média | Médio | Squads por capacidade; F0 dimensiona. |
| R9 | Inconsistências entre fluxos (INSTITUCIONAL, cluster Arrecadação, grupo 616) | Alta | Médio | Decisões registradas no catálogo de parâmetros. |
| R10 | Governança de publicação (quem aprova versão de parâmetro/BRP) | Média | Médio | Fluxo staging → aprovação → produção com alçadas (RF-06, RF-10). |

## 11. Convenções de escrita para todos os documentos

- Português do Brasil, tom técnico-executivo. Markdown. Diagramas em **Mermaid** (flowchart/ C4-like com subgraphs). Sem emojis.
- Toda referência a doc fonte no formato `docs-precificacao/<arquivo>:L<linha>`; para detalhes, apontar para `anexos/A1` e `anexos/A2`.
- C2 e C3 sempre marcados como **[EVOLUÇÃO — a detalhar com o negócio]** em títulos e, nos diagramas, com estilo tracejado (`style ... stroke-dasharray: 5 5`).
- Toda decisão de arquitetura cita seu ID (AD-xx) e os requisitos atendidos (RF-xx / RNF-xx).
- Cabeçalho de cada doc: título, versão 1.0, data 2026-09-18, status "Rascunho para validação", fontes.
