"""
Biblioteca de estilo Bradesco para python-pptx.
Uso: from bradesco_style import Deck; d = Deck(); d.cover(...); d.save(path)

Paleta institucional Bradesco (assumida a partir da identidade visual pública):
  Vermelho Bradesco  #CC092F  (primária)
  Vermelho escuro    #A50021  (ênfase / rodapé)
  Cinza grafite      #58595B  (texto)
  Cinza médio        #939598  (texto secundário / linhas)
  Cinza claro        #E6E7E8  (fundos de caixa)
  Branco             #FFFFFF
  Azul apoio         #1F4E79  (usado com parcimônia p/ camadas "futuras")
  Verde apoio        #2E7D32  (status ok)
  Âmbar apoio        #F2A900  (risco médio)
Fonte: Bradesco Sans não disponível -> Arial (fallback institucional).
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

RED = RGBColor(0xCC, 0x09, 0x2F)
RED_DARK = RGBColor(0xA5, 0x00, 0x21)
GRAY = RGBColor(0x58, 0x59, 0x5B)
GRAY_MID = RGBColor(0x93, 0x95, 0x98)
GRAY_LIGHT = RGBColor(0xE6, 0xE7, 0xE8)
GRAY_BG = RGBColor(0xF4, 0xF4, 0xF5)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
BLUE = RGBColor(0x1F, 0x4E, 0x79)
BLUE_LIGHT = RGBColor(0xDC, 0xE6, 0xF1)
GREEN = RGBColor(0x2E, 0x7D, 0x32)
AMBER = RGBColor(0xF2, 0xA9, 0x00)
RED_LIGHT = RGBColor(0xFB, 0xE3, 0xE8)
FONT = "Arial"

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


class Deck:
    def __init__(self):
        self.prs = Presentation()
        self.prs.slide_width = SLIDE_W
        self.prs.slide_height = SLIDE_H
        self.blank = self.prs.slide_layouts[6]
        self.n = 0

    # ---------- primitivas ----------
    def _slide(self):
        s = self.prs.slides.add_slide(self.blank)
        self.n += 1
        return s

    def rect(self, s, x, y, w, h, fill=GRAY_LIGHT, line=None, shape=MSO_SHAPE.RECTANGLE, radius=None):
        sh = s.shapes.add_shape(shape, x, y, w, h)
        sh.fill.solid()
        sh.fill.fore_color.rgb = fill
        if line is None:
            sh.line.fill.background()
        else:
            sh.line.color.rgb = line
            sh.line.width = Pt(1)
        sh.shadow.inherit = False
        if radius is not None and shape == MSO_SHAPE.ROUNDED_RECTANGLE:
            sh.adjustments[0] = radius
        return sh

    def text(self, s, x, y, w, h, txt, size=12, bold=False, color=GRAY, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, italic=False, font=FONT):
        tb = s.shapes.add_textbox(x, y, w, h)
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Inches(0.05)
        tf.margin_top = tf.margin_bottom = Inches(0.03)
        tf.vertical_anchor = anchor
        lines = txt if isinstance(txt, list) else [txt]
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            r = p.add_run()
            r.text = line
            r.font.name = font
            r.font.size = Pt(size)
            r.font.bold = bold
            r.font.italic = italic
            r.font.color.rgb = color
        return tb

    def bullets(self, s, x, y, w, h, items, size=12, color=GRAY, bullet="▪", spacing=4):
        tb = s.shapes.add_textbox(x, y, w, h)
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Inches(0.05)
        for i, it in enumerate(items):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.space_after = Pt(spacing)
            level = 0
            bold = False
            if isinstance(it, tuple):
                it, level = it[0], it[1]
            if it.startswith("**") and "**" in it[2:]:
                bold = True
                it = it.replace("**", "")
            r = p.add_run()
            r.text = ("    " * level) + (bullet + " " if bullet else "") + it
            r.font.name = FONT
            r.font.size = Pt(size - level)
            r.font.bold = bold
            r.font.color.rgb = color
        return tb

    def box(self, s, x, y, w, h, title, body=None, fill=WHITE, title_fill=RED, title_color=WHITE,
            body_size=10, body_color=GRAY, line=GRAY_LIGHT, title_size=11, dashed=False):
        """Caixa com faixa de título."""
        outer = self.rect(s, x, y, w, h, fill=fill, line=line)
        if dashed:
            from pptx.enum.dml import MSO_LINE
            outer.line.dash_style = MSO_LINE.DASH
            outer.line.width = Pt(1.5)
        th = Inches(0.34)
        self.rect(s, x, y, w, th, fill=title_fill)
        self.text(s, x, y, w, th, title, size=title_size, bold=True, color=title_color,
                  align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        if body:
            if isinstance(body, list):
                self.bullets(s, x + Inches(0.05), y + th + Inches(0.03), w - Inches(0.1), h - th - Inches(0.05),
                             body, size=body_size, color=body_color, spacing=2)
            else:
                self.text(s, x + Inches(0.05), y + th + Inches(0.03), w - Inches(0.1), h - th - Inches(0.05),
                          body, size=body_size, color=body_color)
        return outer

    def chip(self, s, x, y, w, h, txt, fill=RED, color=WHITE, size=9, bold=True, line=None):
        sh = self.rect(s, x, y, w, h, fill=fill, line=line, shape=MSO_SHAPE.ROUNDED_RECTANGLE, radius=0.3)
        self.text(s, x, y, w, h, txt, size=size, bold=bold, color=color, align=PP_ALIGN.CENTER,
                  anchor=MSO_ANCHOR.MIDDLE)
        return sh

    def arrow(self, s, x1, y1, x2, y2, color=GRAY_MID, width=1.5):
        c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x1, y1, x2, y2)
        c.line.color.rgb = color
        c.line.width = Pt(width)
        # seta no fim
        ln = c.line._get_or_add_ln()
        from pptx.oxml.ns import qn
        from lxml import etree
        tail = etree.SubElement(ln, qn("a:tailEnd"))
        tail.set("type", "triangle")
        tail.set("w", "med")
        tail.set("h", "med")
        return c

    def harrow(self, s, x, y, w, h=Inches(0.35), fill=RED, txt=None, size=9):
        sh = self.rect(s, x, y, w, h, fill=fill, shape=MSO_SHAPE.RIGHT_ARROW)
        if txt:
            self.text(s, x, y, w - Inches(0.15), h, txt, size=size, bold=True, color=WHITE,
                      align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        return sh

    def table(self, s, x, y, w, h, header, rows, col_widths=None, size=9, header_fill=RED,
              zebra=True, first_col_bold=False):
        shape = s.shapes.add_table(len(rows) + 1, len(header), x, y, w, h)
        tbl = shape.table
        if col_widths:
            total = sum(col_widths)
            for i, cw in enumerate(col_widths):
                tbl.columns[i].width = int(w * cw / total)
        for j, htxt in enumerate(header):
            c = tbl.cell(0, j)
            c.fill.solid()
            c.fill.fore_color.rgb = header_fill
            c.text = ""
            p = c.text_frame.paragraphs[0]
            r = p.add_run()
            r.text = htxt
            r.font.name = FONT
            r.font.size = Pt(size)
            r.font.bold = True
            r.font.color.rgb = WHITE
            c.margin_left = c.margin_right = Inches(0.05)
            c.margin_top = c.margin_bottom = Inches(0.02)
        for i, row in enumerate(rows, start=1):
            for j, val in enumerate(row):
                c = tbl.cell(i, j)
                c.fill.solid()
                c.fill.fore_color.rgb = GRAY_BG if (zebra and i % 2 == 0) else WHITE
                c.text = ""
                p = c.text_frame.paragraphs[0]
                r = p.add_run()
                r.text = str(val)
                r.font.name = FONT
                r.font.size = Pt(size)
                r.font.bold = first_col_bold and j == 0
                r.font.color.rgb = GRAY
                c.margin_left = c.margin_right = Inches(0.05)
                c.margin_top = c.margin_bottom = Inches(0.02)
        return tbl

    # ---------- molduras ----------
    def _frame(self, s, title, subtitle=None, section=None):
        # barra vermelha superior fina + logo textual
        self.rect(s, 0, 0, SLIDE_W, Inches(0.12), fill=RED)
        self.text(s, Inches(0.45), Inches(0.28), Inches(9.5), Inches(0.6), title, size=24, bold=True, color=RED)
        if subtitle:
            self.text(s, Inches(0.45), Inches(0.85), Inches(11), Inches(0.4), subtitle, size=12, color=GRAY_MID)
        # linha separadora
        self.rect(s, Inches(0.45), Inches(1.25), SLIDE_W - Inches(0.9), Emu(12700), fill=GRAY_LIGHT)
        # rodapé
        self.rect(s, 0, SLIDE_H - Inches(0.35), SLIDE_W, Inches(0.35), fill=RED_DARK)
        self.text(s, Inches(0.45), SLIDE_H - Inches(0.33), Inches(8), Inches(0.3),
                  "Bradesco  |  Motor de Precificação Cash  |  Uso interno" + (f"  |  {section}" if section else ""),
                  size=9, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
        self.text(s, SLIDE_W - Inches(1.2), SLIDE_H - Inches(0.33), Inches(0.8), Inches(0.3), str(self.n),
                  size=9, color=WHITE, align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)

    def cover(self, title, subtitle, meta_lines):
        s = self._slide()
        self.rect(s, 0, 0, SLIDE_W, SLIDE_H, fill=RED)
        self.rect(s, 0, Inches(5.2), SLIDE_W, Inches(2.3), fill=RED_DARK)
        self.text(s, Inches(0.7), Inches(0.6), Inches(6), Inches(0.5), "Bradesco", size=28, bold=True, color=WHITE)
        self.text(s, Inches(0.7), Inches(2.2), Inches(11.5), Inches(1.4), title, size=40, bold=True, color=WHITE)
        self.text(s, Inches(0.7), Inches(3.6), Inches(11.5), Inches(1.2), subtitle, size=18, color=WHITE)
        self.text(s, Inches(0.7), Inches(5.5), Inches(11.5), Inches(1.5), meta_lines, size=12, color=WHITE)
        return s

    def section(self, number, title, lead=None):
        s = self._slide()
        self.rect(s, 0, 0, Inches(4.2), SLIDE_H, fill=RED)
        self.text(s, Inches(0.5), Inches(2.6), Inches(3.3), Inches(1.5), number, size=72, bold=True, color=WHITE)
        self.text(s, Inches(4.8), Inches(2.7), Inches(8), Inches(1.2), title, size=34, bold=True, color=RED)
        if lead:
            self.text(s, Inches(4.8), Inches(3.9), Inches(8), Inches(2), lead, size=14, color=GRAY)
        self.rect(s, 0, SLIDE_H - Inches(0.35), SLIDE_W, Inches(0.35), fill=RED_DARK)
        return s

    def content(self, title, subtitle=None, section=None):
        s = self._slide()
        self._frame(s, title, subtitle, section)
        return s

    def save(self, path):
        self.prs.save(path)
        return path
