# 05 — Domínios, Bounded Contexts e Context Mapping

| Campo | Valor |
|---|---|
| Documento | 05 — Domínios, Bounded Contexts e Context Mapping do Motor de Precificação Cash (MPC) |
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Fontes | `anexos/A0-brief-decisoes.md` (§1-§8), `anexos/A1-analise-fluxos-produtos.md`, `anexos/A2-analise-fluxos-consolidacao.md`, `docs-precificacao/00-doc-negocio.md` |

---

## 1. Introdução e objetivo

Este documento aplica Domain-Driven Design (DDD) estratégico ao Motor de Precificação Cash: fixa a linguagem ubíqua, classifica os subdomínios, delimita os bounded contexts (BCs) com seus agregados, comandos, eventos e políticas, e formaliza o context map. O objetivo é dar às equipes de produto, dados e engenharia um vocabulário único e fronteiras explícitas antes de detalhar serviços, APIs e tabelas. Cada BC corresponde a uma capacidade (C1, C2, C3) ou a um módulo transversal (M1 a M4) do brief `A0 §3`.

Relação com os demais documentos:

- **Doc 03 (Desenho conceitual)** define as camadas (estratégia, canais, capacidades, módulos transversais, dados e inteligência, legado; `A0 §4`) e as capacidades. Este documento pega a camada de capacidades e a decompõe em contextos de domínio: cada BC atende uma ou mais sub-capacidades e nenhuma sub-capacidade fica sem dono.
- **Doc 06 (Arquitetura de solução)** decide tecnologia (AD-01 a AD-14, `A0 §6`). Este documento é a ponte: a seção 7 mapeia cada BC para os componentes canônicos (`svc-*`, `dbx-*`, `sql-motor`, `sb-eventos`, `sf-*`). Toda fronteira de BC aqui vira fronteira de deploy, de dados ou de contrato no doc 06.

Convenção de referências: `NN:L<linha>` abrevia `docs-precificacao/<arquivo>:L<linha>` para os fluxos 01 a 07 (por exemplo, `01:L112` é `docs-precificacao/01-cobrança-fluxo.md:L112`); `A0`, `A1` e `A2` são os anexos `anexos/A0-brief-decisoes.md`, `anexos/A1-analise-fluxos-produtos.md` e `anexos/A2-analise-fluxos-consolidacao.md`.

Convenção de status: **C1 e os módulos M1 a M4 estão detalhados**. **C2 (Reprecificação) e C3 (Reciprocidade) estão marcados [EVOLUÇÃO — a detalhar com o negócio]**, com hipóteses de modelagem explícitas e perguntas em aberto. Onde uma regra não está documentada nas fontes, o texto diz "(hipótese)".

---

## 2. Linguagem ubíqua

Glossário canônico. "Contexto onde vale" indica o BC dono da definição; os demais usam o termo com o mesmo significado ou traduzem via ACL. Sinônimos listados devem ser evitados em código, APIs, telas e documentos.

| Termo | Definição | Contexto onde vale | Sinônimos a evitar |
|---|---|---|---|
| Preço praticado (vigente) | Tarifa efetivamente cobrada hoje do cliente no produto. No motor vem do legado via Adaptador; a BRP Cash traz a foto do ciclo (`A0 §2`; `00-doc-negocio.md:L11`). | Legado (dono); Cálculo de Preço (lê) | TARIFA, tarifa atual, preço corrente |
| Preço alvo | Preço de referência do cluster do cliente: max(tarifa atual, P75 do cluster), política "nunca reduzir". Depende de produto, tier, segmento e região (`A1 §Síntese`, `01:L112`). | Modelagem de Preço (calcula); Cálculo de Preço (lê) | PREÇO_ALVO, preço de cluster, preço de lista |
| Preço sugerido | Preço que o motor recomenda ao cliente: preço alvo ajustado por relacionamento (desconto por saldo IF/DAV), premissas (custos, RFP, nichos, exceções) e gradação Stickiness x Impacto. É o piso de negociação sem alçada (`A0 §2`). | Cálculo de Preço | preço de referência do cliente, preço final, preço motor |
| Preço negociado (simulado) | Valor informado pelo gerente na simulação para comparação com o sugerido (`A0 §2`). | Canal (informa); Cálculo de Preço (avalia) | preço proposto, preço do gerente |
| Cotação | Resultado de uma simulação: conjunto de preços (praticado, alvo, sugerido), cenários, uplift e resultado de alçada, carimbado com as versões usadas. | Cálculo de Preço | simulação (quando se refere ao resultado), consulta |
| Cenário | Variação de uma cotação: por percentil (P25 a P90), por tier, com/sem desconto de relacionamento, com receita/uplift estimado (`A0 §2`). | Cálculo de Preço | faixa, alternativa |
| Tier de volume | Faixa de quantidade do cliente no produto (Tier 1 maior volume, Tier 3 menor), com cortes por produto (`01:L59-79`; `07:L65`). | Parametrização (define cortes); Modelagem e Cálculo (classificam) | faixa de volume, "tear", nível |
| Cluster de precificação | Código 1 a 10 que resume tier + segmento + região para um produto; chave da Matriz de Preço-Alvo (`05:L56-94`). | Parametrização (regra); Modelagem (atribui) | grupo de preço, perfil |
| Percentil de tarifa | Estatística (P25, P35, P40, P50, P60, P75, P90) da tarifa praticada nos clientes de um cluster (`01:L96`). | Modelagem de Preço | quartil, faixa de preço |
| Faixa de percentil | Par (percentil, valor) usado como cenário de negociação; P75 é o percentil-alvo padrão (parametrizável). | Cálculo de Preço | banda |
| Referência corporate | Média ponderada por volume de P25/P75 nos clusters "corporate" de um produto; ponto de partida da monotonicidade (`01:L97`; `02:L50`). | Modelagem de Preço | âncora, cluster 9999 |
| Monotonicidade (cummin) | Mínimo acumulado que garante percentil não crescente do cluster corporate para os clusters de maior volume (`01:L98-102`). | Modelagem de Preço | ajuste, suavização |
| N (representatividade) | Quantidade de grupos econômicos distintos no cluster; N < 15 mantém a tarifa atual e zera o uplift (`01:L106`, `L120`). Semântica a confirmar (`A0 §8.10`). | Modelagem de Preço | contagem, amostra |
| Uplift | Receita anual incremental estimada ao levar a tarifa ao preço alvo (ou sugerido/negociado, na cotação); duas fórmulas conforme limiar de tarifa 1.000 (`01:L116`). | Modelagem (por ciclo); Cálculo (por cotação) | ganho, incremento, delta |
| Política "nunca reduzir" | Regra de que preço alvo e preço sugerido nunca ficam abaixo do praticado (`01:L112`). | Cálculo de Preço; Modelagem | piso |
| Desvio (de preço) | Diferença percentual e em R$ de uplift entre o preço negociado e o preço sugerido; insumo da alçada (`A0 §2`). | Cálculo de Preço (calcula); Alçada (consome) | gap, desconto adicional |
| Alçada | Nível de aprovação exigido quando o preço negociado fica abaixo do sugerido (`00-doc-negocio.md:L22`; `07:L78`). | Alçada e Aprovação | aprovação, workflow (genérico) |
| Aprovador | Papel (não pessoa) habilitado a decidir um pedido de aprovação em determinado nível de alçada. | Alçada e Aprovação | gestor, chefe |
| Pedido de aprovação | Solicitação formal de decisão sobre uma cotação ou item de onda que exige alçada; tem ciclo de vida próprio. | Alçada e Aprovação | ticket, exceção |
| Conjunto de parâmetros | Unidade versionada de parametrização de um tipo (catálogo, tiers, cluster, percentis, premissas, exceções, janelas) e escopo. | Parametrização | premissa (isolada), config |
| Versão de parâmetro | Instância imutável de um conjunto de parâmetros com status e vigência. | Parametrização | release, revisão |
| Vigência | Intervalo [início, fim) em que uma versão está ativa; pode ser imediata ou agendada (`00-doc-negocio.md:L42`). | Parametrização; Publicação de Referência | validade, data de corte |
| Staging | Ambiente lógico onde uma versão pode ser testada em simulações antes da publicação (`00-doc-negocio.md:L17`, `L36`). | Parametrização | homologação, teste |
| Ciclo de precificação (anomes) | Período mensal (ou semestral para preço por produto) que versiona a BRP Cash; chave `anomes` (`07:L89`, `L112`). | Publicação de Referência | onda (reservado a C2), safra |
| BRP Cash | Base de Referência de Preços Cash: conjunto publicado por ciclo com MPA, PPC, Matriz de Relacionamento e Indicadores de Reciprocidade (`A0 §1`; `A2 §6.3`). | Publicação de Referência (publica); Modelagem (produz) | Planilha Ano 1, base final |
| MPA | Matriz de Preço-Alvo por Cluster: produto x tier x segmento x região → cluster e percentis (`tabela_precos`). | Modelagem (produz); Cálculo (lê) | tabela de preços, esqueleto |
| PPC | Posição de Preço Cliente-Produto: por grupo x produto, tarifa praticada, cluster, volumetria, preço alvo, uplift, N (`base_total`). | Modelagem (produz); Cálculo (lê) | Base Pricing, base total |
| Matriz de Relacionamento | Classificação Stickiness x Impacto por grupo econômico (`matriz.xlsx`; `06:L42`). | Modelagem (produz); Cálculo e Reprecificação (leem) | matriz, "Stikiness e Impacto" |
| Stickiness | Grau de dependência do cliente com o banco, max(score de share de cash, score de share de crédito), rótulos Baixo a Alto (`06:L84-93`). | Modelagem de Preço | probabilidade de retenção, aderência |
| Impacto | Relevância financeira do cliente, max(score de ROB, score de receita de cash), rótulos Baixo/Médio/Alto (`06:L115-123`). | Modelagem de Preço | materialidade, relevância |
| Indicadores de Reciprocidade | Saldo médio IF/DAV, SoW de boletos, emissões L3M e share de cash por grupo (`06:L44-56`; `07:L24`). | Modelagem (produz); Reciprocidade (consome) | saldo, share (isolados) |
| Acordo de reciprocidade | [EVOLUÇÃO] Compromisso registrado na negociação: volumetria, saldo e produtos contratados em troca do preço concedido (hipótese, `A0 §3 C3.1`). | Reciprocidade | contrapartida, pacote |
| Desvio de reciprocidade | [EVOLUÇÃO] Diferença entre acordado e realizado além da tolerância parametrizada (`A0 §3 C3.3`). | Reciprocidade | quebra, inadimplência de acordo |
| Elegibilidade | [EVOLUÇÃO] Condição de um cliente x produto poder entrar numa onda: desvio de reciprocidade ou filtros (negociações recentes, datas, RFP, nichos, N mínimo) (`A0 §3 C2.2`). | Reprecificação (decide); Reciprocidade (sinaliza) | seleção, target list |
| Onda de reprecificação | [EVOLUÇÃO] Ciclo planejado de reajuste de tarifas de um conjunto de clientes com metas e calendário (`A0 §1`; `07:L18`). | Reprecificação | ciclo (reservado à BRP), campanha |
| Efetivação | [EVOLUÇÃO] Aplicação da nova tarifa no sistema legado de tarifas (`A0 §3 C2.5`). Se o motor efetiva ou só recomenda está em aberto. | Reprecificação (comanda); Legado (executa) | implantação, ativação (reservado à BRP) |
| Grupo econômico | Unidade de consolidação do cliente (CD_GRUPO); 0 é excluído (`05:L37`). | Cadastro (dono) | cliente (quando ambíguo), GE, conglomerado |
| Segmento | Classificação comercial: ULTRA, LARGE, CORPORATE, GLOBAL, AGRO CORPORATE; INSTITUCIONAL em aberto (`A0 §1`). | Cadastro (dono); Parametrização (domínio) | carteira, porte |
| Região comercial | S, CO, NNE, SE ex-SP, SP, derivada da UF do grupo (`02:L40-46`; `07:L82`). | Cadastro (dono); Parametrização (domínio) | UF, praça |
| Macroproduto | Família: COBRANCA, ARRECADACAO, MULTIPAG, PIX (`05:L34`). | Parametrização (catálogo) | linha, família |
| Produto (evento tarifado) | Evento precificável dentro de um macroproduto, ex.: `QUANDO DO REGISTRO Cliente` (`05:L49`). | Parametrização (catálogo) | modalidade, tarifa (isolado), serviço |
| Visão Cliente / Banco | Quem paga o evento tarifado; sufixo do nome do produto (`01:L57`). | Parametrização (catálogo) | lado, pagador |

---

## 3. Subdomínios

A classificação segue `A0 §5`. "Core" diferencia o banco e concentra as regras de precificação. "Supporting" é necessário mas não diferencia. "Generic" tem solução de prateleira. "External" é dono de dados que o motor apenas lê.

| Subdomínio / BC | Tipo | Capacidade | Justificativa |
|---|---|---|---|
| Cálculo de Preço (Pricing Engine) | **Core** | C1 | É onde o preço sugerido nasce; concentra as regras hoje espalhadas na macro, no SQL 010 e nas premissas (`A0 §8.1`). Diferencia o banco. |
| Alçada e Aprovação | **Core** (compartilhado C1/C2) | C1.3, C2.4 | Política de autonomia comercial com controle; mesma política serve a simulação e a onda. |
| Reprecificação | **Core** (evolução) | C2 | Materializa o uplift: onda, elegibilidade, novo preço, efetivação. [EVOLUÇÃO] |
| Reciprocidade | **Core** (evolução) | C3 | Garante que o preço concedido tenha contrapartida; ciclo de vida próprio (`A0 §3`). [EVOLUÇÃO] |
| Parametrização | Supporting | M1 | Governa regras como dados versionados; essencial, mas não diferencia. |
| Modelagem de Preço (analítico) | Supporting | M2 | Produz clusters, percentis, preço alvo, Stickiness x Impacto. A metodologia é core, mas o contexto é de produção de dados; suas saídas entram como Published Language. |
| Publicação de Referência (BRP Cash) | Supporting | M2 | Versionamento por ciclo, validação, reverse ETL, ativação/rollback. |
| Preço Vigente e Histórico (Legado) | External / ACL | M3 | Sistemas de tarifas e contratos existentes; acessados via Adaptador de Legado. |
| Cadastro de Cliente e Grupo Econômico | External | — | Segmentos, CNPJ → grupo, região. Dono corporativo fora do motor. |
| Identidade e Acesso | Generic | M4 | Perfis, papéis e alçadas de usuário no AD/Salesforce. |
| Auditoria e Observabilidade | Generic | M4 | Trilhas de execução e de mudança; monitoramento padrão ARO. |

```mermaid
flowchart TB
  subgraph CORE["Core"]
    CALC["Cálculo de Preço"]
    ALC["Alçada e Aprovação"]
    REP["Reprecificação (C2)"]
    REC["Reciprocidade (C3)"]
  end
  subgraph SUP["Supporting"]
    PAR["Parametrização"]
    MOD["Modelagem de Preço (analítico)"]
    PUB["Publicação de Referência (BRP Cash)"]
  end
  subgraph EXT["External"]
    LEG["Preço Vigente e Histórico (Legado)"]
    CAD["Cadastro de Cliente e Grupo Econômico"]
  end
  subgraph GEN["Generic"]
    IAM["Identidade e Acesso"]
    AUD["Auditoria e Observabilidade"]
  end
  MOD --> PUB --> CALC
  PAR --> CALC
  PAR --> MOD
  LEG --> CALC
  CAD --> CALC
  CALC --> ALC
  REC --> REP
  REP --> CALC
  REP --> ALC
  REP --> LEG
  IAM -.-> ALC
  AUD -.-> CALC
  style REP stroke-dasharray: 5 5
  style REC stroke-dasharray: 5 5
```

---

## 4. Bounded contexts

Para cada BC: responsabilidade, agregados (raiz, entidades, value objects, invariantes), comandos, eventos (formato SubstantivoParticípio), políticas, dados que possui versus só lê, e o que não é responsabilidade do contexto.

### 4.1 Cálculo de Preço (Pricing Engine)

**Responsabilidade.** Dado cliente ou grupo, produto(s), volumetria e contexto, devolver preço praticado, alvo e sugerido, cenários, uplift e o resultado de alçada, aplicando as versões vigentes de parâmetros e da BRP Cash. Atende C1.1, C1.2, C1.5 (via OHS) e C1.6; solicita C1.3 ao BC de Alçada; solicita C1.4 ao Legado via ACL. Requisitos: RF-01, RF-02, RF-03 (parte), RF-07, RNF-02, RNF-09.

**Agregado `Cotacao`** (raiz; também chamado `SolicitacaoDeSimulacao` enquanto não calculado).

| Elemento | Conteúdo |
|---|---|
| Entrada (`SolicitacaoDeSimulacao`, VO) | identificador do cliente ou grupo econômico; lista de produtos; volumetria informada por produto (opcional: se ausente, usa a da PPC); preço negociado por produto (opcional); canal e usuário solicitante; versão de parâmetros e versão de BRP (opcional: padrão é a vigente; obrigatório informar quando em staging). |
| Entidades | `ItemDeCotacao` (um por produto): `PrecoPraticado`, `PrecoAlvo`, `PrecoSugerido`, `PrecoNegociado`, `Tier`, `Cluster`, lista de `Cenario`, `Uplift`, `ResultadoDeAlcada`. |
| Value objects | `Preco` (valor decimal, unidade: R$ por evento ou %, moeda), `Tier` (código 1-3 + faixa aplicada), `Cluster` (código 1-10 + grupo de regra), `FaixaPercentil` (percentil, valor, rótulo), `Cenario` (tipo: percentil / tier / relacionamento; parâmetros; preços resultantes; uplift anual), `Desvio` (% e R$), `CarimboDeVersoes` (versão de cada tipo de parâmetro, `anomes` da BRP, hash). |
| Invariantes | (I1) `PrecoAlvo ≥ PrecoPraticado` (nunca reduzir). (I2) `PrecoSugerido ≥ PrecoPraticado`; `PrecoSugerido ≤ PrecoAlvo` só quando houver desconto de relacionamento parametrizado (hipótese). (I3) O sugerido é calculado com a versão vigente de parâmetros e de BRP no instante da solicitação, salvo staging explícito. (I4) Toda cotação registra o `CarimboDeVersoes` e é imutável após emissão. (I5) Se `PrecoNegociado` informado e `< PrecoSugerido`, o `ResultadoDeAlcada` é obrigatório. (I6) Uma cotação não efetiva tarifa (RF-02). |

**Comandos.** `SimularPreco`, `ConsultarPreco` (sem negociado e sem cenários, só praticado/alvo/sugerido), `GerarCenarios`, `ConsultarCotacao` (por id), `SimularEmStaging` (exige versão de parâmetros em staging e perfil autorizado), `CalcularEmLote` (C2 reusa: lista de solicitações).

**Eventos.** `CotacaoGerada`, `PrecoSimulado` (com desvio e uplift por item), `CenariosGerados`, `AlcadaSolicitada` (pedido ao BC Alçada, quando I5), `CotacaoRegistrada` (persistida para auditoria, RNF-03).

**Políticas / regras.** Tier pelas faixas vigentes do produto; cluster pela regra vigente; percentis da MPA; alvo = max(praticado, percentil-alvo); sugerido = alvo ajustado por desconto de relacionamento, exceções (RFP, custo, nicho) e gradação, na ordem parametrizada; fallback para combinação produto x cluster sem percentil (hoje descartada, `05:L28`; regra a definir); uplift com as duas fórmulas e limiar parametrizado; validação de entradas (RF-08).

**Dados que possui.** Histórico de cotações (append-only), cenários emitidos, carimbo de versões, log de execução.

**Dados que só lê.** MPA, PPC, Matriz de Relacionamento, Indicadores de Reciprocidade (BRP Cash, versão ativa); conjuntos de parâmetros vigentes; preço vigente e histórico (via ACL); cadastro de cliente (segmento, grupo, região).

**Não é responsabilidade.** Decidir a aprovação (Alçada); manter parâmetros (Parametrização); produzir percentis, clusters ou Stickiness (Modelagem); efetivar tarifa (Reprecificação/Legado); registrar acordo de reciprocidade (Reciprocidade); lógica de tela (canais).

### 4.2 Alçada e Aprovação

**Responsabilidade.** Calcular o nível de alçada e o papel aprovador para um desvio, e registrar pedidos e decisões de aprovação. Atende C1.3 e C2.4. Requisitos: RF-03, RF-09, RF-10.

**Agregado `PoliticaDeAlcada`** (raiz). Entidades: `NivelDeAlcada` (código, ordem, papel aprovador). VOs: `FaixaDeDesvio` (min %, max %, min R$, max R$), `EscopoDaPolitica` (produto, macroproduto, segmento, canal). Invariantes: faixas de desvio não se sobrepõem no mesmo escopo; níveis ordenados; existe um nível terminal ("sem alçada") para desvio zero ou negativo. Conteúdo real de `premissas_alcada` desconhecido (`A0 §8.2`): a estrutura acima é hipótese parametrizável. A política é um parâmetro versionado, portanto sua origem é o BC de Parametrização; este BC a interpreta.

**Agregado `PedidoDeAprovacao`** (raiz). Entidades: `Decisao` (aprovador, data, resultado, justificativa), `ItemDoPedido` (produto, sugerido, negociado, desvio, nível). VOs: `ReferenciaDeOrigem` (cotação ou item de onda), `NivelDeAlcada`, `PapelAprovador`, `Prazo`. Invariantes: só pode ser decidido por usuário com o papel do nível calculado; decisão é imutável; um pedido referencia exatamente uma origem; pedido expira ao vencer o prazo ou quando a cotação de origem perde vigência de versão (hipótese).

**Comandos.** `CalcularAlcada(desvio, escopo)`, `AbrirPedidoDeAprovacao`, `AprovarPedido`, `ReprovarPedido`, `CancelarPedido`, `DelegarAprovacao` (hipótese).

**Eventos.** `AlcadaCalculada`, `PedidoDeAprovacaoAberto`, `PrecoAprovado`, `PrecoReprovado`, `PedidoDeAprovacaoExpirado`.

**Políticas.** Desvio ≤ 0 → sem alçada (contratação direta, `00-doc-negocio.md:L22`). Nível determinado pela maior faixa atingida entre % e R$ (hipótese). Aprovação dispara `PrecoAprovado`, consumido pelo canal (C1) ou pela onda (C2).

**Possui.** Pedidos, decisões, trilha de aprovação. **Só lê.** Política vigente (Parametrização), papéis do usuário (Identidade e Acesso), cotação de origem (Cálculo). **Não é responsabilidade.** Calcular o desvio (Cálculo faz); efetivar preço; notificar por e-mail (canal/Salesforce).

### 4.3 Parametrização

**Responsabilidade.** Manter, versionar, testar em staging, aprovar, publicar (imediato ou agendado) e auditar todos os parâmetros que governam Modelagem e Cálculo. Atende M1. Requisitos: RF-05, RF-06, RF-09, RF-10, RNF-07, RNF-09. Decisão AD-06.

**Agregado `ConjuntoDeParametros`** (raiz), um por `TipoDeParametro` x `Escopo`.

| Elemento | Conteúdo |
|---|---|
| Entidades | `VersaoDeParametro` (número, status, autor, aprovador, vigência, conteúdo imutável), `ItemDeParametro` (chave composta + valor). |
| Tipos de parâmetro (catálogo) | Catálogo de produtos/macroprodutos (com visão Cliente/Banco e grupo de regra de cluster); domínios (segmentos, regiões, tiers, tabela UF → região); faixas de tier por produto (inclusive flag "sem Tier 3"); regra de cluster (grupo de regra x tier x segmento x região → cluster; fallback); percentis calculados e percentil-alvo; clusters corporate e ordem de monotonicidade; premissas de desconto (por saldo IF/DAV), de alçada, de remuneração; N mínimo e limiar de uplift; listas de exceção (negociações recentes, datas de reprecificação, RFP, custos, nichos, associações religiosas, poder público, grupos excluídos); janelas temporais (LTM, L3M, ROB 6M, saldo 3M); parâmetros de Stickiness x Impacto (materialidade, faixas de score, rótulos); cadências de publicação. Lista completa em `A1 §Síntese` (34 famílias) e `A2 §Síntese`. |
| Value objects | `Status` (rascunho → staging → aprovado → publicado → agendado → expirado; rascunho pode ir a descartado), `Vigencia` [início, fim), `Escopo` (global, macroproduto, produto, segmento), `TrilhaDeAlteracao` (quem, quando, diff). |
| Invariantes | (P1) Para cada tipo x escopo existe no máximo uma versão vigente por instante. (P2) Publicação exige status aprovado e pelo menos uma simulação em staging registrada com aquela versão (RF-06; `00-doc-negocio.md:L36`). (P3) Versão publicada é imutável; correção gera nova versão. (P4) Vigência agendada só para data futura; ao chegar a data, a versão anterior expira automaticamente. (P5) Quem aprova não pode ser quem editou (hipótese de governança, RF-10). (P6) Validação de esquema e de referências (ex.: produto do tier deve existir no catálogo) antes de sair de rascunho. |

**Comandos.** `CriarRascunho`, `EditarItens`, `EnviarParaStaging`, `AprovarVersao`, `PublicarVersao(imediata | agendada)`, `RevogarVersao`, `ClonarVersao`, `ConsultarVersaoVigente(tipo, escopo, instante)`.

**Eventos.** `VersaoParametroCriada`, `VersaoParametroEnviadaParaStaging`, `VersaoParametroAprovada`, `VersaoParametroPublicada`, `VersaoParametroAgendada`, `VersaoParametroExpirada`, `VersaoParametroRevogada`.

**Políticas.** Ao publicar, Cálculo invalida cache (AD-11) e passa a usar a nova versão. Modelagem lê a versão vigente no início do ciclo e a carimba na BRP gerada. Mudanças de catálogo (novo produto) não exigem código (RNF-07).

**Possui.** Todas as versões e trilhas. **Só lê.** Perfis (Identidade). **Não é responsabilidade.** Executar cálculo; decidir vigência de BRP (Publicação de Referência); guardar dados de clientes.

### 4.4 Modelagem de Preço (analítico)

**Responsabilidade.** Executar, por ciclo, o Pipeline de Preparação de Preços: tratar bases de origem, enriquecer com cadastro, aplicar janelas e exclusões, classificar tier e cluster, calcular percentis com referência corporate e monotonicidade, preço alvo, uplift, N, Matriz de Relacionamento e Indicadores de Reciprocidade. Atende M2 (produção). Requisitos: RF-08, RF-13, RNF-06. Decisão AD-01.

**Linguagem própria.** Este contexto fala em notebooks, workflows, dataframes, tabelas Delta, partições por `anomes`, expectations e lineage. Não modela agregados transacionais: seus "agregados" são datasets com contrato. Os sete notebooks (`07:L19`) tornam-se tarefas de um Databricks Workflow; listas fixas e datas hard-coded (`A0 §8.6`) viram leitura da versão vigente de parâmetros.

**Contrato publicado (Published Language) que entrega.** Um conjunto de tabelas Delta por `anomes`, com esquema versionado e validações declaradas:

| Dataset | Chave | Conteúdo mínimo |
|---|---|---|
| `mpa` (Matriz de Preço-Alvo por Cluster) | anomes, produto, tier, segmento, região | cluster, P25..P90, percentil-alvo, versão de parâmetros usada |
| `ppc` (Posição de Preço Cliente-Produto) | anomes, cd_grupo, segmento, produto | macroproduto, cluster, tier (a incluir; hoje ausente, `A2 §6`), qtde mensal/anual, receita, tarifa praticada, P25/P75/P90, preço alvo, uplift, N |
| `matriz_relacionamento` | anomes, cd_grupo, segmento | scores e rótulos de Stickiness e Impacto, insumos (ROB, receita cash, shares) |
| `indicadores_reciprocidade` | anomes, cd_grupo, segmento (+ produto) | saldo IF/DAV médio, SoW boletos, emissões L3M, share de cash |
| `preco_por_produto` (semestral) | anomes semestral, produto | preço sugerido de lista (regra da macro, a descobrir, `A0 §8.1`) |
| `qualidade_ciclo` | anomes, dataset, regra | resultado das validações (contagens, nulos, combinações sem percentil) |

**Eventos.** `CicloDeModelagemIniciado`, `BRPCashGerada` (anomes, versões de parâmetros, hashes), `ValidacaoDeQualidadeFalhou`.

**Políticas.** Nunca substitui bases de origem (RNF-06). Toda saída carrega a versão de parâmetros lida. Combinações sem percentil são marcadas, não descartadas silenciosamente.

**Possui.** Datasets intermediários e finais no Databricks. **Só lê.** Bases de origem, parâmetros vigentes. **Não é responsabilidade.** Ativar versão na base de serviço (Publicação); calcular preço online; aplicar desconto de relacionamento por cliente em tempo real.

### 4.5 Publicação de Referência (BRP Cash)

**Responsabilidade.** Receber a BRP gerada, validar, carregar via reverse ETL em staging da base de serviço, ativar a versão (swap atômico por `anomes`), manter catálogo de versões e permitir rollback. Atende M2 (publicação). Requisitos: RF-13, RNF-01, RNF-09. Decisões AD-02, AD-03, AD-13.

**Agregado `VersaoBRP`** (raiz). Entidades: `DatasetPublicado` (nome, contagem, hash, resultado de validação). VOs: `Anomes`, `StatusDaVersao` (gerada → validada → carregada em staging → ativa → substituída → revertida), `ResultadoDeValidacao`, `CarimboDeOrigem` (versão de parâmetros, run id do pipeline). Invariantes: (B1) só uma versão ativa por `anomes`-tipo e só uma versão "corrente" para o Cálculo por instante; (B2) ativação exige todas as validações críticas aprovadas; (B3) a versão anterior permanece disponível para rollback (AD-13); (B4) datasets de cadência distinta (mensal x semestral) têm vigência independente mas são resolvidos numa única "visão corrente" consumida pelo Cálculo.

**Comandos.** `RegistrarVersaoGerada`, `ValidarVersao`, `CarregarEmStaging`, `AtivarVersao`, `ReverterParaVersaoAnterior`, `ConsultarVersaoCorrente`.

**Eventos.** `VersaoBRPValidada`, `VersaoBRPCarregada`, `VersaoBRPAtivada`, `VersaoBRPRevertida`, `VersaoBRPRejeitada`.

**Políticas.** Ativação pode exigir aprovação humana (R10). Ao ativar, publica `VersaoBRPAtivada` para que Cálculo limpe caches e Reciprocidade recalcule realizado.

**Possui.** Catálogo de versões, resultados de validação, tabelas de serviço (MPA, PPC etc.) no `sql-motor`. **Só lê.** Delta da Modelagem. **Não é responsabilidade.** Calcular indicadores; decidir regras de validação de negócio (vêm da Parametrização).

### 4.6 Preço Vigente e Histórico (Legado) — contexto externo atrás de ACL

**Responsabilidade do contexto externo.** Sistemas de tarifas, contratos (ex.: `nseq_contr_negoc`, `vtarif`, `dinic_vgcia`, `02:L19`), eventos tarifados e histórico. Atende M3. Requisitos: RF-04, RNF-01. Decisão AD-10.

**O que o Adaptador de Legado traduz.** Códigos de tarifa (`CD_TARF`, `DESCR_TARIFA`) → produto do catálogo; contrato/modalidade → produto e visão Cliente/Banco; tarifa de contrato ou tarifa média observada → `PrecoPraticado` com origem e data; série mensal de 12 meses → `HistoricoDePreco` (VO: lista de (anomes, preço, volume)); CNPJ → grupo econômico (via Cadastro); unidades e formatos (`04:L16`). Duas estratégias: foto do ciclo (Databricks → `sql-motor`) e consulta online ao sistema de tarifas, selecionadas por parâmetro de frescor exigido pelo canal (`A0 §8.7`).

**Eventos (emitidos pelo adaptador).** `PrecoVigenteConsultado`, `TarifaEfetivada` [EVOLUÇÃO] (confirmação vinda do legado após comando da Reprecificação), `LegadoIndisponivel` (para contingência).

**Não é responsabilidade do motor.** Alterar dados no legado fora do comando de efetivação; reproduzir regras de tarifação do legado.

### 4.7 Reprecificação — [EVOLUÇÃO — a detalhar com o negócio]

**Responsabilidade (hipótese).** Planejar e executar ondas de reajuste: definir escopo e metas, selecionar elegíveis (entrada de C3 + filtros), calcular novo preço por cliente reusando o Cálculo com gradação Stickiness x Impacto, submeter à alçada, comunicar e efetivar, acompanhar resultado. Atende C2. Requisito RF-11. Decisão AD-08.

**Agregado `OndaDeReprecificacao`** (raiz). Entidades: `ItemDaOnda` (grupo, produto, praticado, sugerido, novo preço proposto, gradação aplicada, status). VOs: `EscopoDaOnda` (macroprodutos, segmentos, regiões), `Calendario`, `MetaDeUplift`, `CriterioDeElegibilidade`, `Gradacao` (fração do caminho até o alvo, por célula Stickiness x Impacto). Status: planejada → elegíveis selecionados → calculada → em aprovação → aprovada → comunicada → efetivada → acompanhada → encerrada. Invariantes (hipóteses): um cliente x produto em no máximo uma onda ativa; item só efetiva após `PrecoAprovado` ou nível "sem alçada"; novo preço ≥ praticado; itens com N < mínimo ou em lista de exceção ficam fora.

**Comandos.** `PlanejarOnda`, `SelecionarElegiveis`, `CalcularNovosPrecos` (chama `CalcularEmLote`), `SubmeterParaAprovacao`, `ComunicarClientes`, `EfetivarTarifas`, `AcompanharResultado`, `EncerrarOnda`.

**Eventos.** `OndaPlanejada`, `ElegiveisSelecionados`, `NovosPrecosCalculados`, `OndaSubmetidaParaAprovacao`, `ItemDaOndaAprovado`, `EfetivacaoSolicitada`, `TarifaEfetivada` (recebido do Legado), `ResultadoDaOndaApurado`.

**Perguntas em aberto.** O motor efetiva tarifa no legado ou só recomenda (`A0 §8.4`)? Qual a regra de gradação por célula da Matriz de Relacionamento (`06:L138` truncado)? Quais filtros de elegibilidade são bloqueio e quais são alerta? Como convive o preço semestral por produto com a matriz mensal (`A2 §9`)? A comunicação ao cliente é do motor ou do CRM?

### 4.8 Reciprocidade — [EVOLUÇÃO — a detalhar com o negócio]

**Responsabilidade (hipótese).** Registrar o acordo de reciprocidade firmado na negociação, monitorar o realizado com os Indicadores de Reciprocidade, detectar desvio com tolerâncias parametrizáveis e publicar elegibilidade e alertas. Atende C3. Requisito RF-12. Decisão AD-07.

**Agregado `AcordoDeReciprocidade`** (raiz). Entidades: `CompromissoAcordado` (dimensão: volumetria por produto, saldo IF/DAV, produtos contratados; valor; período), `Medicao` (anomes, realizado, fonte). VOs: `Tolerancia` (% ou absoluto, janela), `StatusDoAcordo` (vigente, em desvio, regularizado, encerrado), `ReferenciaDaCotacao` (cotação aprovada que originou o acordo). Invariantes (hipóteses): acordo nasce de uma cotação aprovada ou contratada; um compromisso por dimensão; desvio só é declarado após N medições consecutivas fora da tolerância (parametrizável).

**Comandos.** `RegistrarAcordo`, `AtualizarMedicao` (job periódico, AD-07), `AvaliarDesvio`, `RegularizarAcordo`, `EncerrarAcordo`.

**Eventos.** `AcordoReciprocidadeRegistrado`, `MedicaoAtualizada`, `DesvioReciprocidadeDetectado`, `ClienteElegivelParaReprecificacao` (Published Language consumida por C2), `AcordoRegularizado`, `AlertaAoGerenteEmitido`.

**Perguntas em aberto.** O que constitui "acordo" hoje e onde é registrado (`A0 §8.4`)? O acordo é por grupo ou por CNPJ? Quais indicadores contam (SoW boletos, saldo IF/DAV, emissões, share de cash) e com que peso? O desconto de relacionamento concedido é revertido automaticamente em caso de desvio? Qual o papel de `QTDE_CASH_CONC`/`QTDE_COB_CONC` (`A0 §8.10`)?

### 4.9 Contextos externos e genéricos

**Cadastro de Cliente e Grupo Econômico.** Dono de CNPJ → grupo, segmento e região. Todos os BCs são Conformist: usam os códigos como estão. Lacunas: CNPJ com dois grupos (`06:L24`, `A2 §9`), INSTITUCIONAL in/out (`A0 §8.5`).

**Identidade e Acesso.** Fornece o papel do usuário (gerente, aprovador nível n, parametrizador, aprovador de parâmetros). Alçada e Parametrização consomem.

**Auditoria e Observabilidade.** Recebe `CotacaoRegistrada`, eventos de versão e decisões de alçada em tabela append-only (RNF-03); métricas e tracing padrão ARO (AD-12).

---

## 5. Context Map

```mermaid
flowchart LR
  subgraph CANAIS["Canais"]
    SF["Calculadora Salesforce e outros canais"]
  end
  subgraph ONLINE["Motor online"]
    CALC["Cálculo de Preço"]
    ALC["Alçada e Aprovação"]
    PAR["Parametrização"]
    PUB["Publicação de Referência (BRP Cash)"]
    REP["Reprecificação (C2)"]
    REC["Reciprocidade (C3)"]
  end
  subgraph DADOS["Dados e inteligência"]
    MOD["Modelagem de Preço (Databricks)"]
  end
  subgraph EXTERNOS["Externos e genéricos"]
    LEG["Legado: Preço Vigente e Histórico"]
    CAD["Cadastro de Cliente e GE"]
    IAM["Identidade e Acesso"]
    AUD["Auditoria e Observabilidade"]
  end

  SF -- "D: Conformist / U: OHS + PL (REST)" --> CALC
  SF -- "D / U: OHS + PL (REST)" --> PAR
  SF -- "D / U: OHS + PL (REST)" --> REP
  PAR -- "U: Supplier / D: Customer" --> CALC
  PAR -- "U: Supplier / D: Customer" --> MOD
  PAR -- "U: Supplier / D: Customer (política de alçada)" --> ALC
  MOD -- "U: Supplier / D: Customer (Delta por anomes)" --> PUB
  PUB -- "U: Published Language (contrato BRP Cash) / D" --> CALC
  PUB -- "U: PL (indicadores) / D" --> REC
  LEG -- "U / D: ACL (Adaptador de Legado)" --> CALC
  CALC -- "U: Supplier / D: Customer (CalcularAlcada)" --> ALC
  REP -- "D: Customer / U: Supplier (CalcularEmLote)" --> CALC
  REP -- "D: Customer / U: Supplier (pedidos de aprovação)" --> ALC
  REC -- "U: PL via eventos (ClienteElegivelParaReprecificacao)" --> REP
  REP -- "D / U: ACL (EfetivarTarifas)" --> LEG
  CAD -- "U / D: Conformist" --> CALC
  CAD -- "U / D: Conformist" --> MOD
  IAM -- "U / D: Conformist" --> ALC
  CALC -. "eventos" .-> AUD
  PAR -. "eventos" .-> AUD
  ALC -. "eventos" .-> AUD
  style REP stroke-dasharray: 5 5
  style REC stroke-dasharray: 5 5
```

| Relação | Upstream (U) | Downstream (D) | Padrão | Contrato / integração | Justificativa | Risco |
|---|---|---|---|---|---|---|
| Canais → Cálculo de Preço | Cálculo | Canais (Salesforce, integradores) | Open Host Service + Published Language; canal é Conformist | REST síncrono via Axway (`/precos/{grupo}/{produto}/referencia`, `/precos/simulacoes`, `/cotacoes/{id}`; contratos no doc 06 §7) | Muitos consumidores, um contrato estável (RF-07; AD-05) | Lógica vazar para Apex (R6) |
| Canais → Parametrização / Reprecificação | Parametrização, Reprecificação | Telas Salesforce | OHS + PL | REST síncrono | Telas são canal, não dono da regra | UX administrativa no Salesforce (AD-05) |
| Parametrização → Cálculo | Parametrização | Cálculo | Customer/Supplier | REST `ConsultarVersaoVigente` + evento `VersaoParametroPublicada` (cache) | Cálculo define o que precisa; Parametrização entrega com SLA | Versão vigente inconsistente entre instâncias (cache, AD-11) |
| Parametrização → Modelagem | Parametrização | Modelagem | Customer/Supplier | Leitura de tabela publicada (JDBC ou snapshot Delta) no início do ciclo | Elimina listas hard-coded (`A0 §8.6`) | Pipeline usar versão diferente da online |
| Parametrização → Alçada | Parametrização | Alçada | Customer/Supplier | REST + evento | Política de alçada é parâmetro versionado | Conteúdo de `premissas_alcada` desconhecido |
| Modelagem → Publicação | Modelagem | Publicação | Customer/Supplier | Tabelas Delta por `anomes` + evento `BRPCashGerada` (Jobs API) | Publicação valida e ativa; Modelagem não conhece a base de serviço | Contrato de esquema quebrar (R3) |
| Publicação → Cálculo | Publicação | Cálculo | Published Language | Contrato de dados da BRP Cash em `sql-motor` (tabelas MPA, PPC, ...) + evento `VersaoBRPAtivada` | Um único contrato consumido por vários (Cálculo, Reciprocidade, relatórios) | Ativação parcial entre datasets (B4) |
| Publicação → Reciprocidade | Publicação | Reciprocidade | Published Language | Tabela `indicadores_reciprocidade` + evento | Indicadores continuam vindo do Databricks (AD-07) | [EVOLUÇÃO] |
| Legado → Cálculo | Legado | Cálculo | Anti-Corruption Layer (Adaptador de Legado) | REST interno do adaptador; por trás, foto em `sql-motor` ou consulta online | Legado tem modelo e códigos próprios (`CD_TARF`, contratos) | Latência e disponibilidade (R4) |
| Cálculo → Alçada | Cálculo | Alçada | Customer/Supplier | REST síncrono `CalcularAlcada`; retorno embutido na cotação | Evita Shared Kernel; Alçada evolui sem alterar Cálculo | Chamada extra na simulação (RNF-02) |
| Reprecificação → Cálculo | Cálculo | Reprecificação | Customer/Supplier | REST `CalcularEmLote` (assíncrono com callback ou paginado) | Reuso do motor (AD-08) | [EVOLUÇÃO] volume em lote |
| Reprecificação → Alçada | Alçada | Reprecificação | Customer/Supplier | REST + eventos `ItemDaOndaAprovado` | Mesma política para simulação e onda | [EVOLUÇÃO] |
| Reciprocidade → Reprecificação | Reciprocidade | Reprecificação | Published Language via eventos | Tópico `sb-eventos`: `ClienteElegivelParaReprecificacao`, `DesvioReciprocidadeDetectado` | Dependência de dados, não de estrutura (`A0 §3`) | Service Bus fora da stack (R5); fallback outbox |
| Reprecificação → Legado | Legado | Reprecificação | ACL | Comando `EfetivarTarifas` via Adaptador; confirmação `TarifaEfetivada` | Escrita no legado exige tradução e idempotência | Negócio não decidiu se o motor efetiva (`A0 §8.4`) |
| Cadastro → todos | Cadastro | Cálculo, Modelagem, Reciprocidade | Conformist | Tabelas de segmentos/grupo/região via Databricks e `sql-motor` | Não há poder de negociação sobre o cadastro corporativo | CNPJ com dois grupos; INSTITUCIONAL |
| Identidade → Alçada, Parametrização | Identidade | Alçada, Parametrização | Conformist | Claims OAuth2 (Axway) + perfis Salesforce/AD | Padrão institucional (AD-12) | Mapeamento papel ↔ nível de alçada |
| Todos → Auditoria | Cada BC | Auditoria | Published Language (eventos) | Eventos de domínio em tabela append-only | RNF-03 | Volume do histórico de cotações (AD-02 reavaliação) |

Não há Shared Kernel. A opção por Customer/Supplier entre Cálculo/Reprecificação e Alçada segue `A0 §5`: o "modelo de nível de alçada" trafega como VO no contrato (código, nome, papel), sem código compartilhado.

---

## 6. Fluxos entre contextos

### 6.1 Simulação de preço com alçada (C1)

```mermaid
sequenceDiagram
  autonumber
  participant SF as Calculadora Salesforce
  participant GW as Axway
  participant CALC as Cálculo de Preço
  participant PRM as Parametrização
  participant PUB as BRP Cash (versão ativa)
  participant LEG as Adaptador de Legado
  participant ALC as Alçada e Aprovação
  participant AUD as Auditoria
  SF->>GW: POST /precos/simulacoes (grupo, produtos, volumetria, preço negociado)
  GW->>CALC: SimularPreco
  CALC->>PRM: ConsultarVersaoVigente (cache)
  PRM-->>CALC: versões por tipo
  CALC->>PUB: ler MPA, PPC, Matriz de Relacionamento, Indicadores
  PUB-->>CALC: dados do anomes ativo
  CALC->>LEG: ConsultarPrecoVigente + histórico 12m
  LEG-->>CALC: PrecoPraticado (origem, data)
  CALC->>CALC: tier, cluster, alvo = max(praticado, P75), sugerido, cenários, uplift
  alt preço negociado < sugerido
    CALC->>ALC: CalcularAlcada(desvio %, R$, escopo)
    ALC-->>CALC: AlcadaCalculada (nível, papel aprovador)
    CALC->>ALC: AbrirPedidoDeAprovacao (opcional, se canal solicitar)
    ALC-->>AUD: PedidoDeAprovacaoAberto
  else negociado >= sugerido ou ausente
    CALC->>CALC: sem alçada (contratação direta)
  end
  CALC-->>AUD: CotacaoRegistrada (carimbo de versões)
  CALC-->>GW: Cotacao (praticado, alvo, sugerido, cenários, uplift, alçada)
  GW-->>SF: 200 Cotacao
  opt aprovação posterior
    ALC-->>SF: PrecoAprovado / PrecoReprovado (evento -> notificação)
  end
```

### 6.2 Publicação de nova versão de parâmetros e de nova versão da BRP Cash

```mermaid
sequenceDiagram
  autonumber
  participant PZ as Parametrizador (Salesforce)
  participant PRM as Parametrização
  participant CALC as Cálculo de Preço
  participant CM as Control-M
  participant MOD as Modelagem de Preço (dbx-ppp)
  participant PUB as Publicação de Referência
  participant SQL as sql-motor
  participant BUS as sb-eventos
  PZ->>PRM: CriarRascunho / EditarItens (ex.: faixas de tier)
  PZ->>PRM: EnviarParaStaging
  PZ->>CALC: SimularEmStaging (versão em staging)
  CALC-->>PZ: Cotacao de teste (carimbo: versão staging)
  PZ->>PRM: AprovarVersao (aprovador distinto)
  PZ->>PRM: PublicarVersao (imediata ou agendada)
  PRM-->>BUS: VersaoParametroPublicada / VersaoParametroAgendada
  BUS-->>CALC: invalidar cache, usar nova versão
  Note over PRM,MOD: Novo ciclo de precificação (anomes)
  CM->>MOD: disparar workflow (Jobs API)
  MOD->>PRM: ler versão vigente de parâmetros
  MOD->>MOD: 7 tarefas: tier, cluster, percentis, alvo, uplift, Stickiness x Impacto, indicadores
  MOD-->>PUB: BRPCashGerada (anomes, run id, versões)
  PUB->>PUB: ValidarVersao (contagens, nulos, combinações sem percentil)
  PUB->>SQL: CarregarEmStaging (JDBC, tabelas *_stg)
  PUB->>PUB: AtivarVersao (procedure de swap atômico por anomes)
  PUB-->>BUS: VersaoBRPAtivada
  BUS-->>CALC: usar anomes ativo, limpar cache MPA
  opt problema após ativação
    PUB->>SQL: ReverterParaVersaoAnterior
    PUB-->>BUS: VersaoBRPRevertida
  end
```

### 6.3 [EVOLUÇÃO — a detalhar com o negócio] Desvio de reciprocidade → elegibilidade → onda → aprovação → efetivação

```mermaid
sequenceDiagram
  autonumber
  participant PUB as BRP Cash (Indicadores)
  participant REC as Reciprocidade
  participant BUS as sb-eventos
  participant REP as Reprecificação
  participant CALC as Cálculo de Preço
  participant ALC as Alçada e Aprovação
  participant SF as Salesforce (gerente / aprovador)
  participant LEG as Adaptador de Legado
  PUB-->>REC: VersaoBRPAtivada (novos indicadores)
  REC->>REC: AtualizarMedicao (acordado x realizado) e AvaliarDesvio (tolerâncias)
  REC-->>BUS: DesvioReciprocidadeDetectado
  REC-->>SF: AlertaAoGerenteEmitido
  REC-->>BUS: ClienteElegivelParaReprecificacao
  BUS-->>REP: consumir elegibilidade
  REP->>REP: PlanejarOnda (escopo, calendário, meta) e SelecionarElegiveis (C3 + filtros)
  REP->>CALC: CalcularEmLote (itens da onda, gradação Stickiness x Impacto)
  CALC-->>REP: NovosPrecosCalculados (com carimbo de versões)
  REP->>ALC: AbrirPedidoDeAprovacao por item com desvio
  ALC-->>SF: PedidoDeAprovacaoAberto
  SF->>ALC: AprovarPedido / ReprovarPedido
  ALC-->>BUS: PrecoAprovado
  BUS-->>REP: ItemDaOndaAprovado
  REP->>SF: ComunicarClientes (via CRM, hipótese)
  REP->>LEG: EfetivarTarifas (decisão de escopo em aberto)
  LEG-->>BUS: TarifaEfetivada
  BUS-->>REP: atualizar item, AcompanharResultado
  REP-->>REC: RegistrarAcordo (novo acordo pós-reprecificação, hipótese)
```

---

## 7. Mapeamento BC → componentes de solução

| Bounded context | Componentes (nomes canônicos, `A0 §6`) | Observação |
|---|---|---|
| Cálculo de Preço | `svc-pricing` (Java/Spring no `aro`), lê `sql-motor`; exposto por `apigw-axway` atrás de `appgw-azure` e `akamai` | Cache Caffeine de parâmetros e MPA (AD-11); histórico de cotações em `sql-motor` (reavaliar MongoDB por volume, AD-02) |
| Alçada e Aprovação | `svc-alcada`, tabelas de pedidos/decisões em `sql-motor`; publica em `sb-eventos` | Política vem de `svc-parametros` |
| Parametrização | `svc-parametros`, tabelas versionadas em `sql-motor`; telas em `sf-parametrizacao` | Endpoint de simulação em staging chama `svc-pricing` (AD-06) |
| Modelagem de Preço | `dbx-ppp` (Databricks Workflows), disparado por `controlm`; escreve em `dbx-brp` | Sete notebooks portados (AD-01) |
| Publicação de Referência | `svc-publicacao` (catálogo de versões, ativação, rollback) + job de reverse ETL JDBC de `dbx-brp` para `sql-motor` (AD-03) | Procedure de swap por `anomes` |
| Legado (ACL) | `svc-legado-adapter`; foto em `sql-motor` via `dbx-brp`; consulta online ao sistema de tarifas (AD-10) | Duas estratégias por parâmetro de frescor |
| Reprecificação [EVOLUÇÃO] | `svc-reprecificacao`, telas em `sf-reprecificacao`, consome `sb-eventos`, chama `svc-pricing` e `svc-alcada` (AD-08) | Pré-seleção analítica pode rodar em `dbx-ppp` |
| Reciprocidade [EVOLUÇÃO] | `svc-reciprocidade` + job periódico via `controlm`; acordo em `sql-motor`; indicadores em `dbx-brp`/`sql-motor`; publica em `sb-eventos` (AD-07) | |
| Cadastro de Cliente e GE | Tabelas de cadastro replicadas em `dbx-brp` e `sql-motor` | Externo |
| Identidade e Acesso | OAuth2 no `apigw-axway`, perfis Salesforce/AD (AD-12) | Genérico |
| Auditoria e Observabilidade | Tabela append-only em `sql-motor`; logs, métricas e tracing do `aro` (AD-12) | Genérico |
| Canais | `sf-calculadora`, `sf-parametrizacao`, `sf-reprecificacao` (LWC + Named Credentials) | Sem lógica de negócio em Apex (AD-05) |

Nota de nomenclatura: este documento usa nomes de domínio; os docs 06, 07 e 08 usam os nomes de implementação. Correspondências: evento `VersaoBRPAtivada` = `VersaoBrpPublicada` (tópico `mpc.publicacao`); `PedidoDeAprovacaoAberto` = `PedidoAprovacaoCriado`; `PrecoReprovado` = `PrecoRecusado`; `AcordoReciprocidadeRegistrado` = `AcordoRegistrado`; datasets `mpa`, `ppc`, `matriz_relacionamento`, `indicadores_reciprocidade` = tabelas `brp.matriz_preco_alvo_cluster`, `brp.posicao_preco_cliente_produto`, `brp.matriz_relacionamento`, `brp.indicadores_reciprocidade` (doc 06 §5.1 e §6).

---

## 8. Decisões de modelagem e alternativas consideradas

| # | Decisão | Alternativa considerada | Avaliação |
|---|---|---|---|
| DM-01 | **Alçada e Aprovação como BC próprio**, relação Customer/Supplier com Cálculo e Reprecificação. | Alçada dentro do Cálculo de Preço. | Alçada tem ciclo de vida próprio (pedido, decisão, expiração) e dois clientes (C1 e C2). Dentro do Cálculo, o histórico de cotações e o workflow de aprovação se misturariam. Custo: uma chamada síncrona a mais na simulação (RNF-02). |
| DM-02 | **Reciprocidade separada de Reprecificação** (reproduz `A0 §3`). | C3 como sub-capacidade de C2. | (1) C3 começa na contratação e roda continuamente, com ou sem onda; (2) serve outros consumidores (gerente, manutenção de descontos, alertas); (3) C3 publica `ClienteElegivelParaReprecificacao` e C2 consome. A dependência C2 → C3 é de dados, não de estrutura. |
| DM-03 | **Parâmetros como dados versionados** interpretados por estratégias em código (AD-04). | Engine de regras (FICO Blaze/DM). | As regras atuais são tabelas de faixas (tier, cluster, percentil, desconto, alçada). Cabem no agregado `ConjuntoDeParametros`. FICO só se em C2 surgirem políticas de gradação complexas. |
| DM-04 | **Modelagem como BC próprio com Published Language**, separado de Publicação. | Um único BC "Dados". | Modelagem fala Delta/dataframes; Publicação fala versão ativa, validação e rollback na base de serviço. Separar permite trocar o mecanismo de reverse ETL (AD-03) sem tocar o pipeline. |
| DM-05 | **Cotação imutável com carimbo de versões** como raiz do Cálculo. | Cálculo sem estado (só resposta). | RNF-09 exige reproduzir qualquer preço; C2 e Reciprocidade referenciam cotações. |
| DM-06 | **Sem Shared Kernel** para nível de alçada. | Shared Kernel pequeno. | `A0 §5`: evitar acoplamento de código entre times; o nível trafega como VO no contrato. |
| DM-07 | **Legado atrás de ACL com duas estratégias**. | Só foto (Databricks) ou só online. | `A0 §8.7`: latência aceitável é decisão do negócio; o adaptador isola a escolha. |
| DM-08 | **Preço sugerido calculado online no Cálculo**, não pré-computado no pipeline. | Pré-computar sugerido na PPC. | O sugerido depende de premissas com vigência própria e de exceções comerciais que mudam entre ciclos; pré-computar quebraria RF-06 (staging) e RF-07 (informação mais atual). O preço alvo, sim, é pré-computado. |

---

## 9. Lacunas de domínio e próximos passos de modelagem

Lacunas (lista única do `A0 §8`) com o BC afetado:

| # | Lacuna | BC afetado | Efeito na modelagem |
|---|---|---|---|
| 1 | Regras da macro "Preço por Produto"/"Resumo por GE" e do SQL 010 não documentadas | Cálculo de Preço, Modelagem | Política de composição do sugerido é hipótese (DM-08); R1 |
| 2 | Conteúdo de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto`, `regiao_por_ge` desconhecido | Parametrização, Alçada | Estrutura dos tipos de parâmetro é hipótese |
| 3 | Definição formal de sugerido x alvo e da regra de alçada | Cálculo, Alçada | Invariantes I2 e faixas de desvio a validar |
| 4 | C2 e C3 sem detalhamento | Reprecificação, Reciprocidade | Agregados inteiros marcados [EVOLUÇÃO] |
| 5 | Inconsistências entre fluxos (INSTITUCIONAL, cluster Arrecadação, grupo 616, produto sem cluster, CANAIS DIGITAIS e DÉBITO AUTOMÁTICO sem fonte) | Parametrização, Modelagem | Decisões viram itens do catálogo e da regra de cluster por produto |
| 6 | Datas hard-coded e listas fixas | Parametrização, Modelagem | Tipo "janelas temporais" e "catálogo" |
| 7 | Latência aceitável do preço vigente | Legado (ACL) | Parâmetro de frescor por canal |
| 8 | Trechos truncados nos docs fonte | Modelagem | Clusters "demais" de Cobrança e gradação Stickiness x Impacto |
| 9 | Service Bus fora da stack | Reciprocidade → Reprecificação, Publicação → Cálculo | Fallback outbox + polling mantém o padrão PL via eventos |
| 10 | Semântica de N e dos campos `*_CONC` | Modelagem, Reciprocidade | Invariante de representatividade e indicadores de concorrência |

Próximos passos de modelagem (fase F0 e F3 do roadmap):

1. **Validar a linguagem ubíqua** (seção 2) com o time de Precificação e o OPCH, em especial as três definições de preço e o termo "cotação".
2. **Event storming de C1** (meio dia) com Precificação, Comercial e TI para confirmar comandos, eventos e invariantes do Cálculo e da Alçada; usar como entrada a engenharia reversa da macro e do SQL 010 (R1).
3. **Workshop do catálogo de parâmetros**: fechar os tipos, escopos, chaves e regras de validação a partir das 34 famílias de `A1` e da lista de `A2`; decidir as inconsistências da lacuna 5.
4. **Contrato de dados da BRP Cash**: esquema, chaves, validações e cadências dos seis datasets da seção 4.4; incluir tier na PPC.
5. **Event storming de C2/C3** (F3, dois dias): mapear o ciclo real de uma onda (a partir da "Onda 4", `07:L18`) e o que hoje é "acordo" na negociação; decidir efetivação no legado; fechar gradação por célula da Matriz de Relacionamento e tolerâncias de desvio. Resultado: promover os agregados das seções 4.7 e 4.8 de hipótese a modelo.
6. **Decisão sobre mensageria** (R5) antes de F1, pois o padrão Published Language via eventos aparece já na publicação de versões.
