# 03 — Desenho Conceitual do Motor de Precificação Cash

| Campo | Valor |
|---|---|
| Título | Desenho conceitual: visão de todas as camadas de negócio e suas capacidades |
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Fontes | `anexos/A0-brief-decisoes.md` (nomes, IDs, camadas, definições), `anexos/A1-analise-fluxos-produtos.md`, `anexos/A2-analise-fluxos-consolidacao.md`, `docs-precificacao/00-doc-negocio.md`, `docs-precificacao/00-etapas-geracao-planilha-ano1.md`, `docs-precificacao/01` a `07` |

---

## 1. Introdução e como ler

Este documento apresenta o desenho conceitual do **Motor de Precificação Cash (MPC)**, organizado em seis camadas de negócio (Estratégia, Canais e jornadas, Capacidades, Módulos transversais, Dados e inteligência, Legado e fontes) e nas três capacidades de negócio identificadas: **C1 Cálculo, Simulação e Entrega de Preços** (prioritária, funciona hoje de forma manual e fragmentada), **C2 Onda de Reprecificação** e **C3 Gestão de Reciprocidade** (ambas marcadas como **[EVOLUÇÃO — a detalhar com o negócio]**). Para cada camada e capacidade descrevemos o que é, quem atua, o que entrega e o que consome, sempre com a situação atual (AS-IS: Planilha Preço Ano 1, SAS, Servidor SQL 010 e Calculadora Salesforce) e a situação-alvo (TO-BE: motor online com parâmetros versionados e a Base de Referência de Preços Cash). Nos diagramas, tudo o que é evolução aparece tracejado. Toda afirmação de regra tem referência de linha ao documento fonte no formato `docs-precificacao/<arquivo>:L<linha>`, abreviado para `NN:L<linha>` quando o arquivo é um dos fluxos 01 a 07 (por exemplo, `07:L29` é `docs-precificacao/07-planilha-ano1-fluxo.md:L29`) e para `00-etapas:L<linha>` no caso de `00-etapas-geracao-planilha-ano1.md`; `A1` e `A2` são os anexos `anexos/A1-analise-fluxos-produtos.md` e `anexos/A2-analise-fluxos-consolidacao.md`. O que foi deduzido pelo analista está marcado como **(inferido)**. A rastreabilidade completa de cada capacidade está no documento `04-capacidades-rastreabilidade.md`.

## 2. Diagrama conceitual em camadas

```mermaid
flowchart TB
  subgraph L1["1. Estratégia de negócio"]
    direction LR
    E1["Monetizar payments no Atacado<br/>uplift com política nunca reduzir"]
    E2["Padronizar preço por cluster"]
    E3["Autonomia comercial<br/>com alçada controlada"]
    E4["Reter clientes e garantir<br/>reciprocidade dos acordos"]
    E5["Governança e auditoria<br/>dos parâmetros"]
  end

  subgraph L2["2. Canais e jornadas"]
    direction LR
    K1["sf-calculadora<br/>Calculadora Salesforce FSC"]
    K2["Jornada de contratação<br/>sem alçada"]
    K3["sf-parametrizacao<br/>Telas de parametrização"]
    K4["sf-reprecificacao<br/>Telas de onda e aprovação"]
    K5["APIs para outros canais,<br/>plataformas e integradores<br/>apigw-axway"]
  end

  subgraph L3["3. Capacidades de negócio"]
    direction LR
    C1["C1 Cálculo, Simulação e<br/>Entrega de Preços<br/>PRIORITÁRIA"]
    C2["C2 Onda de Reprecificação<br/>[EVOLUÇÃO]"]
    C3["C3 Gestão de Reciprocidade<br/>[EVOLUÇÃO]"]
  end

  subgraph L4["4. Módulos transversais"]
    direction LR
    M1["M1 Parametrização<br/>versões, staging, vigência"]
    M4["M4 Governança, Auditoria<br/>e Segurança"]
  end

  subgraph L5["5. Dados e inteligência"]
    direction LR
    M2["M2 Pipeline de Preparação<br/>de Preços dbx-ppp"]
    MOD["Modelos: tier, cluster, percentis,<br/>uplift, stickiness x impacto"]
    BRP[("BRP Cash por anomes<br/>MPA, PPC, Matriz de Relacionamento,<br/>Indicadores de Reciprocidade")]
  end

  subgraph L6["6. Legado e fontes"]
    direction LR
    SRC["Sistemas de origem<br/>eventos tarifados, movimento, contratos,<br/>segmentos, ROB, IF/DAV, shares"]
    M3["M3 Adaptador de Legado<br/>preço vigente e histórico 12 meses"]
    OLD["SAS + SQL 010 + Planilha<br/>a desligar"]
  end

  E1 -.-> C1
  E3 -.-> C1
  E2 -.-> M2
  E4 -.-> C3
  E5 -.-> M1

  K1 --> C1
  K2 --> C1
  K5 --> C1
  K3 --> M1
  K4 --> C2

  C3 -.->|"evento ClienteElegivel"| C2
  C2 -.->|"reusa simulação em lote"| C1

  M1 --> C1
  M1 -.-> C2
  M1 -.-> C3
  M1 --> M2
  M4 --> C1
  M4 --> M1

  SRC --> M2
  M2 --> MOD
  MOD --> BRP
  BRP --> C1
  BRP -.-> C3
  M3 --> C1
  SRC --> M3
  C2 -.->|"efetivação de tarifa: lacuna"| M3
  OLD -.->|"shadow run e desligamento"| C1

  style C2 stroke-dasharray: 5 5
  style C3 stroke-dasharray: 5 5
  style K4 stroke-dasharray: 5 5
  style OLD stroke-dasharray: 5 5
```

Leitura do diagrama: os fluxos principais são (i) **fontes → pipeline → BRP Cash → motor → canais**, que é o caminho de C1; (ii) **C3 → C2**, em que a reciprocidade publica elegibilidade para a onda; (iii) **C2 → C1**, em que a onda reusa o motor de cálculo em lote; e (iv) **parametrização → tudo**, já que M1 alimenta o motor online, o pipeline e as capacidades de evolução. As setas tracejadas indicam relações que só existirão nas fases F3 e F4 do roadmap ou cuja definição depende do negócio.

## 3. Descrição das camadas

### 3.1 Estratégia de negócio

**O que é.** Os objetivos que justificam o motor, derivados do business case de Pricing Cash e de `docs-precificacao/00-doc-negocio.md:L1-3`: monetizar os produtos de payments no Atacado levando cada tarifa ao patamar do seu cluster com política "nunca reduzir" (`01-cobrança-fluxo.md:L112`, `L133`); padronizar preço por cluster de volume, segmento e região; dar autonomia ao comercial com alçada controlada (`00-doc-negocio.md:L22`); reter clientes por meio da matriz Stickiness x Impacto (`06-matriz-stickiness-impacto-fluxo.md:L5`) e garantir reciprocidade dos acordos; e governar parâmetros com versionamento e auditoria (`00-doc-negocio.md:L13-14`).

**Quem atua.** Diretoria de Cash/Payments e o time de Precificação, responsável por regras, parâmetros e políticas (`00-doc-negocio.md:L26`, `L33`).

**O que entrega.** Metas de uplift por ciclo, política de preço (percentil-alvo, exceções), prioridades de produto e segmento.

**O que consome.** Resultado das ondas, acompanhamento do uplift realizado x estimado (`05-uplift-consolidado-fluxo.md:L39`), indicadores de retenção.

### 3.2 Canais e jornadas

**O que é.** As interfaces pelas quais pessoas e sistemas usam o motor. Hoje existe apenas a Calculadora Salesforce alimentada por SAS e SQL 010 (`07-planilha-ano1-fluxo.md:L40-42`, `L114`). No TO-BE: `sf-calculadora` (Calculadora Salesforce FSC para gerente e comercial), jornada de contratação sem alçada no preço sugerido (`00-doc-negocio.md:L22`), `sf-parametrizacao` (telas do time de Precificação), `sf-reprecificacao` (telas de onda e aprovação, evolução) e APIs publicadas no `apigw-axway` para outros canais, plataformas e integradores (`00-doc-negocio.md:L15-16`, `L31-32`). Conforme AD-05, Salesforce é canal: nenhuma regra de negócio em Apex.

**Quem atua.** Gerente comercial, aprovadores de alçada, time de Precificação, sistemas integradores.

**O que entrega.** Simulações, contratações, pedidos de aprovação, parametrizações, decisões de onda.

**O que consome.** APIs de C1 (consulta e simulação), M1 (parametrização), C2 (onda) e os eventos de C3 (alertas ao gerente).

### 3.3 Capacidades de negócio

**O que é.** O núcleo funcional: C1 calcula e entrega preços (praticado, alvo, sugerido, cenários, alçada); C2 organiza ondas de reprecificação de carteira; C3 registra e monitora a reciprocidade acordada na negociação. C1 é prioritária porque hoje já funciona, embora de forma manual; C2 e C3 têm apenas insumos analíticos prontos e nenhuma regra de negócio documentada (ver seções 5 e 6).

**Quem atua.** Gerente comercial e aprovadores (C1), time de Precificação (C2), gerente comercial e Precificação (C3).

**O que entrega / consome.** Ver seções 4 a 6 e a matriz de interações na seção 10.

### 3.4 Módulos transversais

**O que é.** M1 Parametrização, com versionamento, staging, vigência agendada e perfis (`00-doc-negocio.md:L8-9`, `L13`, `L17-18`, `L42`); M4 Governança, Auditoria e Segurança, com logs de execução e de mudança de parâmetro, perfis, alçadas, monitoramento e contingência (`00-doc-negocio.md:L14`, `L18`, `L20`, `L39-40`). Ambos são necessários desde a fase F1 porque C1 não é auditável nem calibrável sem eles.

### 3.5 Dados e inteligência

**O que é.** M2, o **Pipeline de Preparação de Preços (PPP)** no Databricks, que porta os sete notebooks atuais (`07-planilha-ano1-fluxo.md:L19-20`) para Databricks Workflows e produz a **BRP Cash** versionada por `anomes`, com as entidades Matriz de Preço-Alvo por Cluster (MPA), Posição de Preço Cliente-Produto (PPC), Matriz de Relacionamento e Indicadores de Reciprocidade. Inclui os modelos de tier, cluster, percentis, uplift e stickiness x impacto, e a publicação por reverse ETL para a base de serviço do motor (AD-01, AD-02, AD-03).

**Quem atua.** Engenharia de dados e o time de Precificação (validação de cada ciclo).

**O que entrega.** Uma versão da BRP Cash por Ciclo de Precificação, validada e ativada.

**O que consome.** As bases de origem já ingeridas no Databricks (`00-doc-negocio.md:L27-28`, `00-etapas-geracao-planilha-ano1.md:L5-18`) e os parâmetros de M1 (tiers, cluster, percentis, janelas).

### 3.6 Legado e fontes

**O que é.** M3: os sistemas de origem (eventos tarifados, movimento, contratos, segmentos, ROB, Invest Fácil/DAV, share BACEN/cash/boletos), o preço vigente e o histórico de 12 meses (`00-doc-negocio.md:L11-12`, `L29`), e a cadeia de distribuição atual SAS → SQL 010 → Salesforce (`07-planilha-ano1-fluxo.md:L37-42`), que será desligada gradualmente (AD-14). O motor acessa o legado pelo **Adaptador de Legado** (AD-10), nunca diretamente.

## 4. Capacidade C1 — Cálculo, Simulação e Entrega de Preços (prioritária)

### 4.1 Visão geral

C1 é o que a Calculadora Salesforce faz hoje para o gerente: dado cliente, produto e volumetria, mostrar preço-alvo por cluster, saldos e share, e permitir simular um preço (`07-planilha-ano1-fluxo.md:L5`, `L40-42`). O cálculo efetivo ocorre em três lugares não documentados: a macro da planilha ("Preço por Produto" e "Resumo por GE", `07:L29-31`), as premissas em Excel (`07:L78-80`) e o Motor da Calculadora no Servidor SQL 010, que "contém regra de negócio" (`07:L41`, `L114`). No TO-BE, todo esse cálculo passa a ser executado por `svc-pricing` e `svc-alcada` em tempo real, com parâmetros versionados e dados da BRP Cash.

### 4.2 Sub-capacidades

| ID | Sub-capacidade | Descrição | AS-IS (como é feito hoje) | TO-BE (motor) |
|---|---|---|---|---|
| C1.1 | Consulta de preço alvo, sugerido e praticado | Retornar os três preços por cliente x produto (`00-doc-negocio.md:L3`, `L7`; `00-etapas:L1`). Alvo = max(tarifa atual, P75 do cluster) (`01:L112`; `02:L52`; `03:L62`; `04:L78`). Praticado = TARIFA da Base Pricing (`05:L38`) ou tarifa de contrato (`02:L19`). Sugerido = alvo ajustado por desconto de saldo IF/DAV e premissas (`06:L137`; `07:L79`) **(inferido)**. | Planilha: aba Base Pricing e Tabela de Preços (`07:L22-23`); macro gera "Preço por Produto"; SAS publica `SIMUL_PRC_ALVO_CLUSTER` e `SIMUL_PRECO_POR_PRODUTO` (`07:L105-106`); SQL 010 aplica a regra final. | `svc-pricing` lê MPA e PPC do ciclo ativo em `sql-motor`, aplica `premissas_desconto` versionadas em M1 e devolve os três preços com a versão de parâmetro e de BRP usada. |
| C1.2 | Simulação e cenários | Simular sem efetivar tarifa (`00-doc-negocio.md:L10`), expondo faixas por percentil, sensibilidade a tier e efeito do relacionamento (brief §2). | Calculadora Salesforce mostra o preço do cluster; o gerente digita o valor negociado. Percentis P25 a P90 existem na Tabela de Preços (`05:L20`) mas o uso como cenário é **(inferido)**. | Endpoint de simulação devolve a tabela de cenários da seção 4.4, com uplift anual estimado por cenário (fórmulas de `01:L116`). |
| C1.3 | Cálculo de alçada e indicação do aprovador | Quando o preço negociado fica abaixo do sugerido, calcular desvio e nível de alçada; sem alçada quando igual ou acima (`00-doc-negocio.md:L22`). | `premissas_alcada.xlsx` (`07:L79`), conteúdo não documentado; a Calculadora indica a necessidade de aprovação **(inferido)**. | `svc-alcada` consulta `premissas_alcada` parametrizadas por produto, segmento e faixa de desvio; registra o pedido de aprovação e o papel aprovador. |
| C1.4 | Consulta de preço vigente e histórico de 12 meses | Exibir o preço vigente e a série de 12 meses vinda do legado (`00-doc-negocio.md:L11-12`, `L29`). | A Base Pricing carrega a foto do ciclo (`05:L30-33`); a tarifa de contrato vem de `contratos_multipag.csv` (`02:L19`); não há consulta online. | `svc-legado-adapter` com duas estratégias (foto via Databricks ou consulta online), conforme AD-10; a latência aceitável é decisão pendente (brief §8 item 7). |
| C1.5 | APIs para canais | Expor consulta e simulação a Salesforce e a outros canais, plataformas e integradores, com a informação mais atual disponível (`00-doc-negocio.md:L15-16`, `L31`). | Só existe a Calculadora Salesforce, alimentada por cópia manual e SAS (`07:L34-42`). | APIs REST no `apigw-axway` (Open Host Service), OAuth2, contrato publicado; Salesforce via LWC e Named Credentials (AD-05). |
| C1.6 | Rastreabilidade das execuções | Registrar cada execução com entradas, saídas, versão de parâmetros e de BRP, e responsável (`00-doc-negocio.md:L14`). | Inexistente: processo manual em planilha sem versionamento nem log (A2 §Fluxo 07 item 9). | Tabela de auditoria append-only por simulação e por pedido de alçada (AD-12); atende RF-09 e RNF-03/RNF-09. |

### 4.3 Jornada de simulação (TO-BE)

```mermaid
sequenceDiagram
  autonumber
  actor G as Gerente comercial
  participant SF as sf-calculadora (Salesforce FSC)
  participant GW as apigw-axway
  participant P as svc-pricing (C1)
  participant PRM as svc-parametros (M1)
  participant BRP as sql-motor / BRP Cash (M2)
  participant LEG as svc-legado-adapter (M3)
  participant AL as svc-alcada (C1.3)
  participant AUD as Auditoria (M4)

  G->>SF: Seleciona cliente, produto, volumetria e preço negociado
  SF->>GW: POST /mpc/v1/precos/simulacoes (OAuth2)
  GW->>P: Encaminha requisição
  P->>PRM: Versão vigente de parâmetros (tiers, cluster, percentis, premissas)
  PRM-->>P: Parâmetros v.N
  P->>BRP: MPA, PPC, Matriz de Relacionamento e Indicadores (ciclo anomes ativo)
  BRP-->>P: Percentis do cluster, preço alvo, stickiness x impacto, saldos IF/DAV
  P->>LEG: Preço vigente e histórico de 12 meses
  LEG-->>P: Tarifa vigente e série mensal
  P->>P: Tier, cluster, preço alvo, desconto por relacionamento, preço sugerido, cenários e uplift
  P->>AL: Preço negociado x preço sugerido
  AL-->>P: Sem alçada, ou nível de alçada e papel aprovador
  P->>AUD: Registra execução (entradas, saídas, versões, usuário)
  P-->>SF: Praticado, alvo, sugerido, cenários, uplift e alçada
  SF-->>G: Exibe resultado e próximo passo (contratar ou solicitar aprovação)
```

### 4.4 Cenários expostos pelo motor

| Cenário | O que mostra | Base de cálculo | Fonte |
|---|---|---|---|
| (a) Faixas por percentil do cluster | Preço em P25, P35, P40, P50, P60, P75 e P90 do cluster do cliente, como faixas de negociação | MPA do ciclo ativo | `05-uplift-consolidado-fluxo.md:L20`, `L28-29`; `02:L54` **(uso inferido)** |
| (b) Sensibilidade a tier | Preço alvo se a volumetria mudar de faixa (tier acima ou abaixo), inclusive mudança de cluster | Faixas de tier por produto e regra de cluster (M1) | `01:L59-79`, `L81-92`; `02:L30-31`; `03:L52-56`; `04:L45-61` |
| (c) Efeito do relacionamento | Preço sugerido com e sem desconto por saldo Invest Fácil/DAV | `premissas_desconto` (M1) e Indicadores de Reciprocidade | `06:L137`; `07:L79`, `L83-84` |
| (d) Receita e uplift anual por cenário | Uplift = (alvo − tarifa) × quantidade anual se tarifa < 1.000; senão (alvo / tarifa − 1) × receita | PPC (quantidade anual e receita) | `01:L116`; `02:L52`; `03:L62`; `04:L79` |

A regra de alçada (definição de trabalho do brief §2) completa a resposta: se preço negociado < preço sugerido, o motor devolve o desvio em % e em R$ de uplift perdido, o nível de alçada e o papel aprovador; caso contrário, contratação sem alçada.

## 5. Capacidade C2 — Onda de Reprecificação [EVOLUÇÃO — a detalhar com o negócio]

> **Atenção.** C2 não tem regra de negócio documentada. Os documentos fonte mostram que o processo existe (a "Onda 3" e a pasta `03_modelo_onda_4`, `07:L18`) e que a decisão é manual (`07:L33`), mas não descrevem critérios de elegibilidade, gradação do reajuste, fluxo de aprovação nem se o motor efetiva a tarifa no legado. Tudo o que segue é estrutura para o discovery da fase F3, não especificação.

### 5.1 Sub-capacidades

| ID | Sub-capacidade | Descrição | Insumo que já existe |
|---|---|---|---|
| C2.1 | Planejamento da onda | Definir escopo (produtos, segmentos), calendário e metas de uplift do ciclo. | Uplift por cliente x produto e soma total (`05:L38-39`); cadência semestral do preço por produto (`07:L112`); aba Datas de Reprecificação (`07:L53`). |
| C2.2 | Seleção de elegíveis | Entrada de C3 (clientes com desvio de reciprocidade) mais filtros: negociações recentes, datas de reprecificação, RFPs, nichos, associações religiosas, poder público, N mínimo. | Exclusões já aplicadas no pipeline: poder público (`02:L24`), grupo 616 (`02:L25`), N < 15 (`02:L52`), CD_GRUPO = 0 (`05:L37`); listas manuais (`07:L52-60`) **(papel inferido)**. |
| C2.3 | Cálculo do novo preço por cliente | Reusar `svc-pricing` em lote e aplicar gradação por Stickiness x Impacto ("reajustes graduais", passo 4 da metodologia). | Matriz de Relacionamento com rótulos de stickiness (4 níveis) e impacto (3 níveis) (`06:L84-93`, `L115-123`); passo 4 citado em `03:L79`, `05:L111`, `06:L138` (truncado). |
| C2.4 | Aprovação (alçada) e comunicação | Submeter a lista de novos preços à alçada e comunicar ao cliente e ao gerente. | "Comunicar e implementar novos preços" reconhecido como etapa posterior manual (`03:L81`, `05:L113`); regra de alçada só definida para simulação (`00-doc-negocio.md:L22`). |
| C2.5 | Efetivação no legado e acompanhamento | Registrar a nova tarifa no sistema de tarifas e acompanhar uplift realizado x estimado. | Saída 1 do fluxo 07, manual (`07:L33`); nenhum documento descreve efetivação sistêmica. |

### 5.2 Fluxo macro

```mermaid
flowchart LR
  C21["C2.1 Planejamento<br/>escopo, calendário, metas"] -.-> C22["C2.2 Seleção de elegíveis"]
  C22 -.-> C23["C2.3 Novo preço por cliente<br/>motor C1 em lote + gradação"]
  C23 -.-> C24["C2.4 Aprovação e comunicação"]
  C24 -.-> C25["C2.5 Efetivação e acompanhamento"]
  EV["C3.4 evento<br/>ClienteElegivelParaReprecificacao"] -.-> C22
  EXC["Listas de exceção e<br/>datas de reprecificação (M1)"] -.-> C22
  PRC["svc-pricing (C1)"] -.-> C23
  MR["Matriz de Relacionamento<br/>stickiness x impacto (BRP Cash)"] -.-> C23
  AL["svc-alcada"] -.-> C24
  C25 -.->|"lacuna: efetiva ou só recomenda?"| LEG["Legado de tarifas (M3)"]
  C25 -.->|"uplift realizado"| PPC["PPC do próximo ciclo"]
  style C21 stroke-dasharray: 5 5
  style C22 stroke-dasharray: 5 5
  style C23 stroke-dasharray: 5 5
  style C24 stroke-dasharray: 5 5
  style C25 stroke-dasharray: 5 5
  style EV stroke-dasharray: 5 5
  style LEG stroke-dasharray: 5 5
```

### 5.3 O que o negócio precisa definir (perguntas objetivas)

1. Quais são os critérios de elegibilidade de um cliente para a onda, e qual o papel exato de cada lista (Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos, Associações Religiosas)? Hoje só existem as abas (`07:L52-60`).
2. Como a matriz Stickiness x Impacto se traduz em gradação de reajuste? Por exemplo: percentual máximo por ciclo, número de parcelas, ordem de prioridade. O texto do doc 06 está truncado exatamente nesse ponto (`06:L138`).
3. O motor efetiva a tarifa no sistema legado ou apenas recomenda e a efetivação continua manual? A premissa atual é "simulação sem efetivação" (`00-doc-negocio.md:L10`).
4. Qual a periodicidade da onda (mensal, semestral, anual) e como ela se relaciona com a cadência semestral de `SIMUL_PRECO_POR_PRODUTO` (`07:L112`)?
5. Quem aprova a onda como um todo e quem aprova exceções por cliente? A alçada de simulação (`00-doc-negocio.md:L22`) se estende à onda?
6. Como o cliente é comunicado e qual o prazo entre aprovação e vigência?
7. Qual a meta de uplift e como o realizado é medido (a soma de UPLIFT em `05:L39` é estimativa, não realizado)?

## 6. Capacidade C3 — Gestão de Reciprocidade [EVOLUÇÃO — a detalhar com o negócio]

> **Atenção.** Nenhum documento fonte descreve "acordo de reciprocidade". Os fluxos medem apenas volumetria e relacionamento **realizados** (A1, síntese transversal: "Não há evidência direta de gestão de reciprocidade"). O que existe são os indicadores; a comparação acordado x realizado é inteiramente a definir.

### 6.1 Sub-capacidades

| ID | Sub-capacidade | Descrição | Insumo que já existe |
|---|---|---|---|
| C3.1 | Registro do acordo | Guardar, na contratação ou na onda, a contrapartida acordada: volumetria por produto, saldo IF/DAV, produtos contratados, tier e preço concedido. | Contratação com tiers de volume e cluster (`00-doc-negocio.md:L22`); contrato com tarifa e vigência (`02:L19`); "acordos de parceria" citados como bases de negócio fora do Databricks (`00-doc-negocio.md:L27`). |
| C3.2 | Monitoramento do realizado | Acompanhar por grupo econômico o que foi efetivamente entregue. | Emissões L3M (`07:L24`, `L75`); saldo médio IF e DAV (`06:L44-51`); SoW de boletos (`06:L52-56`); share de cash (`06:L23-27`, `L32`); tiers de volume (`07:L65`, `L76`). |
| C3.3 | Detecção de desvio | Comparar acordado x realizado com regras e tolerâncias parametrizáveis (por exemplo: queda de tier, saldo abaixo do mínimo por N meses). | Nenhuma regra documentada; a consequência "mudou de tier, mudou de cluster e de preço" é **(inferida)** de `05:L62-94`. |
| C3.4 | Elegibilidade para C2 e alertas | Publicar o evento ClienteElegivelParaReprecificacao e alertar o gerente para renegociar ou retirar o desconto. | As três bases do fluxo 06 são "insumos de priorização e diagnóstico de relacionamento para o Motor" (`06:L127`). |

### 6.2 Fluxo macro

```mermaid
flowchart LR
  NEG["Negociação ou contratação<br/>(C1 sem alçada, C2 onda)"] -.-> C31["C3.1 Registro do acordo<br/>volumetria, saldo, produtos, tier"]
  C31 -.-> C32["C3.2 Monitoramento do realizado"]
  IND["Indicadores de Reciprocidade<br/>emissões L3M, IF/DAV, SoW, share (BRP Cash)"] -.-> C32
  C32 -.-> C33["C3.3 Detecção de desvio"]
  TOL["Regras e tolerâncias (M1)"] -.-> C33
  C33 -.-> C34["C3.4 Elegibilidade e alertas"]
  C34 -.->|"evento ClienteElegivelParaReprecificacao"| C2["C2 Onda de Reprecificação"]
  C34 -.->|"alerta"| GER["Gerente comercial (Salesforce)"]
  style NEG stroke-dasharray: 5 5
  style C31 stroke-dasharray: 5 5
  style C32 stroke-dasharray: 5 5
  style C33 stroke-dasharray: 5 5
  style C34 stroke-dasharray: 5 5
  style C2 stroke-dasharray: 5 5
```

### 6.3 O que o negócio precisa definir

1. O que é o "acordo de reciprocidade": é o tier de volume assumido na contratação, um saldo mínimo de Invest Fácil/DAV, um share mínimo de cobrança, ou uma combinação? Onde ele é registrado hoje (contrato, proposta, planilha do gerente)?
2. Quais tolerâncias e por quanto tempo um desvio precisa persistir para gerar ação (exemplo de trabalho: dois meses consecutivos abaixo do tier acordado)?
3. Qual a periodicidade do monitoramento: mensal, acompanhando o ciclo da BRP Cash, ou contínua?
4. Qual a consequência do desvio: elegibilidade para a onda, retirada automática do desconto por relacionamento, ou apenas alerta ao gerente?
5. Quem é o dono do acordo (gerente, Precificação) e quem pode alterá-lo?

### 6.4 C3 é capacidade própria ou sub-capacidade de C2?

**Conclusão (brief §3): C3 é capacidade própria.** Justificativa: (1) tem ciclo de vida próprio, começa na contratação e roda continuamente, haja ou não onda; (2) serve a outros consumidores além da reprecificação, como o gerente comercial (alerta), a manutenção do desconto por relacionamento (C1.1) e o diagnóstico de carteira; (3) em DDD fica como bounded context "Reciprocidade" que **publica** o evento de desvio ou elegibilidade, consumido por C2 via Published Language (brief §5). A dependência C2 → C3 é de dados (elegibilidade), não de estrutura.

**Argumentos do lado contrário, registrados para o debate.** (a) Hoje o único consumidor evidente dos indicadores de reciprocidade é a decisão de reprecificação (`06:L127`, `07:L33`), o que sugeriria tratar C3 como a etapa "seleção de elegíveis" de C2. (b) Ambas as capacidades estão igualmente indefinidas e serão detalhadas no mesmo discovery (F3), então separá-las agora pode gerar dois backlogs vazios. (c) Um serviço a menos reduz custo de operação na fase inicial. **Por que a conclusão se mantém:** os argumentos (b) e (c) são de cronograma e custo, não de domínio, e são absorvidos pelo roadmap (F3 entrega o MVP de C3 antes de C2, justamente porque C2 depende dos seus eventos). O argumento (a) descreve o AS-IS, mas o TO-BE já prevê o desconto por relacionamento dentro do preço sugerido (`06:L137`), o que torna C1 um segundo consumidor de C3 desde a fase F1 ou F2. Se o discovery mostrar que o "acordo" não existe como conceito de negócio, a decisão deve ser revista, e nesse caso C3 se reduz a "Indicadores de Reciprocidade" dentro de M2, não a uma sub-capacidade de C2.

## 7. Módulo de Parametrização (M1)

### 7.1 O que é parametrizável

Os anexos A1 (34 famílias de parâmetros nos fluxos de produto) e A2 (lista consolidada dos fluxos 05 a 07) foram agrupados em oito grupos. Hoje todos estão em código, listas fixas ou abas de planilha.

| Grupo | Conteúdo | Onde está hoje | Fonte |
|---|---|---|---|
| 1. Catálogo de produtos | 18 produtos e vínculo com macroproduto (COBRANCA, ARRECADACAO, MULTIPAG, PIX); visão Cliente/Banco; constantes para bases sem PRODUTO; mapeamentos DESCR_TARIFA → modalidade, CD_TARF → PIX Pagamentos, mídia → produto de arrecadação; grupo de regra de cluster por produto | Listas no notebook 06 e nos fluxos de produto | `05:L34`, `L49`, `L60-85`; `01:L35-57`; `03:L24`; `04:L22` |
| 2. Domínios | Segmentos (6, com INSTITUCIONAL em aberto) e segmentos elegíveis de atacado (5); regiões (5) e tabela UF → região; tiers (3); agrupamento de segmentos nas faixas de score | Listas fixas | `05:L50-52`; `06:L33`, `L101`; `02:L40-46` |
| 3. Tiers de volume | Faixas por produto (13 em Cobrança, 1 em Multipag, 1 em PIX, 2 em Arrecadação), base de volume (média mensal x total anual), flag "sem Tier 3" | Código e aba Tears de Volume / `tier_por_produto.xlsx` | `01:L59-79`; `02:L30`; `03:L52-56`; `04:L45-48`; `07:L65`, `L76` |
| 4. Regra de cluster | Matriz tier x segmento x região → cluster (1 a 10) por grupo de regra; clusters "corporate" de referência; ordem de precedência do cummin; cluster auxiliar 9999; fallback para combinação sem cluster (lacuna) | Função `cluster()` no código | `05:L56-96`; `01:L81-102`; `02:L31`, `L50`; `04:L54-61`, `L67` |
| 5. Percentis e preço-alvo | Lista de percentis (P25 a P90), percentil-alvo (P75), campo de peso, regra "nunca reduzir", limiar 1.000 das fórmulas de uplift, N mínimo 15, fonte de percentis por produto | Código | `01:L96`, `L112`, `L116`, `L120`; `05:L17`, `L20-21` |
| 6. Premissas de desconto, alçada, remuneração e relacionamento | `premissas_desconto` (por saldo IF/DAV), `premissas_alcada` (níveis, aprovadores), `premissas_remuneracao`; limiares de materialidade de crédito por segmento, faixas de score 0,1/0,4/0,7, faixas de ROB e receita de cash, função de combinação e rótulos de stickiness/impacto; lista de macroprodutos cash | Arquivos Excel com conteúdo não documentado; código do fluxo 06 | `07:L78-80`; `06:L19`, `L68-73`, `L79-93`, `L99-123` |
| 7. Listas de exceção e elegibilidade | Poder público, grupo 616/Bradesco, CD_GRUPO = 0, associações religiosas, negociações recentes, datas de reprecificação, RFPs, custos, nichos, volume mínimo, receita negativa | CSVs e abas manuais | `01:L9`, `L14`, `L26`; `02:L22-25`; `03:L23-25`; `05:L37`; `07:L52-60` |
| 8. Janelas temporais e ciclo | LTM 13 referências, L3M, ROB 6 meses, share de cash 3 meses, saldo IF/DAV 3 meses, boletos 12 meses, divisor de mensalização 12, `anomes` do ciclo, cadência mensal x semestral por tabela | Datas hard-coded (202506, 2026-03 a 05) | `02:L17`; `06:L17`, `L26`, `L50`; `05:L31`; `07:L89`, `L112`; `00-etapas:L5-16` |

### 7.2 Ciclo de vida de uma versão de parâmetro

```mermaid
stateDiagram-v2
  [*] --> Rascunho: analista de Precificação cria ou clona versão
  Rascunho --> Staging: envia para teste
  Staging --> Rascunho: ajuste após simulação em staging
  Staging --> Aprovado: aprovador com alçada aprova
  Aprovado --> Publicado: publicação imediata
  Aprovado --> Agendado: vigência futura definida
  Agendado --> Publicado: data de vigência atingida
  Publicado --> Expirado: nova versão publicada ou fim de vigência
  Expirado --> [*]
```

Regras do ciclo (`00-doc-negocio.md:L13`, `L17`, `L36-37`, `L42`; AD-06): toda mudança nasce como rascunho; só passa a produção depois de validada em staging, onde o endpoint de simulação "em staging" permite comparar resultados com a versão publicada; a publicação pode ser imediata ou agendada; a versão anterior permanece disponível para rollback (AD-13) e para reproduzir qualquer cálculo antigo (RNF-09).

### 7.3 Quem parametriza, quem aprova, auditoria

- **Parametriza:** analistas do time de Precificação, dono das regras (`00-doc-negocio.md:L26`, `L33`).
- **Aprova:** papéis com alçada definidos pelo próprio time de Precificação (`00-doc-negocio.md:L35`), seguindo o processo de governança de publicação (`L37`); a matriz de quem aprova o quê é lacuna (R10).
- **Auditoria:** cada versão guarda autor, aprovador, data, diff em relação à anterior e justificativa; cada execução de C1 referencia a versão usada (`00-doc-negocio.md:L14`; RF-09; RNF-03).
- **Perfis:** acesso às telas de parametrização restrito por perfil e alçada (`00-doc-negocio.md:L18`; RF-10), integrado a AD/Salesforce (M4).

## 8. Legado e base histórica (M3)

**O que continua no legado.** O preço vigente e o histórico de 12 meses por cliente x produto (`00-doc-negocio.md:L11-12`, `L29`); as tarifas de contrato, como as de Multipag (`02:L19`); o cadastro de segmentos e grupo econômico, consumido por todos os fluxos (`02:L15`; `06:L24`); e os sistemas de origem de eventos tarifados, movimento, ROB, Invest Fácil, DAV e shares (`00-etapas:L5-18`). O motor consulta essas bases pelo Databricks sem substituí-las (`00-doc-negocio.md:L30`) e pelo Adaptador de Legado quando precisa de informação online (AD-10).

**O que é desligado.** A Planilha Preço Ano 1 e sua macro (`07:L21-31`), a cópia manual para a pasta `calculadora salesforce` e a query SAS manual (`07:L34-36`), as tabelas `SIMUL_*` do SAS (`07:L87-98`) e o Motor da Calculadora no Servidor SQL 010 (`07:L40-42`, `L114`). O desligamento é gradual e por produto, com execução paralela (shadow) durante o piloto (AD-14; `00-doc-negocio.md:L41`).

**Como a base histórica é preservada.** A BRP Cash é versionada por `anomes` (herdando o versionamento que o SAS já faz, `07:L89`), com todas as versões mantidas em tabelas Delta; a versão anterior fica sempre ativável para rollback (AD-13). O histórico de simulações e de pedidos de alçada fica em tabela append-only (C1.6), e cada registro aponta a versão de parâmetro e de BRP usada. As tabelas `SIMUL_*_AAAAMM` existentes devem ser migradas como ciclos históricos da BRP Cash para não perder a série já produzida **(recomendação, não requisito documentado)**.

## 9. Preparação de dados (M2)

### 9.1 Pipeline resumido

```mermaid
flowchart LR
  subgraph SRC["Fontes no Databricks (M3)"]
    S1["Movimento e eventos tarifados<br/>Cobrança, Arrecadação, Multipag/TED, PIX"]
    S2["Segmentos, poder público,<br/>associações religiosas, UF/ROB"]
    S3["ROB, saldo IF/DAV,<br/>share de cash, crédito e boletos"]
  end
  subgraph PPP["dbx-ppp Pipeline de Preparação de Preços"]
    J1["Preparação por produto<br/>tier, cluster, percentis,<br/>preço-alvo, uplift, emissões L3M"]
    J2["Consolidação<br/>MPA e PPC"]
    J3["Relacionamento<br/>stickiness x impacto, saldos, SoW"]
    J4["Validações de qualidade<br/>e alertas (RF-08)"]
  end
  subgraph BRPC["dbx-brp BRP Cash (Delta, versão por anomes)"]
    B1[("MPA")]
    B2[("PPC")]
    B3[("Matriz de Relacionamento")]
    B4[("Indicadores de Reciprocidade")]
  end
  subgraph PUB["Publicação (AD-03)"]
    R1["Reverse ETL JDBC<br/>para staging"]
    R2["svc-publicacao<br/>ativação de versão"]
    R3[("sql-motor")]
  end
  PARM["M1 parâmetros<br/>tiers, cluster, percentis, janelas"] --> J1
  S1 --> J1
  S2 --> J1
  S2 --> J3
  S3 --> J3
  J1 --> J2
  J2 --> J4
  J3 --> J4
  J4 --> B1
  J4 --> B2
  J4 --> B3
  J4 --> B4
  B1 --> R1
  B2 --> R1
  B3 --> R1
  B4 --> R1
  R1 --> R2
  R2 --> R3
  R3 --> C1["C1 svc-pricing"]
  R3 -.-> C3["C3 svc-reciprocidade"]
  style C3 stroke-dasharray: 5 5
```

O pipeline substitui a execução sequencial dos sete scripts Python (`07:L19-20`) e a cópia manual de saídas para abas (`07:L21-27`). Os notebooks 01 a 05 viram o job "Preparação por produto" e "Consolidação"; o notebook 07 vira "Relacionamento"; a macro e as listas manuais são substituídas por M1. As validações antes da ativação (contagens por cluster, N mínimo, combinações sem percentil, datas fora da janela) atendem `00-doc-negocio.md:L19` e o risco R3. O Control-M pode disparar o job quando a governança de scheduling exigir (AD-01).

### 9.2 Entidades da BRP Cash (resumo de A2 §Síntese)

| Entidade | Chave | Conteúdo principal | Hoje | Fonte |
|---|---|---|---|---|
| Matriz de Preço-Alvo por Cluster (MPA) | ciclo, produto, tier, segmento, região | cluster, P25 a P90, preço-alvo, vigência | `tabela_precos.xlsx` / `SIMUL_PRC_ALVO_CLUSTER` | `05:L28-29`; `07:L77` |
| Posição de Preço Cliente-Produto (PPC) | ciclo, grupo econômico, segmento, produto | cluster, macroproduto, quantidade mensal e anual, receita, tarifa praticada, percentis, preço-alvo, uplift, N | `base_total.xlsx` (aba Base Pricing) | `05:L38`; `07:L23` |
| Preço por Produto | ciclo semestral, produto | preço sugerido ou de lista **(inferido)** | `SIMUL_PRECO_POR_PRODUTO` | `07:L30`, `L112` |
| Matriz de Relacionamento | ciclo, grupo econômico, segmento | resultado operacional, receita de cash, shares, scores, stickiness, impacto | `matriz.xlsx` | `06:L42` |
| Indicadores de Reciprocidade | ciclo, grupo econômico, segmento (+ produto) | saldo médio IF e DAV, SoW de boletos, emissões L3M | `saldo.xlsx`, `sow_cobranca.xlsx`, `df_qtde_L3M.csv` | `06:L50-56`; `07:L24` |
| Grupo Econômico | grupo econômico | segmento, região, CNPJs | `segmentos_atualizados.csv`, `regiao_por_ge.xlsx` | `06:L24`; `07:L82` |
| Ciclo de Precificação | anomes | data de publicação, versão de parâmetros, status | sufixo `_AAAAMM` das tabelas SAS | `07:L89`, `L112` |

Produto, Segmento, Região, Tier de Volume, Regra de Cluster, Premissas e Exceções são entidades de **parametrização** (M1), não da BRP Cash, embora cada ciclo da BRP registre qual versão delas usou. Preço Vigente e Histórico continua no legado (M3).

## 10. Interações entre capacidades

| Fornece → Recebe | C1 Cálculo e Simulação | C2 Onda de Reprecificação | C3 Reciprocidade | M1 Parametrização | M2 Preparação de Dados | M3 Legado | M4 Governança |
|---|---|---|---|---|---|---|---|
| **C1** | — | Cálculo em lote do novo preço por cliente; cenários e uplift; nível de alçada (via `svc-alcada`) | Preço e tier concedidos na contratação, para registro do acordo (C3.1) | Retorno de simulação "em staging" para validar versões | — | — | Trilha de execuções |
| **C2** | Efetivação de novo preço altera o praticado consultado por C1 (via legado) | — | Acordo renegociado na onda (C3.1) | Demanda de novos parâmetros de gradação e elegibilidade | Uplift realizado para o próximo ciclo (PPC) | Nova tarifa (se o motor efetivar; lacuna) | Decisões de aprovação da onda |
| **C3** | Desconto por relacionamento vigente ou retirado (C1.1); alerta exibido ao gerente | Evento ClienteElegivelParaReprecificacao (C2.2) | — | Demanda de regras e tolerâncias | — | — | Trilha de desvios e alertas |
| **M1** | Tiers, cluster, percentis, premissas de desconto e alçada, exceções | Elegibilidade, gradação, calendário | Tolerâncias, periodicidade | — | Tiers, cluster, percentis, janelas, catálogo | — | Versões e autores |
| **M2** | MPA, PPC, Matriz de Relacionamento, Indicadores (ciclo ativo) | Elegíveis pré-computados, uplift potencial | Indicadores de Reciprocidade realizados | Domínios observados (novos produtos, segmentos) para atualizar catálogo | — | — | Métricas de qualidade de cada ciclo |
| **M3** | Preço vigente e histórico de 12 meses; tarifas de contrato | Efetivação (lacuna) | Contrato e vigência como parte do acordo | — | Bases de origem ingeridas no Databricks | — | — |
| **M4** | Autenticação, perfis, auditoria | Perfis de aprovador | Perfis de gerente | Perfis de quem parametriza e aprova | Monitoramento do job | — | — |

## 11. Lacunas e decisões pendentes que afetam o desenho

Lista única do brief §8, com o efeito de cada item neste desenho:

1. **Regras da macro "Preço por Produto"/"Resumo por GE" e do Motor da Calculadora (SQL 010)** não documentadas (`07:L29-31`, `L41`, `L114`). Efeito: C1.1 não pode ser especificada sem engenharia reversa na fase F0 (R1); o shadow run de F1 é a validação.
2. **Conteúdo de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto`, `regiao_por_ge`** desconhecido (`07:L76-82`). Efeito: grupos 3 e 6 de M1 sem estrutura de dados definida.
3. **Definição formal de preço sugerido x alvo e da regra de alçada.** Efeito: as definições de trabalho do brief §2 e a tabela de cenários (4.4) precisam ser validadas pelo negócio.
4. **C2 e C3 sem detalhamento de negócio.** Efeito: seções 5 e 6 são estrutura para discovery; a decisão "motor efetiva ou só recomenda" define se existe integração de escrita com o legado.
5. **Inconsistências entre fluxos:** INSTITUCIONAL dentro (`05:L51`) e fora (`06:L33`) do atacado; cluster de Arrecadação com códigos 3 e 4 diferentes (`04:L58-59`); grupo 616/Bradesco sem justificativa (`02:L25`; `01:L14`); `NA BAIXA POR PAGAMENTO Banco` sem cluster (`05:L96`); CANAIS DIGITAIS e DÉBITO AUTOMÁTICO sem fonte de percentis. Efeito: o catálogo (M1 grupo 1) e a regra de cluster (grupo 4) precisam de decisão registrada antes do primeiro ciclo (R9).
6. **Datas hard-coded e listas fixas** (`06:L17`, `L26`; `05:L45-54`). Efeito: grupo 8 de M1 e contrato de dados do pipeline.
7. **Latência aceitável do preço vigente** (foto via Databricks x consulta online). Efeito: define a estratégia do Adaptador de Legado em C1.4 (AD-10, R4).
8. **Trechos truncados** nos docs fonte (`01:L92`, `L106`, `L135`; `06:L138`; `07:L98`). Efeito: regra de cluster de Cobrança, uso de N e gradação por stickiness incompletos.
9. **Mensageria (Service Bus) fora da stack.** Efeito: a integração C3 → C2 pode precisar do fallback outbox + polling (AD-09, R5).
10. **Semântica do campo N e de QTDE_CASH_CONC/QTDE_COB_CONC.** Efeito: N é usado como critério de elegibilidade (N < 15) sem definição formal; os campos de concorrência são carregados e não usados, mas são candidatos naturais a C3.2.
