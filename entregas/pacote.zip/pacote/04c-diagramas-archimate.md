# 04c — Diagramas ArchiMate: Termo de Adesão Multiproduto (Cash Management / Payments)

> Modela em **ArchiMate 3.2 (The Open Group)** as camadas **Motivação, Estratégia, Negócio, Aplicação e Tecnologia** da iniciativa de Aceite Digital Cash.
> É uma **visão derivada**: não cria decisões novas. Os nomes e IDs vêm de `01-contexto-de-negocio.md` (mestre de DRV, OE, KPI e RN), `02-desenho-conceitual.md` (CAM-1..CAM-5, ATR, PN, EVN, OBJ, CAP, APP, PRI), `04-desenho-arquitetura-solucao.md` (RST, RF, RNF, COMP, ADR, N-xx) e `04a-componentes-e-justificativas.md`.
> Fontes PlantUML, renders (PNG e SVG) e o modelo importável no Archi estão em `diagramas/archimate/`.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 04c — Diagramas ArchiMate |
| Versão | v0.5 |
| Data | 2026-09-27 |
| Status | Rascunho para validação com os times |
| Autor | Arquitetura Corporativa — Atacado (Cash Management / Payments) |
| Documentos base | `01-contexto-de-negocio.md`, `02-desenho-conceitual.md`, `04-desenho-arquitetura-solucao.md`, `04a-componentes-e-justificativas.md` |
| Público | Time do Atacado Cash Payments, Time de Canais, Time de Experiência, Time do GACD, Arquitetura; apoio: Plataformas Funcionais, Segurança |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-24 | Versão inicial: 11 vistas (Motivação 2, Estratégia 2, Negócio 3, Aplicação 1, Tecnologia 2, integrada 1), modelo Open Exchange e tabela de rastreabilidade |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: INC-01..05 resolvidas na origem (drivers DRV-01..06 do 01; OE-xx/OBJ-xx sem colisão; regras na numeração RN-xx do 01; Axway em "Hub (localização a confirmar — QA-TEC-09)"; nome canônico "Canal Digital PJ"); `.puml` ajustados; vistas re-renderizadas com Graphviz (exceto am-04, mantida em Smetana); modelo Open Exchange regerado (198 elementos, 266 relações) |
| v0.3 | 2026-09-24 | Correção pós-entrega: modelo Open Exchange validado contra o XSD oficial `archimate3_Diagram.xsd` 3.1, sem erros |
| v0.4 | 2026-09-27 | Ordem das camadas do 02 v0.6 (`instrucoes-ajustes.md`, item 6): na tabela da §2, CAM-2 = Capacidades e CAM-3 = Negócio, com as linhas reordenadas e nota da relação ArchiMate (processo realiza capacidade). Referências às seções do 02 trocadas: 02 §3.2.x (Negócio) → §3.3.x e 02 §3.3 (Capacidades) → §3.2, no texto, nas tabelas de rastreabilidade e nos comentários de fonte dos blocos PlantUML (e nos `.puml` correspondentes). Diagramas e modelo Open Exchange inalterados |
| v0.5 | 2026-09-27 | Convênio com **etapa de implantação e homologação** (`instrucoes-ajustes.md`, item 8), alinhado ao 02 v0.7 **[PREMISSA — padrão de mercado]**: `am-03` com PN-10 **"Implantar produto e gerar Convênio"** (PN-10.1 a PN-10.4 aninhadas, executor Gerente de Cash ou backoffice — QA-CON-24), novo **EVN-13 "Implantação iniciada"** (aberto por EVN-08 ou pelo contrato vigente) e EVN-10 **"Convênio ativado"**, com os status projetados em PN-12; `am-03b` com o novo **ATR-09 Backoffice de Cash** e o papel "Executor da implantação do produto" (ATR-01 ou ATR-09 candidatos); `am-03c` com os estados do OBJ-07 (Em teste → Ativo, RN-17) e o registro no sistema do produto; `am-02` com o estágio **VS-01.4 "Implantar produtos e ativar Convênios"**. Textos das §4.1, §5.1–5.3 e §6, rastreabilidade (§10.2, §10.3), §9 e §12 atualizados; blocos PlantUML iguais aos `.puml`; PNG/SVG das quatro vistas regerados; `gerar_open_exchange.py` aceita `'@name` e o modelo Open Exchange foi regerado (205 elementos, 279 relações), válido contra o XSD |

### 1.1 Notação e convenções

| Item | Convenção |
|---|---|
| Linguagem | ArchiMate 3.2, com a biblioteca `<archimate/Archimate>` embarcada no PlantUML (cores padrão por camada: lilás = Motivação, bege = Estratégia, amarelo = Negócio, azul = Aplicação, verde = Tecnologia) |
| Agrupamentos | Caixas tracejadas (`Grouping`) só organizam a leitura (fase, zona de rede, "fora do escopo"). Não são elementos do modelo |
| Marcas no rótulo | `[existente]`, `[nova]`, `[reuso]`, `[indefinida]`, `[externa]`, `[hipótese]`, `[a confirmar]`, `[candidato]`, `[a definir]` repetem o status registrado nos documentos base |
| Relações | Realização (seta vazada pontilhada), Serving (seta aberta), Flow (tracejada), Triggering (sólida), Access (pontilhada; a ponta indica leitura/escrita), Assignment (ponto + seta), Composition/Aggregation (losango), Influence (tracejada com `+`), Association (linha simples) |
| IDs novos | Só estes são criados aqui, para elementos que não têm ID nos documentos base: **AVL-01..05** (avaliações), **VS-01 / VS-01.1..5** (value stream e estágios), **RES-01..06** (recursos), **COA-01..06** (cursos de ação). Os demais nomes e IDs são os canônicos |
| Nomes técnicos | Deployables, módulos e interfaces usam o nome técnico do 04 (ex.: `atacado-adesao-termo`, API Adesão v1) |

### 1.2 Arquivos e como regenerar

| Arquivo (em `diagramas/archimate/`) | Viewpoint ArchiMate | Camada |
|---|---|---|
| `am-01-motivacao.puml` | Stakeholder / Motivation | Motivação (1/2) |
| `am-01b-motivacao-requisitos.puml` | Goal Realization / Requirements Realization | Motivação (2/2) |
| `am-02-estrategia.puml` | Capability Map + Value Stream | Estratégia (1/2) |
| `am-02b-estrategia-cursos-de-acao.puml` | Strategy | Estratégia (2/2) |
| `am-03-negocio.puml` | Business Process Cooperation | Negócio (1/3) |
| `am-03b-negocio-atores-servicos.puml` | Organization / Actor Co-operation | Negócio (2/3) |
| `am-03c-negocio-objetos.puml` | Information Structure (negócio) | Negócio (3/3) |
| `am-04-aplicacao.puml` | Application Cooperation | Aplicação |
| `am-05-tecnologia.puml` | Technology / Physical (rede) | Tecnologia (1/2) |
| `am-05b-tecnologia-implantacao.puml` | Implementation and Deployment | Tecnologia (2/2) |
| `am-06-visao-integrada.puml` | Layered | Todas |
| `am-modelo-open-exchange.xml` | Open Exchange Format (importável no Archi) | Todas |
| `gerar_open_exchange.py` | Gera o XML a partir dos `.puml` | — |

Os viewpoints de Motivação, Estratégia, Negócio e Tecnologia foram divididos em mais de um diagrama para manter a leitura. Os nomes pedidos (`am-01` a `am-06`) foram mantidos, e as vistas extras usam o sufixo `b`/`c`.

```bash
cd docs-final/diagramas/archimate
GRAPHVIZ_DOT=/caminho/para/dot java -DPLANTUML_LIMIT_SIZE=8192 -jar plantuml.jar -tpng am-*.puml   # PNG
GRAPHVIZ_DOT=/caminho/para/dot java -DPLANTUML_LIMIT_SIZE=8192 -jar plantuml.jar -tsvg am-*.puml   # SVG
python3 gerar_open_exchange.py             # am-modelo-open-exchange.xml
```

Requisitos: Java 21, `plantuml.jar` (testado com PlantUML 1.2026.8) e Graphviz `dot` (testado com 2.42.2; o mesmo wrapper do 04b §1.2). Os renders da v0.2 usam Graphviz, exceto `am-04-aplicacao`, que força o layout Smetana com `!pragma layout smetana` (ver §12).

---

## 2. Correspondência entre as camadas do 02 e as camadas ArchiMate

O `02-desenho-conceitual.md` organiza a iniciativa em CAM-1..CAM-5. O ArchiMate separa **Motivação** de **Estratégia** e põe as capacidades na camada de Estratégia, acima da camada de Negócio: o processo de negócio realiza a capacidade. Desde a v0.6 do 02, a ordem das camadas do 02 segue a mesma lógica (CAM-2 Capacidades antes de CAM-3 Negócio). A correspondência adotada é esta:

| Camada do 02 | Conteúdo | Camada ArchiMate | Vistas |
|---|---|---|---|
| CAM-1 Camada de Estratégia | Drivers (DRV), objetivos (OE), KPIs | **Motivação** (Driver, Goal, Outcome) e **Estratégia** (Course of Action, Resource) | am-01, am-01b, am-02b |
| CAM-2 Camada de Capacidades | CAP-01..CAP-13 | **Estratégia** (Capability, Value Stream) | am-02, am-02b |
| CAM-3 Camada de Negócio | Atores (ATR), processos (PN), eventos (EVN), objetos (OBJ), regras (RN) | **Negócio** | am-03, am-03b, am-03c |
| CAM-4 Camada de Aplicação | APP-01..APP-10 (conceitual) → COMP-01..COMP-20 (04) | **Aplicação** | am-04, am-05b |
| CAM-5 Camada de Tecnologia e Integração | TEC-01..TEC-12 → COMP-07..COMP-12, COMP-04/05 (04) | **Tecnologia** | am-05, am-05b |
| Princípios (PRI), requisitos (RF/RNF), restrições (RST) | 02 §6; 04 §3 | **Motivação** (Principle, Requirement, Constraint) | am-01b |

---

## 3. Camada de Motivação

### 3.1 Stakeholders, drivers, avaliações, objetivos e resultados (`am-01`)

**O que mostra.** Por que a iniciativa existe. Os cinco stakeholders (os quatro times do Contexto Geral e o Jurídico/Compliance, este como PRM-NEG-15) estão ligados aos **drivers DRV-01..06** do 01 §5.2 (mesmos IDs e textos no 02 §3.1.1). Os drivers DRV-01..05 se desdobram em **avaliações** (os problemas do PRD [03]: assinatura manual, falta de rastreabilidade, tarifas travadas sem convênio, falta de visibilidade e canal fragmentado). As avaliações influenciam positivamente (`+`) os **objetivos OE-01..05**, e cada objetivo é realizado por um **resultado mensurável** (KPI-01..05, com as metas do PRD).

**Leitura.**
- As metas dos KPIs são as do PRD. A de KPI-02 depende de um baseline ainda não definido (QA-CON-18), e a de KPI-05 depende de critérios regulatórios não detalhados (QA-CON-17).
- AVL-01..05 são avaliações introduzidas aqui só para dar forma ArchiMate às dores já descritas no 01 §4.1–4.2 e no 02 §3.1.1. Cada uma corresponde a um driver (DRV-01 → AVL-01, …, DRV-05 → AVL-05).
- DRV-06 (reuso de componentes corporativos) é um driver habilitador, sem avaliação própria; liga-se ao Time do GACD.

![ArchiMate — Motivação 1/2](diagramas/archimate/am-01-motivacao.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-01-motivacao.puml</code></summary>

```plantuml
@startuml am-01-motivacao
' Viewpoint: Motivation (parte 1) — Stakeholders, Drivers, Assessments, Goals, Outcomes
' Fontes: 01-contexto-de-negocio.md (§4, §5.2, §6) e 02-desenho-conceitual.md (§3.1) — drivers DRV-01..06 do 01 (mestre)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 190
skinparam nodesep 25
skinparam ranksep 55
title ArchiMate 3.2 — Motivação (1/2): Stakeholders, Drivers, Avaliações, Objetivos e Resultados

Grouping(g_stk, "Stakeholders") {
  Motivation_Stakeholder(stk_atacado, "Time do Atacado Cash Payments\n(Gerente de Cash)")
  Motivation_Stakeholder(stk_canais, "Time de Canais")
  Motivation_Stakeholder(stk_exp, "Time de Experiência")
  Motivation_Stakeholder(stk_gacd, "Time do GACD")
  Motivation_Stakeholder(stk_jur, "Jurídico / Compliance\n(premissa PRM-NEG-15)")
}

Grouping(g_drv, "Drivers (DRV)") {
  Motivation_Driver(drv01, "DRV-01 Contratação de produtos Cash bloqueada por dependência de termo manual")
  Motivation_Driver(drv02, "DRV-02 Falta de rastreabilidade e evidência de aceite")
  Motivation_Driver(drv03, "DRV-03 Tarifas negociadas não cadastradas por ausência de convênio")
  Motivation_Driver(drv04, "DRV-04 Baixa visibilidade do gerente sobre o status da adesão")
  Motivation_Driver(drv05, "DRV-05 Fragmentação de canais (BGS sem GACD)")
  Motivation_Driver(drv06, "DRV-06 Reuso de componentes corporativos (GACD, FIRP, GCC/Filenet, IMPD, Databricks)")
}

Grouping(g_ass, "Avaliações (problemas do PRD [03])") {
  Motivation_Assessment(as01, "AVL-01 Termo de Adesão assinado manualmente, fora do Salesforce")
  Motivation_Assessment(as02, "AVL-02 Processo sem rastreabilidade: evidência de aceite frágil")
  Motivation_Assessment(as03, "AVL-03 Tarifas travadas: sem Convênio por produto não há cadastro de tarifas")
  Motivation_Assessment(as04, "AVL-04 Gerente de Cash sem visibilidade do status do termo")
  Motivation_Assessment(as05, "AVL-05 Canal fragmentado: BGS não integra com o GACD")
}

Grouping(g_goal, "Objetivos estratégicos (OE)") {
  Motivation_Goal(oe01, "OE-01 Digitalizar a geração de termos")
  Motivation_Goal(oe02, "OE-02 Reduzir o tempo de ciclo de contratação")
  Motivation_Goal(oe03, "OE-03 Aumentar a conversão de contratações")
  Motivation_Goal(oe04, "OE-04 Melhorar a visibilidade do Gerente de Cash")
  Motivation_Goal(oe05, "OE-05 Garantir compliance")
}

Grouping(g_out, "Resultados esperados (KPIs do PRD)") {
  Motivation_Outcome(kpi01, "KPI-01 ≥ 90% dos termos gerados via Salesforce em 6 meses")
  Motivation_Outcome(kpi02, "KPI-02 −50% no tempo de negociação → assinatura (baseline a definir)")
  Motivation_Outcome(kpi03, "KPI-03 ≥ 80% de conversão gerado → assinado")
  Motivation_Outcome(kpi04, "KPI-04 100% dos Gerentes de Cash com status em tempo real")
  Motivation_Outcome(kpi05, "KPI-05 100% dos termos em conformidade regulatória")
}

' Stakeholder — Driver
Rel_Association_Down(stk_atacado, drv01)
Rel_Association_Down(stk_atacado, drv03)
Rel_Association_Down(stk_atacado, drv04)
Rel_Association_Down(stk_jur, drv02)
Rel_Association_Down(stk_gacd, drv06)
Rel_Association_Down(stk_canais, drv05)
Rel_Association_Down(stk_exp, drv05)

' Driver — Assessment
Rel_Association_Down(drv01, as01)
Rel_Association_Down(drv02, as02)
Rel_Association_Down(drv03, as03)
Rel_Association_Down(drv04, as04)
Rel_Association_Down(drv05, as05)

' Assessment influencia Goal
Rel_Influence_Down(as01, oe01, "+")
Rel_Influence_Down(as01, oe02, "+")
Rel_Influence_Down(as03, oe02, "+")
Rel_Influence_Down(as04, oe04, "+")
Rel_Influence_Down(as02, oe05, "+")
Rel_Influence_Down(as05, oe03, "+")

' Outcome realiza Goal
Rel_Realization_Up(kpi01, oe01)
Rel_Realization_Up(kpi02, oe02)
Rel_Realization_Up(kpi03, oe03)
Rel_Realization_Up(kpi04, oe04)
Rel_Realization_Up(kpi05, oe05)
@enduml
```

</details>

### 3.2 Princípios, requisitos e restrições (`am-01b`)

**O que mostra.** Como a arquitetura responde aos objetivos:
- **Princípios** (PRI do 02 §6) realizam objetivos.
- **Requisitos funcionais e não funcionais** principais (RF/RNF do 04 §3.2–3.3) realizam princípios ou objetivos.
- **Restrições** (RST do 04 §3.1, mais o limite de escopo do Canal) realizam princípios ou delimitam requisitos.

**Leitura.**
- As restrições **RST-01** ("Salesforce só via ARO Atacado"), **RST-03** ("FIRP e GACD pelo Axway") e **RST-04** ("Akamai → Application Gateway → Axway") são a base de PRI-01, PRI-07 e da rota de entrada.
- **RST-05** representa a stack corporativa (Java prioritário).
- O limite "Canal Digital PJ fora do escopo" realiza PRI-10.
- A vista mostra só os RF/RNF que mais pesam nas decisões (04 §3.4). A lista completa está no 04 §3.2–3.3.

![ArchiMate — Motivação 2/2](diagramas/archimate/am-01b-motivacao-requisitos.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-01b-motivacao-requisitos.puml</code></summary>

```plantuml
@startuml am-01b-motivacao-requisitos
' Viewpoint: Motivation (parte 2) — Goals, Principles, Requirements, Constraints
' Fontes: 02-desenho-conceitual.md (§3.1.2, §6) e 04-desenho-arquitetura-solucao.md (§3.1–§3.3)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 170
skinparam nodesep 20
skinparam ranksep 90
left to right direction
title ArchiMate 3.2 — Motivação (2/2): Objetivos, Princípios, Requisitos e Restrições

Grouping(g_goal2, "Objetivos estratégicos (OE)") {
  Motivation_Goal(oe01, "OE-01 Digitalizar a geração de termos")
  Motivation_Goal(oe02, "OE-02 Reduzir o tempo de ciclo de contratação")
  Motivation_Goal(oe04, "OE-04 Melhorar a visibilidade do Gerente de Cash")
  Motivation_Goal(oe05, "OE-05 Garantir compliance")
}

Grouping(g_pri, "Princípios (PRI)") {
  Motivation_Principle(pri01, "PRI-01 Salesforce nunca integra diretamente com componentes do banco")
  Motivation_Principle(pri02, "PRI-02 ARO Atacado como camada anticorrupção")
  Motivation_Principle(pri03, "PRI-03 Reuso de componentes corporativos antes de construir")
  Motivation_Principle(pri05, "PRI-05 Consistência eventual com outbox transacional")
  Motivation_Principle(pri07, "PRI-07 APIs corporativas somente via Axway API Gateway")
  Motivation_Principle(pri10, "PRI-10 Canal abstraído e desacoplado por contrato")
  Motivation_Principle(pri11, "PRI-11 Rastreabilidade ponta a ponta por padrão")
  Motivation_Principle(pri12, "PRI-12 Separação de ciclos de vida Termo × Convênio")
}

Grouping(g_rf, "Requisitos funcionais (RF) — principais") {
  Motivation_Requirement(rf01, "RF-01 Receber do Salesforce a solicitação do Termo de Adesão (idempotente, 202 + idAdesao)")
  Motivation_Requirement(rf03, "RF-03 Consultar na FIRP (via Axway) os representantes com poderes")
  Motivation_Requirement(rf04, "RF-04 Gerar o documento do Termo (PDF base64, modelo versionado + hash)")
  Motivation_Requirement(rf06, "RF-06 Registrar o termo no GACD em 3 etapas como saga")
  Motivation_Requirement(rf07, "RF-07 Receber, validar e deduplicar o callback do GACD")
  Motivation_Requirement(rf08, "RF-08 Expor ao Canal a API de alerta de assinantes inválidos")
  Motivation_Requirement(rf09, "RF-09 Entregar status e alertas ao Salesforce (consistência eventual)")
  Motivation_Requirement(rf12, "RF-12 Publicar eventos-gatilho do Convênio (porta desativada)")
  Motivation_Requirement(rf13, "RF-13 Registrar trilha de auditoria e eventos para KPIs")
}

Grouping(g_rnf, "Requisitos não funcionais (RNF) — principais") {
  Motivation_Requirement(rnf01, "RNF-01 Autenticação e autorização em todas as fronteiras")
  Motivation_Requirement(rnf03, "RNF-03 Segmentação Hub and Spoke, private endpoints, ingress só pelo Axway")
  Motivation_Requirement(rnf04, "RNF-04 LGPD: minimização, mascaramento, staging ≤ 30 dias")
  Motivation_Requirement(rnf05, "RNF-05 Entrega at-least-once com consumidores idempotentes")
  Motivation_Requirement(rnf06, "RNF-06 Status no Salesforce p95 ≤ 60 s")
  Motivation_Requirement(rnf10, "RNF-10 Trilha de auditoria append-only correlacionada")
  Motivation_Requirement(rnf14, "RNF-14 Evidência documental: modelo aprovado + hash")
}

Grouping(g_rst, "Restrições (RST) e limites de escopo") {
  Motivation_Constraint(rst01, "RST-01 Salesforce só se comunica com serviços no ARO Atacado")
  Motivation_Constraint(rst02, "RST-02 Serviços no ARO, namespace atacado-core, vNet spoke (Plataformas Funcionais)")
  Motivation_Constraint(rst03, "RST-03 FIRP e GACD consumidos pelo Axway API Gateway")
  Motivation_Constraint(rst04, "RST-04 Canal externo entra por Akamai → Azure Application Gateway → Axway")
  Motivation_Constraint(rst05, "RST-05 Stack corporativa: Java prioritário (Python só para dados)")
  Motivation_Constraint(rst06, "RST-06 Segredos no Azure Key Vault")
  Motivation_Constraint(rst08, "RST-08 Callback do GACD fica na Azure (ARO Atacado), não no Salesforce")
  Motivation_Constraint(cns_canal, "Canal Digital PJ fora do escopo (abstraído; só contrato de API)")
}

' Princípios realizam objetivos
Rel_Realization(pri11, oe05)
Rel_Realization(pri01, oe05)
Rel_Realization(pri05, oe04)
Rel_Realization(pri03, oe02)
Rel_Realization(pri12, oe02)

' Requisitos realizam princípios / objetivos
Rel_Realization(rf01, pri02)
Rel_Realization(rf03, pri07)
Rel_Realization(rf06, pri07)
Rel_Realization(rf04, oe01)
Rel_Realization(rf07, pri05)
Rel_Realization(rf08, pri10)
Rel_Realization(rf09, pri05)
Rel_Realization(rf12, pri12)
Rel_Realization(rf13, pri11)
Rel_Realization(rnf01, pri01)
Rel_Realization(rnf03, pri01)
Rel_Realization(rnf04, oe05)
Rel_Realization(rnf05, pri05)
Rel_Realization(rnf06, oe04)
Rel_Realization(rnf10, pri11)
Rel_Realization(rnf14, oe05)

' Restrições realizam princípios / delimitam requisitos
Rel_Realization(rst01, pri01)
Rel_Realization(rst02, pri02)
Rel_Realization(rst03, pri07)
Rel_Realization(rst04, pri07)
Rel_Association(rst05, rf01)
Rel_Association(rst06, rnf01)
Rel_Association(rst08, rf07)
Rel_Realization(cns_canal, pri10)
@enduml
```

</details>

---

## 4. Camada de Estratégia

### 4.1 Value stream "Adesão a Produtos Cash" × capacidades CAP-01..13 (`am-02`)

**O que mostra.** O value stream **VS-01 Adesão a Produtos Cash** e seus cinco estágios, derivados do fluxo PN-01 → PN-11 (02 §3.3.2), com as **13 capacidades L1** do 02 §3.2 servindo cada estágio. As capacidades estão agrupadas como no mapa do 02 §4.2:
- Relacionamento e Adesão
- Formalização
- Pós-assinatura e Receita
- Transversais
- Externas

**Leitura.**
- **CAP-13 Gestão do Canal Digital PJ** é **externa**: serve o estágio de assinatura, mas fica fora do escopo de implementação do Atacado (dono: Time de Canais).
- **CAP-06 Gestão de Convênios** serve o estágio **VS-01.4 Implantar produtos e ativar Convênios** com status **indefinido** (QA-CON-02). O estágio inclui a implantação e a homologação com o cliente, feitas por pessoas (Gerente de Cash ou backoffice — QA-CON-24) **[PREMISSA — padrão de mercado]**. O nome anterior era "Habilitar produtos (Convênio por produto)".
- As capacidades transversais (CAP-10, CAP-11, CAP-12) servem as capacidades de negócio, não os estágios.
- A ordem VS-01.4 (Convênio ativo) antes de VS-01.5 (Tarifas) segue o texto do PRD (PRM-CON-08). O diagrama do PRD mostra a ordem inversa (QA-CON-05).

![ArchiMate — Estratégia 1/2](diagramas/archimate/am-02-estrategia.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-02-estrategia.puml</code></summary>

```plantuml
@startuml am-02-estrategia
' Viewpoint: Strategy / Capability Map x Value Stream
' Fontes: 02-desenho-conceitual.md (§3.1.3, §3.2, §4.2) e 01-contexto-de-negocio.md (§5, §7.2)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 170
skinparam nodesep 22
skinparam ranksep 38
title ArchiMate 3.2 — Estratégia (1/2): Value Stream "Adesão a Produtos Cash" × Capacidades CAP-01..13

Strategy_ValueStream(vs01, "VS-01 Adesão a Produtos Cash\n(valor: Cliente PJ Atacado com produtos Cash contratados e tarifados)")

Grouping(g_vs, "Estágios do value stream") {
  Strategy_ValueStream(vs01_1, "VS-01.1 Negociar e aprovar a Proposta")
  Strategy_ValueStream(vs01_2, "VS-01.2 Verificar elegibilidade e formalizar o Termo de Adesão")
  Strategy_ValueStream(vs01_3, "VS-01.3 Obter a assinatura do Cliente PJ Atacado")
  Strategy_ValueStream(vs01_4, "VS-01.4 Implantar produtos e ativar Convênios")
  Strategy_ValueStream(vs01_5, "VS-01.5 Cadastrar tarifas e iniciar a receita")
}

Grouping(g_rel, "Relacionamento e Adesão") {
  Strategy_Capability(cap01, "CAP-01 Gestão de Relacionamento Comercial\n[existente]")
  Strategy_Capability(cap02, "CAP-02 Gestão de Adesão a Produtos Cash\n[nova]")
}
Grouping(g_form, "Formalização") {
  Strategy_Capability(cap03, "CAP-03 Gestão do Termo de Adesão\n[nova]")
  Strategy_Capability(cap04, "CAP-04 Gestão de Representantes e Poderes\n[reuso FIRP]")
  Strategy_Capability(cap08, "CAP-08 Gestão Documental\n[nova/reuso — DEC-CON-03]")
  Strategy_Capability(cap05, "CAP-05 Gestão de Assinatura Digital\n[reuso GACD; receptor novo]")
}
Grouping(g_ext, "Externa — fora do escopo do Atacado") {
  Strategy_Capability(cap13, "CAP-13 Gestão do Canal Digital PJ\n[externa — Time de Canais]")
}
Grouping(g_pos, "Pós-assinatura e Receita") {
  Strategy_Capability(cap06, "CAP-06 Gestão de Convênios\n[indefinida — QA-CON-02]")
  Strategy_Capability(cap07, "CAP-07 Gestão de Tarifas\n[existente — Databricks]")
  Strategy_Capability(cap09, "CAP-09 Notificação e Acompanhamento de Status\n[nova]")
}
Grouping(g_trans, "Transversais (habilitadoras)") {
  Strategy_Capability(cap10, "CAP-10 Integração e Exposição de APIs\n[nova/reuso Axway]")
  Strategy_Capability(cap11, "CAP-11 Segurança e Identidade de Integração\n[reuso/a confirmar]")
  Strategy_Capability(cap12, "CAP-12 Rastreabilidade, Auditoria e Conformidade\n[nova]")
}

' Composição e fluxo do value stream
Rel_Composition_Down(vs01, vs01_1)
Rel_Composition_Down(vs01, vs01_2)
Rel_Composition_Down(vs01, vs01_3)
Rel_Composition_Down(vs01, vs01_4)
Rel_Composition_Down(vs01, vs01_5)
Rel_Flow_Right(vs01_1, vs01_2)
Rel_Flow_Right(vs01_2, vs01_3)
Rel_Flow_Right(vs01_3, vs01_4)
Rel_Flow_Right(vs01_4, vs01_5)

' Capacidades servem estágios
Rel_Serving_Up(cap01, vs01_1)
Rel_Serving_Up(cap02, vs01_2)
Rel_Serving_Up(cap03, vs01_2)
Rel_Serving_Up(cap04, vs01_2)
Rel_Serving_Up(cap08, vs01_2)
Rel_Serving_Up(cap05, vs01_3)
Rel_Serving_Up(cap13, vs01_3)
Rel_Serving_Up(cap06, vs01_4)
Rel_Serving_Up(cap07, vs01_5)
Rel_Serving_Up(cap09, vs01_3)

' Transversais servem as capacidades de negócio (habilitadoras)
Rel_Serving_Up(cap10, cap03)
Rel_Serving_Up(cap10, cap05)
Rel_Serving_Up(cap11, cap10)
Rel_Serving_Up(cap12, cap05)

' Layout auxiliar (não é relação ArchiMate)
cap01 -[hidden]down- cap02
cap03 -[hidden]down- cap04
cap04 -[hidden]down- cap08
cap06 -[hidden]down- cap09
@enduml
```

</details>

### 4.2 Recursos, cursos de ação e realização dos objetivos (`am-02b`)

**O que mostra.**
- **Recursos** (RES-01..06) atribuídos às capacidades.
- Capacidades que **realizam objetivos**, conforme a tabela de capacidades estratégicas do 02 §3.1.3.
- **Cursos de ação** (COA-01..06), que resumem as escolhas estratégicas já registradas:
  - digitalizar a adesão no Salesforce;
  - reusar antes de construir (PRI-03);
  - usar o ARO Atacado como camada anticorrupção (PRI-02, OP-02);
  - IMPD como Plano A, com geração própria como Plano B (ADR-03);
  - Convênio atrás de porta desativada (ADR-11);
  - status em tempo quase real por outbox e upsert (ADR-05, ADR-06).

Cada curso de ação realiza objetivos e se associa à capacidade que desenvolve.

![ArchiMate — Estratégia 2/2](diagramas/archimate/am-02b-estrategia-cursos-de-acao.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-02b-estrategia-cursos-de-acao.puml</code></summary>

```plantuml
@startuml am-02b-estrategia-cursos-de-acao
' Viewpoint: Strategy — Resources, Capabilities, Courses of Action realizando Goals
' Fontes: 01 (§5.1, §5.3, §10), 02 (§3.1.3, §6), 04 (§13 ADRs)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 200
skinparam nodesep 18
skinparam ranksep 110
left to right direction
title ArchiMate 3.2 — Estratégia (2/2): Recursos, Capacidades e Cursos de Ação realizando os Objetivos

Grouping(g_res, "Recursos") {
  Strategy_Resource(res01, "RES-01 Salesforce (Salesforce Financial Services Cloud) — jornada do Gerente de Cash")
  Strategy_Resource(res02, "RES-02 Plataforma ARO Atacado (namespace atacado-core, Plataformas Funcionais)")
  Strategy_Resource(res03, "RES-03 Serviços corporativos GACD, FIRP e GCC/Filenet")
  Strategy_Resource(res04, "RES-04 Modelos do Termo de Adesão (Produtos / Produtos + Canal) aprovados pelo Jurídico/Compliance")
  Strategy_Resource(res05, "RES-05 Pipeline de Tarifas no Databricks")
  Strategy_Resource(res06, "RES-06 Time do Atacado Cash Payments (dono dos Serviços de Integração do Atacado)")
}

Grouping(g_cap, "Capacidades (seleção)") {
  Strategy_Capability(cap02, "CAP-02 Gestão de Adesão a Produtos Cash")
  Strategy_Capability(cap03, "CAP-03 Gestão do Termo de Adesão")
  Strategy_Capability(cap05, "CAP-05 Gestão de Assinatura Digital")
  Strategy_Capability(cap06, "CAP-06 Gestão de Convênios")
  Strategy_Capability(cap07, "CAP-07 Gestão de Tarifas")
  Strategy_Capability(cap09, "CAP-09 Notificação e Acompanhamento de Status")
  Strategy_Capability(cap10, "CAP-10 Integração e Exposição de APIs")
  Strategy_Capability(cap12, "CAP-12 Rastreabilidade, Auditoria e Conformidade")
}

Grouping(g_coa, "Cursos de ação") {
  Strategy_CourseOfAction(coa01, "COA-01 Digitalizar a adesão na jornada do Salesforce (o Gerente não sai do Salesforce)")
  Strategy_CourseOfAction(coa02, "COA-02 Reusar componentes corporativos antes de construir (PRI-03)")
  Strategy_CourseOfAction(coa03, "COA-03 ARO Atacado como plataforma de integração e camada anticorrupção (PRI-02, OP-02)")
  Strategy_CourseOfAction(coa04, "COA-04 Geração do documento: IMPD API cloud (Plano A) com geração própria (Plano B) (ADR-03)")
  Strategy_CourseOfAction(coa05, "COA-05 Convênio preparado por porta desativada e eventos-gatilho (ADR-11)")
  Strategy_CourseOfAction(coa06, "COA-06 Status em tempo quase real via outbox e upsert no Salesforce (ADR-05, ADR-06)")
}

Grouping(g_oe, "Objetivos estratégicos (OE)") {
  Motivation_Goal(oe01, "OE-01 Digitalizar a geração de termos")
  Motivation_Goal(oe02, "OE-02 Reduzir o tempo de ciclo de contratação")
  Motivation_Goal(oe03, "OE-03 Aumentar a conversão de contratações")
  Motivation_Goal(oe04, "OE-04 Melhorar a visibilidade do Gerente de Cash")
  Motivation_Goal(oe05, "OE-05 Garantir compliance")
}

' Recursos atribuídos a capacidades
Rel_Assignment(res01, cap02)
Rel_Assignment(res01, cap09)
Rel_Assignment(res02, cap10)
Rel_Assignment(res03, cap05)
Rel_Assignment(res04, cap03)
Rel_Assignment(res05, cap07)
Rel_Assignment(res06, cap02)

' Capacidades realizam objetivos (02 §3.1.3)
Rel_Realization(cap02, oe01)
Rel_Realization(cap03, oe01)
Rel_Realization(cap05, oe03)
Rel_Realization(cap06, oe02)
Rel_Realization(cap07, oe02)
Rel_Realization(cap09, oe04)
Rel_Realization(cap12, oe05)

' Cursos de ação realizam objetivos
Rel_Realization(coa01, oe01)
Rel_Realization(coa01, oe02)
Rel_Realization(coa02, oe02)
Rel_Realization(coa03, oe05)
Rel_Realization(coa04, oe01)
Rel_Realization(coa05, oe02)
Rel_Realization(coa06, oe04)

' Cursos de ação x capacidades que desenvolvem
Rel_Association(cap02, coa01)
Rel_Association(cap05, coa02)
Rel_Association(cap10, coa03)
Rel_Association(cap03, coa04)
Rel_Association(cap06, coa05)
Rel_Association(cap09, coa06)
@enduml
```

</details>

---

## 5. Camada de Negócio

### 5.1 Processos e eventos (`am-03`)

**O que mostra.** Os 12 processos (PN-01..PN-12), as quatro atividades do PN-10 (PN-10.1..PN-10.4) e os 13 eventos (EVN-01..EVN-13) do 02 §3.3.2–3.3.3, ligados por *triggering*. As atividades aparecem **dentro** da caixa do PN-10 (composição por aninhamento; no modelo Open Exchange, relações de composição). A vista está organizada em cinco fases:
1. Negociação e elegibilidade (Salesforce)
2. Formalização (Serviços de Integração do Atacado)
3. Assinatura (Canal Digital PJ, externo)
4. Confirmação e acompanhamento
5. Pós-assinatura (implantação, Convênio e Tarifas)

**Leitura.**
- EVN-02 dispara PN-03 **somente sem contrato vigente**. Com contrato vigente, PN-02 segue direto para a implantação (EVN-13 → PN-10; ramo "SIM" do PRD).
- O desvio PN-07 → EVN-07 → PN-08 volta para PN-02 ("Gerente regulariza e reemite").
- EVN-08 dispara PN-09 (callback) e **abre a implantação** (EVN-13 Implantação iniciada), como indicam PRI-12 e RN-13. A assinatura não cria o convênio.
- **PN-10 Implantar produto e gerar Convênio** (por produto) tem quatro atividades: PN-10.1 definir parâmetros com o cliente (layout CNAB 240/400 ou API, canal de transmissão, contas, carteira) → PN-10.2 criar o convênio em modo teste no sistema do produto → PN-10.3 homologar com o cliente (remessa e retorno) → PN-10.4 ativar o convênio (RN-17). O executor é o **Gerente de Cash ou o backoffice** (a definir — QA-CON-24), nunca um processo automático. Etapas e executor são **[PREMISSA — padrão de mercado]** (PRM-CON-15).
- **EVN-10 Convênio ativado** (após a homologação) dispara PN-11: o cadastro de tarifas depende do **convênio ativo**.
- EVN-13 e EVN-10 alimentam PN-12 com os status da jornada por produto: "Em implantação" e "Convênio ativo" (depois, "Tarifas cadastradas" por EVN-11).
- **EVN-12** (recusado, expirado ou cancelado) é **hipótese** (QA-CON-12).
- O sistema onde o convênio é criado e registrado continua **indefinido** (sistema de cada produto, APP-09 — QA-CON-02). A fase Pós-assinatura aparece antes de "Confirmação e acompanhamento" (§12).
- Os processos executados por "Serviços de Integração do Atacado" são automatizados (APP-02). Na vista integrada (§8), eles são servidos pelos serviços de aplicação.

![ArchiMate — Negócio 1/3](diagramas/archimate/am-03-negocio.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-03-negocio.puml</code></summary>

```plantuml
@startuml am-03-negocio
' Viewpoint: Business Process Cooperation — processos PN-01..12 (PN-10.1..10.4) e eventos EVN-01..13
' Fonte: 02-desenho-conceitual.md (§3.3.2, §3.3.3)
!include <archimate/Archimate>
' Variantes "NR" (norank): mesma semântica ArchiMate, sem influenciar o layout
!procedure Rel_Triggering_NR($a, $b, $l="")
!if ($l == "")
$a -[norank]->> $b
!else
$a -[norank]->> $b : $l
!endif
!endprocedure
!procedure Rel_Flow_NR($a, $b, $l="")
!if ($l == "")
$a .[norank].>> $b
!else
$a .[norank].>> $b : $l
!endif
!endprocedure
skinparam defaultFontSize 12
skinparam wrapWidth 160
skinparam nodesep 25
skinparam ranksep 30
title ArchiMate 3.2 — Negócio (1/3): Processos de negócio (PN) e eventos (EVN) da jornada de adesão

Grouping(g_f1, "Negociação e elegibilidade (Salesforce)") {
  Business_Process(pn01, "PN-01 Negociar e aprovar Proposta\n[existente — Gerente de Cash]")
  Business_Event(evn01, "EVN-01 Proposta aprovada")
  Business_Process(pn02, "PN-02 Verificar elegibilidade e definir tipo de termo\n[Gerente de Cash]")
  Business_Event(evn02, "EVN-02 Termo de Adesão solicitado")
}

Grouping(g_f2, "Formalização (Serviços de Integração do Atacado)") {
  Business_Process(pn03, "PN-03 Identificar assinantes")
  Business_Event(evn03, "EVN-03 Assinantes identificados")
  Business_Process(pn04, "PN-04 Gerar Termo de Adesão")
  Business_Event(evn04, "EVN-04 Termo de Adesão gerado")
  Business_Process(pn05, "PN-05 Registrar termo para assinatura")
  Business_Event(evn05, "EVN-05 Protocolo de assinatura emitido (codigoProtocolo)")
}

Grouping(g_f3, "Assinatura (Canal Digital PJ — externo, Time de Canais)") {
  Business_Event(evn06, "EVN-06 Termo disponibilizado para assinatura")
  Business_Process(pn06, "PN-06 Disponibilizar termo e notificar o cliente\n[e-mail: dono indefinido]")
  Business_Process(pn07, "PN-07 Revalidar assinantes e assinar o termo\n[Assinante/Representante]")
  Business_Event(evn07, "EVN-07 Assinantes invalidados")
  Business_Process(pn08, "PN-08 Tratar assinantes inválidos\n[Canal Digital PJ / Gerente de Cash]")
}

Grouping(g_f4, "Confirmação e acompanhamento") {
  Business_Event(evn08, "EVN-08 Termo de Adesão assinado")
  Business_Process(pn09, "PN-09 Confirmar assinatura e atualizar status\n[Serviços de Integração do Atacado]")
  Business_Event(evn09, "EVN-09 Status do termo atualizado no Salesforce")
  Business_Process(pn12, "PN-12 Acompanhar status e indicadores\n[Gerente de Cash]")
  Business_Event(evn12, "EVN-12 Termo recusado / expirado / cancelado\n[hipótese — QA-CON-12]")
}

Grouping(g_f5, "Pós-assinatura (implantação, Convênio e Tarifas)") {
  Business_Event(evn13, "EVN-13 Implantação iniciada (por produto)")
  Business_Process(pn10, "PN-10 Implantar produto\ne gerar Convênio\n[Gerente de Cash ou backoffice\n— QA-CON-24]") {
    Business_Process(pn10_1, "PN-10.1 Definir parâmetros com o cliente\n(layout CNAB 240/400 ou API, canal, contas, carteira)")
    Business_Process(pn10_2, "PN-10.2 Criar o convênio em modo teste\nno sistema do produto [QA-CON-02]")
    Business_Process(pn10_3, "PN-10.3 Homologar com o cliente\n(remessa e retorno)")
    Business_Process(pn10_4, "PN-10.4 Ativar o convênio (RN-17)")
  }
  Business_Event(evn10, "EVN-10 Convênio ativado (por produto)")
  Business_Process(pn11, "PN-11 Cadastrar Tarifas\n[existente — Databricks; depende do convênio ativo]")
  Business_Event(evn11, "EVN-11 Tarifas cadastradas")
}

' Cadeias dentro de cada fase
Rel_Triggering_Down(pn01, evn01)
Rel_Triggering_Down(evn01, pn02)
Rel_Triggering_Down(pn02, evn02)
Rel_Triggering_Down(pn03, evn03)
Rel_Triggering_Down(evn03, pn04)
Rel_Triggering_Down(pn04, evn04)
Rel_Triggering_Down(evn04, pn05)
Rel_Triggering_Down(pn05, evn05)
Rel_Triggering_Down(evn06, pn06)
Rel_Triggering_Down(pn06, pn07)
Rel_Triggering_Down(pn07, evn07)
Rel_Triggering_Down(evn07, pn08)
Rel_Triggering_Down(evn08, pn09)
Rel_Triggering_Down(pn09, evn09)
Rel_Triggering_Down(evn09, pn12)
Rel_Triggering_Up(evn12, pn12)
Rel_Triggering_Down(evn13, pn10_1)
Rel_Triggering_Down(pn10_1, pn10_2)
Rel_Triggering_Down(pn10_2, pn10_3)
Rel_Triggering_Down(pn10_3, pn10_4)
Rel_Triggering_Down(pn10_4, evn10)
Rel_Triggering_Down(evn10, pn11)
Rel_Triggering_Down(pn11, evn11)
' Composição do PN-10 (desenhada por aninhamento) e nome do PN-10 no modelo (o rótulo quebra só por layout)
'@name pn10 PN-10 Implantar produto e gerar Convênio
'@xml Rel_Composition(pn10, pn10_1)
'@xml Rel_Composition(pn10, pn10_2)
'@xml Rel_Composition(pn10, pn10_3)
'@xml Rel_Composition(pn10, pn10_4)

' Passagens entre fases
Rel_Triggering_NR(evn02, pn03, "sem contrato vigente")
Rel_Triggering_NR(pn05, evn06)
Rel_Triggering_NR(pn07, evn08)
Rel_Triggering_NR(evn05, pn09, "correlação")
Rel_Triggering_NR(evn08, evn13, "abre a implantação (PRI-12, RN-13)")
Rel_Triggering_NR(evn13, pn12, "status Em implantação")
Rel_Triggering_NR(evn10, pn12, "status Convênio ativo")
Rel_Triggering_NR(evn11, pn12)
Rel_Flow_NR(pn08, pn02, "Gerente regulariza e reemite")
Rel_Flow_NR(pn02, evn13, "com contrato vigente (adesão dispensada)")
' Layout auxiliar (não é relação ArchiMate): alinha o topo das fases
' (sem aresta oculta evn08 → evn13: com EVN-13 já ligado por PRI-12, ela faz o Graphviz 2.42 falhar)
pn01 -[hidden]right- pn03
pn03 -[hidden]right- evn06
evn06 -[hidden]right- evn08
@enduml
```

</details>

### 5.2 Atores, papéis, colaboração entre times e serviços de negócio (`am-03b`)

**O que mostra.**
- Os atores ATR-01..ATR-09 (02 §3.3.1) desempenham papéis.
- Os papéis dos quatro times formam a colaboração **Colaboração Aceite Digital Cash** (Atacado Cash Payments, Canais, Experiência e GACD), coerente com a RACI do 01 §6.3.
- Os papéis provedores realizam **serviços de negócio**, que servem os papéis consumidores (Solicitante do Termo, Signatário, Contratante).

**Leitura.**
- O serviço "Aceite Digital de termos e contratos (GACD)" serve tanto a Formalização quanto a Assinatura no Canal, porque o Canal busca as pendências no GACD (PRM-CON-07).
- O Time de Experiência não provê serviço próprio: ele desenha a experiência da assinatura (PRM-CON-10).
- O serviço "Implantação de produto e geração de Convênio" é realizado pelo papel **Executor da implantação do produto**, ainda a definir (QA-CON-24). Os dois candidatos aparecem ligados ao papel: **ATR-01 Gerente de Cash** e o novo **ATR-09 Backoffice de Cash**. Se existir uma área de implantação de Cash, ela ocupa o papel (QA-CON-25). Executor e etapa são **[PREMISSA — padrão de mercado]**.
- O convênio fica registrado no sistema do produto, ainda indefinido (QA-CON-02).

![ArchiMate — Negócio 2/3](diagramas/archimate/am-03b-negocio-atores-servicos.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-03b-negocio-atores-servicos.puml</code></summary>

```plantuml
@startuml am-03b-negocio-atores-servicos
' Viewpoint: Organization / Actor Co-operation — atores ATR-01..09, papéis, colaboração entre times e serviços de negócio
' Fontes: 02-desenho-conceitual.md (§3.3.1, §3.2) e 01-contexto-de-negocio.md (§6)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 160
skinparam nodesep 22
skinparam ranksep 55
title ArchiMate 3.2 — Negócio (2/3): Atores, papéis, colaboração entre times e serviços de negócio

Grouping(g_cli, "Cliente") {
  Business_Actor(atr02, "ATR-02 Cliente PJ Atacado")
  Business_Actor(atr03, "ATR-03 Assinante/Representante")
}
Grouping(g_com, "Área comercial") {
  Business_Actor(atr01, "ATR-01 Gerente de Cash")
  Business_Actor(atr04, "ATR-04 Aprovador da Proposta\n[não identificado — QA-CON-23]")
}
Grouping(g_times, "Times envolvidos") {
  Business_Actor(atr08, "ATR-08 Time do Atacado Cash Payments")
  Business_Actor(atr05, "ATR-05 Time de Canais")
  Business_Actor(atr06, "ATR-06 Time de Experiência")
  Business_Actor(atr07, "ATR-07 Time do GACD")
}
Grouping(g_bo, "Backoffice (a confirmar)") {
  Business_Actor(atr09, "ATR-09 Backoffice de Cash\n[candidato — QA-CON-24, QA-CON-25]")
}

Business_Role(rl_contr, "Contratante")
Business_Role(rl_sign, "Signatário do Termo de Adesão")
Business_Role(rl_solic, "Solicitante do Termo de Adesão")
Business_Role(rl_aprov, "Aprovador da Proposta")
Business_Role(rl_dono, "Dono da jornada e dos Serviços de Integração do Atacado")
Business_Role(rl_canal, "Provedor do Canal Digital PJ")
Business_Role(rl_exp, "Responsável pela experiência da jornada")
Business_Role(rl_gacd, "Provedor de Aceite Digital")
Business_Role(rl_impl, "Executor da implantação do produto\n[a definir — QA-CON-24]")

Business_Collaboration(col01, "Colaboração Aceite Digital Cash\n(Atacado Cash Payments + Canais + Experiência + GACD)")

Grouping(g_bs, "Serviços de negócio") {
  Business_Service(bs01, "Formalização Digital do Termo de Adesão")
  Business_Service(bs02, "Aceite Digital de termos e contratos (GACD)")
  Business_Service(bs03, "Assinatura no Canal Digital PJ")
  Business_Service(bs04, "Acompanhamento de Status da Adesão")
  Business_Service(bs05, "Implantação de produto e geração de Convênio\n[sistema do produto — QA-CON-02]")
}

' Atores desempenham papéis
Rel_Assignment_Down(atr02, rl_contr)
Rel_Assignment_Down(atr03, rl_sign)
Rel_Assignment_Down(atr01, rl_solic)
Rel_Assignment_Down(atr04, rl_aprov)
Rel_Assignment_Down(atr08, rl_dono)
Rel_Assignment_Down(atr05, rl_canal)
Rel_Assignment_Down(atr06, rl_exp)
Rel_Assignment_Down(atr07, rl_gacd)
Rel_Assignment_Down(atr01, rl_impl, "candidato")
Rel_Assignment_Down(atr09, rl_impl, "candidato")
Rel_Association(rl_sign, rl_contr, "representa")

' Colaboração entre times
Rel_Aggregation_Up(col01, rl_dono)
Rel_Aggregation_Up(col01, rl_canal)
Rel_Aggregation_Up(col01, rl_exp)
Rel_Aggregation_Up(col01, rl_gacd)

' Provedores realizam serviços
Rel_Realization_Down(rl_dono, bs01)
Rel_Realization_Down(rl_dono, bs04)
Rel_Realization_Down(rl_gacd, bs02)
Rel_Realization_Down(rl_canal, bs03)
Rel_Association(rl_exp, bs03, "desenha a experiência")
Rel_Realization_Down(rl_impl, bs05)

' Serviços servem consumidores
Rel_Serving_Up(bs01, rl_solic)
Rel_Serving_Up(bs04, rl_solic)
Rel_Serving(bs02, bs01)
Rel_Serving(bs02, bs03)
Rel_Serving_Up(bs03, rl_sign)
Rel_Serving_Up(bs05, rl_contr)
@enduml
```

</details>

### 5.3 Objetos de negócio (`am-03c`)

**O que mostra.** Os objetos OBJ-01..OBJ-10 (02 §3.3.4), com o sistema de registro conceitual no rótulo. A vista também mostra o acesso dos processos a esses objetos (leitura/escrita) e as relações estruturais do 02 §3.3.5.

**Leitura.** Os rótulos usam a numeração mestre de regras do 01 §8.1 (também usada no 02 §3.3.5 desde a v0.3): RN-01 multiproduto, RN-02 dispensa por contrato vigente, RN-11 convênio por produto e RN-12 convênio como pré-requisito das tarifas (convênio **ativo**).

- **OBJ-07 Convênio** tem dois estados: **Em teste** (homologação com o cliente) → **Ativo** (RN-17). Os estados são **[PREMISSA — padrão de mercado]** e aparecem no rótulo, porque o ArchiMate não modela estados de objeto.
- O convênio é registrado no **sistema do produto** (APP-09, indefinido — QA-CON-02). O Salesforce mostra só o número e o status.

![ArchiMate — Negócio 3/3](diagramas/archimate/am-03c-negocio-objetos.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-03c-negocio-objetos.puml</code></summary>

```plantuml
@startuml am-03c-negocio-objetos
' Viewpoint: Information Structure (negócio) — objetos OBJ-01..10 e acesso pelos processos PN
' Fonte: 02-desenho-conceitual.md (§3.3.2, §3.3.4, §3.3.5)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 170
skinparam nodesep 28
skinparam ranksep 70
left to right direction
title ArchiMate 3.2 — Negócio (3/3): Objetos de negócio (OBJ) e acesso pelos processos

Grouping(g_pn, "Processos de negócio (seleção)") {
  Business_Process(pn01, "PN-01 Negociar e aprovar Proposta")
  Business_Process(pn02, "PN-02 Verificar elegibilidade e definir tipo de termo")
  Business_Process(pn03, "PN-03 Identificar assinantes")
  Business_Process(pn04, "PN-04 Gerar Termo de Adesão")
  Business_Process(pn05, "PN-05 Registrar termo para assinatura")
  Business_Process(pn07, "PN-07 Revalidar assinantes e assinar o termo")
  Business_Process(pn10, "PN-10 Implantar produto e gerar Convênio")
  Business_Process(pn11, "PN-11 Cadastrar Tarifas")
}

Grouping(g_obj, "Objetos de negócio (sistema de registro conceitual)") {
  Business_Object(obj01, "OBJ-01 Proposta\n[Salesforce]")
  Business_Object(obj10, "OBJ-10 Contrato vigente\n[fonte a definir — QA-CON-21]")
  Business_Object(obj03, "OBJ-03 Assinante/Representante\n[FIRP]")
  Business_Object(obj04, "OBJ-04 Poder de assinatura\n[FIRP]")
  Business_Object(obj02, "OBJ-02 Termo de Adesão\n(único, multiproduto; tipos Produtos / Produtos + Canal)")
  Business_Object(obj05, "OBJ-05 Protocolo de assinatura\n(codigoProtocolo) [GACD]")
  Business_Object(obj06, "OBJ-06 Prévia do documento\n(IdPrevia, CaminhoPrevia) [GCC/Filenet]")
  Business_Object(obj09, "OBJ-09 Produto Cash\n[lista ausente — QA-CON-06]")
  Business_Object(obj07, "OBJ-07 Convênio\n(por produto; estados Em teste → Ativo — RN-17)\n[sistema do produto; Salesforce só número e status]")
  Business_Object(obj08, "OBJ-08 Tarifa\n[Databricks]")
}

' Acesso dos processos aos objetos
Rel_Access_w(pn01, obj01)
Rel_Access_r(pn02, obj01)
Rel_Access_r(pn02, obj10)
Rel_Access_r(pn03, obj03)
Rel_Access_r(pn03, obj04)
Rel_Access_w(pn04, obj02)
Rel_Access_w(pn05, obj05)
Rel_Access_w(pn05, obj06)
Rel_Access_rw(pn07, obj02)
Rel_Access_w(pn10, obj07)
Rel_Access_w(pn11, obj08)

' Relações estruturais entre objetos
Rel_Aggregation(obj01, obj09, "produtos negociados")
Rel_Aggregation(obj02, obj09, "RN-01 multiproduto")
Rel_Association(obj02, obj03, "assinado por")
Rel_Association(obj03, obj04, "detém")
Rel_Association(obj02, obj05, "registrado em")
Rel_Association(obj05, obj06, "prévia")
Rel_Association(obj10, obj02, "RN-02 dispensa")
Rel_Association(obj07, obj09, "1 por produto (RN-11)")
Rel_Association(obj08, obj07, "pré-requisito: convênio ativo (RN-12)")
@enduml
```

</details>

---

## 6. Camada de Aplicação (`am-04`)

**O que mostra.** A cooperação entre:
- os componentes **novos** COMP-01, COMP-02 e COMP-03, que formam o APP-02 Serviços de Integração do Atacado no ARO Atacado;
- **COMP-06**, os artefatos no Salesforce;
- os componentes **corporativos** consumidos: FIRP, GACD, GCC/Filenet e IMPD API cloud;
- os externos: Canal Digital PJ, Sistema de Convênio (indefinido) e Databricks (Tarifas).

A vista também traz as interfaces e os serviços de aplicação:

| Interface / serviço | Componente | Referência |
|---|---|---|
| API Adesão v1 | COMP-01 | 04 §11.1 |
| Callback GACD | COMP-02 | 04 §11.2 |
| API de alerta de assinantes inválidos | COMP-02 | 04 §11.3 |
| Entrega de status e alertas ao Salesforce | COMP-03 | 04 §11.4 |

Os objetos de dados (estado/saga, inbox, outbox, auditoria e PDF em staging) ficam no COMP-04 e no COMP-05.

**Leitura.**
- **Entrada:** o Salesforce (COMP-06) é servido só pela API Adesão v1 do COMP-01 (RST-01). A rota física Akamai → Application Gateway → Axway está na §7.
- **Sinais:** o GACD (callback) e o Canal (alerta) são servidos pelas interfaces do COMP-02, que grava na **inbox**. O COMP-01 consome a inbox (ADR-08, ADR-09).
- **Saída:** o COMP-01 grava na **outbox**. O COMP-03 lê a outbox e entrega ao Salesforce pela interface de upsert REST do COMP-06, com OAuth 2.0 JWT Bearer (ADR-05, ADR-06).
- **Dependências:** FIRP, GACD e IMPD servem o COMP-01 via Axway (FIRP e GACD) ou por rota a confirmar (IMPD, Plano A do ADR-03).
- **Convênio:** o fluxo para o Sistema de Convênio sai da porta `convenio-produto`, que está **desativada** (ADR-11). Quando ativada, a porta tende a **abrir uma pendência de implantação** (tarefa para o Gerente de Cash ou o backoffice, visível no Salesforce) e acompanhar o status (Em implantação → Convênio ativo), e **não** a criar o convênio direto por API no sistema do produto **[PREMISSA — padrão de mercado]**. A aresta desta vista mostra só a dependência entre os componentes.

![ArchiMate — Aplicação](diagramas/archimate/am-04-aplicacao.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-04-aplicacao.puml</code></summary>

```plantuml
@startuml am-04-aplicacao
' Viewpoint: Application Cooperation — componentes COMP-xx, serviços, interfaces e objetos de dados
' Fontes: 04-desenho-arquitetura-solucao.md (§4, §5, §11) e 04a-componentes-e-justificativas.md
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 190
skinparam nodesep 30
skinparam ranksep 55
title ArchiMate 3.2 — Aplicação: Serviços de Integração do Atacado (COMP-01..06) e componentes corporativos

Grouping(g_sf, "Salesforce (Salesforce Financial Services Cloud) — SaaS") {
  Application_Component(app01, "APP-01 Salesforce\n(jornada do Gerente de Cash)")
  Application_Component(comp06, "COMP-06 Artefatos Salesforce do Atacado\n(LWC/Flow, Named Credential, Adesao_Termo~_~_c, Alerta_Adesao~_~_c)")
  Application_Interface(if_upsert, "Upsert de status (REST)")
}

Grouping(g_aro, "APP-02 Serviços de Integração do Atacado — ARO Atacado, namespace atacado-core [NOVOS]") {
  Application_Interface(if_adesao, "API Adesão v1\n(POST /v1/adesoes)")
  Application_Service(as_adesao, "Solicitação, confirmação e consulta da adesão")
  Application_Component(comp01, "COMP-01 atacado-adesao-termo\n(adesao-termo, acl-firp, acl-gacd/saga, termo-documento, acl-registro-contratos, convenio-produto [desativada])")
  Application_Interface(if_callback, "Callback GACD")
  Application_Interface(if_alerta, "API de alerta de assinantes inválidos\n(Alerta de Assinantes Inválidos v1)")
  Application_Component(comp02, "COMP-02 atacado-adesao-receptor\n(ACL de entrada, deduplicação, inbox)")
  Application_Component(comp03, "COMP-03 atacado-adesao-acompanhamento\n(relay da outbox, projeção, entrega ao Salesforce)")
  Application_Service(as_status, "Entrega de status e alertas ao Salesforce")
}

Grouping(g_dados, "Objetos de dados (COMP-04 atacado-adesao-db / COMP-05 atacado-adesao-staging)") {
  Application_DataObject(do_estado, "AdesaoTermo: estado e saga")
  Application_DataObject(do_inbox, "Inbox (sinais recebidos)")
  Application_DataObject(do_outbox, "Outbox (eventos a entregar)")
  Application_DataObject(do_audit, "Trilha de auditoria (append-only)")
  Application_DataObject(do_pdf, "PDF do Termo (base64, staging ≤ 30 dias)")
}

Grouping(g_corp, "Componentes corporativos consumidos (via Axway API Gateway)") {
  Application_Component(comp13, "COMP-13 FIRP")
  Application_Service(as_firp, "Consulta de representantes e poderes")
  Application_Component(comp14, "COMP-14 GACD")
  Application_Service(as_gacd, "Coordenar Contrato → Armazenar Prévia → Coordenar Regra")
  Application_Component(comp15, "COMP-15 GCC/Filenet")
  Application_Component(comp16, "COMP-16 IMPD API cloud\n(impd-srv-doc-generator) — Plano A")
  Application_Service(as_impd, "Renderização de PDF (base64)")
}

Grouping(g_ext, "Externos / fora do escopo") {
  Application_Component(comp18, "COMP-18 Canal Digital PJ\n[abstraído — Time de Canais]")
  Application_Component(app09, "APP-09 Sistema de Convênio (indefinido)")
  Application_Component(comp20, "COMP-20 Databricks (Tarifas)\n[sem integração nesta entrega]")
}

' Salesforce
Rel_Composition_Down(app01, comp06)
Rel_Composition(comp06, if_upsert)

' COMP-01 — API Adesão
Rel_Composition(comp01, if_adesao)
Rel_Realization_Up(comp01, as_adesao)
Rel_Assignment(if_adesao, as_adesao)
Rel_Serving_Up(as_adesao, comp06)

' Dependências de COMP-01
Rel_Serving_Up(as_firp, comp01)
Rel_Serving_Up(as_gacd, comp01)
Rel_Serving_Up(as_impd, comp01)
Rel_Realization(comp13, as_firp)
Rel_Realization(comp14, as_gacd)
Rel_Realization(comp16, as_impd)
Rel_Serving(comp15, comp14)

' COMP-02 — sinais de entrada
Rel_Composition(comp02, if_callback)
Rel_Composition(comp02, if_alerta)
Rel_Serving_Down(if_callback, comp14, "callback de assinatura")
Rel_Serving_Down(if_alerta, comp18, "alerta de assinantes inválidos")
Rel_Access_w(comp02, do_inbox)
Rel_Access_r(comp01, do_inbox)

' COMP-01 dados
Rel_Access_rw(comp01, do_estado)
Rel_Access_w(comp01, do_outbox)
Rel_Access_w(comp01, do_audit)
Rel_Access_rw(comp01, do_pdf)

' COMP-03 — saída
Rel_Access_r(comp03, do_outbox)
Rel_Realization(comp03, as_status)
Rel_Serving_Up(as_status, comp06)
Rel_Serving_Down(if_upsert, comp03, "upsert REST — OAuth 2.0 JWT Bearer")

' Canal
Rel_Serving(as_gacd, comp18)
Rel_Serving(as_firp, comp18)

' Convênio (porta desativada — ADR-11)
Rel_Flow(comp01, app09, "convenio-produto [desativada — ADR-11]")
Rel_Flow(app09, comp20, "convênio → tarifas [indefinido]")
@enduml
```

</details>

---

## 7. Camada de Tecnologia

### 7.1 Rede Hub and Spoke e fluxos de rede (`am-05`)

**O que mostra.** A implantação física do 04 §7:
- **Salesforce FSC** (SaaS) entra por **Akamai → Azure Application Gateway (WAF v2, vNet Hub) → Axway API Gateway → Ingress privado** do namespace `atacado-core` no **ARO Atacado** (vNet Spoke Plataformas Funcionais).
- Os três Deployments Java acessam **PostgreSQL Flexible Server**, **Blob Storage** e **Key Vault** (via CSI Driver) por acesso privado.
- A saída para o Salesforce passa pelo **Azure Firewall** do Hub.
- FIRP, GACD, GCC/Filenet e Canal Digital PJ aparecem com **localização incerta** (Azure ou on-premise; QA-TEC-09, QA-CON-13).
- IMPD API cloud fica em outra vNet, com rota a confirmar.

Os rótulos **N-01..N-10** são os fluxos de rede do 04 §7.1.

**Leitura.**
- O **Axway API Gateway** aparece no agrupamento do **Hub**, com a ressalva "Hub (localização a confirmar — QA-TEC-09)" no rótulo, igual ao 04 §7 e ao 04b (ver §11, INC-04).
- As redes (vNet Hub, vNet Spoke) e a composição ARO → Deployments aparecem aqui como agrupamentos. No modelo Open Exchange, elas são elementos `CommunicationNetwork` e `Node` com relações próprias (linhas `'@xml` do fonte).
- Os fluxos de retorno (callback, alerta, egress e chamadas saindo do COMP-01) não influenciam o layout (`norank`).

![ArchiMate — Tecnologia 1/2](diagramas/archimate/am-05-tecnologia.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-05-tecnologia.puml</code></summary>

```plantuml
@startuml am-05-tecnologia
' Viewpoint: Technology / Physical — Azure Hub and Spoke, ARO Atacado, serviços de dados e fluxos de rede N-01..N-10
' Fonte: 04-desenho-arquitetura-solucao.md (§7, §7.1, §8)
' Linhas '@xml: elementos/relações do modelo Open Exchange representados aqui só pelo agrupamento (não desenhados)
!include <archimate/Archimate>
!procedure Rel_Flow_NR($a, $b, $l="")
!if ($l == "")
$a .[norank].>> $b
!else
$a .[norank].>> $b : $l
!endif
!endprocedure
skinparam defaultFontSize 12
skinparam wrapWidth 200
skinparam nodesep 35
skinparam ranksep 45
title ArchiMate 3.2 — Tecnologia (1/2): Rede Hub and Spoke, ARO Atacado e fluxos de rede (N-xx)

'@xml Technology_CommunicationNetwork(net_hub, "vNet Hub")
'@xml Technology_CommunicationNetwork(net_spoke, "vNet Spoke Plataformas Funcionais")
'@xml Technology_Node(tn_aro, "COMP-10 ARO Atacado (Azure Red Hat OpenShift, namespace atacado-core)")
'@xml Rel_Association(net_hub, net_spoke, "peering")
'@xml Rel_Association(net_hub, tn_agw)
'@xml Rel_Association(net_hub, tn_fw)
'@xml Rel_Association(net_hub, ss_axway, "localização a confirmar — QA-TEC-09")
'@xml Rel_Association(net_spoke, tn_aro)
'@xml Rel_Association(net_spoke, tn_pg)
'@xml Rel_Association(net_spoke, tn_blob)
'@xml Rel_Association(net_spoke, tn_kv)
'@xml Rel_Composition(tn_aro, ss_ing)
'@xml Rel_Composition(tn_aro, ss_p1)
'@xml Rel_Composition(tn_aro, ss_p2)
'@xml Rel_Composition(tn_aro, ss_p3)
'@xml Rel_Composition(tn_aro, ss_csi)

Technology_Node(tn_sf, "Salesforce FSC (Hyperforce) — SaaS")
Technology_Node(tn_akamai, "COMP-07 Akamai\n(WAF, mTLS, allowlist de IPs do Salesforce)")

Grouping(g_azure, "Azure — tenant corporativo") {
  Grouping(g_hub, "vNet Hub") {
    Technology_Node(tn_agw, "COMP-08 Azure Application Gateway (WAF v2)")
    Technology_Node(tn_fw, "COMP-12 Azure Firewall\n(egress; allowlist FQDN do My Domain Salesforce)")
    Technology_SystemSoftware(ss_axway, "COMP-09 Axway API Gateway\n(políticas externas e internas)\nHub (localização a confirmar — QA-TEC-09)")
  }
  Grouping(g_spoke, "vNet Spoke — Plataformas Funcionais") {
    Grouping(g_ns, "COMP-10 ARO Atacado — namespace atacado-core (NetworkPolicy deny-all, EgressFirewall)") {
      Technology_SystemSoftware(ss_ing, "Ingress privado (router interno)")
      Technology_SystemSoftware(ss_p1, "Deployment atacado-adesao-termo\n(2–4 réplicas, HPA)")
      Technology_SystemSoftware(ss_p2, "Deployment atacado-adesao-receptor\n(2–3 réplicas, PDB)")
      Technology_SystemSoftware(ss_p3, "Deployment atacado-adesao-acompanhamento\n(2 réplicas, 1 ativa por lock)")
      Technology_SystemSoftware(ss_csi, "Secrets Store CSI Driver\n(provider Azure Key Vault)")
    }
    Technology_Node(tn_pg, "COMP-04 atacado-adesao-db\nAzure Database for PostgreSQL Flexible Server\n(subnet delegada, HA zonal)")
    Technology_Node(tn_blob, "COMP-05 atacado-adesao-staging\nAzure Blob Storage (private endpoint)")
    Technology_Node(tn_kv, "COMP-11 Azure Key Vault (private endpoint)")
  }
  Technology_Node(tn_impd, "COMP-16 IMPD API cloud (impd-srv-doc-generator)\n[outra vNet — rota a confirmar]")
}

Grouping(g_corp, "Corporativo — Azure ou on-premise [localização incerta: QA-TEC-09, QA-CON-13]") {
  Technology_Node(tn_firp, "COMP-13 FIRP")
  Technology_Node(tn_gacd, "COMP-14 GACD")
  Technology_Node(tn_gcc, "COMP-15 GCC/Filenet")
  Technology_Node(tn_canal, "COMP-18 Canal Digital PJ")
}

' Entrada do Salesforce (N-01)
Rel_Flow_Down(tn_sf, tn_akamai, "N-01 HTTPS 443, mTLS + OAuth2")
Rel_Flow_Down(tn_akamai, tn_agw)
Rel_Flow_Down(tn_agw, ss_axway)
Rel_Flow_Down(ss_axway, ss_ing, "rota externa (API Adesão) e interna (callback, alerta)")
Rel_Flow_Down(ss_ing, ss_p1)
Rel_Flow_Down(ss_ing, ss_p2)

' Saídas de COMP-01 (N-02, N-03, N-04) — via Axway interno
Rel_Flow_NR(ss_p1, ss_axway, "N-02/N-03 token LEAP [hipótese]")
Rel_Flow_Down(ss_axway, tn_firp)
Rel_Flow_Down(ss_axway, tn_gacd)
Rel_Flow_Down(ss_p1, tn_impd, "N-04 [a confirmar]")
Rel_Serving_Left(tn_gcc, tn_gacd)

' Sinais de entrada (N-05, N-06)
Rel_Flow_NR(tn_gacd, ss_axway, "N-05 callback")
Rel_Flow_NR(tn_canal, ss_axway, "N-06 alerta")

' Dados (N-08, N-09, N-10)
Rel_Flow_Down(ss_p1, tn_pg, "N-08")
Rel_Flow_Down(ss_p2, tn_pg)
Rel_Flow_Down(ss_p3, tn_pg)
Rel_Flow_Down(ss_p1, tn_blob, "N-09")
Rel_Flow_Down(ss_csi, tn_kv, "N-10")

' Saída para o Salesforce (N-07)
Rel_Flow_Down(ss_p3, tn_fw, "N-07 OAuth JWT Bearer")
Rel_Flow_NR(tn_fw, tn_sf, "egress HTTPS 443")
@enduml
```

</details>

### 7.2 Implantação: artefatos, componentes e nós (`am-05b`)

**O que mostra.** A realização da camada de Aplicação pela de Tecnologia:
- As **imagens de contêiner Java** (UBI 9 + OpenJDK 21) realizam COMP-01, COMP-02 e COMP-03 e são atribuídas aos Deployments, que compõem o **ARO Atacado**.
- Os **metadados Salesforce** realizam o COMP-06 e são atribuídos ao Salesforce FSC.
- Os **schemas por BC** (no PostgreSQL) e o container **termos-staging** (no Blob) realizam os objetos de dados.

![ArchiMate — Tecnologia 2/2](diagramas/archimate/am-05b-tecnologia-implantacao.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-05b-tecnologia-implantacao.puml</code></summary>

```plantuml
@startuml am-05b-tecnologia-implantacao
' Viewpoint: Implementation and Deployment — artefatos realizando componentes/objetos de dados e atribuídos a nós
' Fontes: 04-desenho-arquitetura-solucao.md (§5, §7, §10) e 04a-componentes-e-justificativas.md
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 190
skinparam nodesep 25
skinparam ranksep 55
title ArchiMate 3.2 — Tecnologia (2/2): Implantação — artefatos, componentes de aplicação e nós

Grouping(g_app, "Camada de Aplicação (realizada)") {
  Application_Component(comp01, "COMP-01 atacado-adesao-termo")
  Application_Component(comp02, "COMP-02 atacado-adesao-receptor")
  Application_Component(comp03, "COMP-03 atacado-adesao-acompanhamento")
  Application_Component(comp06, "COMP-06 Artefatos Salesforce do Atacado")
  Application_DataObject(do_estado, "AdesaoTermo: estado e saga")
  Application_DataObject(do_inbox, "Inbox (sinais recebidos)")
  Application_DataObject(do_outbox, "Outbox (eventos a entregar)")
  Application_DataObject(do_audit, "Trilha de auditoria (append-only)")
  Application_DataObject(do_pdf, "PDF do Termo (base64, staging ≤ 30 dias)")
}

Grouping(g_art, "Artefatos") {
  Technology_Artifact(art01, "Imagem de contêiner atacado-adesao-termo\n(UBI 9 + OpenJDK 21, Spring Boot 3)")
  Technology_Artifact(art02, "Imagem de contêiner atacado-adesao-receptor\n(UBI 9 + OpenJDK 21)")
  Technology_Artifact(art03, "Imagem de contêiner atacado-adesao-acompanhamento\n(UBI 9 + OpenJDK 21)")
  Technology_Artifact(art06, "Metadados Salesforce\n(LWC/Flow, objetos customizados, Named/External Credential, Connected App)")
  Technology_Artifact(art_db, "Schemas por BC (estado, saga, inbox, outbox, auditoria)")
  Technology_Artifact(art_blob, "Container termos-staging (lifecycle ≤ 30 dias)")
}

Grouping(g_tec, "Nós e software de sistema") {
  Technology_SystemSoftware(ss_p1, "Deployment atacado-adesao-termo\n(2–4 réplicas, HPA)")
  Technology_SystemSoftware(ss_p2, "Deployment atacado-adesao-receptor\n(2–3 réplicas, PDB)")
  Technology_SystemSoftware(ss_p3, "Deployment atacado-adesao-acompanhamento\n(2 réplicas, 1 ativa por lock)")
  Technology_Node(tn_aro, "COMP-10 ARO Atacado (Azure Red Hat OpenShift, namespace atacado-core)")
  Technology_Node(tn_pg, "COMP-04 atacado-adesao-db\nAzure Database for PostgreSQL Flexible Server")
  Technology_Node(tn_blob, "COMP-05 atacado-adesao-staging\nAzure Blob Storage")
  Technology_Node(tn_sf, "Salesforce FSC (Hyperforce) — SaaS")
}

' Artefatos realizam componentes e objetos de dados
Rel_Realization_Up(art01, comp01)
Rel_Realization_Up(art02, comp02)
Rel_Realization_Up(art03, comp03)
Rel_Realization_Up(art06, comp06)
Rel_Realization_Up(art_db, do_estado)
Rel_Realization_Up(art_db, do_inbox)
Rel_Realization_Up(art_db, do_outbox)
Rel_Realization_Up(art_db, do_audit)
Rel_Realization_Up(art_blob, do_pdf)

' Artefatos atribuídos a software de sistema / nós
Rel_Assignment_Up(ss_p1, art01)
Rel_Assignment_Up(ss_p2, art02)
Rel_Assignment_Up(ss_p3, art03)
Rel_Assignment_Up(tn_sf, art06)
Rel_Assignment_Up(tn_pg, art_db)
Rel_Assignment_Up(tn_blob, art_blob)
Rel_Composition_Up(tn_aro, ss_p1)
Rel_Composition_Up(tn_aro, ss_p2)
Rel_Composition_Up(tn_aro, ss_p3)
@enduml
```

</details>

---

## 8. Visão integrada em camadas (`am-06`)

**O que mostra.** As cinco camadas empilhadas (Motivação → Estratégia → Negócio → Aplicação → Tecnologia) com duas cadeias de realização de ponta a ponta. A vista usa só um subconjunto dos elementos.

| Cadeia | Leitura de baixo para cima |
|---|---|
| **1 — Geração do Termo de Adesão** | ARO Atacado → imagem `atacado-adesao-termo` → **COMP-01** → serviço "Solicitação, confirmação e consulta da adesão" → **PN-04 Gerar Termo de Adesão** → **CAP-03 Gestão do Termo de Adesão** → **OE-01 Digitalizar a geração de termos** ← **KPI-01** (≥ 90% via Salesforce), com DRV-01 influenciando OE-01 |
| **2 — Status em tempo real** | ARO Atacado → imagem `atacado-adesao-acompanhamento` → **COMP-03** → serviço "Entrega de status e alertas ao Salesforce" → **PN-09 Confirmar assinatura e atualizar status** → **CAP-09 Notificação e Acompanhamento de Status** → **OE-04 Melhorar a visibilidade do Gerente de Cash** ← **KPI-04** (100% com status em tempo real) |
| Ligação de dados | O COMP-01 lê e grava "AdesaoTermo: estado e saga", que realiza o **OBJ-02 Termo de Adesão**. O PostgreSQL (COMP-04) serve COMP-01 e COMP-03 |

Os processos também realizam os serviços de negócio que servem o **Gerente de Cash**.

![ArchiMate — Visão integrada](diagramas/archimate/am-06-visao-integrada.png)

<details>
<summary>Fonte PlantUML — <code>diagramas/archimate/am-06-visao-integrada.puml</code></summary>

```plantuml
@startuml am-06-visao-integrada
' Viewpoint: Layered — cadeias de realização Motivação → Estratégia → Negócio → Aplicação → Tecnologia
' Subconjunto dos elementos de am-01..am-05 (mesmos aliases)
!include <archimate/Archimate>
skinparam defaultFontSize 12
skinparam wrapWidth 190
skinparam nodesep 30
skinparam ranksep 38
title ArchiMate 3.2 — Visão integrada em camadas: cadeias de realização (Termo de Adesão e Status em tempo real)

Grouping(l_mot, "MOTIVAÇÃO") {
  Motivation_Driver(drv01, "DRV-01 Contratação de produtos Cash bloqueada por dependência de termo manual")
  Motivation_Outcome(kpi01, "KPI-01 ≥ 90% dos termos gerados via Salesforce em 6 meses")
  Motivation_Outcome(kpi04, "KPI-04 100% dos Gerentes de Cash com status em tempo real")
  Motivation_Goal(oe01, "OE-01 Digitalizar a geração de termos")
  Motivation_Goal(oe04, "OE-04 Melhorar a visibilidade do Gerente de Cash")
}

Grouping(l_est, "ESTRATÉGIA") {
  Strategy_Capability(cap03, "CAP-03 Gestão do Termo de Adesão")
  Strategy_Capability(cap09, "CAP-09 Notificação e Acompanhamento de Status")
}

Grouping(l_neg, "NEGÓCIO") {
  Business_Actor(atr01, "ATR-01 Gerente de Cash")
  Business_Service(bs01, "Formalização Digital do Termo de Adesão")
  Business_Service(bs04, "Acompanhamento de Status da Adesão")
  Business_Process(pn04, "PN-04 Gerar Termo de Adesão")
  Business_Process(pn09, "PN-09 Confirmar assinatura e atualizar status")
  Business_Object(obj02, "OBJ-02 Termo de Adesão")
}

Grouping(l_app, "APLICAÇÃO") {
  Application_Service(as_adesao, "Solicitação, confirmação e consulta da adesão")
  Application_Service(as_status, "Entrega de status e alertas ao Salesforce")
  Application_Component(comp01, "COMP-01 atacado-adesao-termo")
  Application_Component(comp03, "COMP-03 atacado-adesao-acompanhamento")
  Application_DataObject(do_estado, "AdesaoTermo: estado e saga")
}

Grouping(l_tec, "TECNOLOGIA") {
  Technology_Artifact(art01, "Imagem de contêiner atacado-adesao-termo\n(UBI 9 + OpenJDK 21, Spring Boot 3)")
  Technology_Artifact(art03, "Imagem de contêiner atacado-adesao-acompanhamento\n(UBI 9 + OpenJDK 21)")
  Technology_Node(tn_aro, "COMP-10 ARO Atacado (Azure Red Hat OpenShift, namespace atacado-core)")
  Technology_Node(tn_pg, "COMP-04 atacado-adesao-db\nAzure Database for PostgreSQL Flexible Server")
}

' Motivação
Rel_Influence_Down(drv01, oe01, "+")
Rel_Realization_Down(kpi01, oe01)
Rel_Realization_Down(kpi04, oe04)

' Cadeia 1 — geração do Termo de Adesão
Rel_Realization_Up(cap03, oe01)
Rel_Realization_Up(pn04, cap03)
Rel_Realization_Down(pn04, bs01)
Rel_Serving_Down(bs01, atr01)
Rel_Access_w(pn04, obj02)
Rel_Serving_Up(as_adesao, pn04)
Rel_Realization_Up(comp01, as_adesao)
Rel_Access_rw(comp01, do_estado)
Rel_Realization_Up(do_estado, obj02)
Rel_Realization_Up(art01, comp01)
Rel_Assignment_Up(tn_aro, art01)
Rel_Serving_Up(tn_pg, comp01)

' Cadeia 2 — status em tempo real
Rel_Realization_Up(cap09, oe04)
Rel_Realization_Up(pn09, cap09)
Rel_Realization_Down(pn09, bs04)
Rel_Serving_Down(bs04, atr01)
Rel_Serving_Up(as_status, pn09)
Rel_Realization_Up(comp03, as_status)
Rel_Realization_Up(art03, comp03)
Rel_Assignment_Up(tn_aro, art03)
Rel_Serving_Up(tn_pg, comp03)
' Layout auxiliar (não é relação ArchiMate): empilha as camadas
atr01 -[hidden]down- as_adesao
atr01 -[hidden]down- as_status
do_estado -[hidden]down- art01
do_estado -[hidden]down- art03
do_estado -[hidden]down- tn_pg
@enduml
```

</details>

---

## 9. Modelo ArchiMate Open Exchange (`am-modelo-open-exchange.xml`)

| Item | Situação |
|---|---|
| Formato | The Open Group ArchiMate Model Exchange File Format 3.x (namespace `http://www.opengroup.org/xsd/archimate/3.0/`) |
| Conteúdo | 205 elementos das 5 camadas e todas as relações dos 11 diagramas, sem duplicatas, e pastas (`organizations`) por camada: Strategy, Business, Application, Technology & Physical, Motivation, Relations |
| Geração | `python3 gerar_open_exchange.py`, que lê os `am-*.puml`. O mesmo alias em vários diagramas vira um único elemento. A documentação de cada elemento traz o rótulo completo e os diagramas onde ele aparece. Linhas `'@xml` entram no modelo sem ser desenhadas (ex.: composição do PN-10 com as atividades PN-10.1..10.4, desenhada por aninhamento) e linhas `'@name` fixam o nome quando o rótulo quebra só por layout (PN-10) |
| Validação | XML bem-formado (verificado com `xml.dom.minidom`) e **válido contra o XSD oficial** The Open Group `archimate3_Diagram.xsd` 3.1, com `lxml`, sem erros (2026-09-24; revalidado em 2026-09-27 na v0.5, com 205 elementos e 279 relações). Todas as combinações origem–relação–destino foram conferidas manualmente contra a tabela de relações do ArchiMate 3.x |
| Importação | Archi: *File → Import → Open Exchange XML Model…* |
| Limitações | (1) O arquivo **não contém diagramas** (`views`): no Archi, as vistas precisam ser montadas a partir dos elementos ou consultadas nos PNG/SVG. (2) Os agrupamentos visuais não são exportados. (3) Não houve teste de importação no Archi neste ambiente (o XSD foi validado). (4) Duas relações dependem de derivação (papel realiza serviço de negócio; capacidade realiza objetivo): são válidas no ArchiMate 3.2, mas, se uma versão antiga do Archi as rejeitar, basta trocá-las por *association* |

---

## 10. Rastreabilidade: elemento ArchiMate → ID nos documentos

Tabela gerada a partir dos fontes `.puml`: uma linha por elemento do modelo, com o ID canônico (CAP, OBJ, PN, EVN, ATR, COMP, APP, RF, RNF, RST, PRI, DRV, OE, KPI…) e a seção de origem. Os IDs **AVL, VS, RES e COA** são criados neste documento (§1.1).

### 10.1 Motivação

| Elemento ArchiMate | Nome no modelo | ID(s) nos documentos | Origem | Diagramas |
|---|---|---|---|---|
| Stakeholder | Time do Atacado Cash Payments | ATR-08, ATR-01 | 01 §6.1; 02 §3.3.1 | `am-01-motivacao` |
| Stakeholder | Time de Canais | ATR-05 | 01 §6.1; 02 §3.3.1 | `am-01-motivacao` |
| Stakeholder | Time de Experiência | ATR-06 | 01 §6.1; 02 §3.3.1 | `am-01-motivacao` |
| Stakeholder | Time do GACD | ATR-07 | 01 §6.1; 02 §3.3.1 | `am-01-motivacao` |
| Stakeholder | Jurídico / Compliance | PRM-NEG-15 | 01 §6.2 | `am-01-motivacao` |
| Driver | DRV-01 Contratação de produtos Cash bloqueada por dependência de termo manual | DRV-01 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao`, `am-06-visao-integrada` |
| Driver | DRV-02 Falta de rastreabilidade e evidência de aceite | DRV-02 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao` |
| Driver | DRV-03 Tarifas negociadas não cadastradas por ausência de convênio | DRV-03 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao` |
| Driver | DRV-04 Baixa visibilidade do gerente sobre o status da adesão | DRV-04 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao` |
| Driver | DRV-05 Fragmentação de canais (BGS sem GACD) | DRV-05 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao` |
| Driver | DRV-06 Reuso de componentes corporativos (GACD, FIRP, GCC/Filenet, IMPD, Databricks) | DRV-06 | 01 §5.2; 02 §3.1.1 | `am-01-motivacao` |
| Assessment | AVL-01 Termo de Adesão assinado manualmente, fora do Salesforce | AVL-01 | novo (04c) — problemas do PRD [03], 01 §4 | `am-01-motivacao` |
| Assessment | AVL-02 Processo sem rastreabilidade: evidência de aceite frágil | AVL-02 | novo (04c) — problemas do PRD [03], 01 §4 | `am-01-motivacao` |
| Assessment | AVL-03 Tarifas travadas: sem Convênio por produto não há cadastro de tarifas | AVL-03 | novo (04c) — problemas do PRD [03], 01 §4 | `am-01-motivacao` |
| Assessment | AVL-04 Gerente de Cash sem visibilidade do status do termo | AVL-04 | novo (04c) — problemas do PRD [03], 01 §4 | `am-01-motivacao` |
| Assessment | AVL-05 Canal fragmentado: BGS não integra com o GACD | AVL-05 | novo (04c) — problemas do PRD [03], 01 §4 | `am-01-motivacao` |
| Goal | OE-01 Digitalizar a geração de termos | OE-01 | 02 §3.1.2 | `am-01-motivacao`, `am-01b-motivacao-requisitos`, `am-02b-estrategia-cursos-de-acao`, `am-06-visao-integrada` |
| Goal | OE-02 Reduzir o tempo de ciclo de contratação | OE-02 | 02 §3.1.2 | `am-01-motivacao`, `am-01b-motivacao-requisitos`, `am-02b-estrategia-cursos-de-acao` |
| Goal | OE-03 Aumentar a conversão de contratações | OE-03 | 02 §3.1.2 | `am-01-motivacao`, `am-02b-estrategia-cursos-de-acao` |
| Goal | OE-04 Melhorar a visibilidade do Gerente de Cash | OE-04 | 02 §3.1.2 | `am-01-motivacao`, `am-01b-motivacao-requisitos`, `am-02b-estrategia-cursos-de-acao`, `am-06-visao-integrada` |
| Goal | OE-05 Garantir compliance | OE-05 | 02 §3.1.2 | `am-01-motivacao`, `am-01b-motivacao-requisitos`, `am-02b-estrategia-cursos-de-acao` |
| Outcome | KPI-01 ≥ 90% dos termos gerados via Salesforce em 6 meses | KPI-01 | 02 §3.1.2 (PRD [03]) | `am-01-motivacao`, `am-06-visao-integrada` |
| Outcome | KPI-02 −50% no tempo de negociação → assinatura (baseline a definir) | KPI-02 | 02 §3.1.2 (PRD [03]) | `am-01-motivacao` |
| Outcome | KPI-03 ≥ 80% de conversão gerado → assinado | KPI-03 | 02 §3.1.2 (PRD [03]) | `am-01-motivacao` |
| Outcome | KPI-04 100% dos Gerentes de Cash com status em tempo real | KPI-04 | 02 §3.1.2 (PRD [03]) | `am-01-motivacao`, `am-06-visao-integrada` |
| Outcome | KPI-05 100% dos termos em conformidade regulatória | KPI-05 | 02 §3.1.2 (PRD [03]) | `am-01-motivacao` |
| Principle | PRI-01 Salesforce nunca integra diretamente com componentes do banco | PRI-01 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-02 ARO Atacado como camada anticorrupção | PRI-02 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-03 Reuso de componentes corporativos antes de construir | PRI-03 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-05 Consistência eventual com outbox transacional | PRI-05 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-07 APIs corporativas somente via Axway API Gateway | PRI-07 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-10 Canal abstraído e desacoplado por contrato | PRI-10 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-11 Rastreabilidade ponta a ponta por padrão | PRI-11 | 02 §6 | `am-01b-motivacao-requisitos` |
| Principle | PRI-12 Separação de ciclos de vida Termo × Convênio | PRI-12 | 02 §6 | `am-01b-motivacao-requisitos` |
| Requirement | RF-01 Receber do Salesforce a solicitação do Termo de Adesão (idempotente, 202 + idAdesao) | RF-01 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-03 Consultar na FIRP (via Axway) os representantes com poderes | RF-03 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-04 Gerar o documento do Termo (PDF base64, modelo versionado + hash) | RF-04 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-06 Registrar o termo no GACD em 3 etapas como saga | RF-06 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-07 Receber, validar e deduplicar o callback do GACD | RF-07 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-08 Expor ao Canal a API de alerta de assinantes inválidos | RF-08 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-09 Entregar status e alertas ao Salesforce (consistência eventual) | RF-09 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-12 Publicar eventos-gatilho do Convênio (porta desativada) | RF-12 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RF-13 Registrar trilha de auditoria e eventos para KPIs | RF-13 | 04 §3.2 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-01 Autenticação e autorização em todas as fronteiras | RNF-01 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-03 Segmentação Hub and Spoke, private endpoints, ingress só pelo Axway | RNF-03 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-04 LGPD: minimização, mascaramento, staging ≤ 30 dias | RNF-04 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-05 Entrega at-least-once com consumidores idempotentes | RNF-05 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-06 Status no Salesforce p95 ≤ 60 s | RNF-06 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-10 Trilha de auditoria append-only correlacionada | RNF-10 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Requirement | RNF-14 Evidência documental: modelo aprovado + hash | RNF-14 | 04 §3.3 | `am-01b-motivacao-requisitos` |
| Constraint | RST-01 Salesforce só se comunica com serviços no ARO Atacado | RST-01 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-02 Serviços no ARO, namespace atacado-core, vNet spoke (Plataformas Funcionais) | RST-02 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-03 FIRP e GACD consumidos pelo Axway API Gateway | RST-03 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-04 Canal externo entra por Akamai → Azure Application Gateway → Axway | RST-04 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-05 Stack corporativa: Java prioritário (Python só para dados) | RST-05 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-06 Segredos no Azure Key Vault | RST-06 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | RST-08 Callback do GACD fica na Azure (ARO Atacado), não no Salesforce | RST-08 | 04 §3.1 | `am-01b-motivacao-requisitos` |
| Constraint | Canal Digital PJ fora do escopo (abstraído; só contrato de API) | PRI-10; escopo do 04 §2.3 | 02 §2.3, §6; 04 §2.3 | `am-01b-motivacao-requisitos` |

### 10.2 Estratégia

| Elemento ArchiMate | Nome no modelo | ID(s) nos documentos | Origem | Diagramas |
|---|---|---|---|---|
| Value Stream | VS-01 Adesão a Produtos Cash | VS-01 | novo (04c) — fluxo 02 §3.3.2 | `am-02-estrategia` |
| Value Stream | VS-01.1 Negociar e aprovar a Proposta | VS-01.1 | novo (04c) — fluxo 02 §3.3.2 | `am-02-estrategia` |
| Value Stream | VS-01.2 Verificar elegibilidade e formalizar o Termo de Adesão | VS-01.2 | novo (04c) — fluxo 02 §3.3.2 | `am-02-estrategia` |
| Value Stream | VS-01.3 Obter a assinatura do Cliente PJ Atacado | VS-01.3 | novo (04c) — fluxo 02 §3.3.2 | `am-02-estrategia` |
| Value Stream | VS-01.4 Implantar produtos e ativar Convênios | VS-01.4 | novo (04c) — fluxo 02 §3.3.2 (PN-10) | `am-02-estrategia` |
| Value Stream | VS-01.5 Cadastrar tarifas e iniciar a receita | VS-01.5 | novo (04c) — fluxo 02 §3.3.2 | `am-02-estrategia` |
| Capability | CAP-01 Gestão de Relacionamento Comercial | CAP-01 | 02 §3.2 | `am-02-estrategia` |
| Capability | CAP-02 Gestão de Adesão a Produtos Cash | CAP-02 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Capability | CAP-03 Gestão do Termo de Adesão | CAP-03 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao`, `am-06-visao-integrada` |
| Capability | CAP-04 Gestão de Representantes e Poderes | CAP-04 | 02 §3.2 | `am-02-estrategia` |
| Capability | CAP-08 Gestão Documental | CAP-08 | 02 §3.2 | `am-02-estrategia` |
| Capability | CAP-05 Gestão de Assinatura Digital | CAP-05 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Capability | CAP-13 Gestão do Canal Digital PJ | CAP-13 | 02 §3.2 | `am-02-estrategia` |
| Capability | CAP-06 Gestão de Convênios | CAP-06 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Capability | CAP-07 Gestão de Tarifas | CAP-07 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Capability | CAP-09 Notificação e Acompanhamento de Status | CAP-09 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao`, `am-06-visao-integrada` |
| Capability | CAP-10 Integração e Exposição de APIs | CAP-10 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Capability | CAP-11 Segurança e Identidade de Integração | CAP-11 | 02 §3.2 | `am-02-estrategia` |
| Capability | CAP-12 Rastreabilidade, Auditoria e Conformidade | CAP-12 | 02 §3.2 | `am-02-estrategia`, `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-01 Salesforce (Salesforce Financial Services Cloud) — jornada do Gerente de Cash | RES-01 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-02 Plataforma ARO Atacado (namespace atacado-core, Plataformas Funcionais) | RES-02 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-03 Serviços corporativos GACD, FIRP e GCC/Filenet | RES-03 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-04 Modelos do Termo de Adesão (Produtos / Produtos + Canal) aprovados pelo Jurídico/Compliance | RES-04 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-05 Pipeline de Tarifas no Databricks | RES-05 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Resource | RES-06 Time do Atacado Cash Payments (dono dos Serviços de Integração do Atacado) | RES-06 | novo (04c) — 01 §5.1, 02 §3.4 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-01 Digitalizar a adesão na jornada do Salesforce (o Gerente não sai do Salesforce) | COA-01 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-02 Reusar componentes corporativos antes de construir (PRI-03) | COA-02 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-03 ARO Atacado como plataforma de integração e camada anticorrupção (PRI-02, OP-02) | COA-03 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-04 Geração do documento: IMPD API cloud (Plano A) com geração própria (Plano B) (ADR-03) | COA-04 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-05 Convênio preparado por porta desativada e eventos-gatilho (ADR-11) | COA-05 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |
| Course of Action | COA-06 Status em tempo quase real via outbox e upsert no Salesforce (ADR-05, ADR-06) | COA-06 | novo (04c) — 01 §5.1, 02 §6, 04 §13 | `am-02b-estrategia-cursos-de-acao` |

### 10.3 Negócio

| Elemento ArchiMate | Nome no modelo | ID(s) nos documentos | Origem | Diagramas |
|---|---|---|---|---|
| Business Process | PN-01 Negociar e aprovar Proposta | PN-01 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-01 Proposta aprovada | EVN-01 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-02 Verificar elegibilidade e definir tipo de termo | PN-02 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-02 Termo de Adesão solicitado | EVN-02 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-03 Identificar assinantes | PN-03 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-03 Assinantes identificados | EVN-03 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-04 Gerar Termo de Adesão | PN-04 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos`, `am-06-visao-integrada` |
| Business Event | EVN-04 Termo de Adesão gerado | EVN-04 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-05 Registrar termo para assinatura | PN-05 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-05 Protocolo de assinatura emitido (codigoProtocolo) | EVN-05 | 02 §3.3.3 | `am-03-negocio` |
| Business Event | EVN-06 Termo disponibilizado para assinatura | EVN-06 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-06 Disponibilizar termo e notificar o cliente | PN-06 | 02 §3.3.2 | `am-03-negocio` |
| Business Process | PN-07 Revalidar assinantes e assinar o termo | PN-07 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-07 Assinantes invalidados | EVN-07 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-08 Tratar assinantes inválidos | PN-08 | 02 §3.3.2 | `am-03-negocio` |
| Business Event | EVN-08 Termo de Adesão assinado | EVN-08 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-09 Confirmar assinatura e atualizar status | PN-09 | 02 §3.3.2 | `am-03-negocio`, `am-06-visao-integrada` |
| Business Event | EVN-09 Status do termo atualizado no Salesforce | EVN-09 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-12 Acompanhar status e indicadores | PN-12 | 02 §3.3.2 | `am-03-negocio` |
| Business Event | EVN-12 Termo recusado / expirado / cancelado | EVN-12 | 02 §3.3.3 | `am-03-negocio` |
| Business Event | EVN-13 Implantação iniciada (por produto) | EVN-13 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-10 Implantar produto e gerar Convênio | PN-10 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Process | PN-10.1 Definir parâmetros com o cliente | PN-10.1 | 02 §3.3.2 | `am-03-negocio` |
| Business Process | PN-10.2 Criar o convênio em modo teste | PN-10.2 | 02 §3.3.2 | `am-03-negocio` |
| Business Process | PN-10.3 Homologar com o cliente | PN-10.3 | 02 §3.3.2 | `am-03-negocio` |
| Business Process | PN-10.4 Ativar o convênio (RN-17) | PN-10.4; RN-17 | 02 §3.3.2 | `am-03-negocio` |
| Business Event | EVN-10 Convênio ativado (por produto) | EVN-10 | 02 §3.3.3 | `am-03-negocio` |
| Business Process | PN-11 Cadastrar Tarifas | PN-11 | 02 §3.3.2 | `am-03-negocio`, `am-03c-negocio-objetos` |
| Business Event | EVN-11 Tarifas cadastradas | EVN-11 | 02 §3.3.3 | `am-03-negocio` |
| Business Actor | ATR-02 Cliente PJ Atacado | ATR-02 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-03 Assinante/Representante | ATR-03 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-01 Gerente de Cash | ATR-01 | 02 §3.3.1 | `am-03b-negocio-atores-servicos`, `am-06-visao-integrada` |
| Business Actor | ATR-04 Aprovador da Proposta | ATR-04 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-08 Time do Atacado Cash Payments | ATR-08 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-05 Time de Canais | ATR-05 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-06 Time de Experiência | ATR-06 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-07 Time do GACD | ATR-07 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Actor | ATR-09 Backoffice de Cash | ATR-09; QA-CON-24, QA-CON-25 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Contratante | ATR-02 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Signatário do Termo de Adesão | ATR-03; RN-05, RN-06 (01 §8.1) | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Solicitante do Termo de Adesão | ATR-01; PN-02 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Aprovador da Proposta | ATR-04; QA-CON-23 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Dono da jornada e dos Serviços de Integração do Atacado | ATR-08; PRM-CON-02 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Provedor do Canal Digital PJ | ATR-05; CAP-13 | 02 §3.3.1, §3.2 | `am-03b-negocio-atores-servicos` |
| Business Role | Responsável pela experiência da jornada | ATR-06; PRM-CON-10 | 02 §3.3.1 | `am-03b-negocio-atores-servicos` |
| Business Role | Provedor de Aceite Digital | ATR-07; CAP-05 | 02 §3.3.1, §3.2 | `am-03b-negocio-atores-servicos` |
| Business Role | Executor da implantação do produto | ATR-01 ou ATR-09; PN-10; QA-CON-24 | 02 §3.3.1, §3.3.2 | `am-03b-negocio-atores-servicos` |
| Business Collaboration | Colaboração Aceite Digital Cash | ATR-05..ATR-08; RACI | 01 §6.1, §6.3 | `am-03b-negocio-atores-servicos` |
| Business Service | Formalização Digital do Termo de Adesão | CAP-02.3, CAP-03.1; PN-03..PN-05 | 02 §3.2 | `am-03b-negocio-atores-servicos`, `am-06-visao-integrada` |
| Business Service | Aceite Digital de termos e contratos (GACD) | CAP-05.1..CAP-05.3; APP-05 | 02 §3.2 | `am-03b-negocio-atores-servicos` |
| Business Service | Assinatura no Canal Digital PJ | CAP-05.4, CAP-13.1; APP-07 | 02 §3.2 | `am-03b-negocio-atores-servicos` |
| Business Service | Acompanhamento de Status da Adesão | CAP-09.1, CAP-09.4; PN-12 | 02 §3.2 | `am-03b-negocio-atores-servicos`, `am-06-visao-integrada` |
| Business Service | Implantação de produto e geração de Convênio | CAP-06.1; PN-10; QA-CON-02, QA-CON-24 | 02 §3.2 | `am-03b-negocio-atores-servicos` |
| Business Object | OBJ-01 Proposta | OBJ-01 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-10 Contrato vigente | OBJ-10 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-03 Assinante/Representante | OBJ-03 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-04 Poder de assinatura | OBJ-04 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-02 Termo de Adesão | OBJ-02 | 02 §3.3.4 | `am-03c-negocio-objetos`, `am-06-visao-integrada` |
| Business Object | OBJ-05 Protocolo de assinatura | OBJ-05 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-06 Prévia do documento | OBJ-06 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-09 Produto Cash | OBJ-09 | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-07 Convênio | OBJ-07; RN-17 (estados Em teste → Ativo) | 02 §3.3.4 | `am-03c-negocio-objetos` |
| Business Object | OBJ-08 Tarifa | OBJ-08 | 02 §3.3.4 | `am-03c-negocio-objetos` |

### 10.4 Aplicação

| Elemento ArchiMate | Nome no modelo | ID(s) nos documentos | Origem | Diagramas |
|---|---|---|---|---|
| Application Component | APP-01 Salesforce | APP-01 | 02 §3.4 | `am-04-aplicacao` |
| Application Component | COMP-06 Artefatos Salesforce do Atacado | COMP-06 (parte do APP-01); BC-05 | 04 §5.1; 04a | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Application Interface | Upsert de status (REST) | COMP-06; ADR-06; RF-09 | 04 §11.4, §13 | `am-04-aplicacao` |
| Application Interface | API Adesão v1 | APP-02.1; RF-01; R-01 | 04 §11.1 | `am-04-aplicacao` |
| Application Service | Solicitação, confirmação e consulta da adesão | APP-02.1; RF-01, RF-05, RF-10, RF-11 | 04 §3.2, §11.1 | `am-04-aplicacao`, `am-06-visao-integrada` |
| Application Component | COMP-01 atacado-adesao-termo | COMP-01 (APP-02.1, APP-02.2, APP-02.3, APP-02.7; APP-03 no módulo termo-documento); BC-01, BC-02 | 04 §5.1; 04a; 02 §3.4.1 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Application Interface | Callback GACD | APP-02.4; RF-07; ADR-08 | 04 §11.2 | `am-04-aplicacao` |
| Application Interface | API de alerta de assinantes inválidos | APP-02.6; RF-08; ADR-09 | 04 §11.3 | `am-04-aplicacao` |
| Application Component | COMP-02 atacado-adesao-receptor | COMP-02 (APP-02.4, APP-02.6); BC-01 | 04 §5.1; 04a; 02 §3.4.1 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Application Component | COMP-03 atacado-adesao-acompanhamento | COMP-03 (APP-02.5); BC-03 | 04 §5.1; 04a; 02 §3.4.1 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Application Service | Entrega de status e alertas ao Salesforce | APP-02.5; RF-09; ADR-06 | 04 §11.4 | `am-04-aplicacao`, `am-06-visao-integrada` |
| Data Object | AdesaoTermo: estado e saga | APP-02.7; RF-06; ADR-02, ADR-05 | 04 §10 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Data Object | Inbox (sinais recebidos) | APP-02.7; RNF-05; ADR-05, ADR-08 | 04 §10 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Data Object | Outbox (eventos a entregar) | APP-02.7; PRI-05; ADR-05 | 04 §10 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Data Object | Trilha de auditoria (append-only) | CAP-12.1; RF-13; RNF-10 | 04 §9.5, §10 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Data Object | PDF do Termo (base64, staging ≤ 30 dias) | COMP-05; ADR-04; RNF-04 | 04 §5.1, §13 | `am-04-aplicacao`, `am-05b-tecnologia-implantacao` |
| Application Component | COMP-13 FIRP | COMP-13 (APP-04); BC-06 | 04 §5.2; 02 §3.4 | `am-04-aplicacao` |
| Application Service | Consulta de representantes e poderes | CAP-04.1; RF-03 | 02 §3.2; 04 §3.2 | `am-04-aplicacao` |
| Application Component | COMP-14 GACD | COMP-14 (APP-05); BC-07 | 04 §5.2; 02 §3.4 | `am-04-aplicacao` |
| Application Service | Coordenar Contrato → Armazenar Prévia → Coordenar Regra | CAP-05.1..CAP-05.3; RF-06 | 02 §3.2; 04 §3.2 | `am-04-aplicacao` |
| Application Component | COMP-15 GCC/Filenet | COMP-15 (APP-06); BC-08 | 04 §5.2; 02 §3.4 | `am-04-aplicacao` |
| Application Component | COMP-16 IMPD API cloud | COMP-16 (candidato a APP-03; TEC-12); BC-09 | 04 §5.2, §12; 02 §3.5 | `am-04-aplicacao` |
| Application Service | Renderização de PDF (base64) | CAP-08.1; RF-04; ADR-03 | 02 §3.2; 04 §12 | `am-04-aplicacao` |
| Application Component | COMP-18 Canal Digital PJ | COMP-18 (APP-07); BC-10 | 04 §5.2; 02 §3.4 | `am-04-aplicacao` |
| Application Component | APP-09 Sistema de Convênio (indefinido) | APP-09 | 02 §3.4 | `am-04-aplicacao` |
| Application Component | COMP-20 Databricks (Tarifas) | COMP-20 (APP-08; TEC-11); BC-11 | 04 §5.2; 02 §3.4 | `am-04-aplicacao` |

### 10.5 Tecnologia

| Elemento ArchiMate | Nome no modelo | ID(s) nos documentos | Origem | Diagramas |
|---|---|---|---|---|
| Communication Network | vNet Hub | TEC-02; COMP-12 | 02 §3.5; 04 §7 | `am-05-tecnologia` |
| Communication Network | vNet Spoke Plataformas Funcionais | TEC-02, TEC-03; RST-02 | 02 §3.5; 04 §7 | `am-05-tecnologia` |
| Node | COMP-10 ARO Atacado (Azure Red Hat OpenShift, namespace atacado-core) | COMP-10 (TEC-03) | 04 §5.2, §7; 02 §3.5 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Node | Salesforce FSC (Hyperforce) — SaaS | APP-01 (SaaS); N-01, N-07 | 04 §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao` |
| Node | COMP-07 Akamai | COMP-07 (TEC-05) | 04 §5.2; 02 §3.5 | `am-05-tecnologia` |
| Node | COMP-08 Azure Application Gateway (WAF v2) | COMP-08 (TEC-06) | 04 §5.2; 02 §3.5 | `am-05-tecnologia` |
| Node | COMP-12 Azure Firewall | COMP-12 (TEC-02; PRM-CON-11) | 04 §5.2, §7 | `am-05-tecnologia` |
| System Software | COMP-09 Axway API Gateway | COMP-09 (TEC-04); no Hub, localização a confirmar (QA-TEC-09) | 04 §5.2; 02 §3.5 | `am-05-tecnologia` |
| System Software | Ingress privado (router interno) | COMP-10; N-01, N-05, N-06 | 04 §7 | `am-05-tecnologia` |
| System Software | Deployment atacado-adesao-termo | COMP-01 (implantação) | 04 §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao` |
| System Software | Deployment atacado-adesao-receptor | COMP-02 (implantação); RNF-08 | 04 §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao` |
| System Software | Deployment atacado-adesao-acompanhamento | COMP-03 (implantação) | 04 §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao` |
| System Software | Secrets Store CSI Driver | ADR-10; PRM-TEC-08; N-10 | 04 §7, §8.2 | `am-05-tecnologia` |
| Node | COMP-04 atacado-adesao-db | COMP-04 (TEC-10; PRM-TEC-01) | 04 §5.1, §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Node | COMP-05 atacado-adesao-staging | COMP-05 (PRM-TEC-02) | 04 §5.1, §7 | `am-05-tecnologia`, `am-05b-tecnologia-implantacao` |
| Node | COMP-11 Azure Key Vault (private endpoint) | COMP-11 (TEC-07) | 04 §5.2; 02 §3.5 | `am-05-tecnologia` |
| Node | COMP-16 IMPD API cloud (impd-srv-doc-generator) | COMP-16 (TEC-12); N-04 | 04 §7 | `am-05-tecnologia` |
| Node | COMP-13 FIRP | COMP-13; N-02 | 04 §7 | `am-05-tecnologia` |
| Node | COMP-14 GACD | COMP-14; N-03, N-05 | 04 §7 | `am-05-tecnologia` |
| Node | COMP-15 GCC/Filenet | COMP-15 | 04 §7 | `am-05-tecnologia` |
| Node | COMP-18 Canal Digital PJ | COMP-18; N-06 | 04 §7 | `am-05-tecnologia` |
| Artifact | Imagem de contêiner atacado-adesao-termo | COMP-01; PRM-TEC-09 | 04 §7 | `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Artifact | Imagem de contêiner atacado-adesao-receptor | COMP-02; PRM-TEC-09 | 04 §7 | `am-05b-tecnologia-implantacao` |
| Artifact | Imagem de contêiner atacado-adesao-acompanhamento | COMP-03; PRM-TEC-09 | 04 §7 | `am-05b-tecnologia-implantacao`, `am-06-visao-integrada` |
| Artifact | Metadados Salesforce | COMP-06 | 04 §5.1 | `am-05b-tecnologia-implantacao` |
| Artifact | Schemas por BC (estado, saga, inbox, outbox, auditoria) | COMP-04; PRM-TEC-01 | 04 §10 | `am-05b-tecnologia-implantacao` |
| Artifact | Container termos-staging (lifecycle ≤ 30 dias) | COMP-05; PRM-TEC-02 | 04 §5.1 | `am-05b-tecnologia-implantacao` |

---

## 11. Inconsistências encontradas entre os documentos

Registradas na v0.1 para correção pelos donos dos documentos. Na Consolidação Rodada 2, INC-01..05 foram corrigidas na origem; INC-06..09 continuam como escolhas de modelagem deste documento.

| # | Inconsistência | Onde | Escolha adotada aqui |
|---|---|---|---|
| INC-01 | **Drivers com o mesmo ID e conteúdo diferente** entre 01 §5.2 e 02 §3.1.1 (DRV-04/DRV-05 trocados; redação de DRV-01..03 diferente) | 01 §5.2 × 02 §3.1.1 | **Resolvida na Rodada 2:** o 01 é o mestre; o 02 v0.3 usa os mesmos textos e o DRV-06 (reuso, antes DRV-05 do 02) foi acrescentado aos dois. As vistas usam DRV-01..06 do 01 |
| INC-02 | **Colisão de prefixo OBJ:** no 01 v0.2 §4.3, OBJ-01..05 eram objetivos; no 02 §3.3.4, OBJ-01..10 são objetos de negócio | 01 §4.3 × 02 §3.3.4 | **Resolvida na Rodada 2:** o 01 v0.3 usa OE-01..05 (com KPI-01..05) para objetivos; OBJ-xx fica só para objetos de negócio. OE-04 com o texto do 01 ("Melhorar a visibilidade do Gerente de Cash") |
| INC-03 | **Numeração de regras de negócio:** o 02 v0.2 usava RN1..RN5 com sentidos diferentes dos RN-01..RN-16 do 01 | 01 §8.1 × 02 §3.3.5 | **Resolvida na Rodada 2:** o 02 v0.3 usa RN-xx do 01 (RN1 → RN-01, RN2 → RN-03, RN3 → RN-02, RN4 → RN-11/RN-12, RN5 → RN-05/RN-06). Rótulos do am-03c atualizados |
| INC-04 | **Localização do Axway API Gateway** divergia entre 02 §4.4 ("camada de APIs corporativa"), 04 §7 ("zona de integração") e 04b (Hub) | 02 §4.4 × 04 §7 × 04b | **Resolvida na Rodada 2:** 04, 04b e 04c usam "Hub (localização a confirmar — QA-TEC-09)". No am-05, o Axway fica no agrupamento do Hub. O 02 §4.4 (conceitual) mantém a camada de APIs separada, sem conflito com a ressalva |
| INC-05 | **Nome do canal:** "Canal Digital PJ" × "Canal Digital do Cliente" | 01 × 02 × 04 × 04a | **Resolvida na Rodada 2:** nome canônico "Canal Digital PJ" (COMP-18, BC-10, CAP-13 "Gestão do Canal Digital PJ"); "Canal Digital do Cliente (Canal Digital PJ)" só na primeira menção de cada documento |
| INC-06 | **COMP-04 e COMP-05 classificados como "componentes"**, mas são serviços gerenciados de dados (PostgreSQL Flexible Server, Blob Storage) | 04 §5.1 | Modelados como **Node** (Tecnologia). Os dados que guardam aparecem como Data Objects (Aplicação) realizados por artefatos |
| INC-07 | **Nome do Salesforce.** `stack-tech.md` diz "Salesforce Financial Service"; o glossário diz "Salesforce Financial Services Cloud"; o 04 abrevia "Salesforce FSC" | stack × 02 × 04 | "Salesforce (Salesforce Financial Services Cloud)" na aplicação e "Salesforce FSC (Hyperforce)" no nó de tecnologia, como no 04 §7 |
| INC-08 | **Nomes dos serviços do GACD** grafados de dois jeitos (`gacd-srv-coordenar-ass-sformatador` × `…-coordenador-…`; `cgcc_conteudo_gacd` × `cgcc-conteudo-gacd`) | [04] (já em QA-CON-16) | Nomes funcionais das etapas ("Coordenar Contrato → Armazenar Prévia → Coordenar Regra"), sem o nome técnico |
| INC-09 | **Ordem Convênio × Tarifas** (diagrama do PRD × texto) | [01] (já em QA-CON-05) | Texto do PRD (PRM-CON-08): VS-01.4 Convênio (ativo) antes de VS-01.5 Tarifas |

---

## 12. Limitações dos diagramas

- **Layout (v0.2):** as vistas foram re-renderizadas com **Graphviz `dot` 2.42.2** (wrapper do 04b §1.2) e comparadas uma a uma com os renders Smetana da v0.1. Ganharam legibilidade sobretudo **am-03** (de 1223 × 1755 px com curvas longas para 1662 × 995 px, fases em colunas) e **am-05** (Axway no Hub, fluxos N-xx mais curtos); as demais ficaram equivalentes ou mais compactas.
- **am-03:** com o Graphviz 2.42, a aresta oculta `evn08 → pn10` provocava erro de layout e foi retirada; na v0.5, a aresta oculta equivalente `evn08 → evn13` também faz o layout falhar e não foi usada. As fases aparecem em colunas, mas o Graphviz põe "Assinatura" antes de "Formalização" e, desde a v0.5, "Pós-assinatura" antes de "Confirmação e acompanhamento"; a ordem de leitura segue os eventos (EVN-xx), não a posição das colunas. Com as atividades PN-10.1..10.4, a vista passou a ≈ 1940 × 1370 px.
- **am-04:** com Graphviz, a vista ficava com ≈ 2.800 px de largura e os objetos de dados longe do COMP-01, mesmo com ajustes de direção e arestas ocultas. Por isso o fonte força o layout Smetana (`!pragma layout smetana`), que continua sendo o render publicado (1890 × 1750 px).
- Setas `_NR` (norank) e arestas ocultas são dicas de layout; o Graphviz pode ignorá-las parcialmente. Nenhuma vista tem sobreposição de elementos ou rótulos ilegíveis.
- **am-01b** é alta (≈ 1160 × 2120 px), porque empilha verticalmente 29 requisitos, restrições e princípios. Para apresentação, use o SVG.
- As vistas mostram subconjuntos coerentes com cada viewpoint. O modelo completo está no XML e na tabela da §10.
