# 00 — Log de Execução

Projeto: Termo de Adesão multiproduto (Cash Management / Payments) — Atacado
Início da execução: 2026-09-23
Modo: execução autônoma em 3 rodadas, com orquestração por subagents (sem validação intermediária do usuário).
Restrição respeitada em todas as delegações: a pasta `/imgs` não foi lida.

---

## Rodada 1 — Negócio e domínio (itens 01, 02, 03)

### Fontes analisadas
| Sigla | Arquivo | Conteúdo |
|---|---|---|
| [01] | 01-prd-aceite-digital-cash-resumo-executivo-fluxo.md | PRD v1.0 (rascunho): objetivo, fluxo parcial (diagrama cortado) |
| [02] | 02-prd-aceite-digital-cash-contexto-canais-gacd.md | Canal Digital (BGS+PDPJ), GACD × Open Cash Hub, tipos de termo |
| [03] | 03-prd-aceite-digital-cash-problema-impacto-objetivos.md | Problema, impacto, metas/KPIs; personas vazias |
| [04] | 04-confluence-gacd-jornada-armazenamento-previa-contrato.md | Jornada GACD em 3 chamadas + callback |
| [05] [06] | 05/06-impd-*.md | IMPD: CSF Designer v21, saída base64, esteira GitHub/RDM, API cloud `impd-srv-doc-generator` na Azure |
| [stack] | stack-tech.md | Stack corporativa (11 itens) |
| [CG] | Contexto Geral do usuário | Reuniões: FIRP→assinantes→GACD, callback na Azure (atacado-core, Hub and Spoke), Axway, LEAP (hipótese), Java |

### Achados relevantes da exploração
- **FIRP não aparece em nenhuma fonte documental**; toda a integração FIRP vem só do Contexto Geral (reuniões). Sem contrato de API.
- **IMPD não é só on-premise**: [06] documenta uma API cloud (`impd-srv-doc-generator`) "disponível na Azure"; o mainframe é o legado. A hipótese do usuário ("IMPD parece on-premise") foi parcialmente contraditada → registrada para avaliação crítica no item 04.
- **GACD exige "usuário sistêmico"** no armazenamento da prévia [04]; token LEAP não aparece em nenhuma fonte (permanece hipótese).
- Nomes de serviços GACD inconsistentes na própria fonte (`coordenar-ass-sformatador` × `coordenador-ass-sformatador`; `cgcc_conteudo_gacd` × `cgcc-conteudo-gacd`).
- Contradição no PRD: diagrama mostra convênio após cadastro de tarifas; texto diz que convênio é pré-requisito das tarifas.
- PostgreSQL (sugerido para outbox) **não consta** no stack-tech.md → premissa de uso de Azure Database for PostgreSQL Flexible Server.

### Artefatos produzidos
| Arquivo | Versão | Conteúdo principal |
|---|---|---|
| 01-contexto-de-negocio.md | v0.2 | Sumário, problema/metas, estratégia, stakeholders + RACI, jornada AS-IS/TO-BE (Mermaid), RN-01..16, RFN/RNFN, capacidades, oportunidades OP-01..09, **Questões em aberto — Convênio (QA-CONV-01..11)**, QA-NEG-01..19, PRM-NEG-01..17 |
| 02-desenho-conceitual.md | v0.2 | Camadas CAM-1..5 (Estratégia, Negócio, Capacidades, Aplicação, Tecnologia/Integração), CAP-01..13, OBJ-01..10, APP-01..10 (+ APP-02.1..02.7), PRI-01..13, DEC-CON-01..08, 5 diagramas Mermaid validados, QA-CON-01..23, PRM-CON-01..14 |

### Decisões do orquestrador (consolidação)
1. **Glossário canônico** definido antes da produção e repassado a todos os subagents (Salesforce, Gerente de Cash, Termo de Adesão — tipos "Produtos" e "Produtos + Canal", Convênio, ARO Atacado/atacado-core, FIRP, GACD, GCC/Filenet, IMPD, Canal Digital PJ, Open Cash Hub, Databricks).
2. **Inconsistência corrigida — IDs de capacidade:** o 01 usava CN-01..10 e o 02 CAP-01..12. Adotada a nomenclatura CAP-xx do 02 (base do DDD). CN-09 "Gestão de Canal Digital do Cliente" virou **CAP-13 Gestão do Canal Digital do Cliente** (capacidade externa — Time de Canais), incluída no 02. CN-10 foi mapeada para CAP-12 Rastreabilidade, Auditoria e Conformidade. Ambos os documentos subiram para v0.2.
3. **Inconsistência corrigida — estados do Termo:** o 01 misturava estados da jornada com estados do Termo. Estados canônicos adotados (do 02): Solicitado, Assinantes identificados, Gerado, Aguardando assinatura, Assinantes inválidos, Assinado, Falha na geração, Encerrado (recusado/expirado/cancelado). "Não requerido" e "Convênios gerados/Tarifas cadastradas" passaram a ser status da jornada (PRI-12: ciclos de vida de Termo e Convênio separados).
4. **Padronização de nomes:** "Time GACD" → "Time do GACD"; "Serviço no ARO Atacado" → "Serviços de Integração do Atacado (ARO Atacado)"; provedor do canal = "Canal Digital PJ" ("Canal Digital do Cliente" mantido como abstração).
5. **Cruzamento de questões:** QA-CONV-xx (01) ↔ QA-CON-02..05 (02) referenciadas mutuamente para evitar duplicidade.
6. **Conflito style × layout do deck (antecipado para a Rodada 3):** instrução do usuário aplicada literalmente — style = deckkit (paleta, Calibri, header/rodapé do deckkit); layout = sequência/estrutura de slides do sample-ppt.pptx.

### Premissas principais assumidas (Rodada 1)
- GACD é o gerenciador de termos de referência (Open Cash Hub como alternativa) — PRM-NEG-01 / PRM-CON-01.
- Salesforce é sistema de engajamento, não de registro; guarda só projeção do status — PRM-NEG-02 / PRM-CON-09.
- Toda integração passa pelo ARO Atacado; callback do GACD entra por rota interna via Axway — PRM-NEG-03 / PRM-CON-04.
- Autenticação por token LEAP — PRM-CON-03.
- Convênio: gerado automaticamente após a assinatura, cadastral, coberto pelo termo, 1 termo → N convênios (um por produto), antes do cadastro de tarifas — PRM-NEG-07/17, PRM-CON-08.
- Um termo por CNPJ, no máximo um pendente; tipo de termo determinado automaticamente — PRM-NEG-05/13.
- PDF gerado antes do passo 1 do GACD; GACD não formata documento — PRM-CON-06.

### Item 03 — DDD (03-dominios-bounded-contexts-context-mapping.md, v0.1)
**Subdomínios:** Core = SD-01 Adesão a Produtos Cash (propositalmente estreito). Supporting = SD-02 Geração do Termo, SD-03 Acompanhamento da Jornada, SD-04 Convênios (dono indefinido), SD-05 Relacionamento Comercial (Salesforce), SD-06 Tarifas (Databricks). Generic = SD-07 GACD, SD-08 FIRP, SD-09 GCC/Filenet, SD-10 IMPD. Externo = SD-11 Canal Digital PJ.

**Bounded contexts identificados:**
| ID | Nome | Nome técnico | Tipo | Dono |
|---|---|---|---|---|
| BC-01 | Adesão ao Termo | `adesao-termo` | Interno — Core | Atacado Cash Payments |
| BC-02 | Geração do Termo | `termo-documento` | Interno — Supporting | Atacado Cash Payments |
| BC-03 | Acompanhamento da Jornada | `adesao-acompanhamento` | Interno — Supporting | Atacado Cash Payments |
| BC-04 | Gestão de Convênios | `convenio-produto` | Indefinido | Indefinido (QA-CON-02) |
| BC-05..13 | Salesforce, FIRP, GACD, GCC/Filenet, IMPD, Canal Digital PJ, Databricks, Open Cash Hub, Registro de Contratos | — | Externos | Respectivos donos |

**Context map (destaques):** Salesforce ✕ FIRP/GACD = Separate Ways (proibido, PRI-01); FIRP → BC-01 e GACD → BC-01 via ACL (callback GACD = OHS, Conformist + ACL, idempotente por `codigoProtocolo`); IMPD → BC-02 Conformist (alternativa: geração própria); BC-01 → Canal = C/S + OHS da API de alerta de assinantes inválidos (a combinar com Canais); BC-01 → BC-04 com 4 opções (A novo serviço, B legado + ACL, C Open Cash Hub, D Salesforce — não recomendada).

**Eventos de domínio:** TermoSolicitado, AdesaoDispensada, AssinantesIdentificados, TermoGerado, TermoEnviadoParaAssinatura, GeracaoDoTermoFalhou, AssinantesInvalidados, ReemissaoSolicitada, AssinaturaConcluida, TermoEncerrado, StatusJornadaAtualizado, AlertaGerenteEmitido, ConvenioSolicitado, ConvenioGerado, TarifasCadastradas — at-least-once via outbox + idempotência.

**Recomendação indicativa de implantação:** DU-01 `adesao-termo` como monólito modular Java (BC-01/02/03 como módulos, schema por BC) + DU-02 `adesao-outbox-relay` opcional; BC-04 não implantar antes de QA-CON-02.

**Ponto de atenção levado à Rodada 2:** a recomendação do 03 (poucos deployables) tensiona com a orientação do usuário (4 microsserviços: integrador FIRP, gerador de PDF, integrador GACD, callback). Não é uma inconsistência. É a decisão que o item 04 deve tomar criticamente e justificar.

**Questões de DDD:** QA-DDD-01..13 (identidade do agregado; reemissão/cancelamento de protocolo; vocabulário de status GACD; GACD já resolve assinantes na FIRP?; broker de mensageria; posse do gatilho do Convênio; catálogo de Produto Cash; LGPD da API de alerta; quem sinaliza adesão ao Canal; elegibilidade no Salesforce × BC-01; interface Databricks; estado "sem assinantes"; guarda do documento). Premissas PRM-DDD-01..11.

### Consistência final da Rodada 1
- 01, 02 e 03 usam o mesmo glossário, os mesmos CAP-xx e os mesmos estados canônicos do Termo. O 03 acrescenta BC-13 Registro de Contratos (fonte de "contrato vigente", ligado à QA-NEG-14/QA-CON-21).
- Transições extras propostas no 03 (PRM-DDD-10) são extensões compatíveis com os estados canônicos.

### Questões em aberto de negócio (destaques; lista completa nos docs 01 e 02)
- **Convênio (QA-CONV-01..11):** onde é gerado, quem gera, gatilho, cardinalidade, assinatura própria × coberto pelo termo, documento × registro cadastral, ordem convênio × tarifas, reuso do Open Cash Hub, chave para Databricks, tratamento de falha.
- GACD × Open Cash Hub como gerenciador oficial; clientes BGS (BGS não integra GACD); regras de poderes/assinatura conjunta; baseline do KPI de tempo; critérios regulatórios e retenção; lista de produtos Cash no escopo; quem envia e-mail ao cliente; contrato da API de alerta de assinantes inválidos com Canais.

---

## Rodada 2 — Solução, especificação e roadmap (itens 04, 05, 06)

Antes de iniciar, os documentos 00–03 foram relidos pelos subagents (cada delegação recebeu os caminhos e o glossário canônico).

### Artefatos produzidos
| Arquivo | Conteúdo principal |
|---|---|
| 04-desenho-arquitetura-solucao.md | Drivers (RF-01..14, RNF-01..16), visão macro, fluxos (sequências), implantação/rede, segurança, resiliência, modelo de dados, contratos, **análise crítica do IMPD**, ADR-01..12, RSK-01..17, QA-TEC-01..18, PRM-TEC-01..15 |
| 04a-componentes-e-justificativas.md | COMP-01..31: definição, justificativa, alternativas descartadas, RF/RNF atendidos, matrizes Componente × RF e Componente × RNF |
| 04b-diagramas-c4.md + diagramas/c4/ | C4 Contexto, Containers, Componentes (COMP-01 e COMP-02/03), Dinâmico (jornada e assinantes inválidos), Implantação — .puml/.png/.svg |
| 04c-diagramas-archimate.md + diagramas/archimate/ | 11 vistas ArchiMate com as camadas **Estratégia, Motivação, Negócio, Aplicação e Tecnologia** + visão integrada; modelo Open Exchange (`am-modelo-open-exchange.xml`, importável no Archi — não testado no Archi) |
| 05-especificacoes-tecnicas.md | 91 unidades de especificação (TRV, TER, FIR, GAC, DOC, ELG, CNV, REC, ACP, DB, STG, SFC, API, EVT, SEG, INF, OBS, TST), DDL PostgreSQL, máquina de estados, catálogo de eventos, saga, DT-01..20, QA-TEC-19..30. **Nenhuma task criada** (conforme instrução) |
| 06-roadmap-de-implementacao.md | Fases F0..F5 (out/26 → jan/28), marcos M1..M9, decisões D1..D14 com prazo-limite, caminho crítico, cenários, rollout, governança, RSK-RMP-01..12, QA-RMP-01..12 |

### Componentes e justificativas (resumo)
| Componente | Decisão | Justificativa resumida |
|---|---|---|
| COMP-01 `atacado-adesao-termo` | **Novo** — Java 21/Spring Boot 3, monólito modular (BC-01+BC-02) | Orquestra a jornada (ADR-02) e absorve as ACLs FIRP/GACD, a geração do documento e o gatilho do convênio. Um serviço por integração geraria microsserviços anêmicos, com transação distribuída e credenciais espalhadas |
| COMP-02 `atacado-adesao-receptor` | **Novo** | Único ponto exposto a chamadores externos ao Atacado (callback do GACD e alerta do Canal). Tem superfície de ataque, disponibilidade e credenciais próprias. Grava na inbox (idempotente) |
| COMP-03 `atacado-adesao-acompanhamento` | **Novo** (worker) | Relay da outbox que faz upsert no Salesforce (OAuth JWT Bearer). Isola a credencial do Salesforce e o egress para a internet |
| COMP-04 `atacado-adesao-db` (PostgreSQL Flexible Server) | **Novo** — fora do stack-tech | Transactional outbox/inbox, saga e auditoria. **Premissa a aprovar** (QA-TEC-12) |
| COMP-05 `atacado-adesao-staging` (Blob) | **Novo** | Staging do PDF para reprocessamento sem regerar o documento, com lifecycle de 30 dias. Fallback: bytea no PostgreSQL |
| COMP-06 artefatos Salesforce | **Novo** (configuração) | Named Credential, objeto/campos de status |
| IMPD cloud `impd-srv-doc-generator` | **Plano A condicionado** | A fonte [06] mostra que há API na Azure. O gate é um spike de 3 semanas (G1–G5). Plano B: geração própria em Java atrás da mesma porta |
| Orientações do usuário **descartadas** | integrador-firp, gerador-termo-pdf, integrador-gacd e callback como serviços separados; callback chamando o Salesforce direto; Azure Functions; IMPD mainframe; documento no Salesforce; Debezium; Private Connect; Platform Events como canal principal | Justificativas em 04a (COMP-21..30) |
| Convênio | **Porta inativa** + eventos-gatilho (ADR-11); COMP-31 adiado | Não construir o que o negócio ainda não definiu |

### Riscos identificados (principais)
RSK-01 IMPD imaturo ou sem conectividade (M/A) · RSK-02 templates CSF (A/M) · RSK-03 contrato do callback (A/A) · RSK-04 protocolos órfãos no GACD (M/A) · RSK-05 LEAP não confirmado (M/A) · RSK-06 Canal não entrega a API de alerta (A/A) · RSK-07 contrato FIRP (A/M) · RSK-08 payload base64 (M/M) · RSK-09 rotas de rede Hub and Spoke (M/A) · RSK-10 PostgreSQL/Blob fora do stack (M/M) · RSK-11 limites do Salesforce (B/M) · RSK-12 LGPD (M/A) · RSK-13 convênio indefinido (A/A) · RSK-14 IPs/My Domain do Salesforce (M/M) · RSK-15 BGS (A/A) · RSK-16 callback forjado (B/A) · RSK-17 versões divergentes na inbox (B/M) · roadmap: RSK-RMP-01..12 (congelamento de fim de ano, squad único, backlog de Canais, decisões atrasadas, adoção, HML instável, jurídico etc.).

### Questões em aberto técnicas (destaques obrigatórios)
- **IMPD:** QA-TEC-01 conectividade ARO → IMPD cloud; QA-TEC-02 criação e esteira do template CSF (competência de nicho, RDM); decisão D2 (Plano A/B) com prazo-limite em 06/11/26.
- **Autenticação LEAP:** QA-TEC-03 (Segurança), confirmar LEAP como padrão no Axway para FIRP/GACD; QA-TEC-04 "usuário sistêmico" exigido pelo GACD [04]; QA-TEC-14 identidade de workload; QA-TEC-26 certificados.
- **Contrato com o Canal:** QA-TEC-08 (Canais), API de alerta de assinantes inválidos, proposta sem dado pessoal (ADR-09) "a combinar com Canais"; decisão D11 até 26/02/27.
- **Convênio:** QA-TEC-11 + QA-CONV-01..11 + QA-CON-02..05; decisão D12 (26/02/27 se opção A, 30/04/27 se B/C).
- Outras: contratos FIRP (05) e GACD (06, 07, 24), rede (09), payload (10), PostgreSQL/Blob (12), broker (13), observabilidade (16), retenção (17), guarda do termo assinado (18), CI/CD e IaC (19, 20), HML integrada (21), CNPJ alfanumérico (25).

### Decisões do orquestrador na consolidação (Rodada 2)
1. **Tensão 03 × orientação do usuário:** o 03 propunha um monólito modular e o usuário, 4 microsserviços. O 04 decidiu por **3 deployables** (ADR-01). O 03 recebeu nota de consolidação na §8 com a correspondência de nomes (`convenio-gateway` → `convenio-produto`; DU-02 absorvida por COMP-03).
2. **Paralelização:** 04b (C4), 04c (ArchiMate), 05 e 06 rodaram em paralelo a partir do resumo único do item 04 (`resumo-item04`), para garantir os mesmos nomes técnicos.
3. **Ferramental:** PlantUML (jar) baixado no scratchpad. O Graphviz foi extraído de pacotes .deb sem instalação no sistema. O Mermaid foi validado com mmdc.
4. **Passada de consistência pós-paralelo (inconsistências corrigidas):**
   - **Colisão OBJ-xx:** no 01, OBJ-01..05 eram *objetivos*; no 02, *objetos de negócio*. Os objetivos do 01 viraram **OE-01..05** (ligados a KPI-01..05), e OBJ-xx ficou só para objetos de negócio. O OE-04 do 02/04c foi alinhado ao texto do 01.
   - **Drivers DRV-xx divergentes (DRV-04/05):** o 01 é o mestre. O 02 foi alinhado e foi criado **DRV-06** (reuso de componentes corporativos) nos dois documentos. am-01/am-06 foram atualizados.
   - **Regras de negócio:** o 02 usava RN1..RN5 com significados trocados em relação ao RN-01..16 do 01. Foram substituídas pelas RN-xx equivalentes (RN-01, RN-03, RN-02, RN-11/12, RN-05/06), com nota de equivalência. Também foi corrigida uma referência interna do 01 (RN-08/09 → RN-05/06).
   - **Nomes:** "Canal Digital PJ" ficou padronizado em todos os docs e .puml (CAP-13 = "Gestão do Canal Digital PJ"). COMP-06 = "Artefatos Salesforce do Atacado". Axway = "Hub (localização a confirmar — QA-TEC-09)" em 04, 04a, 04b e 04c.
   - **Refinamentos do 05 propagados às fontes (05 §17, I-01..I-16):** repetição com `Idempotency-Key` → 202 + `Idempotent-Replayed` (o 04 dizia 200); unicidade da inbox = `(origem, chave)` (04 × 04a divergiam); a outbox tem consumidor único (COMP-03) e o COMP-01 ganhou uma fila de tarefas interna (o 03 previa o COMP-01 consumindo a própria outbox); dois campos de correlação no envelope; tabelas `produto_aderido` e `decisao_elegibilidade`; egress por namespace (DT-20); CPF possivelmente exigido pelo GACD (QA-TEC-24).
   - Sem outras colisões de ID (PRI, R, DU, RSK × RSK-RMP, QA-*, D1..D14, M1..M9, KPI verificados).
5. **Re-renderização:** 10 vistas ArchiMate e c4-01/02/06 foram re-renderizados com Graphviz, com ganho de legibilidade. O am-04 foi mantido em layout Smetana porque ficava pior no Graphviz. O modelo Open Exchange foi regerado (198 elementos / 266 relações, XML bem-formado). Os 20 blocos Mermaid foram validados.
6. **Versões após a consolidação:** 01 v0.3; 02 v0.3; 03, 04, 04a, 04b, 04c e 05 v0.2; 06 v0.1.

### Status ao final da Rodada 2
Documentos 01–06 consistentes entre si. Seguindo para a Rodada 3 sem parada.

---

## Rodada 3 — Apresentação executiva (item 07)

Os documentos 00–06 foram relidos pelos subagents de conteúdo. **Nenhum documento anterior foi alterado nesta rodada**, conforme a instrução. A única edição foi a criação do novo arquivo 08 (consolidado de questões).

### Execução
1. **Análise de /scripts e do sample-ppt.pptx** (adiantada em paralelo na Rodada 1): style do deckkit, layout slide a slide do sample, limites de texto e caminho de renderização.
2. **Conteúdo por tópico em paralelo** (6 subagents, um por tópico): JSON já dimensionado para os limites de caracteres do layout (`docs-final/deck/conteudo/topico1..6.json`).
3. **Montagem única** do .pptx por um só subagent (`docs-final/deck/build_deck.py`, que importa o `scripts/deckkit.py`).
4. **Revisão visual independente** por outro subagent (render a 130 dpi + checagens com python-pptx), com as correções devolvidas ao montador.

### Decisão de style × layout
Style = deckkit (paleta CC092F/2B2B2B/666666/F5F5F5/FBEAEE, Calibri, kicker + título afirmativo + apoio em itálico, rosa = novo/alvo, cinza = contexto, sem sombras, fonte ≥ 7,3pt). Layout = estrutura do sample-ppt.pptx: capa, agenda, onepage, divisores, camadas, capacidades, AS-IS→TO-BE, macro, tabela de decisões, riscos com semáforo, questões em 2 colunas, Gantt e encerramento. A agenda foi ampliada para 6 tópicos, com "Questões em aberto" como seção própria.

### Artefatos
- **`docs-final/07-apresentacao-executiva.pptx`** (19 slides, com notas do orador em todos os slides de conteúdo, na agenda e nos divisores)
- `docs-final/07-apresentacao-executiva.pdf`
- `docs-final/deck/build_deck.py` + `docs-final/deck/conteudo/*.json` (regeneração: `python3 docs-final/deck/build_deck.py --pdf`)
- `docs-final/08-consolidado-questoes-em-aberto-por-time.md` (74 questões consolidadas a partir de 108 IDs, agrupadas por time, com prazos-limite)

Slides: 1 Capa · 2 Agenda · 3 Onepage · 4 Divisor · 5 Camadas · 6 Capacidades · 7 Divisor · 8 AS-IS→TO-BE · 9 Macro · 10 Decisões de arquitetura · 11 Divisor · 12 Riscos · 13 Divisor · 14 Questões de negócio · 15 Questões técnicas · 16 Divisor · 17 Roadmap (Gantt) · 18 Decisões do roadmap · 19 Encerramento/próximos passos.

### Ajustes feitos após a revisão visual
**Autorrevisão do montador (2 iterações):**
- Princípios e camadas passaram a 9pt, para ocupar o espaço vazio.
- As caixas de capacidades foram reequilibradas.
- "Plano A" deixou de quebrar, com espaço inseparável.
- No macro, legenda e lista de fluxos foram aproximadas.
- No Gantt, os rótulos de marco ganharam fundo para não sumirem sobre as faixas de congelamento.
- A largura dos grupos do macro foi rebalanceada depois que o COMP-03 estourou a caixa.

**Revisão independente (veredito "aprovado com ajustes": 6 médias e 6 baixas), todas corrigidas:**
1. IDs quebrando no hífen ("QA-/CON-02"): hífen inseparável U+2011 aplicado a todos os IDs.
2. "atacado-adesao-/acompanhamento" quebrando: hífen inseparável e caixa do COMP-03 alargada.
3. Nomes dos serviços divergiam entre os slides 3, 8 e 9: padronizados como COMP-01/02/03 `atacado-adesao-*`. No slide 8, `termo-documento` virou módulo interno tracejado do COMP-01, coerente com "3 serviços".
4. Slide 9: vazios grandes eliminados, e a legenda "Vermelho: novo" foi corrigida para "Rosa: novo, construído pelo Atacado".
5. Slides 18 e 19: a D6 (contrato FIRP) faltava. Foi incluída, e os próximos passos passaram a citar os IDs exatos.
6. Jargão "deployables" trocado por "serviços" em títulos e subtítulos.
7. Português: "tempo negociação" virou "tempo de negociação". "Atacado CP" foi escrito por extenso. O slide 14 ganhou espaçamento uniforme. O título do slide 19 passou a afirmar: "Quatro entregas até 27/11 destravam a F0". Referências como "04 §14" trocadas pelo nome do documento. "LRM" e "nota 3,40×3,30" foram para as notas do orador.

**Checagens finais:** 19 slides, nenhuma shape fora da área, fonte mínima de 7,3pt, zero sombras e todos os títulos com até 55 caracteres. O orquestrador conferiu os slides 3 e 9 por amostragem.

### Inconsistência identificada na Rodada 3 (corrigida após a entrega — ver seção seguinte)
- **Letras das opções do Convênio:** o 02 (DEC-CON-02) usa (a) Open Cash Hub, (b) novo serviço, (c) sistemas de cada produto, (d) Salesforce. Já 03 §4.3, 04 (ADR-11) e 06 (D12) usam **A** novo serviço, **B** legado + ACL, **C** Open Cash Hub, **D** Salesforce. O deck cita as opções por nome, então fica neutro, e o 08 traz nota explicativa. **Correção recomendada:** alinhar o 02 às letras do 03.

### Ferramental usado (fora do repositório)
- LibreOffice 25.8 AppImage extraído em `~/.local/opt/libreoffice` (~725 MB + AppImage de 291 MB, que pode ser apagado), com wrapper em `~/.local/bin/soffice`. Instalado sem sudo pelo subagent de análise de scripts.
- PlantUML (jar), Graphviz (extraído de .deb) e a fonte Carlito (métrica do Calibri) ficaram só no scratchpad da sessão. mmdc foi executado via npx.

---

## Correções pós-entrega (2026-09-24, a pedido do usuário)

Pedido: "corrigir as letras das opções de convênio e demais correções".

| # | Correção | Arquivos | Versão |
|---|---|---|---|
| 1 | **Letras das opções do Convênio** alinhadas às canônicas em DEC-CON-02: **A** novo serviço no ARO Atacado; **B** sistemas legados de produto via ACL; **C** Open Cash Hub; **D** Salesforce + legado (não recomendada). Antes: (a) Open Cash Hub, (b) novo serviço, (c) sistemas de produto, (d) Salesforce | 02-desenho-conceitual.md | v0.4 |
| 2 | Coluna "Referência" da tabela de opções (§4.3) apontava para as letras antigas do 02 (b/c/a/d) e passou a A/B/C/D | 03-dominios-bounded-contexts-context-mapping.md | v0.3 |
| 3 | Nome residual `convenio-gateway` trocado pelo definitivo: módulo `convenio-produto` (COMP-01.6) e microsserviço `atacado-convenio-produto` (COMP-31, só na opção A), na tabela e no diagrama da §8 do 03 e na rastreabilidade do 04a. Registros históricos de correspondência (04 §17 e nota do 03) mantidos de propósito | 03, 04a-componentes-e-justificativas.md | 03 v0.3 · 04a v0.3 |
| 4 | Modelo ArchiMate Open Exchange **validado contra o XSD oficial** (`archimate3_Diagram.xsd` 3.1, The Open Group) com lxml: **válido, 0 erros**. Limitação atualizada: falta só o teste de importação no Archi | 04c-diagramas-archimate.md | v0.3 |
| 5 | Nota do consolidado atualizada: a divergência de letras deixou de existir | 08-consolidado-questoes-em-aberto-por-time.md | — |
| 6 | Erro de português "tempo negociação", apontado na revisão do deck, corrigido para "tempo de negociação" também nos documentos. A vista am-01 foi re-renderizada com Graphviz e o modelo Open Exchange foi regerado e revalidado contra o XSD: 198 elementos, 266 relações, 0 erros | 01, 04c, 05, 06, 08, diagramas/archimate/am-01-motivacao.* e am-modelo-open-exchange.xml | — |

Verificação: nenhuma referência a letras de opção do Convênio diverge entre 02, 03, 04, 04a, 04b, 06, 08 e o deck. O deck (07) cita as opções por nome, então não precisou ser regenerado.

---

## Ajustes pós-entrega — rodada 2 (2026-09-24, `instrucoes-ajustes.md`)

Pedido: "Execute os ajustes das instruções do arquivo instrucoes-ajustes.md" (três itens: nomes das capacidades nos slides 3 × 6; separação da CAP-09.2; passo de revalidação na FIRP antes da assinatura no GACD).

| # | Ajuste | Arquivos | Versão |
|---|---|---|---|
| 1 | **Slide 3 alinhado ao slide 6.** Os cards de capacidade do onepage passam a usar os nomes e status do slide de capacidades: "Jornada de adesão e Termo" (antes "Jornada do termo no ARO") · Nova · construir; "Assinatura, poderes e documentos" (antes "Aceite digital corporativo") · Reuso corporativo; "Convênio, tarifas e elegibilidade" (antes "Convênio por produto") · Em aberto, com um bullet para a fonte do contrato vigente (elegibilidade). Descrições do COMP-02 ("sinal de assinantes inválidos do Canal") e do COMP-03 ("status e alertas ao Gerente") ajustadas ao item 2 | deck/conteudo/topico1.json | — |
| 2 | **CAP-09.2 separada em duas L2.** CAP-09.2 **Alertas ao Gerente** mantida e redefinida como notificação de alertas ao Gerente no Salesforce (COMP-03 / APP-02.5 / BC-03: lê `AssinantesInvalidados` da outbox, cria o `AlertaGerente` e faz o upsert em `Alerta_Adesao__c`, com retentativa). Nova **CAP-09.5 Recepção de Sinais de Assinantes Inválidos** (COMP-02 / APP-02.6 / borda de entrada do BC-01: autentica, valida, deduplica, grava na inbox e responde o ACK, sem regra de negócio; entrada via Axway interno, contrato a combinar com Canais). Entre as duas, o COMP-01 aplica a regra de domínio (INV-08, estado "Assinantes inválidos"). Revisados: 02 (mapa L1/L2 com nota das duas metades, APP-02.5/02.6, Mermaid do mapa de capacidades, matriz capacidade × processo × sistema × time, QA-CON-08, §9); 03 (SD-01, SD-03, BC-01, BC-03, R-13, eventos `AssinantesInvalidados` e `AlertaGerenteEmitido`); 04 (RF-08 = recepção, CAP-09.5; RF-09 = notificação, CAP-09.2; leituras da §4 e do Fluxo 3); 04a (fichas COMP-02, COMP-03 e COMP-18; leitura da matriz Componente × RF); 05 (SPEC-REC-02 e SPEC-API-03 → CAP-09.5; matriz §15); 06 (capacidades da F3); deck slides 3, 8 e 9 (papel do COMP-03) | 02, 03, 04, 04a, 05, 06, deck/conteudo/topico1.json, topico3.json | 02 v0.5 · 03 v0.4 · 04 v0.3 · 04a v0.4 · 05 v0.3 · 06 v0.2 |
| 3 | **Revalidação na FIRP antes da assinatura (passo que faltava).** O Canal Digital PJ revalida os assinantes na FIRP (RN-06) e só depois registra a assinatura no GACD. Slide 9: fluxos 7 "acessa o termo pendente", **8 "revalida assinantes na FIRP"** (Canal → FIRP) e **9 "só então assina no GACD"** (Canal → GACD), com as setas desenhadas no diagrama; os seguintes foram renumerados (10 callback … 13 upsert status e alertas). 04: setas rotuladas Canal → FIRP / Canal → GACD na §4 e Fluxo 2 (§6.2) passa a começar no Canal (pendência → revalidação → assinatura → callback). 04b: C4 dinâmico da jornada (§5.1, `c4-04-dinamico-jornada`) com os passos 16 a 19 do Canal (17 = revalidação) e renumeração até 25; PNG e SVG re-renderizados | deck/conteudo/topico3.json, deck/build_deck.py, 04, 04b, diagramas/c4/c4-04-dinamico-jornada.* | 04 v0.3 · 04b v0.3 |

**Sem alteração (validado com grep):** 01 e 04c/`.puml`/modelo Open Exchange citam só a L1 CAP-09, nunca a L2 CAP-09.2. O slide 6 não cita a L2 de alerta. 08 não cita CAP-09.

**Verificação:**
- Deck regerado (`build_deck.py --render`, Carlito no lugar do Calibri). Comparação pixel a pixel com a versão anterior: só os slides 3, 8 e 9 mudaram. Os três foram conferidos no render, sem estouro de texto. PDF atualizado em `07-apresentacao-executiva.pdf`.
- Mermaid alterados (02 mapa de capacidades; 04 visão macro, Fluxo 2 e Fluxo 3) renderizados com mermaid-cli sem erro.
- `c4-04-dinamico-jornada.puml` igual ao bloco PlantUML embutido no 04b.

---

## Ajustes pós-entrega — rodada 3 (2026-09-27, `instrucoes-ajustes.md`)

Pedido: "faça os ajustes do documento instrucoes-ajustes.md". Os itens 1 a 3 já estavam feitos (rodada 2) e não foram refeitos. Foram executados os dois pendentes: glossário de siglas (item 4) e nomes das capacidades no slide 5 (item 5).

| # | Ajuste | Arquivos | Versão |
|---|---|---|---|
| 4 | **Glossário de siglas.** Novo documento com as siglas levantadas por grep em todos os documentos de `docs-final/`: prefixos de ID agrupados por tema (estratégia e negócio; desenho conceitual e ArchiMate; DDD; arquitetura de solução; especificações; roadmap; questões e premissas), códigos `<CÓD>` das SPEC/CA, sistemas do banco e siglas técnicas, cada um com significado, documento de origem (com seção) e exemplo real. Também traz as marcas FATO/PREMISSA/HIPÓTESE/ABERTO/DECISÃO/BLOQUEIO. Onde as fontes não trazem a expansão de uma sigla interna (GACD, GCC, BGS, PDPJ, LEAP, BCM), o documento diz isso e descreve o papel do sistema, sem inventar a expansão. **Slide 20 "O que cada sigla significa"** (anexo, depois do encerramento), gerado pela nova função `glossario()` do `build_deck.py`, que lê as tabelas das seções 3.1 a 3.7, 4 e 5 do 09 e distribui os grupos em 4 colunas (7,6 pt). A 3.8 (códigos das SPEC) e a 6 (marcas) ficam só no documento | 09-glossario-de-siglas.md (novo), deck/build_deck.py | 09 v0.1 |
| 5 | **Slide 5, faixa Capacidades com os nomes canônicos das L1 do 02 §3.3** (substantivo, sem sistema e sem sequência), com os IDs numa linha menor e cinza abaixo: "Gestão de Relacionamento Comercial, de Tarifas e Documental · CAP-01, 07, 08"; "Gestão de Adesão a Produtos Cash e do Termo de Adesão · CAP-02, 03 · novas"; "Gestão de Representantes e Poderes e de Assinatura Digital · CAP-04, 05 · reuso"; "Acompanhamento de Status, Integração, Segurança e Rastreabilidade · CAP-09 a 12" (a CAP-11, que faltava na faixa, entrou aqui); "Gestão de Convênios (sem dono) e do Canal Digital PJ (externa) · CAP-06, 13". Destaque rosa mantido na 2ª e 4ª caixas; a 5ª segue tracejada. `camadas()` passou a aceitar caixa como `{nome, ids, tracejado}` (as demais faixas continuam com texto simples). Fonte mantida em 9 pt; as caixas 1 e 4 ocupam 3 linhas + IDs sem estourar. Notas do orador reescritas com os nomes completos das L1 | deck/conteudo/topico2.json, deck/build_deck.py | — |

**Verificação:**
- Deck regerado (`build_deck.py --pdf`, com a fonte Carlito no lugar do Calibri via `FONTCONFIG_FILE`): agora com **20 slides** (1 a 19 como antes + 20 Glossário). Comparação pixel a pixel com o render da versão anterior: entre os slides 1 a 19, só a faixa Capacidades do slide 5 mudou. Slides 5 e 20 conferidos no render, sem estouro de texto.
- Checagens com python-pptx: nenhuma shape fora da área e fonte mínima de 7,3 pt. PDF com 20 páginas e as mesmas fontes da versão anterior (Carlito + fallbacks de símbolos).
- `07-apresentacao-executiva.pptx` e `07-apresentacao-executiva.pdf` atualizados.

---

## Ajustes pós-entrega — rodada 4 (2026-09-27, `instrucoes-ajustes.md`, item 6)

Pedido: colocar Capacidades antes de Negócio, como no ArchiMate (Estratégia → Objetivos → Capacidades → Processos de negócio → …), com o rótulo "Processos de negócio" no slide. Decisões registradas no item 6:
- consistência total com os documentos (IDs das camadas e seções do 02 renumerados);
- "Processos de negócio" e "Drivers" como rótulos **só no slide**;
- troca de "realiza" por "sustenta" na seta fora do escopo.

Motivo: com Negócio acima de Capacidades, a seta "cada camada realiza a camada acima" dizia que capacidades realizam processos. No ArchiMate é o inverso: o processo realiza a capacidade. O 04c já punha as capacidades na camada de Estratégia do ArchiMate.

| # | Ajuste | Arquivos | Versão |
|---|---|---|---|
| 6a | **Camadas do 02 reordenadas.** **CAM-2 = Camada de Capacidades** e **CAM-3 = Camada de Negócio** (antes o inverso). Capacidades passa à §3.2 e Negócio à §3.3 (subseções §3.3.1–§3.3.6), com o conteúdo inalterado. Também mudaram: <br>• tabela de camadas da §3, com nota explicando a ordem e perguntas da CAM-3 e da CAM-4 citando processos e capacidades; <br>• §3.1.3 ("Capacidades (CAM-2)"); <br>• referências internas "seção 3.2.6" → "3.3.6"; <br>• diagrama da §4.1 (`CAM1 --> CAM2 Capacidades --> CAM3 Negócio --> CAM4 --> CAM5`) | 02-desenho-conceitual.md | 02 v0.6 |
| 6b | **Referências cruzadas ao 02 atualizadas por script:** "02 §3.2.x" → "02 §3.3.x" e "02 §3.3" → "02 §3.2", só quando a referência aponta para o 02. As referências ao 04 §3.2/§3.3 (RF/RNF), ao 03 e ao 06 foram mantidas. Linhas de histórico de versão e este log não foram tocados. Total: 101 no 04c (outras 22 referências a "04 §3.x" mantidas), 7 no 03, 1 no 01, 9 no 09 e 8 nos comentários de fonte de 4 `.puml` do ArchiMate (`am-02`, `am-03`, `am-03b`, `am-03c`). Os comentários dos blocos PlantUML embutidos no 04c ficaram iguais aos dos `.puml` | 01, 03, 04c, 09, diagramas/archimate/*.puml | 01 0.4 · 03 v0.5 · 04c v0.4 · 09 v0.2 |
| 6c | **IDs CAM fora do 02:** tabela de correspondência Camada do 02 × ArchiMate do 04c (§2) com as linhas trocadas e reordenadas (CAM-2 Capacidades → Estratégia; CAM-3 Negócio → Negócio) e nota de que o processo realiza a capacidade; exemplo da CAM no 09 (CAM-2 Camada de Capacidades) | 04c, 09 | — |
| 6d | **Slide 5:** faixas 3 e 4 trocadas. Os rótulos passam a ser 1 Drivers, 2 Objetivos, 3 Capacidades, 4 Processos de negócio, 5 Aplicação e 6 Tecnologia. Destaque rosa e tracejado mantidos, e as colunas continuam casadas (PN-01 ↔ CAP-01…). Notas do orador com a razão da ordem, e "faixa Negócio" virou "faixa Processos de negócio" | deck/conteudo/topico2.json | — |

**Verificação:**
- **Deck:** regerado com a fonte Carlito, 20 slides e PDF com 20 páginas. Na comparação pixel a pixel com a rodada 3, só o slide 5 mudou. O render do slide 5 foi conferido: "Processos de negócio" cabe em uma linha e nenhuma shape sai da área.
- **Mermaid da §4.1 do 02:** renderizado com mermaid-cli sem erro, na ordem nova.
- **Grep:** nenhuma referência "02 §3.3" citando CAP-xx e nenhuma "02 §3.2.x" citando ATR/PN/EVN/OBJ fora deste log.
- **Pendências preexistentes, não mexidas:**
  - o bloco embutido `am-03-negocio` no 04c difere do `.puml` numa aresta oculta de layout (`evn08 → pn10`, retirada só no `.puml`);
  - o cabeçalho do 04c indicava v0.2 com histórico em v0.3 (agora v0.4 nos dois).

---

## Ajustes pós-entrega — rodada 5 (2026-09-27, `instrucoes-ajustes.md`, itens 7 a 10)

Pedido: "execute as instruções pendentes do arquivo instrucoes-ajustes.md". Os itens 1 a 6 já estavam feitos e não foram refeitos. Ordem de execução: 8 (documentos), 10 (novo slide), 9 e 7 (slide de camadas). O item 8 foi executado antes do 10, então o slide novo já usa o nome novo do estágio VS-01.4.

### Item 8 — Convênio: implantação e homologação, executadas pelo Gerente de Cash ou pelo backoffice

Todo o conteúdo de mercado entrou como **PREMISSA — padrão de mercado** ou **INFERÊNCIA**, nunca como FATO. Vocabulário comum aplicado em todos os documentos:
- **PN-10 "Implantar produto e gerar Convênio"**, com as atividades PN-10.1 a PN-10.4: definir parâmetros com o cliente, criar o convênio em teste no sistema do produto, homologar e ativar;
- executor **Gerente de Cash ou backoffice (a definir)**, com a nova **ATR-09 Backoffice de Cash**;
- **EVN-13 "Implantação iniciada"** e **EVN-10 "Convênio ativado"**;
- estados do convênio **Em teste → Ativo**;
- status da jornada **Assinado → Em implantação → Convênio ativo → Tarifas cadastradas**, com "Convênio pendente" como exceção;
- **RN-17** "o Convênio só fica ativo após a homologação";
- **QA-CONV-12/QA-CON-24** (quem executa a implantação) e **QA-CONV-13/QA-CON-25** (produtos com homologação e existência de uma área de implantação);
- **RSK-18** (implantação técnica pelo Gerente de Cash foge do papel comercial);
- a porta `convenio-produto`, quando ativada, **abre uma pendência de implantação** e não cria o convênio por API.

| Arquivo | O que mudou | Versão |
|---|---|---|
| 01 | Sumário; métrica de ciclo separando o tempo de homologação (§4.3); DRV-03; RACI (atividade 13); AS-IS, TO-BE (Mermaid com implantação, homologação e ativação) e etapas (§7.1–7.3); status da jornada (§7.4); RN-13 revista e RN-17; RFN-09 e RFN-10; CAP-06/07 (§9); OP-05; §11 com nota de padrão de mercado, QA-CONV-02, 03 e 11 revistas, QA-CONV-12 e 13 novas e o risco associado; PRM-NEG-17 revista e PRM-NEG-18 nova; glossário (Convênio, Implantação, Homologação, CNAB, VAN) | 0.5 |
| 02 | Objetivo (§2.1); CAP-06.1 e CAP-07.1; ATR-01 e nova ATR-09; PN-10 e PN-11; EVN-10 e novo EVN-13; OBJ-07 com estados; RN-13 e RN-17 na referência; status da jornada (§3.3.6); APP-09 = sistema de cada produto; diagramas §4.1 e §4.3 (executor e homologação); matriz (§5); PRI-12; nota em DEC-CON-02 (em todas as opções A–D há executor humano); QA-CON-03 revista, QA-CON-24 e 25 novas; PRM-CON-08 e 14 revistas e PRM-CON-15 nova; insumos para o 03 | v0.7 |
| 03 | BC-04 reescrito com linguagem ubíqua (Implantação, Homologação, Convênio em teste / ativo, Executor da implantação, Convênio pendente); BC-03 com os novos status; context map e R-15/R-16/R-18; nota em §4.3; eventos (`ConvenioSolicitado` = EVN-13; `ConvenioGerado` → `ConvenioAtivado`; `GeracaoConvenioFalhou` → `ConvenioPendente`; novo `ConvenioCriadoEmTeste`); fluxo §5.4; QA-DDD-06/11 revistas e nova QA-DDD-14; glossário. Também corrigidas letras residuais de DEC-CON-02 (SD-04 e BC-12) | v0.6 |
| 04 | §2.3, RF-12, COMP-01.6, COMP-20, nota do Fluxo 2, ADR-11 (status reservados, porta que abre pendência, executor humano em todas as opções), **RSK-18** (M/A) e QA-TEC-11 | v0.4 |
| 04a | Tabela e ficha do COMP-01.6 (abre a implantação; RSK-18) e COMP-20 (consome o convênio ativo) | v0.5 |
| 04b + `c4-01-contexto`, `c4-03-componentes-adesao-termo` | Ator tracejado Backoffice de Cash no C4 de contexto; porta `convenio-produto` que abre a implantação e acompanha o status; leituras, rastreabilidade e §8. PNG/SVG regerados; blocos embutidos iguais aos `.puml` | v0.4 |
| 04c + `am-02`, `am-03`, `am-03b`, `am-03c` | VS-01.4 → **"Implantar produtos e ativar Convênios"** (§4.1); PN-10 com PN-10.1–10.4, EVN-13 e EVN-10 no `am-03`; ATR-09 e papel "Executor da implantação" no `am-03b`; estados do OBJ-07 no `am-03c`; textos e tabelas de rastreio. PNG/SVG regerados; blocos embutidos iguais aos `.puml`. Modelo Open Exchange regerado (205 elementos, 279 relações) e **válido contra o XSD** (0 erros). O `gerar_open_exchange.py` ganhou a diretiva `'@name` para nomes com rótulo em várias linhas | v0.5 |
| 05 | SPEC-CNV-01 (comportamento esperado na ativação), flag `convenio.gatilho.habilitado`, status reservados `EM_IMPLANTACAO`/`CONVENIO_ATIVO`/`TARIFAS_CADASTRADAS` (`CONVENIO_PENDENTE` como exceção), picklist `Status_Jornada__c`, catálogo de eventos e matriz §15 | v0.4 |
| 06 | D12 inclui **quem executa a implantação**, com prazo-limite de 30/04/2027 em qualquer opção e regra padrão (Gerente de Cash, com o RSK-18 aceito no Steering); F5, M8, DEP-22, §9, Onda 4 e métrica de ciclo revistos; novos PRM-RMP-14 (o M8 mede o software; a homologação de cada cliente fica fora do cronograma do squad) e RSK-RMP-13. **Datas não mudaram** | v0.3 |
| 08 | Item 2 reduzido a "Gerente de Cash ou backoffice"; item 9 com atraso na homologação; novas linhas QA-CONV-12/QA-CON-24 e QA-CONV-13/QA-CON-25 (Atacado Cash Payments, prazo 30/04/27). Totais: **76 questões, 112 IDs** (antes 74 e 108) | — |
| 09 | CNAB e VAN nas siglas técnicas | v0.3 |
| Deck | Slide 3 (bullet do Convênio), 7 (o que falta definir e pedido ao Atacado), 10 (porta abre a implantação), 11 (notas do ADR-11), 15 (QA-CONV-02/03/12 com prazo 30/04/27, falha ou atraso na homologação, contagens 76/112), 18 (F5 e nota) e 19 (nota da D12); notas do orador correspondentes | — |

### Item 10 — Novo slide 5: value stream VS-01 × capacidades

- Nova função `value_stream()` no `build_deck.py`, chamada entre o divisor do tópico 02 e `camadas()`. O conteúdo fica em `slide_value_stream` no `topico2.json`.
- Desenho com formas nativas: os cinco estágios em chevrons, com o valor entregue no fim da linha; uma coluna de capacidades por estágio, com nome canônico e ID em linha cinza; e a faixa "Transversais" (CAP-10, 11 e 12), que servem outras capacidades e não um estágio.
- Cores conforme a tabela decidida no item 10, com a mesma legenda do slide de camadas. Em rosa: CAP-02, 03, 08, 09, 10 e 12. Tracejada: CAP-06. As demais ficam em branco.
- O estágio VS-01.4 usa o nome novo e traz a nota "Implantação e homologação com o cliente: Gerente de Cash ou backoffice (QA-CON-24)".
- **Ponto decidido — CAP-09:** a capacidade fica no VS-01.3, como no `am-02-estrategia.puml`, e as notas do orador dizem que ela acompanha a jornada inteira. Assim o 04c não precisou mudar.
- Divisor do tópico 02 com "Três slides" e agenda citando o value stream.
- **Renumeração:** o slide de camadas passa a 6, o de capacidades a 7 e o glossário a 21, com 21 páginas no PDF. O grep não achou referências a número de slide fora deste log e do `instrucoes-ajustes.md`.
- **Coerência com a CAP-08 em rosa:**
  - no slide 6, a CAP-08 saiu da caixa branca "Relacionamento, Tarifas e Documental" e foi para a caixa rosa com CAP-02 e CAP-03;
  - no slide 7, a coluna de reuso passa a listar só a CAP-08.2 (GCC/Filenet), e a contagem do subtítulo foi corrigida para "6 a cargo do Atacado, 6 reusadas ou externas e o Convênio ainda sem dono". Antes a soma dava 12 de 13.

### Item 9 — Slide de camadas (agora slide 6): todos os objetivos em rosa
- Faixa Objetivos com OE-01 a OE-05 em rosa.
- **Ponto decidido — drivers:** os cinco drivers também passam a rosa. A legenda define o rosa em Drivers e Objetivos como "o que a iniciativa atende", e a iniciativa responde a todos, inclusive ao DRV-03 e ao DRV-06. Deixá-los em branco sugeriria que são reuso ou contexto.
- O texto do DRV-03 passa a "Convênio ativo e tarifa no menor prazo após o aceite", conforme o item 8.
- As notas do orador dizem que todos os objetivos são foco.

### Item 7 — Slide de camadas: legenda com três estados
- **Legenda embaixo da faixa Tecnologia**, com amostras reais das caixas: "Foco da iniciativa" (rosa), "Reuso ou contexto" (branca) e "A definir" (tracejada). Ela é desenhada por `legenda_estados()`, que o slide de value stream também usa. Os textos ficam em `slide_camadas.legenda`.
- Para caber, as faixas passaram de 0,74" para 0,72" e o espaço entre elas de 0,095" para 0,07". A fonte das caixas continua em 9 pt.
- O subtítulo passa a "Cada camada realiza a de cima; o novo se concentra em poucas caixas."
- **Revisão das caixas a definir.** A 5ª coluna (Convênio + Canal Digital PJ) fica tracejada em Capacidades, Processos e Aplicação, e o texto diz que só o Convênio está a definir:
  - Capacidades: "Gestão de Convênios (a definir) e do Canal Digital PJ (externa)", com IDs "CAP-06 a definir · CAP-13 externa";
  - Processos: "PN-10 Implantar produto e gerar Convênio (executor a definir) → PN-11 Tarifas";
  - Aplicação: "APP-07 Canal Digital PJ (externo) · APP-09 Sistema de Convênio (a definir)", que passou a tracejada.
- `camadas()` passou a aceitar `tracejado` como lista de índices por camada, como `destaque`. Antes o tracejado dependia de a palavra "indefinid" aparecer no texto.
- **APP-03 Geração de Documento:** passou a tracejada e branca, com o texto "(IMPD ou própria · D2)", até a D2 (06/11/2026). No Plano A é reuso; no Plano B, construção. Isso segue a decisão do item 10 de mostrar essa dúvida na faixa Aplicação.
- **Caixa "CAP-09 a 12":** continua rosa. As notas explicam que a CAP-11 é reuso e que o Axway é tecnologia reusada, como decidido no item 10.

### Verificação
- **Deck:** regerado com a fonte Carlito, com **21 slides** e PDF de 21 páginas nas mesmas fontes da versão anterior.
- **Checagens com python-pptx:** nenhuma shape fora da área e fonte mínima de 7,3 pt.
- **Comparação pixel a pixel com a rodada 4:** mudaram os slides 2 (agenda), 3, 4 (divisor), 5 (novo), 6, 7, 10, 15, 18, 19 e 21 (CNAB e VAN no glossário). Nos outros, só o número da página.
- **Render conferido nos slides 3, 5, 6, 7, 15 e 18:** no slide 3, o bullet "Sistema e executor da implantação indefinidos" quebrava e invadia o selo, então foi encurtado para "Sistema e executor indefinidos".
- **Mermaid:** todos os blocos do 01, 02, 03, 04, 04c e 06 renderizam com mermaid-cli sem erro.
- **PlantUML:** PNG e SVG regerados e conferidos (C4 `c4-01`, `c4-03`; ArchiMate `am-02`, `am-03`, `am-03b`, `am-03c`).
- **Grep em `docs-final`:** "processo automático", "geração automática", "gerado automaticamente", "Convênio(s) gerado(s)", "Gerar Convênio por produto", `ConvenioGerado` e "Habilitar produtos" só aparecem em:
  - linhas de histórico;
  - na pergunta original da QA-CONV-02, que lista as opções;
  - em negações ("nunca um processo automático");
  - na menção histórica do 04c §4.1;
  - no passo AS-IS do slide 10.
- **Pendências observadas, não mexidas:**
  - o bloco embutido `am-04-aplicacao` no 04c não tem as duas linhas do Smetana que existem no `.puml`;
  - no `am-03`, o Graphviz põe a coluna "Pós-assinatura" antes de "Confirmação e acompanhamento", o que está documentado no 04c;
  - o campo "Documentos base" do 03, do 04 e do 06 ainda cita as versões antigas do 01 e do 02.
