# 01 — Contexto de Negócio: Termo de Adesão Multiproduto (Cash Management / Payments — Atacado)

> Iniciativa: **Aceite Digital Cash** — integração do Salesforce a um gerenciador de termos e contratos para gerar e acompanhar o **Termo de Adesão** e viabilizar a geração do **Convênio** por produto e o cadastro de tarifas.
> Documento complementar: `02-desenho-conceitual.md` (camadas de negócio, capacidades e integração) e `03-...` (DDD).

---

## 1. Controle do documento

| Item | Valor |
|---|---|
| Documento | 01 — Contexto de Negócio |
| Versão | 0.5 |
| Data | 2026-09-27 |
| Status | **Rascunho para validação** |
| Autor | Análise de Negócio / Arquitetura de Negócio — Atacado, Cash Management / Payments |
| Público | Time do Atacado Cash Payments, Time de Experiência, Time de Canais, Time do GACD, Arquitetura |
| Próxima revisão | Após validação das questões em aberto (seções 11 e 12) com os times responsáveis |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| 0.1 | 2026-09-23 | Versão inicial para validação |
| 0.2 | 2026-09-23 | Alinhamento de nomenclatura de capacidades (CAP-xx) e cruzamento de questões |
| 0.3 | 2026-09-24 | Consolidação Rodada 2: objetivos renomeados de OBJ-01..05 para **OE-01..05** (o prefixo OBJ fica reservado aos objetos de negócio do 02) e ligados a KPI-01..05; novo **DRV-06** (reuso de componentes corporativos, vindo do 02); correção das RN citadas no princípio 2 (RN-05, RN-06); nome canônico do sistema do cliente padronizado como **Canal Digital PJ** (CAP-13 passa a "Gestão do Canal Digital PJ") |
| 0.4 | 2026-09-27 | Referência ao ciclo de vida do Termo atualizada para a numeração do 02 v0.6 (seção 3.2.6 → 3.3.6). Conteúdo inalterado |
| 0.5 | 2026-09-27 | Convênio com **etapa de implantação e homologação** (`instrucoes-ajustes.md`, item 8), executada pelo **Gerente de Cash ou pelo backoffice** (a definir — nova QA-CONV-12), no lugar da hipótese de processo automático. Revisados: métrica de ciclo (§4.3) e DRV-03 (§5.3); RACI (atividade 13); AS-IS, TO-BE e etapas (§7.1–7.3); status da jornada "Em implantação" e "Convênio ativo" (§7.4); RN-13 e nova RN-17; RFN-09 e RFN-10; CAP-06 (§9); OP-05; §11 (QA-CONV-02, 03 e 11 revistas, novas QA-CONV-12 e 13, nota de padrão de mercado e risco RSK-18); PRM-NEG-17 revista e nova PRM-NEG-18; glossário (Convênio, Implantação, Homologação, CNAB, VAN) |

### 1.1 Fontes utilizadas

| Sigla | Fonte | Observação |
|---|---|---|
| [01] | PRD Aceite Digital Cash — Resumo Executivo e Fluxo de Processo (v1.0, 07/05/2026, Rascunho) | Fluxo do diagrama parcialmente cortado (ramos "NÃO" ausentes) |
| [02] | PRD Aceite Digital Cash — Contexto (Canal Digital, GACD, Open Cash Hub) | Tipos de termo, convênio, candidatos a gerenciador |
| [03] | PRD Aceite Digital Cash — Problema, Impacto e Objetivos | Metas/KPIs; seção de personas vazia |
| [04] | Confluence GACD — Jornada de Armazenamento da Prévia do Contrato | 3 chamadas sequenciais + callback |
| [05] | IMPD — Visão Geral, Objetivo e CSF Designer | Gerador estrutural de documentos |
| [06] | IMPD — Esteira de Publicação e Como Usar | API cloud `impd-srv-doc-generator` na Azure |
| [stack] | `stack-tech.md` | Stack corporativa |
| [CG] | Contexto Geral informado pelo usuário (reuniões) | FIRP → assinantes → GACD; callback na Azure (ARO Atacado, `atacado-core`) |

### 1.2 Convenção de marcação

| Marca | Significado |
|---|---|
| **FATO [xx]** | Afirmação suportada por fonte explícita |
| **INFERÊNCIA** | Dedução do analista a partir das fontes; requer validação |
| **PREMISSA (PRM-NEG-xx)** | Assunção adotada para prosseguir; ver seção 13 |
| ⚠️ **QA-CONV-xx / QA-NEG-xx** | Questão em aberto; ver seções 11 e 12 |

---

## 2. Sumário executivo

Os **Gerentes de Cash** do Atacado conduzem toda a jornada comercial de produtos de Cash Management / Payments no **Salesforce (Salesforce Financial Services Cloud)**, mas **não conseguem gerar o Termo de Adesão** a partir da plataforma. Clientes sem contrato vigente ficam bloqueados até a assinatura manual do termo, a geração dos **Convênios por produto** e o cadastro das tarifas negociadas — um processo manual, lento e **sem rastreabilidade** (FATO [01][03]).

A iniciativa propõe digitalizar a **jornada de adesão** ponta a ponta:

1. o Gerente de Cash gera, a partir do Salesforce, um **Termo de Adesão único e multiproduto** (tipo *Produtos* ou *Produtos + Canal*);
2. os assinantes (representantes com poderes) são obtidos na **FIRP** e enviados, com o termo, ao **GACD** (serviço corporativo de Aceite Digital);
3. o **Cliente PJ Atacado** assina no **Canal Digital do Cliente (Canal Digital PJ)** — hoje BGS + PDPJ —, que revalida os assinantes na FIRP;
4. o GACD notifica a conclusão via **callback** para um serviço no **ARO Atacado**, que atualiza o status no Salesforce em tempo real;
5. a assinatura abre a **implantação** de cada produto: o **Convênio por produto** é criado em teste, **homologado com o cliente** e ativado, pelo Gerente de Cash ou pelo backoffice (a definir); com o convênio ativo, segue-se o **cadastro de tarifas** via pipeline **Databricks** existente.

**Metas do PRD [03]:** ≥ 90% dos termos gerados via Salesforce em 6 meses; −50% no tempo de negociação → assinatura (**baseline não definido**); ≥ 80% de conversão gerado → assinado; 100% dos gerentes com status em tempo real; 100% de conformidade regulatória.

**Principal ponto crítico de negócio:** a **geração do Convênio** — onde é gerado, quem executa a implantação e a homologação, gatilho e relação com o termo — **não está definida** nas fontes. Este documento propõe hipóteses e registra as questões em aberto de forma destacada (**seção 11**) para validação com o Time do Atacado Cash Payments.

---

## 3. Contexto do negócio

### 3.1 Cash Management / Payments no Atacado

- **FATO [02]:** Gerentes de Cash negociam produtos de Cash Management com clientes do Atacado. Parte dos clientes já possui contrato vigente; os demais precisam assinar um **termo de aceite único** que cobre **todos** os produtos Cash e "resguarda o banco para qualquer utilização futura dos serviços".
- **FATO [01]:** Após a assinatura do termo, é necessário gerar **convênios por produto** para que as tarifas negociadas possam ser cadastradas.
- **FATO [01][02]:** A lista de produtos Cash / Payments abrangidos **não é informada** nas fontes (⚠️ QA-NEG-08).
- **INFERÊNCIA:** Produtos típicos de Cash Management / Payments no Atacado (cobrança, pagamentos a fornecedores, folha, arrecadação, conciliação, API/ERP) seriam o universo-alvo; a lista oficial deve vir do Time do Atacado Cash Payments.

### 3.2 Situação atual (AS-IS)

| Aspecto | Situação atual | Fonte |
|---|---|---|
| Geração do termo | Não é possível gerar a partir do Salesforce; termo assinado **manualmente** | FATO [01][02] |
| Rastreabilidade | Processo manual e **sem rastreabilidade** | FATO [03] |
| Contratação | Cliente fica **bloqueado** até a assinatura do termo | FATO [03] |
| Convênio | Gerado fora da jornada comercial; processo/sistema **não documentado** | FATO [01]; ⚠️ QA-CONV |
| Tarifas | Cadastro via pipeline **Databricks** já existente; depende do convênio | FATO [01][02] |
| Visibilidade do gerente | Sem status do termo em tempo real (meta de 100% indica ausência atual) | INFERÊNCIA a partir de [03] |
| Gestão de assinaturas e documentos | Em discussão entre Atacado, Time de Canais e Time do GACD | FATO [01] |

### 3.3 Jornada do Gerente de Cash no Salesforce

- **FATO [01]:** A jornada do Gerente de Cash (Salesforce) é tratada pelo time de Cash dentro do Salesforce. A **proposta** é construída no pipeline do Salesforce com **valores de tarifa já negociados e previamente aprovados**, seguida de visita ao cliente e envio para aprovação.
- **FATO [CG]:** O Salesforce **não se integra diretamente** com FIRP ou GACD: toda integração passa por serviços no **ARO Atacado** (Azure RedHat OpenShift, namespace `atacado-core`, domínio de Plataformas Funcionais, vNet spoke em arquitetura Hub and Spoke). O callback do GACD também é recebido no ARO Atacado, e não no Salesforce.
- **PREMISSA (PRM-NEG-02):** O Salesforce é o **sistema de engajamento** do Gerente de Cash (hub comercial), não o sistema de registro do termo nem do convênio.

### 3.4 Canal Digital PJ (BGS + PDPJ)

- **FATO [02]:** O Canal Digital, composto por **BGS** e **PDPJ**, é onde o Cliente PJ Atacado visualiza pendências de assinatura e acessa serviços bancários.
  - **PDPJ** já possui integração com o GACD.
  - **BGS** ainda **não** possui integração com o GACD (roadmap de modernização do core).
  - **Roadmap:** unificação em um único canal digital integrado ao GACD.
- **FATO [01]:** A jornada do cliente (visualização e assinatura) é responsabilidade do **Canal Digital**, que já possui infraestrutura.
- **Decisão de escopo (PRM-NEG-04):** Nesta iniciativa o canal é **abstraído** sob o nome canônico **"Canal Digital PJ"** (sem distinguir BGS, PDPJ ou o futuro canal unificado), sob responsabilidade do Time de Canais / Experiência. O Atacado define apenas os pontos de contato (pendência de assinatura e comunicação de assinantes inválidos ao gerente).

### 3.5 Componentes corporativos relevantes (visão de negócio)

| Componente | Papel de negócio | Fonte |
|---|---|---|
| GACD | Serviço corporativo de Aceite Digital — gestão de assinaturas, termos e contratos, integrado à FIRP. **Candidato principal** a gerenciador de termos | FATO [02][04] |
| Open Cash Hub | Canal para ERPs com módulo próprio de termos e convênios — **candidato alternativo**; já possui processo de convênio | FATO [02] |
| FIRP | Firmas e Poderes — fonte dos representantes com poderes (assinantes) | FATO [02][CG] |
| IMPD | Impressão de Documentos On-line — formatação estrutural de PDFs (templates CSF Designer v21); API cloud na Azure | FATO [05][06] |
| GCC/Filenet | Repositório de conteúdo onde o GACD armazena a prévia do documento | FATO [04] |
| Databricks | Pipeline existente de cadastro de tarifas | FATO [01][02] |

---

## 4. Problema, impacto e objetivos

### 4.1 Declaração do problema (FATO [03])

A ausência de integração entre o Salesforce e um gerenciador de termos impede que o Gerente de Cash gere Termos de Adesão digitais e Convênios por produto durante a jornada comercial, **bloqueando a contratação** de produtos Cash, o **cadastro de tarifas** e gerando **fricção no processo de vendas**.

### 4.2 Impacto

| Dimensão | Impacto | Fonte |
|---|---|---|
| Usuários afetados | Gerentes de Cash e clientes corporativos sem contrato vigente | FATO [03] |
| Receita | Atraso na contratação → atraso no início da receita de tarifas | FATO [03] (atraso); INFERÊNCIA (receita) |
| Cliente | Cliente bloqueado até assinatura do termo | FATO [03] |
| Operação | Impossibilidade de cadastrar tarifas sem convênio por produto | FATO [03] |
| Risco / Conformidade | Processo manual e sem rastreabilidade (evidência de aceite frágil) | FATO [03]; INFERÊNCIA (evidência) |
| Custo operacional | Esforço manual de coleta, conferência de poderes e guarda de papel | INFERÊNCIA |

### 4.3 Objetivos e métricas de sucesso (FATO [03])

| ID | Objetivo estratégico | KPI (métrica) | Meta | Observação do analista |
|---|---|---|---|---|
| OE-01 | Digitalizar a geração de termos | KPI-01 — % de termos gerados via Salesforce | ≥ 90% em 6 meses | Denominador (total de termos, inclusive manuais) precisa ser definido — PRM-NEG-14 |
| OE-02 | Reduzir o tempo de ciclo de contratação | KPI-02 — Tempo médio entre negociação e assinatura | −50% vs. baseline | ⚠️ **Baseline não definido** — QA-NEG-06 |
| OE-03 | Aumentar a conversão de contratações | KPI-03 — % de termos gerados que são assinados | ≥ 80% | Requer definição de prazo de expiração do termo — QA-NEG-11 |
| OE-04 | Melhorar a visibilidade do Gerente de Cash | KPI-04 — % de Gerentes de Cash com status do termo em tempo real | 100% | Depende do callback GACD → ARO Atacado → Salesforce |
| OE-05 | Garantir compliance | KPI-05 — % de termos em conformidade regulatória | 100% | ⚠️ Critérios regulatórios não especificados — QA-NEG-07 |

**Métricas complementares sugeridas (INFERÊNCIA, não constam no PRD):**

- Tempo médio assinatura do termo → convênio ativo → tarifa cadastrada (ciclo completo até faturar), **separando o tempo de implantação e homologação**, que depende do cliente (ERP, layout, testes de remessa e retorno), do tempo interno do banco. O KPI-02 do PRD mede negociação → assinatura e não inclui esse trecho **[PREMISSA — padrão de mercado; ver seção 11]**.
- % de envios devolvidos por **assinantes inválidos** na revalidação do canal.
- % de clientes com termo pendente > N dias (aging de pendências).

---

## 5. Estratégia

### 5.1 Alinhamento estratégico

| Direcionador | Como a iniciativa se alinha | Base |
|---|---|---|
| Digitalização da jornada de adesão | Substitui a assinatura manual por aceite digital rastreável, originado no Salesforce | FATO [01][03] |
| Reuso de componentes corporativos | Consome **GACD** (aceite digital), **FIRP** (poderes), **IMPD** (documentos) e **Databricks** (tarifas), evitando soluções paralelas | FATO [02][04][05][06]; INFERÊNCIA (diretriz de reuso) |
| Unificação de canal | Aproveita o roadmap de canal único integrado ao GACD; abstrai BGS/PDPJ como "Canal Digital PJ" | FATO [02] |
| Salesforce como hub comercial | Mantém o Gerente de Cash em uma única ferramenta, com status em tempo real | FATO [01][03] |
| Plataforma de integração do Atacado | Toda integração Salesforce ↔ banco passa pelo ARO Atacado (`atacado-core`), criando um padrão reutilizável | FATO [CG] |

### 5.2 Drivers de negócio

| ID | Driver | Tipo |
|---|---|---|
| DRV-01 | Contratação de produtos Cash bloqueada por dependência de termo manual | Dor operacional / receita |
| DRV-02 | Falta de rastreabilidade e evidência de aceite | Risco / conformidade |
| DRV-03 | Tarifas negociadas não cadastradas por ausência de convênio | Receita |
| DRV-04 | Baixa visibilidade do gerente sobre o status da adesão | Experiência do colaborador |
| DRV-05 | Fragmentação de canais (BGS sem GACD) | Experiência do cliente / modernização |
| DRV-06 | Reuso de componentes corporativos (GACD, FIRP, GCC/Filenet, IMPD, Databricks) em vez de soluções paralelas | Eficiência / arquitetura corporativa |

### 5.3 Mapa estratégico (driver → objetivo → capacidade)

| Driver | Direção estratégica | Objetivos estratégicos (OE) e KPIs | Capacidades de negócio (seção 9) |
|---|---|---|---|
| DRV-01 | Adesão digital fim a fim a partir do Salesforce | OE-01, OE-02 (KPI-01, KPI-02) | CAP-01, CAP-02, CAP-03, CAP-05 |
| DRV-02 | Evidência de aceite íntegra e auditável | OE-05 (KPI-05) | CAP-05, CAP-08, CAP-12 |
| DRV-03 | Convênio ativo e tarifa cadastrada no menor prazo após o aceite (o ciclo inclui a homologação com o cliente) | OE-02 (KPI-02, ciclo) | CAP-06, CAP-07 |
| DRV-04 | Status em tempo real para o gerente | OE-04 (KPI-04) | CAP-01, CAP-05, CAP-09 |
| DRV-05 | Assinatura em canal único para o cliente | OE-03 (KPI-03) | CAP-04, CAP-13 (externa) |
| DRV-06 | Consumir capacidades corporativas, não reconstruí-las | OE-01..OE-05 (habilitador) | CAP-04, CAP-05, CAP-07, CAP-08 |

### 5.4 Princípios de negócio adotados

1. **Um termo por cliente, multiproduto** — o cliente assina uma vez; novos produtos não exigem novo termo (RN-01).
2. **Assinante certo, no momento certo** — poderes consultados na FIRP na geração e revalidados no ato da assinatura (RN-05, RN-06).
3. **O gerente não sai do Salesforce** — geração, acompanhamento e alertas ficam na ferramenta comercial.
4. **Não duplicar capacidades corporativas** — aceite digital, poderes, documentos e tarifas são consumidos, não reconstruídos.
5. **Canal é do cliente** — a experiência de assinatura pertence ao Time de Canais / Experiência; o Atacado não constrói canal próprio.

---

## 6. Stakeholders e times

### 6.1 Times principais

| Time | Papel na iniciativa | Interesse principal |
|---|---|---|
| **Time do Atacado Cash Payments** (Gerente de Cash, PO de Cash) | Dono do negócio e da jornada comercial no Salesforce; dono dos serviços de integração no ARO Atacado | Contratar e tarifar rápido, com visibilidade |
| **Time de Experiência** | Desenho de experiência das jornadas (gerente e cliente) — escopo exato a confirmar (⚠️ QA-NEG-15) | Usabilidade, consistência, conversão |
| **Time de Canais** | Dono do Canal Digital PJ (BGS + PDPJ, roadmap de unificação); exibição de pendências, assinatura e revalidação de assinantes | Integração canal ↔ GACD / FIRP; roadmap de unificação |
| **Time do GACD** | Dono do serviço corporativo de Aceite Digital (coordenação de assinatura, prévia, regras, callback) | Padrão de consumo, volumetria, onboarding de novo "Produto" consumidor |

### 6.2 Times e sistemas de apoio

| Time / Sistema | Papel |
|---|---|
| FIRP (Firmas e Poderes) | Fonte de representantes e poderes; consultada pelo Atacado e pelo canal |
| IMPD | Formatação do PDF do termo (candidato); templates CSF Designer mantidos pela área consumidora [05] |
| Tarifas / Databricks | Pipeline de cadastro de tarifas negociadas |
| Open Cash Hub | Referência/alternativa para termos e convênios [02] |
| Plataformas Funcionais / ARO Atacado | Hospedagem dos serviços `atacado-core` |
| Jurídico / Compliance (PREMISSA PRM-NEG-15) | Validação do conteúdo do Termo de Adesão e dos critérios de conformidade |
| Cliente PJ Atacado (representantes legais) | Assinantes do termo |

### 6.3 Matriz RACI preliminar (PREMISSA PRM-NEG-12)

> R = Responsável (executa), A = Aprovador/Dono, C = Consultado, I = Informado. Apenas um "A" por atividade.

| # | Atividade | Atacado Cash Payments | Experiência | Canais | GACD | Apoio |
|---|---|---|---|---|---|---|
| 1 | Definir e operar a jornada comercial (proposta, aprovação) no Salesforce | A/R | C | I | I | — |
| 2 | Desenhar a experiência do Gerente de Cash (geração/acompanhamento do termo) | A | R | I | C | — |
| 3 | Desenhar a experiência do cliente (pendência e assinatura) | C | R | A | C | — |
| 4 | Definir conteúdo e tipos do Termo de Adesão (Produtos / Produtos + Canal) | A/R | C | C | C | Jurídico/Compliance (C), IMPD (C) |
| 5 | Verificar contrato vigente do cliente | A/R | I | I | I | Sistema de registro de contratos (C) — ⚠️ QA-NEG-14 |
| 6 | Consultar assinantes com poderes (FIRP) na geração | A/R | I | I | C | FIRP (C) |
| 7 | Gerar o documento do termo (PDF) | A/R | C | I | C | IMPD (C) |
| 8 | Coordenar assinatura e armazenar prévia no GACD | R | I | C | A | GCC/Filenet (I) |
| 9 | Exibir pendência e coletar assinatura do cliente | I | C | A/R | C | — |
| 10 | Revalidar assinantes na FIRP no ato da assinatura | I | C | A/R | C | FIRP (C) |
| 11 | Comunicar o gerente sobre assinantes inválidos (API no ARO Atacado → Salesforce) | A/R | C | R | I | — |
| 12 | Notificar conclusão (callback) e atualizar status no Salesforce | A/R | I | I | R | — |
| 13 | Implantar produto e gerar Convênio (parâmetros com o cliente, convênio em teste, homologação, ativação) | A | I | I | I | ⚠️ R = Gerente de Cash **ou** backoffice, a definir — QA-CONV-12; Cliente PJ Atacado (C — homologação); sistema do produto (I) |
| 14 | Cadastrar tarifas negociadas | A | I | I | I | Tarifas/Databricks (R) |
| 15 | Definir baseline e acompanhar KPIs | A/R | C | C | C | — |
| 16 | Decidir o gerenciador de termos (GACD × Open Cash Hub) | A | I | C | C | Arquitetura (R) |

---

## 7. Jornada de negócio ponta a ponta

### 7.1 AS-IS (situação atual)

**FATO [01][03]** com complementos por **INFERÊNCIA** (ramos "NÃO" do diagrama original não estão visíveis).

```mermaid
flowchart TD
    A1(["Gerente de Cash monta proposta no Salesforce<br/>tarifas negociadas"]) --> A2["Visita ao cliente"]
    A2 --> A3["Envia proposta para aprovação"]
    A3 --> A4{"Cadastrar tarifas?"}
    A4 -- "Sim" --> A5{"Possui contrato ativo?"}
    A5 -- "Sim" --> A9["Cadastra tarifas via Databricks"]
    A5 -- "Não (inferência)" --> A6["Termo emitido e assinado manualmente<br/>fora do Salesforce, sem rastreabilidade"]
    A6 --> A7["E-mail para o cliente"]
    A7 --> A8["Gera convênio → Sistemas (BD)<br/>processo e dono não documentados<br/>(implantação e homologação não descritas)"]
    A8 --> A9
    A9 --> A10(["Produto contratado e tarifado"])
```

**Dores do AS-IS:** bloqueio da contratação; ausência de status para o gerente; sem trilha de auditoria; conferência de poderes manual; ordem convênio × tarifa inconsistente no próprio PRD (ver QA-CONV-07).

### 7.2 TO-BE (proposto)

Etapas marcadas com ⚠️ dependem de validação. O ramo de **assinantes inválidos** mostra a revalidação pelo canal e a comunicação ao gerente.

```mermaid
flowchart TD
    S(["Gerente de Cash cria proposta no Salesforce<br/>tarifas negociadas"]) --> P1{"Proposta aprovada?"}
    P1 -- "Não" --> P0["Ajustar proposta ou encerrar oportunidade"]
    P1 -- "Sim" --> C1{"Cliente possui contrato vigente?"}
    C1 -- "Sim" --> CV
    C1 -- "Não" --> F1["Consultar assinantes com poderes na FIRP<br/>via serviço no ARO Atacado"]
    F1 --> F2{"Assinantes encontrados?"}
    F2 -- "Não" --> F3["Gerente de Cash orienta regularização<br/>de poderes do cliente ⚠️ QA-NEG-03"]
    F3 --> F1
    F2 -- "Sim" --> T0{"Cliente já tem acesso<br/>ao Canal Digital PJ?"}
    T0 -- "Sim" --> T1["Gerar Termo de Adesão – Produtos"]
    T0 -- "Não" --> T2["Gerar Termo de Adesão – Produtos + Canal"]
    T1 --> G1["Enviar termo e assinantes ao GACD<br/>coordenar contrato → armazenar prévia → coordenar regra"]
    T2 --> G1
    G1 --> SF1["Salesforce: status 'Aguardando assinatura'"]
    SF1 --> N1["Cliente notificado da pendência<br/>⚠️ QA-NEG-05 quem envia o e-mail"]
    N1 --> CH1["Cliente acessa a pendência no<br/>Canal Digital PJ"]
    CH1 --> CH2{"Canal revalida assinantes na FIRP:<br/>ainda válidos?"}
    CH2 -- "Não" --> CH3["Canal comunica o Gerente de Cash<br/>via API no ARO Atacado → Salesforce<br/>⚠️ QA-NEG-04 contrato a combinar"]
    CH3 --> SF2["Salesforce: status 'Assinantes inválidos'<br/>Gerente trata e reenvia"]
    SF2 --> F1
    CH2 -- "Sim" --> CH4["Representantes assinam o Termo de Adesão"]
    CH4 --> CB["GACD envia callback de assinatura concluída<br/>ao endpoint no ARO Atacado"]
    CB --> SF3["Salesforce: status 'Assinado'"]
    SF3 --> CV["Abrir a implantação do produto<br/>(evento Termo assinado ou contrato vigente)<br/>⚠️ QA-CONV-01..13 onde, quem, gatilho"]
    CV --> IM["Implantar produto: definir parâmetros com o cliente<br/>→ criar Convênio em teste no sistema do produto<br/>Gerente de Cash ou backoffice ⚠️ QA-CONV-12"]
    IM --> HO{"Homologação com o cliente<br/>(remessa e retorno) aprovada?"}
    HO -- "Não" --> IM
    HO -- "Sim" --> AT["Ativar o Convênio<br/>Salesforce: status 'Convênio ativo'"]
    AT --> TF["Cadastrar tarifas negociadas via Databricks"]
    TF --> E(["Produto contratado e tarifado<br/>status final no Salesforce"])
```

### 7.3 Descrição das etapas TO-BE

| # | Etapa | Ator / Sistema | Natureza |
|---|---|---|---|
| 1 | Proposta com tarifas negociadas e aprovadas | Gerente de Cash / Salesforce | FATO [01] |
| 2 | Verificação de contrato vigente (dispensa termo) | Serviços de Integração do Atacado (ARO Atacado) (fonte ⚠️ QA-NEG-14) | FATO [01][02] (regra); INFERÊNCIA (automação) |
| 3 | Consulta de assinantes na FIRP | Serviços de Integração do Atacado (ARO Atacado) → FIRP | FATO [CG] |
| 4 | Determinação do tipo de termo (Produtos / Produtos + Canal) | Regra automática | FATO [02] (tipos); PREMISSA PRM-NEG-13 (automação) |
| 5 | Geração do documento (PDF) do Termo de Adesão | Serviços de Integração do Atacado (ARO Atacado) + Geração de Documento (IMPD candidato) | INFERÊNCIA; componente definido no desenho de solução |
| 6 | Envio ao GACD (3 chamadas) | Serviços de Integração do Atacado (ARO Atacado) → GACD | FATO [04][CG] |
| 7 | Notificação ao cliente | Canal ou Salesforce | ⚠️ QA-NEG-05 |
| 8 | Revalidação de assinantes e assinatura | Canal Digital PJ → FIRP / GACD | FATO [CG] |
| 9 | Comunicação de assinantes inválidos ao gerente | Canal → API no ARO Atacado → Salesforce | FATO [CG] (necessidade); ⚠️ QA-NEG-04 (contrato) |
| 10 | Callback de conclusão e status no Salesforce | GACD → ARO Atacado → Salesforce | FATO [04][CG] |
| 11 | Implantação do produto e geração do Convênio: definir parâmetros com o cliente → criar o convênio em modo teste no sistema do produto → homologar com o cliente → ativar o convênio | Gerente de Cash **ou** backoffice (⚠️ QA-CONV-12), no sistema do produto; Cliente PJ Atacado na homologação | FATO [01][02] (necessidade do convênio); **PREMISSA — padrão de mercado** (implantação assistida e homologação); ⚠️ seção 11 |
| 11a | Convênio ativo (por produto), refletido no Salesforce só com número e status | Sistema do produto → Serviços de Integração do Atacado → Salesforce | INFERÊNCIA; ⚠️ QA-CONV-10 |
| 12 | Cadastro de tarifas (depende do **convênio ativo**) | Databricks | FATO [01][02] |

### 7.4 Status de negócio do termo (visão do Gerente de Cash) — PREMISSA PRM-NEG-16

Estados canônicos do ciclo de vida do Termo de Adesão, alinhados ao `02-desenho-conceitual.md` (seção 3.3.6, PRM-CON-13):

| Status do termo | Significado |
|---|---|
| Solicitado | Termo solicitado pelo Gerente de Cash a partir da proposta aprovada (EVN-02) |
| Assinantes identificados | Assinantes com poderes obtidos na FIRP (EVN-03) |
| Gerado | Documento (PDF) do termo gerado (EVN-04) |
| Aguardando assinatura | Termo registrado no GACD e disponível no canal (EVN-05, EVN-06) |
| Assinantes inválidos | Canal detectou que os assinantes não são mais válidos; o gerente regulariza e reemite (volta para "Solicitado") |
| Assinado | Callback de conclusão recebido (EVN-08) |
| Falha na geração | Erro na FIRP, na geração do documento ou no GACD; nova tentativa volta para "Solicitado" |
| Encerrado (Recusado / Expirado / Cancelado) | ⚠️ QA-NEG-11 e QA-NEG-12 (não previstos nas fontes) |

Status da **jornada de adesão** exibidos ao gerente no Salesforce, mas que **não** são estados do Termo (ciclos de vida separados — PRI-12 do 02):

| Status da jornada | Significado |
|---|---|
| Não requerido | Cliente possui contrato vigente; não há termo |
| Em implantação | Pós-assinatura, por produto: implantação aberta, convênio em teste e homologação com o cliente em andamento (ciclo de vida do Convênio) **[PREMISSA — padrão de mercado]** |
| Convênio ativo | Homologação concluída e convênio ativado no sistema do produto (RN-17) |
| Tarifas cadastradas | Tarifas negociadas cadastradas no Databricks para o convênio ativo do produto |

> O GACD não documenta máquina de estados [04]; a lista acima é proposta de negócio a ser conciliada com o GACD.

---

## 8. Regras e requisitos de negócio

### 8.1 Regras de negócio

| ID | Regra | Tipo | Fonte |
|---|---|---|---|
| RN-01 | O Termo de Adesão é **único e multiproduto**: cobre todos os produtos Cash e resguarda o banco para utilização futura; não é por produto | FATO | [02] |
| RN-02 | O Termo de Adesão é exigido **apenas** de clientes **sem contrato vigente** | FATO | [01][02] |
| RN-03 | Há dois tipos de termo: **"Termo de Adesão – Produtos"** (cliente já possui acesso ao Canal Digital) e **"Termo de Adesão – Produtos + Canal"** (cliente novo, adere ao canal e aos produtos) | FATO | [02] |
| RN-04 | A proposta deve conter tarifas **negociadas e previamente aprovadas** antes da adesão | FATO | [01] |
| RN-05 | Os assinantes do termo são os representantes com poderes registrados na **FIRP** | FATO | [02][CG] |
| RN-06 | O Canal Digital PJ deve **revalidar os assinantes na FIRP** antes de permitir a assinatura | FATO | [CG] |
| RN-07 | Se os assinantes não forem mais válidos, o canal deve **comunicar o Gerente de Cash** no Salesforce (via serviço no ARO Atacado) | FATO (necessidade) / ⚠️ forma a combinar | [CG] |
| RN-08 | A conclusão da assinatura é notificada pelo GACD via **callback** a endpoint informado na coordenação do contrato | FATO | [04] |
| RN-09 | O Salesforce comunica-se apenas com serviços do **ARO Atacado**; estes integram FIRP e GACD | FATO (restrição) | [CG] |
| RN-10 | A geração do Convênio é **processo distinto** da geração/assinatura do termo | FATO | [02] |
| RN-11 | O Convênio é gerado **por produto** (cada produto Cash requer seu convênio) | FATO | [01][02] |
| RN-12 | O Convênio é **pré-requisito** para o cadastro das tarifas negociadas | FATO (texto) — contradição no diagrama | [01][02][03]; ⚠️ QA-CONV-07 |
| RN-13 | A implantação do produto (e a geração do Convênio) só pode ser **aberta** após o termo **assinado** ou com contrato vigente comprovado; a assinatura abre a implantação, não cria o convênio | INFERÊNCIA | [01] ("após a assinatura do termo"); ⚠️ QA-CONV-03 |
| RN-14 | O cadastro de tarifas é executado pelo pipeline **Databricks** existente | FATO | [01][02] |
| RN-15 | A prévia do documento é armazenada no **GCC/Filenet** via GACD | FATO | [04] |
| RN-16 | Um cliente não pode ter mais de um Termo de Adesão pendente simultaneamente | PREMISSA PRM-NEG-05 | — |
| RN-17 | O Convênio só fica **ativo** após a **homologação** com o cliente; antes disso fica em modo teste | **PREMISSA — padrão de mercado** (PRM-NEG-18) | Não vem das fontes; ⚠️ QA-CONV-13 |

### 8.2 Requisitos funcionais de negócio

| ID | Requisito | Rastreio |
|---|---|---|
| RFN-01 | Permitir ao Gerente de Cash solicitar a geração do Termo de Adesão a partir da oportunidade/proposta aprovada no Salesforce | RN-04, OE-01 |
| RFN-02 | Identificar automaticamente se o cliente possui contrato vigente e dispensar o termo | RN-02 |
| RFN-03 | Determinar o tipo de termo (Produtos / Produtos + Canal) conforme acesso do cliente ao Canal Digital | RN-03 |
| RFN-04 | Obter os assinantes com poderes na FIRP e apresentá-los ao gerente antes do envio | RN-05 |
| RFN-05 | Registrar o termo e os assinantes no gerenciador de termos (GACD) | RN-08, PRM-NEG-01 |
| RFN-06 | Disponibilizar o termo como pendência de assinatura no Canal Digital PJ | RN-06 |
| RFN-07 | Informar o gerente, no Salesforce, quando os assinantes forem invalidados na revalidação | RN-07 |
| RFN-08 | Atualizar o status do termo no Salesforce a cada evento de negócio (ver 7.4) | OE-04 |
| RFN-09 | Abrir a **implantação** de cada produto contratado após a assinatura (ou contrato vigente), como pendência para o executor (Gerente de Cash ou backoffice — QA-CONV-12), e refletir no Salesforce o status "Em implantação" e, depois da homologação, "Convênio ativo" com o número do convênio | RN-10, RN-11, RN-13, RN-17 |
| RFN-10 | Acionar o cadastro das tarifas negociadas após a **ativação** do convênio do produto | RN-12, RN-14, RN-17 |
| RFN-11 | Permitir ao gerente consultar/baixar o termo assinado (evidência) | INFERÊNCIA; ⚠️ QA-NEG-17 |
| RFN-12 | Disponibilizar dados para os KPIs do PRD (geração, assinatura, tempos de ciclo) | OE-01..05 (KPI-01..05) |

### 8.3 Requisitos não funcionais de negócio

| ID | Requisito | Fonte |
|---|---|---|
| RNFN-01 | **Rastreabilidade:** cada termo e convênio deve ter trilha completa (quem gerou, quando, assinantes, eventos, versão do documento) | FATO [03] |
| RNFN-02 | **Conformidade regulatória:** 100% dos termos em conformidade; critérios a definir com Jurídico/Compliance | FATO [03]; ⚠️ QA-NEG-07 |
| RNFN-03 | **Status em tempo real** para 100% dos gerentes (latência de negócio alvo: minutos, não dias — PREMISSA PRM-NEG-16) | FATO [03] |
| RNFN-04 | **Evidência de aceite / não repúdio:** documento assinado e metadados de assinatura guardados em repositório corporativo | INFERÊNCIA de [03][04] |
| RNFN-05 | **Proteção de dados (LGPD):** dados de representantes (FIRP) tratados com finalidade e mínimo necessário | INFERÊNCIA (dados pessoais) |
| RNFN-06 | **Retenção:** prazo de guarda do termo assinado compatível com a política do banco | ⚠️ QA-NEG-17 |
| RNFN-07 | **Mensurabilidade:** eventos da jornada registrados de forma a permitir o cálculo de baseline e KPIs | OE-02 (KPI-02); QA-NEG-06 |

---

## 9. Capacidades de negócio envolvidas

**Escala de maturidade (PREMISSA PRM-NEG-11):** 1 = Inexistente · 2 = Manual / ad hoc · 3 = Parcial (existe, mas não atende esta jornada) · 4 = Estabelecida e reutilizável · 5 = Otimizada.
Provedor e maturidade são estimativas do analista a partir das fontes; o desenho em camadas está no `02-desenho-conceitual.md`.

| Nível 1 | Nível 2 | Provedor atual | Provedor alvo | Mat. atual → alvo |
|---|---|---|---|---|
| **CAP-01 Gestão de Relacionamento Comercial** | CAP-01.1 Gestão de Propostas e Pipeline | Salesforce | Salesforce | 4 → 4 |
| | CAP-01.2 Negociação e Aprovação de Tarifas | Salesforce | Salesforce | 4 → 4 |
| **CAP-02 Gestão de Adesão a Produtos Cash** | CAP-02.1 Verificação de Contrato Vigente | Manual; fonte indefinida (⚠️ QA-NEG-14) | Serviços de Integração do Atacado (ARO Atacado) | 2 → 4 |
| | CAP-02.2 Determinação do Tipo de Termo | Manual | Regra automatizada (Serviços de Integração do Atacado) | 2 → 4 |
| | CAP-02.3 Orquestração da Jornada de Adesão | Manual | Serviços de Integração do Atacado (ARO Atacado) | 1 → 4 |
| **CAP-03 Gestão do Termo de Adesão** | CAP-03.1 Composição do Termo (dados e produtos) | Manual / papel | Serviços de Integração do Atacado + Geração de Documento | 2 → 4 |
| | CAP-03.2 Controle de Ciclo de Vida e Status do Termo | Inexistente | GACD + espelho de status no Salesforce | 1 → 4 |
| | CAP-03.3 Gestão de Modelos do Termo | Inexistente para Cash | IMPD (CSF Designer) — candidato | 1 → 3 |
| **CAP-04 Gestão de Representantes e Poderes** | CAP-04.1 Consulta de Assinantes e Poderes | FIRP (corporativo) | FIRP via Serviços de Integração do Atacado | 4 → 4 |
| | CAP-04.2 Revalidação de Assinantes na Assinatura | PDPJ (parcial) | Canal Digital PJ | 3 → 4 |
| **CAP-05 Gestão de Assinatura Digital** | CAP-05.1 Coordenação de Contrato e Protocolo (com CAP-05.2 Armazenamento de Prévia e CAP-05.3 Coordenação de Regras) | GACD (usado pelo PDPJ) | GACD | 4 → 4 |
| | CAP-05.4 Coleta de Assinatura do Cliente | PDPJ (BGS não integra) | Canal Digital PJ (unificado) | 3 → 4 |
| | CAP-05.5 Notificação de Conclusão de Assinatura (callback) | GACD callback (contrato não documentado) | GACD → callback nos Serviços de Integração do Atacado | 3 → 4 |
| **CAP-06 Gestão de Convênios** | CAP-06.1 Geração de Convênio por Produto (inclui implantação, homologação e ativação) | ⚠️ Indefinido (Open Cash Hub possui processo próprio) | ⚠️ A definir — QA-CONV-01; executada por pessoas (Gerente de Cash ou backoffice — QA-CONV-12) no sistema do produto | 2 → 4 |
| | CAP-06.2 Registro e Consulta de Convênios | ⚠️ Indefinido ("Sistemas (BD)" [01]) | ⚠️ A definir | 2 → 4 |
| **CAP-07 Gestão de Tarifas** | CAP-07.1 Cadastro de Tarifas Negociadas | Databricks | Databricks (acionado após o convênio ativo) | 4 → 4 |
| **CAP-08 Gestão Documental** | CAP-08.1 Renderização de Documento PDF (base64) | IMPD (outros produtos) | IMPD API cloud — candidato | 3 → 4 |
| | CAP-08.2 Armazenamento e Retenção de Documentos | GCC/Filenet (via GACD) | GCC/Filenet (via GACD) | 4 → 4 |
| **CAP-09 Notificação e Acompanhamento de Status** (habilitadora) | CAP-09.1 Atualização de Status no Salesforce (acompanhamento da jornada de adesão pelo gerente) | Inexistente | Salesforce (alimentado pelos Serviços de Integração do Atacado) | 1 → 4 |
| | CAP-09.3 Notificação ao Cliente (pendência de assinatura) | Indefinido | ⚠️ QA-NEG-05 | 2 → 4 |
| | CAP-09.4 Indicadores da Jornada | Inexistente | Salesforce / Databricks | 1 → 3 |
| **CAP-12 Rastreabilidade, Auditoria e Conformidade** | CAP-12.1 Trilha de Auditoria Ponta a Ponta | Inexistente | Serviços de Integração do Atacado + GACD | 1 → 4 |
| | CAP-12.2 Evidência de Aceite e Conformidade Regulatória | Papel | GACD + GCC/Filenet | 2 → 4 |
| **CAP-13 Gestão do Canal Digital PJ** (externa — Time de Canais / Experiência) | CAP-13.1 Gestão de Pendências de Assinatura | PDPJ (parcial); BGS (inexistente) | Canal Digital PJ (unificado) | 3 → 4 |
| | CAP-13.2 Adesão ao Canal Digital | Canais (processo atual não documentado) | Canais, disparado pelo Termo de Adesão – Produtos + Canal | 2 → 4 |

> Capacidades CAP-09 (Notificação e Acompanhamento de Status), CAP-10 (Integração e Exposição de APIs) e CAP-11 (Segurança e Identidade de Integração) são capacidades habilitadoras detalhadas no 02-desenho-conceitual.md. Neste quadro, CAP-09 aparece apenas com as L2 de interesse direto do negócio. CAP-13 é capacidade **externa**, provida pelo Canal Digital PJ (BGS/PDPJ) sob responsabilidade do Time de Canais, fora do escopo de implementação do Atacado.

**Leitura de lacunas (INFERÊNCIA):** as maiores lacunas estão em **CAP-09.1**, **CAP-02.3**, **CAP-03**, **CAP-06** e **CAP-12** — são as capacidades que a iniciativa efetivamente cria ou orquestra. As demais (CAP-04, CAP-05.1, CAP-07, CAP-08.2) já existem como capacidades corporativas e devem ser **consumidas**.

---

## 10. Oportunidades

| ID | Oportunidade | Valor esperado | Dependência / risco |
|---|---|---|---|
| OP-01 | **Reuso do GACD para outros produtos do Atacado** (crédito, câmbio, trade) que exigem termos/contratos | Escala do padrão de aceite digital; menor custo marginal | Onboarding do Atacado como "Produto" consumidor do GACD |
| OP-02 | **Padrão de integração Salesforce → ARO Atacado reutilizável** (FIRP, GACD, callback, comunicação canal → gerente) | Acelera novas jornadas do Salesforce que dependem de componentes do banco | Governança do `atacado-core`; contratos de API |
| OP-03 | **Dados para analytics de conversão** (funil proposta → termo → assinatura → convênio → tarifa) | Gestão comercial baseada em dados; mede OE-01..03 | Eventos registrados (RNFN-07); Databricks |
| OP-04 | **Eliminação de papel** e da guarda física de termos | Redução de custo e risco operacional | Aceitação jurídica do aceite digital (QA-NEG-07) |
| OP-05 | **Redução do ciclo até a primeira receita de tarifa** | Antecipação de receita; meta de −50% no ciclo | Abertura automática da implantação e checklist de implantação no Salesforce; o tempo de homologação depende do cliente (seção 11) |
| OP-06 | **Convergência com o Open Cash Hub** (reuso do processo de convênio já existente) | Evita construir nova capacidade de convênio | Aderência do modelo do Open Cash Hub a clientes fora do canal ERP (QA-CONV-09) |
| OP-07 | **Antecipar a unificação de canal** usando a jornada de adesão como caso de uso do canal único integrado ao GACD | Reforça o roadmap de Canais; experiência única | Roadmap BGS (QA-NEG-02) |
| OP-08 | **Revalidação proativa de poderes** (alerta ao gerente quando poderes mudam na FIRP antes do cliente assinar) | Menos devoluções por assinantes inválidos; melhor conversão | Capacidade da FIRP de notificar mudanças (não documentada) |
| OP-09 | **Termo como ativo reutilizável**: um único termo habilita contratação futura de novos produtos sem nova assinatura (RN-01) | Cross-sell mais rápido | Clareza sobre convênio para produtos adicionais (QA-CONV-08) |

---

## 11. ⚠️ Questões em aberto — Convênio

> **Contexto:** as fontes afirmam apenas que o Convênio é **distinto** do termo, **por produto**, **pré-requisito das tarifas**, gerado **após a assinatura** e que o **Open Cash Hub já possui esse processo** [01][02][03]. O diagrama do PRD mostra "Gera convênio → Sistemas (BD)" **depois** do cadastro de tarifas [01]. **Não se sabe onde é gerado, quem gera nem qual o gatilho** [CG].
> Todas as questões abaixo devem ser validadas pelo **Time do Atacado Cash Payments** (dono do negócio), com apoio dos times indicados.
> **Correspondência com o `02-desenho-conceitual.md` (seção 8.1):** QA-CONV-01 ↔ QA-CON-02; QA-CONV-02 e QA-CONV-03 ↔ QA-CON-03; QA-CONV-04 e QA-CONV-08 ↔ QA-CON-04; QA-CONV-07 ↔ QA-CON-05; QA-CONV-12 ↔ QA-CON-24; QA-CONV-13 ↔ QA-CON-25.

> **Padrão de mercado (PREMISSA — não vem das fontes; validar com o Atacado Cash Payments):** no atacado, entre a assinatura e o convênio ativo existe uma etapa de **implantação e homologação** feita por pessoas. Muitos parâmetros dependem do cliente, que integra o próprio ERP ao banco: layout (**CNAB** 240/400 ou API), canal de envio dos arquivos (internet banking, **VAN**, SFTP, API), contas, carteira. O convênio costuma nascer em **modo teste**; o cliente envia arquivos de remessa, o banco valida e devolve o retorno, e só depois da homologação o convênio é **ativado**. O convênio fica registrado no **sistema do produto**. Em produtos e clientes simples (cobrança via API, Pix cobrança, varejo e middle market) o convênio pode nascer automaticamente na contratação; no atacado, com integração via ERP, a maioria dos bancos usa implantação assistida. Consequência (INFERÊNCIA): **a assinatura do termo abre a implantação; não gera o convênio automaticamente**.
>
> **Como fica nesta iniciativa:** o Atacado orquestra a jornada, representado pelo Gerente de Cash, e não há área de implantação separada prevista. A implantação (parâmetros, criação do convênio, homologação e ativação) fica com o **Gerente de Cash ou com o backoffice** (QA-CONV-12); se existir hoje uma área de implantação de Cash, ela é a candidata natural (QA-CONV-13). O Salesforce mostra só o número e o status do convênio.

| ID | Questão | Hipótese / inferência recomendada | Time a validar |
|---|---|---|---|
| ⚠️ **QA-CONV-01** | **Onde o Convênio é gerado?** Salesforce? Open Cash Hub? Sistema de cadastro de produtos / legado de Cash? GACD? (ver QA-CON-02 no 02) | **Hipótese:** no **sistema de registro de convênios de Cash já existente** (o "Sistemas (BD)" do diagrama [01]), acionado por serviço no ARO Atacado. **Não** no GACD (que gere assinaturas, não parametrização de produto) e **não** no Salesforce (sistema de engajamento — PRM-NEG-02), que apenas espelha o número/status. Open Cash Hub como alternativa se o seu módulo for reutilizável (QA-CONV-09). | Atacado Cash Payments (A); GACD (C — confirmar que não é escopo GACD) |
| ⚠️ **QA-CONV-02** | **Quem gera o Convênio?** Gerente de Cash, processo automático pós-callback ou backoffice? (ver QA-CON-03 no 02) | **Hipótese (revista na v0.5):** **implantação assistida**, executada pelo **Gerente de Cash ou pelo backoffice** (QA-CONV-12). O evento "Termo assinado" (ou "contrato vigente confirmado") **abre a implantação** — uma pendência para o executor, visível no Salesforce — e não cria o convênio. O gerente acompanha os status "Em implantação" e "Convênio ativo" no Salesforce **[PREMISSA — padrão de mercado]**. | Atacado Cash Payments |
| ⚠️ **QA-CONV-03** | **Qual é o gatilho?** Callback de assinatura concluída? Aprovação da proposta? Ação manual? (ver QA-CON-03 no 02) | **Hipótese:** o gatilho **abre a implantação**: (a) callback de "Termo assinado" para clientes novos; (b) confirmação de contrato vigente + proposta aprovada para clientes existentes. A **ativação** do convênio depende da homologação com o cliente (RN-17), e não do gatilho. | Atacado Cash Payments; GACD (C — conteúdo do callback) |
| ⚠️ **QA-CONV-04** | **Relação termo × convênio (cardinalidade)** (ver QA-CON-04 no 02) | **Inferência:** **1 Termo de Adesão (multiproduto) → N Convênios**, um por produto contratado na proposta (RN-01, RN-11). Produtos contratados depois, sob o mesmo termo, geram novos convênios sem novo termo. | Atacado Cash Payments |
| ⚠️ **QA-CONV-05** | **O Convênio exige assinatura própria ou é coberto pelo termo?** | **Hipótese:** **coberto pelo termo** — o termo "resguarda o banco para qualquer utilização futura dos serviços" [02]; portanto o convênio não passa pelo GACD. Se exigir assinatura, a jornada precisa de nova rodada no GACD por produto (impacto relevante em OE-02/OE-03). | Atacado Cash Payments; GACD (C) |
| ⚠️ **QA-CONV-06** | **O Convênio é documento assinado ou apenas registro cadastral?** | **Hipótese:** **registro cadastral/parametrização** (produto, conta, condições, identificador de convênio) — o diagrama aponta "Sistemas (BD)" [01], não documento. | Atacado Cash Payments |
| ⚠️ **QA-CONV-07** | **Contradição de ordem convênio × tarifas** — texto: convênio é pré-requisito das tarifas; diagrama: tarifas antes do convênio [01] (ver QA-CON-05 no 02) | **Recomendação:** adotar o **texto** (convênio **antes** das tarifas), por aparecer em três trechos [01][02][03] e ser coerente com a dependência "impossibilidade de cadastrar tarifas sem convênio" [03]. Diagrama tratado como desatualizado/cortado (PRM-NEG-07). | Atacado Cash Payments |
| ⚠️ **QA-CONV-08** | **Cliente com contrato vigente que contrata produto novo precisa de convênio?** O diagrama leva direto a "Cadastra tarifas" [01] (ver QA-CON-04 no 02) | **Hipótese:** sim — o convênio é por produto; se o produto ainda não tem convênio, ele deve ser gerado antes das tarifas (fluxo TO-BE 7.2). | Atacado Cash Payments |
| ⚠️ **QA-CONV-09** | **O processo de convênio do Open Cash Hub pode ser reutilizado** para clientes que não usam ERP? | **Hipótese:** avaliar reuso como capacidade de convênio; se o módulo for acoplado ao canal ERP, usar apenas como referência de modelo de dados. | Atacado Cash Payments (C: time do Open Cash Hub) |
| ⚠️ **QA-CONV-10** | **Quais dados o Convênio exige e de onde vêm?** (produto, conta, agência, condições, tarifas, identificador do termo) E o identificador do convênio é chave para o Databricks? | **Hipótese:** dados vêm da proposta aprovada no Salesforce + identificador do termo assinado; o número do convênio retorna ao Salesforce e é insumo do cadastro de tarifas. | Atacado Cash Payments |
| ⚠️ **QA-CONV-11** | **Tratamento de falha na geração do convênio** (retentativa, fila de exceção, responsável), **incluindo falha ou atraso na homologação** | **Hipótese:** falhas técnicas de integração com retentativa automática; falha ou atraso na homologação (layout, arquivos de remessa rejeitados, cliente sem retorno) tratados pelo executor da implantação (QA-CONV-12), com prazo de acompanhamento e status "Em implantação" / "Convênio pendente" visível ao gerente. | Atacado Cash Payments |
| ⚠️ **QA-CONV-12** | **Quem executa a implantação do produto (Gerente de Cash ou backoffice)?** Parametrização com o cliente, criação do convênio em teste, homologação e ativação (ver QA-CON-24 no 02) | **Hipótese:** Gerente de Cash **ou** backoffice de Cash — **a definir**. Implantação técnica pelo Gerente de Cash foge do papel comercial no padrão de mercado (risco RSK-18 do 04); o backoffice é o executor mais aderente, com o Gerente acompanhando pelo Salesforce. | Atacado Cash Payments |
| ⚠️ **QA-CONV-13** | **Quais produtos Cash exigem homologação e existe hoje uma área de implantação de Cash?** (ver QA-CON-25 no 02) | **Hipótese:** produtos com integração via ERP (cobrança e pagamentos por arquivo CNAB) exigem homologação; produtos simples podem nascer ativos. Se existir uma área de implantação de Cash, ela é a candidata natural a executora, no lugar do Gerente de Cash ou do backoffice. | Atacado Cash Payments |

**Risco associado (INFERÊNCIA):** se a implantação técnica (layout CNAB, canal de transmissão, homologação) ficar com o **Gerente de Cash**, ela foge do papel comercial previsto no padrão de mercado; o risco é falta de capacidade ou de conhecimento técnico e atraso no ciclo até o faturamento. Mitigações possíveis: backoffice como executor, checklist de implantação no Salesforce e apoio do time de produto. Registrado como **RSK-18** no `04-desenho-arquitetura-solucao.md`.

---

## 12. Demais questões em aberto de negócio

| ID | Questão | Hipótese / encaminhamento | Time responsável |
|---|---|---|---|
| QA-NEG-01 | Gerenciador de termos **GACD × Open Cash Hub** não formalmente decidido [02] | Adotar GACD (PRM-NEG-01); formalizar em decisão de arquitetura | Atacado Cash Payments (com GACD) |
| QA-NEG-02 | **Clientes BGS:** como assinam enquanto o BGS não integra o GACD? | Transitório via PDPJ ou canal unificado; sem fluxo manual paralelo | Canais |
| QA-NEG-03 | **Regras de assinatura** (isolada/conjunta, quantidade mínima, alçada por produto/valor) e tratamento quando a FIRP não retorna assinantes | Seguir regras de poderes da FIRP; gerente orienta regularização | Atacado Cash Payments (com GACD) |
| QA-NEG-04 | **Assinantes inválidos na revalidação:** o que o canal faz (bloqueia, informa cliente) e como comunica o gerente (API no ARO Atacado → Salesforce — contrato a combinar) | Canal bloqueia a assinatura e chama API do Atacado; gerente reinicia envio | Canais |
| QA-NEG-05 | **Notificação ao cliente (e-mail):** quem envia — Canal, GACD ou Salesforce? [01] | Canal (dono da experiência do cliente) | Canais / Experiência |
| QA-NEG-06 | **Baseline** do tempo de negociação → assinatura não definido [03] | Medir manualmente amostra atual ou os 2 primeiros meses | Atacado Cash Payments |
| QA-NEG-07 | **Critérios de conformidade regulatória** do termo (o que é "100% em conformidade") | Validar com Jurídico/Compliance | Atacado Cash Payments |
| QA-NEG-08 | **Lista de produtos Cash / Payments** no escopo não informada | Obter catálogo oficial de produtos Cash | Atacado Cash Payments |
| QA-NEG-09 | **Personas** vazias no PRD [03] | Construir personas do Gerente de Cash e do representante do cliente | Experiência |
| QA-NEG-10 | **Conteúdo do Termo de Adesão:** texto jurídico, variáveis, se lista os produtos contratados, quem mantém o modelo | Modelo mantido pelo Atacado (IMPD exige que a área mantenha templates [05]) | Atacado Cash Payments |
| QA-NEG-11 | **Ciclo de vida do termo:** estados, prazo de validade/expiração, reenvio, lembretes (GACD não documenta máquina de estados [04]) | Adotar estados de 7.4 e conciliar com o GACD | GACD |
| QA-NEG-12 | **Recusa ou cancelamento** do termo (pelo cliente ou por alteração da proposta) | Cancelamento no GACD + status no Salesforce | Atacado Cash Payments |
| QA-NEG-13 | **Termo Produtos + Canal:** após assinatura, quem efetiva a adesão ao canal (cadastro de usuários master, acessos)? | Canais, acionado pelo evento de termo assinado | Canais |
| QA-NEG-14 | **Fonte de verdade de "contrato vigente"** — qual sistema/critério? | Sistema de registro de contratos de Cash; a confirmar | Atacado Cash Payments |
| QA-NEG-15 | **Escopo do Time de Experiência** (Salesforce, canal ou ambos) | Ambos, na camada de experiência (PRM-NEG-12) | Experiência |
| QA-NEG-16 | **Unidade do termo:** por CNPJ, por raiz de CNPJ ou por grupo econômico? | Por CNPJ (PRM-NEG-05) | Atacado Cash Payments |
| QA-NEG-17 | **Guarda e acesso ao termo assinado:** prazo de retenção e se o gerente consulta o PDF assinado no Salesforce | Retenção no GCC/Filenet; link/consulta sob demanda | GACD |
| QA-NEG-18 | **Prévia pelo gerente:** o gerente revisa o termo antes do envio ao GACD? | Sim, com confirmação explícita | Experiência |
| QA-NEG-19 | **Onboarding do Atacado como "Produto" consumidor do GACD** (pré-requisitos, volumetria, usuário sistêmico [04]) | Iniciar trilha de onboarding com o GACD | GACD |

---

## 13. Premissas assumidas

| ID | Premissa | Impacto se falsa |
|---|---|---|
| PRM-NEG-01 | O **GACD** é o gerenciador de termos adotado (candidato principal [02]); o Open Cash Hub é alternativa/referência, sobretudo para convênio | Redesenho da integração de assinatura |
| PRM-NEG-02 | O **Salesforce** é sistema de engajamento (hub comercial); não é sistema de registro de termo nem de convênio | Mudança de ownership de dados |
| PRM-NEG-03 | Toda integração Salesforce ↔ banco (FIRP, GACD, callback) passa por serviços no **ARO Atacado** (`atacado-core`) [CG] | — (fato do CG, mantido como premissa de escopo) |
| PRM-NEG-04 | O **Canal Digital PJ** fica abstraído e é responsabilidade do Time de Canais / Experiência | Atacado precisaria construir experiência de assinatura |
| PRM-NEG-05 | Existe **um termo vigente por Cliente PJ Atacado (CNPJ)** e no máximo um termo pendente por vez | Regras de deduplicação e escopo de grupo econômico |
| PRM-NEG-06 | Cliente com **contrato vigente** dispensa o termo e segue direto para convênio/tarifas [01][02] | — |
| PRM-NEG-07 | O **convênio precede o cadastro de tarifas** (texto do PRD prevalece sobre o diagrama parcial) | Reordenação da jornada e das dependências |
| PRM-NEG-08 | A proposta chega à adesão com **tarifas negociadas e aprovadas** [01] | Necessidade de etapa de aprovação dentro da jornada |
| PRM-NEG-09 | Assinantes são obtidos na FIRP pelo Atacado na geração e **revalidados pelo canal** no ato da assinatura [CG] | Risco de assinatura por representante sem poderes |
| PRM-NEG-10 | A geração do PDF do termo é uma capacidade de documentos consumida (IMPD candidato); a escolha do componente é feita no desenho de solução | — |
| PRM-NEG-11 | Maturidades e provedores de capacidades (seção 9) são **estimativas do analista** | Reavaliação de lacunas e esforço |
| PRM-NEG-12 | A **RACI** (6.3) é preliminar; Experiência atua na camada de experiência das duas jornadas | Revisão de responsabilidades |
| PRM-NEG-13 | O **tipo de termo** é determinado automaticamente pelo acesso atual do cliente ao Canal Digital | Necessidade de seleção manual pelo gerente |
| PRM-NEG-14 | O KPI "% de termos gerados via Salesforce" considera no denominador **todos** os termos (digitais e manuais) do período | Meta de 90% pode ficar distorcida |
| PRM-NEG-15 | **Jurídico/Compliance** valida o conteúdo do termo e os critérios de conformidade | OE-05 sem critério objetivo |
| PRM-NEG-16 | Status de negócio do termo conforme 7.4 (estados canônicos alinhados a PRM-CON-13 do 02), com atualização em minutos após cada evento | Ajuste do modelo de status com o GACD |
| PRM-NEG-17 | O **Convênio** é **registro cadastral** no sistema do produto, coberto pelo termo (sem assinatura própria), segue **1 termo → N convênios** e é criado na **implantação** aberta pelo termo assinado (não automaticamente) — hipóteses de QA-CONV-02/04/05/06 | Nova rodada de assinatura por produto |
| PRM-NEG-18 | **Padrão de mercado:** entre a assinatura e o convênio ativo há implantação e homologação com o cliente, executadas por pessoas (Gerente de Cash ou backoffice — QA-CONV-12); o convênio nasce em teste e só é ativado após a homologação (RN-17) | Se todos os produtos puderem nascer ativos com parâmetros padrão, a implantação vira automática e o ciclo encurta |

---

## 14. Glossário

| Termo | Definição |
|---|---|
| **Salesforce (Salesforce Financial Services Cloud)** | CRM onde o Gerente de Cash conduz a jornada comercial (proposta, aprovação, acompanhamento) |
| **Gerente de Cash** | Ator do Time do Atacado Cash Payments responsável pela negociação e adesão de produtos Cash |
| **Cliente PJ Atacado** | Cliente corporativo do segmento Atacado que adere aos produtos e assina o termo por meio de seus representantes |
| **Termo de Adesão** | Termo de aceite digital **único e multiproduto** para todos os produtos Cash; tipos "Termo de Adesão – Produtos" e "Termo de Adesão – Produtos + Canal"; exigido apenas de quem não tem contrato vigente [01][02] |
| **Convênio** | Registro **por produto** no sistema do produto, criado na implantação aberta após a assinatura do termo; nasce em teste e fica **ativo** após a homologação; pré-requisito para o cadastro de tarifas; sistema e executor **indefinidos** (seção 11) |
| **Implantação (de produto Cash)** | Etapa entre a assinatura e o convênio ativo: definir parâmetros com o cliente, criar o convênio em teste, homologar e ativar. Executor: Gerente de Cash ou backoffice (QA-CONV-12) **[PREMISSA — padrão de mercado]** |
| **Homologação** | Testes com o cliente (arquivos de remessa e retorno ou chamadas de API) até o convênio funcionar; condição para ativar o convênio (RN-17) |
| **CNAB** | Padrão de layout de arquivos de remessa e retorno entre empresas e bancos (240 ou 400 posições) |
| **VAN** | *Value Added Network* — rede privada para transmissão de arquivos entre o cliente e o banco |
| **Contrato vigente** | Contrato já firmado entre o cliente e o banco que dispensa o Termo de Adesão (critério exato em QA-NEG-14) |
| **ARO Atacado** | Azure RedHat OpenShift do Atacado; namespace `atacado-core`; domínio de Plataformas Funcionais; vNet spoke em Hub and Spoke. Hospeda os serviços que integram o Salesforce aos componentes do banco |
| **FIRP** | Firmas e Poderes — fonte dos representantes com poderes (assinantes) |
| **GACD** | Serviço corporativo de Aceite Digital (gestão de assinaturas, termos e contratos), integrado à FIRP e exposto via Axway API Gateway |
| **GCC/Filenet** | Repositório de conteúdo onde o GACD armazena a prévia (PDF) do documento |
| **IMPD** | Impressão de Documentos On-line — serviço estrutural de formatação de PDFs (templates CSF Designer v21); API cloud `impd-srv-doc-generator` na Azure; legado mainframe |
| **Canal Digital PJ** | Canal do cliente composto hoje por BGS e PDPJ (PDPJ integra GACD; BGS não), com roadmap de unificação |
| **Canal Digital do Cliente** | Sinônimo do Canal Digital PJ, aceito só na primeira menção de cada documento ("Canal Digital do Cliente (Canal Digital PJ)"). O nome canônico nos documentos é **Canal Digital PJ** |
| **Open Cash Hub** | Canal para ERPs com módulo próprio de termos e convênios — alternativa ao GACD |
| **Databricks** | Plataforma analítica/ETL onde roda o pipeline existente de cadastro de tarifas |
| **Callback** | Notificação enviada pelo GACD ao endpoint informado na coordenação do contrato quando a assinatura é concluída; recebida no ARO Atacado |
| **Prévia** | Versão do documento (PDF base64) enviada ao GACD e armazenada no GCC/Filenet antes da assinatura |
| **Axway API Gateway** | Gateway corporativo pelo qual GACD e FIRP expõem seus endpoints |
| **Token LEAP** | Hipótese de mecanismo de autenticação padrão do banco (não documentado nas fontes) |
| **Proposta** | Registro no Salesforce com produtos e tarifas negociadas, previamente aprovadas |
| **Assinantes inválidos** | Situação em que os representantes enviados no termo deixaram de ter poderes na FIRP no momento da assinatura |
