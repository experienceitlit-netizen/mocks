# 03 — Domínios, Bounded Contexts e Context Mapping: Termo de Adesão Multiproduto (Cash Management / Payments)

> Tradução do desenho conceitual (`02-desenho-conceitual.md`) para **Domain-Driven Design**, estratégico (subdomínios, bounded contexts, context map, times) e tático indicativo (agregados, value objects, comandos, eventos, invariantes).
> Os nomes de camadas (CAM-x), capacidades (CAP-xx), processos (PN-xx), eventos de negócio (EVN-xx), objetos (OBJ-xx), blocos de aplicação (APP-xx) e princípios (PRI-xx) são **herdados sem alteração** do documento 02. Os IDs criados aqui (SD-xx, BC-xx, R-xx, INV-xx, QA-DDD-xx, PRM-DDD-xx) são estáveis e devem ser reutilizados no Desenho de Arquitetura de Solução (documento 04).

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 03 — Domínios, Bounded Contexts e Context Mapping |
| Versão | v0.6 |
| Data | 2026-09-27 |
| Status | Rascunho |
| Autor | Arquitetura de Software — Atacado (Cash Management / Payments) |
| Documentos base | `01-contexto-de-negocio.md` (v0.2) e `02-desenho-conceitual.md` (v0.2) |
| Documento seguinte | `04-*` — Desenho de Arquitetura de Solução (decide a topologia física) |
| Público | Time do Atacado Cash Payments, Time de Canais, Time de Experiência, Time do GACD, Arquitetura |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: subdomínios, bounded contexts, context map, eventos, máquina de estados, times e fronteiras indicativas |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: refinamentos do 05 §17 propagados como notas (fila de tarefas interna e outbox com consumidor único; dois campos de correlação no envelope; `decisao_elegibilidade` para adesão dispensada; eventos internos fora da outbox; confirmação no estado Gerado e cancelamento proposto em Gerado); regras do 02 agora na numeração RN-xx do 01; nome canônico "Canal Digital PJ" (SD-11, BC-10) |
| v0.3 | 2026-09-24 | Correção pós-entrega: coluna "Referência" da §4.3 aponta para as letras canônicas de DEC-CON-02 (A/B/C/D, iguais às do 02 v0.4); nome residual `convenio-gateway` trocado por `convenio-produto` (módulo) e `atacado-convenio-produto` (COMP-31) na §8 |
| v0.4 | 2026-09-24 | Alerta de assinantes inválidos separado em duas L2 (02 v0.5): **CAP-09.5 Recepção de Sinais de Assinantes Inválidos** fica no SD-01/BC-01 (borda de entrada, ACL-Alerta) e **CAP-09.2 Alertas ao Gerente** (notificação no Salesforce) fica no SD-03/BC-03. Revisados: §2.2, §3.1, §3.2, §3.4, R-13 e catálogo de eventos (§5) |
| v0.5 | 2026-09-27 | Referências às seções do 02 atualizadas para a numeração do 02 v0.6 (Capacidades na §3.2, Negócio na §3.3): 02 §3.3 → §3.2 e 02 §3.2.x → §3.3.x (§1.1 e §6). Conteúdo inalterado |
| v0.6 | 2026-09-27 | Convênio com **etapa de implantação e homologação** (`instrucoes-ajustes.md`, item 8), alinhado ao 01 v0.5 e ao 02 v0.7: a assinatura (ou o contrato vigente) **abre a implantação**; o convênio é criado em teste no sistema do produto, homologado com o cliente e ativado pelo **Gerente de Cash ou pelo backoffice** (a definir — QA-CON-24), no lugar da geração automática na assinatura **[PREMISSA: PRM-CON-15 — padrão de mercado]**. Revisados: §1.1, §2.1, SD-04, §2.3 (itens 3 e 4), BC-03 (status da jornada "Em implantação" e "Convênio ativo"; "Convênio pendente" como exceção), **BC-04 (§3.5)** com linguagem ubíqua (Implantação, Homologação, Convênio em teste / ativo, Executor da implantação, Convênio pendente), estados do `Convenio` (Em teste → Ativo), comandos, eventos e invariantes (RN-17); §3.6, §3.7, context map (§4.1, R-15, R-16, R-18), §4.3 (em todas as opções A–D existe a etapa de implantação com executor humano), catálogo de eventos (§5.1: `ConvenioSolicitado` = EVN-13 "Implantação iniciada"; `ConvenioGerado` passa a `ConvenioAtivado` = EVN-10 "Convênio ativado"; `GeracaoConvenioFalhou` passa a `ConvenioPendente`; novo `ConvenioCriadoEmTeste`, interno), fluxo ponta a ponta (§5.4), §6, §7.1, §8.1, QA-DDD-06 e QA-DDD-11 revistas e nova **QA-DDD-14**, PRM-DDD-11 revista, §9.3 e glossário. Letras residuais de DEC-CON-02 em SD-04 e BC-12 corrigidas para as canônicas (A novo serviço, C Open Cash Hub) |

### 1.1 Rastreabilidade

| Elemento deste documento | Deriva de | Onde |
|---|---|---|
| Subdomínios (SD-xx) | Mapa de capacidades CAP-01..CAP-13 e agrupamento indicativo para DDD | 02 §3.2 e §9; 01 §9 |
| Bounded contexts internos (BC-01..BC-04) | Blocos APP-02 (sub-blocos APP-02.1..02.7), APP-03, APP-09 | 02 §3.4 e §3.4.1 |
| Bounded contexts externos (BC-05..BC-13) | Blocos APP-01, APP-04..APP-10 e fonte de contrato vigente (OBJ-10) | 02 §3.4; 01 §3.5 |
| Invariantes (INV-xx) | Regras RN-01..RN-17 | 01 §8.1 (o 02 §3.3.5 usa a mesma numeração desde a v0.3) |
| Eventos de domínio | Eventos de negócio EVN-01..EVN-13 | 02 §3.3.3 |
| Máquina de estados | Estados canônicos do Termo (PRM-NEG-16, PRM-CON-13) | 01 §7.4; 02 §3.3.6 |
| Relações do context map (R-xx) | Princípios PRI-01..PRI-13 e decisões DEC-CON-01..08 | 02 §6 e §7 |
| Questões e premissas | QA-CONV-xx, QA-NEG-xx, QA-CON-xx, PRM-NEG-xx, PRM-CON-xx | 01 §11–13; 02 §8 |

### 1.2 Convenção de marcação

| Marca | Significado |
|---|---|
| **[FATO: xx]** | Suportado pela fonte `xx` do 01/02 ([01]..[06], [stack], [CG]) |
| **[PREMISSA: PRM-xxx-nn]** | Suposição adotada para seguir com o modelo — precisa de validação |
| **[HIPÓTESE]** | Hipótese técnica sem fonte (ex.: token LEAP) |
| **[ABERTO: QA-xxx-nn]** | Depende de resposta a uma questão em aberto |
| **[PROPOSTA DDD]** | Decisão de modelagem proposta neste documento (não vem das fontes) |

### 1.3 O que este documento decide e o que não decide

- **Decide (proposta):** classificação de subdomínios, fronteiras lógicas de modelo (bounded contexts), linguagem ubíqua, padrões de relacionamento entre contextos, catálogo de eventos de domínio e ciclo de vida do agregado do Termo.
- **Não decide:** topologia física final, frameworks, banco de dados, broker e contratos de API detalhados — ficam no documento 04. A seção 8 traz apenas uma **recomendação indicativa** de fronteiras de implantação.

---

## 2. Domínio e subdomínios

### 2.1 Domínio

**Domínio:** *Contratação de Produtos de Cash Management / Payments no Atacado* — tudo o que é necessário para que um Cliente PJ Atacado, a partir de uma Proposta aprovada no Salesforce, esteja formalmente aderido (Termo de Adesão assinado ou contrato vigente), com Convênio por produto e tarifas cadastradas **[FATO: 01, 02, 03]**. Entre a assinatura e o convênio ativo existe uma etapa de **implantação e homologação** com o cliente, executada por pessoas (Gerente de Cash ou backoffice — QA-CON-24) **[PREMISSA: PRM-CON-15 — padrão de mercado]**.

O **problema** que a iniciativa resolve é estreito: o Gerente de Cash não consegue formalizar digitalmente a adesão nem acompanhar seu andamento, o que bloqueia convênio e tarifas **[FATO: 03]**. Quase todas as capacidades pesadas (assinatura, poderes, documentos, conteúdo, tarifas) **já existem** no banco **[FATO: 02, 04, 06]**. O que falta é o **modelo da adesão Cash** que costura essas capacidades e dá visibilidade ao Gerente.

### 2.2 Classificação dos subdomínios

| ID | Subdomínio | Classificação | Capacidades | Justificativa | O Atacado constrói ou consome? |
|---|---|---|---|---|---|
| **SD-01** | **Adesão a Produtos Cash** (orquestração da jornada do Termo de Adesão no Atacado) | **Core** | CAP-02.1, CAP-02.2, CAP-02.3, CAP-03.1, CAP-03.2, CAP-05.5 (receptor), CAP-09.5 (recepção do sinal do Canal), CAP-12.1 | É onde estão as regras que **só o Atacado conhece**: elegibilidade por contrato vigente (RN-02), tipo de termo (RN-03), termo único multiproduto como ativo reutilizável (RN-01, OP-09), unicidade por cliente (RN-16), tratamento de assinantes inválidos (RN-06, RN-07) e amarração com o Convênio por produto (RN-10..RN-13). Sustenta OE-01..OE-04 | **Constrói** (APP-02.1..02.4, 02.6, 02.7) |
| **SD-02** | **Geração do Termo** (modelos e documento do Termo de Adesão) | **Supporting** | CAP-03.3, CAP-08.1 | Necessário e específico do Atacado (2 modelos, conteúdo jurídico próprio), mas **sem diferencial**: renderizar PDF é commodity **[FATO: 05, 06]** | **Constrói pouco:** catálogo de modelos e composição; renderização **consumida** (IMPD candidato, DEC-CON-03) |
| **SD-03** | **Acompanhamento da Jornada de Adesão** (status, alertas e indicadores para o Gerente) | **Supporting** | CAP-09.1, CAP-09.2 (notificação de alertas ao Gerente), CAP-09.4, CAP-10.4 | Materializa OE-04/KPI-04 e tem linguagem própria (**status da jornada ≠ estado do Termo**, PRI-12), mas é uma projeção sem regra de negócio complexa | **Constrói** (APP-02.5 e visão no Salesforce) |
| **SD-04** | **Gestão de Convênios** | **Supporting** (dono e sistema **indefinidos**) | CAP-06.1, CAP-06.2, CAP-07.2 | Convênio é parametrização **por produto**, pré-requisito de tarifas (RN-11, RN-12). É específico de Cash, mas **já existe algum processo** ("Sistemas (BD)" [01]; Open Cash Hub [02]). O convênio é criado na **implantação** (parâmetros com o cliente, convênio em teste, homologação e ativação), feita por pessoas no sistema do produto **[PREMISSA: PRM-CON-15 — padrão de mercado]** | **Deveria consumir**; construir apenas se QA-CON-02 decidir por novo serviço (DEC-CON-02 A). Executor da implantação: Gerente de Cash ou backoffice **[ABERTO: QA-CON-02, QA-CON-03, QA-CON-24]** |
| **SD-05** | **Relacionamento Comercial** (Proposta, pipeline, negociação) | **Supporting** (sobre CRM **Generic**) | CAP-01.1, CAP-01.2, CAP-01.3, CAP-09.4 (visualização) | O CRM é SaaS genérico (Salesforce); a configuração de Proposta e pipeline Cash é suporte do Atacado. Upstream da adesão | **Configura** (Salesforce) — já existente |
| **SD-06** | **Tarifas** | **Supporting** (existente) | CAP-07.1 | Pipeline de cadastro de tarifas negociadas já existe no Databricks **[FATO: 01, 02]**; mantido pelo Atacado **[PREMISSA: PRM-CON-14]** | **Consome/integra** — fora do escopo de evolução |
| **SD-07** | **Assinatura Digital** | **Generic** (corporativo) | CAP-05.1, CAP-05.2, CAP-05.3, CAP-05.5 (emissor), CAP-12.2 | Serviço corporativo (GACD) usado por vários produtos do banco **[FATO: 02, 04]** | **Consome** |
| **SD-08** | **Firmas e Poderes** | **Generic** (corporativo) | CAP-04.1, CAP-04.3 | Fonte corporativa de representantes e poderes (FIRP) **[FATO: 02, CG]** | **Consome** via ACL |
| **SD-09** | **Gestão Documental** | **Generic** (corporativo) | CAP-08.2 | GCC/Filenet, acessado apenas por meio do GACD **[FATO: 04]** | **Nem consome diretamente** (via GACD) |
| **SD-10** | **Geração de Documentos** | **Generic** (corporativo) | CAP-08.1 (renderização) | IMPD é o gerador estrutural corporativo **[FATO: 05, 06]** | **Consome** (candidato) |
| **SD-11** | **Canal Digital do Cliente (Canal Digital PJ)** | **Externo** (core **do Time de Canais**, não do Atacado) | CAP-13.1, CAP-13.2, CAP-05.4, CAP-04.2, CAP-09.3 | Experiência do cliente, pendências, revalidação e coleta de assinatura são do Canal Digital PJ **[FATO: 01, CG]** (PRM-NEG-04) | **Não constrói**; fornece apenas a API de alerta |
| — | Integração, Segurança e Auditoria | **Não é subdomínio** (plataforma/transversal) | CAP-10.2, CAP-11.1..11.3 (e parte de CAP-12) | Axway, Key Vault, Hub and Spoke, token LEAP **[HIPÓTESE]** são plataforma. Outbox (CAP-10.4), recepção de callback (CAP-10.3) e trilha (CAP-12.1) são **mecanismos embutidos** nos BCs do Atacado | Plataforma corporativa + mecanismos internos |

### 2.3 Leitura crítica: o que o Atacado realmente constrói × consome

1. **O core é pequeno — e deve continuar pequeno.** O diferencial não está em assinar (GACD), achar poderes (FIRP), gerar PDF (IMPD) nem guardar documento (GCC/Filenet). Está nas **regras da adesão Cash** e na **coordenação** entre esses serviços com visibilidade para o Gerente. Ele é "core" no escopo do Atacado, mas tem complexidade moderada: **modelo rico, porém enxuto**, e sem microsserviço por etapa.
2. **"Integração de Representantes (ACL para FIRP)" não é subdomínio**: é um **padrão de solução** (Anticorruption Layer) que pertence ao contexto downstream, o BC-01. O subdomínio real é **Firmas e Poderes** (SD-08, Generic, do dono da FIRP). O mesmo vale para a "Integração GACD": é a ACL do BC-01 sobre o SD-07.
3. **"Notificação/Status ao Salesforce" só é subdomínio porque existe um vocabulário próprio da jornada** (Não requerido, Em implantação, Convênio ativo, Tarifas cadastradas), que não cabe no ciclo de vida do Termo (PRI-12). Sem essa distinção, seria só um adaptador de saída.
4. **Convênio é o maior risco de fronteira.** A iniciativa não sabe onde ele nasce **[ABERTO: QA-CON-02]**. Construir um "serviço de convênio" no ARO Atacado antes dessa resposta arrisca **duplicar um sistema de registro existente** ("Sistemas (BD)" [01], Open Cash Hub [02]). A recomendação é modelar o BC-04 como **contrato** (linguagem e eventos) e adiar a implementação. Além disso, o convênio **não nasce sozinho na assinatura**: a assinatura abre a implantação, e o convênio é criado em teste, homologado com o cliente e ativado pelo Gerente de Cash ou pelo backoffice (QA-CON-24) **[PREMISSA: PRM-CON-15 — padrão de mercado]**. O BC-04 acompanha e registra esse ciclo; não o substitui.
5. **Geração do Termo (SD-02) tende a Generic** se o IMPD for adotado: o Atacado mantém só o catálogo de modelos e o mapeamento de variáveis. Se a opção for geração própria (DEC-CON-03 b), o Atacado passa a **possuir um gerador de documento**, o que contraria PRI-03 e precisa de justificativa no 04.
6. **Salesforce não é o core**, embora seja onde o Gerente trabalha: é sistema de engajamento (PRM-NEG-02, PRM-CON-09). Colocar regra de adesão em Apex/Flow dispersaria o core entre SaaS e ARO e violaria PRI-02.

### 2.4 Mapa de subdomínios

```mermaid
flowchart TB
  subgraph CORE["Core - Atacado constrói"]
    SD01["SD-01 Adesão a Produtos Cash<br/>CAP-02, CAP-03.1, CAP-03.2"]
  end
  subgraph SUP["Supporting"]
    SD02["SD-02 Geração do Termo<br/>CAP-03.3, CAP-08.1"]
    SD03["SD-03 Acompanhamento da Jornada<br/>CAP-09"]
    SD04["SD-04 Gestão de Convênios<br/>CAP-06 - indefinido"]
    SD05["SD-05 Relacionamento Comercial<br/>CAP-01 - Salesforce"]
    SD06["SD-06 Tarifas<br/>CAP-07 - Databricks"]
  end
  subgraph GEN["Generic - corporativos consumidos"]
    SD07["SD-07 Assinatura Digital<br/>GACD"]
    SD08["SD-08 Firmas e Poderes<br/>FIRP"]
    SD09["SD-09 Gestão Documental<br/>GCC/Filenet"]
    SD10["SD-10 Geração de Documentos<br/>IMPD"]
  end
  subgraph EXT["Externo ao Atacado"]
    SD11["SD-11 Canal Digital PJ<br/>Time de Canais"]
  end
  SD05 --> SD01
  SD01 --> SD02
  SD01 --> SD03
  SD01 --> SD04
  SD04 --> SD06
  SD01 --> SD07
  SD01 --> SD08
  SD02 --> SD10
  SD07 --> SD09
  SD11 --> SD07
  SD11 --> SD08
  SD11 --> SD01

  classDef core fill:#e3f2fd,stroke:#1565c0,color:#000
  classDef sup fill:#fff8e1,stroke:#f9a825,color:#000
  classDef gen fill:#e8f5e9,stroke:#2e7d32,color:#000
  classDef ext fill:#eeeeee,stroke:#616161,stroke-dasharray:4 3,color:#000
  classDef indef fill:#fde2e2,stroke:#c0392b,color:#000
  class SD01 core
  class SD02,SD03,SD05,SD06 sup
  class SD04 indef
  class SD07,SD08,SD09,SD10 gen
  class SD11 ext
```

Legenda: azul = core; amarelo = supporting; vermelho = supporting com dono/sistema indefinido; verde = generic corporativo; cinza tracejado = externo. Setas = dependência de modelo (quem usa quem).

---

## 3. Bounded Contexts

### 3.1 Visão geral

| ID | Bounded Context | Nome técnico sugerido | Tipo | Subdomínio | Time dono | Realiza (02) | Capacidades |
|---|---|---|---|---|---|---|---|
| **BC-01** | **Adesão ao Termo** | `adesao-termo` | Interno (Core) | SD-01 | Atacado Cash Payments | APP-02.1, 02.2, 02.3, 02.4, 02.6, 02.7 | CAP-02.1*, 02.2*, 02.3, 03.1, 03.2, 04.1 (consumo), 05.1..05.3 (consumo), 05.5 (receptor), 09.5 (recepção do sinal do Canal), 10.1, 10.3, 12.1 |
| **BC-02** | **Geração do Termo** | `termo-documento` | Interno (Supporting) | SD-02 | Atacado Cash Payments (conteúdo: Jurídico/Compliance, PRM-NEG-15) | APP-03 | CAP-03.3, 08.1 |
| **BC-03** | **Acompanhamento da Jornada** | `adesao-acompanhamento` | Interno (Supporting) | SD-03 | Atacado Cash Payments | APP-02.5 (+ visão em APP-01) | CAP-09.1, 09.2 (notificação ao Gerente), 09.4, 10.4, 12.1 (projeção) |
| **BC-04** | **Gestão de Convênios** | `convenio-produto` | **Indefinido** (interno ou externo) | SD-04 | Indefinido (Atacado Cash Payments decide) | APP-09 (ou APP-10) | CAP-06.1, 06.2, 07.2 |
| BC-05 | Relacionamento Comercial | `ext-salesforce` | Externo (SaaS, configurado pelo Atacado) | SD-05 | Atacado Cash Payments | APP-01 | CAP-01, 02.1*, 02.2*, 09 (UI) |
| BC-06 | Firmas e Poderes | `ext-firp` | Externo (corporativo) | SD-08 | Dono da FIRP | APP-04 | CAP-04.1, 04.3 |
| BC-07 | Aceite Digital | `ext-gacd` | Externo (corporativo) | SD-07 | Time do GACD | APP-05 | CAP-05.1..05.3, 05.5 (emissor), 12.2 |
| BC-08 | Gestão de Conteúdo | `ext-gcc-filenet` | Externo (corporativo) | SD-09 | Time do GACD (consumo) / dono do GCC | APP-06 | CAP-08.2 |
| BC-09 | Impressão de Documentos | `ext-impd` | Externo (corporativo) | SD-10 | Dono do IMPD | APP-03 (candidato) / TEC-12 | CAP-08.1 |
| BC-10 | Canal Digital PJ | `ext-canal-digital-pj` | Externo (Canais) | SD-11 | Time de Canais (Experiência na jornada) | APP-07 | CAP-13, 05.4, 04.2, 09.3 |
| BC-11 | Tarifas | `ext-databricks-tarifas` | Externo à iniciativa (existente) | SD-06 | Atacado Cash Payments (PRM-CON-14) | APP-08 | CAP-07.1 |
| BC-12 | Open Cash Hub | `ext-open-cash-hub` | Externo (alternativa) | SD-07 / SD-04 | Não identificado | APP-10 | Alternativa a CAP-05 e candidato a CAP-06 |
| BC-13 | Registro de Contratos (fonte de contrato vigente) | `ext-registro-contratos` | Externo (indefinido) | SD-01 (insumo) | Não identificado | OBJ-10 | CAP-02.1 **[ABERTO: QA-CON-21]** |

\* CAP-02.1 e CAP-02.2 aparecem no 02 com provedor "APP-01 Salesforce". Este documento **propõe** que a **regra** fique no BC-01 (política de domínio) e o Salesforce apenas exiba o resultado, para não dividir o core entre SaaS e ARO **[PROPOSTA DDD]** **[ABERTO: QA-DDD-10]**.

> **Por que ACLs não são BCs próprios:** as camadas anticorrupção para FIRP, GACD, IMPD, Convênio e Registro de Contratos traduzem modelos externos **para a linguagem do contexto que as consome**. Portanto pertencem ao BC downstream (BC-01 ou BC-02) e não formam contextos de negócio independentes (PRM-DDD-04).

### 3.2 BC-01 — Adesão ao Termo (`adesao-termo`) — Core

**Propósito.** Conduzir o ciclo de vida do **Termo de Adesão** de um Cliente PJ Atacado, da solicitação pelo Gerente de Cash até a assinatura ou o encerramento, garantindo as regras de adesão Cash e a correlação com o GACD.

**Responsabilidades**

- Receber a solicitação do Salesforce (Open Host Service) e aplicar a **política de elegibilidade** (contrato vigente → adesão dispensada; RN-02) e a **política de tipo de termo** (RN-03).
- Identificar assinantes na FIRP (ACL-FIRP) e, opcionalmente, registrar a confirmação do Gerente (DEC-CON-07).
- Solicitar o documento ao BC-02 e conduzir o **envio para assinatura** no GACD em 3 passos (Coordenar Contrato → Armazenar Prévia → Coordenar Regra) como **processo com compensação** (saga) **[FATO: 04]** **[ABERTO: QA-CON-16]**.
- Receber o **callback** do GACD (CAP-05.5) e o **sinal de assinantes inválidos** do Canal (CAP-09.5), traduzindo-os para eventos de domínio (ACL de entrada). A borda de entrada só autentica, valida, deduplica, grava na inbox e responde o ACK; a regra (INV-08, estado "Assinantes inválidos") é aplicada pelo agregado.
- Manter o **estado do Termo na visão do Atacado** (espelho derivado; a fonte da verdade da assinatura é o GACD — PRI-04, PRM-DDD-02) e publicar eventos de domínio via outbox (PRI-05).
- Registrar trilha de auditoria correlacionada por `idAdesao` + `codigoProtocolo` (PRI-06, PRI-11).

**Linguagem ubíqua (BC-01)**

| Termo | Definição no BC-01 |
|---|---|
| Adesão (AdesaoTermo) | Processo de formalização, por um Cliente PJ Atacado, dos produtos Cash de uma Proposta, materializado em um Termo de Adesão; identificado por `idAdesao` |
| Termo de Adesão | Documento de aceite **único e multiproduto** (RN-01); tipos "Termo de Adesão – Produtos" e "Termo de Adesão – Produtos + Canal" (RN-03) |
| Tipo de Termo | `PRODUTOS` (cliente já tem acesso ao Canal Digital) ou `PRODUTOS_CANAL` (cliente novo) |
| Produto Cash (Produto aderido) | Produto de Cash Management / Payments da Proposta coberto pelo termo; **não confundir** com "Produto" do GACD (sistema consumidor) |
| Elegibilidade | Resultado da política que decide entre "termo requerido" e "adesão dispensada" (contrato vigente) |
| Adesão dispensada | Cliente com contrato vigente: nenhum Termo é criado; projetado como "Não requerido" na jornada |
| Assinante | Representante do Cliente PJ Atacado com poderes na FIRP, apto a assinar o termo (RN-05) |
| Protocolo de assinatura | Processo de assinatura aberto no GACD, identificado por `codigoProtocolo` |
| Prévia | PDF do termo registrado no GACD/GCC, identificado por `IdPrevia` e `CaminhoPrevia` |
| Envio para assinatura | Sequência dos 3 passos no GACD que leva o Termo a "Aguardando assinatura" |
| Assinantes inválidos | Situação em que o Canal, na revalidação, detecta que os assinantes enviados não têm mais poderes (RN-06, RN-07) |
| Reemissão | Nova tentativa do mesmo Termo após falha ou assinantes inválidos; volta a "Solicitado" e abre novo protocolo |
| Encerramento | Fim sem assinatura: recusado, expirado ou cancelado |

**Modelo de domínio (indicativo)**

```mermaid
classDiagram
  class AdesaoTermo {
    <<AggregateRoot>>
    IdAdesao idAdesao
    IdProposta idProposta
    Cnpj cnpj
    TipoTermo tipoTermo
    List~ProdutoAderido~ produtos
    List~Assinante~ assinantes
    DocumentoTermo documento
    ProtocoloAssinatura protocolo
    List~ProtocoloAssinatura~ historicoProtocolos
    StatusTermo status
    MotivoFalha motivoFalha
    MotivoEncerramento motivoEncerramento
    Matricula solicitadoPor
    int tentativas
    long versao
    solicitar()
    registrarAssinantes()
    registrarDocumento()
    registrarEnvioParaAssinatura()
    concluirAssinatura()
    invalidarAssinantes()
    registrarFalha()
    reemitir()
    encerrar()
  }
  class ProdutoAderido {
    <<ValueObject>>
    CodigoProduto codigo
    String nome
  }
  class Assinante {
    <<ValueObject>>
    IdRepresentanteFirp idRepresentante
    String nome
    PapelAssinatura papel
  }
  class DocumentoTermo {
    <<ValueObject>>
    VersaoModelo versaoModelo
    Hash hashSha256
    Instant geradoEm
  }
  class ProtocoloAssinatura {
    <<ValueObject>>
    CodigoProtocolo codigoProtocolo
    IdPrevia idPrevia
    CaminhoPrevia caminhoPrevia
    Instant abertoEm
  }
  class ProcessoEnvioAssinatura {
    <<ProcessManager>>
    IdAdesao idAdesao
    EtapaGacd etapaAtual
    int tentativas
    avancar()
    compensar()
  }
  class PoliticaElegibilidade {
    <<DomainService>>
    avaliar(cnpj, produtos)
  }
  class PoliticaTipoTermo {
    <<DomainService>>
    determinar(cnpj)
  }
  AdesaoTermo "1" *-- "1..*" ProdutoAderido
  AdesaoTermo "1" *-- "0..*" Assinante
  AdesaoTermo "1" *-- "0..1" DocumentoTermo
  AdesaoTermo "1" *-- "0..*" ProtocoloAssinatura
  ProcessoEnvioAssinatura ..> AdesaoTermo : coordena
  PoliticaElegibilidade ..> AdesaoTermo : pré-condição
  PoliticaTipoTermo ..> AdesaoTermo : define tipoTermo
```

| Elemento | Tipo DDD | Observações |
|---|---|---|
| `AdesaoTermo` | Agregado (raiz) | Fronteira de consistência do Termo. Atributos mínimos: `idAdesao`, `idProposta`, `cnpj`, `tipoTermo`, `produtos[]`, `assinantes[]`, `documento`, `protocolo` (vigente), `historicoProtocolos[]`, `status`, `motivoFalha`, `motivoEncerramento`, `solicitadoPor`, `tentativas`, `versao` (lock otimista) |
| `Cnpj`, `IdAdesao`, `IdProposta`, `CodigoProtocolo` | Value Objects (identificadores) | `Cnpj` valida dígitos; unidade do termo (CNPJ × raiz) em **[ABERTO: QA-NEG-16]** |
| `TipoTermo` | Value Object (enum) | `PRODUTOS` \| `PRODUTOS_CANAL` |
| `ProdutoAderido` | Value Object | Snapshot da Proposta no momento da solicitação (PRM-DDD-07); catálogo oficial **[ABERTO: QA-CON-06]** |
| `Assinante` | Value Object | Snapshot da FIRP com dados pessoais **mínimos** (PRM-DDD-08, RNFN-05) |
| `DocumentoTermo` | Value Object | Referência ao documento gerado: versão do modelo + hash; o PDF segue para o GACD e **não** é fonte de verdade no BC-01 **[ABERTO: QA-DDD-13]** |
| `ProtocoloAssinatura` | Value Object | `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia` **[FATO: 04]**; histórico preservado nas reemissões |
| `StatusTermo` | Value Object (enum) | Estados canônicos (seção 6) |
| `ProcessoEnvioAssinatura` | Process Manager (saga) | Estado técnico dos 3 passos no GACD, retentativas e compensação; eventos intermediários **não publicados** (ProtocoloAberto, PreviaArmazenada, RegraCoordenada) |
| `PoliticaElegibilidade`, `PoliticaTipoTermo` | Domain Services | Consultam BC-13 e o acesso do cliente ao Canal via portas (ACL) |
| `RepositorioAdesaoTermo` | Repositório | Garante a invariante de conjunto INV-01 (índice único por CNPJ para termos não terminais) |
| ACL-FIRP, ACL-GACD, ACL-Callback, ACL-Alerta, ACL-Contratos | Anticorruption Layers (portas/adaptadores) | Traduzem "representante/poder", "contrato/protocolo/prévia" e sinais externos para a linguagem do BC-01 |

**Comandos**

| Comando | Origem | Efeito | Evento(s) |
|---|---|---|---|
| `SolicitarTermoAdesao` | Salesforce (API Adesão, OHS) | Aplica elegibilidade e tipo; cria `AdesaoTermo` em Solicitado ou registra adesão dispensada (sem agregado; refinado no 05 §17 I-09: registro em `decisao_elegibilidade`, cujo `idDecisao` identifica o status "Não requerido" no Salesforce) | `TermoSolicitado` ou `AdesaoDispensada` |
| `IdentificarAssinantes` | Interno (reação a `TermoSolicitado`/`ReemissaoSolicitada`) | Consulta FIRP via ACL | `AssinantesIdentificados` ou `GeracaoDoTermoFalhou` |
| `ConfirmarAssinantes` (opcional) | Salesforce (Gerente de Cash) | Libera geração após conferência (DEC-CON-07, QA-NEG-18) | `AssinantesConfirmados` |
| `GerarTermo` | Interno | Solicita documento ao BC-02 | `TermoGerado` ou `GeracaoDoTermoFalhou` |
| `EnviarParaAssinatura` | Interno (saga) | 3 passos no GACD com compensação | `TermoEnviadoParaAssinatura` ou `GeracaoDoTermoFalhou` |
| `RegistrarConclusaoAssinatura` | GACD (callback, via ACL) | Transição para Assinado, se protocolo vigente | `AssinaturaConcluida` |
| `InvalidarAssinantes` | Canal Digital PJ (API de alerta, via ACL) | Transição para Assinantes inválidos | `AssinantesInvalidados` |
| `ReemitirTermo` | Salesforce (Gerente de Cash) | Volta a Solicitado com nova tentativa | `ReemissaoSolicitada` |
| `EncerrarTermo` | Salesforce (cancelamento) ou GACD (recusa/expiração **[ABERTO: QA-CON-12]**) | Transição para Encerrado | `TermoEncerrado` |
| `ConsultarAdesao` | Salesforce | Consulta (sem efeito) | — |

**Invariantes (INV)**

| ID | Invariante | Regra |
|---|---|---|
| INV-01 | No máximo **um** `AdesaoTermo` não terminal por Cliente PJ Atacado (CNPJ) — invariante de conjunto, garantida pelo repositório | RN-16, PRM-NEG-05 **[ABERTO: QA-NEG-16, QA-DDD-01]** |
| INV-02 | Só se cria Termo para Proposta com tarifas aprovadas e cliente **sem** contrato vigente | RN-02, RN-04 |
| INV-03 | Um único Termo cobre **todos** os produtos da solicitação; `produtos[]` não vazio | RN-01 |
| INV-04 | `tipoTermo` ∈ {Produtos, Produtos + Canal}, definido pela política de tipo e **imutável** a partir de Gerado (mudança exige reemissão) | RN-03, PRM-NEG-13 |
| INV-05 | `assinantes[]` não vazio e originado da FIRP antes de Gerado | RN-05 |
| INV-06 | O envio ao GACD só ocorre com documento gerado; `codigoProtocolo` é obrigatório em Aguardando assinatura | PRM-CON-06, RN-08 |
| INV-07 | Transição para Assinado só por callback correlacionado ao `codigoProtocolo` **vigente**; sinais de protocolos anteriores são auditados e ignorados | RN-08, PRI-06 |
| INV-08 | Assinantes inválidos só a partir de Aguardando assinatura | RN-06, RN-07 |
| INV-09 | Assinado e Encerrado são terminais e imutáveis | PRM-CON-13 |
| INV-10 | Toda transição persiste o evento de domínio **na mesma transação** do estado (outbox) | PRI-05, PRI-11, RNFN-01 |

**Time dono:** Time do Atacado Cash Payments (PRM-CON-02). **Tecnologia provável:** microsserviço Java no ARO Atacado (`atacado-core`), estado e outbox em PostgreSQL gerenciado (PRM-CON-05), chamadas a FIRP/GACD via Axway API Gateway com token LEAP **[HIPÓTESE]**; detalhes no 04.

### 3.3 BC-02 — Geração do Termo (`termo-documento`) — Supporting

**Propósito.** Transformar os dados de composição do Termo em **documento PDF (base64)** a partir de um **modelo versionado** por tipo de termo.

**Responsabilidades:** manter o catálogo de modelos (tipo, versão, vigência, referência ao template); mapear dados da adesão para variáveis do modelo; acionar o renderizador (IMPD ou alternativa); devolver o documento e sua versão/hash para rastreabilidade (RNFN-01).

| Termo | Definição no BC-02 |
|---|---|
| Modelo do Termo | Template jurídico de um tipo de termo, com versão e vigência; conteúdo validado por Jurídico/Compliance (PRM-NEG-15) |
| Versão do modelo | Identificador imutável de um modelo publicado; registrado no Termo gerado |
| Variável de modelo | Campo preenchido na composição (razão social, CNPJ, produtos, assinantes, data) **[ABERTO: QA-NEG-10]** |
| Renderização | Conversão modelo + dados → PDF base64 **[FATO: 05]** |
| Documento do Termo | Resultado da renderização (PDF base64 + hash + versão do modelo) |

| Elemento | Tipo DDD | Observações |
|---|---|---|
| `ModeloTermo` | Agregado (raiz) | `idModelo`, `tipoTermo`, `versao`, `vigenciaInicio`, `vigenciaFim`, `referenciaTemplate` (id do template CSF no IMPD ou artefato próprio), `status` (Rascunho \| Vigente \| Descontinuado), `aprovadoPor` |
| `DadosComposicao` | Value Object | Entrada da renderização (snapshot vindo do BC-01) |
| `DocumentoTermo` | Value Object | `pdfBase64`, `hashSha256`, `versaoModelo` |
| `RenderizadorDocumento` | Porta (ACL) | Adaptador IMPD (`impd-srv-doc-generator`) ou biblioteca própria (DEC-CON-03) |

- **Comandos:** `GerarDocumentoTermo` (síncrono, chamado pelo BC-01); `PublicarVersaoModelo`; `DescontinuarModelo`.
- **Eventos:** `ModeloTermoPublicado` (consumido pelo BC-01 apenas para cache/validação). O documento gerado é **retorno síncrono**; quem publica `TermoGerado` é o BC-01.
- **Invariantes:** um único modelo **vigente** por tipo de termo em cada instante (RN-03); versão publicada é imutável; todo documento carrega a versão do modelo usada (RNFN-01).
- **Time dono:** Atacado Cash Payments (dono do conteúdo: Jurídico/Compliance **[ABERTO: QA-CON-19]**). **Tecnologia provável:** módulo Java do serviço de adesão + IMPD API cloud (conectividade ARO ↔ IMPD a confirmar **[FATO: 06]**).
- **Capacidades:** CAP-03.3, CAP-08.1.
- **Crítica:** com IMPD, o BC-02 se reduz a **catálogo de modelos + ACL**; sua existência como contexto se justifica pela linguagem jurídica/versionamento, **não** por volume de lógica. Não justifica microsserviço próprio (seção 8).

### 3.4 BC-03 — Acompanhamento da Jornada (`adesao-acompanhamento`) — Supporting

**Propósito.** Manter e entregar ao Salesforce a **visão consolidada da jornada de adesão** (termo + convênios + tarifas) e os **alertas ao Gerente de Cash**, com consistência eventual e entrega garantida.

**Responsabilidades:** projetar eventos de BC-01, BC-04 e BC-11 em uma visão por Proposta; derivar o **status da jornada**; criar e entregar os alertas ao Gerente (assinantes inválidos, falhas) a partir dos eventos do BC-01 (CAP-09.2) — a recepção do sinal do Canal **não** é do BC-03 (CAP-09.5, borda de entrada do BC-01); entregar ao Salesforce via outbox (DEC-CON-05 a); fornecer dados para KPIs (CAP-09.4, RNFN-07).

| Termo | Definição no BC-03 |
|---|---|
| Visão da jornada | Projeção por Proposta com estado do Termo, status da jornada, convênios por produto e alertas |
| Status da jornada | Não requerido \| Termo em andamento (espelha o estado do Termo) \| Termo assinado \| Em implantação (por produto) \| Convênio ativo (por produto) \| Tarifas cadastradas \| Encerrada. "Convênio pendente" é situação de **exceção** (falha ou atraso na implantação ou na homologação — QA-CONV-11), exibida com alerta. **Não** é estado do Termo (PRI-12) |
| Alerta ao Gerente | Aviso acionável no Salesforce (ex.: regularizar assinantes, reemitir termo, convênio pendente por falha ou atraso na implantação) |
| Entrega de status | Mensagem da outbox destinada ao Salesforce, com retentativa até confirmação |

| Elemento | Tipo DDD | Observações |
|---|---|---|
| `VisaoJornadaAdesao` | Read model (projeção) | `idProposta`, `cnpj`, `idAdesao`, `statusTermo`, `statusJornada`, `convenios[] {codigoProduto, status (Em implantação \| Convênio ativo \| Convênio pendente), numeroConvenio}`, `alertas[]`, `ultimaVersaoAplicada` por origem |
| `AlertaGerente` | Entidade | `idAlerta`, `tipo` (ASSINANTES_INVALIDOS \| FALHA_GERACAO \| FALHA_CONVENIO — falha ou atraso na implantação), `criadoEm`, `resolvidoEm` |
| `EntregaStatus` | Entidade técnica (outbox de saída) | `idMensagem`, `destino` (Salesforce), `payload`, `tentativas`, `situacao` |

- **Comandos:** `ProjetarEvento` (interno, por evento consumido); `ReentregarStatus` (operacional).
- **Eventos:** `StatusJornadaAtualizado` (EVN-09), `AlertaGerenteEmitido`.
- **Invariantes:** projeção **idempotente** por `idEvento` e **monotônica** por `versaoAgregado` (evento mais antigo não sobrescreve o mais novo); o BC-03 **nunca altera** o estado do Termo; o status da jornada é derivado, nunca informado pelo Salesforce.
- **Time dono:** Atacado Cash Payments. **Tecnologia provável:** módulo Java + relay de outbox para a API do Salesforce (mecanismo — REST, Platform Events — no 04).
- **Capacidades:** CAP-09.1, CAP-09.2 (notificação de alertas ao Gerente), CAP-09.4, CAP-10.4, CAP-12.1 (projeção).
- **Crítica:** contexto fino. Existe para **proteger o Salesforce do modelo interno** e o BC-01 das restrições da plataforma Salesforce (limites de API, indisponibilidade). É módulo, não microsservício.

### 3.5 BC-04 — Gestão de Convênios (`convenio-produto`) — Supporting, indefinido

**Propósito.** Acompanhar a **implantação** de cada produto aderido e registrar **um Convênio por produto** (RN-11), como pré-requisito do cadastro de tarifas (RN-12). O Termo assinado ou o contrato vigente **abre a implantação** (RN-13 — inferência); o convênio é criado **em teste** no sistema do produto, **homologado** com o cliente e **ativado** pelo executor da implantação — Gerente de Cash ou backoffice **[ABERTO: QA-CON-24]** — e só então libera as tarifas (RN-17) **[PREMISSA: PRM-CON-15 — padrão de mercado]**.

| Termo | Definição no BC-04 |
|---|---|
| Convênio | Registro cadastral **por produto** que habilita o cadastro de tarifas; registrado no **sistema do produto** (APP-09), com o Salesforce mostrando só número e status; hipótese de não exigir assinatura própria (QA-CONV-05, QA-CONV-06) |
| Número do convênio | Identificador do convênio; hipótese de ser chave para o Databricks **[ABERTO: QA-CONV-10]** |
| Implantação (do produto) | Etapa, por produto, entre o Termo assinado (ou o contrato vigente) e o convênio ativo (PN-10 "Implantar produto e gerar Convênio"): **PN-10.1** definir parâmetros com o cliente (layout CNAB 240/400 ou API, canal de transmissão — internet banking, VAN, SFTP, API —, contas, carteira) → **PN-10.2** criar o convênio em teste no sistema do produto → **PN-10.3** homologar com o cliente → **PN-10.4** ativar o convênio. Feita por pessoas, não por processo automático **[PREMISSA: PRM-CON-15 — padrão de mercado]** |
| Executor da implantação | Quem executa a implantação: Gerente de Cash (ATR-01) **ou** Backoffice de Cash (ATR-09), a definir **[ABERTO: QA-CON-24]**. Se existir hoje uma área de implantação de Cash, ela é a candidata natural **[ABERTO: QA-CON-25]** |
| Solicitação de convênio (pendência de implantação) | Pendência aberta para o executor por (CNPJ, produto, origem) quando a implantação é aberta; visível no Salesforce. Onde nasce depende da opção de 4.3 |
| Origem do convênio | `idAdesao` (termo assinado) ou referência de contrato vigente |
| Homologação | Testes com o cliente (arquivos de remessa e retorno, ou chamadas de API) até o convênio funcionar; condição para ativar o convênio (RN-17). Quais produtos exigem homologação: **[ABERTO: QA-CON-25]** |
| Convênio em teste | Convênio criado no sistema do produto com os parâmetros do cliente, ainda em homologação; **não** libera o cadastro de tarifas |
| Convênio ativo | Convênio ativado pelo executor após a homologação (EVN-10); libera o cadastro de tarifas (PN-11) |
| Convênio pendente | Situação de **exceção**: implantação ou homologação com falha ou atraso (falha técnica de integração, layout ou remessa rejeitados, cliente sem retorno), tratada pelo executor com alerta ao Gerente (QA-CONV-11) |

| Elemento | Tipo DDD | Observações |
|---|---|---|
| `Convenio` | Agregado (raiz) | `numeroConvenio`, `cnpj`, `codigoProduto`, `origem`, `status` (Em teste \| Ativo), `criadoEm`, `ativadoEm`. O registro oficial fica no sistema do produto (APP-09); no Atacado é só referência (número e status), salvo na opção A de 4.3 |
| `SolicitacaoConvenio` | Entidade (ou agregado local, se o sistema de registro for externo) | Guarda, no lado do Atacado, a **pendência de implantação**: situação (Em implantação \| Convênio ativo \| Convênio pendente), executor (QA-CON-24), prazo de acompanhamento e retentativa das integrações técnicas |

- **Comandos:** `SolicitarConvenio` (por produto; abre a implantação como pendência para o executor), `RegistrarConvenioEmTeste` (executor), `RegistrarConvenioAtivado` (executor, após a homologação), `RegistrarPendenciaConvenio` (falha ou atraso). Os três últimos são registros do que o executor fez no sistema do produto; como chegam ao BC-04 está em **[ABERTO: QA-DDD-14]**.
- **Eventos:** `ConvenioSolicitado` (EVN-13 "Implantação iniciada"), `ConvenioCriadoEmTeste` (interno), `ConvenioAtivado` (EVN-10 "Convênio ativado"), `ConvenioPendente`.
- **Invariantes (hipóteses):** 1 Termo → N Convênios, um por produto (QA-CONV-04); no máximo um convênio ativo por (CNPJ, produto); a implantação só é aberta com termo assinado ou contrato vigente (RN-13); o convênio nasce **Em teste** e só fica **Ativo** após a homologação com o cliente (RN-17, PRM-CON-15); só o convênio **ativo** libera as tarifas (RN-12, PRM-NEG-07).
- **Time dono:** indefinido **[ABERTO: QA-CON-02, QA-CON-03]**. **Executor da implantação:** Gerente de Cash ou backoffice **[ABERTO: QA-CON-24, QA-CON-25]**. **Tecnologia:** indefinida (ver opções em 4.3).
- **Capacidades:** CAP-06.1, CAP-06.2, CAP-07.2.
- **Crítica:** o BC-04 é definido aqui **como linguagem e contrato de eventos**, não como sistema. Qualquer implementação antes de QA-CON-02 é especulativa. Em qualquer opção, o ciclo até o convênio ativo tem uma **etapa humana** (implantação e homologação com o cliente), cujo tempo depende do cliente; o BC-04 acompanha e registra essa etapa, não a elimina.

### 3.6 Contextos externos

| ID | Contexto | Propósito (visão do Atacado) | Linguagem própria relevante | O que o Atacado usa | Dono | Tecnologia |
|---|---|---|---|---|---|---|
| BC-05 | Relacionamento Comercial (Salesforce) | Jornada do Gerente de Cash: Proposta, solicitação, visão de status, alertas | Proposta, Oportunidade, Pipeline, Aprovação | Origem dos comandos; destino da projeção | Atacado Cash Payments | Salesforce Financial Services Cloud (SaaS) **[FATO: stack]** |
| BC-06 | Firmas e Poderes (FIRP) | Fonte da verdade de representantes e poderes | Firma, Representante, Poder, Alçada, Assinatura isolada/conjunta | Consulta de assinantes (PN-03) | Dono da FIRP | API via Axway (sem documentação **[ABERTO: QA-CON-15]**) |
| BC-07 | Aceite Digital (GACD) | Coordenação de assinatura, prévia, regras, protocolo e callback | Contrato, Protocolo (`codigoProtocolo`), Prévia (`IdPrevia`, `CaminhoPrevia`), Regra, **Produto** (sistema consumidor), Callback | 3 chamadas + callback (PN-05, PN-09) | Time do GACD | APIs via Axway: `gacd-srv-coordenar-ass-sformatador`, `cgcc_conteudo_gacd/.../armazenar`, `gacd-srv-coordenar-regra` **[FATO: 04]** (nomes em QA-CON-16) |
| BC-08 | Gestão de Conteúdo (GCC/Filenet) | Repositório da prévia e do documento | Conteúdo, Documento, Caminho | Nada diretamente (via GACD) | Dono do GCC / GACD | Corporativo |
| BC-09 | Impressão de Documentos (IMPD) | Renderização estrutural de PDF | Template CSF Designer v21, Documento, base64, Esteira/RDM | Renderização do Termo (candidato) | Dono do IMPD | API cloud `impd-srv-doc-generator` na Azure **[FATO: 06]** |
| BC-10 | Canal Digital PJ | Pendências, revalidação na FIRP, assinatura, notificação ao cliente | Pendência de assinatura, Revalidação, Usuário master | Chamada à API de alerta de assinantes inválidos | Time de Canais (+ Experiência) | BGS + PDPJ (PDPJ integra GACD; BGS não) **[FATO: 02]** |
| BC-11 | Tarifas (Databricks) | Cadastro das tarifas negociadas | Tarifa, Pipeline de cadastro | Consumidor dos convênios ativos | Atacado Cash Payments (PRM-CON-14) | Databricks **[FATO: 01, stack]** |
| BC-12 | Open Cash Hub | Canal para ERPs com módulo de termos e convênios | Termo (ERP), Convênio (ERP) | Alternativa ao GACD (DEC-CON-01) e candidato a BC-04 (DEC-CON-02 C) | Não identificado | Existente **[FATO: 02]** |
| BC-13 | Registro de Contratos | Fonte de "contrato vigente" que dispensa o termo | Contrato vigente | Política de elegibilidade (CAP-02.1) | Não identificado | Indefinida **[ABERTO: QA-CON-21]** |

### 3.7 Homônimos e traduções entre contextos

Os homônimos abaixo são o principal motivo para as ACLs; sem tradução, o modelo do GACD e da FIRP "vaza" para o Salesforce.

| Termo | Significado em cada contexto | Tradução no BC-01 |
|---|---|---|
| **Contrato** | BC-07 GACD: processo/documento coordenado para assinatura ("Coordenar Contrato"). BC-13: **contrato vigente** de Cash que dispensa o termo. Linguagem comercial: acordo com o cliente | GACD "contrato" → `ProtocoloAssinatura` do `AdesaoTermo`; "contrato vigente" → resultado da `PoliticaElegibilidade` |
| **Produto** | BC-07 GACD: **sistema/área consumidora** (o Atacado é um "Produto" do GACD). BC-01/BC-05: **Produto Cash** aderido | Nunca propagar o "Produto" do GACD; `ProdutoAderido` é sempre Produto Cash |
| **Representante / Poder / Firma** | BC-06 FIRP: pessoa e alçada registradas | `Assinante` (snapshot mínimo) |
| **Status** | BC-01: estado do Termo. BC-03: status da jornada. BC-05: estágio da Proposta/Oportunidade. BC-07: situação do protocolo (não documentada) | Estados canônicos (seção 6) × status da jornada (3.4) — mapeamento de GACD em **[ABERTO: QA-DDD-03]** |
| **Termo** | BC-01: Termo de Adesão multiproduto. BC-12: módulo de termos do Open Cash Hub (canal ERP) | Se o Open Cash Hub for adotado, a ACL traduz para `AdesaoTermo` sem mudar o contrato com o Salesforce (PRI-13) |
| **Prévia** | BC-07/BC-08: conteúdo armazenado (`IdPrevia`, `CaminhoPrevia`) | Atributos de `ProtocoloAssinatura` |
| **Convênio** | BC-04 (a definir), BC-12 (processo existente) e o sistema de cada produto podem ter modelos e nomes de estado diferentes (ex.: como chamam o modo teste) | Linguagem do BC-04 (3.5: Em teste, Ativo, Convênio pendente) como Published Language para BC-03 e BC-11 |

---

## 4. Context Map

### 4.1 Diagrama

Convenção: a **seta vai de upstream (U) para downstream (D)**, ou seja, indica quem influencia o modelo, **não** a direção da chamada. Linhas tracejadas = relação indefinida, alternativa ou a combinar.

```mermaid
flowchart LR
  subgraph SFX["Salesforce - Time do Atacado Cash Payments"]
    SF["BC-05 Relacionamento Comercial<br/>Salesforce"]
  end

  subgraph ARO["ARO Atacado - namespace atacado-core"]
    B1["BC-01 Adesão ao Termo<br/>adesao-termo - CORE"]
    B2["BC-02 Geração do Termo<br/>termo-documento"]
    B3["BC-03 Acompanhamento da Jornada<br/>adesao-acompanhamento"]
  end

  subgraph CORP["Corporativos - via Axway API Gateway"]
    FIRP["BC-06 Firmas e Poderes<br/>FIRP"]
    GACD["BC-07 Aceite Digital<br/>GACD"]
    GCC["BC-08 Gestão de Conteúdo<br/>GCC/Filenet"]
    IMPD["BC-09 Impressão de Documentos<br/>IMPD"]
  end

  subgraph CANX["Time de Canais"]
    CAN["BC-10 Canal Digital PJ"]
  end

  subgraph POS["Pós-assinatura e insumos indefinidos"]
    CONV["BC-04 Gestão de Convênios<br/>sistema do produto - indefinido<br/>implantação: Gerente ou backoffice"]
    DBX["BC-11 Tarifas<br/>Databricks"]
    OCH["BC-12 Open Cash Hub<br/>alternativa"]
    RC["BC-13 Registro de Contratos<br/>indefinido"]
  end

  B1 -->|"R-01 OHS/PL API Adesão - C/S"| SF
  B3 -->|"R-02 PL Status da Jornada - C/S"| SF
  SF -.-x|"R-03 Separate Ways - PRI-01"| FIRP
  SF -.-x|"R-03 Separate Ways - PRI-01"| GACD
  FIRP -->|"R-04 ACL + Conformist"| B1
  GACD -->|"R-05 C/S + ACL - 3 chamadas"| B1
  GACD -->|"R-06 OHS callback - Conformist + ACL"| B1
  GCC -->|"R-07 interno corporativo"| GACD
  FIRP -->|"R-08 integração existente"| GACD
  B2 -->|"R-09 C/S interno"| B1
  IMPD -->|"R-10 Conformist - alt. Separate Ways"| B2
  GACD -->|"R-11 Conformist / C/S"| CAN
  FIRP -->|"R-12 Conformist / C/S - revalidação"| CAN
  B1 -->|"R-13 OHS/PL alerta - C/S a combinar"| CAN
  B1 -->|"R-14 eventos de domínio - C/S interno"| B3
  B1 -.->|"R-15 abre a implantação - opções A a D"| CONV
  CONV -.->|"R-16 PL convênio ativo - C/S"| DBX
  SF -->|"R-17 existente - tarifas negociadas"| DBX
  CONV -.->|"R-18 eventos"| B3
  DBX -.->|"R-18 eventos"| B3
  RC -.->|"R-19 ACL"| B1
  OCH -.->|"R-20 alternativa - ACL"| B1

  classDef core fill:#e3f2fd,stroke:#1565c0,color:#000
  classDef sup fill:#fff8e1,stroke:#f9a825,color:#000
  classDef gen fill:#e8f5e9,stroke:#2e7d32,color:#000
  classDef ext fill:#eeeeee,stroke:#616161,stroke-dasharray:4 3,color:#000
  classDef indef fill:#fde2e2,stroke:#c0392b,color:#000
  class B1 core
  class B2,B3,SF,DBX sup
  class FIRP,GACD,GCC,IMPD gen
  class CAN ext
  class CONV,OCH,RC indef
```

### 4.2 Tabela de relações

Siglas: C/S = Customer/Supplier; OHS = Open Host Service; PL = Published Language; ACL = Anticorruption Layer.

| ID | Relação | U | D | Padrão DDD | Protocolo previsto | Justificativa |
|---|---|---|---|---|---|---|
| R-01 | Salesforce ↔ BC-01 (solicitar, confirmar, reemitir, cancelar, consultar) | BC-01 | BC-05 | **C/S + OHS/PL** ("API Adesão v1") | REST síncrono via Akamai → App Gateway → Axway (PRM-CON-11); resposta de aceite com `idAdesao` (processamento assíncrono) | O Salesforce **não acessa componentes do banco diretamente** (PRI-01, RN-09). O BC-01 publica um contrato estável e independente de FIRP/GACD (PRI-02, PRI-13). Mesmo time dos dois lados, mas **Partnership foi rejeitada**: acoplaria o modelo do core ao da plataforma SaaS |
| R-02 | BC-03 → Salesforce (status da jornada, alertas) | BC-03 | BC-05 | **C/S + PL** (status canônicos) | Push REST para a API do Salesforce (DEC-CON-05 a) a partir da outbox, saindo pelo egress do Hub (PRM-CON-11) | KPI-04 exige tempo quase real; a outbox garante reentrega. Tecnicamente o BC-03 se **conforma à API da plataforma** Salesforce; a semântica (estados) é do Atacado |
| R-03 | Salesforce ✕ FIRP / GACD | — | — | **Separate Ways** (proibida) | Nenhum | Restrição de arquitetura **[FATO: CG]** (PRI-01). Registrada no mapa para que nenhuma solução futura crie o atalho |
| R-04 | BC-01 → FIRP (consulta de assinantes) | BC-06 | BC-01 | **ACL** (o Atacado se conforma ao contrato da FIRP e traduz) | REST síncrono via Axway; token LEAP **[HIPÓTESE]** | FIRP é Generic corporativo e não adapta seu modelo ao Atacado. A ACL converte Representante/Poder em `Assinante` e isola dados pessoais (RNFN-05). Pode ser redundante se o GACD já resolver assinantes **[ABERTO: QA-DDD-04]** |
| R-05 | BC-01 → GACD (Coordenar Contrato, Armazenar Prévia, Coordenar Regra) | BC-07 | BC-01 | **C/S** (onboarding do Atacado como "Produto" consumidor, QA-NEG-19) **+ ACL** no Atacado | REST via Axway; saga com compensação; usuário sistêmico no passo 2 **[FATO: 04]** | O GACD é OHS corporativo, mas há negociação real (contrato de callback, estados, volumetria), o que caracteriza C/S. A ACL protege o core de "contrato/produto/prévia" e permite trocar pelo Open Cash Hub (PRI-13) |
| R-06 | GACD → BC-01 (callback de assinatura concluída) | BC-07 | BC-01 | **OHS/PL do GACD; Conformist** no payload **+ ACL** de entrada | Callback HTTP (push) ao endpoint informado no passo 1, via Axway em rota interna (PRM-CON-04); ACK após persistir estado + outbox; deduplicação por `codigoProtocolo` | O GACD define o formato do callback (upstream); o Atacado não tem poder para mudá-lo. A ACL traduz em `AssinaturaConcluida` / `TermoEncerrado` e aplica INV-07 (protocolo vigente) |
| R-07 | GACD → GCC/Filenet | BC-08 | BC-07 | C/S interno corporativo; **Separate Ways** entre Atacado e GCC | Interno do GACD | O Atacado só vê a prévia via GACD (`IdPrevia`, `CaminhoPrevia`); acesso ao termo assinado pelo Gerente **[ABERTO: QA-NEG-17]** |
| R-08 | FIRP → GACD | BC-06 | BC-07 | Existente (fora do escopo) | Interno corporativo | **[FATO: 02]** GACD integrado à FIRP; relevante para evitar consulta duplicada (QA-DDD-04) |
| R-09 | BC-02 → BC-01 (documento do termo) | BC-02 | BC-01 | **C/S interno** (mesmo time) com PL interna `GerarDocumentoTermo` | Chamada in-process (módulo); REST apenas se extraído | Fronteira de linguagem (modelo jurídico/versão × ciclo de vida), não de implantação |
| R-10 | IMPD → BC-02 (renderização) | BC-09 | BC-02 | **Conformist** (template CSF Designer v21, saída só base64, esteira com RDM) com porta `RenderizadorDocumento` | REST para `impd-srv-doc-generator` na Azure (conectividade a confirmar) | O IMPD não se adapta aos consumidores **[FATO: 05, 06]**. **Alternativa:** Separate Ways (geração própria com biblioteca PDF no ARO) — DEC-CON-03 |
| R-11 | GACD → Canal Digital PJ (pendências e assinatura) | BC-07 | BC-10 | **Conformist** (PDPJ já integrado) / **C/S** no canal unificado | REST existente (PDPJ); BGS sem integração **[ABERTO: QA-CON-07]** | Relação dos times de Canais e do GACD; o Atacado não participa, mas depende dela para RN-06 e CAP-05.4 |
| R-12 | FIRP → Canal Digital PJ (revalidação) | BC-06 | BC-10 | **Conformist / C/S** | REST (Canal ↔ FIRP) | Revalidação no ato da assinatura (RN-06) **[FATO: CG]**; regras em **[ABERTO: QA-CON-09]** |
| R-13 | Canal Digital PJ → BC-01 (sinal de assinantes inválidos, CAP-09.5) | BC-01 (define a PL) | BC-10 | **C/S** com **OHS/PL** "Alerta de Assinantes Inválidos v1" — **a combinar com Canais** | REST via Axway (entrada pelo padrão corporativo); idempotente por `codigoProtocolo` + id da notificação | O Atacado publica o contrato, mas **depende do backlog de Canais** para a chamada existir: na prática, o Atacado é "cliente" da entrega de Canais. Exige acordo formal (colaboração temporária). Alternativa DEC-CON-06 b: Canal sinaliza ao GACD e o GACD avisa por callback (então U = GACD) **[ABERTO: QA-CON-08]** |
| R-14 | BC-01 → BC-03 (eventos de domínio) | BC-01 | BC-03 | **C/S interno**; BC-03 **Conformist** à PL de eventos do BC-01 | Outbox transacional; in-process no mesmo serviço (PRM-DDD-06) ou broker se extraído **[ABERTO: QA-DDD-05]** | Separa ciclo de vida do Termo (BC-01) da visão da jornada (BC-03), conforme PRI-12. **Shared Kernel rejeitado**: compartilhar só o esquema de eventos, não uma biblioteca de domínio |
| R-15 | BC-01 → BC-04 (abertura da implantação) | BC-01 (opções A/B) ou BC-04/BC-12 (opções C/D) | varia | **Indefinido** — ver 4.3 | Evento/outbox (A) ou REST via ACL (B, C, D) | O gatilho **abre a implantação** (EVN-13); a ativação do convênio (EVN-10) depende da homologação com o cliente e do executor humano **[PREMISSA: PRM-CON-15 — padrão de mercado]** **[ABERTO: QA-CON-02, QA-CON-03, QA-CON-24, QA-DDD-06]** |
| R-16 | BC-04 → Tarifas (Databricks) | BC-04 | BC-11 | **C/S + PL** do convênio ativo (`numeroConvenio`, CNPJ, produto, status) | Indefinido (tabela, arquivo ou evento) **[ABERTO: QA-DDD-11]** | Só o convênio **ativo** libera as tarifas (RN-12, RN-17, PRM-NEG-07) |
| R-17 | Salesforce → Tarifas (tarifas negociadas) | BC-05 | BC-11 | Existente (fora do escopo) | Existente, não documentado | Tarifas nascem na Proposta (RN-04) **[FATO: 01]** |
| R-18 | BC-04 / Tarifas → BC-03 (implantação iniciada, convênio ativo ou pendente, tarifas cadastradas) | BC-04, BC-11 | BC-03 | **Conformist** (BC-03 lê o que os upstreams publicarem) | Indefinido **[ABERTO: QA-DDD-14]** | Necessário para os status "Em implantação", "Convênio ativo" e "Tarifas cadastradas" da jornada (01 §7.4) e para o alerta de convênio pendente |
| R-19 | Registro de Contratos → BC-01 (contrato vigente) | BC-13 | BC-01 | **ACL** | Indefinido **[ABERTO: QA-CON-21]** | Se a decisão de elegibilidade ficar no Salesforce (QA-DDD-10), R-19 deixa de existir e o Salesforce informa o resultado no comando |
| R-20 | Open Cash Hub → BC-01 | BC-12 | BC-01 | **Alternativa** — ACL (substitui R-05/R-06) | REST via ACL | PRI-13: trocar o gerenciador de termos não deve afetar R-01 nem R-02 (DEC-CON-01) |

### 4.3 Relação com o Convênio: opções

> **Em todas as opções (A–D) existe a etapa de implantação com executor humano.** A assinatura (ou o contrato vigente) abre a implantação; o convênio é criado em teste, homologado com o cliente e ativado pelo Gerente de Cash ou pelo backoffice (QA-CON-24) **[PREMISSA: PRM-CON-15 — padrão de mercado]**. A opção escolhida define **onde o convênio é registrado** e **onde a pendência de implantação nasce**; não elimina a homologação (nota de DEC-CON-02 no 02).

| Opção | Onde nasce o Convênio | Padrão DDD da relação | Quem abre a implantação / quem executa | Prós | Contras | Referência |
|---|---|---|---|---|---|---|
| **A** | **Novo serviço no ARO Atacado** (BC-04 interno, `convenio-produto`) | C/S interno por **eventos** (BC-04 assina `AssinaturaConcluida` e `AdesaoDispensada` — coreografia) | BC-04 abre a pendência ao consumir o evento (hipótese QA-CONV-02); o executor cria, homologa e ativa | Autonomia; linguagem própria (o ciclo continua limitado pela homologação com o cliente) | **Risco de duplicar** o sistema de registro existente ("Sistemas (BD)"); cria sistema de registro novo para o Atacado manter | DEC-CON-02 A |
| **B** | **Sistemas legados de produto / "Sistemas (BD)"** | BC-04 fino no Atacado (solicitação + retentativa) com **ACL** para cada sistema de destino (Conformist) | BC-01/BC-04 abre a pendência (orquestração); o executor cria, homologa e ativa no sistema do produto | Reusa o sistema de registro atual; alinhado a PRI-03 | N adaptadores se cada produto tiver seu sistema; contratos desconhecidos | DEC-CON-02 B; QA-CONV-01 (hipótese recomendada no 01) |
| **C** | **Open Cash Hub** | **ACL + Conformist** ao Open Cash Hub (upstream) | BC-01/BC-04 via ACL abre a pendência; o executor atua no Open Cash Hub | Processo já existe **[FATO: 02]** | Modelo acoplado ao canal ERP; aderência a clientes não ERP incerta (QA-CONV-09) | DEC-CON-02 C |
| **D** | **Salesforce registra** e um legado efetiva | Salesforce vira upstream do convênio; BC-04 inexistente no ARO | Salesforce abre a pendência; o executor registra no Salesforce e efetiva no legado | Menor esforço inicial | Viola PRM-NEG-02/PRM-CON-09 (Salesforce não é sistema de registro) e PRI-02; espalha regra de negócio no SaaS | DEC-CON-02 D |

**Indicação preliminar [PROPOSTA DDD]:** B ou C, com um **BC-04 fino** no Atacado que possui apenas a `SolicitacaoConvenio` (pendência de implantação, acompanhamento do executor e retentativa técnica, QA-CONV-11) e publica `ConvenioSolicitado` (EVN-13) e `ConvenioAtivado` (EVN-10) como Published Language para BC-03 e Tarifas. Nessa linha, a porta `convenio-produto` tende a **abrir uma pendência de implantação** visível no Salesforce e acompanhar o status (Em implantação → Convênio ativo), e **não** a criar o convênio direto por API no sistema do produto (04, COMP-01.6 e ADR-11). A opção A só se justifica se nenhum sistema existente servir. A opção D não é recomendada.

### 4.4 Geração de documento: IMPD e alternativa

| Opção | Padrão | Implicação para o BC-02 |
|---|---|---|
| **IMPD** (API cloud) | **Conformist** + porta `RenderizadorDocumento` | BC-02 = catálogo de modelos + mapeamento de variáveis; templates CSF Designer v21 mantidos pelo Atacado com terceiros e RDM **[FATO: 05, 06]** |
| **Geração própria** no ARO | **Separate Ways** em relação ao IMPD | BC-02 passa a ter motor de template e biblioteca PDF; mais autonomia, mais responsabilidade de manutenção e conformidade |
| Geração no Salesforce | — (não recomendada) | Tira o BC-02 do Atacado e viola parcialmente PRI-02 |

A porta `RenderizadorDocumento` permite trocar a opção sem afetar o BC-01. Decisão no 04 (DEC-CON-03).

### 4.5 Padrões avaliados e não adotados

| Padrão | Onde poderia ser usado | Por que não |
|---|---|---|
| Shared Kernel | Biblioteca comum de domínio entre BC-01, BC-03 e BC-04 | Acopla ciclos de release; basta compartilhar o **esquema de eventos** (PL) e identificadores como tipos simples |
| Partnership | BC-01 ↔ Salesforce (mesmo time) | Incentiva mudanças acopladas e regra de negócio no SaaS; C/S + OHS mantém a disciplina de contrato |
| Partnership | BC-01 ↔ Canal (API de alerta) | Os times têm backlogs e prioridades distintas; basta uma colaboração **temporária** para fechar o contrato e depois C/S estável |
| Conformist puro ao GACD no core | BC-01 adotando o modelo do GACD | Levaria "contrato/produto/prévia" ao Salesforce e impediria a troca pelo Open Cash Hub (PRI-13) |

---

## 5. Eventos de domínio e fluxo de eventos

### 5.1 Catálogo de eventos

Visibilidade: **Publicado** = contrato (Published Language) consumido fora do contexto produtor; **Interno** = usado dentro do BC produtor (reações, saga, auditoria).

| Evento | EVN (02) | Produtor | Consumidores | Payload mínimo (além do envelope 5.2) | Chave de idempotência | Visibilidade |
|---|---|---|---|---|---|---|
| `TermoSolicitado` | EVN-02 | BC-01 | BC-03; BC-01 reage pela fila de tarefas interna (identificar assinantes — 05 DT-05) | `idAdesao`, `idProposta`, `cnpj`, `tipoTermo`, `produtos[codigo]`, `solicitadoPor` | `idAdesao` + `versaoAgregado` | Publicado |
| `AdesaoDispensada` | — (jornada "Não requerido") | BC-01 | BC-03, BC-04 (abre a implantação — hipótese QA-CONV-03 b) | `idProposta`, `cnpj`, `produtos[codigo]`, `referenciaContratoVigente` | `idProposta` | Publicado |
| `AssinantesIdentificados` | EVN-03 | BC-01 | BC-03; BC-01 pela fila de tarefas interna | `idAdesao`, `quantidadeAssinantes`, `idsRepresentanteFirp[]` (sem documento pessoal) | `idAdesao` + `versaoAgregado` | Publicado |
| `AssinantesConfirmados` (opcional) | — | BC-01 | BC-01 | `idAdesao`, `confirmadoPor` | `idAdesao` + `versaoAgregado` | Interno |
| `TermoGerado` | EVN-04 | BC-01 | BC-03; BC-01 (saga) pela fila de tarefas interna | `idAdesao`, `versaoModelo`, `hashDocumento` | `idAdesao` + `versaoAgregado` | Publicado |
| `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada` | EVN-05 (parcial) | BC-01 (saga) | BC-01 | `idAdesao`, `codigoProtocolo` / `IdPrevia`, `CaminhoPrevia` | `idAdesao` + etapa | Interno |
| `TermoEnviadoParaAssinatura` | EVN-05, EVN-06 | BC-01 | BC-03 | `idAdesao`, `codigoProtocolo`, `IdPrevia`, `enviadoEm` | `codigoProtocolo` | Publicado |
| `GeracaoDoTermoFalhou` | — (estado Falha na geração) | BC-01 | BC-03 (alerta) | `idAdesao`, `etapa` (FIRP \| DOCUMENTO \| GACD), `motivo`, `reprocessavel` | `idAdesao` + `versaoAgregado` | Publicado |
| `AssinantesInvalidados` | EVN-07 | BC-01 (traduz o sinal do Canal recebido pela borda de entrada — CAP-09.5) | BC-03 (alerta ao Gerente — CAP-09.2) | `idAdesao`, `codigoProtocolo`, `motivo`, `quantidadeInvalidos` | `codigoProtocolo` + `idNotificacaoCanal` | Publicado |
| `ReemissaoSolicitada` | — | BC-01 | BC-03; BC-01 pela fila de tarefas interna | `idAdesao`, `protocoloAnterior`, `solicitadoPor`, `tentativa` | `idAdesao` + `versaoAgregado` | Publicado |
| `AssinaturaConcluida` | EVN-08 | BC-01 (traduz o callback do GACD) | BC-03, BC-04 (abre a implantação, hipótese), Canais para adesão ao canal **[ABERTO: QA-DDD-09]** | `idAdesao`, `codigoProtocolo`, `cnpj`, `tipoTermo`, `produtos[codigo]`, `assinadoEm` | `codigoProtocolo` | Publicado |
| `TermoEncerrado` | EVN-12 | BC-01 | BC-03 | `idAdesao`, `codigoProtocolo`, `motivo` (RECUSADO \| EXPIRADO \| CANCELADO) | `idAdesao` + `versaoAgregado` | Publicado |
| `ModeloTermoPublicado` | — | BC-02 | BC-01 | `tipoTermo`, `versao`, `vigenciaInicio` | `tipoTermo` + `versao` | Interno (Atacado) |
| `StatusJornadaAtualizado` | EVN-09 | BC-03 | Salesforce (BC-05) | `idProposta`, `idAdesao`, `statusTermo`, `statusJornada`, `atualizadoEm`, `versao` | `idProposta` + `versao` | Publicado |
| `AlertaGerenteEmitido` | — (CAP-09.2 notificação ao Gerente) | BC-03 | Salesforce (BC-05) | `idAlerta`, `idProposta`, `tipo`, `acaoSugerida` | `idAlerta` | Publicado |
| `ConvenioSolicitado` | EVN-13 (Implantação iniciada, PN-10) | BC-04 (ou BC-01, conforme opção 4.3) | BC-03 (status "Em implantação" e pendência visível no Salesforce para o executor — Gerente de Cash ou backoffice, QA-CON-24) | `idSolicitacao`, `cnpj`, `codigoProduto`, `origem` (`idAdesao` \| contrato vigente) | `cnpj` + `codigoProduto` + `origem` | Publicado |
| `ConvenioCriadoEmTeste` | — (PN-10.2) | BC-04 (registro do executor) | BC-04 (auditoria) | `idSolicitacao`, `numeroConvenio`, `codigoProduto` | `numeroConvenio` + estado | Interno |
| `ConvenioAtivado` | EVN-10 (Convênio ativado, após a homologação — PN-10.4) | BC-04 (registro do executor ou sinal do sistema do produto — QA-DDD-14) | Tarifas (BC-11), BC-03 (status "Convênio ativo") | `numeroConvenio`, `cnpj`, `codigoProduto`, `idAdesao`, `ativadoEm` | `numeroConvenio` | Publicado |
| `ConvenioPendente` | — (Convênio pendente, QA-CONV-11) | BC-04 | BC-03 (alerta ao Gerente e ao executor) | `idSolicitacao`, `codigoProduto`, `motivo` (ex.: falha de integração, homologação rejeitada, atraso do cliente), `reprocessavel` | `idSolicitacao` + ocorrência | Publicado |
| `TarifasCadastradas` | EVN-11 | Tarifas (BC-11, externo) | BC-03 | `idProposta`, `codigoProduto`, `numeroConvenio` | a definir **[ABERTO: QA-DDD-11]** | Publicado (externo) |

EVN-01 (Proposta aprovada) é fato do Salesforce, não evento de domínio do Atacado: chega como pré-condição do comando `SolicitarTermoAdesao`.

> **Refinado em `05-especificacoes-tecnicas.md` §17 (I-01, I-10, I-13) e DT-05:** (1) as reações do próprio BC-01 (identificar assinantes, gerar documento, conduzir a saga) não consomem a outbox: são disparadas pela **fila de tarefas interna `adesao_termo.tarefa`**, gravada na mesma transação da transição (INV-10 preservada); (2) a **outbox tem consumidor único**, o COMP-03 (BC-03); (3) os eventos **internos** (`AssinantesConfirmados`, `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada`) ficam só na trilha de auditoria e na saga e não vão à outbox; (4) `StatusJornadaAtualizado` e `AlertaGerenteEmitido` são materializados como **upsert** no Salesforce (04 §11.4), não como eventos de outbox nesta entrega.

### 5.2 Envelope padrão

| Campo | Descrição |
|---|---|
| `idEvento` | UUID único do evento (chave primária de deduplicação) |
| `tipoEvento` / `versaoSchema` | Nome no passado + versão do esquema (evolução compatível) |
| `ocorridoEm` | Instante do fato no produtor |
| `idAgregado` / `versaoAgregado` | Ex.: `idAdesao` e versão sequencial, para ordenação por agregado |
| `correlationId` | Correlação **técnica**: valor do cabeçalho `X-Correlation-ID` recebido (ou gerado pelo COMP-01), propagado ponta a ponta (04 §9.3) |
| `chaveCorrelacaoNegocio` | Correlação **de negócio**: `codigoProtocolo` quando existir; antes disso, `idAdesao` (PRM-CON-12) |
| `causationId` | `idEvento` ou id do comando/callback que causou o evento |
| `idProposta` | Chave comercial para a projeção no Salesforce |
| `produtor` | BC produtor (ex.: `adesao-termo`) |

> **Refinado em `05-especificacoes-tecnicas.md` DT-08 (§17 I-02):** a v0.1 deste documento usava um único `correlationId` com a chave de negócio, enquanto o 04 §9.3 usava o `X-Correlation-ID` técnico. O envelope passa a ter os **dois campos** acima.

### 5.3 Garantias de entrega e idempotência

- **Outbox transacional (PRI-05, INV-10):** estado do agregado e evento gravados na **mesma transação**; um relay publica depois. Nada é publicado sem o estado estar persistido, e nenhum estado fica sem o evento.
- **At-least-once:** o relay reenvia até confirmar. Os consumidores devem ser **idempotentes**: registram `idEvento` processado e aplicam a chave de negócio da tabela 5.1 (`codigoProtocolo`, `idAdesao` + `versaoAgregado`, `numeroConvenio`).
- **Ordem:** garantida **por agregado** (`versaoAgregado`); consumidores descartam versões antigas (projeção monotônica no BC-03).
- **Entradas externas idempotentes:** callback do GACD deduplicado por `codigoProtocolo` + tipo de sinal; API de alerta do Canal por `codigoProtocolo` + `idNotificacaoCanal`. ACK só depois de persistir estado + outbox (PRI-06).
- **Falhas:** retentativa com backoff; após N tentativas, a mensagem vai para estacionamento (parking) com alerta operacional e `AlertaGerenteEmitido` quando afeta o Gerente.
- **Transporte:** o `stack-tech.md` não cita broker de mensagens. Com BC-01 e BC-03 no mesmo serviço, o relay entrega in-process e faz push REST para o Salesforce (PRM-DDD-06). Extrair contextos exige broker corporativo **[ABERTO: QA-DDD-05]**.

### 5.4 Fluxo de eventos ponta a ponta

```mermaid
sequenceDiagram
  autonumber
  actor GC as Gerente de Cash
  participant SF as Salesforce (BC-05)
  participant B1 as BC-01 Adesão ao Termo
  participant OB as Outbox (BC-01/BC-03)
  participant B2 as BC-02 Geração do Termo
  participant B3 as BC-03 Acompanhamento
  participant FIRP as FIRP (BC-06)
  participant GACD as GACD (BC-07)
  participant CAN as Canal Digital PJ (BC-10)
  participant CONV as BC-04 Convênio (indefinido)
  actor EXE as Executor da implantação (Gerente de Cash ou backoffice)
  participant DBX as Databricks Tarifas (BC-11)

  Note over B1,GACD: Chamadas a FIRP e GACD via Axway API Gateway - token LEAP (hipótese)
  GC->>SF: Solicita Termo de Adesão da Proposta aprovada
  SF->>B1: SolicitarTermoAdesao (idProposta, cnpj, produtos)
  B1->>B1: Política de elegibilidade e tipo de termo
  alt Contrato vigente
    B1->>OB: AdesaoDispensada (mesma transação)
  else Termo requerido
    B1->>OB: TermoSolicitado (mesma transação do estado Solicitado)
    B1-->>SF: Aceite com idAdesao
    B1->>FIRP: Consulta assinantes e poderes (ACL-FIRP)
    FIRP-->>B1: Representantes com poderes
    B1->>OB: AssinantesIdentificados
    B1->>B2: GerarDocumentoTermo (tipo, dados, produtos, assinantes)
    B2-->>B1: PDF base64, versaoModelo, hash
    B1->>OB: TermoGerado
    B1->>GACD: Passo 1 Coordenar Contrato (assinantes, endpoint de callback)
    GACD-->>B1: codigoProtocolo
    B1->>GACD: Passo 2 Armazenar Prévia (PDF base64)
    GACD-->>B1: IdPrevia e CaminhoPrevia
    B1->>GACD: Passo 3 Coordenar Regra
    GACD-->>B1: Regras confirmadas
    B1->>OB: TermoEnviadoParaAssinatura (codigoProtocolo)
  end
  OB-->>B3: Relay entrega eventos (at-least-once)
  B3->>B3: Projeta visão da jornada (idempotente por idEvento)
  B3->>SF: StatusJornadaAtualizado (push via outbox de saída)
  SF-->>GC: Status em tempo real

  CAN->>GACD: Busca pendências do cliente
  CAN->>FIRP: Revalida assinantes
  alt Assinantes válidos
    CAN->>GACD: Registra assinatura
    GACD->>B1: Callback assinatura concluída (codigoProtocolo)
    B1->>B1: ACL-Callback deduplica e valida protocolo vigente
    B1->>OB: AssinaturaConcluida (mesma transação do estado Assinado)
    B1-->>GACD: ACK
    OB-->>B3: AssinaturaConcluida
    B3->>SF: StatusJornadaAtualizado - Assinado
    opt Implantação do produto - por produto (QA-CON-02, QA-CON-03 e QA-CON-24)
      Note over OB,CONV: A assinatura abre a implantação - não cria o convênio
      OB-->>CONV: AssinaturaConcluida ou AdesaoDispensada
      CONV->>CONV: ConvenioSolicitado por produto (EVN-13 Implantação iniciada)
      CONV-->>B3: ConvenioSolicitado
      B3->>SF: StatusJornadaAtualizado - Em implantação
      SF-->>EXE: Pendência de implantação
      EXE->>CONV: Define parâmetros com o cliente e cria o convênio em teste
      Note over CONV,EXE: Homologação com o cliente - remessa e retorno de teste até funcionar
      EXE->>CONV: Ativa o convênio após a homologação (RN-17)
      CONV-->>DBX: ConvenioAtivado (numeroConvenio)
      CONV-->>B3: ConvenioAtivado
      B3->>SF: StatusJornadaAtualizado - Convênio ativo
      DBX-->>B3: TarifasCadastradas
      B3->>SF: StatusJornadaAtualizado - Tarifas cadastradas
    end
  else Assinantes inválidos - contrato a combinar com Canais (QA-CON-08)
    CAN->>B1: Notifica assinantes inválidos (API de alerta, codigoProtocolo)
    B1->>B1: ACL-Alerta deduplica e valida estado Aguardando assinatura
    B1->>OB: AssinantesInvalidados (mesma transação)
    B1-->>CAN: Recebimento confirmado
    OB-->>B3: AssinantesInvalidados
    B3->>SF: AlertaGerenteEmitido e status Assinantes inválidos
    SF-->>GC: Alerta para regularizar poderes e reemitir
    GC->>SF: Reemitir termo
    SF->>B1: ReemitirTermo (idAdesao)
    B1->>OB: ReemissaoSolicitada (volta a Solicitado, nova consulta FIRP e novo protocolo)
  end
```

Leitura do diagrama:

- Os passos 1 a 3 no GACD e o callback são **[FATO: 04]**; a consulta FIRP pelo Atacado e o callback no ARO Atacado são **[FATO: CG]**.
- "Outbox" representa a tabela de outbox do serviço do Atacado; o relay é o mesmo mecanismo que entrega ao BC-03 e, a partir dele, ao Salesforce (PRM-DDD-06).
- Cancelamento do protocolo anterior no GACD na reemissão: **[ABERTO: QA-DDD-02]**.
- O bloco de Convênio e Tarifas é **ilustrativo** (opção A/B de 4.3). A implantação (parâmetros, convênio em teste, homologação com o cliente e ativação) é executada por pessoas — Gerente de Cash ou backoffice **[ABERTO: QA-CON-24]** — e o tempo de homologação depende do cliente **[PREMISSA: PRM-CON-15 — padrão de mercado]**. Onde a pendência nasce (Salesforce, BC-04 ou sistema do produto) depende da opção de 4.3.

### 5.5 Tradução de sinais externos em eventos de domínio

| Sinal externo | Origem | ACL | Evento de domínio | Regra aplicada |
|---|---|---|---|---|
| Retorno da FIRP com representantes | BC-06 | ACL-FIRP | `AssinantesIdentificados` ou `GeracaoDoTermoFalhou` (sem assinantes / indisponível) | RN-05, INV-05 **[ABERTO: QA-DDD-12]** |
| Retornos dos passos 1–3 | BC-07 | ACL-GACD | `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada` → `TermoEnviadoParaAssinatura` | INV-06 |
| Falha em um dos passos 1–3 | BC-07 | ACL-GACD + saga | `GeracaoDoTermoFalhou` (após compensação) | **[ABERTO: QA-CON-16]** |
| Callback "assinatura concluída" | BC-07 | ACL-Callback | `AssinaturaConcluida` | RN-08, INV-07 |
| Callback de recusa/expiração (se existir) | BC-07 | ACL-Callback | `TermoEncerrado` | **[ABERTO: QA-CON-12]** |
| Notificação de assinantes inválidos | BC-10 | ACL-Alerta | `AssinantesInvalidados` | RN-06, RN-07, INV-08 |

---

## 6. Máquina de estados do agregado `AdesaoTermo`

Estados canônicos (01 §7.4; 02 §3.3.6). "Não requerido", "Em implantação", "Convênio ativo" e "Tarifas cadastradas" são status **da jornada** (BC-03), não estados do Termo (PRI-12). Os estados do convênio (Em teste → Ativo) pertencem ao `Convenio` do BC-04 (3.5).

```mermaid
stateDiagram-v2
  state "Solicitado" as Solicitado
  state "Assinantes identificados" as AssinantesIdentificados
  state "Gerado" as Gerado
  state "Aguardando assinatura" as AguardandoAssinatura
  state "Assinantes inválidos" as AssinantesInvalidos
  state "Assinado" as Assinado
  state "Falha na geração" as FalhaNaGeracao
  state "Encerrado (recusado / expirado / cancelado)" as Encerrado

  [*] --> Solicitado: SolicitarTermoAdesao / TermoSolicitado
  Solicitado --> AssinantesIdentificados: AssinantesIdentificados
  Solicitado --> FalhaNaGeracao: GeracaoDoTermoFalhou (FIRP ou sem assinantes)
  AssinantesIdentificados --> Gerado: TermoGerado
  AssinantesIdentificados --> FalhaNaGeracao: GeracaoDoTermoFalhou (documento)
  Gerado --> AguardandoAssinatura: TermoEnviadoParaAssinatura
  Gerado --> FalhaNaGeracao: GeracaoDoTermoFalhou (GACD após compensação)
  AguardandoAssinatura --> Assinado: AssinaturaConcluida (callback GACD)
  AguardandoAssinatura --> AssinantesInvalidos: AssinantesInvalidados (alerta do Canal)
  AguardandoAssinatura --> Encerrado: TermoEncerrado
  AssinantesInvalidos --> Solicitado: ReemissaoSolicitada
  FalhaNaGeracao --> Solicitado: ReemissaoSolicitada (nova tentativa)
  AssinantesInvalidos --> Encerrado: TermoEncerrado (cancelado)
  FalhaNaGeracao --> Encerrado: TermoEncerrado (cancelado)
  Assinado --> [*]
  Encerrado --> [*]
```

| De | Para | Comando / sinal | Evento | Guarda | Base |
|---|---|---|---|---|---|
| — | Solicitado | `SolicitarTermoAdesao` | `TermoSolicitado` | Proposta aprovada; sem contrato vigente; sem outro termo não terminal no CNPJ | RN-02, RN-04, INV-01, INV-02 |
| Solicitado | Assinantes identificados | Retorno FIRP | `AssinantesIdentificados` | Lista não vazia | RN-05, INV-05 |
| Solicitado | Falha na geração | Erro FIRP ou nenhum assinante | `GeracaoDoTermoFalhou` | — | 02 §3.3.6; QA-DDD-12 |
| Assinantes identificados | Gerado | `GerarTermo` (após `ConfirmarAssinantes`, se adotado) | `TermoGerado` | Modelo vigente para o tipo | INV-04, DEC-CON-07 |
| Assinantes identificados | Falha na geração | Erro no BC-02/IMPD | `GeracaoDoTermoFalhou` | — | **[PROPOSTA DDD]** refina 02 |
| Gerado | Aguardando assinatura | Saga concluiu os 3 passos | `TermoEnviadoParaAssinatura` | `codigoProtocolo` presente | INV-06 **[FATO: 04]** |
| Gerado | Falha na geração | Falha em passo do GACD após compensação | `GeracaoDoTermoFalhou` | — | **[PROPOSTA DDD]**; QA-CON-16 |
| Aguardando assinatura | Assinado | Callback do GACD | `AssinaturaConcluida` | Protocolo vigente | RN-08, INV-07 |
| Aguardando assinatura | Assinantes inválidos | Alerta do Canal | `AssinantesInvalidados` | Protocolo vigente | RN-06, RN-07, INV-08 |
| Aguardando assinatura | Encerrado | Recusa/expiração (GACD) ou cancelamento (Gerente) | `TermoEncerrado` | — | EVN-12 **[ABERTO: QA-CON-12, QA-NEG-11, QA-NEG-12]** |
| Assinantes inválidos / Falha na geração | Solicitado | `ReemitirTermo` | `ReemissaoSolicitada` | Protocolo anterior tratado (QA-DDD-02) | 02 §3.3.6 |
| Assinantes inválidos / Falha na geração | Encerrado | `EncerrarTermo` (cancelado) | `TermoEncerrado` | — | **[PROPOSTA DDD]** PRM-DDD-10 |

> Refinamentos em relação ao 02: as falhas passam a sair do estado em que ocorrem (Solicitado, Assinantes identificados ou Gerado), e não só de Solicitado; e o cancelamento pode ocorrer a partir de Assinantes inválidos e de Falha na geração. Os estados canônicos não mudam (PRM-DDD-10).
>
> **Refinado no 04 (ADR-02) e no `05-especificacoes-tecnicas.md` §7 (§17 I-11, I-12):** a confirmação do Gerente deixa de ocorrer entre Assinantes identificados e Gerado e passa a ser **única (assinantes + prévia do PDF) no estado Gerado** (`POST …/confirmacao-envio`, evento interno `AssinantesConfirmados`); a saga do GACD só começa depois dela. O 05 propõe ainda a transição **T-17 Gerado → Encerrado (cancelado)**, para o Gerente desistir antes do envio (DT-16, **[PROPOSTA]** compatível com PRM-DDD-10).

---

## 7. Mapeamento BC → Times e Team Topologies (premissa)

### 7.1 Donos por contexto

| BC | Time dono | Times de apoio | Observação |
|---|---|---|---|
| BC-01 Adesão ao Termo | Atacado Cash Payments | GACD (onboarding, callback), Canais (contrato de alerta), Experiência (jornada do Gerente) | Core; único contexto em que o Atacado concentra regra de negócio nova |
| BC-02 Geração do Termo | Atacado Cash Payments | IMPD (template/esteira), Jurídico/Compliance (conteúdo) | Conteúdo jurídico: QA-CON-19 |
| BC-03 Acompanhamento da Jornada | Atacado Cash Payments | Experiência (alertas e visão no Salesforce) | — |
| BC-04 Gestão de Convênios | **Indefinido** (Atacado Cash Payments decide) | Open Cash Hub / donos de sistemas legados; executor da implantação (Gerente de Cash ou backoffice) | QA-CON-02, QA-CON-24, QA-CON-25 |
| BC-05 Salesforce | Atacado Cash Payments | Experiência | Configuração da jornada no SaaS |
| BC-06 FIRP | Dono da FIRP | — | Plataforma consumida |
| BC-07 GACD / BC-08 GCC/Filenet | Time do GACD | — | Plataforma consumida |
| BC-09 IMPD | Dono do IMPD | — | Plataforma consumida (candidato) |
| BC-10 Canal Digital PJ | Time de Canais | Experiência | Externo ao Atacado |
| BC-11 Tarifas (Databricks) | Atacado Cash Payments (PRM-CON-14) | Plataforma de dados | Fora do escopo de evolução |
| BC-12 Open Cash Hub / BC-13 Registro de Contratos | Não identificado | — | QA-CONV-09, QA-CON-21 |

### 7.2 Team Topologies simplificado

| Time | Tipo (Team Topologies) | Modo de interação com o Atacado | Justificativa |
|---|---|---|---|
| **Time do Atacado Cash Payments** | **Stream-aligned** (fluxo: adesão a produtos Cash) | — | Dono do fluxo de valor ponta a ponta do Gerente de Cash (Salesforce + ARO Atacado) |
| **Time de Canais** | **Stream-aligned** (fluxo: experiência digital do Cliente PJ Atacado) | **Collaboration temporária** para fechar a API de alerta (R-13) e o sinal de adesão ao canal (QA-DDD-09); depois X-as-a-Service | Dois fluxos distintos que se tocam em pontos de contrato |
| **Time de Experiência** | **Enabling** | **Facilitating** para Atacado (jornada do Gerente) e Canais (jornada do cliente) | Não é dono de BC (PRM-DDD-09); escopo em QA-NEG-15 |
| **Time do GACD** | **Platform** | **X-as-a-Service** (com Collaboration no onboarding, QA-NEG-19) | Serviço corporativo com vários consumidores |
| FIRP | **Platform** | X-as-a-Service | Serviço corporativo |
| IMPD | **Platform** (com traço de *complicated-subsystem* pela especialidade CSF Designer) | X-as-a-Service + Facilitating na criação do template | Competência de nicho **[FATO: 05]** |
| Plataformas Funcionais (ARO Atacado, Axway, Hub and Spoke) | **Platform** | X-as-a-Service | Hospedagem e rede; não possui BC de negócio |

> Premissa (PRM-DDD-09): classificação simplificada, sem validação com os times. O ponto de atenção é o Atacado depender de **dois** times com backlog próprio (Canais e GACD) no caminho crítico da jornada.

---

## 8. Recomendação de fronteiras de implantação (indicativa)

> A decisão final é do Desenho de Arquitetura de Solução (documento 04). Esta seção propõe um ponto de partida e as regras para não fragmentar demais.
>
> **Nota de consolidação (Rodada 2):** o documento 04 (ADR-01) refinou esta recomendação em **três deployables**: COMP-01 `atacado-adesao-termo` (BC-01 + BC-02, com os módulos `adesao-termo`, `acl-firp`, `acl-gacd`, `termo-documento`, `acl-registro-contratos`, `convenio-produto`), COMP-02 `atacado-adesao-receptor` (borda de entrada do BC-01, que recebe o callback do GACD e o alerta do Canal) e COMP-03 `atacado-adesao-acompanhamento` (BC-03 completo, que absorve a DU-02 `adesao-outbox-relay`). O módulo de convênio abaixo usa o nome definitivo `convenio-produto` (antes `convenio-gateway`). Ver 04-desenho-arquitetura-solucao.md §17.

### 8.1 Proposta

| Unidade de implantação | Conteúdo (BCs / sub-blocos do 02) | Forma | Justificativa |
|---|---|---|---|
| **DU-01 `adesao-termo`** | BC-01 completo (APP-02.1, 02.2, 02.3, 02.4, 02.6, 02.7) + **BC-02 como módulo** (APP-03, lado Atacado) + **BC-03 como módulo** (projeção) | **1 microsserviço Java** no ARO Atacado (`atacado-core`), monólito modular com um pacote por BC | Um time, uma transação para estado + outbox, volume baixo (termos por dia, não por segundo), sem broker confirmado. A saga do GACD fica local, sem transação distribuída |
| **DU-02 `adesao-outbox-relay`** (opcional) | Relay da outbox e entrega ao Salesforce (APP-02.5) | **Mesmo código e mesma imagem**, executado como processo separado (perfil *worker*) | Isola falhas e limites de API do Salesforce da recepção de callbacks. **Não** é um novo contexto nem um novo microsserviço de domínio |
| **BC-04 Convênio** | — | **Não implantar** antes de QA-CON-02. Opção B/C: módulo `convenio-produto` (ACL + `SolicitacaoConvenio`) dentro da DU-01 (COMP-01.6 no 04). Opção A: candidato a **segundo microsserviço** `atacado-convenio-produto` (COMP-31 no 04). Em qualquer opção, o módulo abre a pendência de implantação e acompanha o status; não cria o convênio sozinho na assinatura | Só vira serviço próprio se tiver sistema de registro, consumidores (Tarifas, Salesforce) e ciclo de vida próprios |
| Contextos externos | BC-05..BC-13 | Consumidos via Axway (FIRP, GACD), API cloud (IMPD) ou SaaS (Salesforce) | Nada a implantar pelo Atacado além de adaptadores |

```mermaid
flowchart LR
  SF["Salesforce"]
  CAN["Canal Digital PJ"]
  GACD["GACD"]
  FIRP["FIRP"]
  IMPD["IMPD API cloud"]
  subgraph NS["ARO Atacado - namespace atacado-core"]
    subgraph DU1["DU-01 adesao-termo - microsserviço Java"]
      M1["BC-01 Adesão ao Termo<br/>API Adesão, ACL-FIRP, ACL-GACD,<br/>ACL-Callback, ACL-Alerta, saga"]
      M2["BC-02 Geração do Termo<br/>módulo"]
      M3["BC-03 Acompanhamento<br/>módulo de projeção"]
      M4["convenio-produto<br/>módulo - se opção B ou C<br/>pendência de implantação"]
    end
    DU2["DU-02 adesao-outbox-relay<br/>worker - mesmo código"]
    DB[("PostgreSQL<br/>schemas por BC + outbox<br/>PRM-CON-05")]
  end
  SF -->|"API Adesão"| M1
  CAN -->|"API de alerta"| M1
  GACD -->|"callback"| M1
  M1 --> FIRP
  M1 --> GACD
  M1 --> M2
  M2 --> IMPD
  M1 --> DB
  M3 --> DB
  M4 --> DB
  DB --> DU2
  DU2 -->|"status e alertas"| SF
```

### 8.2 Regras para não fragmentar demais

- **Não criar um microsserviço por sub-bloco do 02** (APP-02.1..02.7). São sete responsabilidades de um mesmo contexto; separá-las geraria serviços anêmicos, transações distribuídas para cada transição de estado e acoplamento por chamadas síncronas.
- **Não criar microsserviço por ACL** ("firp-service", "gacd-service"): a ACL pertence ao BC-01 e muda junto com ele.
- **BC-02 e BC-03 não justificam implantação própria**: pouca lógica, mesmo time, mesma cadência de release e dependência total dos eventos do BC-01.
- **Fronteiras lógicas explícitas dentro do monólito modular:** um pacote por BC, dependências verificadas por teste de arquitetura, **um schema por BC** no mesmo PostgreSQL, sem joins entre schemas e comunicação entre módulos apenas por interfaces públicas ou eventos. Isso mantém a extração futura barata.
- **Endpoints de entrada separados por consumidor** (Salesforce, Canal, GACD) na mesma aplicação, com políticas distintas no Axway, para não misturar autenticação e limites.

### 8.3 Critérios para extrair um contexto no futuro

| Gatilho | Contexto a extrair |
|---|---|
| Outros produtos do Atacado passam a usar o GACD (OP-01, OP-02) | ACL-GACD + recepção de callback → serviço genérico interno `aceite-digital-atacado` (Generic interno reutilizável) |
| Decisão pela opção A de convênio (4.3) | BC-04 → `convenio-produto` |
| Geração própria de documentos com cadência de release de templates distinta (DEC-CON-03 b) | BC-02 → `termo-documento` |
| Rota externa do callback (DEC-CON-04 b) ou requisitos de isolamento/escala distintos | Recepção de callback como borda dedicada |
| Outro time assume um contexto | O contexto que muda de dono |

---

## 9. Questões em aberto e premissas de DDD

### 9.1 Questões em aberto (QA-DDD)

Só questões novas de modelagem; as de negócio e conceituais continuam nos documentos 01 e 02 e são referenciadas.

| ID | Questão | Referências | Time responsável | Impacto |
|---|---|---|---|---|
| QA-DDD-01 | **Identidade e unicidade do agregado:** um `AdesaoTermo` por solicitação (com reemissões) ou um por Cliente PJ Atacado? Um termo já assinado impede nova solicitação? Unicidade por CNPJ ou por raiz? | QA-NEG-16, QA-CON-22, RN-16 | Atacado Cash Payments | INV-01, identidade do agregado |
| QA-DDD-02 | **Reemissão:** o mesmo agregado com novo `codigoProtocolo`? O protocolo anterior precisa ser cancelado no GACD, e existe API para isso? | QA-CON-16, QA-NEG-12 | GACD (com Atacado Cash Payments) | Saga, INV-07, máquina de estados |
| QA-DDD-03 | **Vocabulário de status do GACD:** quais sinais existem além de "assinatura concluída" (recusa, expiração, assinatura parcial em conjunta) e como mapeá-los para os estados canônicos | QA-CON-12, QA-NEG-11 | GACD | ACL-Callback, Encerrado |
| QA-DDD-04 | **Resolução de assinantes:** o GACD já consulta a FIRP por conta própria? Se sim, a ACL-FIRP do BC-01 serve só para exibir/confirmar (ou é dispensável) | QA-CON-15, R-04, R-08 | GACD | Fronteira BC-01 × BC-06 |
| QA-DDD-05 | **Mensageria:** existe broker corporativo (ex.: Azure Service Bus, Kafka, Event Grid) disponível para o ARO Atacado? Sem ele, eventos ficam intra-serviço e a entrega externa é por REST | PRM-CON-05, stack-tech | Atacado Cash Payments (arquitetura) com Plataformas Funcionais | R-14, R-15, seção 8 |
| QA-DDD-06 | **Posse da abertura da implantação:** coreografia (BC-04 assina `AssinaturaConcluida`) ou orquestração pelo BC-01? Onde nasce a pendência de implantação (Salesforce, BC-04 ou sistema do produto) e quem guarda o estado "Convênio pendente"? | QA-CON-02, QA-CON-03, QA-CON-24, QA-CONV-02, QA-CONV-11 | Atacado Cash Payments | R-15, BC-04 |
| QA-DDD-07 | **Catálogo de Produto Cash:** existe sistema de referência de códigos de produto que sirva de Published Language comum a Salesforce, BC-04 e Databricks? | QA-CON-06, QA-NEG-08 | Atacado Cash Payments | `ProdutoAderido`, R-16 |
| QA-DDD-08 | **Semântica e minimização da API de alerta:** o alerta invalida o protocolo inteiro ou só alguns assinantes? Leva só `codigoProtocolo` + motivo ou a lista de assinantes (dados pessoais)? | QA-CON-08, QA-CON-09, RNFN-05 | Canais | R-13, ACL-Alerta |
| QA-DDD-09 | **Adesão ao canal (Termo de Adesão – Produtos + Canal):** quem publica "termo assinado" para Canais efetivar o acesso — GACD (que o Canal já consome) ou `AssinaturaConcluida` do BC-01 (novo contrato)? | QA-NEG-13, QA-CON-11 | Canais | Consumidores de `AssinaturaConcluida` |
| QA-DDD-10 | **Onde fica a regra de elegibilidade e tipo de termo:** no Salesforce (como no 02, CAP-02.1/02.2) ou no BC-01 (proposta deste documento)? | QA-CON-21, PRM-NEG-13 | Atacado Cash Payments | Fronteira do core, R-19 |
| QA-DDD-11 | **Interface do Databricks (Tarifas):** como recebe convênios ativos e como sinaliza `TarifasCadastradas` (evento, tabela, arquivo)? | QA-CONV-10, PRM-CON-14 | Atacado Cash Payments (Tarifas) | R-16, R-18 |
| QA-DDD-12 | **"Nenhum assinante encontrado" na FIRP:** tratar como Falha na geração (motivo de negócio) ou criar um estado próprio de pendência de regularização? | QA-NEG-03 | Atacado Cash Payments com Experiência | Máquina de estados |
| QA-DDD-13 | **Guarda do documento no BC-01:** manter apenas hash + `IdPrevia`/`CaminhoPrevia` ou uma cópia? Como o Gerente acessa o termo assinado (via GACD)? | QA-NEG-17, QA-CON-17 | GACD | `DocumentoTermo`, RNFN-04 |
| QA-DDD-14 | **Sinal de convênio ativo:** como o BC-04 fica sabendo que o executor criou o convênio em teste e o ativou após a homologação — registro manual no Salesforce, evento do sistema do produto ou consulta periódica? | QA-CON-02, QA-CON-24, QA-CON-25, RN-17 | Atacado Cash Payments | `ConvenioAtivado`, `ConvenioPendente`, R-15, R-18 |

### 9.2 Premissas (PRM-DDD)

| ID | Premissa | Impacto se falsa | Validar com |
|---|---|---|---|
| PRM-DDD-01 | A **Adesão a Produtos Cash** (BC-01) é o único core do Atacado nesta iniciativa; os demais contextos internos são supporting | Mais investimento em BC-02/BC-04 | Atacado Cash Payments |
| PRM-DDD-02 | O **GACD é a fonte da verdade** da assinatura; o BC-01 mantém estado **derivado** do Termo, atualizado só por sinais correlacionados (PRI-04) | Conflitos de estado entre GACD e Atacado | GACD |
| PRM-DDD-03 | Um `AdesaoTermo` por solicitação; reemissões no mesmo agregado com histórico de protocolos; no máximo um não terminal por CNPJ (PRM-NEG-05) | Mudança de identidade do agregado (QA-DDD-01) | Atacado Cash Payments |
| PRM-DDD-04 | As ACLs (FIRP, GACD, callback, alerta, IMPD, convênio, contratos) pertencem ao contexto downstream do Atacado e **não** são BCs próprios | Fragmentação em serviços de integração anêmicos | Arquitetura |
| PRM-DDD-05 | Eventos publicados via **outbox transacional** no PostgreSQL (PRM-CON-05), com entrega at-least-once e consumidores idempotentes | Perda ou duplicação de status no Salesforce | Atacado Cash Payments (arquitetura) |
| PRM-DDD-06 | Sem broker confirmado, a comunicação BC-01 → BC-03 é intra-processo (mesma implantação) e a entrega ao Salesforce é push REST (DEC-CON-05 a) | Revisão da seção 8 se houver broker | Plataformas Funcionais |
| PRM-DDD-07 | O comando `SolicitarTermoAdesao` carrega um **snapshot** da Proposta (`idProposta`, CNPJ, produtos); o Salesforce continua sistema de registro da Proposta (PRM-CON-09) | Consultas síncronas do ARO ao Salesforce durante a jornada | Atacado Cash Payments |
| PRM-DDD-08 | Dados pessoais de assinantes no BC-01 limitados ao mínimo (id FIRP, nome, papel); documento de identificação não trafega em eventos (RNFN-05) | Exposição LGPD em eventos e logs | Atacado Cash Payments com Jurídico/Compliance |
| PRM-DDD-09 | Classificação de Team Topologies da seção 7.2; Experiência como enabling team, sem posse de BC | Revisão de donos e interfaces | Experiência, Canais |
| PRM-DDD-10 | As transições adicionais da máquina de estados (falhas a partir de Assinantes identificados e Gerado; cancelamento a partir de Assinantes inválidos e Falha na geração) são proposta e **não** alteram os estados canônicos (refina PRM-CON-13) | Ajuste do modelo de status com o GACD | GACD, Atacado Cash Payments |
| PRM-DDD-11 | A **abertura da implantação** é **coreografada** por `AssinaturaConcluida` / `AdesaoDispensada` (derivado de PRM-NEG-17 e das hipóteses de QA-CONV-02/03); a ativação do convênio (`ConvenioAtivado`) depende da homologação com o cliente e do executor humano (PRM-CON-15), não do evento | Orquestração pelo BC-01 ou abertura manual da pendência pelo Gerente | Atacado Cash Payments |

### 9.3 Questões existentes que mais afetam as fronteiras

| Questão | BC/relação afetada | Efeito possível |
|---|---|---|
| QA-CON-01 / QA-NEG-01 (GACD × Open Cash Hub) | R-05, R-06, R-20 | Troca da ACL do BC-01; R-01 e R-02 inalteradas (PRI-13) |
| QA-CON-02, QA-CON-03, QA-CON-04 / QA-CONV-01..04 | BC-04, R-15, R-16 | Define se o BC-04 é construído, adaptado ou consumido |
| QA-CON-24 / QA-CONV-12 (executor da implantação); QA-CON-25 / QA-CONV-13 (produtos com homologação e área de implantação) | BC-04, R-15, R-18 | Define quem atende a pendência de implantação e onde ela aparece; não muda o contrato de eventos |
| QA-CON-05 / QA-CONV-07 (ordem convênio × tarifas) | R-16 | Inverte dependência BC-04 × BC-11 |
| QA-CON-08 / QA-NEG-04 (API de alerta) | R-13 | Contrato OHS/PL ou alternativa via GACD |
| QA-CON-12 (callback) | R-06, máquina de estados | Estados Encerrado e ACL-Callback |
| QA-CON-15 (FIRP) | R-04 | Mantém ou dispensa ACL-FIRP |
| QA-CON-21 / QA-NEG-14 (contrato vigente) | R-19, `PoliticaElegibilidade` | Nova ACL ou regra no Salesforce |
| DEC-CON-03 (geração do PDF) | R-10, BC-02 | Conformist ao IMPD ou Separate Ways |
| DEC-CON-07 (estilo de orquestração) | BC-01, saga | Confirmar assinantes como etapa com o Gerente ou fluxo automático |

---

## 10. Glossário da linguagem ubíqua

| Termo | Contexto | Definição |
|---|---|---|
| **Adesão (AdesaoTermo)** | BC-01 | Agregado que representa a formalização de um Cliente PJ Atacado aos produtos Cash de uma Proposta por meio de um Termo de Adesão; identificado por `idAdesao` |
| **Adesão dispensada** | BC-01 / BC-03 | Resultado da elegibilidade quando há contrato vigente; nenhum Termo é criado; exibido como "Não requerido" |
| **Agregado** | DDD | Conjunto de objetos tratado como unidade de consistência, acessado pela raiz |
| **Alerta ao Gerente** | BC-03 | Aviso acionável no Salesforce (assinantes inválidos, falhas) |
| **Anticorruption Layer (ACL)** | DDD | Camada que traduz o modelo de um contexto externo para a linguagem do contexto consumidor |
| **ARO Atacado** | Plataforma | Azure RedHat OpenShift do Atacado; namespace `atacado-core`; domínio Plataformas Funcionais; vNet spoke em Hub and Spoke |
| **Assinante** | BC-01 | Representante do Cliente PJ Atacado com poderes na FIRP, apto a assinar o termo (snapshot mínimo) |
| **Assinantes inválidos** | BC-01 | Estado em que o Canal detectou, na revalidação, que os assinantes não têm mais poderes |
| **Axway API Gateway** | Plataforma | Gateway corporativo pelo qual FIRP e GACD expõem APIs e pelo qual entram callback e alerta |
| **Backoffice de Cash** | BC-04 | Candidato a executor da implantação do produto (ATR-09), no lugar do Gerente de Cash **[ABERTO: QA-CON-24]** **[PREMISSA: PRM-CON-15 — padrão de mercado]** |
| **Bounded Context (BC)** | DDD | Fronteira dentro da qual um modelo e sua linguagem são consistentes |
| **Callback** | BC-07 → BC-01 | Notificação do GACD ao endpoint informado no passo 1, recebida no ARO Atacado |
| **Canal Digital PJ** | BC-10 | Canal do cliente (BGS + PDPJ), abstraído (sinônimo aceito só na primeira menção: "Canal Digital do Cliente"); responsabilidade do Time de Canais |
| **`codigoProtocolo`** | BC-07 / BC-01 | Identificador do protocolo de assinatura no GACD; chave de correlação e idempotência |
| **Cliente PJ Atacado** | Todos | Empresa contratante sem contrato vigente que adere aos produtos Cash |
| **Contrato (GACD)** | BC-07 | Processo/documento coordenado para assinatura; no BC-01 corresponde ao `ProtocoloAssinatura` |
| **Contrato vigente** | BC-13 / BC-01 | Contrato de Cash existente que dispensa o Termo de Adesão (RN-02) |
| **Convênio** | BC-04 | Registro por produto no sistema do produto, criado na implantação aberta pela assinatura (ou pelo contrato vigente); nasce em teste e fica ativo após a homologação (RN-17); pré-requisito do cadastro de tarifas |
| **Convênio ativo / em teste** | BC-04 | Estados do convênio: **Em teste** durante a homologação com o cliente; **Ativo** após a ativação pelo executor (EVN-10), o que libera as tarifas |
| **Convênio pendente** | BC-04 / BC-03 | Exceção: implantação ou homologação com falha ou atraso, com alerta ao Gerente (QA-CONV-11) |
| **Customer/Supplier (C/S)** | DDD | Relação em que o upstream considera as necessidades do downstream no planejamento |
| **Conformist** | DDD | O downstream adota o modelo do upstream sem tradução relevante |
| **Databricks (Tarifas)** | BC-11 | Pipeline existente de cadastro de tarifas negociadas |
| **Documento do Termo** | BC-02 | PDF base64 gerado a partir de um modelo versionado, com hash e versão do modelo |
| **Elegibilidade** | BC-01 | Política que decide entre termo requerido e adesão dispensada |
| **Encerrado** | BC-01 | Estado terminal sem assinatura: recusado, expirado ou cancelado |
| **Estado do Termo** | BC-01 | Um dos estados canônicos: Solicitado, Assinantes identificados, Gerado, Aguardando assinatura, Assinantes inválidos, Assinado, Falha na geração, Encerrado |
| **Evento de domínio** | DDD | Fato de negócio ocorrido, nomeado no passado (ex.: `AssinaturaConcluida`) |
| **Executor da implantação** | BC-04 | Gerente de Cash ou backoffice (a definir — QA-CON-24) que cria, homologa e ativa o convênio; nunca um processo automático |
| **FIRP** | BC-06 | Firmas e Poderes — fonte corporativa de representantes e poderes |
| **GACD** | BC-07 | Serviço corporativo de Aceite Digital: coordenação de contrato, prévia, regras, protocolo e callback |
| **GCC/Filenet** | BC-08 | Repositório de conteúdo onde o GACD armazena a prévia |
| **Gerente de Cash** | BC-05 / BC-01 | Ator do Time do Atacado Cash Payments que solicita e acompanha o Termo no Salesforce; pode executar a implantação do produto (QA-CON-24) |
| **Homologação** | BC-04 | Testes com o cliente (remessa e retorno, ou API) até o convênio funcionar; condição para ativar o convênio (RN-17) **[PREMISSA: PRM-CON-15 — padrão de mercado]** |
| **`IdPrevia` / `CaminhoPrevia`** | BC-07 / BC-01 | Identificador e caminho da prévia no GCC/Filenet |
| **IMPD** | BC-09 | Impressão de Documentos On-line; API cloud `impd-srv-doc-generator`; templates CSF Designer v21 |
| **Implantação (de produto Cash)** | BC-04 | Etapa entre a assinatura (ou contrato vigente) e o convênio ativo: parâmetros com o cliente (layout CNAB ou API, canal de transmissão, contas, carteira), convênio em teste, homologação e ativação (PN-10) **[PREMISSA: PRM-CON-15 — padrão de mercado]** |
| **Modelo do Termo** | BC-02 | Template jurídico versionado de um tipo de termo |
| **Open Cash Hub** | BC-12 | Canal para ERPs com módulo de termos e convênios; alternativa ao GACD e candidato ao convênio |
| **Open Host Service / Published Language (OHS/PL)** | DDD | Contrato público e documentado oferecido pelo upstream a vários consumidores |
| **Outbox** | Mecanismo | Tabela onde o evento é gravado na mesma transação do estado, para entrega posterior garantida |
| **Prévia** | BC-07 | PDF do termo armazenado antes da assinatura |
| **Produto (GACD)** | BC-07 | Sistema/área consumidora do GACD — **não** é Produto Cash |
| **Produto Cash** | BC-01 / BC-04 | Produto de Cash Management / Payments aderido; base do Convênio por produto |
| **Proposta** | BC-05 | Registro no Salesforce com produtos e tarifas negociadas e aprovadas |
| **Protocolo de assinatura** | BC-01 | Value object com `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia` |
| **Reemissão** | BC-01 | Nova tentativa do mesmo Termo após falha ou assinantes inválidos; novo protocolo |
| **Revalidação** | BC-10 | Conferência dos assinantes na FIRP pelo Canal no ato da assinatura (RN-06) |
| **Salesforce** | BC-05 | Salesforce Financial Services Cloud — sistema de engajamento do Gerente de Cash |
| **Saga (processo de envio)** | BC-01 | Coordenação dos 3 passos no GACD com retentativa e compensação |
| **Separate Ways** | DDD | Contextos sem integração, por decisão ou restrição |
| **Status da jornada** | BC-03 | Visão da adesão para o Gerente (Não requerido, Termo em andamento, Termo assinado, Em implantação, Convênio ativo, Tarifas cadastradas, Encerrada; "Convênio pendente" como exceção); não é estado do Termo |
| **Termo de Adesão** | BC-01 | Termo de aceite digital único e multiproduto; tipos "Termo de Adesão – Produtos" e "Termo de Adesão – Produtos + Canal"; exigido só de quem não tem contrato vigente |
| **Tipo de Termo** | BC-01 / BC-02 | `PRODUTOS` (cliente já tem Canal Digital) ou `PRODUTOS_CANAL` (cliente novo) |
| **Token LEAP** | Plataforma | Hipótese de autenticação padrão do banco nas APIs via Axway (não documentada) |
