# 06 — Roadmap de Implementação: Termo de Adesão Multiproduto (Cash Management / Payments)

> Transforma o desenho de solução (`04-desenho-arquitetura-solucao.md`, `04a-componentes-e-justificativas.md`) em um plano de entrega incremental, com fases, marcos, dependências entre times, decisões pendentes, caminho crítico, cenários, rollout e governança.
> Os IDs herdados (CAP-xx, COMP-xx, ADR-xx, RF-xx, RNF-xx, RSK-xx, QA-xxx, PRM-xxx, KPI-xx) não mudam. Os IDs criados aqui são estáveis: **F0..F5** (fases), **M1..M9** (marcos), **D1..D14** (decisões), **PRM-RMP-xx**, **RSK-RMP-xx** e **QA-RMP-xx**.
> **Todas as datas são indicativas e são premissa de planejamento** (PRM-RMP-01). Elas valem até o primeiro checkpoint de replanejamento, no fim da F0 (M2).
> Este documento não contém backlog nem tarefas. O detalhamento em épicos e histórias é feito pelo Time do Atacado Cash Payments a partir das fases.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 06 — Roadmap de Implementação |
| Versão | v0.3 |
| Data | 2026-09-23 (data de referência do planejamento); revisões em 2026-09-24 e 2026-09-27 |
| Status | Rascunho para validação com os times |
| Autor | Arquitetura / Gestão de Programa — Atacado (Cash Management / Payments) |
| Documentos base | `01-contexto-de-negocio.md` (v0.2), `02-desenho-conceitual.md` (v0.2), `03-dominios-bounded-contexts-context-mapping.md` (v0.1), `04-desenho-arquitetura-solucao.md` (v0.1), `04a-componentes-e-justificativas.md` |
| Público | Time do Atacado Cash Payments (inclui Gerente de Cash e PO), Time de Experiência, Time de Canais, Time do GACD; apoio: Plataformas Funcionais, FIRP, IMPD, Segurança, Jurídico/Compliance |
| Horizonte | Outubro/2026 a janeiro/2028 (5 trimestres + medição do KPI de 6 meses) |
| Próxima revisão | No marco M2 (fim da F0), com as decisões D1–D7 tomadas |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: premissas, estratégia, fases F0–F5, Gantt, dependências, decisões, caminho crítico, cenários, rollout, governança, riscos e questões de planejamento |
| v0.2 | 2026-09-24 | Capacidades da F3 explicitam as duas metades do alerta de assinantes inválidos (02 v0.5): CAP-09.5 Recepção de Sinais de Assinantes Inválidos (COMP-02) e CAP-09.2 Alertas ao Gerente (COMP-03). Datas e escopo não mudaram |
| v0.3 | 2026-09-27 | Convênio com **etapa de implantação e homologação** com o cliente, executada pelo Gerente de Cash ou pelo backoffice (`instrucoes-ajustes.md`, item 8; alinhado ao 01 v0.5 e ao 02 v0.7). **D12 passa a incluir quem executa a implantação** (QA-CON-24 / QA-CONV-12), com LRM e regra padrão próprios. Revisados: PRM-RMP-12, §3.2, F0 (escopo), F5 (descrição, escopo, entregáveis, dependências, times, critérios, riscos e KPIs), M8, DEP-22, D12, §9, Onda 4, flag do convênio, métrica de ciclo (§11.3) e §14. Novos **PRM-RMP-14** (M8 = porta ativada e implantação aberta em PRD, não convênio ativo; a homologação depende do cliente e fica fora do cronograma do squad) e **RSK-RMP-13** (tempo de homologação e executor da implantação). **Datas não mudaram.** O conteúdo de mercado entra como **[PREMISSA — padrão de mercado]** |

### 1.1 Convenção de marcação

| Marca | Significado |
|---|---|
| **[PREMISSA: PRM-RMP-xx]** | Suposição de planejamento (seção 2) |
| **[BLOQUEIO: QA-xx]** | Questão em aberto (dos documentos 01–04) que bloqueia a entrada ou a saída de uma fase |
| **[DECISÃO: Dx]** | Decisão pendente do plano de decisões (seção 8) |
| **LRM** | *Last responsible moment*: a data-limite a partir da qual o atraso da decisão passa a mover o cronograma |

---

## 2. Premissas de planejamento

| ID | Premissa | Impacto se falsa |
|---|---|---|
| PRM-RMP-01 | Datas indicativas, derivadas das durações e dependências abaixo. O plano é replanejado no M2 e a cada checkpoint mensal (seção 11) | Datas perdem valor como compromisso; usar só a sequência |
| PRM-RMP-02 | **Capacidade:** 1 squad dedicado do Time do Atacado Cash Payments, com ~9 FTE: PO, tech lead/arquiteto, 4 desenvolvedores Java, 2 desenvolvedores Salesforce, 1 QA, 0,5 DevOps/SRE. Experiência aloca ~0,5 designer da F0 à F2 e sob demanda depois | Com menos capacidade, F3/F4/F5 deixam de se sobrepor e o go-live amplo passa para depois de set/2027 |
| PRM-RMP-03 | **Cadência:** sprints de 2 semanas a partir de 05/10/2026; revisão trimestral do roadmap alinhada ao planejamento trimestral de Canais e GACD | Desalinhamento de janelas de backlog entre times (RSK-RMP-03) |
| PRM-RMP-04 | **Mudança em produção** só com RDM aprovada no comitê de mudanças (CAB semanal), com antecedência mínima de 5 dias úteis para RDM normal. Janelas noturnas em dias úteis. Nada de deploy produtivo no fechamento do mês nem no 5º dia útil (picos de folha e pagamentos de Cash) | Menos janelas; datas de PRD se deslocam em até 1 semana |
| PRM-RMP-05 | **Congelamento de fim de ano:** 14/12/2026 a 15/01/2027 e 13/12/2027 a 14/01/2028. Carnaval (08 a 10/02/2027) com janela restrita | Se o congelamento for maior, M3 e M9 se deslocam |
| PRM-RMP-06 | **Lead times de apoio:** aprovação e provisionamento de PostgreSQL/Blob de 4 a 6 semanas depois da aprovação (QA-TEC-12); liberação de rede de 3 a 4 semanas por pedido (QA-TEC-09); onboarding de novo "Produto" consumidor no GACD de 8 a 10 semanas (QA-NEG-19); template CSF novo no IMPD de 8 a 12 semanas, com terceiros (QA-TEC-02) | Cada semana a mais nesses itens move o caminho crítico (seção 9) |
| PRM-RMP-07 | **Ambientes:** DEV, HML (homologação integrada com GACD, FIRP, IMPD e Canal) e PRD. GACD e FIRP têm HML disponível para o Atacado a partir de jan/2027 | Testes integrados só em PRD controlado (inaceitável para saga e callback) |
| PRM-RMP-08 | **Salesforce:** releases sazonais (Spring em fev, Summer em jun, Winter em out). Não há go-live do Atacado no fim de semana de upgrade da org; os testes de regressão rodam no sandbox *preview* | Regressão no Salesforce no go-live |
| PRM-RMP-09 | **Piloto:** 1 produto Cash, tipo de termo "Produtos", clientes sem contrato vigente que já usam o **PDPJ** (integrado ao GACD); de 5 a 10 Gerentes de Cash selecionados | Piloto com BGS exigiria solução de Canais antes (RSK-15) |
| PRM-RMP-10 | **Relógio do KPI-01** (≥90% via Salesforce em 6 meses) começa no **go-live amplo** (M7), não no piloto, e o denominador exclui clientes que não podem assinar no canal integrado ao GACD enquanto QA-NEG-02 estiver aberta (QA-RMP-01) | Meta de 90% avaliada sobre base que a solução ainda não atende |
| PRM-RMP-11 | **Jurídico/Compliance** aprova o texto de cada modelo de termo em até 4 semanas depois de receber a minuta | Modelo vira item de caminho crítico (RSK-RMP-11) |
| PRM-RMP-12 | **Convênio** não é construído antes da decisão D12 (ADR-11), que inclui **quem executa a implantação** do produto (QA-CON-24 / QA-CONV-12). Até lá só ficam prontos a porta `convenio-produto` desativada e os eventos-gatilho (o termo assinado **abre a implantação**, não cria o convênio) | — (decisão de arquitetura) |
| PRM-RMP-13 | O **processo manual** de termo continua disponível como contingência até o fim da F4 e só é descontinuado por decisão formal (QA-RMP-10) | Sem contingência, o rollback de negócio deixa de existir |
| PRM-RMP-14 | **M8 mede o software, não o convênio ativo.** M8 = porta `convenio-produto` ativada em PRD: pendência de implantação aberta para o executor (Gerente de Cash ou backoffice, visível no Salesforce) e status Em implantação → Convênio ativo acompanhado. A implantação de cada cliente (parâmetros, convênio em teste, homologação de remessa e retorno, ativação) é trabalho de pessoas e depende do cliente; ela acontece caso a caso depois de M8 e não entra no cronograma do squad **[PREMISSA — padrão de mercado]** (PRM-CON-15) | Se o Steering esperar "convênio ativo" em M8, o marco parece atrasado sem ter atrasado; se a implantação precisar de desenvolvimento por cliente, a F5 cresce (RSK-RMP-13) |

---

## 3. Estratégia de entrega

### 3.1 Princípios

1. **Incremental e ponta a ponta cedo.** O primeiro incremento produtivo (F2) já cobre a jornada inteira de um termo — Salesforce → ARO Atacado → FIRP → documento → GACD → callback → status no Salesforce — para um produto e um grupo pequeno de gerentes. Ampliação vem depois, por produto, por gerente e por tipo de termo.
2. **Fase 0 de destravamento com prazo fechado.** A F0 dura 8 semanas e existe para tomar decisões e fechar contratos, não para "esperar". O squad começa a construir o que não depende delas já na 3ª semana (seção 3.2).
3. **Construir contra contratos, não contra times.** Tudo o que o Atacado publica (API Adesão v1, API de alerta v1, eventos da outbox) é contrato OHS/PL do próprio Atacado e sai cedo. O que o Atacado consome (FIRP, GACD, IMPD) entra por ACL com *mock* de contrato até a homologação integrada.
4. **Plano B sempre pronto.** Geração própria do documento (ADR-03), `bytea` para o staging (ADR-04) e alerta de pendência longa como substituto temporário do alerta do Canal (ADR-09) evitam que uma dependência externa pare o go-live.
5. **Flags em vez de branches.** Confirmação do Gerente, renderizador, alerta do Canal, convênio, produto e tipo de termo ficam atrás de *feature flags* (RNF-16). O que está pronto e desligado não bloqueia a release.
6. **Não construir o indefinido.** Convênio (BC-04) só entra depois de D12. "Produtos + Canal" só depois de D13.

### 3.2 O que dá para fazer em paralelo e o que está bloqueado

Leitura crítica: a maior parte do **código** do Atacado não depende das decisões pendentes. O que depende delas é **infraestrutura, conectividade, homologação integrada e go-live**. O risco não é o squad ficar parado. É o squad terminar o código e esperar meses por rede, contrato e HML.

| Frente | Situação | Depende de | Observação |
|---|---|---|---|
| Repositório multi-módulo, esteira CI, padrões (ArchUnit, Flyway, OpenTelemetry) | **Livre** | — | Começa na F0 (semana 3) |
| Domínio BC-01 (agregado `AdesaoTermo`, máquina de estados, invariantes), saga persistida, outbox/inbox, relay | **Livre** | — | PostgreSQL local/Testcontainers. Se D3 trocar o banco, o padrão se mantém |
| API Adesão v1 (contrato próprio) e artefatos Salesforce em sandbox (COMP-06) | **Livre** | D8 só para a UI da prévia | UI começa com *wireframe* de Experiência |
| Contrato "Alerta de Assinantes Inválidos v1" (OpenAPI) | **Livre** | — | Publicar na F0 para Canais planejar (D11) |
| Adaptador de geração própria (Plano B) | **Livre** | Minuta do texto jurídico (D10) | Construído de qualquer forma (ADR-03) |
| ACL FIRP e ACL GACD contra *mock* | **Parcial** | D5, D6 (contratos) | Construir com hipótese; retrabalho esperado de 10–20% |
| ACL GACD com saga | **Em risco** | D1 (GACD × Open Cash Hub) | Se D1 escolher Open Cash Hub, a ACL é refeita (+6 a 8 semanas) |
| Provisionamento PostgreSQL, Blob, Key Vault, namespace | **Bloqueado** | D3, QA-TEC-14 | Sem isso não há HML |
| Regras de rede N-01..N-11 e políticas Axway | **Bloqueado** | D7, D4 | Pedido na F0; PRD só depois do congelamento |
| Adaptador IMPD e template CSF | **Bloqueado** | D2 (gate G1–G5) | Se o gate não fechar até o LRM, o padrão é Plano B |
| Homologação integrada (saga, callback) | **Bloqueado** | D4, D5, D6, D7, M3 | É o gargalo real do MVP |
| Integração com o Canal (alerta) | **Bloqueado** | D11 e backlog de Canais | Atacado entrega o lado dele na F3 sem depender de Canais |
| Tipo "Produtos + Canal" | **Bloqueado** | D13, D10 (2º modelo) | Só na F4 |
| Convênio (porta e acompanhamento da implantação) | **Bloqueado** | D12 (inclui o executor da implantação, QA-CON-24) | Só na F5 (cenário base). A homologação com cada cliente não é código: depende do cliente e do executor (PRM-RMP-14) |
| Medição dos KPIs | **Parcial** | D14 (baseline e denominador) | Sem baseline não se prova −50% |

### 3.3 Visão das fases

| Fase | Nome | Período (indicativo) | Descrição curta (para slide) |
|---|---|---|---|
| **F0** | Destravamento | out/2026 – nov/2026 | Decisões e contratos: GACD × OCH, spike IMPD (G1–G5, Plano A/B), contratos FIRP/GACD/Canal, LEAP, rede e aprovação PostgreSQL/Blob. |
| **F1** | Fundação de plataforma | out/2026 – jan/2027 | Namespace, PostgreSQL, Blob, Key Vault, rotas Axway, rede e esteira CI/CD em DEV, HML e PRD, com esqueleto dos 3 deployables. |
| **F2** | MVP termo ponta a ponta (piloto) | nov/2026 – mai/2027 | Termo "Produtos" ponta a ponta para 1 produto piloto e clientes PDPJ: FIRP, documento, GACD, callback e status no Salesforce. |
| **F3** | Status em tempo real e alerta de assinantes inválidos | fev/2027 – jun/2027 | Status completo no Salesforce, reemissão, reconciliação e alerta de assinantes inválidos integrado ao Canal (Canais). |
| **F4** | Multiproduto, "Produtos + Canal" e ampliação | abr/2027 – ago/2027 | Todos os produtos do lote 1, termo "Produtos + Canal" e ampliação em ondas até 100% dos Gerentes de Cash (go-live amplo). |
| **F5** | Convênio e escala | jun/2027 – jan/2028 | Convênio conforme decisão (porta ativada, implantação com executor definido), clientes BGS com Canais, otimizações, descontinuação do manual e KPIs. |

---

## 4. Detalhamento por fase

### F0 — Destravamento (05/10/2026 – 27/11/2026)

**Descrição curta:** Decisões e contratos: GACD × OCH, spike IMPD (G1–G5, Plano A/B), contratos FIRP/GACD/Canal, LEAP, rede e aprovação PostgreSQL/Blob.

| Item | Conteúdo |
|---|---|
| **Objetivo** | Tomar as decisões de negócio e de arquitetura que travam infraestrutura, contratos e homologação, dentro de um prazo fechado de 8 semanas |
| **Escopo** | Decisões D1–D7 (seção 8); spike IMPD de 3 semanas (12/10–30/10) com relatório G1–G5 e decisão Plano A/B (ADR-03); abertura dos pedidos de rede N-01..N-11 (§7.1 do 04) e de aprovação de COMP-04/COMP-05; *kickoff* do onboarding no GACD (QA-NEG-19); publicação do rascunho do contrato de alerta para Canais (ADR-09); primeira minuta do texto do termo "Produtos" para o Jurídico (D10); pedido formal da decisão de convênio (D12, incluindo quem executa a implantação — QA-CON-24 / QA-CONV-12) ao dono do negócio. Capacidades: CAP-10, CAP-11 (definição), CAP-03.3 (modelo) |
| **Entregáveis** | Relatório do spike IMPD e registro da decisão (Plano A ou Plano B com exceção arquitetural); ADR-01..ADR-12 revisados e aprovados no Comitê de Arquitetura; contratos v1 acordados (GACD 3 APIs + callback + consulta/cancelamento; FIRP; rascunho do alerta ao Canal); pedidos de rede e de infraestrutura protocolados; decisão GACD × Open Cash Hub registrada; mapa de mecanismo de autenticação (LEAP ou alternativa) e usuário sistêmico; plano de rollout do piloto (rascunho) |
| **Dependências bloqueantes** | QA-NEG-01 (Atacado Cash Payments, com GACD); QA-TEC-01/02 (IMPD); QA-TEC-03 (Segurança); QA-TEC-04/06/07 (GACD); QA-TEC-05 (FIRP); QA-TEC-09/10/12/14 (Plataformas Funcionais); QA-DDD-04 (GACD) |
| **Times** | Atacado Cash Payments (dono), GACD, Canais (contrato), Experiência (jornada do Gerente), Plataformas Funcionais, IMPD, FIRP, Segurança, Jurídico/Compliance |
| **Critério de entrada** | Patrocínio formal do Atacado Cash Payments; squad alocado (PRM-RMP-02); pontos focais nomeados em GACD, Canais, Experiência, Plataformas Funcionais, IMPD, FIRP e Segurança |
| **Critério de saída** | D1–D7 tomadas e registradas (ou tratadas pela regra padrão da seção 8); pedidos de rede e infra aprovados ou com data; contratos GACD e FIRP v1 acordados; contrato de alerta publicado para Canais |
| **Marcos** | **M1 — Decisão IMPD A/B** (06/11/2026); **M2 — Contratos fechados** (27/11/2026) |
| **Riscos** | RSK-01, RSK-02, RSK-03, RSK-05, RSK-07, RSK-09, RSK-10; RSK-RMP-04 |
| **KPIs de sucesso** | 100% de D1–D7 decididas até o M2; spike com os 5 gatilhos avaliados por critério objetivo; 100% dos pedidos de rede/infra protocolados até 06/11/2026 |

### F1 — Fundação de plataforma (19/10/2026 – 29/01/2027)

**Descrição curta:** Namespace, PostgreSQL, Blob, Key Vault, rotas Axway, rede e esteira CI/CD em DEV, HML e PRD, com esqueleto dos 3 deployables.

| Item | Conteúdo |
|---|---|
| **Objetivo** | Deixar a plataforma pronta e testada em todos os ambientes, inclusive PRD, antes de a funcionalidade precisar dela |
| **Escopo** | COMP-04 `atacado-adesao-db`, COMP-05 `atacado-adesao-staging` (ou `bytea`, ADR-04 b), COMP-11 Key Vault + CSI, namespace `atacado-core` com NetworkPolicy/EgressFirewall (COMP-10), políticas no COMP-09 Axway (`atacado-adesao-sf`, `atacado-adesao-callback-gacd`, `atacado-adesao-alerta-canal`), entrada COMP-07/COMP-08, egress COMP-12 para o Salesforce, COMP-19 observabilidade; esqueleto *walking skeleton* de COMP-01, COMP-02 e COMP-03 com health check, trace e migração Flyway; Connected App/Named Credential no Salesforce (COMP-06). Capacidades: CAP-10.2, CAP-10.4, CAP-11.1–11.3, CAP-12.1 (trilha) |
| **Entregáveis** | Ambientes DEV e HML até 11/12/2026; PRD depois do congelamento (18–29/01/2027); teste automatizado de conectividade N-01..N-11 verde nos 3 ambientes; esteira CI/CD com SAST/SCA e imagem UBI 9; *dashboards* e alertas mínimos (§9.4 do 04); runbook de plataforma |
| **Dependências bloqueantes** | D3 / QA-TEC-12 e QA-TEC-14 (Plataformas Funcionais); D7 / QA-TEC-09 e QA-TEC-10 (Plataformas Funcionais); D4 / QA-TEC-03 (Segurança); QA-TEC-15 (Atacado Cash Payments, com Experiência); QA-TEC-16 (Plataformas Funcionais) |
| **Times** | Atacado Cash Payments (dono), Plataformas Funcionais, Segurança |
| **Critério de entrada** | D3 e D7 decididas (ou regra padrão aplicada); pedidos protocolados na F0 |
| **Critério de saída** | *Walking skeleton* chamado pelo Salesforce em PRD (N-01) e respondendo ao Salesforce (N-07) com trace ponta a ponta; RDMs de infraestrutura executadas; nenhum achado crítico de segurança aberto |
| **Marcos** | **M3 — Fundação em PRD** (29/01/2027) |
| **Riscos** | RSK-08, RSK-09, RSK-10, RSK-14; RSK-RMP-01 |
| **KPIs de sucesso** | 100% dos fluxos de rede testados nos 3 ambientes; tempo de pipeline commit → HML ≤ 30 min; 0 vulnerabilidade crítica aberta |

### F2 — MVP termo ponta a ponta com produto piloto (16/11/2026 – 07/05/2027)

**Descrição curta:** Termo "Produtos" ponta a ponta para 1 produto piloto e clientes PDPJ: FIRP, documento, GACD, callback e status no Salesforce.

| Item | Conteúdo |
|---|---|
| **Objetivo** | Colocar em produção, para um grupo pequeno de gerentes e clientes, a jornada completa do termo tipo "Produtos", com evidência auditável e status no Salesforce |
| **Escopo** | COMP-01 (módulos 01.1 `adesao-termo`, 01.2 `acl-firp`, 01.3 `acl-gacd` com saga, 01.4 `termo-documento` com o adaptador escolhido em D2 e o outro desligado, 01.5 `acl-registro-contratos` em modo PRM-TEC-10); COMP-02 (callback GACD); COMP-03 (status ao Salesforce); COMP-06 (UI de solicitação, prévia e confirmação do Gerente atrás de flag, objeto de status). RF-01..RF-07, RF-09, RF-11, RF-13, RF-14; RF-10 só cancelamento antes do envio. Capacidades: CAP-02.2, CAP-02.3, CAP-03.1, CAP-03.2, CAP-04.1, CAP-05.1–05.3, CAP-05.5, CAP-08.1, CAP-09.1 (estados principais), CAP-12.1 |
| **Entregáveis** | Modelo "Produtos" aprovado pelo Jurídico e publicado (IMPD ou HTML próprio); homologação integrada com GACD/FIRP/IMPD concluída; teste de carga (PRM-TEC-03) e de *payload* de 5 MB; revisão de segurança e LGPD; runbooks (reprocessar sinal, retomar saga, reentregar, reconciliar protocolo); treinamento dos gerentes piloto; go-live piloto; relatório de hypercare |
| **Dependências bloqueantes** | D1, D2, D4, D5, D6 (M2); D8 / QA-NEG-18 (Experiência); D9 / QA-NEG-08 (Atacado Cash Payments); D10 / QA-CON-19, QA-NEG-07 (Atacado Cash Payments, com Jurídico); QA-TEC-06/07 (GACD); QA-TEC-18 (GACD, para consulta do termo assinado); QA-NEG-11 (GACD, estados e expiração) |
| **Times** | Atacado Cash Payments (dono), GACD, Experiência, FIRP, IMPD (se Plano A), Segurança, Jurídico/Compliance; Canais só informado (clientes PDPJ já assinam no canal) |
| **Critério de entrada** | M2 atingido; ambientes DEV/HML da F1 disponíveis |
| **Critério de saída** | Piloto em PRD com critérios de ampliação da seção 10.4 cumpridos por 4 semanas; hypercare encerrado; decisão go/no-go da ampliação registrada |
| **Marcos** | **M4 — E2E em HML** (12/03/2027); **M5 — Go-live piloto** (13/04/2027) |
| **Riscos** | RSK-01, RSK-02, RSK-03, RSK-04, RSK-05, RSK-07, RSK-11, RSK-12, RSK-16, RSK-17; RSK-RMP-05, RSK-RMP-07, RSK-RMP-08, RSK-RMP-09, RSK-RMP-11 |
| **KPIs de sucesso** | ≥ 95% das solicitações do piloto chegam a Aguardando assinatura sem intervenção técnica; 0 protocolo órfão sem reconciliação em > 48 h; 100% dos callbacks processados; status no Salesforce p95 ≤ 60 s (RNF-06); primeira leitura de conversão (KPI-03) e do tempo de ciclo (KPI-02) do piloto |

### F3 — Status em tempo real e alerta de assinantes inválidos (01/02/2027 – 30/06/2027)

**Descrição curta:** Status completo no Salesforce, reemissão, reconciliação e alerta de assinantes inválidos integrado ao Canal (Canais).

| Item | Conteúdo |
|---|---|
| **Objetivo** | Fechar a visibilidade do Gerente (KPI-04 = 100%) e o ciclo de assinantes inválidos, sem deixar termo parado sem aviso |
| **Escopo** | COMP-02 com a API "Alerta de Assinantes Inválidos v1" (ADR-09) e o caminho alternativo via GACD; COMP-01 com Assinantes inválidos → reemissão (RF-08, RF-10 completo, QA-DDD-02); COMP-03 com alertas ao Gerente (`Alerta_Adesao__c`, Flow de notificação), alerta de pendência longa (SLA de N dias em Aguardando assinatura) e painel de KPIs (CAP-09.4); reconciliação diária de protocolos (ADR-08, se houver API de consulta). Capacidades: CAP-04.2 (lado do Atacado), CAP-09.1 completa, CAP-09.2 (notificação ao Gerente, COMP-03), CAP-09.4, CAP-09.5 (recepção do sinal do Canal, COMP-02), CAP-10.3, CAP-13.1 (externa, Canais) |
| **Entregáveis** | Lado do Atacado pronto em HML até 26/03/2027 (independente de Canais); alerta de pendência longa em PRD junto com o piloto ou logo depois (mitigação de RSK-06); integração do Canal em HML (mai/2027) e PRD; painel de KPIs publicado para o Atacado Cash Payments |
| **Dependências bloqueantes** | D11 / QA-TEC-08, QA-DDD-08, QA-NEG-04 (Canais); PRM-TEC-15 (Canais); QA-DDD-02, QA-DDD-03 (GACD); QA-NEG-05 (Canais/Experiência, notificação ao cliente) |
| **Times** | Atacado Cash Payments (dono), Canais, GACD, Experiência (alertas no Salesforce) |
| **Critério de entrada** | Contrato do alerta aceito por Canais (D11) e item no backlog trimestral de Canais; COMP-02 estável no piloto |
| **Critério de saída** | Canal chamando a API de alerta em PRD; 100% das transições de estado do termo refletidas no Salesforce; alerta de pendência longa ativo |
| **Marcos** | **M6 — Alerta Canal em PRD** (15/06/2027) |
| **Riscos** | RSK-06, RSK-03, RSK-12, RSK-15; RSK-RMP-03 |
| **KPIs de sucesso** | KPI-04: 100% dos gerentes com status em tempo real, medido como ≥ 99% das transições entregues em ≤ 60 s; ≥ 95% dos alertas de assinantes inválidos entregues ao Gerente em ≤ 60 s; % de termos em Aguardando assinatura há mais de N dias em queda mês a mês |

### F4 — Multiproduto, "Produtos + Canal" e ampliação (19/04/2027 – 31/08/2027)

**Descrição curta:** Todos os produtos do lote 1, termo "Produtos + Canal" e ampliação em ondas até 100% dos Gerentes de Cash (go-live amplo).

| Item | Conteúdo |
|---|---|
| **Objetivo** | Levar a solução a todos os Gerentes de Cash e a todos os produtos do lote 1, incluindo o tipo "Produtos + Canal", e começar o relógio do KPI-01 |
| **Escopo** | Catálogo de produtos do lote 1 (QA-NEG-08, QA-DDD-07) habilitado por flag; regra de tipo de termo (CAP-02.2) com "Produtos + Canal"; 2º modelo de termo (IMPD ou próprio); publicação de `AssinaturaConcluida` para Canais efetivar o acesso ao canal (QA-DDD-09, CAP-13.2); ondas de ampliação (seção 10); desligamento gradual do fluxo manual para os casos cobertos. Componentes: COMP-01 (01.1, 01.4), COMP-03, COMP-06; RF-02, RF-04, RF-12 (só o evento). Capacidades: CAP-02.1, CAP-02.2, CAP-03.3, CAP-13.2 (externa) |
| **Entregáveis** | Produtos do lote 1 em PRD; modelo "Produtos + Canal" aprovado e publicado; contrato do sinal de adesão ao canal acordado com Canais; go-live amplo; treinamento de todos os gerentes; hypercare da ampliação |
| **Dependências bloqueantes** | D9 (catálogo, Atacado Cash Payments); D10 (2º modelo, Atacado Cash Payments com Jurídico); D13 / QA-NEG-13, QA-DDD-09, QA-NEG-02 (Canais); D14 / QA-NEG-06 (Atacado Cash Payments); critérios de ampliação da F2 cumpridos |
| **Times** | Atacado Cash Payments (dono), Canais, Experiência (treinamento e comunicação), GACD (volumetria), Jurídico/Compliance |
| **Critério de entrada** | Go/no-go da ampliação aprovado no fim da F2; M6 atingido **ou** alerta de pendência longa aceito formalmente como mitigação temporária |
| **Critério de saída** | 100% dos Gerentes de Cash habilitados; todos os produtos do lote 1 habilitados; "Produtos + Canal" em PRD; hypercare encerrado |
| **Marcos** | **M7 — Go-live amplo** (06/07/2027) |
| **Riscos** | RSK-06, RSK-11, RSK-15; RSK-RMP-02, RSK-RMP-05, RSK-RMP-06, RSK-RMP-10, RSK-RMP-12 |
| **KPIs de sucesso** | Trajetória do KPI-01 a partir de M7: ≥ 50% em M7+2 meses, ≥ 75% em M7+4, ≥ 90% em M7+6; KPI-03 ≥ 80%; ≥ 90% dos gerentes com ao menos 1 termo digital em 60 dias |

### F5 — Convênio e escala (01/06/2027 – 31/01/2028)

**Descrição curta:** Convênio conforme decisão (porta ativada, implantação com executor definido), clientes BGS com Canais, otimizações, descontinuação do manual e KPIs.

| Item | Conteúdo |
|---|---|
| **Objetivo** | Ligar o convênio conforme a decisão de negócio, com a implantação de cada produto aberta para um executor definido, ampliar a base elegível (BGS) e medir os KPIs do PRD no prazo de 6 meses |
| **Escopo** | Convênio (ADR-11): opção B ou C → módulo COMP-01.6 `convenio-produto` como ACL; opção A → COMP-31 `atacado-convenio-produto` (novo deployable, com infraestrutura). Em qualquer opção, a porta, quando ativada, **abre uma pendência de implantação** por produto (tarefa para o Gerente de Cash ou o backoffice, visível no Salesforce) e acompanha o status; ela **não** cria o convênio direto por API no sistema do produto. A implantação (parâmetros com o cliente, convênio em teste no sistema do produto, homologação de remessa e retorno, ativação) é feita pelo executor definido em D12 (QA-CON-24) **[PREMISSA — padrão de mercado]**; flag `convenio.gatilho.habilitado`; status da jornada "Em implantação" → "Convênio ativo" (e "Convênio pendente" como exceção de falha ou atraso) no BC-03; checklist de implantação no Salesforce, se adotado como mitigação do RSK-18. Escala: clientes BGS conforme roadmap de Canais (QA-NEG-02); reavaliação semestral IMPD (gatilho de retorno do ADR-03); broker se QA-TEC-13 confirmar; exportação de KPIs para Databricks (QA-TEC-17, OP-03); descontinuação do processo manual. Capacidades: CAP-06.1, CAP-06.2, CAP-07.1 (acionamento), CAP-09.4 |
| **Entregáveis** | Porta do convênio em PRD (cenário base, opção B/C), com pendência de implantação e acompanhamento de status no Salesforce; executor da implantação definido e preparado (treinamento e checklist); relatório de KPIs aos 6 meses do go-live amplo; decisão de descontinuação do manual; revisão de arquitetura pós-implantação |
| **Dependências bloqueantes** | D12 / QA-CONV-01..13, QA-CON-24, QA-CON-25, QA-TEC-11, QA-DDD-06, QA-DDD-11 (Atacado Cash Payments); D13 / QA-NEG-02 (Canais); QA-TEC-13 (Plataformas Funcionais) |
| **Times** | Atacado Cash Payments (dono; inclui Tarifas/Databricks e o executor da implantação: Gerente de Cash ou backoffice, conforme D12), Canais (BGS), GACD, dono do sistema de convênio (sistema de cada produto, Open Cash Hub ou legado, conforme D12); clientes na homologação |
| **Critério de entrada** | D12 decidida até o LRM, inclusive o executor da implantação; F4 estável |
| **Critério de saída** | Implantação aberta como pendência para o executor depois do termo assinado (ou contrato vigente), com os status "Em implantação" e "Convênio ativo" refletidos no Salesforce; primeiros convênios ativados após a homologação com o cliente; KPIs medidos em M9 e apresentados no Steering |
| **Marcos** | **M8 — Convênio em PRD** (19/10/2027; porta ativada, PRM-RMP-14); **M9 — Medição KPI 6 meses** (06/01/2028) |
| **Riscos** | RSK-13, RSK-15, RSK-18; RSK-RMP-02, RSK-RMP-04, RSK-RMP-10, RSK-RMP-13 |
| **KPIs de sucesso** | KPI-01 ≥ 90%; KPI-02 −50% vs. baseline; KPI-03 ≥ 80%; KPI-04 100%; KPI-05 100%; ≥ 95% das implantações abertas sem intervenção técnica depois do termo assinado; ciclo assinatura → convênio ativo → tarifa medido separando o tempo de implantação e homologação (cliente) do tempo interno (DRV-03) |

---

## 5. Marcos

| ID | Rótulo (≤ 20 caracteres) | Data-alvo (premissa) | Fase | Critério objetivo |
|---|---|---|---|---|
| M1 | Decisão IMPD A/B | 06/11/2026 | F0 | Gatilhos G1–G5 avaliados; Plano A ou Plano B registrado no Comitê de Arquitetura |
| M2 | Contratos fechados | 27/11/2026 | F0 | D1–D7 decididas; contratos GACD/FIRP v1 acordados; contrato de alerta publicado |
| M3 | Fundação em PRD | 29/01/2027 | F1 | *Walking skeleton* em PRD com N-01..N-11 verdes |
| M4 | E2E em HML | 12/03/2027 | F2 | Jornada completa em HML com GACD/FIRP reais e modelo aprovado |
| M5 | Go-live piloto | 13/04/2027 | F2 | RDM executada; primeiros termos reais do piloto |
| M6 | Alerta Canal em PRD | 15/06/2027 | F3 | Canal chamando a API de alerta em PRD |
| M7 | Go-live amplo | 06/07/2027 | F4 | 100% dos gerentes habilitados; início do relógio do KPI-01 |
| M8 | Convênio em PRD | 19/10/2027 | F5 | Porta ativada em PRD (opção B/C): o termo assinado abre a pendência de implantação para o executor definido em D12 e o status é acompanhado no Salesforce. Não exige convênio ativo, que depende da homologação com o cliente (PRM-RMP-14) |
| M9 | Medição KPI 6 meses | 06/01/2028 | F5 | Relatório dos KPI-01..05 aos 6 meses de M7 |

---

## 6. Gantt

Validado com `@mermaid-js/mermaid-cli`. Datas indicativas (PRM-RMP-01). As barras vermelhas são os congelamentos de fim de ano (PRM-RMP-05).

```mermaid
gantt
    title Roadmap Termo de Adesão multiproduto (datas indicativas - premissa)
    dateFormat YYYY-MM-DD
    axisFormat %b/%y
    tickInterval 1month
    todayMarker off

    section Restrições
    Congelamento fim de ano 2026        :crit, fz1, 2026-12-14, 2027-01-15
    Congelamento fim de ano 2027        :crit, fz2, 2027-12-13, 2028-01-14

    section F0 Destravamento
    Decisões e contratos                :f0, 2026-10-05, 2026-11-27
    Spike IMPD 3 semanas G1-G5          :sp, 2026-10-12, 2026-10-30
    M1 Decisão IMPD A/B                 :milestone, m1, 2026-11-06, 0d
    M2 Contratos fechados               :milestone, m2, 2026-11-27, 0d

    section F1 Fundação
    Plataforma, infra, rede e esteira   :f1, 2026-10-19, 2027-01-29
    M3 Fundação em PRD                  :milestone, m3, 2027-01-29, 0d

    section F2 MVP piloto
    Termo ponta a ponta, produto piloto :f2, 2026-11-16, 2027-05-07
    Homologação integrada e RDM         :hml, 2027-03-12, 2027-04-13
    M4 E2E em HML                       :milestone, m4, 2027-03-12, 0d
    M5 Go-live piloto                   :milestone, m5, 2027-04-13, 0d

    section F3 Status e alerta
    Status completo e alerta do Canal   :f3, 2027-02-01, 2027-06-30
    M6 Alerta Canal em PRD              :milestone, m6, 2027-06-15, 0d

    section F4 Multiproduto e ampliação
    Multiproduto, Produtos+Canal, ondas :f4, 2027-04-19, 2027-08-31
    M7 Go-live amplo                    :milestone, m7, 2027-07-06, 0d

    section F5 Convênio e escala
    Convênio, BGS, otimizações, KPIs    :f5, 2027-06-01, 2028-01-31
    M8 Convênio em PRD                  :milestone, m8, 2027-10-19, 0d
    M9 Medição KPI 6 meses              :milestone, m9, 2028-01-06, 0d
```

**Leitura:** F1 e F2 começam dentro da F0 de propósito (seção 3.2). A F3 começa no lado do Atacado em fevereiro, antes do piloto, porque a integração com Canais depende do trimestre de planejamento deles. F4 e F5 se sobrepõem: é o ponto de maior pressão de capacidade (RSK-RMP-02).

---

## 7. Dependências entre times

"Quem entrega o quê para quem e quando". Datas são o prazo de necessidade (não de conforto).

| # | De (entrega) | Para | Entrega | Prazo de necessidade | Fase | Referência |
|---|---|---|---|---|---|---|
| DEP-01 | Atacado Cash Payments | Todos | Decisão GACD × Open Cash Hub | 30/10/2026 | F0 | D1, QA-NEG-01 |
| DEP-02 | IMPD | Atacado Cash Payments | Participação no spike (conectividade, SLA, template-piloto) | 12/10–30/10/2026 | F0 | D2, QA-TEC-01/02 |
| DEP-03 | GACD | Atacado Cash Payments | Contratos v1 das 3 APIs, callback, consulta e cancelamento; trilha de onboarding como "Produto" | 27/11/2026 | F0 | D5, QA-TEC-06/07, QA-NEG-19 |
| DEP-04 | Atacado Cash Payments | GACD | Volumetria, URL de callback por adesão, lista de CNPJs e produto do piloto | 15/01/2027 | F2 | PRM-TEC-03, D9 |
| DEP-05 | GACD | Atacado Cash Payments | Usuário sistêmico em HML / PRD; HML disponível para testes integrados | HML 15/01/2027; PRD 26/02/2027 | F2 | QA-TEC-04, PRM-RMP-07 |
| DEP-06 | GACD | Atacado Cash Payments | Configuração produtiva do Atacado como consumidor (RDM do GACD) e plantão no hypercare | 26/03/2027; abr/2027 | F2 | QA-RMP-05, QA-RMP-12 |
| DEP-07 | FIRP (via Atacado Cash Payments) | Atacado Cash Payments | Contrato v1 e HML | Contrato 27/11/2026; HML 15/01/2027 | F0/F2 | D6, QA-TEC-05 |
| DEP-08 | Atacado Cash Payments | Canais | Contrato "Alerta de Assinantes Inválidos v1" (rascunho → final) e *endpoint* de HML | Rascunho 27/11/2026; final + HML 26/03/2027 | F0/F3 | ADR-09 |
| DEP-09 | Canais | Atacado Cash Payments | Aceite do contrato e item no backlog trimestral | 26/02/2027 (LRM) | F3 | D11, QA-TEC-08 |
| DEP-10 | Canais | Atacado Cash Payments | Chamada à API de alerta em HML e em PRD | HML 21/05/2027; PRD 15/06/2027 | F3 | M6 |
| DEP-11 | Canais | Atacado Cash Payments | Estratégia para clientes BGS e contrato do sinal de adesão ao canal ("Produtos + Canal") | 30/04/2027 | F4 | D13, QA-NEG-02/13, QA-DDD-09 |
| DEP-12 | Atacado Cash Payments | Canais | Evento `AssinaturaConcluida` com tipo "Produtos + Canal" em HML | 30/06/2027 | F4 | QA-DDD-09 |
| DEP-13 | Experiência | Atacado Cash Payments | Jornada do Gerente (solicitação, prévia, confirmação, alertas) e decisão sobre a prévia | 11/12/2026 | F2 | D8, QA-NEG-18, QA-NEG-09 |
| DEP-14 | Experiência | Atacado Cash Payments | Material de treinamento e comunicação do piloto; pesquisa de usabilidade pós-piloto | 26/03/2027; 21/05/2027 | F2 | QA-RMP-07 |
| DEP-15 | Experiência + Canais | Atacado Cash Payments | Definição de quem notifica o cliente da pendência (e-mail) | 26/02/2027 | F2 | QA-NEG-05 |
| DEP-16 | Plataformas Funcionais | Atacado Cash Payments | Aprovação de PostgreSQL/Blob; namespace e esteira | 13/11/2026; 30/10/2026 | F0/F1 | D3, QA-TEC-12 |
| DEP-17 | Plataformas Funcionais | Atacado Cash Payments | Infra e rede em DEV/HML; em PRD | 11/12/2026; 29/01/2027 | F1 | D7, QA-TEC-09/10 |
| DEP-18 | Segurança | Atacado Cash Payments | Mecanismo de token de workload (LEAP ou alternativa); revisão de segurança e LGPD antes do piloto | 27/11/2026; 19/03/2027 | F0/F2 | D4, QA-TEC-03, RSK-12 |
| DEP-19 | Jurídico/Compliance (via Atacado Cash Payments) | Atacado Cash Payments | Texto do modelo "Produtos"; critérios de conformidade; texto do modelo "Produtos + Canal" | 18/12/2026; 26/02/2027; 30/04/2027 | F2/F4 | D10, QA-NEG-07 |
| DEP-20 | IMPD (se Plano A) | Atacado Cash Payments | Template "Produtos" em HML e publicado em PRD (RDM da esteira IMPD) | HML 26/02/2027; PRD 19/03/2027 | F2 | G3 |
| DEP-21 | Atacado Cash Payments (negócio) | Squad | Produto piloto, gerentes piloto, catálogo do lote 1, baseline do KPI-02 | 15/01/2027; 31/03/2027 | F2/F4 | D9, D14 |
| DEP-22 | Atacado Cash Payments (negócio) | Squad / dono do sistema de convênio | Decisão do convênio (sistema, gatilho, opção A/B/C) e do executor da implantação (Gerente de Cash ou backoffice, QA-CON-24); lista dos produtos que exigem homologação (QA-CON-25) | 26/02/2027 (LRM se opção A); 30/04/2027 (B/C e executor) | F5 | D12 |

---

## 8. Plano de decisões (decision log futuro)

Regra geral: cada decisão tem dono único, LRM e **regra padrão** — o que o programa assume se o LRM passar sem decisão, para não parar o squad. A regra padrão é registrada como premissa e comunicada no Steering.

| ID | Decisão | Dono | LRM | Regra padrão se passar do LRM | Impacto no cronograma se atrasar |
|---|---|---|---|---|---|
| D1 | Gerenciador de termos: GACD × Open Cash Hub (QA-NEG-01) | Atacado Cash Payments (com GACD e Arquitetura) | 30/10/2026 | Adotar GACD (PRM-NEG-01) | Caminho crítico: cada semana move M2, M4 e M5 1:1; se escolher Open Cash Hub depois de dez/2026, +6 a 8 semanas na F2 |
| D2 | IMPD Plano A × Plano B (gatilhos G1–G5, ADR-03) | Atacado Cash Payments (Arquitetura), com IMPD | 06/11/2026 (M1); limite absoluto 20/11/2026 | Plano B (geração própria), com exceção arquitetural | Sem decisão até 20/11, o template CSF não fica pronto até 16/03/2027 (G3) e M5 escorrega 1:1 |
| D3 | Aprovação de PostgreSQL Flexible Server e Blob fora do stack (QA-TEC-12) | Plataformas Funcionais (patrocínio do Atacado Cash Payments) | 13/11/2026 | Blob → `bytea` (ADR-04 b); para o banco não há padrão seguro: escalar no Steering | Sem HML antes do congelamento: M3 e M4 +4 a 6 semanas |
| D4 | Autenticação de workload (LEAP ou alternativa) e usuário sistêmico do GACD (QA-TEC-03/04) | Segurança (com GACD) | 27/11/2026 | Adaptador `CredencialProvider` com o mecanismo disponível no Axway hoje | Bloqueia políticas Axway e HML integrada: M4 1:1 |
| D5 | Contratos GACD v1, API de consulta/cancelamento, onboarding (QA-TEC-06/07, QA-NEG-19, QA-DDD-02/03) | GACD | 27/11/2026 | Construir contra hipótese; reconciliação manual obrigatória (RSK-04) | Caminho crítico: M4 1:1; sem API de cancelamento, reemissão (F3) fica manual |
| D6 | Contrato FIRP e papel FIRP × GACD na resolução de assinantes (QA-TEC-05, QA-DDD-04) | FIRP (via Atacado Cash Payments) | 27/11/2026 | ACL com *mock*; se o GACD já resolver assinantes, ACL-FIRP só para exibição | M4 +2 a 4 semanas |
| D7 | Rotas de rede, localização de GACD/FIRP/Canal e limites de *payload* (QA-TEC-09/10) | Plataformas Funcionais | 20/11/2026 | Rota interna via Axway (PRM-TEC-05) | Regras de PRD caem depois do congelamento: M3 +2 a 3 semanas |
| D8 | Prévia e confirmação do Gerente antes do envio (QA-NEG-18) e desenho da jornada | Experiência (com Atacado Cash Payments) | 11/12/2026 | Confirmação ligada (flag), UI mínima | Baixo (flag); retrabalho de UI se decidido tarde |
| D9 | Produto piloto, gerentes/clientes piloto e catálogo do lote 1 (QA-NEG-08, QA-DDD-07) | Atacado Cash Payments | 15/01/2027 (piloto); 30/04/2027 (lote 1) | Produto de maior volume com clientes PDPJ | Piloto sem público: M5 1:1; lote 1 tardio move M7 |
| D10 | Conteúdo jurídico e dono dos 2 modelos; critérios de conformidade (QA-CON-19, QA-NEG-10, QA-NEG-07) | Atacado Cash Payments (com Jurídico/Compliance) | "Produtos" 18/12/2026; conformidade 26/02/2027; "Produtos + Canal" 30/04/2027 | Nenhuma: sem texto aprovado não há go-live | Caminho crítico quase: M4/M5 1:1 depois de 4 semanas de folga |
| D11 | Aceite do contrato do alerta, momento da chamada e prazo no backlog de Canais (QA-TEC-08, QA-DDD-08, QA-NEG-04) | Canais | 26/02/2027 | Alerta de pendência longa + caminho via GACD como mitigação | M6 escorrega 1 trimestre (ciclo de planejamento de Canais); M7 exige aceite formal da mitigação |
| D12 | Convênio: sistema de registro, gatilho, cardinalidade, opção A/B/C/D e **quem executa a implantação** do produto — Gerente de Cash ou backoffice (QA-CONV-01..13, QA-CON-24, QA-CON-25, QA-TEC-11, QA-DDD-06) | Atacado Cash Payments | 26/02/2027 (se opção A); 30/04/2027 (se B/C); executor da implantação até 30/04/2027 em qualquer opção | Porta segue desligada; implantação e convênio seguem no processo manual atual. Executor sem decisão no LRM: a pendência de implantação vai para o Gerente de Cash (ATR-01), com o RSK-18 aceito formalmente no Steering | M8 1:1; opção A acrescenta ~3 meses e cai no congelamento de dez/2027 (M8 → fev/2028). Executor indefinido não move M8, mas atrasa o primeiro convênio ativo e o ciclo até a tarifa (RSK-RMP-13) |
| D13 | Clientes BGS (transitório) e sinal de adesão ao canal para "Produtos + Canal" (QA-NEG-02, QA-NEG-13, QA-DDD-09) | Canais | 30/04/2027 | "Produtos + Canal" fora do go-live amplo; BGS no manual | "Produtos + Canal" sai de F4 para F5; denominador do KPI-01 precisa excluir BGS (QA-RMP-01) |
| D14 | Baseline do KPI-02, denominador e relógio do KPI-01 (QA-NEG-06, PRM-NEG-14, QA-RMP-01) | Atacado Cash Payments | 31/03/2027 | Baseline medido nos 2 meses de piloto; relógio a partir de M7 | Não move datas; move a **prova** das metas |

---

## 9. Caminho crítico e cenários

### 9.1 Caminho crítico (cenário base)

**D1 (GACD) → D5 contratos GACD + D4 autenticação + D7 rede → F1 infra (D3) e HML de GACD/FIRP → M4 E2E em HML → 4 semanas de homologação + RDM → M5 piloto → 4 semanas de estabilização → ondas → M7 go-live amplo → 6 meses → M9.**

Folga: praticamente zero entre M2 e M4, por causa do congelamento de dez/2026–jan/2027. O código não é o gargalo; conectividade, contratos e HML integrada são.

Cadeias quase críticas (viram críticas se escorregarem):

| Cadeia | Folga estimada | Vira crítica quando |
|---|---|---|
| D2 → template CSF (Plano A) → G3 | ~2 semanas | O template "Produtos" não estiver em HML até 26/02/2027 |
| D10 → texto jurídico "Produtos" | ~4 semanas | O texto não estiver aprovado até 15/01/2027 |
| D11 → backlog de Canais → M6 → M7 | ~3 semanas | Canais não planejar o item para o 2º trimestre de 2027 e a mitigação não for aceita |
| D12 (inclui o executor da implantação) → convênio → M8 | Não afeta M7 | Sempre crítica para M8. O primeiro convênio ativo depende ainda da homologação com o cliente, fora do caminho do squad (PRM-RMP-14) |

### 9.2 Cenários

| Cenário | Hipóteses | M5 piloto | M7 go-live amplo | M8 convênio | KPI-01 90% |
|---|---|---|---|---|---|
| **Otimista** | D1–D7 no prazo; spike confirma IMPD e template em 8 semanas **ou** Plano B decidido na semana 3; GACD entrega HML em dez/2026; Canais planeja o alerta no 1º trimestre; convênio e executor da implantação decididos na F0 (opção B/C) | 16/03/2027 | 01/06/2027 | ago/2027 | dez/2027 |
| **Base** | Conforme este documento | 13/04/2027 | 06/07/2027 | 19/10/2027 | 06/01/2028 (M9) |
| **Pessimista** | Contratos GACD fecham só em jan/2027 (depois do congelamento); rede de PRD em fev/2027; Plano B ativado tarde (dez/2026); Canais entrega o alerta só no 3º trimestre; convênio indefinido até jun/2027 ou opção A | jun/2027 (+8 semanas) | set/2027 com mitigação do alerta; out/2027 se exigir o alerta | fev/2028 ou fora do horizonte | mar/2028, e em risco se clientes BGS entrarem no denominador |

### 9.3 Sensibilidade por fator

| Fator | Efeito no cronograma | Leitura crítica |
|---|---|---|
| **IMPD Plano B** | Neutro ou positivo, **se decidido até M1**: o adaptador já está no plano e o template HTML é mais rápido (04 §12.3). +2 a 3 semanas se decidido depois de 20/11/2026 (retrabalho do modelo e exceção arquitetural) | O que atrasa é a decisão tardia, não o Plano B. A regra padrão de D2 existe por isso |
| **Convênio indefinido** | Não move M5 nem M7. Move M8 1:1 e deixa o ciclo "assinatura → tarifa" manual (RSK-13) | Os KPIs do PRD não medem o convênio, mas o problema de negócio (tarifa não cadastrada) continua. Tratar como risco de valor, não de prazo |
| **Homologação com o cliente e executor da implantação** | Não move M8 (software). Move o primeiro convênio ativo e o ciclo assinatura → convênio ativo → tarifa, que dependem do cliente (ERP, layout CNAB ou API, canal de transmissão, testes de remessa e retorno) e da capacidade do executor | M8 não é "convênio ativo para todos". Medir o ciclo separando o tempo do cliente do tempo interno; executor sem capacidade atrasa o faturamento (RSK-18, RSK-RMP-13) **[PREMISSA — padrão de mercado]** |
| **Canal atrasa a API de alerta** | M6 escorrega 1 trimestre. M7 pode sair no prazo se o Steering aceitar a mitigação (alerta de pendência longa + via GACD) | Sem o alerta, o termo com assinante inválido fica parado até o SLA de pendência: afeta KPI-03 (conversão) e KPI-02 (tempo) |
| **GACD × Open Cash Hub reaberto** | +6 a 8 semanas na F2 se depois de dez/2026 | A API Adesão e o Salesforce não mudam (PRI-13); o custo fica na ACL e no onboarding |
| **Aprovação PostgreSQL/Blob** | +4 a 6 semanas em M3/M4 | Maior risco de "fora do stack" é de calendário, não técnico |
| **Congelamento de fim de ano** | Qualquer atraso de 2 semanas em novembro vira 6 semanas em PRD | Motivo de concentrar os pedidos de infra e rede em outubro |

---

## 10. Estratégia de rollout e go-live

### 10.1 Ondas

| Onda | Quando | Público | Escopo | Condição de entrada |
|---|---|---|---|---|
| **Onda 0 — Técnica (dark launch)** | Semana anterior a M5 | Nenhum gerente; 1 CNPJ controlado (empresa do grupo ou cliente parceiro acordado com o GACD) | Jornada completa em PRD com flags ligadas só para a matrícula de teste | RDM aprovada; runbooks prontos; plantão GACD confirmado |
| **Onda 1 — Piloto** | M5 (13/04/2027) + 4 a 6 semanas | 5 a 10 Gerentes de Cash; clientes PDPJ sem contrato vigente | 1 produto, tipo "Produtos"; volume esperado de 20 a 40 termos | Go/no-go da Onda 0 |
| **Onda 2 — Ampliação controlada** | Jun/2027 | 1 plataforma/regional completa (~25% dos gerentes) | Produtos do lote 1 já homologados | Critérios da seção 10.4 cumpridos por 4 semanas |
| **Onda 3 — Go-live amplo** | M7 (06/07/2027) | 100% dos Gerentes de Cash | Todos os produtos do lote 1; "Produtos + Canal" até 31/08/2027 | Critérios da seção 10.4 na Onda 2; M6 ou mitigação aceita |
| **Onda 4 — Convênio** | M8 | Todos | Gatilho da implantação ligado: pendência para o executor a cada termo assinado; convênios ativados à medida que cada cliente conclui a homologação | D12 implementada e testada em HML; executor da implantação definido e treinado (QA-CON-24) |

### 10.2 Feature flags

| Flag | Onde | Uso |
|---|---|---|
| Permissão de uso por gerente/carteira | Salesforce (permission set / custom permission) | Controla quem vê a ação "Gerar Termo" em cada onda |
| `adesao.produto.{codigo}.habilitado` | COMP-01 | Liga produto a produto (F4) |
| `adesao.tipo.produtos-canal.habilitado` | COMP-01 | Liga o tipo "Produtos + Canal" (F4, depende de D13) |
| `confirmacao.gerente.habilitada` | COMP-01 | Prévia/confirmação (ADR-02, D8) |
| `documento.renderizador = impd \| proprio` | COMP-01.4 | Troca Plano A/B sem mudar API nem saga (ADR-03) |
| `alerta.canal.habilitado` e `alerta.pendencia.dias` | COMP-02 / COMP-03 | Alerta do Canal (F3) e mitigação por pendência longa |
| `convenio.gatilho.habilitado` | COMP-01.6 | Abertura da pendência de implantação e acompanhamento do Convênio (F5, ADR-11) |
| `adesao.solicitacao.habilitada` (kill switch) | COMP-01 | Suspende **novas** solicitações sem afetar termos em andamento |

### 10.3 Convivência com o processo manual

- O processo manual continua como **contingência** e como caminho para quem ainda não está no escopo digital (produto fora do lote, cliente BGS, gerente fora da onda) até a decisão de descontinuação (QA-RMP-10).
- **Regra de não duplicidade:** um termo manual em andamento é registrado no Salesforce (campo "termo manual em andamento") e bloqueia a solicitação digital para o mesmo CNPJ (INV-01). O inverso também vale: com termo digital não terminal, o manual não é aberto.
- **Contagem do KPI-01:** o termo manual é registrado no Salesforce com o motivo (fora de escopo, contingência, falha técnica). O motivo "contingência por falha técnica" é métrica de saúde e não pode passar de 5% na Onda 3.
- Após M7, abrir termo manual para caso coberto pelo fluxo digital exige justificativa registrada (evita que o atalho manual derrube a adoção — RSK-RMP-05).

### 10.4 Critérios de ampliação (go/no-go entre ondas)

| Critério | Meta |
|---|---|
| Solicitações que chegam a Aguardando assinatura sem intervenção técnica | ≥ 95% |
| Protocolos órfãos ou RESULTADO_INCERTO sem reconciliação | 0 com mais de 48 h |
| Callbacks processados; sinais em QUARENTENA não explicados | 100%; 0 |
| Entregas ESTACIONADAS ao Salesforce | 0 com mais de 24 h |
| Status no Salesforce | p95 ≤ 60 s (RNF-06) |
| Termos com hash e versão de modelo aprovada (RNF-14) | 100% |
| Incidentes P1/P2 abertos | 0 |
| Satisfação dos gerentes da onda (pesquisa de Experiência) | ≥ 4 de 5 |
| Conversão da onda (leitura antecipada do KPI-03) | ≥ 70% dos termos com mais de 30 dias assinados |

### 10.5 Plano de rollback

| Situação | Ação | O que **não** fazer |
|---|---|---|
| Defeito funcional em nova solicitação | Desligar `adesao.solicitacao.habilitada` e/ou a permissão no Salesforce; gerentes voltam ao manual (seção 10.3) | Não derrubar COMP-02 e COMP-03: termos em Aguardando assinatura continuam recebendo callback e status (RSK-RMP-09) |
| Defeito em release de aplicação | Redeploy da versão anterior pela esteira (RDM de emergência); migrações sempre *expand/contract*, sem migração destrutiva na mesma release | Não fazer rollback de banco que apague inbox, outbox ou trilha de auditoria |
| Problema no IMPD | Trocar `documento.renderizador` para `proprio` (se o modelo HTML estiver aprovado) | Não regenerar documento já enviado ao GACD (hash auditado) |
| Problema no GACD | Circuit breaker abre; saga em AGUARDANDO_RETENTATIVA; reconciliação manual pelo runbook | Não reenviar passo 1 às cegas (RSK-04) |
| Problema na entrega ao Salesforce | Outbox segura por 24 h; reentrega pelo endpoint administrativo | — |
| Falha no piloto que invalide a solução | Suspender a onda; termos em andamento seguem até o fim; novos casos no manual; replanejar no Steering | — |

### 10.6 Hypercare

- **Duração:** 4 semanas depois de M5 e 4 semanas depois de M7; 2 semanas depois de M6 e M8.
- **Formato:** *war room* diário na 1ª semana (squad, GACD, Plataformas Funcionais; Canais depois de M6), depois 3 vezes por semana; plantão com escala nomeada nos três times; canal único de suporte aos gerentes piloto com Experiência.
- **Monitoração:** alertas do §9.4 do 04, painel de KPIs e revisão diária de QUARENTENA, ESTACIONADA, RESULTADO_INCERTO e reconciliação manual.
- **Saída do hypercare:** critérios da seção 10.4 por 2 semanas seguidas e passagem formal para a sustentação do Atacado Cash Payments.

---

## 11. Governança

### 11.1 Ritos

| Rito | Cadência | Participantes | Objetivo |
|---|---|---|---|
| Steering do programa | Mensal (quinzenal na F0) | Liderança do Atacado Cash Payments, Experiência, Canais, GACD; convidados de apoio | Decisões D1–D14, riscos, escalonamentos, go/no-go de ondas |
| Comitê de Arquitetura | Quinzenal na F0–F2; mensal depois | Arquitetura do Atacado, Plataformas Funcionais, Segurança; GACD/IMPD quando pauta pedir | Aprovar ADRs, exceções (Plano B, fora do stack), gatilho de retorno do IMPD |
| Checkpoint GACD | Semanal na F0–F2; quinzenal depois | Squad, Time do GACD | Onboarding, contratos, HML, RDM do GACD, hypercare |
| Checkpoint Canais | Quinzenal a partir da F0 | Squad, Time de Canais, Experiência | Contrato do alerta, backlog trimestral, BGS, "Produtos + Canal" |
| Checkpoint Experiência | Quinzenal na F0–F2 | Squad, Time de Experiência, Gerentes de Cash convidados | Jornada do Gerente, prévia, treinamento, pesquisa |
| Checkpoint de plataforma | Semanal na F0–F1 | Squad, Plataformas Funcionais, Segurança | Infra, rede, Axway, pipeline |
| Cerimônias do squad | Sprint de 2 semanas | Squad | Planejamento, review com stakeholders, retrospectiva |
| Go/no-go | Antes de cada onda e de cada RDM relevante | Steering reduzido + Plataformas Funcionais + GACD | Aplicar critérios da seção 10.4 |

### 11.2 RDMs previstas (não exaustivo)

| RDM | Dono | Janela indicativa | Fase |
|---|---|---|---|
| Infraestrutura PRD (PostgreSQL, Blob, Key Vault, namespace) | Plataformas Funcionais | 18–29/01/2027 | F1 |
| Regras de rede e políticas Axway PRD (N-01..N-11) | Plataformas Funcionais | 18–29/01/2027 | F1 |
| Metadados Salesforce (Connected App, Named Credential, objetos) | Atacado Cash Payments | Fev/2027 (fora do fim de semana de upgrade Spring) | F1/F2 |
| Template IMPD "Produtos" (esteira GitHub → CMG) | IMPD, a pedido do Atacado | 19/03/2027 | F2 |
| Configuração do Atacado como consumidor no GACD | GACD | 26/03/2027 | F2 |
| Aplicação (COMP-01/02/03) — piloto | Atacado Cash Payments | Semana de 05/04/2027 (dark launch) | F2 |
| Política Axway do alerta do Canal e liberação do Canal | Plataformas Funcionais / Canais | Jun/2027 | F3 |
| Produtos do lote 1 e "Produtos + Canal" (config + template 2) | Atacado Cash Payments (IMPD se Plano A) | Jun–ago/2027 (fora do upgrade Summer) | F4 |
| Convênio (ACL ou COMP-31) | Atacado Cash Payments | Out/2027 | F5 |

### 11.3 Métricas de acompanhamento

**KPIs do PRD (medidos pelo painel de CAP-09.4):**

| KPI | Meta do PRD | Como medir no roadmap | Primeira leitura | Meta intermediária |
|---|---|---|---|---|
| KPI-01 % de termos gerados via Salesforce | ≥ 90% em 6 meses | Termos digitais ÷ (digitais + manuais registrados) no escopo elegível (PRM-RMP-10) | Onda 1 (só no escopo do piloto) | ≥ 50% em M7+2m; ≥ 75% em M7+4m; ≥ 90% em M9 |
| KPI-02 Tempo de negociação → assinatura | −50% vs. baseline | Data de aprovação da proposta → `AssinaturaConcluida`; baseline de D14 | Onda 1 | −25% em M7+3m; −50% em M9 |
| KPI-03 % gerados que são assinados | ≥ 80% | Assinados ÷ gerados, com coorte de 30 dias (depende do prazo de expiração, QA-NEG-11) | Onda 1 + 30 dias | ≥ 70% no piloto; ≥ 80% em M9 |
| KPI-04 % de gerentes com status em tempo real | 100% | Gerentes habilitados com ≥ 99% das transições entregues em ≤ 60 s | M5 (estados principais) | 100% em M6 |
| KPI-05 % de termos em conformidade | 100% | Termos com modelo aprovado, hash auditado e evidência no GCC/Filenet, conforme critérios de D10 | M5 | 100% sempre (qualquer desvio é incidente) |

**Métrica complementar (não é KPI do PRD):** ciclo assinatura → convênio ativo → tarifa cadastrada (01 §4.3, DRV-03), separando o tempo de implantação e homologação, que depende do cliente, do tempo interno do banco. Primeira leitura depois de M8. O KPI-02 (negociação → assinatura) não muda.

**Saúde do programa:**

| Métrica | Meta |
|---|---|
| Decisões tomadas até o LRM | 100% (desvio vai ao Steering com a regra padrão aplicada) |
| Dependências entre times entregues no prazo (seção 7) | ≥ 90% |
| Marcos no prazo do cenário base | Desvio ≤ 2 semanas; acima disso, replanejar |
| Riscos altos (RSK e RSK-RMP) sem plano de mitigação | 0 |
| Previsibilidade do squad (entregue ÷ planejado por sprint) | ≥ 80% |

---

## 12. Riscos do roadmap

Riscos de **planejamento e entrega**; os riscos técnicos continuam no 04 (RSK-01..18) e não são repetidos aqui.

| ID | Risco | Prob. | Impacto | Mitigação | Dono |
|---|---|---|---|---|---|
| RSK-RMP-01 | Congelamento de fim de ano comprime a janela de infra e rede em PRD; qualquer atraso de novembro vira 6 semanas | A | A | Protocolar pedidos até 06/11/2026; DEV/HML antes de 11/12; RDMs de PRD pré-agendadas para 18–29/01/2027 | Atacado Cash Payments |
| RSK-RMP-02 | Um único squad sustenta piloto, F3, F4 e F5 em paralelo (abr–set/2027) | A | M | Reforço de 2 desenvolvedores a partir de abr/2027 ou 2º squad para o convênio (QA-RMP-02); congelar escopo novo durante o hypercare | Atacado Cash Payments |
| RSK-RMP-03 | Ciclos de planejamento trimestral de Canais e GACD desalinhados com o roadmap: a dependência entra no backlog um trimestre depois | A | A | Contrato publicado na F0; LRM de D11 alinhado ao planejamento deles; checkpoint quinzenal; escalonamento no Steering | Canais |
| RSK-RMP-04 | Decisões de negócio (GACD × OCH, convênio, catálogo) empurradas além do LRM por falta de fórum com poder de decisão | M | A | Steering com decisores nomeados; regra padrão por decisão (seção 8); decision log publicado | Atacado Cash Payments |
| RSK-RMP-05 | Baixa adoção pelos Gerentes de Cash; o manual vira atalho e o KPI-01 não chega a 90% | M | A | Jornada desenhada com Experiência; treinamento por onda; justificativa obrigatória para termo manual depois de M7; ranking de adoção por carteira | Experiência |
| RSK-RMP-06 | Expectativa desalinhada sobre o início do relógio de 6 meses (piloto × go-live amplo) | M | M | Registrar PRM-RMP-10 e QA-RMP-01 no Steering da F0; metas intermediárias publicadas | Atacado Cash Payments |
| RSK-RMP-07 | HML integrada (GACD, FIRP, IMPD, Canal) indisponível, instável ou sem massa de dados coerente (CNPJ com poderes na FIRP e protocolo no GACD) | A | A | Reserva de janela de HML com o GACD; massa de dados combinada na F1; testes de contrato automatizados antes da HML | GACD |
| RSK-RMP-08 | Upgrade sazonal do Salesforce coincide com go-live ou quebra a UI/integração | M | M | Calendário de releases no plano; regressão no sandbox *preview*; nenhuma RDM no fim de semana de upgrade | Atacado Cash Payments |
| RSK-RMP-09 | Rollback mal executado derruba o receptor e o acompanhamento com termos em andamento, perdendo callbacks | B | A | Kill switch só para novas solicitações; runbook de rollback testado na Onda 0; COMP-02 fora do escopo de rollback funcional | Atacado Cash Payments |
| RSK-RMP-10 | Base elegível ao fluxo digital (PDPJ, produtos do lote 1) menor que o denominador do KPI-01; meta de 90% inatingível mesmo com a solução funcionando | M | A | Denominador definido em D14; plano de BGS com Canais (D13); leitura por segmento | Canais |
| RSK-RMP-11 | Aprovação do Jurídico do texto do termo e dos critérios de conformidade atrasa (e pode ser dupla: CSF e HTML) | M | A | Minuta na F0; um único texto-fonte para os dois planos; SLA de 4 semanas (PRM-RMP-11) | Atacado Cash Payments |
| RSK-RMP-12 | Picos operacionais de Cash (fechamento de mês, 5º dia útil) reduzem janelas de RDM e disponibilidade dos gerentes nas ondas | M | M | Calendário de ondas fora dos picos; RDMs na 2ª e 3ª semanas do mês | Atacado Cash Payments |
| RSK-RMP-13 | Tempo de homologação com o cliente e executor da implantação indefinido ou sem capacidade: o convênio demora a ficar ativo depois de M8 e o ciclo até a tarifa não encurta; a expectativa de "convênio logo após o aceite" gera cobrança sobre o roadmap **[PREMISSA — padrão de mercado]** | M | A | Executor decidido em D12 até 30/04/2027 (QA-CON-24); backoffice como executor, checklist de implantação no Salesforce e apoio do time de produto (RSK-18); lista dos produtos que exigem homologação (QA-CON-25); M8 comunicado como porta ativada (PRM-RMP-14); ciclo medido separando o tempo do cliente do tempo interno | Atacado Cash Payments |

---

## 13. Questões em aberto de planejamento

| ID | Questão | Time responsável | Afeta |
|---|---|---|---|
| QA-RMP-01 | O relógio do KPI-01 (≥90% em 6 meses) começa no piloto ou no go-live amplo? O denominador inclui clientes BGS e produtos fora do lote 1? | Atacado Cash Payments | PRM-RMP-10, D14, M9 |
| QA-RMP-02 | Haverá reforço de capacidade (2 desenvolvedores ou 2º squad) para a sobreposição de F4 e F5, em especial se o convênio for opção A? | Atacado Cash Payments | F4, F5, RSK-RMP-02 |
| QA-RMP-03 | Em qual trimestre de planejamento de Canais entram a chamada à API de alerta e o sinal de adesão ao canal ("Produtos + Canal")? Qual o prazo mínimo de antecedência para entrar no backlog? | Canais | D11, D13, M6 |
| QA-RMP-04 | Qual é o lead time real de onboarding de um novo "Produto" consumidor no GACD, e quando a HML do GACD fica disponível para o Atacado? | GACD | D5, M4, RSK-RMP-07 |
| QA-RMP-05 | O GACD suporta piloto restrito (lista de CNPJs ou produto) e qual é o calendário de mudanças/congelamento do próprio GACD? | GACD | Onda 0/1, DEP-06 |
| QA-RMP-06 | Quem escolhe gerentes e clientes do piloto, com quais critérios (volume, perfil, regional), e quem autoriza cada onda? | Atacado Cash Payments | D9, seção 10.1 |
| QA-RMP-07 | Experiência conduz treinamento, comunicação aos gerentes e pesquisa de usabilidade de cada onda? Com qual capacidade? | Experiência | DEP-14, RSK-RMP-05 |
| QA-RMP-08 | Como o cliente do piloto é avisado da pendência de assinatura no PDPJ durante o piloto (e-mail, notificação do canal, contato do gerente)? | Canais | QA-NEG-05, Onda 1 |
| QA-RMP-09 | Qual é o calendário oficial de congelamento de mudanças 2026/2027 e as janelas de RDM aplicáveis ao `atacado-core`, ao Axway e ao Salesforce? | Atacado Cash Payments | PRM-RMP-04/05, RSK-RMP-01 |
| QA-RMP-10 | Quando e com qual critério o processo manual de termo é descontinuado para os casos cobertos pelo fluxo digital? | Atacado Cash Payments | PRM-RMP-13, seção 10.3 |
| QA-RMP-11 | Em que data o desenho da jornada do Gerente (prévia, confirmação, alertas) fica pronto para o squad, e quem representa os Gerentes de Cash nas validações? | Experiência | D8, DEP-13 |
| QA-RMP-12 | O GACD participa do hypercare (plantão e *war room*) nas Ondas 0, 1 e 3? | GACD | Seção 10.6 |

---

## 14. Rastreabilidade com os documentos anteriores

| Este documento | Origem |
|---|---|
| Fases F0–F5 | Componentes COMP-01..06, 31 e ADR-01..12 do 04; capacidades CAP-xx do 01/02 |
| Spike IMPD e D2 | 04 §12.4 (gatilhos G1–G5) e ADR-03 |
| D1, D5, D6, D11, D12, D13 | QA-NEG-01/02/13, QA-TEC-05..08/11, QA-CONV-01..13, QA-CON-24/25, QA-DDD-02..09 |
| PRM-RMP-14, RSK-RMP-13 (implantação e homologação do Convênio) | 01 §11 (QA-CONV-12/13, PRM-NEG-18) e RN-17; 02 PN-10, ATR-09, PRM-CON-15; 04 RSK-18 |
| D3, D4, D7 | QA-TEC-03/04/09/10/12/14; RSK-05, RSK-09, RSK-10 |
| Métricas | KPI-01..05 (02 §OE; 01 §4.3); RNF-06/07/08/14/16 (04) |
| Rollback e hypercare | ADR-02, ADR-08, ADR-12; 04 §9.2 (estruturas de reprocessamento) |
