# 05 — Especificações Técnicas: Termo de Adesão Multiproduto (Cash Management / Payments)

> Detalha o desenho de solução (`04-desenho-arquitetura-solucao.md` e `04a-componentes-e-justificativas.md`) em **unidades de especificação técnica (SPEC)** rastreáveis, com critérios de aceite verificáveis, para servir de insumo à **criação posterior de tasks**.
> Este documento **não cria tasks**, histórias, backlog nem estimativas. Ele organiza o que deve ser construído, configurado, provisionado ou acordado, e com qual critério será considerado pronto.
> IDs herdados (RN-xx, RFN-xx, RNFN-xx, CAP-xx, APP-xx, BC-xx, R-xx, INV-xx, RF-xx, RNF-xx, COMP-xx, ADR-xx, RSK-xx, QA-xxx, PRM-xxx) **não mudam**. IDs criados aqui: SPEC-xxx-nn, CA-xxx-nn.m, DT-nn (decisões técnicas), T-nn (transições), QA-TEC-19 em diante, PRM-TEC-16 em diante.

---

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Documento | 05 — Especificações Técnicas |
| Versão | v0.4 |
| Data | 2026-09-27 |
| Status | Rascunho para revisão técnica (Tech Lead, Plataformas Funcionais, Segurança, times de Salesforce, GACD e Canais) |
| Autor | Tech Lead / Arquitetura de Software — Atacado (Cash Management / Payments) |
| Documentos base | `01-contexto-de-negocio.md` (v0.2), `02-desenho-conceitual.md` (v0.2), `03-dominios-bounded-contexts-context-mapping.md` (v0.1), `04-desenho-arquitetura-solucao.md` (v0.1), `04a-componentes-e-justificativas.md` (v0.1), `stack-tech.md` |
| Fontes primárias consultadas | [04] Confluence GACD (3 chamadas + callback); [05] [06] IMPD (CSF Designer v21, base64, `impd-srv-doc-generator`) |
| Público | Desenvolvedores Java e Salesforce, QA, SRE/Plataformas Funcionais, Segurança, times do GACD, FIRP, IMPD e Canais (contratos) |

**Histórico de versões**

| Versão | Data | Descrição |
|---|---|---|
| v0.1 | 2026-09-23 | Versão inicial: padrões transversais, SPECs por componente, contratos de API, DDL, máquina de estados, eventos, saga, segurança, infraestrutura, observabilidade, testes, DoR técnico, rastreabilidade e QA-TEC-19..30 |
| v0.2 | 2026-09-24 | Consolidação Rodada 2: itens I-01..I-16 da §17 propagados para 03 (v0.2), 04 (v0.2) e 04a (v0.2); nome do COMP-06 alinhado ao 04/04a ("Artefatos Salesforce do Atacado"). Nenhuma especificação mudou |
| v0.3 | 2026-09-24 | Rastreio de capacidades do alerta de assinantes inválidos alinhado à separação do 02 v0.5: SPEC-REC-02 e SPEC-API-03 (recepção do sinal do Canal no COMP-02) passam a **CAP-09.5**; SPEC-ACP-02, SPEC-SFC-05 e SPEC-TER-13 (notificação ao Gerente) seguem em **CAP-09.2**. Matriz de rastreabilidade (§15) atualizada. Nenhuma regra ou critério de aceite mudou |
| v0.4 | 2026-09-27 | Convênio com **etapa de implantação e homologação** (`instrucoes-ajustes.md`, item 8), alinhado ao 01 v0.5 e ao 02 v0.7: SPEC-CNV-01 registra que a porta `convenio-produto` (COMP-01.6), quando ativada, tende a **abrir uma pendência de implantação** para o Gerente de Cash ou o backoffice (QA-CON-24), visível no Salesforce, e acompanhar o status Em implantação → Convênio ativo, e não a criar o convênio direto por API; flag `convenio.gatilho.habilitado` (SPEC-TRV-14); status reservados da jornada passam a `EM_IMPLANTACAO`, `CONVENIO_ATIVO`, `TARIFAS_CADASTRADAS` (+ `CONVENIO_PENDENTE` como exceção) em SPEC-ACP-02 e no picklist `Status_Jornada__c`; catálogo de eventos (§8.1): gatilhos abrem a implantação; rastreio de RN-17 (§15). Nenhum contrato ativo nem critério de aceite desta entrega mudou |

### 1.1 Convenção de marcação

| Marca | Significado |
|---|---|
| **[FATO: xx]** | Suportado por fonte (`[01]`..`[06]`, `[stack]`, `[CG]`) |
| **[PREMISSA: PRM-TEC-xx]** | Premissa técnica do 04 (01..15) ou deste documento (16..19) |
| **[HIPÓTESE]** | Sem fonte (ex.: token LEAP, payloads de FIRP/GACD/IMPD) |
| **[ABERTO: QA-xxx-nn]** | Depende de resposta a uma questão em aberto |
| **[DECISÃO: ADR-xx]** | Decisão de arquitetura do 04 |
| **[DT-nn]** | Decisão técnica tomada neste documento (seção 2.4) |
| **[PROPOSTA]** | Especificação proposta aqui, sem fonte; sujeita a validação com o time dono do contrato |

### 1.2 Como usar este documento para fatiar tasks depois

Este documento é a **fonte de requisitos técnicos** para quem vai criar as tasks. Ele não as cria. As regras abaixo tornam o fatiamento previsível e rastreável.

**Unidade de especificação (SPEC).** Cada SPEC descreve **uma capacidade técnica entregável e verificável isoladamente** (um endpoint, um adaptador, um job, um recurso de infraestrutura, um acordo de contrato). Uma SPEC pode originar uma ou várias tasks. Uma task nunca deve cobrir mais de uma SPEC de componentes diferentes.

**Convenção de IDs**

| Elemento | Formato | Exemplo | Observação |
|---|---|---|---|
| Especificação | `SPEC-<CÓD>-<nn>` | `SPEC-TER-03` | `<CÓD>` identifica o componente ou o tema (tabela abaixo) |
| Critério de aceite | `CA-<CÓD>-<nn>.<m>` | `CA-TER-03.2` | Unidade mínima de verificação; toda task deve citar os CA que atende |
| Decisão técnica | `DT-<nn>` | `DT-05` | Decisões deste documento (seção 2.4) |
| Transição de estado | `T-<nn>` | `T-09` | Máquina de estados (seção 7) |
| Questão técnica nova | `QA-TEC-<nn>` | `QA-TEC-24` | Continua a numeração do 04 (seção 16) |

| `<CÓD>` | Escopo | Componente(s) |
|---|---|---|
| `TRV` | Padrões transversais aos três deployables | COMP-01, COMP-02, COMP-03 |
| `TER` | Módulo `adesao-termo` (domínio, API Adesão, inbox, outbox, auditoria, admin) | COMP-01.1 |
| `FIR` | Módulo `acl-firp` | COMP-01.2 |
| `GAC` | Módulo `acl-gacd` (adaptadores e saga) | COMP-01.3 |
| `DOC` | Módulo `termo-documento` | COMP-01.4 (+ COMP-05) |
| `ELG` | Módulo `acl-registro-contratos` | COMP-01.5 |
| `CNV` | Módulo `convenio-produto` (inativo) | COMP-01.6 |
| `REC` | `atacado-adesao-receptor` | COMP-02 |
| `ACP` | `atacado-adesao-acompanhamento` | COMP-03 |
| `DB` | `atacado-adesao-db` | COMP-04 |
| `STG` | `atacado-adesao-staging` | COMP-05 |
| `SFC` | Artefatos Salesforce do Atacado | COMP-06 |
| `API` | Contratos de API (entrada e saída) | COMP-01, COMP-02, COMP-03, COMP-06, COMP-09 |
| `EVT` | Eventos de domínio (outbox) | COMP-01, COMP-03 |
| `SEG` | Segurança | Todos os novos + COMP-07..12 |
| `INF` | Infraestrutura e deploy | COMP-04, COMP-05, COMP-09..12 |
| `OBS` | Observabilidade e auditoria | Todos os novos + COMP-19 |
| `TST` | Estratégia de testes | Todos os novos |

**Classe da SPEC** (indica o tipo de trabalho, não o tamanho)

| Classe | Significado |
|---|---|
| CONSTRUIR | Código Java/Apex/LWC ou SQL a ser escrito pelo Atacado |
| CONFIGURAR | Configuração em plataforma existente (Salesforce, Axway, ARO, pipeline) |
| PROVISIONAR | Criação de recurso de infraestrutura (Azure, namespace) |
| ACORDAR | Contrato ou decisão a fechar com outro time; o entregável é um artefato aprovado (OpenAPI, ata, parâmetro) |
| VALIDAR | Teste, prova de conceito ou evidência exigida antes de avançar |

**Prontidão da SPEC**

| Prontidão | Significado | Regra de fatiamento |
|---|---|---|
| PRONTA | Nenhuma questão aberta impede a implementação completa | Fatiar livremente pelos CA |
| PARCIAL | Pode ser implementada contra simulador (WireMock) ou com valor provisório; a conclusão depende de QA | Fatiar em duas partes: (1) o que não depende da QA; (2) ajuste ao contrato real, marcada como bloqueada pela QA |
| BLOQUEADA | Não há como implementar de forma útil sem a resposta | Não fatiar até a QA ser respondida; registrar só a SPEC de ACORDAR correspondente |

**Orientações de fatiamento** (sem criar tasks):

1. Fatiar por **critério de aceite** ou por **porta/adaptador**. Evitar tasks "horizontais" do tipo "criar todas as tabelas": a tabela nasce com a SPEC que a usa, e as SPEC-DB-xx tratam só do que é transversal ao banco.
2. SPECs de classe ACORDAR são pré-requisito das partes bloqueadas das SPECs de CONSTRUIR que as referenciam (seção 14).
3. Toda task derivada herda o **Definition of Done técnico comum** (seção 3.16) e deve citar `SPEC-…` e `CA-…`.
4. A ordem de dependência entre SPECs está na seção 1.4. Ela indica precedência técnica, não priorização de negócio.
5. Quando uma QA for respondida e mudar um CA, a SPEC é revisada neste documento (nova versão) antes de a task ser ajustada.

### 1.3 Catálogo de SPECs

| ID | Título | Componente | Classe | Prontidão | Bloqueios / dependências externas |
|---|---|---|---|---|---|
| SPEC-TRV-01 | Repositório único e build Maven multi-módulo | COMP-01/02/03 | CONSTRUIR | PRONTA | QA-TEC-19 (só o estágio de publicação) |
| SPEC-TRV-02 | Convenções de código Java 21 / Spring Boot 3 | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-03 | Arquitetura hexagonal e fronteiras de módulo | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-04 | Erros padronizados (RFC 9457 Problem Details) | COMP-01/02 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-05 | Versionamento de APIs e contratos | COMP-01/02 | CONSTRUIR | PARCIAL | QA-TEC-23 |
| SPEC-TRV-06 | Idempotência de comandos (`Idempotency-Key`) | COMP-01 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-07 | Correlação e propagação de contexto | COMP-01/02/03 | CONSTRUIR | PARCIAL | QA-TEC-22 |
| SPEC-TRV-08 | Logging estruturado sem dados pessoais | COMP-01/02/03 | CONSTRUIR | PARCIAL | QA-TEC-16 |
| SPEC-TRV-09 | Configuração e profiles por ambiente | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-10 | Segredos via Key Vault (CSI) e `CredencialProvider` | COMP-01/02/03 | CONSTRUIR | PARCIAL | QA-TEC-14, PRM-TEC-08 |
| SPEC-TRV-11 | Resiliência por dependência (Resilience4j) | COMP-01/03 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-12 | Telemetria (OpenTelemetry e Micrometer) | COMP-01/02/03 | CONSTRUIR | PARCIAL | QA-TEC-16 |
| SPEC-TRV-13 | Health, probes e desligamento gracioso | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-TRV-14 | Feature flags | COMP-01/03 | CONSTRUIR | PRONTA | QA-TEC-27 (governança em Prod) |
| SPEC-TRV-15 | Cliente HTTP de saída padronizado | COMP-01/03 | CONSTRUIR | PARCIAL | QA-TEC-03 |
| SPEC-TER-01 | Modelo de domínio `AdesaoTermo` e invariantes | COMP-01.1 | CONSTRUIR | PRONTA | — |
| SPEC-TER-02 | Persistência do agregado e unicidade por CNPJ | COMP-01.1 | CONSTRUIR | PRONTA | QA-NEG-16 (unidade CNPJ × raiz) |
| SPEC-TER-03 | Solicitar adesão (`POST /v1/adesoes`) | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-30 (campos do snapshot) |
| SPEC-TER-04 | Consultas e prévia do documento | COMP-01.1 | CONSTRUIR | PRONTA | QA-TEC-18 (termo assinado, fora desta SPEC) |
| SPEC-TER-05 | Confirmação de envio pelo Gerente | COMP-01.1 | CONSTRUIR | PRONTA | QA-NEG-18 (só o default da flag) |
| SPEC-TER-06 | Reemissão do termo | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-06 / QA-DDD-02 (cancelar protocolo anterior) |
| SPEC-TER-07 | Cancelamento do termo | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-06, QA-NEG-12 |
| SPEC-TER-08 | Fila de tarefas e orquestração assíncrona | COMP-01.1 | CONSTRUIR | PRONTA | — |
| SPEC-TER-09 | Processamento da inbox (sinais externos) | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-07, QA-TEC-08 |
| SPEC-TER-10 | Outbox transacional (produção de eventos) | COMP-01.1 | CONSTRUIR | PRONTA | — |
| SPEC-TER-11 | Trilha de auditoria append-only | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-17 (retenção) |
| SPEC-TER-12 | API administrativa e reprocessamento | COMP-01.1 | CONSTRUIR | PARCIAL | QA-TEC-27 |
| SPEC-TER-13 | Monitor de pendência de assinatura | COMP-01.1 | CONSTRUIR | PARCIAL | QA-NEG-11, QA-TEC-08 |
| SPEC-FIR-01 | Porta `ConsultaAssinantesPort` e modelo de resultado | COMP-01.2 | CONSTRUIR | PRONTA | — |
| SPEC-FIR-02 | Adaptador FIRP via Axway | COMP-01.2 | CONSTRUIR | PARCIAL | QA-TEC-05, QA-TEC-03, QA-DDD-04, QA-TEC-24 |
| SPEC-GAC-01 | Porta `AssinaturaDigitalPort` e adaptadores das 3 APIs GACD | COMP-01.3 | CONSTRUIR | PARCIAL | QA-TEC-06, QA-TEC-04, QA-TEC-24 |
| SPEC-GAC-02 | Saga persistida de envio para assinatura | COMP-01.3 | CONSTRUIR | PRONTA | PRM-TEC-11 |
| SPEC-GAC-03 | Compensação, reconciliação e protocolos órfãos | COMP-01.3 | CONSTRUIR | PARCIAL | QA-TEC-06 |
| SPEC-DOC-01 | Catálogo de modelos do termo | COMP-01.4 | CONSTRUIR | PARCIAL | QA-CON-19 |
| SPEC-DOC-02 | Composição e porta `RenderizadorDocumento` | COMP-01.4 | CONSTRUIR | PARCIAL | QA-TEC-30, QA-NEG-10 |
| SPEC-DOC-03 | Adaptador IMPD `impd-srv-doc-generator` (Plano A) | COMP-01.4 | CONSTRUIR | BLOQUEADA | QA-TEC-01, QA-TEC-02 (gate G1–G5) |
| SPEC-DOC-04 | Renderizador próprio (Plano B, desligado) | COMP-01.4 | CONSTRUIR | PARCIAL | QA-CON-19 (texto jurídico) |
| SPEC-DOC-05 | Staging do PDF, hash e integridade | COMP-01.4 | CONSTRUIR | PARCIAL | QA-TEC-12, QA-TEC-14 |
| SPEC-ELG-01 | Políticas de elegibilidade e tipo de termo | COMP-01.5 | CONSTRUIR | PRONTA | PRM-TEC-10 |
| SPEC-CNV-01 | Porta de convênio desativada e eventos-gatilho | COMP-01.6 | CONSTRUIR | PRONTA | QA-TEC-11, QA-CON-24 (ativação futura) |
| SPEC-REC-01 | Recepção do callback do GACD | COMP-02 | CONSTRUIR | PARCIAL | QA-TEC-07 |
| SPEC-REC-02 | Recepção do alerta de assinantes inválidos | COMP-02 | CONSTRUIR | PARCIAL | QA-TEC-08 |
| SPEC-REC-03 | Verificação da identidade do chamador | COMP-02 | CONSTRUIR | PARCIAL | QA-TEC-22, QA-TEC-07, QA-TEC-08 |
| SPEC-REC-04 | Contrato da inbox, isolamento e disponibilidade | COMP-02 | CONSTRUIR | PRONTA | — |
| SPEC-ACP-01 | Relay da outbox | COMP-03 | CONSTRUIR | PRONTA | — |
| SPEC-ACP-02 | Projeção da jornada e alertas ao Gerente | COMP-03 | CONSTRUIR | PRONTA | — |
| SPEC-ACP-03 | Entrega de status ao Salesforce (upsert) | COMP-03 | CONSTRUIR | PARCIAL | QA-TEC-15 |
| SPEC-ACP-04 | Autenticação OAuth 2.0 JWT Bearer no Salesforce | COMP-03 | CONSTRUIR | PARCIAL | QA-TEC-15, QA-TEC-26 |
| SPEC-ACP-05 | Estacionamento, reentrega e consumo de limites | COMP-03 | CONSTRUIR | PRONTA | — |
| SPEC-DB-01 | Provisionamento do PostgreSQL Flexible Server | COMP-04 | PROVISIONAR | BLOQUEADA | QA-TEC-12, QA-TEC-20, QA-TEC-28 |
| SPEC-DB-02 | Schemas, roles e privilégios | COMP-04 | CONSTRUIR | PARCIAL | QA-TEC-14 |
| SPEC-DB-03 | Migrações Flyway (expand/contract) | COMP-04 | CONSTRUIR | PRONTA | QA-TEC-19 (hook no pipeline) |
| SPEC-DB-04 | Retenção, particionamento e expurgo | COMP-04 | CONSTRUIR | PARCIAL | QA-TEC-17, QA-TEC-28 |
| SPEC-STG-01 | Provisionamento do Blob de staging e lifecycle | COMP-05 | PROVISIONAR | BLOQUEADA | QA-TEC-12, QA-TEC-20 |
| SPEC-SFC-01 | Objetos e campos de status no Salesforce | COMP-06 | CONFIGURAR | PARCIAL | QA-TEC-15 |
| SPEC-SFC-02 | Chamada à API Adesão (Named/External Credential e cliente Apex) | COMP-06 | CONSTRUIR | PARCIAL | QA-TEC-15, QA-TEC-03, QA-TEC-26 |
| SPEC-SFC-03 | Connected App, usuário de integração e permissões | COMP-06 | CONFIGURAR | PARCIAL | QA-TEC-15, QA-TEC-26 |
| SPEC-SFC-04 | UI da jornada do Gerente | COMP-06 | CONSTRUIR | PARCIAL | QA-TEC-15, QA-NEG-18 |
| SPEC-SFC-05 | Notificação ao Gerente | COMP-06 | CONFIGURAR | PRONTA | — |
| SPEC-API-01 | Contrato API Adesão v1 (Salesforce → COMP-01) | COMP-01/06/09 | ACORDAR | PRONTA | — |
| SPEC-API-02 | Contrato do callback GACD (GACD → COMP-02) | COMP-02/14 | ACORDAR | BLOQUEADA | QA-TEC-07 |
| SPEC-API-03 | Contrato Alerta de Assinantes Inválidos v1 (Canal → COMP-02) | COMP-02/18 | ACORDAR | BLOQUEADA | QA-TEC-08 |
| SPEC-API-04 | Contrato de saída para o Salesforce (upsert) | COMP-03/06 | ACORDAR | PARCIAL | QA-TEC-15 |
| SPEC-API-05 | Contrato de consumo FIRP | COMP-01.2/13 | ACORDAR | BLOQUEADA | QA-TEC-05 |
| SPEC-API-06 | Contratos de consumo GACD (3 chamadas + opcionais) | COMP-01.3/14 | ACORDAR | BLOQUEADA | QA-TEC-06, QA-TEC-04, QA-TEC-24 |
| SPEC-API-07 | Contrato de consumo IMPD | COMP-01.4/16 | ACORDAR | BLOQUEADA | QA-TEC-01, QA-TEC-02 |
| SPEC-EVT-01 | Envelope e catálogo de eventos versionados | COMP-01/03 | CONSTRUIR | PRONTA | — |
| SPEC-EVT-02 | Registro de schemas e testes de compatibilidade | COMP-01/03 | CONSTRUIR | PRONTA | — |
| SPEC-SEG-01 | Autenticação por fronteira | Todos | CONFIGURAR | PARCIAL | QA-TEC-03, 04, 07, 08, 22, 26 |
| SPEC-SEG-02 | Autorização, escopos e menor privilégio | Todos | CONSTRUIR | PARCIAL | QA-TEC-22 |
| SPEC-SEG-03 | LGPD: minimização, mascaramento e retenção | Todos | CONSTRUIR | PARCIAL | QA-TEC-17, QA-TEC-24 |
| SPEC-SEG-04 | Segmentação de rede (NetworkPolicy, EgressFirewall) | COMP-10/12 | CONFIGURAR | PARCIAL | QA-TEC-09 |
| SPEC-SEG-05 | Hardening de aplicação, cabeçalhos e imagem | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-SEG-06 | Segurança da cadeia de suprimentos | Pipeline | CONFIGURAR | PARCIAL | QA-TEC-19, QA-TEC-29 |
| SPEC-INF-01 | Manifestos ARO (Deployment, HPA, PDB, probes) | COMP-10 | CONFIGURAR | PRONTA | PRM-TEC-09 |
| SPEC-INF-02 | Pipeline CI/CD | Pipeline | CONFIGURAR | BLOQUEADA | QA-TEC-19 |
| SPEC-INF-03 | Ambientes (local, Dev, Hom, Prod) | Todos | PROVISIONAR | PARCIAL | QA-TEC-21 |
| SPEC-INF-04 | Infraestrutura como código | COMP-04/05/11 | PROVISIONAR | BLOQUEADA | QA-TEC-20 |
| SPEC-INF-05 | Configuração do Axway | COMP-09 | CONFIGURAR | PARCIAL | QA-TEC-03, 09, 10, 22 |
| SPEC-INF-06 | Key Vault e `SecretProviderClass` | COMP-11 | PROVISIONAR | PARCIAL | QA-TEC-14 |
| SPEC-OBS-01 | Métricas técnicas e de negócio | Todos | CONSTRUIR | PRONTA | — |
| SPEC-OBS-02 | Alertas, painéis e runbooks | COMP-19 | CONFIGURAR | PARCIAL | QA-TEC-16 |
| SPEC-OBS-03 | KPIs e dados para auditoria (CAP-12) | COMP-01/03 | CONSTRUIR | PARCIAL | QA-TEC-17, QA-NEG-06 |
| SPEC-TST-01 | Testes unitários e de arquitetura | Todos | CONSTRUIR | PRONTA | — |
| SPEC-TST-02 | Testes de integração com Testcontainers | COMP-01/02/03 | CONSTRUIR | PRONTA | — |
| SPEC-TST-03 | Simuladores de dependências (WireMock) | COMP-01/03 | CONSTRUIR | PARCIAL | Contratos API-05..07 |
| SPEC-TST-04 | Testes de contrato | COMP-01/02/03/06 | CONSTRUIR | PARCIAL | QA-TEC-07, 08, 15 |
| SPEC-TST-05 | Testes de carga | Todos | VALIDAR | PARCIAL | QA-TEC-21 |
| SPEC-TST-06 | Testes de segurança (SAST, SCA, DAST) | Todos | VALIDAR | PARCIAL | QA-TEC-29 |
| SPEC-TST-07 | Testes do template do termo | COMP-01.4 | VALIDAR | PARCIAL | QA-TEC-02, QA-CON-19 |
| SPEC-TST-08 | Testes de resiliência, recuperação e migração | Todos | VALIDAR | PRONTA | — |

### 1.4 Dependências técnicas entre grupos de SPEC

Precedência técnica (quem precisa existir antes), não prioridade de negócio.

```mermaid
flowchart LR
  TRV["SPEC-TRV-01..15<br/>fundação comum"]
  DB["SPEC-DB-02..03<br/>schemas e migrações"]
  EVT["SPEC-EVT-01..02<br/>envelope de eventos"]
  TER1["SPEC-TER-01..02<br/>domínio e persistência"]
  TER3["SPEC-TER-03..07<br/>API Adesão"]
  TER8["SPEC-TER-08, 10, 11<br/>tarefas, outbox, auditoria"]
  ELG["SPEC-ELG-01"]
  FIR["SPEC-FIR-01..02"]
  DOC["SPEC-DOC-01..05"]
  GAC["SPEC-GAC-01..03"]
  REC["SPEC-REC-01..04"]
  TER9["SPEC-TER-09<br/>inbox"]
  ACP["SPEC-ACP-01..05"]
  SFC["SPEC-SFC-01..05"]
  API["SPEC-API-01..07<br/>acordos de contrato"]
  INF["SPEC-INF, SEG, DB-01, STG-01<br/>infra e segurança"]
  OBS["SPEC-OBS-01..03"]

  TRV --> DB
  TRV --> EVT
  DB --> TER1
  TER1 --> TER8
  EVT --> TER8
  TER8 --> TER3
  ELG --> TER3
  TER8 --> FIR
  TER8 --> DOC
  TER8 --> GAC
  DOC --> GAC
  DB --> REC
  REC --> TER9
  TER8 --> TER9
  EVT --> ACP
  TER8 --> ACP
  API --> FIR
  API --> GAC
  API --> REC
  API --> SFC
  ACP --> SFC
  INF --> OBS
  TER3 --> SFC
```

---

## 2. Visão geral técnica e premissas

### 2.1 Resumo da solução (04, ADR-01)

| Deployable | Papel técnico | Entrada | Saída | Estado |
|---|---|---|---|---|
| COMP-01 `atacado-adesao-termo` | Monólito modular: API Adesão v1, agregado `AdesaoTermo`, fila de tarefas, saga GACD, geração do documento, processamento da inbox, outbox, auditoria, API administrativa | HTTPS (Salesforce via Akamai → AppGW → Axway); SQL (inbox) | FIRP e GACD (Axway interno), IMPD, Blob, PostgreSQL | `adesao_termo`, `termo_documento`; lê e atualiza `adesao_entrada` |
| COMP-02 `atacado-adesao-receptor` | Borda de entrada sem regra de domínio: callback do GACD e alerta do Canal → inbox | HTTPS (Axway interno) | PostgreSQL | grava `adesao_entrada` |
| COMP-03 `atacado-adesao-acompanhamento` | Worker: relay da outbox, projeção da jornada, alertas, entrega ao Salesforce | SQL (outbox) | Salesforce REST (egress pelo Hub) | `adesao_acompanhamento`; consome `adesao_termo.outbox_evento` |
| COMP-04 `atacado-adesao-db` | PostgreSQL 16 Flexible Server, um schema por BC | — | — | — |
| COMP-05 `atacado-adesao-staging` | Blob Storage, container `termos-staging`, lifecycle 30 dias | — | — | PDF transitório |
| COMP-06 Artefatos Salesforce do Atacado | UI, Named/External Credential, Connected App, objetos `Adesao_Termo__c` e `Alerta_Adesao__c`, Flow de notificação | — | — | Projeção de status |

### 2.2 Stack de referência dos deployables

As versões exatas ficam fixadas no POM pai (SPEC-TRV-01). A tabela registra o **mínimo** aceito.

| Item | Escolha | Mínimo | Origem |
|---|---|---|---|
| Runtime | Java 21 LTS (virtual threads) | 21 | RST-05, 04a §1.2 |
| Framework | Spring Boot 3.x (Web MVC, Validation, Actuator, Security OAuth2 Resource Server/Client, JDBC) | 3.3 | 04a §1.2; virtual threads nativas desde 3.2 |
| Modularidade | Spring Modulith + ArchUnit | Modulith 1.2 | 04a §1.2, [DT-02] |
| Persistência | Spring Data JDBC + `JdbcClient`; PostgreSQL JDBC; HikariCP | — | [DT-04] |
| Migrações | Flyway (só COMP-01, Job pré-deploy) | 10.x | ADR-01 |
| Resiliência | Resilience4j | 2.x | ADR-12 |
| Agendamento | Spring Scheduling + ShedLock (JDBC) | ShedLock 5 | 04a §1.2 |
| Observabilidade | OpenTelemetry Java agent, Micrometer + Prometheus, Logback + `logstash-logback-encoder` | agente 2.x | ADR-12, PRM-TEC-12 |
| Azure | Azure SDK BOM (`azure-storage-blob`, `azure-identity`) | — | 04a COMP-01 |
| Documento (Plano B) | Thymeleaf + OpenHTMLtoPDF (sobre Apache PDFBox), PDF/A-2b | — | ADR-03 |
| Testes | JUnit 5, AssertJ, Testcontainers (PostgreSQL 16, Azurite), WireMock 3, Gatling (Java DSL), veraPDF | — | 04a §1.2, [DT-14] |
| Imagem | UBI 9 OpenJDK 21 runtime, usuário não root, SCC `restricted-v2` | — | PRM-TEC-09 |
| Build | Maven 3.9 via Maven Wrapper (`./mvnw`) | 3.9 | [DT-01], `AGENTS.md` |

### 2.3 Premissas técnicas aplicadas

Premissas do 04 (PRM-TEC-01..15) e o efeito de cada uma nesta especificação.

| Premissa | Enunciado resumido | Efeito nas SPECs | Se falsa |
|---|---|---|---|
| PRM-TEC-01 | PostgreSQL Flexible Server no spoke, acesso privado | DDL da seção 6; SPEC-DB-01..04 | Trocar o SGBD gerenciado; DDL revisto, padrão outbox mantido |
| PRM-TEC-02 | Blob com private endpoint para staging | SPEC-DOC-05, SPEC-STG-01 | Ativar a coluna `documento_termo.conteudo` (`bytea`) — ADR-04 b |
| PRM-TEC-03 | 500 solicitações/dia, pico 50/h, PDF ≤ 1 MB, até 10 assinantes | Pools, réplicas, limites (SPEC-INF-01), cenários de carga (SPEC-TST-05) | Recalibrar réplicas e pools |
| PRM-TEC-04 | Token LEAP por client credentials + usuário sistêmico no passo 2 | `CredencialProvider` (SPEC-TRV-10, TRV-15) | Trocar só o adaptador de credencial |
| PRM-TEC-05 | Callback e alerta por rota interna do Axway | SPEC-REC-01..03, SPEC-INF-05 | Publicar as políticas na borda externa |
| PRM-TEC-06 | Entrada do Salesforce pela borda externa; egress pelo Firewall do Hub | SPEC-SFC-02, SPEC-ACP-03, SPEC-SEG-04 | Proxy corporativo no egress |
| PRM-TEC-07 | Sem broker corporativo | Relay por polling (SPEC-ACP-01) e fila de tarefas em tabela (SPEC-TER-08) | Relay publica no broker; produtor inalterado |
| PRM-TEC-08 | Secrets Store CSI Driver disponível | SPEC-TRV-10, SPEC-INF-06 | External Secrets Operator |
| PRM-TEC-09 | Java 21 em UBI 9 suportado pela esteira | SPEC-INF-01/02 | Ajustar imagem base |
| PRM-TEC-10 | Elegibilidade informada pelo Salesforce | SPEC-ELG-01 | Novo adaptador para BC-13 |
| PRM-TEC-11 | Passos 2 e 3 do GACD repetíveis; passo 1 não | SPEC-GAC-02 | Reconciliação também nos passos 2 e 3 |
| PRM-TEC-12 | Stack de observabilidade compatível com OTel/Prometheus | SPEC-TRV-12, SPEC-OBS | Trocar exportadores |
| PRM-TEC-13 | Níveis de serviço do RNF-06/07/08 aceitos | Metas dos CA de desempenho e alertas | Revisar metas |
| PRM-TEC-14 | Confirmação do Gerente desejada (flag) | SPEC-TER-05, SPEC-TRV-14 | Flag desligada; saga inicia após `TermoGerado` |
| PRM-TEC-15 | Canal chama o Axway interno com identidade própria | SPEC-REC-02/03 | Política pela borda externa |

**Premissas novas deste documento**

| ID | Premissa | Impacto se falsa | Validar com |
|---|---|---|---|
| PRM-TEC-16 | Existe esteira corporativa de CI/CD para o ARO com entrega por GitOps (ex.: OpenShift GitOps/Argo CD) e hooks pré-sincronização para Jobs de migração | Migração executada por etapa de pipeline em vez de hook; SPEC-INF-02 revista | Plataformas Funcionais (QA-TEC-19) |
| PRM-TEC-17 | Recursos Azure da solução (PostgreSQL, Blob, Key Vault, private endpoints) são provisionados por IaC em Terraform (`azurerm`), com módulos corporativos quando existirem | Bicep ou solicitação à plataforma; SPEC-INF-04 revista | Plataformas Funcionais (QA-TEC-20) |
| PRM-TEC-18 | `groupId` Maven `br.com.bradesco.atacado` e pacote raiz `br.com.bradesco.atacado.adesao` seguem o padrão da casa | Renomear coordenadas e pacotes antes do primeiro commit | Plataformas Funcionais |
| PRM-TEC-19 | O `idProposta` enviado pelo Salesforce é o Id (18 caracteres) do registro da Proposta no Salesforce | Campo de lookup `Proposta__c` passa a ser resolvido por External ID | Atacado Cash Payments (QA-TEC-15) |

### 2.4 Decisões técnicas deste documento (DT)

| ID | Decisão | Alternativas consideradas | Justificativa |
|---|---|---|---|
| DT-01 | **Maven multi-módulo** com **Maven Wrapper**, POM pai + BOM interno | Gradle (Kotlin DSL) multi-projeto | Padrão da casa para Java (Maven Wrapper em `AGENTS.md`); 04a §1.2 já indica "repositório multi-módulo Maven"; esteiras corporativas e Sonar/SCA têm integração madura com Maven; build declarativo e previsível para um time; Gradle traria ganho de performance irrelevante para 3 deployables |
| DT-02 | Módulos internos do COMP-01 (01.1..01.6) são **pacotes** verificados por **Spring Modulith** (`ApplicationModules.verify()`) e **ArchUnit**, não submódulos Maven | Um submódulo Maven por módulo interno | Mantém um único artefato e uma transação local (ADR-01); Modulith verifica dependências e publica documentação; a extração futura (03 §8.3) continua barata porque as fronteiras são testadas |
| DT-03 | **Contrato primeiro**: OpenAPI 3.1 em YAML versionado em `contratos/openapi/` é a fonte; controladores escritos à mão e validados contra o YAML em teste | Gerar o contrato a partir do código (springdoc) como fonte; gerar interfaces com openapi-generator | O contrato precisa ser negociado com Salesforce, Canais e GACD **antes** do código; springdoc fica só em teste para detectar divergência (refina 04a §1.2) |
| DT-04 | Persistência com **Spring Data JDBC** para o agregado e `JdbcClient` para filas (inbox, outbox, tarefas) | JPA/Hibernate | Agregado com fronteira explícita, sem lazy loading nem dirty checking; SQL explícito para `FOR UPDATE SKIP LOCKED` e índices parciais |
| DT-05 | **Fila de tarefas interna** (`adesao_termo.tarefa`) para as etapas assíncronas do COMP-01; a **outbox tem consumidor único** (COMP-03) | COMP-01 consumir a própria outbox (03 §5.1) | Evita dois consumidores disputando a coluna de situação da outbox; a tarefa nasce na mesma transação da transição (INV-10 preservada) |
| DT-06 | `Idempotency-Key` persistida em tabela com TTL de 72 h; repetição devolve o **status e o corpo originais** com `Idempotent-Replayed: true` | Cache em memória; responder `200` na repetição (04 §11.1) | Sobrevive a restart e a múltiplas réplicas; o cliente Apex trata um único caminho de sucesso |
| DT-07 | Problem Details (RFC 9457) com `type` em URN `urn:atacado:adesao:problema:<codigo>` e catálogo fechado de códigos | URLs HTTP de documentação | Não depende de domínio publicado; código estável para o Apex e o Canal tratarem |
| DT-08 | Envelope de evento com **dois campos de correlação**: `correlationId` (técnico, de `X-Correlation-ID`) e `chaveCorrelacaoNegocio` (`codigoProtocolo` ou `idAdesao`) | Um único campo (03 §5.2 × 04 §9.3 divergem) | Atende as duas definições sem perder informação |
| DT-09 | Feature flags como **propriedades tipadas** em ConfigMap versionado (GitOps), alteradas por rollout | Serviço de feature flags externo | Poucas flags, baixo volume; mudança auditada no Git; sem nova dependência |
| DT-10 | Três portas por deployable: **8080** negócio, **8081** Actuator, **8082** administração | Tudo na 8080 | Só a 8080 tem Route/ingress; Actuator e admin ficam fora do caminho externo (04 §9.2) |
| DT-11 | `trilha_auditoria` **particionada por mês** (particionamento nativo) e protegida por privilégio (`INSERT`/`SELECT`) e trigger | Tabela única com `DELETE` periódico | Expurgo por `DROP PARTITION` sem violar o append-only; consultas por período eficientes |
| DT-12 | Salesforce descarta **silenciosamente** atualização com `Versao_Evento__c` menor; COMP-03 **coalesce** entregas de status pendentes do mesmo registro (`SUPERADA`) | Regra de validação que rejeita (4xx) | Rejeição geraria erro permanente e estacionamento indevido; o status é projeção de estado, só a versão mais nova importa |
| DT-13 | Testes de contrato baseados em **OpenAPI com validação nos dois sentidos**; **Pact** só com times que aderirem | Pact obrigatório | O consumidor principal é Apex (sem suporte prático a Pact); Canal e GACD têm stack desconhecida |
| DT-14 | Testes de carga com **Gatling (Java DSL)** | k6, JMeter | Mesma linguagem do time; relatórios versionáveis no repositório |
| DT-15 | Amostragem de traces **100%** em todos os ambientes | Amostragem por razão | Volume baixo (PRM-TEC-03); cada adesão precisa de trace completo para suporte |
| DT-16 | **[PROPOSTA]** Cancelamento permitido em **Gerado** antes do início da saga (T-17) | Só nos estados do 03 §6 | Com a confirmação no estado Gerado (ADR-02), o Gerente pode desistir ao ver a prévia; não cria estado novo (compatível com PRM-DDD-10) |
| DT-17 | **[PROPOSTA]** Evento `PendenciaAssinaturaProlongada` e alerta `PENDENCIA_PROLONGADA`, atrás de flag | Nenhum aviso até o Canal entregar a API de alerta | Mitigação prevista no ADR-09 e RSK-06 |
| DT-18 | Imagem por **Dockerfile multi-estágio** sobre UBI 9 OpenJDK 21 runtime com *layered jar* | Jib; buildpacks | Compatível com builds em OpenShift (buildah) e com o scanner corporativo; camadas reaproveitadas |
| DT-19 | Value object `Cnpj` aceita **CNPJ alfanumérico** (12 posições alfanuméricas + 2 dígitos verificadores) | Só numérico | A Receita Federal adotou o CNPJ alfanumérico para novas inscrições a partir de julho/2026; a solução nasce compatível (QA-TEC-25) |
| DT-20 | Restrição de egress do COMP-03 por **NetworkPolicy por pod** + **EgressFirewall** do namespace (FQDN do My Domain) + **EgressIP** dedicado, se disponível | Só EgressFirewall (04 §7.1) | O EgressFirewall do OVN-Kubernetes vale para o namespace inteiro, não por pod; a exclusividade exige NetworkPolicy no pod e, no Firewall do Hub, regra por IP de origem |

---
## 3. Padrões transversais

Valem para COMP-01, COMP-02 e COMP-03, salvo indicação. Cada padrão é uma SPEC-TRV com critérios próprios.

### 3.1 SPEC-TRV-01 — Repositório único e build Maven multi-módulo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-02, COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | ADR-01 · RSK-17 · RNF-13, RNF-16 · [DT-01], [DT-02], [DT-18] · `AGENTS.md` (padrão mínimo por projeto) |
| Depende de | — |
| Bloqueios | QA-TEC-19 afeta só a publicação de imagens |

**Estrutura do repositório `atacado-adesao`**

```text
atacado-adesao/
├── README.md                        # objetivo, stack, pré-requisitos, setup, primeiro comando
├── setup.sh                         # bootstrap local (executável)
├── .env.example                     # variáveis locais, sem segredos reais
├── .gitignore                       # Java/Maven/IDE/.env
├── mvnw, mvnw.cmd, .mvn/wrapper/    # Maven Wrapper (versão fixada)
├── pom.xml                          # POM pai: versões, plugins, enforcer, perfis
├── bom/                             # atacado-adesao-bom: versões internas e de terceiros
├── contratos/
│   ├── openapi/                     # api-adesao-v1.yaml, callback-gacd-v1.yaml, alerta-assinantes-invalidos-v1.yaml
│   ├── eventos/                     # <TipoEvento>/v<n>.schema.json (JSON Schema 2020-12)
│   └── externos/                    # contratos de FIRP, GACD, IMPD (hipotéticos até QA-TEC-05/06/01)
├── libs/
│   ├── adesao-plataforma/           # problem details, correlação, logging com máscara, cliente HTTP, CredencialProvider
│   ├── adesao-contrato-eventos/     # records do envelope + validação contra os schemas (Published Language, sem domínio)
│   └── adesao-contrato-inbox/       # record SinalExterno + DAO de inserção (contrato interno COMP-02 ↔ COMP-01)
├── servicos/
│   ├── atacado-adesao-termo/        # COMP-01 (pacotes: adesaotermo, aclfirp, aclgacd, termodocumento, aclregistrocontratos, convenioproduto)
│   │   └── src/main/resources/db/migration/   # Flyway (dono único das migrações)
│   ├── atacado-adesao-receptor/     # COMP-02
│   └── atacado-adesao-acompanhamento/ # COMP-03
├── testes/
│   ├── simuladores/                 # mapeamentos WireMock (FIRP, GACD, IMPD, LEAP, Salesforce)
│   ├── carga/                       # Gatling
│   └── e2e/                         # cenários ponta a ponta para Hom
├── deploy/
│   ├── helm/atacado-adesao/         # chart com os 3 deployables + Job de migração
│   └── ambientes/{dev,hom,prd}/     # values por ambiente (sem segredos)
├── infra/terraform/                 # PostgreSQL, Blob, Key Vault, private endpoints (PRM-TEC-17)
├── local/docker-compose.yaml        # postgres:16, azurite, wiremock
└── docs/                            # ADRs locais, runbooks, catálogo de flags
```

**Regras**

- Um único `./mvnw verify` compila, testa e empacota os três deployables com a **mesma versão** (RSK-17). Versionamento semântico `MAJOR.MINOR.PATCH`; a versão da imagem é a do POM + SHA curto do commit.
- `maven-enforcer-plugin`: Java 21, Maven ≥ 3.9, convergência de dependências, proibição de dependências duplicadas e de `SNAPSHOT` em release.
- As bibliotecas em `libs/` **não** contêm regra de domínio (sem Shared Kernel, 03 §4.5). `adesao-contrato-eventos` só contém o envelope e tipos simples.
- COMP-02 depende apenas de `adesao-plataforma` e `adesao-contrato-inbox`; COMP-03 apenas de `adesao-plataforma` e `adesao-contrato-eventos`.
- `setup.sh` (padrão `AGENTS.md`): verifica Java 21 e Docker/Podman, copia `.env.example` para `.env` se não existir, sobe `local/docker-compose.yaml`, executa `./mvnw -q -DskipTests install` e imprime o próximo comando (`./mvnw -pl servicos/atacado-adesao-termo spring-boot:run -Dspring-boot.run.profiles=local`).
- Imagem: Dockerfile multi-estágio por serviço, base UBI 9 OpenJDK 21 runtime, `USER 185` (não root), `JAVA_TOOL_OPTIONS=-XX:MaxRAMPercentage=75 -XX:+ExitOnOutOfMemoryError`, *layered jar*.
- SBOM CycloneDX gerado no build (`cyclonedx-maven-plugin`) e publicado com a imagem.

**Critérios de aceite**

- CA-TRV-01.1 — Dado um clone limpo com Java 21 e Docker, quando `./setup.sh` é executado, então o ambiente local sobe (PostgreSQL, Azurite, WireMock) e o script termina com código 0 e a instrução do próximo passo.
- CA-TRV-01.2 — Quando `./mvnw verify` é executado, então os três JARs e os testes unitários, de arquitetura e de integração passam sem acesso a rede externa.
- CA-TRV-01.3 — Dada uma dependência declarada com versão divergente entre módulos, quando o build roda, então o enforcer falha.
- CA-TRV-01.4 — Dado o build de release, quando as imagens são geradas, então as três têm a mesma tag de versão, rodam como usuário não root e acompanham SBOM.
- CA-TRV-01.5 — O `README.md` documenta objetivo, stack, pré-requisitos, setup, primeiro comando e como rodar os testes (padrão `AGENTS.md`).

### 3.2 SPEC-TRV-02 — Convenções de código Java 21 / Spring Boot 3

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-13 · 03 §3.2 (linguagem ubíqua) · [DT-04], [DT-19] |

| Tema | Convenção |
|---|---|
| Idioma | Domínio e casos de uso em **português**, com os termos da linguagem ubíqua do 03 (`AdesaoTermo`, `Assinante`, `ProtocoloAssinatura`, `ReemitirTermo`). Termos técnicos consagrados podem ficar em inglês (`Repository`, `Controller`, `Port`) |
| Pacote raiz | `br.com.bradesco.atacado.adesao.<servico>.<modulo>` (PRM-TEC-18) |
| Tipos | `record` para value objects, DTOs, comandos e eventos; `sealed interface` para resultados de portas (ex.: `ResultadoConsultaAssinantes`); `enum` para estados e motivos; sem Lombok |
| Injeção | Só por construtor; sem `@Autowired` em campo |
| Nulos | `Optional` só em retorno; parâmetros validados com `Objects.requireNonNull` ou Bean Validation na borda |
| Tempo | `Instant` no domínio e no banco (`timestamptz`); API em ISO-8601 com offset; `Clock` injetado para testes |
| Concorrência | `spring.threads.virtual.enabled=true`; nenhum `synchronized` em volta de I/O (pinning); limites de concorrência por `Semaphore`/bulkhead |
| HTTP de saída | `RestClient` do Spring com o cliente padronizado da SPEC-TRV-15; proibido `RestTemplate` novo e `WebClient` reativo |
| Identificadores | UUID (v4 ou v7) para `idAdesao`, `idEvento`, `idAlerta`; `Cnpj` como VO com validação de dígito verificador e suporte a formato alfanumérico [DT-19] |
| Exceções | Exceções de domínio sem stack trace para o cliente; mapeamento em um único `@RestControllerAdvice` (SPEC-TRV-04) |
| Qualidade | Formatação automática (Spotless com google-java-format), Checkstyle e análise estática no build; build falha em violação |
| `toString` | Records com dados pessoais (`Assinante`, `DadosComposicao`) sobrescrevem `toString` com mascaramento (SPEC-TRV-08) |

**Critérios de aceite**

- CA-TRV-02.1 — Quando o build roda, então Spotless e Checkstyle falham ao encontrar código fora do padrão.
- CA-TRV-02.2 — Dado um CNPJ numérico válido (ex.: `11222333000181`) e um CNPJ alfanumérico válido da massa de exemplos publicada pela Receita Federal, então ambos são aceitos; dígito verificador inválido lança `CnpjInvalido`.
- CA-TRV-02.3 — Um teste ArchUnit falha se houver injeção por campo, uso de `RestTemplate` ou `synchronized` em classes de adaptador de saída.

### 3.3 SPEC-TRV-03 — Arquitetura hexagonal e fronteiras de módulo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-13 · 03 §8.2 · PRM-DDD-04 · ADR-01, ADR-03 · [DT-02] |

**Estrutura por módulo**

```text
<modulo>/
├── dominio/            # agregados, VOs, políticas, eventos de domínio; sem Spring, sem JDBC, sem HTTP
├── aplicacao/          # casos de uso (portas de entrada) e orquestração transacional
│   └── porta/          # portas de saída (interfaces) usadas pelos casos de uso
├── adaptador/
│   ├── entrada/        # REST (controllers), jobs agendados, consumidores de fila/inbox
│   └── saida/          # JDBC, clientes HTTP (FIRP, GACD, IMPD, Salesforce), Blob
└── configuracao/       # beans, @ConfigurationProperties
```

**Portas por módulo do COMP-01**

| Módulo | Portas de entrada (casos de uso) | Portas de saída | Adaptadores de saída |
|---|---|---|---|
| 01.1 `adesaotermo` | `SolicitarTermoAdesao`, `ConsultarAdesao`, `ObterPreviaDocumento`, `ConfirmarAssinantes`, `ReemitirTermo`, `EncerrarTermo`, `ProcessarSinalExterno`, `ExecutarTarefa`, `OperacaoAdministrativa` | `RepositorioAdesaoTermo`, `PublicadorEventos` (outbox), `RegistroAuditoria`, `FilaTarefas`, `RepositorioSinais`, `ConsultaAssinantesPort`, `AssinaturaDigitalPort`, `GeradorDocumentoPort`, `ElegibilidadePort`, `SolicitacaoConvenioPort` | JDBC (agregado, outbox, auditoria, tarefas, inbox) |
| 01.2 `aclfirp` | (implementa `ConsultaAssinantesPort`) | `ClienteFirp` | REST FIRP via Axway |
| 01.3 `aclgacd` | `ExecutarPassoSaga`, `ReconciliarProtocolo` | `AssinaturaDigitalPort` (implementa), `ClienteGacd`, `RepositorioSaga` | REST GACD via Axway; JDBC saga |
| 01.4 `termodocumento` | `GerarDocumentoTermo` (implementa `GeradorDocumentoPort`), `ObterDocumento` | `RenderizadorDocumento`, `StagingDocumento`, `CatalogoModelos` | IMPD REST; renderizador próprio; Blob; JDBC catálogo |
| 01.5 `aclregistrocontratos` | (implementa `ElegibilidadePort`) | — | Indicadores do comando (Salesforce) |
| 01.6 `convenioproduto` | — | `SolicitacaoConvenioPort` (interface) | Nenhum ativo |

**Regras verificadas por teste**

- `dominio` não importa Spring, Jakarta Persistence, JDBC, Jackson nem HTTP.
- Adaptadores não chamam outros adaptadores; só casos de uso.
- Módulos se comunicam por interface pública do pacote raiz do módulo ou por eventos internos do Spring (`ApplicationEvent` dentro da mesma transação, quando aplicável); nunca por classes internas de outro módulo.
- `convenioproduto` não tem implementação registrada como bean enquanto `convenio.gatilho.habilitado=false`.
- COMP-02 não depende de nenhum pacote de domínio do COMP-01 (só de `adesao-contrato-inbox`).

**Critérios de aceite**

- CA-TRV-03.1 — Quando `ApplicationModules.of(AplicacaoTermo.class).verify()` roda, então não há ciclos nem acesso a tipos internos entre módulos.
- CA-TRV-03.2 — Dado um import de `org.springframework` em `..dominio..`, quando os testes ArchUnit rodam, então o build falha.
- CA-TRV-03.3 — O Modulith gera a documentação dos módulos (diagrama C4 de componentes) em `target/` a cada build.

### 3.4 SPEC-TRV-04 — Erros padronizados (RFC 9457 Problem Details)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-02 · CONSTRUIR · PRONTA |
| Rastreio | RNF-01, RNF-04 · R-01, R-13 · [DT-07] |

**Formato** — `Content-Type: application/problem+json`

```json
{
  "type": "urn:atacado:adesao:problema:ESTADO_INCOMPATIVEL",
  "title": "Operação não permitida no estado atual",
  "status": 409,
  "detail": "A adesão está em ASSINADO e não aceita reemissão.",
  "instance": "/v1/adesoes/5b7c.../reemissao",
  "codigo": "ESTADO_INCOMPATIVEL",
  "correlationId": "0f9d6c1e-2c1f-4a41-8f0c-6a3e0d6c9b11",
  "estadoAtual": "ASSINADO",
  "erros": [ { "campo": "produtos[0].codigoProduto", "mensagem": "obrigatório" } ]
}
```

**Catálogo de códigos**

| `codigo` | HTTP | Quando | Onde |
|---|---|---|---|
| `REQUISICAO_INVALIDA` | 400 | Esquema, tipo ou campo obrigatório inválido (lista em `erros[]`) | Todas |
| `CNPJ_INVALIDO` | 400 | Dígito verificador ou formato inválido | API Adesão, alerta |
| `IDEMPOTENCY_KEY_AUSENTE` | 400 | Comando `POST` sem `Idempotency-Key` | API Adesão |
| `IDEMPOTENCY_KEY_REUTILIZADA` | 422 | Mesma chave com corpo diferente | API Adesão |
| `REQUISICAO_EM_PROCESSAMENTO` | 409 | Mesma chave ainda em processamento | API Adesão |
| `ADESAO_NAO_TERMINAL_EXISTENTE` | 409 | INV-01 violada; extensão `idAdesaoExistente` | `POST /v1/adesoes` |
| `ADESAO_NAO_ENCONTRADA` | 404 | `idAdesao` inexistente | API Adesão |
| `ESTADO_INCOMPATIVEL` | 409 | Comando não permitido no estado (matriz da seção 7.3); extensão `estadoAtual` | API Adesão |
| `VERSAO_DESATUALIZADA` | 412 | `If-Match` diferente da versão atual | Comandos sobre adesão existente |
| `DOCUMENTO_DIVERGENTE` | 409 | `hashDocumento` confirmado ≠ hash do documento atual | Confirmação |
| `CONFIRMACAO_DESABILITADA` | 409 | Confirmação chamada com a flag desligada | Confirmação |
| `DOCUMENTO_INDISPONIVEL` | 404 | Documento ainda não gerado | Prévia |
| `DOCUMENTO_EXPIRADO` | 410 | Documento removido do staging (terminal ou lifecycle) | Prévia |
| `NAO_AUTENTICADO` / `ACESSO_NEGADO` | 401 / 403 | Credencial ausente/inválida; escopo ou identidade não autorizada | Todas |
| `CORPO_EXCEDE_LIMITE` | 413 | Corpo acima do limite do endpoint | Todas |
| `LIMITE_REQUISICOES` | 429 | Rate limit (normalmente aplicado no Axway) + `Retry-After` | Todas |
| `SERVICO_INDISPONIVEL` | 503 | Banco indisponível ou circuito aberto em dependência obrigatória; `Retry-After` | Todas |
| `ERRO_INTERNO` | 500 | Falha não prevista; nunca expõe stack trace nem SQL | Todas |

**Regras**

- `detail` e extensões **nunca** contêm dado pessoal, payload recebido, SQL ou nome de classe.
- Erros de integração de saída (FIRP, GACD, IMPD, Salesforce) não viram HTTP para o Salesforce: são tratados de forma assíncrona. Internamente são classificados em `FalhaIntegracao` com `natureza` ∈ {`TRANSITORIA`, `PERMANENTE`, `INCERTA`}, que orienta retentativa (SPEC-TRV-11) e saga (seção 9).
- Validação de entrada com Bean Validation; mensagens em português.

**Critérios de aceite**

- CA-TRV-04.1 — Dado qualquer erro 4xx/5xx de COMP-01 ou COMP-02, então a resposta tem `application/problem+json`, `type` URN do catálogo, `codigo` e `correlationId`.
- CA-TRV-04.2 — Dada uma exceção não tratada com mensagem contendo CPF, então a resposta é `ERRO_INTERNO` com `detail` genérico e o log registra a exceção mascarada.
- CA-TRV-04.3 — Um teste parametrizado cobre cada código do catálogo com seu status HTTP.

### 3.5 SPEC-TRV-05 — Versionamento de APIs e contratos

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-02 · CONSTRUIR · PARCIAL (QA-TEC-23) |
| Rastreio | R-01, R-02, R-13 · RNF-13 · [DT-03] |

| Regra | Especificação |
|---|---|
| Versão maior no caminho | `/v1/...` no serviço; no Axway, `/atacado/adesao/v1/...` (o Axway reescreve o prefixo) |
| Mudança compatível | Novo campo opcional na resposta, novo endpoint, novo valor de enum **documentado como extensível** → sem nova versão maior; `info.version` do OpenAPI sobe MINOR |
| Mudança incompatível | Remoção/renomeação de campo, campo novo obrigatório na requisição, mudança de semântica → `/v2` convivendo com `/v1` por prazo mínimo proposto de 6 meses (QA-TEC-23) |
| Depreciação | Cabeçalhos `Deprecation` (RFC 9745) e `Sunset` (RFC 8594) na versão antiga; registro no catálogo do Axway |
| Leitor tolerante | Todos os desserializadores ignoram campos desconhecidos (`FAIL_ON_UNKNOWN_PROPERTIES=false`); campos desconhecidos **não** são persistidos |
| Enums | Clientes (Apex, Canal) devem tratar valor desconhecido de `status`/`motivo` como "outro" (documentado no OpenAPI) |
| Eventos | `versaoSchema` inteiro no envelope; mudança incompatível cria novo schema `v<n+1>` e o produtor publica as duas versões durante a transição (SPEC-EVT-02) |
| Inbox | Coluna `versao_contrato` em `sinal_externo` (SPEC-REC-04) |

**Critérios de aceite**

- CA-TRV-05.1 — Dado um corpo com campo extra desconhecido, quando enviado a qualquer endpoint, então é aceito e o campo não aparece em banco, log ou evento.
- CA-TRV-05.2 — Um teste compara o OpenAPI gerado pelo springdoc em teste com o YAML de `contratos/openapi/` e falha em divergência de caminho, método, campo obrigatório ou código de resposta.

### 3.6 SPEC-TRV-06 — Idempotência de comandos (`Idempotency-Key`)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01 (API Adesão) · CONSTRUIR · PRONTA |
| Rastreio | RF-01, RF-05, RF-10 · RNF-05 · PRI-06 · ADR-02 · [DT-06] |

**Camadas de idempotência da solução**

| Camada | Chave | Mecanismo | SPEC |
|---|---|---|---|
| Comandos do Salesforce | `Idempotency-Key` (UUID) por consumidor | Tabela `requisicao_idempotente` | Esta |
| Unicidade de negócio | CNPJ com adesão não terminal (INV-01) | Índice único parcial | SPEC-TER-02 |
| Sinais de entrada | `origem` + `chave_idempotencia` | `UNIQUE` + `ON CONFLICT DO NOTHING` | SPEC-REC-04 |
| Consumo de eventos | `idEvento` | Tabela `evento_consumido` | SPEC-ACP-02 |
| Entrega ao Salesforce | External ID + `Versao_Evento__c` | Upsert + descarte de versão antiga | SPEC-ACP-03, SPEC-SFC-01 |
| Chamadas ao GACD | Passo 1 sem retentativa cega; passos 2 e 3 repetíveis | Saga | SPEC-GAC-02 |

**Semântica (comandos `POST` da API Adesão)**

| Situação | Resposta |
|---|---|
| Chave ausente | `400 IDEMPOTENCY_KEY_AUSENTE` |
| Chave nova | Processa; grava `requisicao_idempotente` com `hash_requisicao` (SHA-256 do corpo canônico), status HTTP e corpo da resposta, **na mesma transação** do comando |
| Chave repetida, mesmo hash, concluída | Devolve o **status e o corpo originais** + `Idempotent-Replayed: true` |
| Chave repetida, mesmo hash, em processamento | `409 REQUISICAO_EM_PROCESSAMENTO` + `Retry-After: 1` |
| Chave repetida, hash diferente | `422 IDEMPOTENCY_KEY_REUTILIZADA` |
| Comando rejeitado por regra (4xx) | A rejeição também é registrada e repetida com a mesma chave |
| Falha 5xx | Nada registrado (rollback); o cliente pode repetir com a mesma chave |

Escopo da chave: `(consumidor, chave)`, onde `consumidor` é o `client_id` propagado pelo Axway (SPEC-REC-03 / QA-TEC-22). TTL: 72 h (expurgo pela SPEC-DB-04).

**Critérios de aceite**

- CA-TRV-06.1 — Dado `POST /v1/adesoes` com chave K já concluída (202), quando repetido com o mesmo corpo, então a resposta é 202 com o mesmo `idAdesao` e `Idempotent-Replayed: true`, e nenhuma nova linha é criada em `adesao_termo` ou `outbox_evento`.
- CA-TRV-06.2 — Dada a chave K com corpo diferente, então `422 IDEMPOTENCY_KEY_REUTILIZADA`.
- CA-TRV-06.3 — Dadas duas requisições simultâneas com a mesma chave em réplicas diferentes, então exatamente uma processa e a outra recebe 409 ou o replay.
- CA-TRV-06.4 — Dado um rollback por falha de banco, quando a mesma chave é reenviada, então o comando é processado normalmente.

### 3.7 SPEC-TRV-07 — Correlação e propagação de contexto

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PARCIAL (QA-TEC-22: preservação de cabeçalhos no Axway) |
| Rastreio | RNF-10, RNF-11 · PRI-11 · 04 §9.3 · 03 §5.2 · PRM-CON-12 · [DT-08] |

| Elemento | Regra |
|---|---|
| `X-Correlation-ID` | Aceito na entrada (UUID ou até 64 caracteres `[A-Za-z0-9-]`); se ausente ou inválido, gerado. Devolvido na resposta. Propagado em todas as chamadas de saída |
| `traceparent` / `tracestate` | W3C Trace Context, propagados pelo agente OTel; gravados na outbox, na inbox e na tarefa para **reabrir o trace** com *span link* no processamento assíncrono |
| `correlationId` (envelope) | Valor técnico de `X-Correlation-ID` da requisição que originou a cadeia |
| `chaveCorrelacaoNegocio` (envelope) | `codigoProtocolo` quando existir; antes, `idAdesao` (PRM-CON-12) |
| `causationId` | `idEvento`, id do sinal da inbox ou id da requisição que causou o evento |
| MDC dos logs | `correlationId`, `traceId`, `spanId`, `idAdesao`, `idProposta`, `codigoProtocolo`, `etapa`, `tentativa` |
| Processamento assíncrono | Tarefa, saga e sinal restauram o MDC e o contexto de trace a partir das colunas gravadas antes de executar |

**Critérios de aceite**

- CA-TRV-07.1 — Dado `POST /v1/adesoes` com `X-Correlation-ID: C1`, quando a adesão chega a Aguardando assinatura, então todas as linhas de log, eventos da outbox, registros de auditoria e chamadas simuladas a FIRP/GACD/IMPD da cadeia carregam `C1`.
- CA-TRV-07.2 — Dado um callback do GACD com `traceparent`, quando o COMP-01 processa o sinal, então o span de processamento tem *link* para o trace do callback e o evento `AssinaturaConcluida` carrega `chaveCorrelacaoNegocio` = `codigoProtocolo`.
- CA-TRV-07.3 — Dado `X-Correlation-ID` com caracteres inválidos, então um novo valor é gerado e o valor recebido não é logado.

### 3.8 SPEC-TRV-08 — Logging estruturado sem dados pessoais

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PARCIAL (QA-TEC-16, QA-TEC-26 para padrão corporativo de campos) |
| Rastreio | RNF-04, RNF-10, RNF-11 · RSK-12 · 04 §8.3 |

| Regra | Especificação |
|---|---|
| Formato | JSON por linha em stdout (Logback + `logstash-logback-encoder`); campos: `@timestamp`, `level`, `logger`, `thread`, `message`, `service.name`, `service.version`, `deployment.environment`, MDC da SPEC-TRV-07 |
| Proibido em log | CPF, nome de assinante, matrícula do Gerente fora da auditoria, corpo de requisição/resposta, PDF/base64, tokens, cabeçalho `Authorization`, senhas, chaves |
| Mascaramento | CNPJ com as 5 primeiras e as 2 últimas posições visíveis (`12345*******99`); matrícula como hash curto (`mat#a1b2c3`); regex de CPF e de base64 longo (> 200 caracteres) substituídos por `***` via `MaskingJsonGeneratorDecorator` |
| Níveis | `INFO` para transições de estado e chamadas externas (sem corpo); `WARN` para retentativa; `ERROR` para falha que exige ação; `DEBUG` **proibido em Prod** (validado por configuração) |
| Log de acesso | Método, rota **template** (`/v1/adesoes/{id}`), status, duração, `client_id`; nunca query string completa |
| Segurança | Eventos de autenticação negada (401/403) com `client_id` e IP de origem do Axway, para SIEM (QA-TEC-29) |

**Critérios de aceite**

- CA-TRV-08.1 — Dado um teste que executa o fluxo completo com assinantes sintéticos (nome e CPF), quando os logs capturados são analisados, então nenhum nome, CPF ou trecho de base64 aparece.
- CA-TRV-08.2 — Dado o profile `prd` com `logging.level.root=DEBUG`, então a aplicação não inicia (validação de configuração).
- CA-TRV-08.3 — Cada linha de log de requisição contém `correlationId`, `traceId` e rota template.

### 3.9 SPEC-TRV-09 — Configuração e profiles por ambiente

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-02, RNF-16 · PRM-TEC-08 |

| Profile | Uso | Fontes de configuração |
|---|---|---|
| `local` | Desenvolvimento na máquina (`setup.sh`) | `application.yaml` + `application-local.yaml` + `.env` |
| `test` | Testes automatizados | Testcontainers e WireMock dinâmicos |
| `dev` | ARO Dev | `application.yaml` + ConfigMap (`SPRING_CONFIG_ADDITIONAL_LOCATION=/config/`) + segredos CSI (`spring.config.import=optional:configtree:/mnt/secrets/`) |
| `hom` | ARO Hom (integrações reais de homologação) | Idem |
| `prd` | ARO Prod | Idem; validações extras (DEBUG proibido, flags obrigatórias explícitas) |

**Regras**

- Toda configuração própria em `@ConfigurationProperties` com prefixo `adesao.`, `termo.`, `convenio.` ou `acompanhamento.`, anotadas com `@Validated`; a aplicação **falha na inicialização** se faltar valor obrigatório.
- Nenhum segredo em `application*.yaml`, ConfigMap, variável de ambiente literal ou imagem (RNF-02).
- Diferenças entre ambientes ficam só em `deploy/ambientes/<amb>/values.yaml` (URLs, réplicas, flags).

**Propriedades principais (exemplos, valores por ambiente em SPEC-INF-03)**

| Propriedade | Serviço | Default | Observação |
|---|---|---|---|
| `adesao.firp.base-url` | COMP-01 | — (obrigatória) | URL do Axway interno |
| `adesao.gacd.base-url` | COMP-01 | — | Idem |
| `adesao.gacd.callback-base-url` | COMP-01 | — | `https://<axway-interno>/atacado/adesao/v1/callbacks/gacd/assinaturas` |
| `termo.impd.base-url` | COMP-01 | — | Rota a confirmar (QA-TEC-01) |
| `termo.staging.container` | COMP-01 | `termos-staging` | ADR-04 |
| `termo.documento.tamanho-max-bytes` | COMP-01 | `5242880` | Nominal 1 MB; técnico 5 MB (RNF-15) |
| `adesao.tarefas.intervalo-polling` | COMP-01 | `2s` | SPEC-TER-08 |
| `adesao.inbox.intervalo-polling` | COMP-01 | `1s` | SPEC-TER-09 |
| `acompanhamento.relay.intervalo-polling` | COMP-03 | `1s` | ADR-05 |
| `acompanhamento.relay.tamanho-lote` | COMP-03 | `50` | SPEC-ACP-01 |
| `acompanhamento.salesforce.instance-url` | COMP-03 | — | `https://<mydomain>.my.salesforce.com` |
| `acompanhamento.salesforce.api-version` | COMP-03 | — | Fixada em QA-TEC-15 |
| `acompanhamento.salesforce.audience` | COMP-03 | — | `https://login.salesforce.com` (Prod) / `https://test.salesforce.com` (sandbox) |

**Critérios de aceite**

- CA-TRV-09.1 — Dado o profile `hom` sem `adesao.gacd.base-url`, então a aplicação não inicia e o log indica a propriedade ausente.
- CA-TRV-09.2 — Uma varredura de segredos (gitleaks) no repositório e na imagem não encontra credenciais.

### 3.10 SPEC-TRV-10 — Segredos via Key Vault (CSI) e `CredencialProvider`

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PARCIAL (QA-TEC-14, PRM-TEC-08) |
| Rastreio | RNF-02 · ADR-10 · PRI-08 · CAP-11.2 |

**Regras**

- Segredos montados como arquivos pelo Secrets Store CSI Driver (provider Azure Key Vault) em `/mnt/secrets/` (somente leitura), um arquivo por segredo. **Sem** `secretObjects` (não sincronizar para Secret do Kubernetes) e sem expor como variável de ambiente.
- Rotação: CSI com `rotation-poll-interval` de 2 min (parâmetro da plataforma). A aplicação relê o arquivo:
  - credenciais usadas por chamada (LEAP, usuário sistêmico do GACD, chave JWT do Salesforce, token admin): `CredencialProvider` com cache de até 5 min e releitura imediata após 401 da dependência;
  - banco: preferir autenticação Microsoft Entra ID com token de workload (QA-TEC-14). Sem ela, rotação por **dois usuários alternados** (A/B): o Key Vault troca o usuário ativo e o pool Hikari é reciclado por `softEvict` ao detectar mudança do arquivo.
- `CredencialProvider` é a abstração única (ADR-10) com implementações: `TokenClientCredentials` (LEAP **[HIPÓTESE]**), `UsuarioSistemicoGacd`, `JwtBearerSalesforce`, `TokenAdmin`. Trocar o mecanismo (QA-TEC-03) muda só a implementação.
- Lista completa de segredos: seção 11.7.

**Critérios de aceite**

- CA-TRV-10.1 — Dado o arquivo do segredo LEAP atualizado no volume, quando a próxima chamada à FIRP ocorre após o TTL do cache, então usa a nova credencial sem restart.
- CA-TRV-10.2 — Dado um 401 da dependência, então o `CredencialProvider` relê o segredo e obtém novo token uma única vez antes de classificar a falha.
- CA-TRV-10.3 — `oc get secret` no namespace não lista segredos da aplicação (nenhuma sincronização).

### 3.11 SPEC-TRV-11 — Resiliência por dependência (Resilience4j)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-09 · ADR-12 · 04 §9.1 · PRM-TEC-11 |

**Valores iniciais** (revisar após testes de carga e primeiras semanas de Hom; valores do 04 §9.1 mantidos e completados)

| Dependência | Timeout conexão / leitura | Retry imediato | Circuit breaker | Bulkhead (concorrência) | Retentativa agendada (após esgotar) |
|---|---|---|---|---|---|
| FIRP (consulta) | 2 s / 5 s | 3 tentativas; backoff 0,5 s → 2 s com jitter; só timeout, 5xx e 429 | Janela 20 chamadas; 50% falha ou 50% lentas (> 4 s); aberto 60 s; 3 chamadas em meio-aberto | 10 | 1, 5, 15, 30, 60 min até 2 h → `GeracaoDoTermoFalhou(FIRP)` |
| IMPD `impd-srv-doc-generator` | 2 s / 15 s | 2 tentativas; backoff 1 s | Idem (lenta > 12 s) | 5 | Idem → `GeracaoDoTermoFalhou(DOCUMENTO)` |
| Renderizador próprio (Plano B) | — / 20 s (tempo de CPU) | Não (determinístico) | Não | 2 (memória) | Idem |
| GACD passo 1 Coordenar Contrato | 2 s / 10 s | **Só** erro de conexão antes do envio; timeout de leitura → `RESULTADO_INCERTO` | Por API; janela 20, 50%, aberto 60 s | 5 | Reconciliação (seção 9.4) |
| GACD passo 2 Armazenar Prévia | 2 s / 30 s | 3 tentativas; backoff 1 s → 4 s com jitter | Idem | 3 (payload) | 1, 5, 15, 30, 60 min até 2 h → compensação |
| GACD passo 3 Coordenar Regra | 2 s / 10 s | 3 tentativas; backoff 1 s → 4 s | Idem | 5 | Idem |
| GACD consulta / cancelamento (se existirem) | 2 s / 10 s | 3 tentativas | Idem | 3 | Reconciliação manual |
| Emissor de token (LEAP **[HIPÓTESE]**) | 2 s / 5 s | 3 tentativas; backoff 0,5 s | Aberto 30 s | 5 | — (falha da chamada de negócio) |
| Blob Storage (SDK) | 10 s por tentativa | Política do SDK: 3 tentativas exponenciais | — | 10 | Tarefa reagendada |
| Salesforce REST (upsert) | 2 s / 20 s | Não imediato; retentativa por entrega | Aberto 120 s em 5xx/timeout; 429 respeita `Retry-After` | 4 | Backoff exponencial 1 s → 15 min, até 24 h → `ESTACIONADA` |
| Salesforce token (JWT Bearer) | 2 s / 10 s | 3 tentativas | Compartilhado com o REST | 2 | — |
| PostgreSQL (Hikari) | `connectionTimeout` 3 s; `statement_timeout` 5 s (API) / 30 s (jobs); `lock_timeout` 2 s; `idle_in_transaction_session_timeout` 60 s | — | — | Pool: COMP-01 10, COMP-02 5, COMP-03 5 por réplica | — |

**Regras**

- Timeouts ficam no cliente HTTP (conexão e leitura), não em `TimeLimiter` (evita thread órfã com virtual threads).
- Retry só para falhas `TRANSITORIA` (SPEC-TRV-04); nunca para 4xx de negócio, exceto 408/429.
- Circuito aberto em dependência de etapa assíncrona **reagenda** a tarefa; não gera falha imediata de negócio.
- Todas as instâncias expõem métricas `resilience4j_*` com a tag `dependencia`.

Exemplo de configuração (COMP-01):

```yaml
resilience4j:
  circuitbreaker:
    configs:
      padrao: { slidingWindowSize: 20, failureRateThreshold: 50, slowCallRateThreshold: 50,
                waitDurationInOpenState: 60s, permittedNumberOfCallsInHalfOpenState: 3 }
    instances:
      firp: { baseConfig: padrao, slowCallDurationThreshold: 4s }
      impd: { baseConfig: padrao, slowCallDurationThreshold: 12s }
      gacd-coordenar-contrato: { baseConfig: padrao }
      gacd-armazenar-previa: { baseConfig: padrao, slowCallDurationThreshold: 25s }
      gacd-coordenar-regra: { baseConfig: padrao }
  retry:
    instances:
      firp: { maxAttempts: 3, waitDuration: 500ms, enableExponentialBackoff: true,
              exponentialMaxWaitDuration: 2s, enableRandomizedWait: true,
              retryExceptions: [br.com.bradesco.atacado.adesao.plataforma.http.FalhaTransitoria] }
  bulkhead:
    instances:
      firp: { maxConcurrentCalls: 10, maxWaitDuration: 0 }
```

**Critérios de aceite**

- CA-TRV-11.1 — Dado o WireMock da FIRP respondendo 503 duas vezes e 200 na terceira, então a consulta tem sucesso e a métrica de retry registra 2 tentativas.
- CA-TRV-11.2 — Dado o passo 1 do GACD com atraso de 11 s, então não há segunda chamada e a saga fica em `RESULTADO_INCERTO`.
- CA-TRV-11.3 — Dado o circuito da FIRP aberto, então as tarefas `IDENTIFICAR_ASSINANTES` são reagendadas e a API Adesão continua respondendo dentro do RNF-07.
- CA-TRV-11.4 — Dado o Salesforce respondendo 429 com `Retry-After: 30`, então a próxima tentativa da entrega ocorre após ≥ 30 s.

### 3.12 SPEC-TRV-12 — Telemetria (OpenTelemetry e Micrometer)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PARCIAL (QA-TEC-16) |
| Rastreio | RNF-11 · ADR-12 · PRM-TEC-12 · [DT-15] |

- Agente Java do OpenTelemetry na imagem (ou injetado pelo operador OTel da plataforma, se for o padrão — QA-TEC-16). Exportação OTLP para o coletor corporativo (N-11).
- Atributos de recurso: `service.name` (nome do deployable), `service.version`, `deployment.environment` (`dev`/`hom`/`prd`), `k8s.namespace.name`, `k8s.pod.name`.
- Amostragem `parentbased_always_on` (100%) [DT-15].
- Spans manuais: `adesao.tarefa {tipo}`, `adesao.saga.passo {passo}`, `adesao.inbox.processar {origem,tipoSinal}`, `acompanhamento.relay.lote`, `acompanhamento.entrega {tipoObjeto}`; atributos sem dado pessoal (`adesao.id`, `adesao.etapa`, `adesao.tentativa`).
- Métricas: Micrometer com registro Prometheus em `/actuator/prometheus` (porta 8081), coletadas pelo monitoramento de workloads de usuário do OpenShift via `ServiceMonitor`. Catálogo na SPEC-OBS-01.

**Critérios de aceite**

- CA-TRV-12.1 — Dado o fluxo Solicitado → Aguardando assinatura em Hom, então existe um trace por etapa (requisição, tarefas, passos da saga) ligado por links ao trace de origem.
- CA-TRV-12.2 — `/actuator/prometheus` não é acessível pela Route externa (só porta 8081).

### 3.13 SPEC-TRV-13 — Health, probes e desligamento gracioso

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-08, RNF-16 · [DT-10] |

| Item | COMP-01 | COMP-02 | COMP-03 |
|---|---|---|---|
| Porta negócio / Actuator / admin | 8080 / 8081 / 8082 | 8080 / 8081 / — | — / 8081 / 8082 |
| `startupProbe` | `/actuator/health/liveness`, período 5 s, até 24 falhas (2 min) | Idem, até 12 falhas | Idem |
| `livenessProbe` | `/actuator/health/liveness` (só estado interno; **sem** dependências), período 10 s, 3 falhas | Idem | Idem |
| `readinessProbe` | `/actuator/health/readiness` = estado + `db`; **não** inclui FIRP, GACD, IMPD, Blob | Estado + `db` | Estado + `db` |
| Desligamento | `server.shutdown=graceful`; `spring.lifecycle.timeout-per-shutdown-phase=25s`; `preStop` com `sleep 10`; `terminationGracePeriodSeconds: 45` | Idem | Idem; libera o lock ShedLock ao parar |
| Jobs no desligamento | Param de buscar novas tarefas; concluem ou devolvem a atual (lease expira) | — | Terminam o lote corrente |

**Critérios de aceite**

- CA-TRV-13.1 — Dado o GACD indisponível, então os pods do COMP-01 permanecem `Ready` (dependência externa não afeta readiness).
- CA-TRV-13.2 — Dado o PostgreSQL indisponível, então o COMP-02 sai de `Ready` em até 30 s e volta sozinho quando o banco retorna.
- CA-TRV-13.3 — Dado um rollout durante carga de callbacks, então nenhuma requisição recebe erro de conexão (0 respostas 502/503 geradas pelo router).

### 3.14 SPEC-TRV-14 — Feature flags

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-16 · ADR-02, ADR-03, ADR-08, ADR-11 · PRM-TEC-14 · [DT-09] |

| Flag | Serviço | Default | Dev / Hom / Prod iniciais | Efeito | Critério de remoção |
|---|---|---|---|---|---|
| `adesao.confirmacao-gerente.habilitada` | COMP-01 | `true` | true / true / true | Exige `POST …/confirmacao-envio` no estado Gerado antes da saga; se `false`, a saga inicia ao gerar o documento | Resposta de QA-NEG-18 |
| `termo.renderizador` | COMP-01 | `impd` | `proprio` / conforme gate / conforme gate | Seleciona o adaptador da porta `RenderizadorDocumento` (`impd` \| `proprio`) | Decisão final do gate G1–G5 (ADR-03) |
| `convenio.gatilho.habilitado` | COMP-01 | `false` | false / false / false | Ativa a porta `SolicitacaoConvenioPort` (abre a pendência de implantação por produto; não cria o convênio — SPEC-CNV-01) | QA-TEC-11 / QA-CON-02 / QA-CON-24 |
| `adesao.gacd.confirmacao-ativa.habilitada` | COMP-01 | `false` | — | Consulta o protocolo no GACD antes de aplicar `AssinaturaConcluida` (ADR-08) | Existência de API de consulta (QA-TEC-06) |
| `adesao.gacd.cancelamento-protocolo.habilitado` | COMP-01 | `false` | — | Cancela o protocolo no GACD na reemissão, no cancelamento e na compensação | Existência de API de cancelamento (QA-TEC-06) |
| `adesao.gacd.reconciliacao-diaria.habilitada` | COMP-01 | `false` | — | Job diário de consulta dos protocolos em Aguardando assinatura (ADR-08 c) | Idem |
| `adesao.pendencia.alerta-dias` | COMP-01 | `0` (desligado) | 0 / 7 / a definir | Emite `PendenciaAssinaturaProlongada` após N dias em Aguardando assinatura [DT-17] | QA-NEG-11 |
| `adesao.inbox.payload-bruto.armazenar` | COMP-02 | `false` | true / false / false | Guarda o payload bruto do callback em `sinal_externo.payload_bruto` | QA-TEC-17 |
| `acompanhamento.entrega.resumo-assinantes.habilitado` | COMP-03 | `false` | — | Envia nome e papel dos assinantes ao Salesforce | QA-TEC-15 |

**Regras**

- Flags são propriedades tipadas (`@ConfigurationProperties`) em ConfigMap versionado; mudança por commit + rollout (auditada no Git). Mudança em Prod segue o processo de mudança da plataforma (QA-TEC-27).
- Cada flag tem dono, default seguro, critério de remoção e registro em `docs/flags.md`.
- Toda flag é coberta por testes nos dois estados.
- O valor efetivo das flags é exposto em `/actuator/info` (porta 8081) e registrado em log `INFO` na inicialização.

**Critérios de aceite**

- CA-TRV-14.1 — Dado `adesao.confirmacao-gerente.habilitada=false`, quando o documento é gerado, então a tarefa `EXECUTAR_SAGA` é criada na mesma transação de `TermoGerado`.
- CA-TRV-14.2 — Dado `termo.renderizador=proprio`, então nenhuma chamada ao IMPD ocorre e `documento_termo.renderizador = 'PROPRIO'`.
- CA-TRV-14.3 — A suíte de testes executa os cenários de cada flag com os dois valores.

### 3.15 SPEC-TRV-15 — Cliente HTTP de saída padronizado

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-03 · CONSTRUIR · PARCIAL (QA-TEC-03) |
| Rastreio | RNF-01, RNF-09, RNF-10 · ADR-10, ADR-12 |

Fábrica única em `adesao-plataforma` que produz `RestClient` por dependência com:

1. Timeouts de conexão e leitura por dependência (SPEC-TRV-11).
2. Interceptor de credencial (`CredencialProvider`) — `Authorization: Bearer` do token de workload; cabeçalhos/credencial do usuário sistêmico só no cliente do passo 2 do GACD (formato em QA-TEC-04).
3. Propagação de `X-Correlation-ID` e W3C Trace Context.
4. Métricas `http_client_requests_seconds` com tag `dependencia` e rota template.
5. Log de chamada sem corpo (método, rota template, status, duração).
6. Classificação da resposta em `Sucesso` / `FalhaIntegracao{TRANSITORIA|PERMANENTE|INCERTA}`: conexão recusada → TRANSITORIA; timeout de leitura → INCERTA para chamadas não idempotentes e TRANSITORIA para idempotentes; 5xx/429/408 → TRANSITORIA; demais 4xx → PERMANENTE.
7. TLS 1.2+ com validação de cadeia pela truststore corporativa (montada como arquivo, ConfigMap não sensível).

**Critérios de aceite**

- CA-TRV-15.1 — Dado qualquer cliente criado pela fábrica, então timeouts, correlação e métricas estão presentes (teste de configuração).
- CA-TRV-15.2 — Dado um timeout de leitura no passo 1 do GACD, então o resultado é `FalhaIntegracao{INCERTA}`.

### 3.16 Definition of Done técnico comum (vale para toda task derivada)

| # | Critério |
|---|---|
| DoD-01 | Código revisado por par; build `./mvnw verify` verde; Spotless, Checkstyle e ArchUnit/Modulith sem violações |
| DoD-02 | Testes unitários do domínio e da lógica alterada; cobertura de linhas ≥ 80% nos pacotes `dominio` e `aplicacao` alterados |
| DoD-03 | Teste de integração (Testcontainers/WireMock) quando a task toca banco, fila ou dependência externa |
| DoD-04 | CA da SPEC citados na task comprovados por teste automatizado ou evidência anexada |
| DoD-05 | Nenhum dado pessoal em log, evento, métrica ou erro (SPEC-TRV-08, SPEC-SEG-03) |
| DoD-06 | Métricas, logs e spans da funcionalidade presentes (SPEC-OBS-01) |
| DoD-07 | Contratos (OpenAPI/JSON Schema) atualizados quando a interface muda, com versão ajustada (SPEC-TRV-05) |
| DoD-08 | Migração Flyway compatível com a versão anterior da aplicação (expand/contract, SPEC-DB-03) |
| DoD-09 | Flags novas registradas em `docs/flags.md`; runbook atualizado se houver nova operação administrativa |
| DoD-10 | SAST e SCA sem achado crítico ou alto novo (SPEC-SEG-06) |

---
## 4. Especificação por componente

Formato de cada SPEC: tabela de cabeçalho (componente, classe, prontidão, rastreio, dependências, bloqueios), regras, interfaces, estados/erros, configuração e **critérios de aceite** (Dado/Quando/Então quando fizer sentido). Contratos detalhados na seção 5, DDL na seção 6, estados na seção 7, eventos na seção 8 e saga na seção 9.

### 4.1 COMP-01 — `atacado-adesao-termo`

| Campo | Conteúdo |
|---|---|
| Deployable | Spring Boot 3, monólito modular (pacotes 01.1..01.6) [DT-02] |
| BC | BC-01 (núcleo) + BC-02 (módulo `termodocumento`) |
| RF | RF-01..RF-08 (regra), RF-10..RF-14 |
| RNF | RNF-01, 02, 04, 05, 07, 09..16 |
| ADR | ADR-01, 02, 03, 04, 05, 08, 10, 11, 12 |
| Entradas | API Adesão v1 (8080); admin (8082); jobs internos (tarefas, saga, inbox, SLA, reconciliação) |
| Saídas | FIRP e GACD (Axway interno), IMPD, Blob, PostgreSQL |
| Dono das migrações | Sim (Flyway, Job pré-deploy) |

#### 4.1.1 COMP-01.1 — módulo `adesao-termo`

##### SPEC-TER-01 — Modelo de domínio `AdesaoTermo` e invariantes

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PRONTA |
| Rastreio | RF-01, 02, 05, 07, 08, 10 · INV-01..INV-10 · RN-01, 03, 05, 08, 16 · 03 §3.2, §6 · [DT-16] |
| Depende de | SPEC-TRV-02, SPEC-TRV-03 |

**Regras**

- Agregado `AdesaoTermo` com os atributos do 03 §3.2 (inclui `produtos[]`, `assinantes[]` da tentativa corrente, `documento`, `protocolo` vigente, `historicoProtocolos[]`, `status`, `motivoFalha`, `motivoEncerramento`, `solicitadoPor`, `tentativa`, `versao`) e o atributo técnico `envioConfirmadoEm/Por`.
- VOs: `IdAdesao`, `IdProposta`, `Cnpj` [DT-19], `TipoTermo` (`PRODUTOS` \| `PRODUTOS_CANAL`), `ProdutoAderido`, `Assinante`, `DocumentoTermo`, `ProtocoloAssinatura`, `MotivoFalha{etapa, codigo, reprocessavel}`, `MotivoEncerramento` (`RECUSADO` \| `EXPIRADO` \| `CANCELADO`), `Matricula`.
- Cada método de comportamento (`registrarAssinantes`, `registrarDocumento`, `confirmarEnvio`, `registrarEnvioParaAssinatura`, `concluirAssinatura`, `invalidarAssinantes`, `registrarFalha`, `reemitir`, `encerrar`) valida a transição pela tabela da seção 7.2, incrementa `versao` e devolve a lista de **eventos de domínio** gerados (não publica).
- Transição ilegal lança `TransicaoInvalida(estadoAtual, comando)` → `409 ESTADO_INCOMPATIVEL`.
- `tipoTermo` é imutável a partir de Gerado (INV-04); `produtos[]` não vazio (INV-03); `assinantes[]` não vazio antes de Gerado (INV-05); `codigoProtocolo` obrigatório em Aguardando assinatura (INV-06); Assinado e Encerrado imutáveis (INV-09).
- `PoliticaElegibilidade` e `PoliticaTipoTermo` são serviços de domínio puros (SPEC-ELG-01).

**Critérios de aceite**

- CA-TER-01.1 — Para cada linha da tabela de transições (seção 7.2), um teste unitário comprova estado final, incremento de versão e eventos gerados.
- CA-TER-01.2 — Para cada par (estado, comando) marcado como "não permitido" na matriz da seção 7.3, um teste comprova `TransicaoInvalida`.
- CA-TER-01.3 — Dado um agregado em Assinado, quando qualquer método de comportamento é chamado, então lança `TransicaoInvalida` e a versão não muda.
- CA-TER-01.4 — O pacote `dominio` não depende de Spring (CA-TRV-03.2).

##### SPEC-TER-02 — Persistência do agregado e unicidade por CNPJ

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PRONTA |
| Rastreio | INV-01, INV-10 · RN-16 · PRM-DDD-03 · [DT-04] · tabelas `adesao_termo`, `produto_aderido`, `assinante`, `protocolo_assinatura`, `documento_termo` (seção 6) |
| Depende de | SPEC-TER-01, SPEC-DB-03 |
| Bloqueios | QA-NEG-16 / QA-DDD-01 (unidade CNPJ × raiz): a regra atual usa CNPJ completo |

**Regras**

- `RepositorioAdesaoTermo` (Spring Data JDBC) salva o agregado e as entidades filhas numa única transação, com **lock otimista** por `versao` (`UPDATE … WHERE versao = :versaoAnterior`).
- INV-01 garantida pelo índice único parcial `ux_adesao_cnpj_nao_terminal` (estados não terminais). Violação (`SQLState 23505` nesse índice) é traduzida em `AdesaoNaoTerminalExistente(idExistente)`.
- `OptimisticLockingFailureException` em comando do Salesforce → `409 VERSAO_DESATUALIZADA` quando houver `If-Match`; em processamento assíncrono → nova tentativa da tarefa/sinal (sem erro ao cliente).
- Assinantes e documento são gravados por `tentativa`; o histórico de tentativas anteriores é preservado.

**Critérios de aceite**

- CA-TER-02.1 — Dado um CNPJ com adesão em Gerado, quando outra solicitação para o mesmo CNPJ chega, então `409 ADESAO_NAO_TERMINAL_EXISTENTE` com `idAdesaoExistente`.
- CA-TER-02.2 — Dado um CNPJ cuja adesão anterior está em Assinado ou Encerrado, quando nova solicitação chega, então é aceita (a regra de "termo já assinado dispensa novo termo" depende de QA-CON-22 e está fora desta SPEC).
- CA-TER-02.3 — Dadas duas transações concorrentes alterando a mesma adesão, então uma falha por versão e nenhuma atualização é perdida (teste com Testcontainers).

##### SPEC-TER-03 — Solicitar adesão (`POST /v1/adesoes`)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-TEC-30: campos do snapshot para as variáveis do modelo) |
| Rastreio | RF-01, RF-02 · RNF-05, RNF-07 · RFN-01, RFN-02, RFN-03 · RN-02, RN-03, RN-04, RN-16 · INV-01..INV-03 · CAP-02.1..02.3, CAP-10.1 · ADR-02 |
| Depende de | SPEC-TER-01, 02, 08, 10, 11; SPEC-TRV-04, 06; SPEC-ELG-01; SPEC-API-01 |

**Fluxo**

1. Valida esquema (contrato na seção 5.2) e CNPJ.
2. Aplica idempotência (SPEC-TRV-06).
3. `ElegibilidadePort` → `PoliticaElegibilidade`:
   - **dispensada** (contrato vigente): grava `decisao_elegibilidade` (resultado `DISPENSADA`), outbox `AdesaoDispensada`, auditoria; responde **200** `{resultado: ADESAO_DISPENSADA, idDecisao}`. Nenhum `AdesaoTermo` é criado.
   - **requerida**: `PoliticaTipoTermo` define `tipoTermo`; cria `AdesaoTermo` em **Solicitado** (tentativa 1, versão 1) com `produtos[]`; grava `decisao_elegibilidade` (`REQUERIDA`), outbox `TermoSolicitado`, tarefa `IDENTIFICAR_ASSINANTES`, auditoria `SOLICITAR_TERMO`; responde **202** com `idAdesao`, `Location` e `ETag: "1"`.
4. Tudo na **mesma transação** (INV-10).

**Erros**: `400 REQUISICAO_INVALIDA` / `CNPJ_INVALIDO` / `IDEMPOTENCY_KEY_AUSENTE`; `409 ADESAO_NAO_TERMINAL_EXISTENTE`; `422 IDEMPOTENCY_KEY_REUTILIZADA`; `503 SERVICO_INDISPONIVEL`.

**Critérios de aceite**

- CA-TER-03.1 — Dado um corpo válido com `possuiContratoVigente=false` e `possuiAcessoCanalDigital=true`, quando `POST /v1/adesoes`, então 202, `tipoTermo=PRODUTOS`, estado Solicitado, 1 evento `TermoSolicitado` e 1 tarefa `IDENTIFICAR_ASSINANTES` gravados na mesma transação.
- CA-TER-03.2 — Dado `possuiAcessoCanalDigital=false`, então `tipoTermo=PRODUTOS_CANAL`.
- CA-TER-03.3 — Dado `possuiContratoVigente=true`, então 200 com `resultado=ADESAO_DISPENSADA`, nenhuma linha em `adesao_termo` e 1 evento `AdesaoDispensada`.
- CA-TER-03.4 — Dado `produtos` vazio, então `400 REQUISICAO_INVALIDA` com `erros[0].campo = "produtos"`.
- CA-TER-03.5 — Dado falha simulada ao gravar a outbox, então nenhuma linha de adesão, tarefa ou auditoria persiste (atomicidade).
- CA-TER-03.6 — p95 ≤ 1 s em Hom com a carga nominal (RNF-07; medido pela SPEC-TST-05).
- CA-TER-03.7 — A auditoria registra a origem da elegibilidade (`SALESFORCE`) e os indicadores recebidos (PRM-TEC-10).

##### SPEC-TER-04 — Consultas e prévia do documento

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 (+ COMP-01.4) · CONSTRUIR · PRONTA |
| Rastreio | RF-05, RF-11 · RFN-04, RFN-11 · CAP-03.2 · 04 §11.1 |
| Depende de | SPEC-TER-02, SPEC-DOC-05, SPEC-API-01 |
| Bloqueios | O **termo assinado** (QA-TEC-18) não faz parte desta SPEC |

**Endpoints**

| Operação | Regra |
|---|---|
| `GET /v1/adesoes/{idAdesao}` | Estado, tipo, tentativa, versão (`ETag`), confirmação, assinantes da tentativa corrente (id FIRP, nome, papel), documento (versão do modelo, hash, tamanho, data), protocolo (`codigoProtocolo`, data de abertura), falha (etapa, código, reprocessável), encerramento. **Não** expõe `IdPrevia`/`CaminhoPrevia` (modelo interno do GACD, isolado pela ACL) |
| `GET /v1/adesoes?idProposta={id}` | **[PROPOSTA]** Lista resumida das adesões da Proposta (mais recente primeiro), para o Salesforce recuperar o `idAdesao` em caso de perda da resposta |
| `GET /v1/adesoes/{idAdesao}/documento` | Lê o PDF do staging, **confere o SHA-256** com `documento_termo.hash_sha256` e devolve `application/pdf` com `ETag` = hash, `Cache-Control: no-store`, `Content-Disposition: inline; filename="termo-{idAdesao}-t{tentativa}.pdf"`. Hash divergente → `500 ERRO_INTERNO` + alerta de segurança (tampering, 04 §8.4) |

**Erros**: `404 ADESAO_NAO_ENCONTRADA`; `404 DOCUMENTO_INDISPONIVEL` (antes de Gerado); `410 DOCUMENTO_EXPIRADO` (removido após estado terminal ou lifecycle).

**Critérios de aceite**

- CA-TER-04.1 — Dado uma adesão em Gerado, quando `GET …/documento`, então o corpo é o PDF cujo SHA-256 é igual ao registrado e o cabeçalho `ETag` contém esse hash.
- CA-TER-04.2 — Dado o blob alterado externamente (teste com Azurite), então a resposta é 500, o evento de segurança é logado e a métrica `adesao_documento_integridade_falha_total` incrementa.
- CA-TER-04.3 — Dado uma adesão em Assinado com staging removido, então `410 DOCUMENTO_EXPIRADO`.
- CA-TER-04.4 — A resposta de `GET /v1/adesoes/{id}` não contém `IdPrevia`, `CaminhoPrevia` nem CPF.

##### SPEC-TER-05 — Confirmação de envio pelo Gerente

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PRONTA |
| Rastreio | RF-05 · RFN-04 · QA-NEG-18 · DEC-CON-07 · ADR-02 · PRM-TEC-14 · T-06 |
| Depende de | SPEC-TER-02, SPEC-TRV-06, SPEC-TRV-14, SPEC-GAC-02 |

**Regras**

- `POST /v1/adesoes/{id}/confirmacao-envio` com `Idempotency-Key`, `If-Match` (versão) recomendado e corpo `{matriculaGerente, hashDocumento}`.
- Guardas: flag `adesao.confirmacao-gerente.habilitada=true`; estado Gerado; `hashDocumento` igual ao documento atual (garante que o Gerente confirmou **o mesmo** PDF, 04 §8.4); ainda não confirmado.
- Efeitos (mesma transação): `envioConfirmadoEm/Por`; criação da saga (`saga_envio_assinatura`, etapa `COORDENAR_CONTRATO`, estado `PENDENTE`); tarefa `EXECUTAR_SAGA`; auditoria `CONFIRMAR_ENVIO` com matrícula, versão do modelo e hash. `AssinantesConfirmados` é evento **interno**: fica só na auditoria (seção 8.1).
- Resposta **202** com o estado atual (Gerado, `envioConfirmado=true`).
- Repetição após confirmação com a mesma chave → replay; com chave nova → `409 ESTADO_INCOMPATIVEL` (já confirmado).

**Critérios de aceite**

- CA-TER-05.1 — Dado Gerado e hash correto, quando confirma, então 202, saga criada em `COORDENAR_CONTRATO/PENDENTE` e tarefa `EXECUTAR_SAGA` na mesma transação.
- CA-TER-05.2 — Dado hash diferente, então `409 DOCUMENTO_DIVERGENTE` e nenhuma saga criada.
- CA-TER-05.3 — Dado a flag desligada, então `409 CONFIRMACAO_DESABILITADA`.
- CA-TER-05.4 — Dado estado Assinantes identificados (documento ainda não gerado), então `409 ESTADO_INCOMPATIVEL`.

##### SPEC-TER-06 — Reemissão do termo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (cancelar protocolo anterior depende de QA-TEC-06 / QA-DDD-02) |
| Rastreio | RF-10 · RN-07 · QA-NEG-12 · 03 comando `ReemitirTermo` · T-13, T-14 |
| Depende de | SPEC-TER-02, 08, 10, 11; SPEC-GAC-03 |

**Regras**

- `POST /v1/adesoes/{id}/reemissao` com `Idempotency-Key`, `If-Match` recomendado e `{matriculaGerente, motivo}` (`motivo` ∈ `REGULARIZACAO_ASSINANTES`, `FALHA_TECNICA`, `OUTRO`).
- Guardas: estado Assinantes inválidos ou Falha na geração.
- Efeitos: `tentativa += 1`; volta a **Solicitado**; limpa falha e confirmação; protocolo vigente (se houver) → `SUBSTITUIDO`; se `adesao.gacd.cancelamento-protocolo.habilitado`, cria tarefa `CANCELAR_PROTOCOLO`; senão abre `reconciliacao_manual` com motivo `CANCELAMENTO_PENDENTE` (o protocolo antigo continua aberto no GACD, RSK-04); outbox `ReemissaoSolicitada`; tarefa `IDENTIFICAR_ASSINANTES`; tarefa `EXCLUIR_STAGING` do documento da tentativa anterior; auditoria.
- Sinais posteriores referentes ao protocolo substituído são ignorados (INV-07, SPEC-TER-09).

**Critérios de aceite**

- CA-TER-06.1 — Dado Assinantes inválidos com protocolo P1, quando reemite, então estado Solicitado, `tentativa=2`, P1 `SUBSTITUIDO`, evento `ReemissaoSolicitada` com `protocoloAnterior=P1`.
- CA-TER-06.2 — Dado a flag de cancelamento desligada, então uma linha `reconciliacao_manual(CANCELAMENTO_PENDENTE, P1)` é aberta e a métrica `adesao_reconciliacao_abertos` incrementa.
- CA-TER-06.3 — Dado Aguardando assinatura, então `409 ESTADO_INCOMPATIVEL`.
- CA-TER-06.4 — Dado callback de P1 recebido depois da reemissão, então o sinal fica `IGNORADO` com motivo `PROTOCOLO_NAO_VIGENTE`.

##### SPEC-TER-07 — Cancelamento do termo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-TEC-06, QA-NEG-12) |
| Rastreio | RF-10 · EVN-12 · QA-NEG-12 · 03 `EncerrarTermo` · [DT-16] · T-12, T-15, T-16, T-17 |
| Depende de | SPEC-TER-02, 08, 10, 11; SPEC-GAC-03 |

**Regras**

- `POST /v1/adesoes/{id}/cancelamento` com `Idempotency-Key`, `If-Match` recomendado e `{matriculaGerente, motivo}` (`PROPOSTA_ALTERADA`, `DESISTENCIA_CLIENTE`, `ERRO_OPERACIONAL`, `OUTRO`).
- Estados permitidos: Aguardando assinatura, Assinantes inválidos, Falha na geração e **Gerado sem saga iniciada** [DT-16]. Em Solicitado, Assinantes identificados ou Gerado com saga em andamento → `409 ESTADO_INCOMPATIVEL` (o Gerente aguarda o fim da etapa em curso).
- Efeitos: **Encerrado** com `motivoEncerramento=CANCELADO`; protocolo vigente → `CANCELADO` (com tarefa `CANCELAR_PROTOCOLO` se a flag estiver ligada; senão `reconciliacao_manual(CANCELAMENTO_PENDENTE)`); outbox `TermoEncerrado`; tarefa `EXCLUIR_STAGING`; tarefas pendentes da adesão → `CANCELADA`; auditoria.
- Encerramento por recusa/expiração vem do GACD pela inbox (SPEC-TER-09), não por esta API.

**Critérios de aceite**

- CA-TER-07.1 — Dado Aguardando assinatura, quando cancela, então Encerrado/CANCELADO, evento `TermoEncerrado{motivo: CANCELADO}` e tratamento do protocolo conforme a flag.
- CA-TER-07.2 — Dado Gerado com saga em `COORDENAR_CONTRATO/EM_EXECUCAO`, então `409 ESTADO_INCOMPATIVEL`.
- CA-TER-07.3 — Dado Gerado sem saga, então Encerrado e nenhum contato com o GACD.
- CA-TER-07.4 — Dado Encerrado, quando cancela de novo com chave nova, então `409 ESTADO_INCOMPATIVEL`.

##### SPEC-TER-08 — Fila de tarefas e orquestração assíncrona

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PRONTA |
| Rastreio | RF-03, RF-04, RF-06, RF-14 · RNF-05, RNF-07, RNF-09 · ADR-02 · [DT-05] · tabela `tarefa` |
| Depende de | SPEC-TER-02, SPEC-TRV-11, SPEC-DB-03 |

**Regras**

- Tipos: `IDENTIFICAR_ASSINANTES`, `GERAR_DOCUMENTO`, `EXECUTAR_SAGA`, `CANCELAR_PROTOCOLO`, `EXCLUIR_STAGING`. No máximo **uma tarefa pendente por (adesão, tipo)** (índice único parcial).
- Toda tarefa nasce **na mesma transação** da transição que a exige.
- Execução por *lease* (não segura lock durante a chamada externa):
  1. `UPDATE tarefa SET bloqueado_ate = now() + interval '2 minutes', executor = :pod WHERE id IN (SELECT id FROM tarefa WHERE situacao='PENDENTE' AND proxima_execucao_em <= now() AND (bloqueado_ate IS NULL OR bloqueado_ate < now()) ORDER BY proxima_execucao_em LIMIT :n FOR UPDATE SKIP LOCKED) RETURNING *`;
  2. executa a chamada externa fora de transação;
  3. aplica o resultado em nova transação (transição do agregado + eventos + próxima tarefa + auditoria) conferindo `versao_agregado_origem` e o estado esperado; se o agregado mudou (ex.: cancelado), a tarefa é marcada `CANCELADA`.
- Falha `TRANSITORIA` → `tentativas += 1`, `proxima_execucao_em` pelo calendário 1, 5, 15, 30, 60 min; ao passar de `prazo_limite_em` (criação + 2 h) → transição para **Falha na geração** com a etapa correspondente (`FIRP`, `DOCUMENTO`) e `reprocessavel=true`.
- Falha `PERMANENTE` → Falha na geração imediata, `reprocessavel` conforme o código.
- Polling a cada `adesao.tarefas.intervalo-polling` (2 s) em todas as réplicas (SKIP LOCKED dispensa líder).

| Tarefa | Pré-condição de estado | Executa | Sucesso | Falha final |
|---|---|---|---|---|
| `IDENTIFICAR_ASSINANTES` | Solicitado | `ConsultaAssinantesPort` (SPEC-FIR) | T-02 Assinantes identificados + tarefa `GERAR_DOCUMENTO` | T-03 Falha (FIRP ou SEM_ASSINANTES) |
| `GERAR_DOCUMENTO` | Assinantes identificados | `GeradorDocumentoPort` (SPEC-DOC) | T-04 Gerado (+ `EXECUTAR_SAGA` se a confirmação estiver desligada) | T-05 Falha (DOCUMENTO) |
| `EXECUTAR_SAGA` | Gerado confirmado | Próximo passo da saga (seção 9) | T-07 Aguardando assinatura | T-08 Falha (GACD) |
| `CANCELAR_PROTOCOLO` | Qualquer | Cancelamento no GACD (se API) | Protocolo `CANCELADO` no GACD, reconciliação não aberta | `reconciliacao_manual(CANCELAMENTO_PENDENTE)` |
| `EXCLUIR_STAGING` | Qualquer | Exclusão do blob | `removido_staging_em` preenchido | Log WARN; o lifecycle de 30 dias remove |

**Critérios de aceite**

- CA-TER-08.1 — Dado 3 réplicas e 100 tarefas pendentes, então cada tarefa é executada exatamente uma vez com sucesso (teste de concorrência com Testcontainers).
- CA-TER-08.2 — Dado o pod morto no meio da execução, então após o *lease* (2 min) outra réplica reexecuta a tarefa.
- CA-TER-08.3 — Dado FIRP indisponível por mais de 2 h (relógio simulado), então a adesão vai para Falha na geração com `etapa=FIRP`, `reprocessavel=true` e evento `GeracaoDoTermoFalhou`.
- CA-TER-08.4 — Dado cancelamento enquanto `GERAR_DOCUMENTO` executa, então o resultado da renderização é descartado, a tarefa fica `CANCELADA` e o estado continua Encerrado.
- CA-TER-08.5 — Solicitado → Gerado p95 ≤ 60 s em Hom, com dependências dentro do SLA (RNF-07).

##### SPEC-TER-09 — Processamento da inbox (sinais externos)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-TEC-07: tipos de sinal do GACD; QA-TEC-08: alerta do Canal) |
| Rastreio | RF-07, RF-08, RF-14 · RN-06, RN-07, RN-08 · INV-07, INV-08 · ADR-08, ADR-09 · CAP-05.5, CAP-10.3 · T-09, T-10, T-11 |
| Depende de | SPEC-REC-04, SPEC-TER-02, 10, 11 |

**Regras**

- Busca `sinal_externo` em `RECEBIDO`, ordenado por `recebido_em`, com `FOR UPDATE SKIP LOCKED` em lotes de 20; processamento **inteiramente local** (sem chamada externa), exceto a confirmação ativa (abaixo).
- Resolve a adesão por `codigo_protocolo` em `protocolo_assinatura`. `id_adesao_informado` (caminho da callbackUrl) é só redundância: divergência → `QUARENTENA` (`CORRELACAO_DIVERGENTE`).
- Tradução `tipo_sinal` → comando:

| `tipo_sinal` (canônico) | Origem | Comando | Guarda | Resultado se guarda falha |
|---|---|---|---|---|
| `ASSINATURA_CONCLUIDA` | GACD | `RegistrarConclusaoAssinatura` | Protocolo vigente e estado Aguardando assinatura (INV-07) | `IGNORADO` (`PROTOCOLO_NAO_VIGENTE` ou `ESTADO_INCOMPATIVEL`); duplicado após Assinado → `IGNORADO` (`JA_APLICADO`) |
| `ASSINANTES_INVALIDOS` | CANAL ou GACD (DEC-CON-06 b) | `InvalidarAssinantes` | Protocolo vigente e estado Aguardando assinatura (INV-08) | `IGNORADO` |
| `RECUSADO` / `EXPIRADO` | GACD (se existirem, QA-TEC-07) | `EncerrarTermo` | Protocolo vigente e Aguardando assinatura | `IGNORADO` |
| Desconhecido | Qualquer | — | — | `QUARENTENA` (`TIPO_DESCONHECIDO`) + alerta |
| Protocolo inexistente | Qualquer | — | — | `QUARENTENA` (`PROTOCOLO_DESCONHECIDO`) + alerta (possível forja, RSK-16) |

- Confirmação ativa (flag `adesao.gacd.confirmacao-ativa.habilitada`): antes de aplicar `ASSINATURA_CONCLUIDA`, consulta o protocolo no GACD; se o GACD não confirmar, `QUARENTENA` (`CONFIRMACAO_NEGADA`); se o GACD estiver indisponível, o sinal volta a `RECEBIDO` com `proxima_tentativa_em` (sem aplicar).
- Aplicação (mesma transação): transição do agregado, outbox, auditoria, `sinal_externo.situacao` e `processado_em`. Para Assinado e Encerrado: tarefa `EXCLUIR_STAGING`.
- O alerta do Canal também atualiza a consulta de situação (`APLICADO` \| `REJEITADO` com motivo) exposta pelo COMP-02.
- `OptimisticLockingFailure` → reprocessa o sinal no próximo ciclo (até 5 vezes; depois `QUARENTENA`).

**Critérios de aceite**

- CA-TER-09.1 — Dado Aguardando assinatura com protocolo P e sinal `ASSINATURA_CONCLUIDA(P)`, então Assinado, evento `AssinaturaConcluida` com `cnpj`, `tipoTermo` e `produtos[]`, sinal `PROCESSADO`, auditoria `ASSINATURA_CONCLUIDA` origem GACD — tudo na mesma transação.
- CA-TER-09.2 — Dado o mesmo sinal reenviado com outra chave (ex.: GACD mudou o id de entrega), então o segundo fica `IGNORADO/JA_APLICADO` e não há segundo evento.
- CA-TER-09.3 — Dado sinal para protocolo inexistente, então `QUARENTENA`, métrica `adesao_callback_quarentena_total` incrementa e o estado de nenhuma adesão muda.
- CA-TER-09.4 — Dado alerta do Canal para adesão em Assinado, então `IGNORADO/ESTADO_INCOMPATIVEL` e a consulta do alerta retorna `REJEITADO`.
- CA-TER-09.5 — Idade máxima de sinal em `RECEBIDO` ≤ 120 s em operação normal (alerta da SPEC-OBS-02).

##### SPEC-TER-10 — Outbox transacional (produção de eventos)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PRONTA |
| Rastreio | INV-10 · PRI-05 · RNF-05 · ADR-05 · CAP-10.4 · RF-09, RF-12, RF-13 · [DT-05], [DT-08] |
| Depende de | SPEC-EVT-01, SPEC-DB-03 |

**Regras**

- `PublicadorEventos` grava cada evento **publicado** (seção 8.1) em `outbox_evento` na mesma transação da transição; eventos internos não vão à outbox.
- Campos preenchidos pelo produtor: `id_evento` (UUID v7), `tipo_agregado`, `id_agregado`, `versao_agregado`, `tipo_evento`, `versao_schema`, `payload` (JSON validado contra o schema), `correlation_id`, `chave_correlacao_negocio`, `causation_id`, `traceparent`, `id_proposta`, `situacao='PENDENTE'`.
- Após o commit, o COMP-01 executa `NOTIFY adesao_outbox` (opcional, reduz latência do relay; o relay não depende dele).
- Unicidade `(tipo_agregado, id_agregado, versao_agregado, tipo_evento, versao_schema)` impede duplicidade por reprocessamento.

**Critérios de aceite**

- CA-TER-10.1 — Para cada evento publicado da seção 8, um teste valida o `payload` gravado contra o JSON Schema versionado.
- CA-TER-10.2 — Dado rollback da transação do comando, então nenhum evento persiste.
- CA-TER-10.3 — Nenhum `payload` de evento contém CPF ou nome de assinante (teste automatizado sobre todos os tipos).

##### SPEC-TER-11 — Trilha de auditoria append-only

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-TEC-17: retenção e exportação) |
| Rastreio | RF-13 · RNF-10, RNF-14 · RNFN-01, RNFN-02 · CAP-12.1 · 04 §9.5 · [DT-11] |
| Depende de | SPEC-DB-03, SPEC-DB-04 |

**Regras**

- `RegistroAuditoria` grava em `trilha_auditoria` na mesma transação de cada comando, sinal, transição, operação administrativa e rejeição relevante.
- Catálogo de `acao`: `SOLICITAR_TERMO`, `ADESAO_DISPENSADA`, `ASSINANTES_IDENTIFICADOS`, `DOCUMENTO_GERADO`, `CONFIRMAR_ENVIO`, `PROTOCOLO_ABERTO`, `PREVIA_ARMAZENADA`, `REGRA_COORDENADA`, `ENVIADO_PARA_ASSINATURA`, `FALHA_GERACAO`, `ASSINATURA_CONCLUIDA`, `ASSINANTES_INVALIDADOS`, `TERMO_ENCERRADO`, `REEMITIR`, `CANCELAR`, `SINAL_IGNORADO`, `SINAL_QUARENTENA`, `SAGA_RETOMADA`, `RECONCILIACAO_RESOLVIDA`, `REENTREGA_SOLICITADA`, `FLAG_EFETIVA` (na inicialização).
- `ator`: matrícula do Gerente (comandos do Salesforce), identidade de sistema (`GACD`, `CANAL`, `SISTEMA`) ou do operador (admin). `detalhe` em JSON **sem** dado pessoal além da matrícula (colunas próprias).
- Role da aplicação só com `INSERT` e `SELECT`; trigger bloqueia `UPDATE`/`DELETE` (seção 6).

**Critérios de aceite**

- CA-TER-11.1 — Para o fluxo feliz completo, a trilha contém, em ordem, as ações de solicitação a assinatura, todas com `idAdesao`, `correlationId`; a partir do protocolo, com `codigoProtocolo`; em Gerado e na confirmação, com `versaoModelo` e `hashDocumento` (RNF-10).
- CA-TER-11.2 — `UPDATE` ou `DELETE` em `trilha_auditoria` com a role da aplicação falha por privilégio; com a role de migração, falha pelo trigger.

##### SPEC-TER-12 — API administrativa e reprocessamento

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-TEC-27: modelo de operação) |
| Rastreio | RF-14 · RNF-16 · CAP-10.4 · 04 §9.2 · ADR-12 · [DT-10] |
| Depende de | SPEC-TER-08, 09, 11; SPEC-GAC-02, 03 |

| Endpoint (porta 8082, sem Route) | Efeito |
|---|---|
| `GET /admin/v1/adesoes/{id}` | Visão técnica: estado, tarefas, saga e passos, protocolos, sinais e eventos da adesão |
| `POST /admin/v1/sinais/{id}/reprocessar` | `QUARENTENA`/`IGNORADO` → `RECEBIDO` (com justificativa) |
| `POST /admin/v1/adesoes/{id}/saga/retomar` | Saga `FALHOU`/`AGUARDANDO_RETENTATIVA` → reexecuta a etapa atual (não permitido em `RESULTADO_INCERTO`) |
| `POST /admin/v1/adesoes/{id}/saga/reconciliar` | Decide `RESULTADO_INCERTO`: `{decisao: PROTOCOLO_EXISTE, codigoProtocolo}` ou `{decisao: PROTOCOLO_NAO_EXISTE}` |
| `GET /admin/v1/reconciliacoes?situacao=ABERTO` / `POST /admin/v1/reconciliacoes/{id}/resolver` | Fila de reconciliação manual (RSK-04) |
| `POST /admin/v1/tarefas/{id}/reagendar` | Reagenda tarefa `FALHOU` |

**Regras**: autenticação por token administrativo do Key Vault (`admin-api-token`) **e** cabeçalho `X-Operador` (matrícula), ambos obrigatórios; acesso de rede só por `oc port-forward` controlado por RBAC do OpenShift (grupo de operação) — sem Route; toda chamada gera auditoria (`origem=OPERACAO`) com justificativa obrigatória no corpo.

**Critérios de aceite**

- CA-TER-12.1 — Dado um sinal em `QUARENTENA`, quando reprocessado com justificativa, então volta a `RECEBIDO`, é processado no ciclo seguinte e a auditoria registra operador e justificativa.
- CA-TER-12.2 — Dado requisição sem `X-Operador` ou com token inválido, então 401 e auditoria de tentativa negada.
- CA-TER-12.3 — Não existe Route/Ingress para a porta 8082 (verificação nos manifestos).

##### SPEC-TER-13 — Monitor de pendência de assinatura

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.1 · CONSTRUIR · PARCIAL (QA-NEG-11 prazo; QA-TEC-08 entrega do Canal) |
| Rastreio | RF-09 · RSK-06 · ADR-09 (mitigação) · [DT-17] |
| Depende de | SPEC-TER-10, SPEC-TRV-14 |

**Regras**: job diário (ShedLock, 08:00 America/Sao_Paulo) que, com `adesao.pendencia.alerta-dias = N > 0`, seleciona adesões em Aguardando assinatura há mais de N dias sem alerta emitido para o protocolo vigente e grava outbox `PendenciaAssinaturaProlongada` (um por protocolo). Não muda o estado do Termo.

**Critérios de aceite**

- CA-TER-13.1 — Dado N=7 e um protocolo aguardando há 8 dias, então exatamente um evento é emitido, mesmo com o job executado duas vezes.
- CA-TER-13.2 — Dado N=0, então o job não emite eventos.

#### 4.1.2 COMP-01.2 — módulo `acl-firp`

##### SPEC-FIR-01 — Porta `ConsultaAssinantesPort` e modelo de resultado

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.2 · CONSTRUIR · PRONTA |
| Rastreio | RF-03 · RN-05 · RFN-04 · R-04 · INV-05 · QA-DDD-12 |

```java
public interface ConsultaAssinantesPort {
  ResultadoConsultaAssinantes consultar(Cnpj cnpj, Set<CodigoProduto> produtos);
}
public sealed interface ResultadoConsultaAssinantes {
  record Encontrados(List<Assinante> assinantes) implements ResultadoConsultaAssinantes {}
  record NenhumAssinante() implements ResultadoConsultaAssinantes {}
  record Falha(FalhaIntegracao falha) implements ResultadoConsultaAssinantes {}
}
```

- `Assinante` = `{IdRepresentanteFirp, nome, papel, formaAssinatura}` — nada além (PRM-DDD-08).
- `NenhumAssinante` → Falha na geração com `etapa=FIRP`, `codigo=SEM_ASSINANTES`, `reprocessavel=true` (tratamento provisório de QA-DDD-12).

**Critérios de aceite**

- CA-FIR-01.1 — A porta não expõe tipos do modelo da FIRP (teste ArchUnit: `adesaotermo` não importa `aclfirp.adaptador`).

##### SPEC-FIR-02 — Adaptador FIRP via Axway

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.2 · CONSTRUIR · PARCIAL (QA-TEC-05 contrato; QA-TEC-03 autenticação; QA-DDD-04 redundância com o GACD; QA-TEC-24 CPF exigido pelo GACD) |
| Rastreio | RF-03 · RNF-01, RNF-04, RNF-09 · N-02 · RSK-07 · SPEC-API-05 |
| Depende de | SPEC-FIR-01, SPEC-TRV-10, 11, 15; SPEC-TST-03 |

**Regras**

- Implementa a porta sobre o contrato **hipotético** da seção 5.6 até QA-TEC-05; o adaptador isola o mapeamento em uma classe `TradutorRepresentanteFirp`.
- Filtra representantes com poder vigente para assinatura de termo/contrato de adesão (regra exata em QA-NEG-03); mapeia forma de assinatura (isolada/conjunta).
- **Descarta** CPF, data de nascimento, documentos e demais campos pessoais na fronteira; nenhum deles é persistido, logado ou propagado. Exceção prevista: se QA-TEC-24 confirmar que o GACD exige CPF no passo 1, a obtenção do CPF será feita **no momento do passo 1** por nova consulta (SPEC-GAC-01), mantida só em memória.
- Mapeamento de erros: 404 "empresa sem representantes" → `NenhumAssinante`; 5xx/timeout/429 → `TRANSITORIA`; 400/401/403 → `PERMANENTE` (401 dispara releitura de credencial uma vez).

**Critérios de aceite**

- CA-FIR-02.1 — Dado o stub FIRP retornando 3 representantes (2 com poder vigente, 1 vencido), então `Encontrados` com 2 assinantes e nenhum campo além de id, nome, papel e forma.
- CA-FIR-02.2 — Dado o stub com CPF no payload, então o CPF não aparece em banco, log, evento nem no objeto `Assinante` (inspeção por reflexão no teste).
- CA-FIR-02.3 — Dado 503 persistente, então `Falha(TRANSITORIA)` após 3 tentativas e circuito aberto após a janela.
- CA-FIR-02.4 — A chamada leva `Authorization` do `CredencialProvider`, `X-Correlation-ID` e `traceparent`.

#### 4.1.3 COMP-01.3 — módulo `acl-gacd`

##### SPEC-GAC-01 — Porta `AssinaturaDigitalPort` e adaptadores das 3 APIs GACD

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.3 · CONSTRUIR · PARCIAL (QA-TEC-06 payloads e APIs opcionais; QA-TEC-04 usuário sistêmico; QA-TEC-24 identificação de assinantes) |
| Rastreio | RF-06 · RFN-05 · RN-08, RN-15 · R-05 · RST-07 · CAP-05.1..05.3 · N-03 · SPEC-API-06 |
| Depende de | SPEC-TRV-10, 11, 15; SPEC-DOC-05; SPEC-TST-03 |

```java
public interface AssinaturaDigitalPort {
  ResultadoPasso<ProtocoloAberto> coordenarContrato(PedidoCoordenacao pedido);   // passo 1
  ResultadoPasso<PreviaArmazenada> armazenarPrevia(CodigoProtocolo p, DocumentoParaEnvio doc); // passo 2
  ResultadoPasso<RegraCoordenada> coordenarRegra(CodigoProtocolo p, PreviaArmazenada previa);  // passo 3
  Optional<ConsultaProtocolo> consultarProtocolo(CodigoProtocolo p);   // vazio se a API não existir
  ResultadoPasso<Void> cancelarProtocolo(CodigoProtocolo p);           // NAO_SUPORTADO se a API não existir
  Capacidades capacidades(); // {consulta, cancelamento, referenciaExterna}
}
```

**Regras**

- Nomes dos serviços **conforme a fonte** **[FATO: 04]**: passo 1 `gacd-srv-coordenar-ass-sformatador`; passo 2 `cgcc_conteudo_gacd/rest/v1/conteudo/armazenar`; passo 3 `gacd-srv-coordenar-regra`. A grafia final (`coordenar` × `coordenador`; `_` × `-`) é configurável por propriedade até QA-TEC-06.
- Passo 1 envia dados do contrato, assinantes e `callbackUrl` = `{adesao.gacd.callback-base-url}/{idAdesao}` **[FATO: 04]** (URL por adesão); envia `referenciaExterna = {idAdesao}-{tentativa}` se o GACD aceitar (QA-TEC-06), para reconciliação.
- Passo 2 lê o PDF do staging, confere o SHA-256 (tampering), envia **base64** com **usuário sistêmico** **[FATO: 04]**; retorno `IdPrevia`, `CaminhoPrevia` **[FATO: 04]**.
- Passo 3 confirma prévia e regras **[FATO: 04]**.
- `ResultadoPasso` = `Sucesso(valor)` \| `FalhaIntegracao{TRANSITORIA|PERMANENTE|INCERTA}` \| `NaoSuportado`.
- O modelo do GACD (contrato, "Produto", prévia) não sai do módulo (03 §3.7).

**Critérios de aceite**

- CA-GAC-01.1 — Dado o stub dos 3 passos, então o passo 1 recebe `callbackUrl` terminando em `/{idAdesao}`, o passo 2 recebe base64 cujo SHA-256 decodificado é igual ao registrado e a credencial de usuário sistêmico só aparece no passo 2.
- CA-GAC-01.2 — Dado hash do blob divergente, então o passo 2 não é chamado e a saga falha com `DOCUMENTO_ADULTERADO` (não reprocessável sem nova geração).
- CA-GAC-01.3 — Dado o GACD sem API de consulta/cancelamento, então `capacidades()` reflete isso e `cancelarProtocolo` retorna `NaoSuportado` sem chamada de rede.

##### SPEC-GAC-02 — Saga persistida de envio para assinatura

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.3 · CONSTRUIR · PRONTA (comportamento por passo depende de PRM-TEC-11) |
| Rastreio | RF-06, RF-14 · RNF-05, RNF-09 · ADR-02 · QA-CON-16 · `ProcessoEnvioAssinatura` · seção 9 · tabelas `saga_envio_assinatura`, `saga_envio_assinatura_passo` |
| Depende de | SPEC-GAC-01, SPEC-TER-08 |

Especificação completa na **seção 9**. Resumo: process manager persistido com etapas `COORDENAR_CONTRATO` → `ARMAZENAR_PREVIA` → `COORDENAR_REGRA`; estados `PENDENTE`, `EM_EXECUCAO`, `AGUARDANDO_RETENTATIVA`, `RESULTADO_INCERTO`, `COMPENSANDO`, `CONCLUIDA`, `FALHOU`; retentativa imediata e agendada por até 2 h; passo 1 nunca repetido às cegas.

**Critérios de aceite**

- CA-GAC-02.1 — Fluxo feliz: 3 passos com sucesso → saga `CONCLUIDA`, protocolo `VIGENTE` com `IdPrevia`/`CaminhoPrevia`, adesão Aguardando assinatura, evento `TermoEnviadoParaAssinatura` — a transição final numa única transação.
- CA-GAC-02.2 — Cada passo executado gera uma linha em `saga_envio_assinatura_passo` com resultado, status HTTP e duração.
- CA-GAC-02.3 — Dado falha transitória no passo 2 por 2 h (relógio simulado), então a saga entra em `COMPENSANDO` e depois `FALHOU`, e a adesão vai para Falha na geração (`etapa=GACD`).
- CA-GAC-02.4 — Dado timeout de leitura no passo 1, então `RESULTADO_INCERTO`, nenhuma nova chamada ao passo 1 e alerta operacional imediato.
- CA-GAC-02.5 — Confirmação → Aguardando assinatura p95 ≤ 90 s em Hom (RNF-07).

##### SPEC-GAC-03 — Compensação, reconciliação e protocolos órfãos

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.3 · CONSTRUIR · PARCIAL (QA-TEC-06: consulta, cancelamento e referência externa) |
| Rastreio | RF-14 · RSK-04 · ADR-02, ADR-08 · QA-DDD-02 · seção 9.4 · tabela `reconciliacao_manual` |
| Depende de | SPEC-GAC-01, 02; SPEC-TER-12 |

Especificação completa na **seção 9.4**. Inclui: cancelamento compensatório (se a API existir), abertura de `reconciliacao_manual` (`ORFAO`, `RESULTADO_INCERTO`, `CANCELAMENTO_PENDENTE`), job diário de reconciliação por consulta (flag), alerta operacional e runbook.

**Critérios de aceite**

- CA-GAC-03.1 — Dado protocolo aberto e falha final nos passos 2/3 sem API de cancelamento, então `protocolo_assinatura.situacao=ORFAO`, `reconciliacao_manual(ORFAO)` aberta e alerta com `codigoProtocolo`.
- CA-GAC-03.2 — Dado a API de cancelamento disponível (stub) e flag ligada, então a compensação cancela o protocolo e nenhuma reconciliação é aberta.
- CA-GAC-03.3 — Dado `RESULTADO_INCERTO` e API de consulta por referência externa, então o job reconcilia sozinho (protocolo encontrado → segue para o passo 2; não encontrado → repete o passo 1 com segurança).

#### 4.1.4 COMP-01.4 — módulo `termo-documento`

##### SPEC-DOC-01 — Catálogo de modelos do termo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.4 · CONSTRUIR · PARCIAL (QA-CON-19: dono do conteúdo jurídico) |
| Rastreio | RF-04 · RNF-14 · RN-03 · CAP-03.3 · BC-02 invariantes · tabela `termo_documento.modelo_termo` |
| Depende de | SPEC-DB-03 |

**Regras**

- Um modelo **vigente** por (`tipo_termo`, `renderizador`) — índice único parcial (seção 6); versão publicada é imutável.
- `referencia_template`: id do template CSF no IMPD (Plano A) ou caminho versionado do template HTML no repositório (Plano B).
- Publicação de versão por **migração Flyway** (dados de referência) aprovada por PR com evidência de aprovação do Jurídico/Compliance (`evidencia_aprovacao` = link do PR/RDM); sem endpoint de escrita em runtime.
- Documento gerado registra `id_modelo` e `versao_modelo` (RNFN-01).

**Critérios de aceite**

- CA-DOC-01.1 — Dada uma tentativa de publicar segundo modelo vigente para o mesmo tipo e renderizador, então a migração falha.
- CA-DOC-01.2 — Dado nenhum modelo vigente para o tipo, então a tarefa `GERAR_DOCUMENTO` falha como `PERMANENTE` com `codigo=MODELO_INEXISTENTE` e alerta operacional.

##### SPEC-DOC-02 — Composição e porta `RenderizadorDocumento`

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.4 · CONSTRUIR · PARCIAL (QA-TEC-30 / QA-NEG-10: variáveis) |
| Rastreio | RF-04 · CAP-03.1, CAP-08.1 · R-09, R-10 · ADR-03 |
| Depende de | SPEC-DOC-01, SPEC-TRV-14 |

```java
public interface GeradorDocumentoPort {           // R-09 (in-process)
  ResultadoGeracao gerar(DadosComposicao dados);  // DocumentoGerado{ref, hash, tamanho, versaoModelo, renderizador} | Falha
}
public interface RenderizadorDocumento {          // porta interna do BC-02 (ACL)
  ResultadoRenderizacao renderizar(ModeloTermo modelo, Map<String, Object> variaveis); // bytes PDF | Falha
}
```

**Variáveis propostas** **[PROPOSTA]** (lista final em QA-TEC-30): `razaoSocial`, `cnpjFormatado`, `tipoTermo`, `produtos[] {codigo, nome}`, `assinantes[] {nome, papel}`, `dataEmissao`, `idAdesao`, `tentativa`, `versaoModelo`. Sem CPF no documento, salvo exigência jurídica (QA-NEG-10).

**Regras**: seleção do adaptador por `termo.renderizador`; o gerador calcula SHA-256 sobre os **bytes do PDF** (não do base64), valida tamanho (`≤ termo.documento.tamanho-max-bytes`; acima de 1 MB → WARN e métrica) e grava no staging (SPEC-DOC-05).

**Critérios de aceite**

- CA-DOC-02.1 — Dado `DadosComposicao` com 10 assinantes e 15 produtos, então o documento é gerado e registrado com hash e versão do modelo.
- CA-DOC-02.2 — Dado PDF acima do limite técnico, então `Falha(PERMANENTE, DOCUMENTO_EXCEDE_LIMITE)`.

##### SPEC-DOC-03 — Adaptador IMPD `impd-srv-doc-generator` (Plano A)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.4 · CONSTRUIR · **BLOQUEADA** (QA-TEC-01 conectividade/autenticação/Swagger; QA-TEC-02 templates) — liberada pelo gate G1–G5 (ADR-03) |
| Rastreio | RF-04 · RNF-13, RNF-14 · COMP-16 · N-04 · RSK-01, RSK-02 · SPEC-API-07 |
| Depende de | SPEC-DOC-02, SPEC-API-07 |

**Regras**: chama `impd-srv-doc-generator` **[FATO: 06]** com o identificador do template CSF e as variáveis; a resposta é **base64** **[FATO: 05, 06]**, decodificada e validada (cabeçalho `%PDF-`, tamanho); timeouts da SPEC-TRV-11. Contrato de requisição **[HIPÓTESE]** até o Swagger (seção 5.8).

**Critérios de aceite**

- CA-DOC-03.1 — Dado o stub IMPD devolvendo base64 de um PDF válido, então o documento é registrado com `renderizador=IMPD`.
- CA-DOC-03.2 — Dado base64 que não decodifica em PDF, então `Falha(PERMANENTE, RESPOSTA_IMPD_INVALIDA)`.
- CA-DOC-03.3 — (Gate) Em Hom, p95 ≤ 5 s para documento de até 5 páginas (critério G2 do 04 §12.4).

##### SPEC-DOC-04 — Renderizador próprio (Plano B, desligado)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.4 · CONSTRUIR · PARCIAL (QA-CON-19: texto jurídico aprovado) |
| Rastreio | RF-04 · RNF-14 · ADR-03 (Plano B) · 04 §12 |
| Depende de | SPEC-DOC-02 |

**Regras**: Thymeleaf (modo HTML estrito, sem expressões de pré-processamento com entrada do usuário) + OpenHTMLtoPDF sobre PDFBox; saída **PDF/A-2b** com fontes embutidas (licença compatível); templates em `servicos/atacado-adesao-termo/src/main/resources/modelos/{tipoTermo}/v{versao}.html`; toda alteração de template exige PR aprovado pelo Jurídico (CODEOWNERS) e nova versão no catálogo; escape de todas as variáveis; sem recursos externos (imagens e CSS embutidos). Bulkhead de 2 renderizações concorrentes por pod.

**Critérios de aceite**

- CA-DOC-04.1 — O PDF gerado para os dois tipos passa na validação veraPDF PDF/A-2b.
- CA-DOC-04.2 — Dado `razaoSocial` com `<script>`, então o texto aparece escapado no PDF.
- CA-DOC-04.3 — Renderização de documento com 10 assinantes e 15 produtos em ≤ 3 s p95 com 1 vCPU.

##### SPEC-DOC-05 — Staging do PDF, hash e integridade

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.4 (usa COMP-05) · CONSTRUIR · PARCIAL (QA-TEC-12 aprovação do Blob; QA-TEC-14 identidade de workload) |
| Rastreio | RF-04, RF-05, RF-06, RF-11 · RNF-04, RNF-14, RNF-15 · ADR-04 · N-09 |
| Depende de | SPEC-STG-01 (ou modo `bytea`), SPEC-TRV-10 |

**Regras**

- `StagingDocumento` com dois adaptadores: `StagingBlob` (padrão) e `StagingBytea` (Plano B do ADR-04, coluna `documento_termo.conteudo`), selecionados por `termo.staging.modo=blob|bytea`.
- Caminho `{idAdesao}/{tentativa}/termo.pdf` **(04 ADR-04)**; metadados do blob: `sha256`, `versaoModelo`; `Content-Type: application/pdf`; sobrescrita proibida (`If-None-Match: *`).
- Autenticação no Blob por identidade de workload (`DefaultAzureCredential`) quando disponível; senão credencial do Key Vault (QA-TEC-14).
- Leitura sempre confere o SHA-256 antes de servir a prévia (SPEC-TER-04) ou enviar ao GACD (SPEC-GAC-01).
- Exclusão explícita em Assinado/Encerrado e na reemissão (tarefa `EXCLUIR_STAGING`); lifecycle de 30 dias como rede de segurança (SPEC-STG-01).

**Critérios de aceite**

- CA-DOC-05.1 — Dado Azurite (teste), quando o documento é gravado, então o caminho e os metadados seguem a regra e uma segunda gravação no mesmo caminho falha.
- CA-DOC-05.2 — Dado `termo.staging.modo=bytea`, então o fluxo completo passa sem Blob.
- CA-DOC-05.3 — Dado Assinado, então o blob é excluído em até 5 min e `removido_staging_em` preenchido.

#### 4.1.5 COMP-01.5 — módulo `acl-registro-contratos`

##### SPEC-ELG-01 — Políticas de elegibilidade e tipo de termo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.5 (+ serviços de domínio no 01.1) · CONSTRUIR · PRONTA |
| Rastreio | RF-02 · RFN-02, RFN-03 · RN-02, RN-03 · INV-02, INV-04 · CAP-02.1, CAP-02.2 · PRM-TEC-10 · QA-DDD-10, QA-CON-21 |
| Depende de | SPEC-TER-01 |

**Regras**

- `ElegibilidadePort.avaliar(cnpj, indicadoresRecebidos)` → `InformacoesElegibilidade{possuiContratoVigente, possuiAcessoCanalDigital, referenciaContratoVigente, origem}`.
- Adaptador atual `ElegibilidadeInformadaPeloSalesforce` (PRM-TEC-10): usa os indicadores do comando e marca `origem=SALESFORCE`; propriedade `adesao.elegibilidade.fonte=salesforce` (futuro: `registro-contratos`, BC-13, R-19).
- `PoliticaElegibilidade`: contrato vigente → `DISPENSADA`; senão `REQUERIDA` (RN-02). `PoliticaTipoTermo`: acesso ao Canal → `PRODUTOS`; senão `PRODUTOS_CANAL` (RN-03).
- RN-04 (tarifas aprovadas) é pré-condição garantida pelo Salesforce e registrada na auditoria (`propostaAprovada=true` no comando; ausência → 400).

**Critérios de aceite**

- CA-ELG-01.1 — Tabela-verdade dos dois indicadores coberta por teste (4 combinações).
- CA-ELG-01.2 — Trocar o adaptador por um stub `registro-contratos` não exige mudança em `adesaotermo` (teste de configuração).

#### 4.1.6 COMP-01.6 — módulo `convenio-produto` (inativo)

##### SPEC-CNV-01 — Porta de convênio desativada e eventos-gatilho

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01.6 · CONSTRUIR · PRONTA |
| Rastreio | RF-12 · RFN-09 · RN-10, RN-11, RN-13, RN-17 · ADR-11 · PRM-DDD-11 · PRM-CON-15 · QA-TEC-11, QA-CON-24, QA-CON-25 |
| Depende de | SPEC-EVT-01 |

**Regras**: interface `SolicitacaoConvenioPort` e JSON Schema de `ConvenioSolicitado` (v1) publicados em `contratos/eventos/` como contrato; **nenhuma** implementação registrada; `convenio.gatilho.habilitado=false`; `AssinaturaConcluida` e `AdesaoDispensada` carregam `cnpj` e `produtos[]` (gatilhos).

**Comportamento esperado na ativação (fora desta entrega)**: o gatilho **abre a implantação** do produto, não cria o convênio. Quando ativada, a porta tende a **abrir uma pendência de implantação** por produto (tarefa para o Gerente de Cash ou o backoffice, a definir — QA-CON-24), visível no Salesforce, e a acompanhar o status da jornada **Em implantação → Convênio ativo** (SPEC-ACP-02), e **não** a criar o convênio direto por API no sistema do produto. O convênio nasce em teste, passa pela homologação com o cliente e só então é ativado (RN-17); fica registrado no sistema do produto (APP-09), e o Salesforce mostra só número e status **[PREMISSA: PRM-CON-15 — padrão de mercado]** **[ABERTO: QA-TEC-11, QA-CON-24, QA-CON-25]**. O contrato detalhado (payload de `ConvenioSolicitado`, origem da tarefa, sinal de convênio ativo) será especificado em nova versão deste documento quando essas questões forem respondidas.

**Critérios de aceite**

- CA-CNV-01.1 — Com a flag `false`, o contexto Spring não contém bean que implemente `SolicitacaoConvenioPort` (teste).
- CA-CNV-01.2 — Os schemas de `AssinaturaConcluida` e `AdesaoDispensada` exigem `cnpj` e `produtos[]` não vazio.

### 4.2 COMP-02 — `atacado-adesao-receptor`

| Campo | Conteúdo |
|---|---|
| Deployable | Spring Boot 3 leve, sem Flyway, sem domínio (depende só de `adesao-plataforma` e `adesao-contrato-inbox`) |
| BC | BC-01 (borda de entrada: ACL-Callback, ACL-Alerta) |
| RF / RNF | RF-07, RF-08 (recepção), RF-13, RF-14 (apoio) / RNF-01..05, 08..11 |
| ADR | ADR-01, ADR-08, ADR-09 |
| Disponibilidade | ≥ 99,9%/mês (RNF-08); RPO 0 para sinal com ACK |

##### SPEC-REC-01 — Recepção do callback do GACD

| Campo | Conteúdo |
|---|---|
| Componente | COMP-02 · CONSTRUIR · PARCIAL (QA-TEC-07) |
| Rastreio | RF-07 · RN-08 · RFN-08 · R-06 · CAP-05.5, CAP-10.3 · ADR-08 · RSK-03, RSK-16 · SPEC-API-02 |
| Depende de | SPEC-REC-03, SPEC-REC-04 |

**Regras**

- `POST /v1/callbacks/gacd/assinaturas/{idAdesao}` (público no Axway: `/atacado/adesao/v1/callbacks/gacd/assinaturas/{idAdesao}`).
- ACL **tolerante**: aceita o payload do GACD (hipótese na seção 5.3), extrai `codigoProtocolo`, situação e data; traduz a situação para `tipo_sinal` canônico por **tabela configurável** (`adesao.receptor.gacd.mapa-situacao`), para absorver o contrato real sem novo deploy de código.
- Chave de idempotência: `GACD:{codigoProtocolo}:{tipoSinal}` (04a COMP-02).
- Grava `sinal_externo` com `INSERT … ON CONFLICT (origem, chave_idempotencia) DO NOTHING`; guarda `hash_payload_bruto` (SHA-256) e, se a flag permitir, o payload bruto.
- Respostas: **200** após commit (inclusive duplicado); **400** só para JSON sintaticamente inválido ou sem `codigoProtocolo`; **nunca** 4xx para protocolo desconhecido (vai à quarentena no COMP-01); **503** se o banco estiver indisponível.
- Limite de corpo 256 KB; tempo de resposta p99 ≤ 500 ms.

**Critérios de aceite**

- CA-REC-01.1 — Dado callback válido, então 200 e uma linha `RECEBIDO` com a chave esperada; repetido 5 vezes, então 5 respostas 200 e uma linha.
- CA-REC-01.2 — Dado banco indisponível, então 503 e nenhuma resposta 200 sem commit.
- CA-REC-01.3 — Dado situação não mapeada, então 200 e sinal com `tipo_sinal=DESCONHECIDO` (a quarentena ocorre no COMP-01).
- CA-REC-01.4 — Dado corpo sem `codigoProtocolo`, então 400 `REQUISICAO_INVALIDA` e log sem o corpo.

##### SPEC-REC-02 — Recepção do alerta de assinantes inválidos

| Campo | Conteúdo |
|---|---|
| Componente | COMP-02 · CONSTRUIR · PARCIAL (QA-TEC-08) |
| Rastreio | RF-08 · RN-06, RN-07 · RFN-07 · R-13 · CAP-09.5, CAP-10.3 · ADR-09 · RSK-06 · SPEC-API-03 |
| Depende de | SPEC-REC-03, SPEC-REC-04 |

**Regras**

- `POST /v1/alertas/assinantes-invalidos` e `GET /v1/alertas/{idNotificacao}` (públicos: `/atacado/adesao/v1/...`), contrato "Alerta de Assinantes Inválidos v1" (seção 5.4).
- `Idempotency-Key` = `idNotificacao` (se ambos vierem e divergirem → 400). Chave da inbox: `CANAL:{codigoProtocolo}:{idNotificacao}`.
- Validação: `motivo` no enum; `cnpj` válido; `quantidadeAssinantesInvalidos ≥ 1`; **sem texto livre**; campos desconhecidos ignorados e **não persistidos** (métrica `adesao_alerta_campos_desconhecidos_total` para detectar envio indevido de dado pessoal).
- Resposta **202** `{idAlerta, situacao: RECEBIDO}`; repetição → mesma resposta.
- `GET` devolve `RECEBIDO` \| `APLICADO` \| `REJEITADO` (+ `motivoRejeicao`: `PROTOCOLO_NAO_VIGENTE`, `ESTADO_INCOMPATIVEL`, `PROTOCOLO_DESCONHECIDO`), lido de `sinal_externo`.
- Limite de corpo 16 KB.

**Critérios de aceite**

- CA-REC-02.1 — Dado alerta válido, então 202 e sinal `RECEBIDO`; repetido com o mesmo `idNotificacao`, então 202 com o mesmo `idAlerta`.
- CA-REC-02.2 — Dado alerta com campo extra `cpf`, então 202, o campo não é persistido e a métrica de campos desconhecidos incrementa.
- CA-REC-02.3 — Dado `motivo="texto livre"`, então 400.
- CA-REC-02.4 — Após o COMP-01 aplicar o alerta, `GET /v1/alertas/{id}` retorna `APLICADO`.

##### SPEC-REC-03 — Verificação da identidade do chamador

| Campo | Conteúdo |
|---|---|
| Componente | COMP-02 · CONSTRUIR · PARCIAL (QA-TEC-22 cabeçalhos do Axway; QA-TEC-07/08 mecanismo de cada emissor) |
| Rastreio | RNF-01 · ADR-08, ADR-09 · RSK-16 · 04 §8.1 |
| Depende de | SPEC-INF-05, SPEC-SEG-01 |

**Regras**: além da autenticação no Axway (mTLS ou token), o COMP-02 confere a **identidade propagada** pelo Axway (cabeçalho/claim com `client_id` ou DN do certificado — nome em QA-TEC-22) contra uma allowlist por endpoint (`adesao.receptor.chamadores.callback-gacd`, `…alerta-canal`). Se o Axway propagar um JWT, o COMP-02 valida assinatura e `aud` como Resource Server. Identidade ausente ou fora da allowlist → 403 e log de segurança.

**Critérios de aceite**

- CA-REC-03.1 — Dado chamada ao endpoint de callback com identidade do Canal, então 403.
- CA-REC-03.2 — Dado cabeçalho de identidade ausente, então 403 (defesa em profundidade, mesmo atrás do Axway).

##### SPEC-REC-04 — Contrato da inbox, isolamento e disponibilidade

| Campo | Conteúdo |
|---|---|
| Componente | COMP-02 (+ `libs/adesao-contrato-inbox`) · CONSTRUIR · PRONTA |
| Rastreio | RNF-05, RNF-08 · ADR-01, ADR-08 · RSK-17 · tabela `adesao_entrada.sinal_externo` |
| Depende de | SPEC-DB-02, 03; SPEC-INF-01 |

**Regras**

- A tabela `sinal_externo` é **contrato interno versionado** entre COMP-02 e COMP-01: coluna `versao_contrato` (inicial 1); mudanças só por expand/contract; o record `SinalExterno` e o DAO de inserção ficam em `adesao-contrato-inbox`, usados pelos dois.
- Role `adesao_receptor_app` só com `INSERT`/`SELECT` em `adesao_entrada.sinal_externo`.
- Bulkhead por endpoint (callback e alerta com pools de concorrência separados) para que rajada de um não afete o outro.
- Manifestos: 2..3 réplicas, PDB `minAvailable: 1`, anti-afinidade por zona (SPEC-INF-01).

**Critérios de aceite**

- CA-REC-04.1 — Teste ArchUnit: COMP-02 não depende de nenhum pacote de COMP-01.
- CA-REC-04.2 — Dado a role do receptor, `UPDATE` em `sinal_externo` falha por privilégio.
- CA-REC-04.3 — Dado deploy do COMP-01 em andamento (pods reiniciando), então callbacks continuam recebendo 200 (teste em Hom).

### 4.3 COMP-03 — `atacado-adesao-acompanhamento`

| Campo | Conteúdo |
|---|---|
| Deployable | Spring Boot 3 worker; sem porta de negócio; 8081 Actuator, 8082 admin |
| BC | BC-03 |
| RF / RNF | RF-09, RF-14 (apoio a RF-07, 08, 13) / RNF-01..03, 05, 06, 09..11, 16 |
| ADR | ADR-05, ADR-06, ADR-10 |

##### SPEC-ACP-01 — Relay da outbox

| Campo | Conteúdo |
|---|---|
| Componente | COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RF-09 · RNF-05, RNF-06 · ADR-05 · CAP-10.4 · INV-10 |
| Depende de | SPEC-TER-10, SPEC-DB-02 |

**Regras**

- Uma instância ativa por **ShedLock** (`lockAtMostFor=30s`, renovado a cada lote); a outra réplica fica em espera.
- Ciclo a cada 1 s (ou ao receber `NOTIFY adesao_outbox`): `SELECT … FROM adesao_termo.outbox_evento WHERE situacao='PENDENTE' AND (proxima_tentativa_em IS NULL OR proxima_tentativa_em <= now()) ORDER BY id_agregado, versao_agregado LIMIT 50 FOR UPDATE SKIP LOCKED`.
- **Ordem por agregado**: se um evento de um agregado falhar, os eventos seguintes do mesmo agregado ficam para o próximo ciclo (não pula versão).
- Para cada evento, numa transação: verifica `evento_consumido` (idempotência), aplica a projeção (SPEC-ACP-02), cria/atualiza `entrega_status`, grava `evento_consumido` e marca `outbox_evento.situacao='CONSUMIDO'`.
- Erro na projeção (ex.: evento inválido) → `tentativas += 1`, `proxima_tentativa_em` exponencial; após 10 tentativas → `ESTACIONADO` + alerta.
- Role `adesao_acompanhamento_app`: `SELECT` e `UPDATE (situacao, tentativas, proxima_tentativa_em, ultimo_erro, consumido_em)` em `outbox_evento`.

**Critérios de aceite**

- CA-ACP-01.1 — Dado 3 eventos do mesmo agregado (versões 2, 3, 4), então são projetados em ordem, mesmo com o relay reiniciado entre eles.
- CA-ACP-01.2 — Dado o mesmo evento entregue duas vezes (simulação de falha após projeção e antes do commit), então a projeção é aplicada uma vez.
- CA-ACP-01.3 — Com 2 réplicas, só uma executa o ciclo (métrica `acompanhamento_relay_lider=1` em uma réplica).
- CA-ACP-01.4 — Latência commit → consumo p95 ≤ 5 s.

##### SPEC-ACP-02 — Projeção da jornada e alertas ao Gerente

| Campo | Conteúdo |
|---|---|
| Componente | COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RF-09, RF-08 (alerta), RF-12 (status reservados) · RFN-07, RFN-08 · CAP-09.1, CAP-09.2 (notificação ao Gerente) · PRI-12 · 03 §3.4 |
| Depende de | SPEC-ACP-01 |

**Regras**

- `visao_jornada` por `id_proposta` + `id_adesao` (ou `id_decisao`), **monotônica** por `versao_agregado` (evento mais antigo não sobrescreve o mais novo) e idempotente por `idEvento`.
- Mapeamento para o status da jornada:

| Evento | `status_termo` | `status_jornada` | Alerta |
|---|---|---|---|
| `AdesaoDispensada` | — | `NAO_REQUERIDO` | — |
| `TermoSolicitado`, `AssinantesIdentificados`, `TermoGerado`, `TermoEnviadoParaAssinatura`, `ReemissaoSolicitada` | Estado correspondente | `TERMO_EM_ANDAMENTO` | Resolve alertas ativos da adesão na reemissão |
| `GeracaoDoTermoFalhou` | `FALHA_NA_GERACAO` | `TERMO_EM_ANDAMENTO` | Cria `FALHA_GERACAO` (ação sugerida: reemitir; motivo: etapa) |
| `AssinantesInvalidados` | `ASSINANTES_INVALIDOS` | `TERMO_EM_ANDAMENTO` | Cria `ASSINANTES_INVALIDOS` (ação: regularizar poderes na FIRP e reemitir) |
| `PendenciaAssinaturaProlongada` [DT-17] | (inalterado) | (inalterado) | Cria `PENDENCIA_PROLONGADA` |
| `AssinaturaConcluida` | `ASSINADO` | `TERMO_ASSINADO` | Resolve alertas ativos |
| `TermoEncerrado` | `ENCERRADO` | `ENCERRADA` | Resolve alertas ativos |
| (reservado, ADR-11) | — | `EM_IMPLANTACAO`, `CONVENIO_ATIVO`, `TARIFAS_CADASTRADAS`, por produto, nessa ordem após `TERMO_ASSINADO` (+ `CONVENIO_PENDENTE` como exceção: falha ou atraso na implantação/homologação) **[PREMISSA: PRM-CON-15 — padrão de mercado]** | Não projetados nesta entrega (SPEC-CNV-01) |

- O BC-03 **nunca** altera o estado do Termo; o status da jornada nunca é informado pelo Salesforce.

**Critérios de aceite**

- CA-ACP-02.1 — Para cada linha da tabela, um teste comprova `status_termo`, `status_jornada` e o alerta criado/resolvido.
- CA-ACP-02.2 — Dado `TermoGerado` (v3) processado depois de `TermoEnviadoParaAssinatura` (v4) por reprocessamento, então a visão permanece em Aguardando assinatura.

##### SPEC-ACP-03 — Entrega de status ao Salesforce (upsert)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-03 · CONSTRUIR · PARCIAL (QA-TEC-15: objetos, campos, versão da API) |
| Rastreio | RF-09 · RNF-05, RNF-06 · R-02 · ADR-06 · N-07 · RSK-11 · SPEC-API-04 · [DT-12] |
| Depende de | SPEC-ACP-02, SPEC-ACP-04, SPEC-SFC-01 |

**Regras**

- `entrega_status` por objeto de destino: `ADESAO_TERMO` (chave `Id_Adesao__c`) e `ALERTA_ADESAO` (chave `Id_Alerta__c`).
- Entregador (ShedLock, a cada 1 s) processa entregas `PENDENTE` com `proxima_tentativa_em <= now()`, **em série por `id_adesao`**; antes de enviar uma entrega `ADESAO_TERMO`, marca como `SUPERADA` as pendentes mais antigas do mesmo registro (coalescência, [DT-12]); alertas nunca são coalescidos.
- Upsert: `PATCH {instance}/services/data/{versao}/sobjects/Adesao_Termo__c/Id_Adesao__c/{idAdesao}` e `…/Alerta_Adesao__c/Id_Alerta__c/{idAlerta}` (corpo na seção 5.5).
- Classificação: 200/201/204 → `CONFIRMADA`; 5xx, timeout, 429 (com `Retry-After`) → retentativa exponencial 1 s → 15 min até 24 h, depois `ESTACIONADA` + alerta; 401 `INVALID_SESSION_ID` → renova token e repete uma vez; 400/404 (erro de campo/permissão) → `ESTACIONADA` imediata (erro de configuração, alerta P2).
- Mede `adesao_entrega_latencia_seconds` (commit do evento → confirmação no Salesforce).

**Critérios de aceite**

- CA-ACP-03.1 — Dado o stub do Salesforce disponível, então a latência commit → confirmação p95 ≤ 60 s (RNF-06; meta de produção medida com o Salesforce real em Hom).
- CA-ACP-03.2 — Dado o Salesforce fora por 2 h, então nenhuma entrega é perdida e todas são confirmadas em ordem após a volta.
- CA-ACP-03.3 — Dado 3 entregas pendentes do mesmo `Adesao_Termo__c`, então só a mais recente é enviada e as outras ficam `SUPERADA`.
- CA-ACP-03.4 — Dado 400 `INVALID_FIELD`, então `ESTACIONADA` sem retentativa e alerta.

##### SPEC-ACP-04 — Autenticação OAuth 2.0 JWT Bearer no Salesforce

| Campo | Conteúdo |
|---|---|
| Componente | COMP-03 · CONSTRUIR · PARCIAL (QA-TEC-15 Connected App/External Client App; QA-TEC-26 certificado) |
| Rastreio | RNF-01, RNF-02 · ADR-06 · N-07 · SPEC-SFC-03 |
| Depende de | SPEC-TRV-10, SPEC-SEG-01 |

**Regras**

- JWT RS256 com `iss` = consumer key da Connected App/External Client App, `sub` = username do usuário de integração, `aud` = `acompanhamento.salesforce.audience`, `exp` = agora + 3 min; assinado com a chave privada do Key Vault (`sf-jwt-chave-privada`).
- `POST {instance}/services/oauth2/token` com `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer`.
- O fluxo JWT Bearer não devolve `expires_in`: cache do `access_token` com TTL configurável (default 30 min, menor que o timeout de sessão da Connected App) e renovação imediata em 401.
- Troca de chave: suportar duas chaves (atual e próxima) durante a rotação (certificados cadastrados na Connected App).

**Critérios de aceite**

- CA-ACP-04.1 — Dado stub do endpoint de token, então o JWT enviado tem `iss`, `sub`, `aud`, `exp` ≤ 3 min e assinatura verificável com o certificado público.
- CA-ACP-04.2 — Dado 401 no upsert, então um novo token é obtido e a entrega é repetida uma vez.
- CA-ACP-04.3 — A chave privada nunca aparece em log, métrica ou dump de configuração (`/actuator/env` desabilitado).

##### SPEC-ACP-05 — Estacionamento, reentrega e consumo de limites

| Campo | Conteúdo |
|---|---|
| Componente | COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RF-14 · RNF-11, RNF-16 · RSK-11 · 04 §9.2 |
| Depende de | SPEC-ACP-03 |

**Regras**

- `POST /admin/v1/entregas/{id}/reentregar` e `POST /admin/v1/entregas/reentregar?situacao=ESTACIONADA&desde=…` (porta 8082, mesma autenticação da SPEC-TER-12): volta a `PENDENTE` zerando o backoff; auditoria em log de segurança e na própria entrega (`reentregue_por`, `reentregue_em`).
- Lê o cabeçalho `Sforce-Limit-Info` (`api-usage=usado/limite`) das respostas e publica `adesao_salesforce_api_uso_ratio`; acima de 80% → alerta P3.

**Critérios de aceite**

- CA-ACP-05.1 — Dado uma entrega `ESTACIONADA`, quando reentregue com Salesforce disponível, então `CONFIRMADA`.
- CA-ACP-05.2 — Dado `Sforce-Limit-Info: api-usage=90/100`, então a métrica vale 0,9.

### 4.4 COMP-04 — `atacado-adesao-db`

| Campo | Conteúdo |
|---|---|
| Tipo | Azure Database for PostgreSQL Flexible Server 16 (PRM-TEC-01) |
| Schemas | `adesao_termo` (BC-01), `termo_documento` (BC-02), `adesao_entrada` (borda BC-01), `adesao_acompanhamento` (BC-03), `adesao_migracao` (histórico Flyway) |
| RNF | RNF-03, 04, 05, 08, 10, 12 |

##### SPEC-DB-01 — Provisionamento do PostgreSQL Flexible Server

| Campo | Conteúdo |
|---|---|
| Componente | COMP-04 · PROVISIONAR · **BLOQUEADA** (QA-TEC-12 aprovação; QA-TEC-20 IaC; QA-TEC-28 extensões/parâmetros) |
| Rastreio | ADR-05 · PRM-TEC-01 · RNF-03, RNF-08 · RSK-10 · N-08 |
| Depende de | SPEC-INF-04 |

Parâmetros por ambiente na seção 11.5. **Critérios de aceite**: CA-DB-01.1 — acesso público desabilitado e conexão só pela subnet delegada/DNS privado; CA-DB-01.2 — `require_secure_transport=on` e TLS 1.2+; CA-DB-01.3 — em Prod, HA com redundância de zona e PITR de 35 dias; CA-DB-01.4 — failover forçado em Hom com RTO ≤ 5 min medido (SPEC-TST-08).

##### SPEC-DB-02 — Schemas, roles e privilégios

| Campo | Conteúdo |
|---|---|
| Componente | COMP-04 · CONSTRUIR · PARCIAL (QA-TEC-14: Entra ID × usuário/senha) |
| Rastreio | RNF-03, RNF-04 · 04 §8.1 (role por schema) · ADR-05 |
| Depende de | SPEC-DB-01 |

Roles e grants na seção 6.3. **Critérios de aceite**: CA-DB-02.1 — cada role executa só as operações da matriz (teste automatizado com Testcontainers conectando com cada role); CA-DB-02.2 — nenhuma role de aplicação é dona de objetos nem tem `CREATE`.

##### SPEC-DB-03 — Migrações Flyway (expand/contract)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-04 (código no COMP-01) · CONSTRUIR · PRONTA (hook do pipeline: QA-TEC-19) |
| Rastreio | ADR-01 · RSK-17 · RNF-16 |
| Depende de | SPEC-TRV-01 |

**Regras**

- Migrações em `servicos/atacado-adesao-termo/src/main/resources/db/migration`, nome `V<AAAAMMDDHHmm>__<descricao>.sql`; grants em `R__grants.sql` (repetível).
- Execução por **Job Kubernetes pré-deploy** com a imagem do COMP-01, profile `migracao` (`spring.main.web-application-type=none`, só Flyway) e role `adesao_migracao`; aplicação em runtime com `spring.flyway.enabled=false`.
- `flyway.schemas=adesao_migracao,adesao_termo,termo_documento,adesao_entrada,adesao_acompanhamento` com histórico em `adesao_migracao`.
- **Expand/contract**: toda migração deve ser compatível com a versão N-1 dos três deployables; remoção de coluna/tabela só em release posterior ao que parou de usá-la; `CREATE INDEX CONCURRENTLY` em tabelas com dados (migração não transacional isolada).
- `lock_timeout` de 5 s na sessão de migração para não bloquear o tráfego.

**Critérios de aceite**

- CA-DB-03.1 — O pipeline executa as migrações sobre um banco vazio e sobre uma cópia do schema da versão anterior sem erro.
- CA-DB-03.2 — Teste de compatibilidade: a suíte de integração da versão N-1 roda contra o schema N (SPEC-TST-08).
- CA-DB-03.3 — Falha do Job de migração interrompe o deploy (nenhum pod novo sobe).

##### SPEC-DB-04 — Retenção, particionamento e expurgo

| Campo | Conteúdo |
|---|---|
| Componente | COMP-04 · CONSTRUIR · PARCIAL (QA-TEC-17 prazos; QA-TEC-28 `pg_cron`/`pg_partman`) |
| Rastreio | RNF-04, RNF-10 · RSK-12 · [DT-11] |
| Depende de | SPEC-DB-03 |

Prazos propostos na seção 6.4. Mecanismo: `CronJob` Kubernetes diário com a role `adesao_manutencao` (cria partições dos 3 meses seguintes de `trilha_auditoria`, remove partições vencidas, expurga linhas operacionais vencidas em lotes de 1.000, anonimiza nomes de assinantes vencidos). **Critérios de aceite**: CA-DB-04.1 — execução idempotente; CA-DB-04.2 — com dados sintéticos vencidos, só as linhas elegíveis são removidas/anonimizadas; CA-DB-04.3 — partições futuras sempre existem para ≥ 2 meses (alerta se não).

### 4.5 COMP-05 — `atacado-adesao-staging`

##### SPEC-STG-01 — Provisionamento do Blob de staging e lifecycle

| Campo | Conteúdo |
|---|---|
| Componente | COMP-05 · PROVISIONAR · **BLOQUEADA** (QA-TEC-12, QA-TEC-20) |
| Rastreio | ADR-04 · PRM-TEC-02 · RNF-03, RNF-04, RNF-14 · N-09 · RSK-10, RSK-12 |
| Depende de | SPEC-INF-04, SPEC-INF-06 |

**Configuração**: StorageV2, redundância de zona (ZRS) em Prod; `allowBlobPublicAccess=false`; `publicNetworkAccess=Disabled`; private endpoint `blob` com DNS privado; `allowSharedKeyAccess=false` quando houver identidade de workload (QA-TEC-14); TLS mínimo 1.2; criptografia em repouso (chave gerenciada ou CMK); container privado `termos-staging`; **lifecycle**: excluir blobs com `daysAfterCreationGreaterThan: 30`; soft delete de blob 7 dias; versionamento desligado; RBAC `Storage Blob Data Contributor` só para a identidade do COMP-01, no escopo do container; diagnóstico (logs de leitura/escrita/exclusão) para a observabilidade.

**Critérios de aceite**: CA-STG-01.1 — acesso a partir da internet e de fora do spoke falha; CA-STG-01.2 — a política de lifecycle está ativa com 30 dias (evidência de IaC + portal); CA-STG-01.3 — só a identidade do COMP-01 consegue ler/gravar (teste com outra identidade retorna 403).

### 4.6 COMP-06 — Artefatos Salesforce do Atacado

| Campo | Conteúdo |
|---|---|
| Tipo | Configuração e desenvolvimento em Salesforce FSC (Apex, LWC, Flow, metadados) |
| BC | BC-05 |
| RF / RNF | RF-01, RF-05, RF-09, RF-10, RF-11 / RNF-01, RNF-02, RNF-06 |
| ADR | ADR-06, ADR-07 |
| Regra de ouro | Nenhuma regra de adesão em Apex/Flow (PRI-02): o Salesforce dispara comandos e exibe a projeção |

##### SPEC-SFC-01 — Objetos e campos de status no Salesforce

| Campo | Conteúdo |
|---|---|
| Componente | COMP-06 · CONFIGURAR · PARCIAL (QA-TEC-15) |
| Rastreio | RF-09 · R-02 · ADR-06 · RNF-06 · SPEC-API-04 · [DT-12] |

**Regras**: objetos `Adesao_Termo__c` e `Alerta_Adesao__c` com os campos da seção 5.5; `Id_Adesao__c` e `Id_Alerta__c` como **External ID único**; picklists com os valores canônicos (API names em maiúsculas, rótulos em português); **gatilho before-update** (Apex trigger ou record-triggered Flow *before save*) que, quando `Versao_Evento__c` recebido < atual, **restaura os valores anteriores sem erro** [DT-12]; histórico de campo em `Status_Termo__c`; sharing: registros visíveis ao dono da Proposta e à hierarquia.

**Critérios de aceite**: CA-SFC-01.1 — upsert com versão menor retorna sucesso e não altera o registro; CA-SFC-01.2 — upsert com External ID inexistente cria o registro com lookup para a Proposta.

##### SPEC-SFC-02 — Chamada à API Adesão (Named/External Credential e cliente Apex)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-06 · CONSTRUIR · PARCIAL (QA-TEC-15 mTLS na Named Credential; QA-TEC-03 emissor OAuth; QA-TEC-26 certificado) |
| Rastreio | RF-01, RF-05, RF-10, RF-11 · RN-09 · ADR-07 · N-01 · SPEC-API-01 |

**Regras**

- **External Credential** `Atacado_Adesao_API` (OAuth 2.0 client credentials contra o emissor corporativo) + **Named Credential** com o certificado de cliente mTLS (Certificate and Key Management); permission set concede o principal só aos usuários Gerentes de Cash.
- Classe `AdesaoApiClient` (Apex) com um método por operação; `callout:Atacado_Adesao_API/v1/adesoes…`.
- `Idempotency-Key`: gerada com `UUID.randomUUID()` e **persistida** no registro da solicitação antes do callout, para ser reutilizada em retentativa.
- Timeouts de callout: 10 s para comandos; 30 s para a prévia (≤ 120 s, limite da plataforma).
- `X-Correlation-ID` gerado por solicitação e gravado no `Adesao_Termo__c`.
- Tratamento de `application/problem+json` por `codigo` (mensagens amigáveis na UI); 5xx/timeout → retentativa pelo usuário ou Queueable com a mesma chave.
- Nenhuma credencial em Custom Settings/Metadata.

**Critérios de aceite**: CA-SFC-02.1 — teste Apex com `HttpCalloutMock` para cada código do catálogo; CA-SFC-02.2 — retentativa após timeout reutiliza a mesma `Idempotency-Key`; CA-SFC-02.3 — em Hom, chamada sem certificado de cliente é rejeitada pela borda.

##### SPEC-SFC-03 — Connected App, usuário de integração e permissões

| Campo | Conteúdo |
|---|---|
| Componente | COMP-06 · CONFIGURAR · PARCIAL (QA-TEC-15, QA-TEC-26) |
| Rastreio | RNF-01, RNF-02 · ADR-06 · 04 §8.1 · SPEC-ACP-04 |

**Regras**: Connected App ou External Client App `atacado-adesao-acompanhamento` com certificado digital (fluxo JWT Bearer), "Admin approved users are pre-authorized", política de IP restrita aos IPs de saída do Hub (se aplicável), escopo `api`; **usuário de integração** (licença Salesforce Integration, se disponível) com permission set mínimo: criar/editar `Adesao_Termo__c` e `Alerta_Adesao__c`, leitura da Proposta para o lookup; sem acesso a outros objetos nem à UI.

**Critérios de aceite**: CA-SFC-03.1 — com o token do usuário de integração, tentativa de ler outro objeto (ex.: Account) falha; CA-SFC-03.2 — o JWT com certificado não cadastrado é rejeitado.

##### SPEC-SFC-04 — UI da jornada do Gerente

| Campo | Conteúdo |
|---|---|
| Componente | COMP-06 · CONSTRUIR · PARCIAL (QA-TEC-15 UI da prévia; QA-NEG-18) |
| Rastreio | RF-01, RF-05, RF-10, RF-11 · RFN-01, RFN-04, RFN-08 · CAP-09.1 |

**Regras**: componente LWC na página da Proposta: botão "Solicitar Termo de Adesão" (habilitado com proposta aprovada e sem adesão não terminal visível); painel com status do termo e da jornada, assinantes (via `GET /v1/adesoes/{id}`), prévia do PDF, botões Confirmar envio (estado Gerado, flag), Reemitir (Falha na geração / Assinantes inválidos) e Cancelar (estados da seção 7.3); habilitação dos botões **derivada do status recebido**, sem regra de negócio adicional. Exibição do PDF sem gravá-lo em Salesforce Files (técnica a validar em QA-TEC-15; alternativa: `ContentVersion` temporário com exclusão ao fechar).

**Critérios de aceite**: CA-SFC-04.1 — testes Jest do LWC para cada estado (botões visíveis/ocultos); CA-SFC-04.2 — a confirmação envia o `hashDocumento` do PDF exibido.

##### SPEC-SFC-05 — Notificação ao Gerente

| Campo | Conteúdo |
|---|---|
| Componente | COMP-06 · CONFIGURAR · PRONTA |
| Rastreio | RF-08, RF-09 · RFN-07 · CAP-09.2 · 04 §11.4 |

**Regras**: record-triggered Flow em `Alerta_Adesao__c` (criação com `Situacao__c=ATIVO`) que envia Custom Notification ao dono da Proposta e cria tarefa com a ação sugerida; Flow em `Adesao_Termo__c` para notificar mudança para `ASSINADO`.

**Critérios de aceite**: CA-SFC-05.1 — criação de alerta `ASSINANTES_INVALIDOS` gera notificação e tarefa para o dono da Proposta (teste de Flow).

---
## 5. Contratos de API

### 5.1 Visão geral e grau de certeza

| Contrato | Direção | Dono do contrato | O que é FATO de fonte | O que é PROPOSTA/HIPÓTESE | SPEC |
|---|---|---|---|---|---|
| API Adesão v1 | Salesforce → Axway externo → COMP-01 | Atacado (OHS/PL, R-01) | Salesforce só fala com o ARO [CG]; entrada Akamai → AppGW → Axway [stack] | Todo o contrato (caminhos, campos, códigos) — **[PROPOSTA]** a partir do 04 §11.1 | SPEC-API-01 |
| Callback GACD | GACD → Axway interno → COMP-02 | GACD (upstream; Atacado é Conformist + ACL, R-06) | Callback para endpoint informado no passo 1, quando a assinatura for concluída **[FATO: 04]** | Payload, estados, autenticação, retentativa — **[HIPÓTESE]**, a confirmar com o GACD (QA-TEC-07) | SPEC-API-02 |
| Alerta de Assinantes Inválidos v1 | Canal → Axway interno → COMP-02 | Atacado publica (OHS/PL, R-13), **a combinar com Canais** | Necessidade de comunicar o Gerente via serviço no ARO [CG] (RN-07) | Todo o contrato — **[PROPOSTA]** (04 §11.3) | SPEC-API-03 |
| Saída para o Salesforce | COMP-03 → Salesforce REST | Atacado (PL de status, R-02), conformado à API do Salesforce | API REST sObjects e upsert por External ID (plataforma) | Objetos e campos — **[PROPOSTA]** (QA-TEC-15) | SPEC-API-04 |
| FIRP | COMP-01 → Axway → FIRP | FIRP | Existência da consulta de representantes/poderes [CG]; **nenhuma documentação** | Todo o contrato — **[HIPÓTESE]** (QA-TEC-05) | SPEC-API-05 |
| GACD (3 chamadas) | COMP-01 → Axway → GACD | GACD | Nomes dos serviços, ordem, base64, usuário sistêmico no passo 2, `codigoProtocolo`, `IdPrevia`, `CaminhoPrevia`, callback **[FATO: 04]** | Campos, cabeçalhos, códigos de erro, APIs de consulta/cancelamento — **[HIPÓTESE]** (QA-TEC-06, QA-TEC-04) | SPEC-API-06 |
| IMPD | COMP-01 → IMPD | IMPD | Nome `impd-srv-doc-generator`, "disponível na Azure", resposta base64, template CSF Designer v21 **[FATO: 05, 06]** | Requisição, autenticação, rota — **[HIPÓTESE]**, a confirmar pelo Swagger (QA-TEC-01) | SPEC-API-07 |

Cabeçalhos comuns às APIs do Atacado: `Authorization`, `X-Correlation-ID` (opcional na entrada, sempre na resposta), `traceparent` (opcional), `Idempotency-Key` (obrigatória nos `POST` de comando). Erros: `application/problem+json` (SPEC-TRV-04).

### 5.2 SPEC-API-01 — API Adesão v1 (Salesforce → COMP-01)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · PRONTA (proposta completa para validação com o time de Salesforce do Atacado) |
| Rastreio | R-01 · RF-01, 05, 10, 11 · ADR-02, ADR-07 · 04 §11.1 |
| Entregável | `contratos/openapi/api-adesao-v1.yaml` aprovado e publicado no Axway (política `atacado-adesao-sf`) |

**Critérios de aceite**: CA-API-01.1 — YAML válido em OpenAPI 3.1 (lint sem erro); CA-API-01.2 — revisado e aprovado pelo time de Salesforce do Atacado; CA-API-01.3 — publicado no catálogo do Axway em Dev e Hom.

**OpenAPI 3.1 (resumido) — [PROPOSTA]**

```yaml
openapi: 3.1.0
info:
  title: API Adesão
  version: 1.0.0
  description: Comandos e consultas do Termo de Adesão multiproduto (OHS/PL R-01). Processamento assíncrono.
servers:
  - url: https://{host-externo}/atacado/adesao/v1   # Akamai -> AppGW -> Axway; serviço interno expõe /v1
security:
  - oauth2: [adesao.escrita]
    mtls: []
paths:
  /adesoes:
    post:
      operationId: solicitarAdesao
      summary: Solicita o Termo de Adesão da Proposta (SolicitarTermoAdesao)
      parameters: [ { $ref: '#/components/parameters/IdempotencyKey' }, { $ref: '#/components/parameters/CorrelationId' } ]
      requestBody:
        required: true
        content: { application/json: { schema: { $ref: '#/components/schemas/SolicitacaoAdesao' } } }
      responses:
        '202':
          description: Termo requerido; processamento assíncrono iniciado
          headers: { Location: { schema: { type: string } }, ETag: { schema: { type: string } } }
          content: { application/json: { schema: { $ref: '#/components/schemas/AdesaoAceita' } } }
        '200':
          description: Adesão dispensada (contrato vigente); nenhum termo criado
          content: { application/json: { schema: { $ref: '#/components/schemas/AdesaoDispensada' } } }
        '400': { $ref: '#/components/responses/Problema' }
        '409': { $ref: '#/components/responses/Problema' }   # ADESAO_NAO_TERMINAL_EXISTENTE | REQUISICAO_EM_PROCESSAMENTO
        '422': { $ref: '#/components/responses/Problema' }   # IDEMPOTENCY_KEY_REUTILIZADA
        '503': { $ref: '#/components/responses/Problema' }
    get:
      operationId: listarAdesoesDaProposta
      security: [ { oauth2: [adesao.leitura], mtls: [] } ]
      parameters: [ { name: idProposta, in: query, required: true, schema: { type: string, maxLength: 64 } } ]
      responses:
        '200': { content: { application/json: { schema: { type: array, items: { $ref: '#/components/schemas/AdesaoResumo' } } } } }
  /adesoes/{idAdesao}:
    get:
      operationId: consultarAdesao
      security: [ { oauth2: [adesao.leitura], mtls: [] } ]
      parameters: [ { $ref: '#/components/parameters/IdAdesao' } ]
      responses:
        '200':
          headers: { ETag: { schema: { type: string } } }
          content: { application/json: { schema: { $ref: '#/components/schemas/Adesao' } } }
        '404': { $ref: '#/components/responses/Problema' }
  /adesoes/{idAdesao}/documento:
    get:
      operationId: obterPrevia
      security: [ { oauth2: [adesao.leitura], mtls: [] } ]
      parameters: [ { $ref: '#/components/parameters/IdAdesao' } ]
      responses:
        '200':
          headers: { ETag: { description: SHA-256 do PDF, schema: { type: string } } }
          content: { application/pdf: { schema: { type: string, contentMediaType: application/pdf } } }
        '404': { $ref: '#/components/responses/Problema' }   # ADESAO_NAO_ENCONTRADA | DOCUMENTO_INDISPONIVEL
        '410': { $ref: '#/components/responses/Problema' }   # DOCUMENTO_EXPIRADO
  /adesoes/{idAdesao}/confirmacao-envio:
    post:
      operationId: confirmarEnvio
      parameters: [ { $ref: '#/components/parameters/IdAdesao' }, { $ref: '#/components/parameters/IdempotencyKey' }, { $ref: '#/components/parameters/IfMatch' } ]
      requestBody: { required: true, content: { application/json: { schema: { $ref: '#/components/schemas/ConfirmacaoEnvio' } } } }
      responses:
        '202': { content: { application/json: { schema: { $ref: '#/components/schemas/Adesao' } } } }
        '409': { $ref: '#/components/responses/Problema' }   # ESTADO_INCOMPATIVEL | DOCUMENTO_DIVERGENTE | CONFIRMACAO_DESABILITADA
        '412': { $ref: '#/components/responses/Problema' }   # VERSAO_DESATUALIZADA
  /adesoes/{idAdesao}/reemissao:
    post:
      operationId: reemitir
      parameters: [ { $ref: '#/components/parameters/IdAdesao' }, { $ref: '#/components/parameters/IdempotencyKey' }, { $ref: '#/components/parameters/IfMatch' } ]
      requestBody: { required: true, content: { application/json: { schema: { $ref: '#/components/schemas/Reemissao' } } } }
      responses:
        '202': { content: { application/json: { schema: { $ref: '#/components/schemas/Adesao' } } } }
        '409': { $ref: '#/components/responses/Problema' }
        '412': { $ref: '#/components/responses/Problema' }
  /adesoes/{idAdesao}/cancelamento:
    post:
      operationId: cancelar
      parameters: [ { $ref: '#/components/parameters/IdAdesao' }, { $ref: '#/components/parameters/IdempotencyKey' }, { $ref: '#/components/parameters/IfMatch' } ]
      requestBody: { required: true, content: { application/json: { schema: { $ref: '#/components/schemas/Cancelamento' } } } }
      responses:
        '202': { content: { application/json: { schema: { $ref: '#/components/schemas/Adesao' } } } }
        '409': { $ref: '#/components/responses/Problema' }
        '412': { $ref: '#/components/responses/Problema' }
components:
  securitySchemes:
    oauth2:
      type: oauth2
      flows:
        clientCredentials:
          tokenUrl: https://{emissor-corporativo}/oauth2/token   # LEAP ou OAuth do Axway (QA-TEC-03)
          scopes: { adesao.escrita: Comandos, adesao.leitura: Consultas e prévia }
    mtls: { type: mutualTLS }
  parameters:
    IdAdesao: { name: idAdesao, in: path, required: true, schema: { type: string, format: uuid } }
    IdempotencyKey: { name: Idempotency-Key, in: header, required: true, schema: { type: string, format: uuid } }
    IfMatch: { name: If-Match, in: header, required: false, description: Versão do agregado (ETag), schema: { type: string } }
    CorrelationId: { name: X-Correlation-ID, in: header, required: false, schema: { type: string, maxLength: 64, pattern: '^[A-Za-z0-9-]+$' } }
  responses:
    Problema:
      description: Erro (RFC 9457)
      content: { application/problem+json: { schema: { $ref: '#/components/schemas/Problema' } } }
  schemas:
    Cnpj: { type: string, pattern: '^[0-9A-Z]{12}[0-9]{2}$', description: 'Sem máscara; aceita formato alfanumérico (DT-19)' }
    Matricula: { type: string, maxLength: 20 }
    SolicitacaoAdesao:
      type: object
      required: [idProposta, cnpj, razaoSocial, produtos, matriculaGerente, propostaAprovada, indicadores]
      properties:
        idProposta: { type: string, maxLength: 64, description: 'Id do registro da Proposta no Salesforce (PRM-TEC-19)' }
        cnpj: { $ref: '#/components/schemas/Cnpj' }
        razaoSocial: { type: string, maxLength: 150 }
        produtos:
          type: array
          minItems: 1
          maxItems: 50
          items:
            type: object
            required: [codigoProduto]
            properties: { codigoProduto: { type: string, maxLength: 40 }, nomeProduto: { type: string, maxLength: 120 } }
        matriculaGerente: { $ref: '#/components/schemas/Matricula' }
        propostaAprovada: { type: boolean, const: true, description: 'RN-04: tarifas negociadas e aprovadas' }
        indicadores:
          type: object
          required: [possuiContratoVigente, possuiAcessoCanalDigital]
          description: 'Fonte provisória da elegibilidade (PRM-TEC-10)'
          properties:
            possuiContratoVigente: { type: boolean }
            possuiAcessoCanalDigital: { type: boolean }
            referenciaContratoVigente: { type: [string, 'null'], maxLength: 64 }
    AdesaoAceita:
      type: object
      required: [resultado, idAdesao, status, tipoTermo, versao]
      properties:
        resultado: { const: TERMO_REQUERIDO }
        idAdesao: { type: string, format: uuid }
        status: { $ref: '#/components/schemas/StatusTermo' }
        tipoTermo: { $ref: '#/components/schemas/TipoTermo' }
        versao: { type: integer }
    AdesaoDispensada:
      type: object
      required: [resultado, idDecisao, idProposta]
      properties:
        resultado: { const: ADESAO_DISPENSADA }
        idDecisao: { type: string, format: uuid }
        idProposta: { type: string }
    StatusTermo:
      type: string
      description: 'Estados canônicos; clientes devem tolerar valores novos'
      enum: [SOLICITADO, ASSINANTES_IDENTIFICADOS, GERADO, AGUARDANDO_ASSINATURA, ASSINANTES_INVALIDOS, ASSINADO, FALHA_NA_GERACAO, ENCERRADO]
    TipoTermo: { type: string, enum: [PRODUTOS, PRODUTOS_CANAL] }
    AdesaoResumo:
      type: object
      properties:
        idAdesao: { type: string, format: uuid }
        status: { $ref: '#/components/schemas/StatusTermo' }
        tentativa: { type: integer }
        criadoEm: { type: string, format: date-time }
    Adesao:
      type: object
      required: [idAdesao, idProposta, cnpj, tipoTermo, status, tentativa, versao]
      properties:
        idAdesao: { type: string, format: uuid }
        idProposta: { type: string }
        cnpj: { $ref: '#/components/schemas/Cnpj' }
        tipoTermo: { $ref: '#/components/schemas/TipoTermo' }
        status: { $ref: '#/components/schemas/StatusTermo' }
        tentativa: { type: integer, minimum: 1 }
        versao: { type: integer }
        envioConfirmado: { type: boolean }
        confirmadoEm: { type: [string, 'null'], format: date-time }
        produtos: { type: array, items: { type: object, properties: { codigoProduto: { type: string }, nomeProduto: { type: string } } } }
        assinantes:
          type: array
          description: 'Tentativa corrente; dado pessoal mínimo (id FIRP, nome, papel)'
          items: { type: object, properties: { idRepresentante: { type: string }, nome: { type: string }, papel: { type: string }, formaAssinatura: { type: string, enum: [ISOLADA, CONJUNTA] } } }
        documento:
          type: [object, 'null']
          properties: { versaoModelo: { type: string }, hashSha256: { type: string, pattern: '^[0-9a-f]{64}$' }, tamanhoBytes: { type: integer }, geradoEm: { type: string, format: date-time } }
        protocolo:
          type: [object, 'null']
          properties: { codigoProtocolo: { type: string }, abertoEm: { type: string, format: date-time } }
        falha:
          type: [object, 'null']
          properties: { etapa: { type: string, enum: [FIRP, DOCUMENTO, GACD] }, codigo: { type: string }, reprocessavel: { type: boolean } }
        encerramento:
          type: [object, 'null']
          properties: { motivo: { type: string, enum: [RECUSADO, EXPIRADO, CANCELADO] }, encerradoEm: { type: string, format: date-time } }
        criadoEm: { type: string, format: date-time }
        atualizadoEm: { type: string, format: date-time }
    ConfirmacaoEnvio:
      type: object
      required: [matriculaGerente, hashDocumento]
      properties:
        matriculaGerente: { $ref: '#/components/schemas/Matricula' }
        hashDocumento: { type: string, pattern: '^[0-9a-f]{64}$', description: 'SHA-256 do PDF exibido na prévia' }
    Reemissao:
      type: object
      required: [matriculaGerente, motivo]
      properties:
        matriculaGerente: { $ref: '#/components/schemas/Matricula' }
        motivo: { type: string, enum: [REGULARIZACAO_ASSINANTES, FALHA_TECNICA, OUTRO] }
    Cancelamento:
      type: object
      required: [matriculaGerente, motivo]
      properties:
        matriculaGerente: { $ref: '#/components/schemas/Matricula' }
        motivo: { type: string, enum: [PROPOSTA_ALTERADA, DESISTENCIA_CLIENTE, ERRO_OPERACIONAL, OUTRO] }
    Problema:
      type: object
      required: [type, title, status, codigo]
      properties:
        type: { type: string, format: uri }
        title: { type: string }
        status: { type: integer }
        detail: { type: string }
        instance: { type: string }
        codigo: { type: string }
        correlationId: { type: string }
        estadoAtual: { $ref: '#/components/schemas/StatusTermo' }
        idAdesaoExistente: { type: string, format: uuid }
        erros: { type: array, items: { type: object, properties: { campo: { type: string }, mensagem: { type: string } } } }
```

**Exemplo — `POST /v1/adesoes`**

```http
POST /atacado/adesao/v1/adesoes
Authorization: Bearer <token>
Idempotency-Key: 7d3f2c9e-1b4a-4f7e-9a0c-5e2b8d1f6a33
X-Correlation-ID: 0f9d6c1e-2c1f-4a41-8f0c-6a3e0d6c9b11
Content-Type: application/json

{ "idProposta": "a0X5g00000ABCDEFGH", "cnpj": "11222333000181", "razaoSocial": "EMPRESA EXEMPLO LTDA",
  "produtos": [ { "codigoProduto": "PAG-FORNECEDORES", "nomeProduto": "Pagamento a Fornecedores" },
                { "codigoProduto": "COBRANCA", "nomeProduto": "Cobrança" } ],
  "matriculaGerente": "M1234567", "propostaAprovada": true,
  "indicadores": { "possuiContratoVigente": false, "possuiAcessoCanalDigital": true } }
```

```http
HTTP/1.1 202 Accepted
Location: /atacado/adesao/v1/adesoes/5b7c2f0e-8f1d-4d2b-9a55-0c1e2f3a4b5c
ETag: "1"
X-Correlation-ID: 0f9d6c1e-2c1f-4a41-8f0c-6a3e0d6c9b11

{ "resultado": "TERMO_REQUERIDO", "idAdesao": "5b7c2f0e-8f1d-4d2b-9a55-0c1e2f3a4b5c",
  "status": "SOLICITADO", "tipoTermo": "PRODUTOS", "versao": 1 }
```

### 5.3 SPEC-API-02 — Callback GACD (GACD → COMP-02)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · **BLOQUEADA** (QA-TEC-07) |
| Rastreio | R-06 · RF-07 · ADR-08 · RSK-03 · 04 §11.2 |
| Entregável | Contrato do GACD recebido e registrado em `contratos/externos/gacd-callback.*`; tabela de mapeamento situação → `tipo_sinal` aprovada; `contratos/openapi/callback-gacd-v1.yaml` do lado do Atacado |

| Item | Valor | Grau |
|---|---|---|
| Quando o GACD chama | Quando a assinatura for concluída | **[FATO: 04]** |
| Para onde | Endpoint informado no passo 1 (Coordenar Contrato) | **[FATO: 04]** |
| URL registrada | `https://<axway-interno>/atacado/adesao/v1/callbacks/gacd/assinaturas/{idAdesao}` | [PROPOSTA] (04 §11.2) |
| Método / formato | `POST`, `application/json` | [HIPÓTESE] |
| Autenticação | mTLS ou token do GACD, validado no Axway (política `atacado-adesao-callback-gacd`) | [HIPÓTESE] (QA-TEC-07) |
| Outros estados | Recusa, expiração, cancelamento, assinatura parcial | [HIPÓTESE] (QA-TEC-07, QA-DDD-03) |
| Retentativa do GACD | Backoff por ≥ 24 h até receber 2xx | Expectativa do Atacado (04 §11.2) |

**Payload hipotético — "a confirmar com GACD"**

```json
{
  "codigoProtocolo": "<codigoProtocolo>",
  "situacao": "ASSINADO",
  "dataHoraEvento": "2026-09-30T10:15:00-03:00",
  "idEventoGacd": "<id único da notificação, se existir>"
}
```

**Tradução (ACL, configurável em `adesao.receptor.gacd.mapa-situacao`)**

| `situacao` GACD (hipótese) | `tipo_sinal` canônico | Evento de domínio resultante (COMP-01) |
|---|---|---|
| `ASSINADO` / `CONCLUIDO` | `ASSINATURA_CONCLUIDA` | `AssinaturaConcluida` |
| `RECUSADO` | `RECUSADO` | `TermoEncerrado{RECUSADO}` |
| `EXPIRADO` | `EXPIRADO` | `TermoEncerrado{EXPIRADO}` |
| `ASSINANTES_INVALIDOS` (alternativa DEC-CON-06 b) | `ASSINANTES_INVALIDOS` | `AssinantesInvalidados` |
| `PARCIAL` / outro | `DESCONHECIDO` | nenhum (quarentena) |

**Respostas do COMP-02**: `200` (vazio) após commit, inclusive duplicado; `400` só para JSON inválido ou sem `codigoProtocolo`; `401`/`403` (Axway ou identidade); `413` acima de 256 KB; `503` com banco indisponível. Nunca `404` para protocolo desconhecido.

### 5.4 SPEC-API-03 — Alerta de Assinantes Inválidos v1 (Canal → COMP-02)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · **BLOQUEADA** (QA-TEC-08) — **a combinar com Canais** |
| Rastreio | R-13 · RF-08 · RN-06, RN-07 · CAP-09.5 · ADR-09 · QA-DDD-08 · RSK-06 · 04 §11.3 |
| Entregável | `contratos/openapi/alerta-assinantes-invalidos-v1.yaml` aceito pelo Time de Canais; política `atacado-adesao-alerta-canal` publicada |

**Contrato proposto (sem dado pessoal)**

```yaml
openapi: 3.1.0
info: { title: Alerta de Assinantes Inválidos, version: 1.0.0 }
servers: [ { url: 'https://{axway-interno}/atacado/adesao/v1' } ]
paths:
  /alertas/assinantes-invalidos:
    post:
      operationId: registrarAlerta
      parameters:
        - { name: Idempotency-Key, in: header, required: true, schema: { type: string, format: uuid }, description: 'Igual a idNotificacao' }
        - { name: X-Correlation-ID, in: header, required: false, schema: { type: string, maxLength: 64 } }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [idNotificacao, codigoProtocolo, cnpj, motivo, quantidadeAssinantesInvalidos, detectadoEm, canalOrigem]
              properties:
                idNotificacao: { type: string, format: uuid, description: 'Estável nas retentativas' }
                codigoProtocolo: { type: string, maxLength: 64 }
                cnpj: { type: string, pattern: '^[0-9A-Z]{12}[0-9]{2}$' }
                motivo: { type: string, enum: [PODERES_REVOGADOS, REPRESENTANTE_DESLIGADO, VIGENCIA_EXPIRADA, REGRA_ASSINATURA_NAO_ATENDIDA, OUTRO] }
                quantidadeAssinantesInvalidos: { type: integer, minimum: 1, maximum: 50 }
                detectadoEm: { type: string, format: date-time }
                canalOrigem: { type: string, enum: [PDPJ, BGS, CANAL_UNIFICADO] }
                acaoTomadaNoCanal: { type: string, enum: [ASSINATURA_BLOQUEADA] }
      responses:
        '202':
          content: { application/json: { schema: { type: object, properties: { idAlerta: { type: string, format: uuid }, situacao: { const: RECEBIDO } } } } }
        '400': { description: Esquema inválido (problem+json) }
        '401': { description: Axway }
        '403': { description: Identidade não autorizada }
        '429': { description: Rate limit; respeitar Retry-After }
        '503': { description: Indisponível; retentar com backoff por até 24 h }
  /alertas/{idNotificacao}:
    get:
      operationId: consultarAlerta
      parameters: [ { name: idNotificacao, in: path, required: true, schema: { type: string, format: uuid } } ]
      responses:
        '200':
          content:
            application/json:
              schema:
                type: object
                properties:
                  idAlerta: { type: string, format: uuid }
                  situacao: { type: string, enum: [RECEBIDO, APLICADO, REJEITADO] }
                  motivoRejeicao: { type: [string, 'null'], enum: [PROTOCOLO_NAO_VIGENTE, ESTADO_INCOMPATIVEL, PROTOCOLO_DESCONHECIDO, null] }
        '404': { description: Não encontrado }
```

**Responsabilidades propostas ao Canal** (04 §11.3): revalidar na FIRP antes de liberar a assinatura (RN-06); bloquear e informar o cliente sem expor dados de terceiros; chamar a API uma vez por detecção, com `idNotificacao` estável; retentar em 5xx/timeout; não cancelar o protocolo no GACD por conta própria; não chamar o Salesforce (PRI-01).

### 5.5 SPEC-API-04 — Contrato de saída para o Salesforce (upsert)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · PARCIAL (QA-TEC-15) |
| Rastreio | R-02 · RF-09 · ADR-06 · [DT-12] · 04 §11.4 |
| Entregável | Especificação de objetos/campos aprovada pelo time Salesforce do Atacado; metadados versionados no repositório Salesforce |

**`Adesao_Termo__c`** — `PATCH /services/data/{versao}/sobjects/Adesao_Termo__c/Id_Adesao__c/{idAdesao}`

| Campo (API name) | Tipo | Origem | Observação |
|---|---|---|---|
| `Id_Adesao__c` | Texto(36), External ID, único | `idAdesao` (ou `idDecisao` na dispensa) | Chave do upsert (na URL) |
| `Proposta__c` | Lookup(Proposta) | `idProposta` | PRM-TEC-19 |
| `Status_Termo__c` | Picklist | Estado canônico ou vazio (dispensa) | Valores da seção 7 |
| `Status_Jornada__c` | Picklist | `status_jornada` | `NAO_REQUERIDO`, `TERMO_EM_ANDAMENTO`, `TERMO_ASSINADO`, `ENCERRADA` (+ reservados: `EM_IMPLANTACAO`, `CONVENIO_ATIVO`, `TARIFAS_CADASTRADAS`, `CONVENIO_PENDENTE` — SPEC-ACP-02) |
| `Tipo_Termo__c` | Picklist | `tipoTermo` | `PRODUTOS`, `PRODUTOS_CANAL` |
| `Tentativa__c` | Número(3,0) | `tentativa` | |
| `Codigo_Protocolo__c` | Texto(64) | `codigoProtocolo` | Chave de correlação de negócio |
| `Motivo_Falha__c` | Picklist | `FIRP`, `DOCUMENTO`, `GACD` + código | |
| `Falha_Reprocessavel__c` | Checkbox | `reprocessavel` | |
| `Motivo_Encerramento__c` | Picklist | `RECUSADO`, `EXPIRADO`, `CANCELADO` | |
| `Versao_Modelo__c` | Texto(20) | `versaoModelo` | Evidência exibível |
| `Quantidade_Assinantes__c` | Número(3,0) | contagem | Sem dado pessoal |
| `Resumo_Assinantes__c` | Texto longo | nome e papel | **Só** com `acompanhamento.entrega.resumo-assinantes.habilitado=true` (QA-TEC-15) |
| `Versao_Evento__c` | Número(18,0) | `versaoAgregado` | Regra defensiva [DT-12] |
| `Atualizado_Em__c` | Data/hora | `ocorridoEm` do evento | |
| `Correlation_Id__c` | Texto(64) | `correlationId` | Suporte |

```json
{ "Proposta__c": "a0X5g00000ABCDEFGH", "Status_Termo__c": "AGUARDANDO_ASSINATURA",
  "Status_Jornada__c": "TERMO_EM_ANDAMENTO", "Tipo_Termo__c": "PRODUTOS", "Tentativa__c": 1,
  "Codigo_Protocolo__c": "<codigoProtocolo>", "Versao_Modelo__c": "1.0.0", "Quantidade_Assinantes__c": 2,
  "Versao_Evento__c": 5, "Atualizado_Em__c": "2026-09-24T14:05:12Z", "Correlation_Id__c": "0f9d6c1e-..." }
```

**`Alerta_Adesao__c`** — `PATCH /services/data/{versao}/sobjects/Alerta_Adesao__c/Id_Alerta__c/{idAlerta}`

| Campo | Tipo | Observação |
|---|---|---|
| `Id_Alerta__c` | Texto(36), External ID, único | Chave |
| `Adesao_Termo__r` | Relacionamento por External ID | `{"Id_Adesao__c": "<idAdesao>"}` — evita consulta prévia do Id |
| `Tipo__c` | Picklist | `ASSINANTES_INVALIDOS`, `FALHA_GERACAO`, `PENDENCIA_PROLONGADA` (+ `FALHA_CONVENIO` reservado) |
| `Motivo__c` | Picklist | Enum do alerta do Canal ou etapa de falha (sem texto livre) |
| `Acao_Sugerida__c` | Picklist | `REGULARIZAR_E_REEMITIR`, `REEMITIR`, `ACOMPANHAR_CLIENTE` |
| `Situacao__c` | Picklist | `ATIVO`, `RESOLVIDO` |
| `Criado_Em__c` / `Resolvido_Em__c` | Data/hora | |

Respostas esperadas: `201` (criado), `200`/`204` (atualizado). Erros: ver SPEC-ACP-03.

### 5.6 SPEC-API-05 — Contrato de consumo FIRP (hipotético)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · **BLOQUEADA** (QA-TEC-05; relacionadas QA-TEC-03, QA-DDD-04, QA-NEG-03) |
| Rastreio | R-04 · RF-03 · N-02 · RSK-07 |
| Entregável | Contrato da FIRP (OpenAPI/Swagger) obtido e registrado em `contratos/externos/firp.*`; stubs WireMock atualizados; tabela de tradução aprovada |

Toda a tabela é **[HIPÓTESE]**, usada só para destravar o desenvolvimento com simulador. Não há fonte documental da FIRP (00-log).

| Item | Hipótese de trabalho |
|---|---|
| Rota | `GET https://<axway-interno>/firp/v1/empresas/{cnpj}/representantes?finalidade=ASSINATURA_CONTRATO` |
| Autenticação | `Authorization: Bearer <token de workload>` (LEAP **[HIPÓTESE]**) |
| Resposta 200 | `[{ idRepresentante, nome, cpf, cargo, poderes: [{ codigo, descricao, vigenciaInicio, vigenciaFim, formaAssinatura: ISOLADA ou CONJUNTA, quantidadeMinima }] }]` |
| 404 | Empresa sem representantes cadastrados |
| Tradução para `Assinante` | `idRepresentante` → `IdRepresentanteFirp`; `nome` → `nome`; `cargo` → `papel`; `formaAssinatura` do poder aplicável → `formaAssinatura`; **CPF e demais campos descartados** |
| A confirmar | Regras de assinatura conjunta e quantidade mínima (QA-NEG-03); se o GACD já resolve assinantes (QA-DDD-04); SLA e ambiente de Hom (QA-TEC-05) |

### 5.7 SPEC-API-06 — Contratos de consumo GACD (3 chamadas + opcionais)

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · **BLOQUEADA** (QA-TEC-06, QA-TEC-04, QA-TEC-24; onboarding QA-NEG-19) |
| Rastreio | R-05 · RF-06 · RN-08, RN-15 · RST-07 · N-03 · RSK-03, RSK-04 |
| Entregável | Contratos das 3 APIs (e de consulta/cancelamento, se existirem) em `contratos/externos/gacd-*.*`; nomes oficiais confirmados; formato do usuário sistêmico; stubs atualizados |

| Passo | Serviço **[FATO: 04]** | Entrada **[FATO: 04]** | Saída **[FATO: 04]** | Detalhe **[HIPÓTESE]** a confirmar |
|---|---|---|---|---|
| 1 Coordenar Contrato | `gacd-srv-coordenar-ass-sformatador` (grafia alternativa na mesma fonte: `gacd-srv-coordenador-ass-sformatador`) | Dados do contrato, assinantes e endpoint do callback | `codigoProtocolo` | `POST`; `{ referenciaExterna: "{idAdesao}-{tentativa}", produtoConsumidor: "<id do Atacado no GACD>", documento: { tipo, descricao, cnpj, razaoSocial }, assinantes: [{ identificador, nome, papel, formaAssinatura }], callbackUrl }`; identificador do assinante (id FIRP ou CPF) em **QA-TEC-24**; aceita referência externa para idempotência? (QA-TEC-06) |
| 2 Armazenar Prévia | `cgcc_conteudo_gacd/rest/v1/conteudo/armazenar` (grafia alternativa: `cgcc-conteudo-gacd`) | base64 do documento; **usuário sistêmico** | `IdPrevia`, `CaminhoPrevia` (armazenamento no GCC/Filenet) | `POST`; `{ codigoProtocolo, nomeArquivo: "termo-{idAdesao}-t{n}.pdf", tipoConteudo: "application/pdf", conteudoBase64 }`; formato da credencial do usuário sistêmico (cabeçalho, basic, certificado) em **QA-TEC-04**; limite de tamanho (QA-TEC-10) |
| 3 Coordenar Regra | `gacd-srv-coordenar-regra` | (verificar que prévia e regras foram armazenadas) | Confirmação | `POST`; `{ codigoProtocolo, idPrevia }`; forma de expressar assinatura conjunta? |
| Consulta de protocolo | Não citada na fonte | — | — | Existe? Por `codigoProtocolo` e por referência externa? (QA-TEC-06) — habilita confirmação ativa e reconciliação |
| Cancelamento de protocolo | Não citado na fonte | — | — | Existe? (QA-TEC-06, QA-DDD-02) — habilita compensação e cancelamento |

Erros esperados (hipótese): `400` validação (PERMANENTE), `401/403` credencial (PERMANENTE com releitura), `409` duplicidade (reconciliar), `5xx`/timeout (TRANSITORIA; INCERTA no passo 1).

### 5.8 SPEC-API-07 — Contrato de consumo IMPD

| Campo | Conteúdo |
|---|---|
| Classe / prontidão | ACORDAR · **BLOQUEADA** (QA-TEC-01, QA-TEC-02) — faz parte do gate do ADR-03 |
| Rastreio | R-10 · RF-04 · N-04 · RSK-01, RSK-02 |
| Entregável | Swagger do `impd-srv-doc-generator` obtido (link citado em [06]); rota, autenticação e SLA confirmados; template-piloto publicado em AL2 (Dev) |

| Item | Valor | Grau |
|---|---|---|
| Serviço | `impd-srv-doc-generator`, API cloud "disponível na Azure", recomendada em vez do mainframe | **[FATO: 06]** |
| Saída | Texto **base64** conversível em PDF | **[FATO: 05, 06]** |
| Templates | CSF Designer v21; criados e mantidos pela área consumidora; esteira GitHub → Sandbox/Dev (AL2) → Hom (CM2) → Prod (MZ) com RDM | **[FATO: 05, 06]** |
| Requisição | `POST …/documentos` com `{ template: "<id CSF>", versao, dados: { …variáveis… } }` | [HIPÓTESE] |
| Autenticação e rota | Direta por peering/private endpoint ou via Axway | [ABERTO: QA-TEC-01] |
| Ambientes | AL2 (Dev), CM2 (Hom), MZ (Prod) mapeados aos ambientes do ARO | **[FATO: 06]** (nomes) / [PROPOSTA] (mapeamento) |

---
## 6. Modelo de dados físico (PostgreSQL 16)

### 6.1 Organização e correspondência de nomes

- Um schema por BC (03 §8.2), sem FK nem join entre schemas; relações entre schemas são lógicas.
- Nomes físicos seguem o 04 §10 e o 04a (COMP-04). Os nomes genéricos pedidos para esta especificação correspondem a:

| Nome genérico | Tabela física | Situação |
|---|---|---|
| `adesao` | `adesao_termo.adesao_termo` | Do 04 |
| `adesao_assinante` | `adesao_termo.assinante` | Do 04 |
| `adesao_produto` | `adesao_termo.produto_aderido` | **Nova** (o 04a não tinha tabela para `ProdutoAderido` do 03) |
| `saga_gacd` / passos | `adesao_termo.saga_envio_assinatura` / `adesao_termo.saga_envio_assinatura_passo` | Do 04 / **nova** (histórico por passo) |
| `outbox` | `adesao_termo.outbox_evento` | Do 04 (colunas completadas) |
| `inbox` | `adesao_entrada.sinal_externo` | Do 04 |
| auditoria | `adesao_termo.trilha_auditoria` | Do 04 (particionada, [DT-11]) |
| erros/reprocessamento | `adesao_termo.reconciliacao_manual`, `adesao_termo.tarefa`, `adesao_acompanhamento.entrega_status` (+ situações `QUARENTENA`/`ESTACIONADO`) | Do 04 / **nova** (`tarefa`, [DT-05]) |
| idempotência de API | `adesao_termo.requisicao_idempotente` | **Nova** ([DT-06]) |
| decisão de elegibilidade | `adesao_termo.decisao_elegibilidade` | **Nova** (dispensa sem agregado) |

Mapeamento das colunas genéricas da outbox: `id` → `id_evento`; `aggregate_id` → `id_agregado`; `event_type` → `tipo_evento`; `payload jsonb` → `payload`; `status` → `situacao`; `attempts` → `tentativas`; `next_attempt_at` → `proxima_tentativa_em`; `created_at` → `criado_em`. Inbox: `message_id unique` → `(origem, chave_idempotencia)` único; `source` → `origem`; `payload` → `dados` (traduzido) + `hash_payload_bruto` + `payload_bruto` opcional; `processed_at` → `processado_em`.

### 6.2 DDL proposto (Flyway)

```sql
-- V202610010900__schemas.sql  (role adesao_migracao)
CREATE SCHEMA IF NOT EXISTS adesao_termo;
CREATE SCHEMA IF NOT EXISTS termo_documento;
CREATE SCHEMA IF NOT EXISTS adesao_entrada;
CREATE SCHEMA IF NOT EXISTS adesao_acompanhamento;

-- ============ BC-01: adesao_termo ============
-- V202610010901__adesao_termo.sql
CREATE TABLE adesao_termo.decisao_elegibilidade (
  id_decisao              uuid         PRIMARY KEY,
  id_proposta             varchar(64)  NOT NULL,
  cnpj                    varchar(14)  NOT NULL CHECK (cnpj ~ '^[0-9A-Z]{12}[0-9]{2}$'),
  resultado               varchar(20)  NOT NULL CHECK (resultado IN ('REQUERIDA','DISPENSADA')),
  tipo_termo              varchar(20)  CHECK (tipo_termo IN ('PRODUTOS','PRODUTOS_CANAL')),
  origem                  varchar(30)  NOT NULL,             -- SALESFORCE (PRM-TEC-10) | REGISTRO_CONTRATOS
  indicadores             jsonb        NOT NULL,
  referencia_contrato     varchar(64),
  matricula_solicitante   varchar(20)  NOT NULL,
  decidido_em             timestamptz  NOT NULL DEFAULT now()
);
CREATE INDEX ix_decisao_proposta ON adesao_termo.decisao_elegibilidade (id_proposta);

CREATE TABLE adesao_termo.adesao_termo (
  id_adesao               uuid         PRIMARY KEY,
  id_proposta             varchar(64)  NOT NULL,
  id_decisao              uuid         NOT NULL REFERENCES adesao_termo.decisao_elegibilidade (id_decisao),
  cnpj                    varchar(14)  NOT NULL CHECK (cnpj ~ '^[0-9A-Z]{12}[0-9]{2}$'),
  razao_social            varchar(150) NOT NULL,
  tipo_termo              varchar(20)  NOT NULL CHECK (tipo_termo IN ('PRODUTOS','PRODUTOS_CANAL')),
  status                  varchar(30)  NOT NULL CHECK (status IN ('SOLICITADO','ASSINANTES_IDENTIFICADOS','GERADO',
                              'AGUARDANDO_ASSINATURA','ASSINANTES_INVALIDOS','ASSINADO','FALHA_NA_GERACAO','ENCERRADO')),
  tentativa               integer      NOT NULL DEFAULT 1 CHECK (tentativa >= 1),
  envio_confirmado_em     timestamptz,
  envio_confirmado_por    varchar(20),
  falha_etapa             varchar(20)  CHECK (falha_etapa IN ('FIRP','DOCUMENTO','GACD')),
  falha_codigo            varchar(60),
  falha_reprocessavel     boolean,
  motivo_encerramento     varchar(20)  CHECK (motivo_encerramento IN ('RECUSADO','EXPIRADO','CANCELADO')),
  motivo_cancelamento     varchar(30),
  matricula_solicitante   varchar(20)  NOT NULL,
  correlation_id          varchar(64),
  versao                  bigint       NOT NULL DEFAULT 1,
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  atualizado_em           timestamptz  NOT NULL DEFAULT now(),
  terminal_em             timestamptz,                         -- base da retenção
  CONSTRAINT ck_falha     CHECK ((status = 'FALHA_NA_GERACAO') = (falha_etapa IS NOT NULL)),
  CONSTRAINT ck_encerrado CHECK ((status = 'ENCERRADO') = (motivo_encerramento IS NOT NULL))
);
-- INV-01: no máximo uma adesão não terminal por CNPJ (unidade CNPJ × raiz em QA-NEG-16)
CREATE UNIQUE INDEX ux_adesao_cnpj_nao_terminal ON adesao_termo.adesao_termo (cnpj)
  WHERE status NOT IN ('ASSINADO','ENCERRADO');
CREATE INDEX ix_adesao_proposta ON adesao_termo.adesao_termo (id_proposta);
CREATE INDEX ix_adesao_status   ON adesao_termo.adesao_termo (status, atualizado_em);

CREATE TABLE adesao_termo.produto_aderido (
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  codigo_produto          varchar(40)  NOT NULL,
  nome_produto            varchar(120),
  PRIMARY KEY (id_adesao, codigo_produto)
);

CREATE TABLE adesao_termo.assinante (                       -- dado pessoal mínimo (PRM-DDD-08); sem CPF
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  tentativa               integer      NOT NULL,
  ordem                   smallint     NOT NULL,
  id_representante_firp   varchar(64)  NOT NULL,
  nome                    varchar(150) NOT NULL,             -- anonimizado pela retenção (6.4)
  papel                   varchar(60)  NOT NULL,
  forma_assinatura        varchar(10)  CHECK (forma_assinatura IN ('ISOLADA','CONJUNTA')),
  anonimizado_em          timestamptz,
  UNIQUE (id_adesao, tentativa, id_representante_firp)
);

CREATE TABLE adesao_termo.documento_termo (
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  tentativa               integer      NOT NULL,
  id_modelo               varchar(60)  NOT NULL,
  versao_modelo           varchar(20)  NOT NULL,
  renderizador            varchar(10)  NOT NULL CHECK (renderizador IN ('IMPD','PROPRIO')),
  hash_sha256             char(64)     NOT NULL CHECK (hash_sha256 ~ '^[0-9a-f]{64}$'),
  tamanho_bytes           integer      NOT NULL CHECK (tamanho_bytes > 0),
  ref_blob                varchar(300),                        -- {idAdesao}/{tentativa}/termo.pdf
  conteudo                bytea,                               -- só no modo 'bytea' (ADR-04 b)
  gerado_em               timestamptz  NOT NULL,
  removido_staging_em     timestamptz,
  UNIQUE (id_adesao, tentativa),
  CONSTRAINT ck_local CHECK (ref_blob IS NOT NULL OR conteudo IS NOT NULL OR removido_staging_em IS NOT NULL)
);

CREATE TABLE adesao_termo.protocolo_assinatura (
  codigo_protocolo        varchar(64)  PRIMARY KEY,
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  tentativa               integer      NOT NULL,
  id_previa               varchar(128),
  caminho_previa          varchar(512),
  situacao                varchar(20)  NOT NULL CHECK (situacao IN ('ABERTO','VIGENTE','SUBSTITUIDO','CANCELADO','ORFAO','ENCERRADO')),
  aberto_em               timestamptz  NOT NULL,
  atualizado_em           timestamptz  NOT NULL
);
-- ABERTO = passo 1 concluído; VIGENTE = passo 3 concluído (Aguardando assinatura); INV-07 usa VIGENTE
CREATE UNIQUE INDEX ux_protocolo_ativo_por_adesao ON adesao_termo.protocolo_assinatura (id_adesao)
  WHERE situacao IN ('ABERTO','VIGENTE');

CREATE TABLE adesao_termo.saga_envio_assinatura (
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  tentativa               integer      NOT NULL,
  etapa                   varchar(30)  NOT NULL CHECK (etapa IN ('COORDENAR_CONTRATO','ARMAZENAR_PREVIA','COORDENAR_REGRA','COMPENSACAO','FIM')),
  estado                  varchar(30)  NOT NULL CHECK (estado IN ('PENDENTE','EM_EXECUCAO','AGUARDANDO_RETENTATIVA',
                              'RESULTADO_INCERTO','COMPENSANDO','CONCLUIDA','FALHOU')),
  codigo_protocolo        varchar(64),
  id_previa               varchar(128),
  caminho_previa          varchar(512),
  tentativas_etapa        integer      NOT NULL DEFAULT 0,
  proxima_execucao_em     timestamptz,
  prazo_limite_em         timestamptz  NOT NULL,              -- início da etapa + 2 h
  bloqueado_ate           timestamptz,                        -- lease
  executor                varchar(100),
  ultimo_erro_codigo      varchar(60),
  ultimo_erro_detalhe     varchar(500),                       -- sem dado pessoal
  iniciada_em             timestamptz  NOT NULL,
  concluida_em            timestamptz,
  versao                  bigint       NOT NULL DEFAULT 1,
  UNIQUE (id_adesao, tentativa)
);
CREATE INDEX ix_saga_agendada ON adesao_termo.saga_envio_assinatura (proxima_execucao_em)
  WHERE estado IN ('PENDENTE','AGUARDANDO_RETENTATIVA','COMPENSANDO');

CREATE TABLE adesao_termo.saga_envio_assinatura_passo (
  id                      uuid         PRIMARY KEY,
  id_saga                 uuid         NOT NULL REFERENCES adesao_termo.saga_envio_assinatura (id),
  passo                   varchar(30)  NOT NULL,              -- COORDENAR_CONTRATO | ARMAZENAR_PREVIA | COORDENAR_REGRA | CONSULTAR | CANCELAR
  numero_tentativa        integer      NOT NULL,
  resultado               varchar(25)  NOT NULL CHECK (resultado IN ('SUCESSO','FALHA_TRANSITORIA','FALHA_PERMANENTE','INCERTO','NAO_SUPORTADO')),
  http_status             smallint,
  codigo_erro             varchar(60),
  duracao_ms              integer,
  iniciado_em             timestamptz  NOT NULL,
  correlation_id          varchar(64)
);
CREATE INDEX ix_passo_saga ON adesao_termo.saga_envio_assinatura_passo (id_saga, iniciado_em);

CREATE TABLE adesao_termo.tarefa (                          -- DT-05
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL REFERENCES adesao_termo.adesao_termo (id_adesao),
  tipo                    varchar(30)  NOT NULL CHECK (tipo IN ('IDENTIFICAR_ASSINANTES','GERAR_DOCUMENTO','EXECUTAR_SAGA','CANCELAR_PROTOCOLO','EXCLUIR_STAGING')),
  situacao                varchar(20)  NOT NULL CHECK (situacao IN ('PENDENTE','CONCLUIDA','FALHOU','CANCELADA')),
  parametros              jsonb        NOT NULL DEFAULT '{}',  -- ex.: codigoProtocolo, ref_blob
  versao_agregado_origem  bigint       NOT NULL,
  tentativas              integer      NOT NULL DEFAULT 0,
  proxima_execucao_em     timestamptz  NOT NULL DEFAULT now(),
  prazo_limite_em         timestamptz  NOT NULL,
  bloqueado_ate           timestamptz,
  executor                varchar(100),
  ultimo_erro             varchar(500),
  correlation_id          varchar(64),
  traceparent             varchar(60),
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  concluida_em            timestamptz
);
CREATE INDEX ix_tarefa_pendente ON adesao_termo.tarefa (proxima_execucao_em) WHERE situacao = 'PENDENTE';
CREATE UNIQUE INDEX ux_tarefa_ativa ON adesao_termo.tarefa (id_adesao, tipo) WHERE situacao = 'PENDENTE';

CREATE TABLE adesao_termo.outbox_evento (
  id_evento               uuid         PRIMARY KEY,           -- UUID v7
  tipo_agregado           varchar(40)  NOT NULL,              -- AdesaoTermo | DecisaoElegibilidade
  id_agregado             uuid         NOT NULL,
  versao_agregado         bigint       NOT NULL,
  tipo_evento             varchar(60)  NOT NULL,
  versao_schema           smallint     NOT NULL,
  payload                 jsonb        NOT NULL,
  id_proposta             varchar(64)  NOT NULL,
  correlation_id          varchar(64),
  chave_correlacao_negocio varchar(64) NOT NULL,              -- codigoProtocolo ou idAdesao (DT-08)
  causation_id            varchar(64),
  traceparent             varchar(60),
  situacao                varchar(15)  NOT NULL DEFAULT 'PENDENTE' CHECK (situacao IN ('PENDENTE','CONSUMIDO','ESTACIONADO')),
  tentativas              integer      NOT NULL DEFAULT 0,
  proxima_tentativa_em    timestamptz,
  ultimo_erro             varchar(500),
  ocorrido_em             timestamptz  NOT NULL,
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  consumido_em            timestamptz,
  UNIQUE (tipo_agregado, id_agregado, versao_agregado, tipo_evento, versao_schema)
);
CREATE INDEX ix_outbox_pendente ON adesao_termo.outbox_evento (id_agregado, versao_agregado) WHERE situacao = 'PENDENTE';
CREATE INDEX ix_outbox_consumido ON adesao_termo.outbox_evento (consumido_em) WHERE situacao = 'CONSUMIDO';

CREATE TABLE adesao_termo.reconciliacao_manual (
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL,
  codigo_protocolo        varchar(64),
  motivo                  varchar(30)  NOT NULL CHECK (motivo IN ('ORFAO','RESULTADO_INCERTO','CANCELAMENTO_PENDENTE','DOCUMENTO_ADULTERADO')),
  situacao                varchar(15)  NOT NULL CHECK (situacao IN ('ABERTO','RESOLVIDO')),
  detalhe                 varchar(500),
  resolucao               varchar(500),
  resolvido_por           varchar(20),
  aberto_em               timestamptz  NOT NULL DEFAULT now(),
  resolvido_em            timestamptz
);
CREATE INDEX ix_reconciliacao_aberta ON adesao_termo.reconciliacao_manual (aberto_em) WHERE situacao = 'ABERTO';

CREATE TABLE adesao_termo.requisicao_idempotente (           -- DT-06
  consumidor              varchar(100) NOT NULL,              -- client_id propagado pelo Axway
  chave                   uuid         NOT NULL,
  operacao                varchar(40)  NOT NULL,
  hash_requisicao         char(64)     NOT NULL,
  situacao                varchar(20)  NOT NULL CHECK (situacao IN ('EM_PROCESSAMENTO','CONCLUIDA')),
  status_http             smallint,
  corpo_resposta          jsonb,
  id_recurso              uuid,
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  expira_em               timestamptz  NOT NULL,              -- criado_em + 72 h
  PRIMARY KEY (consumidor, chave)
);
CREATE INDEX ix_idempotencia_expira ON adesao_termo.requisicao_idempotente (expira_em);

-- Auditoria append-only, particionada por mês (DT-11)
CREATE TABLE adesao_termo.trilha_auditoria (
  id_registro             uuid         NOT NULL,
  ocorrido_em             timestamptz  NOT NULL,
  id_adesao               uuid,
  id_proposta             varchar(64),
  codigo_protocolo        varchar(64),
  ator                    varchar(60)  NOT NULL,              -- matrícula ou identidade de sistema/operador
  tipo_ator               varchar(15)  NOT NULL CHECK (tipo_ator IN ('GERENTE','SISTEMA','GACD','CANAL','OPERACAO')),
  acao                    varchar(40)  NOT NULL,
  origem                  varchar(15)  NOT NULL CHECK (origem IN ('SALESFORCE','GACD','CANAL','OPERACAO','SISTEMA')),
  resultado               varchar(15)  NOT NULL CHECK (resultado IN ('SUCESSO','REJEITADO','IGNORADO','FALHA')),
  status_anterior         varchar(30),
  status_novo             varchar(30),
  versao_modelo           varchar(20),
  hash_documento          char(64),
  detalhe                 jsonb,                              -- sem dado pessoal
  correlation_id          varchar(64),
  PRIMARY KEY (id_registro, ocorrido_em)
) PARTITION BY RANGE (ocorrido_em);
CREATE TABLE adesao_termo.trilha_auditoria_202610 PARTITION OF adesao_termo.trilha_auditoria
  FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');         -- demais partições: CronJob da SPEC-DB-04
CREATE TABLE adesao_termo.trilha_auditoria_padrao PARTITION OF adesao_termo.trilha_auditoria DEFAULT;
CREATE INDEX ix_auditoria_adesao    ON adesao_termo.trilha_auditoria (id_adesao, ocorrido_em);
CREATE INDEX ix_auditoria_protocolo ON adesao_termo.trilha_auditoria (codigo_protocolo) WHERE codigo_protocolo IS NOT NULL;

CREATE FUNCTION adesao_termo.fn_auditoria_append_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'trilha_auditoria é append-only (operação % proibida)', TG_OP;
END; $$;
CREATE TRIGGER tg_auditoria_append_only BEFORE UPDATE OR DELETE ON adesao_termo.trilha_auditoria
  FOR EACH ROW EXECUTE FUNCTION adesao_termo.fn_auditoria_append_only();

CREATE TABLE adesao_termo.shedlock (
  name varchar(64) PRIMARY KEY, lock_until timestamptz NOT NULL, locked_at timestamptz NOT NULL, locked_by varchar(255) NOT NULL
);

-- ============ BC-02: termo_documento ============
-- V202610010902__termo_documento.sql
CREATE TABLE termo_documento.modelo_termo (
  id_modelo               varchar(60)  PRIMARY KEY,
  tipo_termo              varchar(20)  NOT NULL CHECK (tipo_termo IN ('PRODUTOS','PRODUTOS_CANAL')),
  versao                  varchar(20)  NOT NULL,
  renderizador            varchar(10)  NOT NULL CHECK (renderizador IN ('IMPD','PROPRIO')),
  referencia_template     varchar(200) NOT NULL,              -- id CSF (IMPD) ou caminho do HTML versionado
  status                  varchar(15)  NOT NULL CHECK (status IN ('RASCUNHO','VIGENTE','DESCONTINUADO')),
  vigencia_inicio         date,
  vigencia_fim            date,
  aprovado_por            varchar(60),
  aprovado_em             timestamptz,
  evidencia_aprovacao     varchar(300),                       -- link do PR/RDM
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  UNIQUE (tipo_termo, versao, renderizador),
  CONSTRAINT ck_vigente_aprovado CHECK (status <> 'VIGENTE' OR (aprovado_por IS NOT NULL AND evidencia_aprovacao IS NOT NULL))
);
CREATE UNIQUE INDEX ux_modelo_vigente ON termo_documento.modelo_termo (tipo_termo, renderizador) WHERE status = 'VIGENTE';

-- ============ Borda BC-01: adesao_entrada ============
-- V202610010903__adesao_entrada.sql
CREATE TABLE adesao_entrada.sinal_externo (
  id                      uuid         PRIMARY KEY,
  origem                  varchar(10)  NOT NULL CHECK (origem IN ('GACD','CANAL')),
  chave_idempotencia      varchar(200) NOT NULL,              -- GACD:{protocolo}:{tipo} | CANAL:{protocolo}:{idNotificacao}
  tipo_sinal              varchar(30)  NOT NULL,              -- ASSINATURA_CONCLUIDA | ASSINANTES_INVALIDOS | RECUSADO | EXPIRADO | DESCONHECIDO
  codigo_protocolo        varchar(64)  NOT NULL,
  id_adesao_informado     uuid,                               -- do caminho da callbackUrl (redundância)
  id_notificacao          uuid,                               -- alerta do Canal
  cnpj                    varchar(14),
  dados                   jsonb        NOT NULL,              -- campos traduzidos pela ACL, sem dado pessoal
  hash_payload_bruto      char(64)     NOT NULL,
  payload_bruto           jsonb,                              -- só com a flag (QA-TEC-17)
  identidade_chamador     varchar(200) NOT NULL,
  versao_contrato         smallint     NOT NULL DEFAULT 1,
  situacao                varchar(15)  NOT NULL DEFAULT 'RECEBIDO' CHECK (situacao IN ('RECEBIDO','PROCESSADO','IGNORADO','QUARENTENA')),
  motivo_situacao         varchar(40),
  tentativas_processamento integer     NOT NULL DEFAULT 0,
  proxima_tentativa_em    timestamptz,
  correlation_id          varchar(64),
  traceparent             varchar(60),
  recebido_em             timestamptz  NOT NULL DEFAULT now(),
  processado_em           timestamptz,
  UNIQUE (origem, chave_idempotencia)
);
CREATE INDEX ix_sinal_recebido  ON adesao_entrada.sinal_externo (recebido_em) WHERE situacao = 'RECEBIDO';
CREATE INDEX ix_sinal_protocolo ON adesao_entrada.sinal_externo (codigo_protocolo);
CREATE UNIQUE INDEX ux_sinal_notificacao ON adesao_entrada.sinal_externo (id_notificacao) WHERE id_notificacao IS NOT NULL;

-- ============ BC-03: adesao_acompanhamento ============
-- V202610010904__adesao_acompanhamento.sql
CREATE TABLE adesao_acompanhamento.visao_jornada (
  id_adesao               uuid         PRIMARY KEY,           -- ou id_decisao na dispensa
  id_proposta             varchar(64)  NOT NULL,
  cnpj                    varchar(14)  NOT NULL,
  status_termo            varchar(30),
  status_jornada          varchar(30)  NOT NULL,
  tipo_termo              varchar(20),
  tentativa               integer,
  codigo_protocolo        varchar(64),
  falha_etapa             varchar(20),
  falha_codigo            varchar(60),
  motivo_encerramento     varchar(20),
  versao_modelo           varchar(20),
  quantidade_assinantes   smallint,
  ultima_versao_aplicada  bigint       NOT NULL,
  atualizado_em           timestamptz  NOT NULL
);
CREATE INDEX ix_visao_proposta ON adesao_acompanhamento.visao_jornada (id_proposta);

CREATE TABLE adesao_acompanhamento.alerta_gerente (
  id_alerta               uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL,
  id_proposta             varchar(64)  NOT NULL,
  tipo                    varchar(30)  NOT NULL CHECK (tipo IN ('ASSINANTES_INVALIDOS','FALHA_GERACAO','PENDENCIA_PROLONGADA','FALHA_CONVENIO')),
  motivo                  varchar(40),
  acao_sugerida           varchar(40)  NOT NULL,
  situacao                varchar(10)  NOT NULL CHECK (situacao IN ('ATIVO','RESOLVIDO')),
  id_evento_origem        uuid         NOT NULL UNIQUE,
  criado_em               timestamptz  NOT NULL,
  resolvido_em            timestamptz
);
CREATE INDEX ix_alerta_adesao_ativo ON adesao_acompanhamento.alerta_gerente (id_adesao) WHERE situacao = 'ATIVO';

CREATE TABLE adesao_acompanhamento.entrega_status (
  id                      uuid         PRIMARY KEY,
  id_adesao               uuid         NOT NULL,
  id_proposta             varchar(64)  NOT NULL,
  destino                 varchar(15)  NOT NULL DEFAULT 'SALESFORCE',
  tipo_objeto             varchar(20)  NOT NULL CHECK (tipo_objeto IN ('ADESAO_TERMO','ALERTA_ADESAO')),
  chave_externa           varchar(36)  NOT NULL,              -- Id_Adesao__c ou Id_Alerta__c
  versao_evento           bigint       NOT NULL,
  payload                 jsonb        NOT NULL,
  situacao                varchar(15)  NOT NULL CHECK (situacao IN ('PENDENTE','CONFIRMADA','ESTACIONADA','SUPERADA')),
  tentativas              integer      NOT NULL DEFAULT 0,
  proxima_tentativa_em    timestamptz  NOT NULL DEFAULT now(),
  prazo_limite_em         timestamptz  NOT NULL,              -- criação + 24 h
  ultimo_http_status      smallint,
  ultimo_erro             varchar(500),
  id_evento_origem        uuid         NOT NULL,
  criado_em               timestamptz  NOT NULL DEFAULT now(),
  confirmada_em           timestamptz,
  reentregue_por          varchar(20),
  reentregue_em           timestamptz
);
CREATE INDEX ix_entrega_pendente ON adesao_acompanhamento.entrega_status (id_adesao, criado_em) WHERE situacao = 'PENDENTE';
CREATE INDEX ix_entrega_estacionada ON adesao_acompanhamento.entrega_status (criado_em) WHERE situacao = 'ESTACIONADA';

CREATE TABLE adesao_acompanhamento.evento_consumido (
  id_evento               uuid         PRIMARY KEY,
  consumido_em            timestamptz  NOT NULL DEFAULT now()
);

CREATE TABLE adesao_acompanhamento.shedlock (
  name varchar(64) PRIMARY KEY, lock_until timestamptz NOT NULL, locked_at timestamptz NOT NULL, locked_by varchar(255) NOT NULL
);
```

### 6.3 Roles e privilégios (SPEC-DB-02)

Roles criadas por IaC/DBA (não por Flyway); grants em `R__grants.sql`.

| Role | Usada por | Privilégios |
|---|---|---|
| `adesao_migracao` | Job de migração | Dona de todos os objetos; `CREATE` nos schemas |
| `adesao_termo_app` | COMP-01 | `SELECT, INSERT, UPDATE` em `adesao_termo.*` e `termo_documento.modelo_termo` (só `SELECT`); **só `INSERT, SELECT`** em `trilha_auditoria`; `DELETE` só em `tarefa` e `requisicao_idempotente`; `SELECT, UPDATE (situacao, motivo_situacao, tentativas_processamento, proxima_tentativa_em, processado_em)` em `adesao_entrada.sinal_externo` |
| `adesao_receptor_app` | COMP-02 | `INSERT, SELECT` em `adesao_entrada.sinal_externo` |
| `adesao_acompanhamento_app` | COMP-03 | `SELECT` e `UPDATE (situacao, tentativas, proxima_tentativa_em, ultimo_erro, consumido_em)` em `adesao_termo.outbox_evento`; `SELECT, INSERT, UPDATE` em `adesao_acompanhamento.*` |
| `adesao_manutencao` | CronJob de retenção | Criação/remoção de partições de `trilha_auditoria`; `DELETE` nas tabelas operacionais vencidas; `UPDATE (nome, anonimizado_em)` em `assinante` |
| `adesao_leitura_ops` | Suporte (leitura) | `SELECT` em todas, exceto `assinante.nome` e `payload_bruto` (grant por coluna) |

### 6.4 Retenção proposta (a confirmar em QA-TEC-17)

| Estrutura | Retenção proposta [PROPOSTA] | Mecanismo |
|---|---|---|
| `adesao_termo`, filhos, `saga*`, `protocolo_assinatura`, `decisao_elegibilidade`, `reconciliacao_manual` | 5 anos após `terminal_em` | CronJob de expurgo |
| `assinante.nome` | Anonimizado (hash) 180 dias após `terminal_em` (a evidência fica no GACD/GCC) | CronJob |
| `trilha_auditoria` | 5 anos | `DROP` de partição mensal |
| `outbox_evento` `CONSUMIDO` | 30 dias | CronJob |
| `evento_consumido` | 35 dias (> outbox) | CronJob |
| `sinal_externo` `PROCESSADO`/`IGNORADO` | 180 dias; `QUARENTENA` até resolução + 180 dias | CronJob |
| `tarefa` concluída/cancelada | 30 dias | CronJob |
| `requisicao_idempotente` | 72 h | CronJob |
| `entrega_status` `CONFIRMADA`/`SUPERADA` | 30 dias; `ESTACIONADA` até resolução | CronJob |
| `visao_jornada`, `alerta_gerente` | Igual ao agregado | CronJob |
| PDF no Blob | Exclusão ao chegar a Assinado/Encerrado/reemissão; lifecycle 30 dias | Tarefa + política do Blob |

### 6.5 Estimativa de volume (PRM-TEC-03)

Com 500 solicitações/dia: ~180 mil adesões/ano; ~8 eventos e ~15 registros de auditoria por adesão → ~1,5 milhão de eventos e ~2,7 milhões de linhas de auditoria/ano. Volume pequeno para PostgreSQL; particionamento só na auditoria (maior tabela e retenção longa).

---

## 7. Máquina de estados do Termo

### 7.1 Diagrama

Estados canônicos (01 §7.4, 03 §6). "Envio confirmado" e "saga em andamento" são **atributos** do estado Gerado, não estados novos (ADR-02).

```mermaid
stateDiagram-v2
  state "Solicitado" as SOL
  state "Assinantes identificados" as AID
  state "Gerado" as GER
  state "Aguardando assinatura" as AGU
  state "Assinantes inválidos" as INV
  state "Assinado" as ASS
  state "Falha na geração" as FAL
  state "Encerrado" as ENC

  [*] --> SOL: T-01 SolicitarTermoAdesao
  SOL --> AID: T-02 FIRP ok
  SOL --> FAL: T-03 FIRP falhou ou sem assinantes
  AID --> GER: T-04 documento gerado
  AID --> FAL: T-05 documento falhou
  GER --> GER: T-06 ConfirmarAssinantes
  GER --> AGU: T-07 saga concluída
  GER --> FAL: T-08 saga falhou
  GER --> ENC: T-17 cancelado sem saga
  AGU --> ASS: T-09 callback assinatura
  AGU --> INV: T-10 alerta assinantes inválidos
  AGU --> ENC: T-11 recusa ou expiração
  AGU --> ENC: T-12 cancelado
  INV --> SOL: T-13 ReemitirTermo
  FAL --> SOL: T-14 ReemitirTermo
  INV --> ENC: T-15 cancelado
  FAL --> ENC: T-16 cancelado
  ASS --> [*]
  ENC --> [*]
```

### 7.2 Tabela de transições

| ID | De → Para | Gatilho (comando / sinal / tarefa) | Guardas | Efeitos (mesma transação) | Evento outbox | Base |
|---|---|---|---|---|---|---|
| T-00 | — (sem agregado) | `SolicitarTermoAdesao` com contrato vigente | Esquema válido; `propostaAprovada=true` | `decisao_elegibilidade(DISPENSADA)`; auditoria | `AdesaoDispensada` | RN-02; RFN-02 |
| T-01 | — → Solicitado | `SolicitarTermoAdesao` | Sem contrato vigente; `produtos[]` ≥ 1; nenhuma adesão não terminal no CNPJ (INV-01); `propostaAprovada=true` (RN-04) | Agregado (tentativa 1, versão 1), `produto_aderido`, `decisao_elegibilidade(REQUERIDA)`, tarefa `IDENTIFICAR_ASSINANTES`, idempotência, auditoria | `TermoSolicitado` | RN-01..04, RN-16; INV-01..03 |
| T-02 | Solicitado → Assinantes identificados | Tarefa `IDENTIFICAR_ASSINANTES` com `Encontrados` | Lista não vazia (INV-05) | `assinante` (tentativa), tarefa `GERAR_DOCUMENTO`, auditoria | `AssinantesIdentificados` | RN-05 |
| T-03 | Solicitado → Falha na geração | `NenhumAssinante` ou falha FIRP após prazo (2 h) ou falha permanente | — | `falha_*` (`FIRP`, `SEM_ASSINANTES`/`FIRP_INDISPONIVEL`/…), auditoria | `GeracaoDoTermoFalhou{etapa: FIRP}` | QA-DDD-12 |
| T-04 | Assinantes identificados → Gerado | Tarefa `GERAR_DOCUMENTO` com sucesso | Modelo vigente para (tipo, renderizador); PDF ≤ limite | `documento_termo`, blob, auditoria (versão do modelo + hash); se confirmação **desligada**: saga + tarefa `EXECUTAR_SAGA` | `TermoGerado` | INV-04; RNFN-01 |
| T-05 | Assinantes identificados → Falha na geração | Falha do renderizador após prazo ou permanente | — | `falha_*` (`DOCUMENTO`) | `GeracaoDoTermoFalhou{etapa: DOCUMENTO}` | 03 §6 |
| T-06 | Gerado → Gerado | `ConfirmarAssinantes` (`POST …/confirmacao-envio`) | Flag ligada; hash confere; não confirmado | `envio_confirmado_*`, saga (`COORDENAR_CONTRATO/PENDENTE`), tarefa `EXECUTAR_SAGA`, auditoria | — (interno `AssinantesConfirmados`) | ADR-02; QA-NEG-18 |
| T-07 | Gerado → Aguardando assinatura | Saga `CONCLUIDA` | `codigoProtocolo` presente (INV-06); protocolo `ABERTO` → `VIGENTE` | Protocolo `VIGENTE` com `IdPrevia`/`CaminhoPrevia`, auditoria | `TermoEnviadoParaAssinatura` | INV-06; [FATO: 04] |
| T-08 | Gerado → Falha na geração | Saga `FALHOU` (após compensação) | — | `falha_*` (`GACD`), protocolo `CANCELADO`/`ORFAO`, reconciliação se necessário | `GeracaoDoTermoFalhou{etapa: GACD}` | 03 §6; QA-CON-16 |
| T-09 | Aguardando assinatura → Assinado | Sinal `ASSINATURA_CONCLUIDA` | Protocolo `VIGENTE` (INV-07); confirmação ativa ok (se flag) | Protocolo `ENCERRADO`; `terminal_em`; tarefa `EXCLUIR_STAGING`; sinal `PROCESSADO`; auditoria | `AssinaturaConcluida` | RN-08; INV-07, INV-09 |
| T-10 | Aguardando assinatura → Assinantes inválidos | Sinal `ASSINANTES_INVALIDOS` | Protocolo `VIGENTE` (INV-08) | Sinal `PROCESSADO`; auditoria | `AssinantesInvalidados` | RN-06, RN-07; INV-08 |
| T-11 | Aguardando assinatura → Encerrado | Sinal `RECUSADO`/`EXPIRADO` (se existir, QA-TEC-07) | Protocolo `VIGENTE` | `motivo_encerramento`; protocolo `ENCERRADO`; `terminal_em`; `EXCLUIR_STAGING` | `TermoEncerrado{RECUSADO ou EXPIRADO}` | EVN-12; QA-CON-12 |
| T-12 | Aguardando assinatura → Encerrado | `EncerrarTermo` (`POST …/cancelamento`) | — | `CANCELADO`; protocolo `CANCELADO`; `CANCELAR_PROTOCOLO` (flag) ou reconciliação `CANCELAMENTO_PENDENTE`; `EXCLUIR_STAGING` | `TermoEncerrado{CANCELADO}` | QA-NEG-12 |
| T-13 | Assinantes inválidos → Solicitado | `ReemitirTermo` | — | `tentativa+1`; protocolo `SUBSTITUIDO` + `CANCELAR_PROTOCOLO` ou reconciliação; limpa confirmação; `IDENTIFICAR_ASSINANTES`; `EXCLUIR_STAGING` (tentativa anterior) | `ReemissaoSolicitada` | 03 §6; QA-DDD-02 |
| T-14 | Falha na geração → Solicitado | `ReemitirTermo` | — | `tentativa+1`; limpa falha e confirmação; `IDENTIFICAR_ASSINANTES`; `EXCLUIR_STAGING` se houver documento | `ReemissaoSolicitada` | 03 §6 |
| T-15 | Assinantes inválidos → Encerrado | `EncerrarTermo` | — | Como T-12 | `TermoEncerrado{CANCELADO}` | PRM-DDD-10 |
| T-16 | Falha na geração → Encerrado | `EncerrarTermo` | — | `CANCELADO`; protocolo órfão (se houver) permanece em reconciliação | `TermoEncerrado{CANCELADO}` | PRM-DDD-10 |
| T-17 | Gerado → Encerrado | `EncerrarTermo` | Saga inexistente (antes da confirmação) | `CANCELADO`; `EXCLUIR_STAGING` | `TermoEncerrado{CANCELADO}` | **[PROPOSTA]** [DT-16] |

Toda transição: incrementa `versao`, atualiza `atualizado_em`, grava auditoria com `status_anterior`/`status_novo`.

### 7.3 Matriz comando × estado

`✓` permitido · `—` rejeitado com `409 ESTADO_INCOMPATIVEL` · `R` replay idempotente se mesma `Idempotency-Key`

| Comando \ Estado | SOLICITADO | ASSINANTES_IDENTIFICADOS | GERADO | AGUARDANDO_ASSINATURA | ASSINANTES_INVALIDOS | ASSINADO | FALHA_NA_GERACAO | ENCERRADO |
|---|---|---|---|---|---|---|---|---|
| Consultar / prévia | ✓ (prévia: 404) | ✓ (prévia: 404) | ✓ | ✓ | ✓ | ✓ (prévia: 410 após exclusão) | ✓ | ✓ (prévia: 410) |
| Confirmar envio | — | — | ✓ (uma vez; flag) | — | — | — | — | — |
| Reemitir | — | — | — | — | ✓ | — | ✓ | — |
| Cancelar | — | — | ✓ só sem saga (T-17) | ✓ | ✓ | — | ✓ | — |

Sinais externos fora da guarda não geram erro ao emissor: o sinal fica `IGNORADO` ou `QUARENTENA` (SPEC-TER-09).

---

## 8. Eventos (outbox)

### 8.1 SPEC-EVT-01 — Envelope e catálogo de eventos versionados

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01 (produtor), COMP-03 (consumidor) · CONSTRUIR · PRONTA |
| Rastreio | RF-09, RF-12, RF-13 · RNF-05 · R-14 · ADR-05, ADR-11 · 03 §5 · [DT-08] |
| Depende de | SPEC-TRV-01 (módulo `adesao-contrato-eventos`) |


| Evento | v | Produtor | Consumidor(es) nesta entrega | Visibilidade | Payload (além do envelope) | Chave de negócio |
|---|---|---|---|---|---|---|
| `TermoSolicitado` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `idProposta`, `cnpj`, `tipoTermo`, `produtos[{codigoProduto}]`, `tentativa` | `idAdesao`+`versaoAgregado` |
| `AdesaoDispensada` | 1 | COMP-01 | COMP-03; gatilho futuro da implantação do convênio | Publicado | `idDecisao`, `idProposta`, `cnpj`, `produtos[]`, `referenciaContratoVigente` | `idProposta` |
| `AssinantesIdentificados` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `tentativa`, `quantidadeAssinantes`, `idsRepresentanteFirp[]` | `idAdesao`+`versaoAgregado` |
| `TermoGerado` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `tentativa`, `versaoModelo`, `hashDocumento`, `renderizador` | `idAdesao`+`versaoAgregado` |
| `TermoEnviadoParaAssinatura` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `tentativa`, `codigoProtocolo`, `enviadoEm` (sem `IdPrevia`/`CaminhoPrevia` para fora do BC-01) | `codigoProtocolo` |
| `GeracaoDoTermoFalhou` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `tentativa`, `etapa`, `codigo`, `reprocessavel` | `idAdesao`+`versaoAgregado` |
| `AssinantesInvalidados` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `codigoProtocolo`, `motivo`, `quantidadeInvalidos`, `origem` (`CANAL`\|`GACD`) | `codigoProtocolo`+`idNotificacao` |
| `ReemissaoSolicitada` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `tentativa`, `protocoloAnterior`, `motivo` | `idAdesao`+`versaoAgregado` |
| `AssinaturaConcluida` | 1 | COMP-01 | COMP-03; gatilho futuro da implantação do convênio (ADR-11) | Publicado | `idAdesao`, `codigoProtocolo`, `cnpj`, `tipoTermo`, `produtos[]`, `assinadoEm` | `codigoProtocolo` |
| `TermoEncerrado` | 1 | COMP-01 | COMP-03 | Publicado | `idAdesao`, `codigoProtocolo` (se houver), `motivo` | `idAdesao`+`versaoAgregado` |
| `PendenciaAssinaturaProlongada` | 1 | COMP-01 | COMP-03 | Publicado **[PROPOSTA]** [DT-17] | `idAdesao`, `codigoProtocolo`, `diasPendente` | `codigoProtocolo`+`diasLimite` |
| `ConvenioSolicitado` | 1 | (futuro) | — | Contrato inativo (ADR-11); se ativado, abre a implantação, não cria o convênio (SPEC-CNV-01) | `idSolicitacao`, `cnpj`, `codigoProduto`, `origem` | `cnpj`+`codigoProduto`+`origem` |
| `AssinantesConfirmados`, `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada` | — | COMP-01 | — | **Interno** (só auditoria e saga; não vão à outbox) | — | — |

`StatusJornadaAtualizado` e `AlertaGerenteEmitido` (03 §5.1) não são eventos de outbox nesta entrega: materializam-se como upsert de `Adesao_Termo__c` e `Alerta_Adesao__c` (ADR-06).

### 8.2 Envelope (JSON Schema 2020-12)

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:atacado:adesao:evento:envelope:v1",
  "type": "object",
  "required": ["idEvento","tipoEvento","versaoSchema","ocorridoEm","tipoAgregado","idAgregado","versaoAgregado",
               "idProposta","correlationId","chaveCorrelacaoNegocio","produtor","dados"],
  "properties": {
    "idEvento":               { "type": "string", "format": "uuid" },
    "tipoEvento":             { "type": "string" },
    "versaoSchema":           { "type": "integer", "minimum": 1 },
    "ocorridoEm":             { "type": "string", "format": "date-time" },
    "tipoAgregado":           { "enum": ["AdesaoTermo","DecisaoElegibilidade"] },
    "idAgregado":             { "type": "string", "format": "uuid" },
    "versaoAgregado":         { "type": "integer", "minimum": 1 },
    "idProposta":             { "type": "string", "maxLength": 64 },
    "correlationId":          { "type": "string", "maxLength": 64 },
    "chaveCorrelacaoNegocio": { "type": "string", "maxLength": 64 },
    "causationId":            { "type": ["string","null"], "maxLength": 64 },
    "produtor":               { "const": "adesao-termo" },
    "dados":                  { "type": "object" }
  },
  "additionalProperties": false
}
```

Exemplo — `AssinaturaConcluida` v1:

```json
{
  "idEvento": "01926f3a-7c1b-7d2e-9a44-3b5c6d7e8f90",
  "tipoEvento": "AssinaturaConcluida",
  "versaoSchema": 1,
  "ocorridoEm": "2026-10-05T13:22:41Z",
  "tipoAgregado": "AdesaoTermo",
  "idAgregado": "5b7c2f0e-8f1d-4d2b-9a55-0c1e2f3a4b5c",
  "versaoAgregado": 7,
  "idProposta": "a0X5g00000ABCDEFGH",
  "correlationId": "0f9d6c1e-2c1f-4a41-8f0c-6a3e0d6c9b11",
  "chaveCorrelacaoNegocio": "<codigoProtocolo>",
  "causationId": "sinal:3c2b1a09-...",
  "produtor": "adesao-termo",
  "dados": {
    "idAdesao": "5b7c2f0e-8f1d-4d2b-9a55-0c1e2f3a4b5c",
    "codigoProtocolo": "<codigoProtocolo>",
    "cnpj": "11222333000181",
    "tipoTermo": "PRODUTOS",
    "produtos": [ { "codigoProduto": "PAG-FORNECEDORES" }, { "codigoProduto": "COBRANCA" } ],
    "assinadoEm": "2026-10-05T13:22:30-03:00"
  }
}
```

Na outbox, as colunas do envelope ficam em colunas próprias e `dados` fica em `payload` (o relay remonta o envelope).

### 8.3 SPEC-EVT-02 — Registro de schemas e testes de compatibilidade

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-13 · R-14 · 03 §5.2 |
| Depende de | SPEC-EVT-01 |


| Regra | Especificação |
|---|---|
| Local | `contratos/eventos/<TipoEvento>/v<n>.schema.json` (+ `envelope/v1.schema.json`) |
| Compatível (mesma versão) | Novo campo **opcional** em `dados`; consumidores ignoram campos desconhecidos |
| Incompatível | Novo arquivo `v<n+1>`; durante a transição o produtor grava as duas versões (duas linhas com o mesmo `tipo_evento` e `versao_schema` diferente — a unicidade da outbox inclui `versao_schema`) até os consumidores migrarem; o consumidor declara as versões que aceita e ignora as demais |
| Validação | Produtor valida o payload antes de gravar (CA-TER-10.1); teste de compatibilidade compara o schema novo com o anterior e falha em remoção de campo obrigatório ou mudança de tipo |
| Documentação | Catálogo gerado a partir dos schemas no build (`docs/eventos.md`) |

**Critérios de aceite**: CA-EVT-01.1 — todo evento publicado tem schema versionado e exemplo; CA-EVT-02.1 — alteração que remove campo obrigatório de um schema existente quebra o build; CA-EVT-02.2 — nenhum schema de evento contém propriedade `cpf`, `nome` de pessoa ou base64 (teste de lint).

---

## 9. Saga GACD (`ProcessoEnvioAssinatura`)

### 9.1 Passos e estados

```mermaid
stateDiagram-v2
  state "COORDENAR_CONTRATO" as P1
  state "ARMAZENAR_PREVIA" as P2
  state "COORDENAR_REGRA" as P3
  state "RESULTADO_INCERTO" as INC
  state "COMPENSANDO" as CMP
  state "CONCLUIDA" as OK
  state "FALHOU" as KO

  [*] --> P1: confirmação ou TermoGerado com flag desligada
  P1 --> P2: codigoProtocolo recebido
  P1 --> P1: erro de conexão antes do envio, retentativa
  P1 --> INC: timeout de leitura ou 5xx ambíguo
  P1 --> KO: erro permanente ou prazo sem protocolo
  INC --> P2: reconciliação encontrou protocolo
  INC --> P1: reconciliação confirmou inexistência
  INC --> KO: decisão da operação
  P2 --> P3: IdPrevia e CaminhoPrevia
  P2 --> P2: falha transitória, retentativa imediata e agendada
  P2 --> CMP: prazo de 2 h esgotado ou erro permanente
  P3 --> OK: prévia e regras confirmadas
  P3 --> P3: falha transitória, retentativa
  P3 --> CMP: prazo esgotado ou erro permanente
  CMP --> KO: protocolo cancelado ou marcado ORFAO
  OK --> [*]
  KO --> [*]
```

Correspondência com o 04 §9.2: `ETAPA_n_PENDENTE` = (`etapa` n, `estado` `PENDENTE`); demais estados iguais.

| Passo | Serviço **[FATO: 04]** | Timeout | Retry imediato | Retentativa agendada | Idempotência | Pós-condição (mesma transação) |
|---|---|---|---|---|---|---|
| 1 Coordenar Contrato | `gacd-srv-coordenar-ass-sformatador` | 2 s / 10 s | Só erro de conexão antes do envio | Idem se nenhum byte enviado; ambíguo → `RESULTADO_INCERTO` | **Não repetível** às cegas (PRM-TEC-11); `referenciaExterna` se o GACD aceitar | `protocolo_assinatura(ABERTO)`; saga → `ARMAZENAR_PREVIA/PENDENTE`; auditoria `PROTOCOLO_ABERTO` |
| 2 Armazenar Prévia | `cgcc_conteudo_gacd/rest/v1/conteudo/armazenar` | 2 s / 30 s | 3× (1 s → 4 s, jitter) | 1, 5, 15, 30, 60 min até 2 h | Repetível no mesmo protocolo (PRM-TEC-11) | `id_previa`, `caminho_previa`; saga → `COORDENAR_REGRA/PENDENTE`; auditoria `PREVIA_ARMAZENADA` |
| 3 Coordenar Regra | `gacd-srv-coordenar-regra` | 2 s / 10 s | 3× | Idem | Repetível (PRM-TEC-11) | Saga `CONCLUIDA`; T-07; auditoria `REGRA_COORDENADA` e `ENVIADO_PARA_ASSINATURA` |

### 9.2 Execução

- Disparo pela tarefa `EXECUTAR_SAGA` (SPEC-TER-08) e por um agendador próprio (`ix_saga_agendada`) para retentativas; *lease* de 2 min por saga (`bloqueado_ate`), chamada externa fora de transação, resultado aplicado em transação com lock otimista (`versao`).
- Antes de cada passo, verifica se a adesão ainda está em Gerado e confirmada; se foi cancelada, a saga vai para `COMPENSANDO` (se há protocolo) ou `FALHOU` sem chamada.
- Cada chamada gera linha em `saga_envio_assinatura_passo`.
- Circuito aberto → `AGUARDANDO_RETENTATIVA` sem consumir tentativa.

### 9.3 Compensação

| Situação | Compensação | Resultado |
|---|---|---|
| Falha final no passo 1 sem protocolo | Nenhuma | Saga `FALHOU`; T-08 |
| Falha final nos passos 2/3, API de cancelamento disponível e flag ligada | `cancelarProtocolo` (3 tentativas) | Protocolo `CANCELADO`; saga `FALHOU`; T-08 |
| Idem, sem API ou cancelamento falhou | — | Protocolo `ORFAO`; `reconciliacao_manual(ORFAO)`; alerta P2 com `codigoProtocolo`; saga `FALHOU`; T-08 |
| Hash do documento divergente antes do passo 2 | Idem aos passos 2/3 (se protocolo aberto) | `reconciliacao_manual(DOCUMENTO_ADULTERADO)`; alerta P1 de segurança; `falha_reprocessavel=true` (reemissão gera novo documento) |

### 9.4 Resultado incerto, reconciliação e protocolos órfãos (RSK-04)

**Definições**

| Termo | Definição |
|---|---|
| Resultado incerto | Passo 1 com timeout de leitura ou resposta ambígua: o protocolo pode ter sido criado no GACD sem o Atacado saber o `codigoProtocolo` |
| Protocolo órfão | Protocolo aberto no GACD que não é o vigente de nenhuma adesão ativa: saga falhou após o passo 1 sem cancelamento; reemissão ou cancelamento sem API de cancelamento; resultado incerto decidido como "existe" e depois abandonado |

**Tratamento**

1. **Prevenção:** passo 1 sem retry cego; `referenciaExterna` = `{idAdesao}-{tentativa}` enviada se o GACD aceitar (permite consulta e, idealmente, idempotência no GACD) — QA-TEC-06.
2. **Reconciliação automática** (se houver API de consulta por referência externa): job a cada 5 min para sagas em `RESULTADO_INCERTO` → protocolo encontrado: grava `codigoProtocolo` e segue para o passo 2; não encontrado após 15 min: volta a `COORDENAR_CONTRATO/PENDENTE` (repetição segura).
3. **Reconciliação manual** (sem API): `reconciliacao_manual(RESULTADO_INCERTO)` + alerta P2 imediato; a operação consulta o GACD pelo runbook e decide pela API administrativa (`/saga/reconciliar`).
4. **Órfãos:** registrados em `reconciliacao_manual(ORFAO|CANCELAMENTO_PENDENTE)`; relatório diário para o time do GACD; cancelamento manual no GACD pelo runbook; resolução registrada (`resolvido_por`, `resolucao`).
5. **Sinais de órfãos:** callback ou alerta de protocolo `SUBSTITUIDO`, `CANCELADO` ou `ORFAO` → `IGNORADO` (`PROTOCOLO_NAO_VIGENTE`) e anotação na reconciliação correspondente (um órfão assinado pelo cliente é caso de atenção: alerta P2).
6. **Reconciliação diária** (flag `adesao.gacd.reconciliacao-diaria.habilitada`, ADR-08 c): consulta os protocolos `VIGENTE` em Aguardando assinatura há mais de 24 h e injeta na inbox um sinal sintético (`origem=GACD`, chave `GACD:{protocolo}:{tipo}`), reaproveitando a deduplicação — cobre callbacks perdidos.

**Métricas e alertas**: `adesao_saga_estado_total{estado}`, `adesao_reconciliacao_abertos{motivo}`, `adesao_protocolos_orfaos_total`; alerta para qualquer `RESULTADO_INCERTO` e para reconciliação aberta há mais de 2 dias úteis.

**Runbooks obrigatórios antes do go-live** (ADR-12): RB-01 retomar saga; RB-02 decidir resultado incerto; RB-03 cancelar protocolo órfão no GACD; RB-04 reprocessar sinal em quarentena; RB-05 reentregar status estacionado; RB-06 documento adulterado.

---
## 10. Segurança

### 10.1 SPEC-SEG-01 — Autenticação por fronteira

| Campo | Conteúdo |
|---|---|
| Componente | Todos · CONFIGURAR · PARCIAL (QA-TEC-03, 04, 07, 08, 22, 26) |
| Rastreio | RNF-01, RNF-02 · ADR-06, 07, 08, 09, 10 · CAP-11.1 · RSK-05, RSK-16 · 04 §8.1 |

| # | Fronteira | Mecanismo | Onde é validado | Segredo / material | Grau |
|---|---|---|---|---|---|
| A-01 | Salesforce → borda externa → COMP-01 | mTLS (certificado de cliente na Named Credential) + OAuth 2.0 client credentials (escopos `adesao.escrita`, `adesao.leitura`); allowlist de IPs do Salesforce no Akamai | Akamai/Axway (mTLS, token, escopo); COMP-01 confere o `client_id` propagado e o escopo por operação | Chave do certificado no Salesforce; client secret na External Credential | [PREMISSA: PRM-TEC-06]; emissor em QA-TEC-03 |
| A-02 | COMP-01 → Axway → FIRP / GACD | Token de workload (LEAP **[HIPÓTESE]**) por client credentials, em cache até `exp − 60 s` | Axway | `leap-client-id`, `leap-client-secret` (ou certificado) no Key Vault | PRM-TEC-04; QA-TEC-03 |
| A-03 | COMP-01 → GACD passo 2 | Token de workload + **usuário sistêmico** **[FATO: 04]** | Axway + GACD | `gacd-usuario-sistemico`, `gacd-senha-sistemica` no Key Vault | Formato em QA-TEC-04 |
| A-04 | COMP-01 → IMPD | A definir (direto ou via Axway) | IMPD / Axway | `impd-credencial` (se houver) | QA-TEC-01 |
| A-05 | GACD → Axway interno → COMP-02 (callback) | mTLS ou token do GACD na política `atacado-adesao-callback-gacd`; identidade propagada conferida pelo COMP-02 (SPEC-REC-03); protocolo vigente (INV-07); confirmação ativa (flag) | Axway + COMP-02 + COMP-01 | Truststore/cliente no Axway | QA-TEC-07, QA-TEC-22 |
| A-06 | Canal → Axway interno → COMP-02 (alerta) | Token de workload do Canal ou mTLS na política `atacado-adesao-alerta-canal`; identidade conferida pelo COMP-02 | Axway + COMP-02 | — | QA-TEC-08, PRM-TEC-15 |
| A-07 | COMP-03 → Salesforce | OAuth 2.0 JWT Bearer (RS256), usuário de integração com permission set mínimo | Salesforce | `sf-jwt-chave-privada`, `sf-client-id`, `sf-usuario-integracao` no Key Vault | ADR-06; QA-TEC-15, QA-TEC-26 |
| A-08 | Serviços → PostgreSQL | Microsoft Entra ID (token de workload) ou usuário/senha por serviço | PostgreSQL | `pg-<servico>-*` no Key Vault se não houver Entra | QA-TEC-14 |
| A-09 | COMP-01 → Blob | Identidade de workload (RBAC no container) ou credencial no Key Vault | Azure Storage | `blob-credencial` (fallback) | QA-TEC-14 |
| A-10 | Pods → Key Vault | Identidade do CSI Driver (workload identity ou service principal) | Key Vault | Configuração da plataforma | PRM-TEC-08 |
| A-11 | Operação → API admin (8082) | `oc port-forward` (RBAC do OpenShift) + token admin + `X-Operador` | OpenShift + aplicação | `admin-api-token` por serviço | QA-TEC-27 |

```mermaid
sequenceDiagram
  autonumber
  participant SF as Salesforce
  participant EM as Emissor OAuth corporativo
  participant BX as Akamai AppGW Axway externo
  participant T as COMP-01
  participant LEAP as Emissor LEAP hipótese
  participant AXI as Axway interno
  participant G as GACD
  participant R as COMP-02
  participant AC as COMP-03
  participant SFT as Salesforce token endpoint

  SF->>EM: client credentials
  EM-->>SF: access token
  SF->>BX: HTTPS mTLS e Bearer
  BX->>BX: valida certificado, token, escopo e IP
  BX->>T: encaminha com identidade propagada
  T->>LEAP: client credentials com segredo do Key Vault
  LEAP-->>T: token de workload
  T->>AXI: chamada GACD com Bearer e usuário sistêmico no passo 2
  AXI->>G: encaminha
  G->>AXI: callback com mTLS ou token do GACD
  AXI->>R: encaminha com identidade propagada
  R->>R: confere allowlist do chamador
  AC->>SFT: JWT assinado com chave do Key Vault
  SFT-->>AC: access token
  AC->>SF: upsert REST com Bearer
```

**Critérios de aceite**: CA-SEG-01.1 — em Hom, chamada à API Adesão sem certificado de cliente ou sem token é rejeitada na borda; CA-SEG-01.2 — chamada direta ao Service do COMP-01/COMP-02 a partir de outro namespace é bloqueada (SPEC-SEG-04); CA-SEG-01.3 — nenhum segredo fora do Key Vault (varredura de repositório, imagem e ConfigMaps).

### 10.2 SPEC-SEG-02 — Autorização, escopos e menor privilégio

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PARCIAL (QA-TEC-22) |
| Rastreio | RNF-01 · 04 §8.1 · RSK-16 |

| Recurso | Consumidor autorizado | Escopo / regra |
|---|---|---|
| `POST /v1/adesoes`, `…/confirmacao-envio`, `…/reemissao`, `…/cancelamento` | Salesforce (`client_id` do Atacado) | `adesao.escrita` |
| `GET /v1/adesoes…`, `…/documento` | Salesforce | `adesao.leitura` |
| `POST /v1/callbacks/gacd/assinaturas/{id}` | Só a identidade do GACD | Allowlist `callback-gacd` |
| `POST /v1/alertas/assinantes-invalidos`, `GET /v1/alertas/{id}` | Só a identidade do Canal | Allowlist `alerta-canal` |
| `/admin/v1/**` | Operação | Token admin + `X-Operador` + RBAC de port-forward |
| Banco | Por serviço | Matriz da seção 6.3 |
| Salesforce | Usuário de integração | Permission set: `Adesao_Termo__c`, `Alerta_Adesao__c` (criar/editar), Proposta (leitura) |

O Gerente não tem token próprio no ARO: `matriculaGerente` vem no corpo e é **auditada**; o Salesforce é cliente confiável (04 §8.1). **Critérios de aceite**: CA-SEG-02.1 — token com só `adesao.leitura` recebe 403 em comandos; CA-SEG-02.2 — teste de cada linha da matriz.

### 10.3 SPEC-SEG-03 — LGPD: minimização, mascaramento e retenção

| Campo | Conteúdo |
|---|---|
| Componente | Todos · CONSTRUIR · PARCIAL (QA-TEC-17 retenção; QA-TEC-24 CPF no GACD) |
| Rastreio | RNF-04 · RNFN-05 · PRM-DDD-08 · RSK-12 · 04 §8.3 |

| Dado | Classificação | Onde pode existir | Onde é proibido | Controle |
|---|---|---|---|---|
| CNPJ, razão social, produtos | Confidencial (empresarial) | API, banco, eventos, Salesforce, documento | Logs sem máscara | Máscara em log; TLS; criptografia em repouso |
| Assinante: id FIRP, nome, papel | **Pessoal** | `assinante` (banco), documento, resposta `GET /v1/adesoes/{id}`, `Resumo_Assinantes__c` (só com flag) | Eventos, logs, métricas, alertas, problem details | `toString` mascarado; anonimização após 180 dias do estado terminal |
| CPF de representante | **Pessoal** | Em memória no adaptador FIRP (e no passo 1 do GACD, se QA-TEC-24 exigir) | Banco, eventos, logs, Salesforce, documento (salvo exigência jurídica) | Descarte na ACL; teste automatizado |
| Matrícula do Gerente | Pessoal | `trilha_auditoria`, `adesao_termo.matricula_solicitante`, `envio_confirmado_por` | Logs em claro, eventos | Hash curto em log |
| PDF do termo | Pessoal + confidencial | Blob (≤ 30 dias), trânsito para GACD e prévia | Logs, eventos, Salesforce Files | Private endpoint; exclusão explícita; hash |
| Alerta do Canal | Sem dado pessoal por contrato | Inbox | — | Enum sem texto livre; campos desconhecidos descartados |
| Payload bruto do callback | Possivelmente pessoal | `payload_bruto` só com flag | — | Default desligado (QA-TEC-17) |

Base legal e finalidade: execução de contrato e obrigação regulatória (confirmar com Jurídico/Compliance). Direitos do titular: dados de representantes são obtidos da FIRP (fonte da verdade); o Atacado guarda cópia mínima e temporária.

**Critérios de aceite**: CA-SEG-03.1 — teste automatizado percorre eventos, logs e respostas de erro de um fluxo com dados sintéticos e não encontra CPF nem nome; CA-SEG-03.2 — o job de retenção anonimiza nomes vencidos (SPEC-DB-04); CA-SEG-03.3 — RIPD/avaliação de privacidade registrada com Segurança antes de Prod.

### 10.4 SPEC-SEG-04 — Segmentação de rede (NetworkPolicy, EgressFirewall)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-10, COMP-12 · CONFIGURAR · PARCIAL (QA-TEC-09) |
| Rastreio | RNF-03 · ADR-10 · CAP-11.3 · N-01..N-11 · RSK-09, RSK-14 · [DT-20] |

| Política | Seleção | Regra |
|---|---|---|
| `deny-all` | Todos os pods do namespace | Nega ingress e egress por padrão |
| `allow-dns` | Todos | Egress UDP/TCP 53 para o DNS do cluster |
| `ingress-router-negocio` | `app in (atacado-adesao-termo, atacado-adesao-receptor)` | Ingress TCP 8080 só do namespace do router (`policy-group.network.openshift.io/ingress`) |
| `ingress-monitoramento` | Todos | Ingress TCP 8081 só do monitoramento de workloads de usuário |
| `egress-postgres` | Os três | Egress TCP 5432 para a subnet delegada do PostgreSQL |
| `egress-keyvault-blob` | Os três (Blob só COMP-01) | Egress TCP 443 para os IPs dos private endpoints |
| `egress-axway` | `atacado-adesao-termo` | Egress TCP 443 para os IPs do Axway interno (e IMPD, conforme QA-TEC-01) |
| `egress-otel` | Os três | Egress para o coletor OTLP |
| `egress-salesforce` | **Só** `atacado-adesao-acompanhamento` | Egress TCP 443 para `0.0.0.0/0` **exceto** faixas privadas (única política que permite saída para a internet) |
| `EgressFirewall default` (namespace) | Namespace inteiro | `Allow dnsName: <mydomain>.my.salesforce.com`; `Allow` para CIDRs internos necessários; `Deny 0.0.0.0/0` |
| EgressIP (se disponível) | Namespace | IP de saída dedicado, usado na regra do Azure Firewall do Hub (origem = EgressIP, destino = FQDN do My Domain) |

A combinação garante que só o COMP-03 alcança a internet (NetworkPolicy por pod) e só o FQDN do Salesforce (EgressFirewall + Azure Firewall). **Critérios de aceite**: CA-SEG-04.1 — de um pod do COMP-01, `curl https://<mydomain>.my.salesforce.com` falha; do COMP-03, funciona; CA-SEG-04.2 — do COMP-03, `curl https://example.com` falha; CA-SEG-04.3 — teste automatizado de conectividade (N-01..N-11) roda a cada deploy em Dev/Hom.

### 10.5 SPEC-SEG-05 — Hardening de aplicação, cabeçalhos e imagem

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01/02/03 · CONSTRUIR · PRONTA |
| Rastreio | RNF-01 · 04 §8.4 (STRIDE) |

| Tema | Regra |
|---|---|
| Cabeçalhos de resposta | `Cache-Control: no-store` (todas as respostas de negócio), `X-Content-Type-Options: nosniff`, `Content-Security-Policy: default-src 'none'; frame-ancestors 'none'`, `Strict-Transport-Security` (na borda), sem `Server`/`X-Powered-By` |
| Entrada | Limites de corpo por endpoint (256 KB API/callback; 16 KB alerta); `Content-Type` exigido; JSON com profundidade e tamanho de string limitados; rejeição de parâmetros duplicados |
| Actuator | Só `health`, `info`, `prometheus` expostos, na porta 8081; `env`, `heapdump`, `threaddump`, `configprops` desabilitados |
| Erros | Sem stack trace (SPEC-TRV-04) |
| Imagem | UBI 9 runtime, usuário não root, sistema de arquivos somente leitura (`readOnlyRootFilesystem: true` com `emptyDir` em `/tmp`), sem shell de depuração em Prod, `capabilities: drop [ALL]`, `seccompProfile: RuntimeDefault`, SCC `restricted-v2` |
| Dependências | Atualização mensal; bloqueio de CVE crítica/alta (SPEC-SEG-06) |

**Critérios de aceite**: CA-SEG-05.1 — teste de integração confere os cabeçalhos em todas as rotas; CA-SEG-05.2 — `/actuator/env` retorna 404; CA-SEG-05.3 — o pod roda com `readOnlyRootFilesystem` sem erro.

### 10.6 SPEC-SEG-06 — Segurança da cadeia de suprimentos

| Campo | Conteúdo |
|---|---|
| Componente | Pipeline · CONFIGURAR · PARCIAL (QA-TEC-19, QA-TEC-29) |
| Rastreio | RNF-01 · RSK-12 |

SAST no PR e no build (ferramenta corporativa); SCA com bloqueio de CVE crítica/alta sem exceção aprovada; varredura de segredos (pre-commit e pipeline); varredura de imagem; SBOM CycloneDX anexado; assinatura de imagem e verificação na admissão (se a plataforma suportar); DAST em Hom (SPEC-TST-06). **Critério de aceite**: CA-SEG-06.1 — pipeline falha com dependência de CVE crítica conhecida (teste com dependência vulnerável em branch de verificação).

---

## 11. Infraestrutura e deploy

### 11.1 SPEC-INF-01 — Manifestos ARO (Deployment, HPA, PDB, probes)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-10 · CONFIGURAR · PRONTA |
| Rastreio | RNF-08, RNF-12 · PRM-TEC-03, PRM-TEC-09 · 04 §7 |

| Item | COMP-01 `atacado-adesao-termo` | COMP-02 `atacado-adesao-receptor` | COMP-03 `atacado-adesao-acompanhamento` |
|---|---|---|---|
| Réplicas (Prod) | 2..4 (HPA) | 2..3 (HPA) | 2 fixas (1 ativa por lock) |
| HPA | CPU 70% | CPU 70% | — |
| `requests` CPU / memória | 250m / 768Mi | 100m / 384Mi | 100m / 384Mi |
| `limits` CPU / memória | 1 / 1536Mi (renderização Plano B) | 500m / 768Mi | 500m / 768Mi |
| JVM | `-XX:MaxRAMPercentage=75` | Idem | Idem |
| PDB | `minAvailable: 1` | `minAvailable: 1` | `minAvailable: 1` |
| Anti-afinidade | Preferencial por zona | **Obrigatória** por zona (`topologySpreadConstraints`, `maxSkew: 1`) | Preferencial por zona |
| Estratégia | RollingUpdate `maxUnavailable: 0`, `maxSurge: 1` | Idem | Idem |
| Probes | SPEC-TRV-13 | SPEC-TRV-13 | SPEC-TRV-13 |
| Route / Ingress | Privado, só 8080, atrás do Axway | Privado, só 8080, atrás do Axway | Nenhum |
| ServiceAccount | Dedicada (identidade de workload) | Dedicada | Dedicada |
| Outros | Job de migração (hook pré-deploy); CronJob de retenção (SPEC-DB-04) | — | — |

Empacotamento: um Helm chart `atacado-adesao` com os três deployables, o Job de migração e os CronJobs; values por ambiente. **Critérios de aceite**: CA-INF-01.1 — `helm lint` e validação de schema dos manifestos no pipeline; CA-INF-01.2 — política de admissão da plataforma aceita os pods (SCC `restricted-v2`); CA-INF-01.3 — com um nó drenado, o COMP-02 continua atendendo (PDB + anti-afinidade).

Esboço (COMP-02):

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: atacado-adesao-receptor, labels: { app: atacado-adesao-receptor } }
spec:
  replicas: 2
  strategy: { type: RollingUpdate, rollingUpdate: { maxUnavailable: 0, maxSurge: 1 } }
  selector: { matchLabels: { app: atacado-adesao-receptor } }
  template:
    metadata: { labels: { app: atacado-adesao-receptor } }
    spec:
      serviceAccountName: atacado-adesao-receptor
      terminationGracePeriodSeconds: 45
      topologySpreadConstraints:
        - { maxSkew: 1, topologyKey: topology.kubernetes.io/zone, whenUnsatisfiable: DoNotSchedule,
            labelSelector: { matchLabels: { app: atacado-adesao-receptor } } }
      containers:
        - name: app
          image: <registro>/atacado-adesao-receptor:<versao>
          ports: [ { containerPort: 8080, name: http }, { containerPort: 8081, name: management } ]
          env: [ { name: SPRING_PROFILES_ACTIVE, value: prd } ]
          resources: { requests: { cpu: 100m, memory: 384Mi }, limits: { cpu: 500m, memory: 768Mi } }
          startupProbe:   { httpGet: { path: /actuator/health/liveness,  port: management }, periodSeconds: 5, failureThreshold: 12 }
          livenessProbe:  { httpGet: { path: /actuator/health/liveness,  port: management }, periodSeconds: 10, failureThreshold: 3 }
          readinessProbe: { httpGet: { path: /actuator/health/readiness, port: management }, periodSeconds: 5, failureThreshold: 3 }
          lifecycle: { preStop: { exec: { command: ["sh", "-c", "sleep 10"] } } }
          securityContext: { allowPrivilegeEscalation: false, readOnlyRootFilesystem: true, runAsNonRoot: true,
                             capabilities: { drop: [ALL] }, seccompProfile: { type: RuntimeDefault } }
          volumeMounts:
            - { name: segredos, mountPath: /mnt/secrets, readOnly: true }
            - { name: config, mountPath: /config, readOnly: true }
            - { name: tmp, mountPath: /tmp }
      volumes:
        - { name: segredos, csi: { driver: secrets-store.csi.k8s.io, readOnly: true,
                                   volumeAttributes: { secretProviderClass: atacado-adesao-receptor } } }
        - { name: config, configMap: { name: atacado-adesao-receptor } }
        - { name: tmp, emptyDir: {} }
```

### 11.2 SPEC-INF-02 — Pipeline CI/CD

| Campo | Conteúdo |
|---|---|
| Componente | Pipeline · CONFIGURAR · **BLOQUEADA** (QA-TEC-19) |
| Rastreio | RNF-16 · PRM-TEC-09, PRM-TEC-16 |

**[PREMISSA: PRM-TEC-16]** — estágios propostos:

| # | Estágio | Gatilho | Gate |
|---|---|---|---|
| 1 | Build + testes unitários, arquitetura e integração (`./mvnw verify`, Testcontainers) | PR e merge | 100% verde; cobertura mínima (DoD-02) |
| 2 | SAST, SCA, segredos, lint de OpenAPI e JSON Schema, testes de compatibilidade de contrato | PR e merge | Sem crítico/alto novo |
| 3 | Build das 3 imagens (mesma versão), SBOM, varredura de imagem, assinatura | Merge na principal | Sem CVE crítica |
| 4 | Deploy Dev (GitOps): Job de migração → rollout → teste de conectividade (N-xx) → smoke | Automático | Smoke verde |
| 5 | Testes de contrato contra simuladores e, quando existirem, ambientes Dev de GACD/FIRP/IMPD | Automático | Verde |
| 6 | Deploy Hom: migração → rollout → E2E → DAST → carga (sob demanda/semanal) | Promoção manual | Verde + relatório de carga dentro das metas |
| 7 | Deploy Prod: RDM, migração, rollout, smoke, verificação de métricas por 30 min | RDM aprovada | Rollback automático se alerta P1 no período |

**Critérios de aceite**: CA-INF-02.1 — falha em qualquer gate impede a promoção; CA-INF-02.2 — rollback para a versão N-1 em até 15 min sem ação no banco (expand/contract).

### 11.3 SPEC-INF-03 — Ambientes

| Campo | Conteúdo |
|---|---|
| Componente | Todos · PROVISIONAR · PARCIAL (QA-TEC-21) |
| Rastreio | RNF-16 · RSK-09 |

| Ambiente | ARO / namespace | PostgreSQL | Blob | FIRP / GACD | IMPD | Salesforce | Flags iniciais relevantes |
|---|---|---|---|---|---|---|---|
| Local | Docker/Podman (`setup.sh`) | `postgres:16` | Azurite | WireMock | WireMock | WireMock | `termo.renderizador=proprio` |
| Dev | ARO Dev, `atacado-core` | Burstable, sem HA | LRS, PE | WireMock no namespace até haver Dev real | AL2 (se o gate avançar) ou WireMock | Sandbox Developer | `proprio`; payload bruto ligado |
| Hom | ARO Hom, `atacado-core` | General Purpose 2 vCores, sem HA (ou HA para teste de failover) | ZRS, PE | Hom reais (QA-TEC-21) | CM2 | Sandbox Full/Partial | Conforme gate; `adesao.pendencia.alerta-dias=7` |
| Prod | ARO Prod, `atacado-core` | General Purpose 2 vCores, HA zona, PITR 35 d | ZRS, PE | Prod | MZ | Produção | Decisões finais das QA |

**Critério de aceite**: CA-INF-03.1 — cada ambiente tem values versionados e o teste de conectividade (N-xx) passa.

### 11.4 SPEC-INF-04 — Infraestrutura como código

| Campo | Conteúdo |
|---|---|
| Componente | COMP-04, COMP-05, COMP-11 · PROVISIONAR · **BLOQUEADA** (QA-TEC-20) |
| Rastreio | PRM-TEC-17 · RSK-10 |

**[PREMISSA: PRM-TEC-17]** Terraform (`azurerm`) em `infra/terraform/` com módulos: `postgresql-flexible` (subnet delegada, DNS privado, parâmetros, HA, backup), `storage-staging` (conta, container, lifecycle, PE, RBAC), `keyvault` (RBAC, PE, soft delete e purge protection), `identidades` (workload identities e atribuições). State remoto com lock; plano revisado em PR; aplicação por pipeline com identidade dedicada. **Critérios de aceite**: CA-INF-04.1 — `terraform plan` sem drift após aplicação; CA-INF-04.2 — nenhum recurso com acesso público habilitado (política de conformidade).

### 11.5 PostgreSQL, Blob e Key Vault — parâmetros

| Recurso | Parâmetro | Dev | Hom | Prod |
|---|---|---|---|---|
| PostgreSQL | SKU | Burstable B2s | General Purpose 2 vCores | General Purpose 2 vCores (escala para 4 sem mudança de arquitetura) |
| | HA | Não | Opcional | Zona redundante (réplica síncrona) |
| | Storage | 32 GiB | 64 GiB | 64 GiB com autogrow |
| | Backup / PITR | 7 dias | 14 dias | 35 dias; backup geo-redundante conforme política |
| | Parâmetros | `require_secure_transport=on`, `log_min_duration_statement=500ms`, `idle_in_transaction_session_timeout=60s`, `max_connections` ≥ 100 | Idem | Idem + `pgaudit` se exigido (QA-TEC-28) |
| Blob | Redundância | LRS | ZRS | ZRS |
| | Lifecycle | 30 dias | 30 dias | 30 dias |
| | Acesso | PE, sem público | Idem | Idem; sem chave compartilhada (se workload identity) |
| Key Vault | Modelo | RBAC | RBAC | RBAC; soft delete 90 dias; purge protection |

Conexões estimadas em Prod: COMP-01 4×10 + COMP-02 3×5 + COMP-03 2×5 + jobs ≈ 70 (< `max_connections`).

### 11.6 SPEC-INF-05 — Configuração do Axway

| Campo | Conteúdo |
|---|---|
| Componente | COMP-09 · CONFIGURAR · PARCIAL (QA-TEC-03, 09, 10, 22) |
| Rastreio | RST-03, RST-04 · PRI-07 · RNF-01, RNF-15 · ADR-07, 08, 09 |

| API / política | Tipo | Consumidor → backend | Autenticação | Limites propostos | Observações |
|---|---|---|---|---|---|
| `atacado-adesao-sf` — API Adesão v1 | Publicar (externa) | Salesforce → ingress privado → COMP-01 `/v1/adesoes/**` | mTLS + OAuth (escopos) | Corpo requisição 256 KB; resposta até 5 MB (prévia); timeout backend 30 s; 20 req/s | Reescreve `/atacado/adesao/v1` → `/v1`; valida esquema OpenAPI |
| `atacado-adesao-callback-gacd` | Publicar (interna) | GACD → COMP-02 `/v1/callbacks/gacd/**` | mTLS ou token do GACD | 256 KB; timeout 10 s; 50 req/s | Rota interna (PRM-TEC-05) |
| `atacado-adesao-alerta-canal` | Publicar (interna) | Canal → COMP-02 `/v1/alertas/**` | Token do Canal ou mTLS | 16 KB; timeout 10 s; 10 req/s | Contrato "a combinar" |
| FIRP — consulta de representantes | Consumir | COMP-01 → FIRP | Token de workload | Timeout 5 s | QA-TEC-05 |
| GACD — 3 APIs (+ consulta/cancelamento) | Consumir | COMP-01 → GACD | Token de workload + usuário sistêmico (passo 2) | Passo 2: corpo até 7 MB (5 MB em base64 ≈ 6,7 MB); timeout 30 s | QA-TEC-06, QA-TEC-10 |
| IMPD `impd-srv-doc-generator` | Consumir (se via Axway) | COMP-01 → IMPD | A definir | Resposta até 7 MB; timeout 15 s | QA-TEC-01 |
| Emissor de token (LEAP) | Consumir | COMP-01 → emissor | Client credentials | — | QA-TEC-03 |

Todas as políticas: propagar `X-Correlation-ID` e `traceparent`; remover cabeçalhos de identidade enviados pelo cliente e injetar a identidade autenticada (QA-TEC-22); registrar métricas por API. **Critérios de aceite**: CA-INF-05.1 — as três APIs publicadas com OpenAPI em Dev e Hom; CA-INF-05.2 — cabeçalho de identidade forjado pelo cliente não chega ao backend.

### 11.7 SPEC-INF-06 — Key Vault e `SecretProviderClass`

| Campo | Conteúdo |
|---|---|
| Componente | COMP-11 · PROVISIONAR · PARCIAL (QA-TEC-14) |
| Rastreio | RNF-02 · ADR-10 · PRI-08 |

| Segredo (nome no Key Vault) | Serviço | Rotação | Observação |
|---|---|---|---|
| `leap-client-id`, `leap-client-secret` (ou `leap-cert`) | COMP-01 | ≤ 90 dias | Hipótese LEAP (QA-TEC-03) |
| `gacd-usuario-sistemico`, `gacd-senha-sistemica` | COMP-01 | ≤ 90 dias ou política do GACD | Formato em QA-TEC-04 |
| `impd-credencial` | COMP-01 | ≤ 90 dias | Se houver (QA-TEC-01) |
| `blob-credencial` | COMP-01 | ≤ 90 dias | Só sem identidade de workload |
| `pg-termo-usuario-a/b`, `pg-termo-senha-a/b` | COMP-01 | ≤ 90 dias, alternados | Só sem Entra ID |
| `pg-receptor-*` | COMP-02 | Idem | Idem |
| `pg-acompanhamento-*` | COMP-03 | Idem | Idem |
| `pg-migracao-*`, `pg-manutencao-*` | Job / CronJob | Idem | Idem |
| `sf-jwt-chave-privada`, `sf-jwt-chave-privada-proxima` | COMP-03 | Certificado anual (alerta 30 dias antes) | QA-TEC-26 |
| `sf-client-id`, `sf-usuario-integracao` | COMP-03 | Na troca da Connected App | Não sensível, mantido junto por coesão |
| `admin-api-token-termo`, `admin-api-token-acompanhamento` | COMP-01, COMP-03 | ≤ 90 dias | SPEC-TER-12 |

Uma `SecretProviderClass` por deployable, listando só os segredos daquele serviço (menor privilégio). **Critério de aceite**: CA-INF-06.1 — o pod do COMP-02 não tem acesso aos segredos do COMP-01 (tentativa de montagem falha por RBAC).

---

## 12. Observabilidade e auditoria

### 12.1 SPEC-OBS-01 — Métricas técnicas e de negócio

| Campo | Conteúdo |
|---|---|
| Componente | Todos · CONSTRUIR · PRONTA |
| Rastreio | RNF-06, RNF-07, RNF-11 · RFN-12 · RNFN-07 · CAP-09.4 · 04 §9.4 |

**Métricas de negócio** (contadores e histogramas; tags sem dado pessoal)

| Métrica | Tipo | Tags | Origem |
|---|---|---|---|
| `adesao_solicitacoes_total` | counter | `resultado` (REQUERIDA, DISPENSADA, REJEITADA), `tipo_termo` | COMP-01 |
| `adesao_transicoes_total` | counter | `de`, `para` | COMP-01 |
| `adesao_termos_por_estado` | gauge (consulta a cada 60 s) | `estado` | COMP-01 |
| `adesao_etapa_duracao_seconds` | histogram | `etapa` (FIRP, DOCUMENTO, GACD_P1, GACD_P2, GACD_P3, ENTREGA) | COMP-01, COMP-03 |
| `adesao_ciclo_solicitacao_assinatura_seconds` | histogram | `tipo_termo` | COMP-01 (em T-09) |
| `adesao_falhas_geracao_total` | counter | `etapa`, `codigo` | COMP-01 |
| `adesao_assinantes_invalidos_total` | counter | `origem`, `motivo` | COMP-01 |
| `adesao_reemissoes_total`, `adesao_cancelamentos_total` | counter | `motivo` | COMP-01 |
| `adesao_documento_tamanho_bytes` | histogram | `renderizador` | COMP-01 |

**Métricas técnicas**

| Métrica | Origem |
|---|---|
| `http_server_requests_seconds` (rota template, status), `http_client_requests_seconds` (`dependencia`) | Todos |
| `resilience4j_circuitbreaker_state`, `resilience4j_retry_calls_total`, `resilience4j_bulkhead_available_concurrent_calls` | COMP-01, COMP-03 |
| `adesao_tarefas_pendentes{tipo}`, `adesao_tarefa_idade_max_seconds` | COMP-01 |
| `adesao_saga_estado_total{estado}`, `adesao_reconciliacao_abertos{motivo}`, `adesao_protocolos_orfaos_total` | COMP-01 |
| `adesao_inbox_pendentes`, `adesao_inbox_idade_max_seconds`, `adesao_callback_quarentena_total{motivo}`, `adesao_sinais_recebidos_total{origem,tipo,duplicado}` | COMP-01, COMP-02 |
| `adesao_alerta_campos_desconhecidos_total` | COMP-02 |
| `adesao_outbox_pendentes`, `adesao_outbox_idade_max_seconds`, `adesao_outbox_estacionados` | COMP-03 |
| `adesao_entrega_latencia_seconds`, `adesao_entrega_tentativas_total{resultado,http_status}`, `adesao_entrega_estacionada_total` | COMP-03 |
| `adesao_salesforce_api_uso_ratio` | COMP-03 |
| `adesao_documento_integridade_falha_total` | COMP-01 |
| `hikaricp_*`, `jvm_*`, `process_*` | Todos |

**Critério de aceite**: CA-OBS-01.1 — todas as métricas acima existem em `/actuator/prometheus` após o fluxo E2E; nenhuma tag contém CNPJ, nome ou matrícula.

### 12.2 SPEC-OBS-02 — Alertas, painéis e runbooks

| Campo | Conteúdo |
|---|---|
| Componente | COMP-19 · CONFIGURAR · PARCIAL (QA-TEC-16) |
| Rastreio | RNF-11 · ADR-12 |

| Alerta | Condição | Severidade | Runbook |
|---|---|---|---|
| Receptor indisponível | `up{app=receptor}` < 1 réplica por 2 min ou 5xx > 1% em 5 min | P1 | Plataforma |
| Documento adulterado | `adesao_documento_integridade_falha_total` > 0 | P1 (segurança) | RB-06 |
| Saga incerta | `adesao_saga_estado_total{estado="RESULTADO_INCERTO"}` aumentou | P2 | RB-02 |
| Saga falhou / órfão | `…{estado="FALHOU"}` ou `adesao_protocolos_orfaos_total` aumentou | P2 | RB-01, RB-03 |
| Quarentena | `adesao_callback_quarentena_total` aumentou | P2 | RB-04 |
| Inbox atrasada | `adesao_inbox_idade_max_seconds` > 120 s | P2 | RB-04 |
| Entrega estacionada | `adesao_entrega_estacionada_total` > 0 | P2 | RB-05 |
| Outbox acumulada | `adesao_outbox_pendentes` > 100 por 10 min | P2 | — |
| Latência de status | p95 `adesao_entrega_latencia_seconds` > 60 s por 15 min | P3 | — |
| Latência de etapa | p95 `adesao_etapa_duracao_seconds` acima da meta RNF-07 por 15 min | P3 | — |
| Circuito aberto | `resilience4j_circuitbreaker_state{state="open"}` > 5 min | P3 | — |
| Limite Salesforce | `adesao_salesforce_api_uso_ratio` > 0,8 | P3 | — |
| Reconciliação antiga | Item `ABERTO` há > 2 dias úteis | P3 | RB-03 |
| Partição de auditoria | Menos de 2 meses futuros criados | P3 | SPEC-DB-04 |
| Certificado | Vencimento em ≤ 30 dias | P3 | QA-TEC-26 |

Painéis: (1) Jornada (funil por estado, KPIs); (2) Etapas (latência e erro por dependência); (3) Filas (tarefas, saga, inbox, outbox, entregas); (4) Plataforma (JVM, pool, pods). **Critério de aceite**: CA-OBS-02.1 — cada alerta P1/P2 disparado em Hom por teste controlado e com runbook linkado.

### 12.3 SPEC-OBS-03 — KPIs e dados para auditoria (CAP-12)

| Campo | Conteúdo |
|---|---|
| Componente | COMP-01, COMP-03 · CONSTRUIR · PARCIAL (QA-TEC-17 exportação; QA-NEG-06 baseline; PRM-NEG-14 denominador) |
| Rastreio | RF-13 · RFN-12 · RNFN-01, RNFN-07 · KPI-01..KPI-05 · CAP-09.4, CAP-12.1 |

| KPI (02 §) | Medida que a solução fornece | Fonte | Limitação |
|---|---|---|---|
| KPI-01 % termos gerados via Salesforce (≥ 90%) | Numerador: adesões que chegaram a Gerado | `trilha_auditoria` (`DOCUMENTO_GERADO`) | Denominador (termos manuais) fora do sistema (PRM-NEG-14) |
| KPI-02 Tempo de negociação → assinatura (−50%) | Tempo solicitação → assinatura (`adesao_ciclo_solicitacao_assinatura_seconds`) | Auditoria | Início da negociação vem do Salesforce; baseline em QA-NEG-06 |
| KPI-03 % gerados que são assinados (≥ 80%) | Coorte mensal: `ASSINATURA_CONCLUIDA` / `DOCUMENTO_GERADO` | Auditoria | Prazo de expiração em QA-NEG-11 |
| KPI-04 % Gerentes com status em tempo real (100%) | % de entregas confirmadas com latência ≤ 60 s | `entrega_status` + métrica | Indicador técnico substituto |
| KPI-05 % termos em conformidade (100%) | % de documentos com modelo `VIGENTE` aprovado e hash conferido antes do passo 2 | `documento_termo`, `modelo_termo`, auditoria | Critérios regulatórios em QA-NEG-07 |
| Complementares (01 §4.3) | % devolvidos por assinantes inválidos; aging de pendências | Auditoria, `adesao_termos_por_estado` | — |

Exemplo (KPI-03, coorte mensal):

```sql
SELECT date_trunc('month', g.ocorrido_em) AS coorte,
       count(DISTINCT g.id_adesao) AS gerados,
       count(DISTINCT a.id_adesao) AS assinados,
       round(100.0 * count(DISTINCT a.id_adesao) / nullif(count(DISTINCT g.id_adesao), 0), 1) AS conversao_pct
FROM adesao_termo.trilha_auditoria g
LEFT JOIN adesao_termo.trilha_auditoria a
  ON a.id_adesao = g.id_adesao AND a.acao = 'ASSINATURA_CONCLUIDA'
WHERE g.acao = 'DOCUMENTO_GERADO'
GROUP BY 1 ORDER BY 1;
```

Exportação para Databricks (OP-03): **fora desta entrega** até QA-TEC-17; a trilha já tem o formato necessário. **Critério de aceite**: CA-OBS-03.1 — as consultas dos KPIs rodam em Hom sobre a massa de testes e batem com a contagem esperada.

---

## 13. Estratégia de testes

| Nível | Escopo | Ferramentas | Onde roda | SPEC |
|---|---|---|---|---|
| Unitário | Domínio, políticas, tradutores das ACLs, máquina de estados, mapeamentos | JUnit 5, AssertJ | Build | TST-01 |
| Arquitetura | Fronteiras de módulo, hexagonal, convenções | Spring Modulith, ArchUnit | Build | TST-01 |
| Integração | Repositórios, filas (tarefa/inbox/outbox), migrações, idempotência, concorrência | Testcontainers (PostgreSQL 16, Azurite), WireMock | Build | TST-02 |
| Contrato | API Adesão, callback, alerta, saída Salesforce, consumo FIRP/GACD/IMPD | Validação OpenAPI (requisição e resposta), JSON Schema; Pact opcional | Build + Dev | TST-04 |
| Componente | Cada deployable isolado com simuladores | Spring Boot Test + WireMock | Build | TST-03 |
| E2E | Salesforce sandbox → COMP-01 → dependências Hom → callback → Salesforce | Scripts em `testes/e2e` | Hom | TST-04 |
| Carga | Volumetria PRM-TEC-03 × 10 | Gatling | Hom | TST-05 |
| Segurança | SAST, SCA, segredos, imagem, DAST | Ferramentas corporativas, OWASP ZAP | Pipeline + Hom | TST-06 |
| Documento | Template, PDF/A, conteúdo, tamanho | PDFBox, veraPDF | Build + Hom | TST-07 |
| Resiliência / migração | Falhas de dependência, pod kill, failover, compatibilidade N-1 | WireMock (faults), Testcontainers, testes em Hom | Build + Hom | TST-08 |

### 13.1 SPEC-TST-01 — Testes unitários e de arquitetura

CONSTRUIR · PRONTA · Rastreio: RNF-13, DoD-01/02. Cobertura ≥ 80% de linhas em `dominio` e `aplicacao`; 100% das transições T-00..T-17 e da matriz 7.3; tabelas-verdade de elegibilidade. **CA-TST-01.1** — relatório de cobertura publicado no pipeline com os limites aplicados como gate.

### 13.2 SPEC-TST-02 — Testes de integração com Testcontainers

CONSTRUIR · PRONTA · Rastreio: RNF-05, INV-01, INV-10. PostgreSQL 16 real com as migrações Flyway; cenários: INV-01 concorrente, lock otimista, SKIP LOCKED com várias instâncias, atomicidade estado+outbox+tarefa+auditoria, `ON CONFLICT` da inbox, roles e privilégios (conectar com cada role), trigger da auditoria, particionamento. **CA-TST-02.1** — suíte roda em < 10 min no pipeline e sem rede externa.

### 13.3 SPEC-TST-03 — Simuladores de dependências (WireMock)

CONSTRUIR · PARCIAL (contratos API-05..07) · Rastreio: RSK-07, RSK-03, RSK-01. Mapeamentos versionados em `testes/simuladores/` para FIRP, GACD (3 passos, consulta, cancelamento, callback de saída para testes), IMPD, emissor LEAP e Salesforce (token + sObjects). Cada simulador tem cenários de falha: atraso acima do timeout, 5xx intermitente, 429 com `Retry-After`, 401, resposta malformada, conexão recusada. Os mesmos mapeamentos rodam como contêiner no Dev. **CA-TST-03.1** — cada cenário de falha tem um teste de componente que o exercita; **CA-TST-03.2** — quando o contrato real chegar, os stubs são validados contra ele (teste de conformidade).

### 13.4 SPEC-TST-04 — Testes de contrato

CONSTRUIR · PARCIAL (QA-TEC-07, 08, 15) · Rastreio: R-01, R-02, R-06, R-13 · [DT-13].

| Contrato | Lado do Atacado | Outro lado |
|---|---|---|
| API Adesão v1 | Provedor: validação de requisições e respostas contra `api-adesao-v1.yaml` em todos os testes de controller | Salesforce: `HttpCalloutMock` gerados a partir dos exemplos do OpenAPI; testes Apex |
| Callback GACD | Provedor tolerante: payloads de exemplo fornecidos pelo GACD como casos de teste | GACD: envia exemplos reais em Hom (QA-TEC-07) |
| Alerta v1 | Provedor: validação OpenAPI; Pact provider se Canais aderir | Canais: consumer tests (Pact ou OpenAPI) |
| Saída Salesforce | Consumidor: stubs validados contra os metadados dos objetos | Salesforce: testes Apex do trigger defensivo |
| FIRP, GACD, IMPD | Consumidor: stubs validados contra o contrato do provedor | Provedores: verificação se aderirem (Pact) |
| Eventos | Produtor e consumidor validam contra `contratos/eventos` | — |

**CA-TST-04.1** — mudança no YAML que quebre compatibilidade falha o build (CA-TRV-05.2); **CA-TST-04.2** — E2E em Hom cobre o fluxo feliz e os fluxos 2, 3 e 4 do 04 §6.

### 13.5 SPEC-TST-05 — Testes de carga

VALIDAR · PARCIAL (QA-TEC-21: ambiente e dependências em Hom) · Rastreio: RNF-06, RNF-07, RNF-12 · PRM-TEC-03 · [DT-14].

| Cenário | Perfil | Critério |
|---|---|---|
| Nominal | 50 solicitações/h (pico PRM-TEC-03) por 2 h, fluxo completo com simuladores a p95 realista (FIRP 1 s, IMPD 3 s, GACD 2 s) | `POST /v1/adesoes` p95 ≤ 1 s; Solicitado → Gerado p95 ≤ 60 s; confirmação → Aguardando p95 ≤ 90 s; entrega p95 ≤ 60 s |
| Escala ×10 (RNF-12) | 500 solicitações/h por 1 h | Mesmos p95; erro < 0,1%; CPU < 70%; pool < 70% |
| Rajada de sinais | 200 callbacks + 50 alertas em 1 min, com 20% duplicados | 0 perdas; 0 duplicidade de efeito; p99 de ACK ≤ 500 ms |
| Resistência | Nominal por 8 h | Sem crescimento de memória; filas estáveis |
| Salesforce lento | Stub com 5 s de latência e 10% de 503 | Nenhuma perda; latência cresce sem afetar COMP-01/02 |
| Documento máximo | PDF de 5 MB no passo 2 | Sem erro de payload no caminho (Axway, GACD) — QA-TEC-10 |

**CA-TST-05.1** — relatório Gatling versionado por release com os critérios acima.

### 13.6 SPEC-TST-06 — Testes de segurança

VALIDAR · PARCIAL (QA-TEC-29) · Rastreio: RNF-01, RNF-04 · RSK-12, RSK-16. SAST, SCA, segredos e imagem no pipeline (SPEC-SEG-06); DAST (OWASP ZAP ou ferramenta corporativa) contra as três APIs em Hom via Axway; testes negativos: callback forjado (identidade errada, protocolo inexistente, protocolo anterior), alerta com dado pessoal, `Idempotency-Key` reutilizada, escopo insuficiente, corpo acima do limite, injeção no template (Plano B); pentest antes de Prod. **CA-TST-06.1** — nenhum achado crítico/alto aberto no go-live.

### 13.7 SPEC-TST-07 — Testes do template do termo

VALIDAR · PARCIAL (QA-TEC-02, QA-CON-19) · Rastreio: RF-04 · RNF-14, RNF-15 · RNFN-02.

| Verificação | Plano A (IMPD) | Plano B (próprio) |
|---|---|---|
| PDF válido e decodificável do base64 | ✓ | ✓ |
| Texto contém as cláusulas obrigatórias e as variáveis (extração com PDFBox) | ✓ | ✓ |
| Casos-limite: 1 e 10 assinantes; 1 e 15 produtos; razão social com 150 caracteres e acentos; CNPJ alfanumérico | ✓ | ✓ |
| Tamanho ≤ 1 MB nominal | ✓ | ✓ |
| PDF/A-2b (veraPDF) e fontes embutidas | Se o IMPD suportar (QA-TEC-02) | ✓ |
| Regressão visual (render de página e comparação com referência aprovada) | Em Hom (CM2) | No build |
| Escape de conteúdo (HTML/script) | N/A | ✓ |
| Versão do modelo registrada e hash reprodutível para os mesmos bytes | ✓ | ✓ |

**CA-TST-07.1** — suíte de template roda a cada alteração de modelo e é evidência da aprovação do Jurídico no PR.

### 13.8 SPEC-TST-08 — Testes de resiliência, recuperação e migração

VALIDAR · PRONTA · Rastreio: RNF-05, RNF-08, RNF-09 · RSK-04, RSK-17. Cenários: pod do COMP-01 morto durante cada passo da saga (retomada correta, sem passo 1 duplicado); COMP-03 morto no meio do lote (sem perda nem duplicidade de efeito); banco indisponível 2 min (COMP-02 devolve 503; recuperação automática); failover do PostgreSQL em Hom (RTO ≤ 5 min; RPO 0 para sinais com ACK); Salesforce fora 2 h; restauração PITR em ambiente isolado (ensaio trimestral); compatibilidade de schema N com aplicação N-1. **CA-TST-08.1** — relatório de cada cenário anexado antes do go-live.

---
## 14. Requisitos de ambiente e pré-requisitos (Definition of Ready técnico)

### 14.1 Pré-requisitos da iniciativa

Coluna "Bloqueia": **Início** = impede começar o desenvolvimento; **Dev**/**Hom**/**Prod** = impede avançar para o ambiente. "Simulador?" indica se é possível desenvolver antes, com WireMock, Azurite, valores provisórios ou Plano B.

| ID | Pré-requisito | Categoria | SPECs afetadas | Responsável | QA ligada | Simulador? | Bloqueia |
|---|---|---|---|---|---|---|---|
| DOR-01 | Repositório `atacado-adesao` criado, acessos do time, proteção de branch e CODEOWNERS (Jurídico nos templates) | Acesso | TRV-01, DOC-04 | Plataformas Funcionais | QA-TEC-19 | — | **Início** |
| DOR-02 | Pipeline de CI capaz de rodar `./mvnw verify` com Testcontainers (Docker/Podman no agente) | Acesso / ferramenta | INF-02, TST-02 | Plataformas Funcionais | QA-TEC-19 | Não | **Início** |
| DOR-03 | Contrato API Adesão v1 aprovado com o time de Salesforce do Atacado | Contrato | API-01, TER-03..07, SFC-02, SFC-04 | Atacado Cash Payments | — | Não (é o primeiro acordo) | **Início** (dessas SPECs) |
| DOR-04 | Namespace `atacado-core` em Dev com quota, ServiceAccounts, permissão de deploy (GitOps) e registro de imagens | Acesso | INF-01, INF-03 | Plataformas Funcionais | QA-TEC-19 | Sim (local) | Dev |
| DOR-05 | Aprovação do PostgreSQL Flexible Server e do Blob no spoke | Aprovação | DB-01, STG-01, DOC-05 | Plataformas Funcionais | QA-TEC-12 | Sim (Testcontainers, Azurite; `bytea`) | Dev |
| DOR-06 | Padrão de IaC e responsável pelo provisionamento | Aprovação | INF-04, DB-01, STG-01, INF-06 | Plataformas Funcionais | QA-TEC-20 | Sim | Dev |
| DOR-07 | Key Vault da solução, CSI Driver e identidade de workload (ou service principal) | Credencial | TRV-10, INF-06, DB-02 | Plataformas Funcionais / Segurança | QA-TEC-14, PRM-TEC-08 | Sim (arquivos locais) | Dev |
| DOR-08 | Rotas de rede N-01..N-11 por ambiente (Axway interno → ingress privado; egress Salesforce; private endpoints; OTLP) | Rede | SEG-04, INF-05, REC-01..03, ACP-03 | Plataformas Funcionais | QA-TEC-09 | Sim | Dev (parcial) / Hom |
| DOR-09 | Mecanismo de autenticação ARO → Axway (LEAP ou equivalente) e credencial de Dev/Hom | Credencial | TRV-10, TRV-15, FIR-02, GAC-01 | Segurança | QA-TEC-03 | Sim | Hom |
| DOR-10 | Contrato FIRP, ambiente de Hom e massa de representantes fictícios | Contrato / ambiente | API-05, FIR-02, TST-05 | FIRP (via Atacado Cash Payments) | QA-TEC-05, QA-TEC-21 | Sim | Hom |
| DOR-11 | Contratos das 3 APIs GACD (+ consulta/cancelamento), nomes oficiais, onboarding como "Produto", usuário sistêmico emitido | Contrato / credencial | API-06, GAC-01..03 | GACD | QA-TEC-06, QA-TEC-04, QA-NEG-19, QA-TEC-24 | Sim | Hom |
| DOR-12 | Contrato do callback do GACD e cadastro da callbackUrl de Hom | Contrato | API-02, REC-01, TER-09 | GACD | QA-TEC-07 | Sim (ACL tolerante) | Hom |
| DOR-13 | Contrato do alerta aceito e política de autenticação do Canal | Contrato | API-03, REC-02, REC-03 | Canais | QA-TEC-08 | Sim | Hom |
| DOR-14 | Gate do IMPD: conectividade, Swagger, autenticação, template-piloto em AL2 | Contrato / rede | API-07, DOC-03 | IMPD (com Plataformas Funcionais) | QA-TEC-01, QA-TEC-02 | Sim (Plano B) | Decisão Plano A/B |
| DOR-15 | Limites de corpo e timeout em Akamai, AppGW e Axway | Rede | INF-05, TST-05 | Plataformas Funcionais | QA-TEC-10 | Sim | Hom |
| DOR-16 | Cabeçalhos de identidade e correlação propagados pelo Axway | Contrato de plataforma | REC-03, TRV-06, TRV-07 | Plataformas Funcionais | QA-TEC-22 | Sim (configurável) | Hom |
| DOR-17 | Objetos, Connected App, usuário de integração e sandbox Salesforce | Acesso / contrato | SFC-01..05, ACP-03, ACP-04, API-04 | Atacado Cash Payments (com Experiência) | QA-TEC-15 | Sim (stub) | Hom |
| DOR-18 | Certificados: mTLS do Salesforce, JWT Bearer, mTLS de GACD/Canal | Credencial | SFC-02, SFC-03, ACP-04, SEG-01 | Segurança | QA-TEC-26 | Sim (autoassinados em Dev) | Hom |
| DOR-19 | Coletor OTLP e ferramenta de observabilidade | Ferramenta | TRV-12, OBS-02 | Plataformas Funcionais | QA-TEC-16 | Sim (local) | Hom |
| DOR-20 | Ambientes integrados de Hom e massa de teste (GACD Hom com callback para ARO Hom, FIRP, IMPD CM2, sandbox) | Ambiente | TST-04, TST-05, E2E | Atacado Cash Payments (coordena) | QA-TEC-21 | Parcial | Hom |
| DOR-21 | Texto jurídico e variáveis dos 2 modelos, com dono e aprovação | Conteúdo | DOC-01, DOC-02, DOC-04, TST-07 | Atacado Cash Payments (Jurídico) | QA-CON-19, QA-NEG-10, QA-TEC-30 | Sim (modelo "MINUTA") | Hom (aceite) / Prod |
| DOR-22 | Prazos de retenção | Política | DB-04, SEG-03 | Atacado Cash Payments (com Segurança) | QA-TEC-17 | Sim (valores propostos) | Prod |
| DOR-23 | Modelo de operação da API admin e governança de flags em Prod | Processo | TER-12, ACP-05, TRV-14 | Atacado Cash Payments (com Plataformas Funcionais) | QA-TEC-27 | Sim | Prod |
| DOR-24 | Autorização de DAST/pentest e ferramenta padrão; integração com SIEM | Processo | TST-06, TRV-08 | Segurança | QA-TEC-29 | Não | Prod |

### 14.2 DoR técnico por task (checklist a aplicar no fatiamento)

1. A task cita a SPEC e os CA que atende.
2. As SPECs de que depende (seção 1.4) estão concluídas ou há simulador acordado.
3. Se a SPEC é PARCIAL, a task cobre só a parte não bloqueada, ou a QA bloqueante já foi respondida.
4. Contrato (OpenAPI/JSON Schema/stub) necessário está versionado no repositório.
5. Ambiente, credencial e rota necessários para validar os CA existem (tabela 14.1) ou o CA é verificável localmente.
6. Dados de teste sintéticos definidos (sem dado pessoal real).

---

## 15. Matriz de rastreabilidade

SPEC → COMP → RF/RNF → BC/CAP → RN/RNFN. Relações do context map (R-xx) e ADR aparecem nas SPECs.

| SPEC | COMP | RF | RNF | BC / CAP | RN / RNFN |
|---|---|---|---|---|---|
| SPEC-TRV-01 | 01, 02, 03 | — | RNF-13, RNF-16 | BC-01/02/03 · CAP-10.1 | — |
| SPEC-TRV-02 | 01, 02, 03 | — | RNF-13 | BC-01 | — |
| SPEC-TRV-03 | 01, 02, 03 | — | RNF-13 | BC-01/02/03/04 · CAP-10.1 | — |
| SPEC-TRV-04 | 01, 02 | RF-01, RF-07, RF-08 | RNF-01, RNF-04 | BC-01 · CAP-10.1 | RNFN-05 |
| SPEC-TRV-05 | 01, 02 | RF-01, RF-08 | RNF-13 | BC-01/03 · CAP-10.1, CAP-10.2 | — |
| SPEC-TRV-06 | 01 | RF-01, RF-05, RF-10 | RNF-05 | BC-01 · CAP-10.1 | RN-16 |
| SPEC-TRV-07 | 01, 02, 03 | RF-13 | RNF-10, RNF-11 | BC-01/03 · CAP-12.1 | RN-08; RNFN-01 |
| SPEC-TRV-08 | 01, 02, 03 | RF-13 | RNF-04, RNF-10, RNF-11 | CAP-11, CAP-12.1 | RNFN-05 |
| SPEC-TRV-09 | 01, 02, 03 | — | RNF-02, RNF-16 | CAP-11.2 | — |
| SPEC-TRV-10 | 01, 02, 03, 11 | RF-03, RF-06, RF-09 | RNF-02 | CAP-11.2 | — |
| SPEC-TRV-11 | 01, 03 | RF-03, RF-04, RF-06, RF-09 | RNF-09 | CAP-10.2 | — |
| SPEC-TRV-12 | 01, 02, 03, 19 | RF-13 | RNF-11 | CAP-09.4, CAP-12.1 | RNFN-07 |
| SPEC-TRV-13 | 01, 02, 03 | — | RNF-08, RNF-16 | — | — |
| SPEC-TRV-14 | 01, 03 | RF-04, RF-05, RF-12 | RNF-16 | BC-01/02/04 · CAP-03.1 | RN-10 |
| SPEC-TRV-15 | 01, 03 | RF-03, RF-06, RF-09 | RNF-01, RNF-09, RNF-10 | CAP-10.2, CAP-11.1 | RN-09 |
| SPEC-TER-01 | 01.1 | RF-01, RF-02, RF-05, RF-07, RF-08, RF-10 | RNF-13 | BC-01 · CAP-02.3, CAP-03.2 | RN-01, RN-03, RN-05, RN-08, RN-16 |
| SPEC-TER-02 | 01.1, 04 | RF-01 | RNF-05 | BC-01 · CAP-03.2 | RN-16 |
| SPEC-TER-03 | 01.1 | RF-01, RF-02 | RNF-05, RNF-07 | BC-01 · CAP-02.1, CAP-02.2, CAP-02.3, CAP-10.1 | RN-01, RN-02, RN-03, RN-04, RN-09, RN-16 |
| SPEC-TER-04 | 01.1, 01.4, 05 | RF-05, RF-11 | RNF-04, RNF-14 | BC-01/02 · CAP-03.2 | RN-09; RNFN-04 |
| SPEC-TER-05 | 01.1 | RF-05 | RNF-05, RNF-14 | BC-01 · CAP-02.3 | RN-05 |
| SPEC-TER-06 | 01.1 | RF-10 | RNF-05 | BC-01 · CAP-02.3 | RN-07 |
| SPEC-TER-07 | 01.1 | RF-10 | RNF-05 | BC-01 · CAP-03.2 | — |
| SPEC-TER-08 | 01.1 | RF-03, RF-04, RF-06, RF-14 | RNF-05, RNF-07, RNF-09 | BC-01 · CAP-02.3, CAP-10.4 | RN-05 |
| SPEC-TER-09 | 01.1 | RF-07, RF-08, RF-14 | RNF-05 | BC-01 · CAP-05.5, CAP-10.3 | RN-06, RN-07, RN-08 |
| SPEC-TER-10 | 01.1, 04 | RF-09, RF-12, RF-13 | RNF-05 | BC-01→BC-03 · CAP-10.4 | RN-10, RN-13 |
| SPEC-TER-11 | 01.1, 04 | RF-13 | RNF-10, RNF-14 | BC-01 · CAP-12.1 | RNFN-01, RNFN-02 |
| SPEC-TER-12 | 01.1 | RF-14 | RNF-16 | BC-01 · CAP-10.4 | — |
| SPEC-TER-13 | 01.1 | RF-09 | RNF-11 | BC-01/03 · CAP-09.2 | RN-07 |
| SPEC-FIR-01 | 01.2 | RF-03 | — | BC-01→BC-06 · CAP-04.1 | RN-05 |
| SPEC-FIR-02 | 01.2, 09, 13 | RF-03 | RNF-01, RNF-04, RNF-09 | BC-06 · CAP-04.1, CAP-10.2 | RN-05, RN-09; RNFN-05 |
| SPEC-GAC-01 | 01.3, 09, 14 | RF-06 | RNF-01, RNF-15 | BC-01→BC-07 · CAP-05.1, CAP-05.2, CAP-05.3 | RN-08, RN-15 |
| SPEC-GAC-02 | 01.3, 04 | RF-06, RF-14 | RNF-05, RNF-07, RNF-09 | BC-07 · CAP-05.1..05.3 | RN-08 |
| SPEC-GAC-03 | 01.3 | RF-14 | RNF-09 | BC-07 · CAP-05.1, CAP-10.4 | — |
| SPEC-DOC-01 | 01.4 | RF-04 | RNF-14 | BC-02 · CAP-03.3 | RN-03; RNFN-02 |
| SPEC-DOC-02 | 01.4 | RF-04 | RNF-13 | BC-02 · CAP-03.1, CAP-08.1 | RN-01, RN-03 |
| SPEC-DOC-03 | 01.4, 16 | RF-04 | RNF-13, RNF-14 | BC-02→BC-09 · CAP-08.1 | — |
| SPEC-DOC-04 | 01.4 | RF-04 | RNF-14 | BC-02 · CAP-08.1 | RNFN-02 |
| SPEC-DOC-05 | 01.4, 05 | RF-04, RF-05, RF-06, RF-11 | RNF-04, RNF-14, RNF-15 | BC-02 · CAP-08.1, CAP-12.1 | RNFN-05 |
| SPEC-ELG-01 | 01.5 | RF-02 | RNF-13 | BC-01→BC-13 · CAP-02.1, CAP-02.2 | RN-02, RN-03, RN-04 |
| SPEC-CNV-01 | 01.6 | RF-12 | RNF-13 | BC-04 · CAP-06.1, CAP-06.2 | RN-10, RN-11, RN-13, RN-17 |
| SPEC-REC-01 | 02 | RF-07 | RNF-01, RNF-05, RNF-08 | BC-01 (borda) · CAP-05.5, CAP-10.3 | RN-08 |
| SPEC-REC-02 | 02 | RF-08 | RNF-04, RNF-05, RNF-08 | BC-01←BC-10 · CAP-09.5, CAP-10.3 | RN-06, RN-07 |
| SPEC-REC-03 | 02, 09 | RF-07, RF-08 | RNF-01 | CAP-11.1 | — |
| SPEC-REC-04 | 02, 04 | RF-07, RF-08 | RNF-05, RNF-08 | BC-01 · CAP-10.3 | — |
| SPEC-ACP-01 | 03, 04 | RF-09 | RNF-05, RNF-06 | BC-03 · CAP-10.4 | — |
| SPEC-ACP-02 | 03 | RF-08, RF-09 | RNF-06 | BC-03 · CAP-09.1, CAP-09.2 | RN-07 |
| SPEC-ACP-03 | 03, 06, 12 | RF-09 | RNF-05, RNF-06 | BC-03→BC-05 · CAP-09.1 | RN-09; RNFN-03 |
| SPEC-ACP-04 | 03, 06, 11 | RF-09 | RNF-01, RNF-02 | CAP-11.1 | — |
| SPEC-ACP-05 | 03 | RF-14 | RNF-11, RNF-16 | BC-03 · CAP-10.4 | — |
| SPEC-DB-01 | 04 | — | RNF-03, RNF-08, RNF-12 | CAP-11.3 | — |
| SPEC-DB-02 | 04 | — | RNF-03, RNF-04 | CAP-11.3 | RNFN-05 |
| SPEC-DB-03 | 04, 01 | — | RNF-16 | — | — |
| SPEC-DB-04 | 04 | RF-13 | RNF-04, RNF-10 | CAP-12.1 | RNFN-05, RNFN-06 |
| SPEC-STG-01 | 05 | RF-04, RF-05 | RNF-03, RNF-04, RNF-14 | BC-02 · CAP-08.1 | RNFN-05 |
| SPEC-SFC-01 | 06 | RF-09 | RNF-06 | BC-05 · CAP-09.1 | RN-09; RNFN-03 |
| SPEC-SFC-02 | 06, 07, 08, 09 | RF-01, RF-05, RF-10, RF-11 | RNF-01, RNF-02 | BC-05 · CAP-01, CAP-10.1 | RN-04, RN-09 |
| SPEC-SFC-03 | 06 | RF-09 | RNF-01, RNF-02 | BC-05 · CAP-11.1 | — |
| SPEC-SFC-04 | 06 | RF-01, RF-05, RF-10, RF-11 | — | BC-05 · CAP-09.1 | RN-04; RFN-01, RFN-04 |
| SPEC-SFC-05 | 06 | RF-08, RF-09 | — | BC-05 · CAP-09.2 | RN-07 |
| SPEC-API-01 | 01, 06, 09 | RF-01, RF-05, RF-10, RF-11 | RNF-01 | BC-01→BC-05 (R-01) · CAP-10.1 | RN-09 |
| SPEC-API-02 | 02, 14 | RF-07 | RNF-01 | BC-07→BC-01 (R-06) · CAP-05.5 | RN-08 |
| SPEC-API-03 | 02, 18 | RF-08 | RNF-04 | BC-01↔BC-10 (R-13) · CAP-09.5 | RN-06, RN-07 |
| SPEC-API-04 | 03, 06 | RF-09 | RNF-06 | BC-03→BC-05 (R-02) · CAP-09.1 | — |
| SPEC-API-05 | 01.2, 13 | RF-03 | — | R-04 · CAP-04.1 | RN-05 |
| SPEC-API-06 | 01.3, 14 | RF-06 | RNF-15 | R-05 · CAP-05.1..05.3 | RN-08, RN-15 |
| SPEC-API-07 | 01.4, 16 | RF-04 | RNF-15 | R-10 · CAP-08.1 | — |
| SPEC-EVT-01 | 01, 03 | RF-09, RF-12, RF-13 | RNF-05 | BC-01→BC-03 (R-14) · CAP-10.4 | RN-10, RN-13 |
| SPEC-EVT-02 | 01, 03 | — | RNF-13 | CAP-10.4 | — |
| SPEC-SEG-01 | Todos | RF-01, RF-03, RF-06, RF-07, RF-08, RF-09 | RNF-01, RNF-02 | CAP-11.1 | RN-09 |
| SPEC-SEG-02 | 01, 02, 03 | RF-01, RF-07, RF-08 | RNF-01 | CAP-11.1 | RN-09 |
| SPEC-SEG-03 | Todos | RF-03, RF-08 | RNF-04 | CAP-11, CAP-12.1 | RNFN-05, RNFN-06 |
| SPEC-SEG-04 | 10, 12 | RF-09 | RNF-03 | CAP-11.3 | RN-09 |
| SPEC-SEG-05 | 01, 02, 03 | — | RNF-01 | CAP-11.1 | — |
| SPEC-SEG-06 | Pipeline | — | RNF-01 | CAP-11 | — |
| SPEC-INF-01 | 10 | — | RNF-08, RNF-12 | — | — |
| SPEC-INF-02 | Pipeline | — | RNF-16 | — | — |
| SPEC-INF-03 | Todos | — | RNF-16 | — | — |
| SPEC-INF-04 | 04, 05, 11 | — | RNF-03 | CAP-11.3 | — |
| SPEC-INF-05 | 07, 08, 09 | RF-01, RF-03, RF-06, RF-07, RF-08 | RNF-01, RNF-15 | CAP-10.2 | RN-09 |
| SPEC-INF-06 | 11 | — | RNF-02 | CAP-11.2 | — |
| SPEC-OBS-01 | Todos | RF-13 | RNF-06, RNF-07, RNF-11 | CAP-09.4 | RNFN-07 |
| SPEC-OBS-02 | 19 | — | RNF-11 | CAP-09.4 | — |
| SPEC-OBS-03 | 01, 03 | RF-13 | RNF-10 | CAP-09.4, CAP-12.1 | RNFN-01, RNFN-07 |
| SPEC-TST-01 | Todos | Todos | RNF-13 | — | — |
| SPEC-TST-02 | 01, 02, 03, 04 | RF-01, RF-07, RF-08, RF-09 | RNF-05 | CAP-10.4 | RN-16 |
| SPEC-TST-03 | 01, 03 | RF-03, RF-04, RF-06, RF-09 | RNF-09 | — | — |
| SPEC-TST-04 | 01, 02, 03, 06 | RF-01, RF-07, RF-08, RF-09 | RNF-13 | CAP-10.1, CAP-10.3 | — |
| SPEC-TST-05 | Todos | RF-01, RF-09 | RNF-06, RNF-07, RNF-12 | — | — |
| SPEC-TST-06 | Todos | — | RNF-01, RNF-04 | CAP-11 | RNFN-05 |
| SPEC-TST-07 | 01.4, 16 | RF-04 | RNF-14, RNF-15 | CAP-03.3, CAP-08.1 | RN-01, RN-03; RNFN-02 |
| SPEC-TST-08 | Todos | RF-06, RF-14 | RNF-05, RNF-08, RNF-09 | CAP-10.4 | — |

**Cobertura reversa (todo RF e RNF tem ao menos uma SPEC responsável)**

| Requisito | SPECs principais |
|---|---|
| RF-01 | TER-03, API-01, SFC-02, SFC-04 |
| RF-02 | TER-03, ELG-01 |
| RF-03 | FIR-01, FIR-02, TER-08, API-05 |
| RF-04 | DOC-01..05, TER-08, API-07 |
| RF-05 | TER-04, TER-05, SFC-04 |
| RF-06 | GAC-01, GAC-02, API-06 |
| RF-07 | REC-01, TER-09, API-02 |
| RF-08 | REC-02, TER-09, ACP-02, API-03 |
| RF-09 | ACP-01..03, SFC-01, API-04 |
| RF-10 | TER-06, TER-07, SFC-04 |
| RF-11 | TER-04 (prévia; termo assinado em QA-TEC-18) |
| RF-12 | CNV-01, TER-10, EVT-01 |
| RF-13 | TER-11, OBS-01, OBS-03 |
| RF-14 | TER-12, GAC-03, ACP-05 |
| RNF-01..16 | RNF-01 SEG-01/02; RNF-02 TRV-10, INF-06; RNF-03 SEG-04, DB-01, STG-01; RNF-04 SEG-03, TRV-08; RNF-05 TRV-06, TER-10, ACP-01; RNF-06 ACP-03; RNF-07 TER-03, TER-08, GAC-02; RNF-08 REC-04, INF-01, TRV-13; RNF-09 TRV-11; RNF-10 TER-11, TRV-07; RNF-11 OBS-01/02; RNF-12 INF-01, TST-05; RNF-13 TRV-03; RNF-14 DOC-01, DOC-05; RNF-15 INF-05, DOC-02; RNF-16 TER-12, TRV-14 |

---

## 16. Questões em aberto técnicas adicionais

Novas questões surgidas no detalhamento. Não duplicam QA-TEC-01..18 (04 §15), QA-CON, QA-CONV, QA-NEG nem QA-DDD; quando se relacionam, a relação é indicada.

| ID | Questão | Time responsável | Relação | Impacto (SPECs) |
|---|---|---|---|---|
| QA-TEC-19 | **Esteira CI/CD e GitOps para o ARO:** ferramentas padrão (pipeline, GitOps, registro de imagens), gates obrigatórios (SAST/SCA/DAST), suporte a Testcontainers no agente, assinatura de imagem e hook pré-deploy para Job de migração | Plataformas Funcionais | PRM-TEC-09, PRM-TEC-16 | INF-02, DB-03, SEG-06, TRV-01 |
| QA-TEC-20 | **IaC e responsabilidade de provisionamento:** Terraform ou Bicep, módulos corporativos, quem aplica e onde fica o state dos recursos da solução (PostgreSQL, Blob, Key Vault, private endpoints, identidades) | Plataformas Funcionais | QA-TEC-12, PRM-TEC-17 | INF-04, DB-01, STG-01, INF-06 |
| QA-TEC-21 | **Ambientes integrados de homologação e massa de teste:** GACD Hom apto a chamar o callback do ARO Hom; FIRP Hom com representantes fictícios; IMPD CM2; sandbox Salesforce; CNPJs de teste consistentes entre sistemas | Atacado Cash Payments (coordena com GACD, FIRP e IMPD) | QA-TEC-05 (Hom FIRP) | INF-03, TST-04, TST-05 |
| QA-TEC-22 | **Identidade e cabeçalhos propagados pelo Axway ao backend:** nome/formato do cabeçalho ou JWT com `client_id`/DN do certificado; remoção de cabeçalhos forjados; preservação de `X-Correlation-ID`, `traceparent` e `Idempotency-Key` | Plataformas Funcionais | QA-TEC-03 | REC-03, TRV-06, TRV-07, SEG-02, INF-05 |
| QA-TEC-23 | **Política de versionamento e depreciação de APIs no Axway:** convivência v1/v2, prazo mínimo, uso de `Deprecation`/`Sunset`, catálogo | Plataformas Funcionais | — | TRV-05, API-01..03 |
| QA-TEC-24 | **Identificação de assinantes exigida pelo GACD no passo 1:** CPF, id FIRP ou outro? Se CPF, a especificação propõe nova consulta à FIRP no momento do passo 1, sem persistir o CPF; o GACD confirma que aceita esse desenho? | GACD (com Segurança para LGPD) | QA-TEC-06 (payloads), QA-DDD-04 | GAC-01, FIR-02, SEG-03, API-06 |
| QA-TEC-25 | **CNPJ alfanumérico:** FIRP, GACD, templates do IMPD, Canal e Salesforce já aceitam o novo formato (vigente para novas inscrições desde julho/2026)? | Atacado Cash Payments (com GACD, FIRP, IMPD e Canais) | — | TRV-02, API-01..06, TST-07 |
| QA-TEC-26 | **Emissão e rotação de certificados:** CA (corporativa ou autoassinada) para o mTLS do Salesforce, o JWT Bearer e o mTLS de GACD/Canal; validade; processo coordenado de rotação entre Salesforce, Axway e Key Vault | Segurança | QA-TEC-15 (suporte a mTLS na Named Credential) | SEG-01, SFC-02, SFC-03, ACP-04, INF-06 |
| QA-TEC-27 | **Operação em produção:** quem opera a API administrativa (sustentação do Atacado ou operação central), acesso por `port-forward` em Prod, exigência de RDM para mudança de feature flag | Atacado Cash Payments (com Plataformas Funcionais) | — | TER-12, ACP-05, TRV-14 |
| QA-TEC-28 | **Extensões e parâmetros do PostgreSQL Flexible Server:** `pg_cron`, `pg_partman`, `pgaudit`, `max_connections`, PgBouncer embutido; permissão para particionamento nativo e CronJob de manutenção | Plataformas Funcionais | QA-TEC-12, QA-TEC-14 (Entra ID) | DB-01, DB-04, INF-04 |
| QA-TEC-29 | **Testes de segurança e SIEM:** autorização e ferramenta para DAST/pentest em Hom atrás do Axway; integração dos eventos de autenticação negada com o SIEM corporativo | Segurança | — | TST-06, SEG-06, TRV-08 |
| QA-TEC-30 | **Snapshot da Proposta para as variáveis do modelo:** quais campos o Salesforce deve enviar em `POST /v1/adesoes` (razão social, endereço, nomes de produtos, dados do Gerente, condições) para compor o termo nos dois tipos | Atacado Cash Payments (com Jurídico) | QA-NEG-10 (conteúdo), QA-CON-19 (dono do texto) | TER-03, DOC-02, API-01, SFC-02 |

**Questões existentes que mais bloqueiam o início de SPECs** (sem repetir o texto): QA-TEC-01/02 (DOC-03), QA-TEC-05 (FIR-02), QA-TEC-06/04 (GAC-01, GAC-03), QA-TEC-07 (REC-01, TER-09), QA-TEC-08 (REC-02), QA-TEC-12 (DB-01, STG-01), QA-TEC-15 (SFC, ACP-03/04), QA-TEC-03 (autenticação de saída), QA-TEC-09 (rede), QA-TEC-17 (retenção), QA-TEC-18 (termo assinado, fora das SPECs atuais), QA-NEG-18 (default da confirmação), QA-DDD-02 (cancelar protocolo na reemissão), QA-DDD-12 (sem assinantes).

---

## 17. Inconsistências encontradas e tratamento

| # | Onde | Inconsistência | Tratamento neste documento |
|---|---|---|---|
| I-01 | 03 §5.1 × 04 §9.2 / 04a COMP-03 | O 03 prevê o BC-01 consumindo os próprios eventos (`TermoSolicitado` → identificar assinantes) via outbox; o 04 faz do COMP-03 o consumidor da outbox (coluna de situação única) | Fila de tarefas interna `adesao_termo.tarefa` criada na mesma transação da transição; outbox com consumidor único [DT-05]. INV-10 preservada |
| I-02 | 03 §5.2 × 04 §9.3 | `correlationId` = `codigoProtocolo`/`idAdesao` (03) × `X-Correlation-ID` do Salesforce (04) | Envelope com `correlationId` (técnico) e `chaveCorrelacaoNegocio` (negócio) [DT-08] |
| I-03 | 04 §11.1 | Repetição com a mesma `Idempotency-Key` responde `200` | Mantém o status original (`202`) + `Idempotent-Replayed: true` [DT-06]; registrar na revisão do 04 |
| I-04 | 04 §11.1 | `correlationId` listado no corpo de `POST /v1/adesoes` | Movido para o cabeçalho `X-Correlation-ID` (padrão transversal); campo do corpo ignorado se enviado |
| I-05 | 04a ER (COMP-04) × 03 §3.2 | O agregado tem `produtos[]` (`ProdutoAderido`), mas o modelo físico não tinha tabela | Tabela `produto_aderido` |
| I-06 | 04a ER × 04 §10 | Unicidade da inbox: `chave_idempotencia` (04a) × `origem` + `chaveIdempotencia` (04) | Unicidade composta `(origem, chave_idempotencia)` |
| I-07 | 04 §7.1 | "EgressFirewall libera COMP-03 → FQDN do Salesforce", mas o EgressFirewall do OVN-Kubernetes vale para o namespace inteiro | NetworkPolicy de egress por pod + EgressFirewall do namespace + EgressIP (se disponível) [DT-20] |
| I-08 | 04a COMP-01.2 × passo 1 do GACD **[FATO: 04]** | A ACL-FIRP descarta CPF, mas o GACD pode exigir identificação dos assinantes (possivelmente CPF) no passo 1, horas ou dias depois (após a confirmação) | Porta do GACD com identificador opaco; proposta de reconsultar a FIRP no passo 1, só em memória; nova QA-TEC-24 |
| I-09 | 03 §3.4 / §6 × 04 §11.4 | `AdesaoDispensada` não cria agregado (sem `idAdesao`), mas o upsert no Salesforce usa `Id_Adesao__c` | Tabela `decisao_elegibilidade`; `idDecisao` usado como `Id_Adesao__c` do registro "Não requerido" |
| I-10 | 03 §5.1 × 04 §9.2 | Eventos internos (`AssinantesConfirmados`, `ProtocoloAberto`, `PreviaArmazenada`, `RegraCoordenada`) × outbox "com eventos de domínio" | Internos ficam só na auditoria e na saga; não vão à outbox |
| I-11 | 03 §6 × ADR-02 | Confirmação entre Assinantes identificados e Gerado (03) × no estado Gerado (04) | Segue o 04 (já registrado no 04 §17); o 03 permanece com a nota de consolidação |
| I-12 | 03 §6 (sem cancelamento em Gerado) × ADR-02 | Com a prévia em Gerado, o Gerente pode desistir antes do envio, mas não há transição | Nova transição T-17 como **proposta** compatível com PRM-DDD-10 [DT-16] |
| I-13 | 03 §5.1 × 04 §11.4 | `StatusJornadaAtualizado` e `AlertaGerenteEmitido` como eventos publicados (03) × materializados como upsert (04) | Mantido o 04: não são eventos de outbox nesta entrega |
| I-14 | 04a §1.2 (springdoc como contrato) × necessidade de acordar contratos antes do código | — | YAML como fonte; springdoc só em teste para detectar divergência [DT-03] |
| I-15 | 04a §1.2 ("Data JDBC/JPA") | Escolha aberta | Spring Data JDBC + `JdbcClient` [DT-04] |
| I-16 | 04 §9.2 (estados da saga `ETAPA_n_PENDENTE`) | Estado e etapa no mesmo campo | Separados em `etapa` + `estado`; correspondência na seção 9.1 |
| I-17 | 04 §11.3 × 04a COMP-02 | Caminhos `/atacado/adesao/v1/...` × `/v1/...` | Não é conflito: prefixo público no Axway, reescrito para o caminho do serviço (SPEC-TRV-05, SPEC-INF-05) |

Na v0.1, nenhum outro documento foi alterado. **Consolidação Rodada 2:** as correções foram propagadas para a fonte — 03 v0.2 (notas em §3.2, §5.1, §5.2 e §6: I-01, I-02, I-09..I-13), 04 v0.2 (§7.1, §8.3, §9.2, §9.3, §10, §11.1, §11.4 e §17: I-01..I-04, I-07..I-10, I-16) e 04a v0.2 (§1.2, COMP-01, COMP-01.2, COMP-03 e modelo de dados do COMP-04: I-01, I-05, I-06, I-07, I-08, I-09, I-14, I-15). I-17 não exigia correção.

---

## 18. Referências

- `01-contexto-de-negocio.md` — RN-01..16, RFN-01..12, RNFN-01..07, QA-NEG, QA-CONV.
- `02-desenho-conceitual.md` — CAP-xx, APP-02.x, PRI-01..13, DEC-CON-xx, KPI-01..05, QA-CON.
- `03-dominios-bounded-contexts-context-mapping.md` — BC-xx, R-xx, INV-01..10, eventos, máquina de estados, QA-DDD, PRM-DDD.
- `04-desenho-arquitetura-solucao.md` — RF-01..14, RNF-01..16, ADR-01..12, RSK-01..17, QA-TEC-01..18, PRM-TEC-01..15.
- `04a-componentes-e-justificativas.md` — COMP-01..31, stack-padrão, modelo de dados indicativo.
- Fontes: [04] Confluence GACD (3 chamadas + callback); [05] [06] IMPD; [stack] `stack-tech.md`; [CG] Contexto Geral; `AGENTS.md` (padrão mínimo de projeto).
- Normas técnicas citadas: RFC 9457 (Problem Details), RFC 8594 (`Sunset`), RFC 9745 (`Deprecation`), W3C Trace Context, IETF draft `Idempotency-Key`, JSON Schema 2020-12, OpenAPI 3.1, PDF/A-2b (ISO 19005-2).
