# Bootstrap — WSL + RHEL + Podman em um script

Nov 10, 2026 · @Italo

## 1. O que é

Um `.bat` no Windows que dispara um `.sh` dentro do RHEL e deixa o Podman pronto do zero: os 3 arquivos de config, login no JFrog e um pull de teste. Serve pra recriar a distro depois de reinstalar a imagem pela loja, ou pra montar numa máquina nova. O passo a passo e o porquê de cada config estão no *Manual — WSL + RHEL + Podman no Bradesco*; aqui é só execução.

Precisa existir antes:

- WSL 2.4.11 e a imagem RHEL instalados pela loja interna, com reboot feito. `wsl -l -v` tem que listar a distro.
- Identity Token do JFrog em mãos (UI → Edit Profile → Generate an Identity Token). O script pede no terminal, não grava em arquivo.
- Rede do WSL funcionando (se a VPN derrubou, resolver antes — seção 3 do manual).

## 2. Pasta `wsl-config`

Tudo em `C:\Users\<matrícula>\wsl-config\`. Fica fora da distro, então sobrevive a `unregister`. Pode virar repo de dotfiles — **sem** `auth.json`.

```
wsl-config\
├── setup-wsl.bat        ← roda no Windows
├── setup-rhel.sh        ← roda dentro do RHEL (chamado pelo .bat)
├── containers.conf
├── 50-search.conf
├── 60-aliases.conf
└── site\
    └── index.html       ← página servida pelo nginx de teste
```

Os 3 `.conf` são os mesmos do manual (seções 4 e 5). Pra editar a lista de aliases, mexe no `60-aliases.conf` da pasta e roda o `.bat` de novo — ele sobrescreve.

**site\\index.html** — qualquer coisa; o nginx do banco é S2I e sem conteúdo devolve 403, então sem isso o teste no browser parece erro.

```html
<!doctype html>
<h1>WSL + RHEL + Podman funcionando</h1>
<p>nginx no container, porta 8080, servido pelo Windows via localhost.</p>
```

**containers.conf**

```toml
[engine]
cgroup_manager = "cgroupfs"
events_logger = "file"
```

**50-search.conf**

```toml
unqualified-search-registries = ["artefatos.bradesco.com.br"]
short-name-mode = "enforcing"
```

**60-aliases.conf**

```toml
[aliases]
"redis"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/redis"
"python"     = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/python"
"postgres"   = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/postgres"
"mongo"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/mongo"
"grafana"    = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/grafana"
"loki"       = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/loki"
"tempo"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/grafana/tempo"
"fluent-bit" = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/fluent/fluent-bit"
"localstack" = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/localstack/localstack-azure"
"ubi10"      = "artefatos.bradesco.com.br/public-external-images/external-images/docker.io/redhat/ubi10"
"nginx"      = "artefatos.bradesco.com.br/devtools-docker-central/base-images/ubi8/nginx-126"
```

Salvar os `.sh` e `.conf` com quebra de linha **LF**, não CRLF — bash e TOML quebram com `\r`. No VS Code: canto inferior direito, clicar em CRLF → LF. O `.bat` pode ser CRLF.

## 3. `setup-wsl.bat`

Valida que a distro existe, converte o caminho da pasta pro formato Linux e chama o `.sh` dentro do RHEL. Ajustar `DISTRO` pro nome que aparece em `wsl -l -v`.

```bat
@echo off
setlocal

set DISTRO=RHEL
set SRC=%~dp0
set SRC=%SRC:~0,-1%

wsl -d %DISTRO% -- true 2>nul
if errorlevel 1 (
  echo Distro %DISTRO% nao encontrada. Confira com: wsl -l -v
  exit /b 1
)

for /f "delims=" %%p in ('wsl -d %DISTRO% -- wslpath -u "%SRC%"') do set WSRC=%%p

echo Rodando setup-rhel.sh em %DISTRO% a partir de %WSRC% ...
wsl -d %DISTRO% -- bash -c "tr -d '\r' < '%WSRC%/setup-rhel.sh' | bash -s -- '%WSRC%'"

if errorlevel 1 (
  echo FALHOU. Veja a saida acima.
  exit /b 1
)
echo OK.
```

O `tr -d '\r' | bash -s` faz o `.sh` rodar mesmo se tiver sido salvo com CRLF. O `%~dp0` é a pasta onde o `.bat` está — não precisa de caminho fixo.

## 4. `setup-rhel.sh`

Recebe a pasta `wsl-config` como argumento, copia os `.conf` (limpando `\r`), confere o cgroup manager, loga no JFrog só se ainda não estiver logado e faz um pull de teste. Idempotente: rodar de novo só sobrescreve os `.conf`.

```bash
#!/usr/bin/env bash
set -euo pipefail

SRC="${1:?uso: setup-rhel.sh <pasta wsl-config>}"
REG=artefatos.bradesco.com.br
DST="$HOME/.config/containers"
CTN=bootstrap-nginx

cp_lf() { tr -d '\r' < "$1" > "$2"; }

# 1. config do Podman (manual, secoes 4 e 5)
mkdir -p "$DST/registries.conf.d"
cp_lf "$SRC/containers.conf" "$DST/containers.conf"
cp_lf "$SRC/50-search.conf"  "$DST/registries.conf.d/50-search.conf"
cp_lf "$SRC/60-aliases.conf" "$DST/registries.conf.d/60-aliases.conf"
echo "[1/4] config copiada para $DST"

# 2. confere que o Podman leu o containers.conf
CG=$(podman info --format '{{.Host.CgroupManager}}')
[[ "$CG" == "cgroupfs" ]] || { echo "cgroup manager = $CG (esperava cgroupfs)"; exit 1; }
echo "[2/4] podman ok ($(podman --version), cgroup=$CG)"

# 3. login no JFrog (pede usuario + identity token; so grava no auth.json)
if podman login --get-login "$REG" >/dev/null 2>&1; then
  echo "[3/4] ja logado em $REG como $(podman login --get-login "$REG")"
else
  echo "[3/4] login em $REG — usuario do JFrog + Identity Token:"
  podman login "$REG"
fi

# 4. nginx do banco via alias, servindo site/ na 8080, e deixa rodando
podman rm -f "$CTN" >/dev/null 2>&1 || true
podman pull nginx >/dev/null
podman run -d --name "$CTN" -p 8080:8080 -v "$SRC/site:/opt/app-root/src:ro" nginx >/dev/null
sleep 2
CODE=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:8080 || echo 000)
[[ "$CODE" == "200" ]] || { echo "nginx respondeu $CODE em localhost:8080"; podman logs "$CTN"; exit 1; }
echo "[4/4] nginx no ar — abra http://localhost:8080 no browser do Windows"
```

O container `bootstrap-nginx` fica rodando de propósito, pra abrir no browser. Some no próximo `wsl --shutdown`; pra tirar antes: `podman rm -f bootstrap-nginx`. As imagens UBI escutam na 8080 sem root — por isso `-p 8080:8080`, não `8080:80`.

## 5. Rodar e verificar

No Explorer, duplo clique em `setup-wsl.bat`, ou no PowerShell:

```powershell
cd $env:USERPROFILE\wsl-config
.\setup-wsl.bat
```

Saída esperada:

```
Rodando setup-rhel.sh em RHEL a partir de /mnt/c/Users/<matrícula>/wsl-config ...
[1/4] config copiada para /home/<user>/.config/containers
[2/4] podman ok (podman version 5.x, cgroup=cgroupfs)
[3/4] login em artefatos.bradesco.com.br — usuario do JFrog + Identity Token:
Username: ...
Password:
Login Succeeded!
[4/4] nginx no ar — abra http://localhost:8080 no browser do Windows
OK.
```

Na segunda vez em diante o passo 3 vira `ja logado em ... como <usuario>` e não pede nada.

Aí é abrir **http://localhost:8080** no Edge/Chrome do Windows: tem que aparecer a página do `site\index.html`. Isso fecha a prova toda — config lida, alias resolvendo no JFrog, credencial ok e Windows alcançando o container.

Conferência manual, se quiser:

| O quê | Comando | Esperado |
| --- | --- | --- |
| Config lida | `podman info --format '{{.Host.CgroupManager}}'` | `cgroupfs` |
| Alias ativo | `podman pull nginx` | sem erro de short-name |
| Container no ar | `podman ps` | `bootstrap-nginx` com `0.0.0.0:8080->8080` |
| Windows → container | `curl.exe -I http://localhost:8080` no PowerShell | `HTTP/1.1 200 OK` |

Se parar em algum passo, a tabela de troubleshooting do manual (seção 9) cobre os erros que já apareceram.
