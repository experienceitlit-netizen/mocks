---
description: "Epic-flow: painel de status dos artefatos, gates pendentes e questões Q-nnn abertas (geral, por épico ou feature)"
argument-hint: "[EP-nn|FT-nn.nn]"
---
Você é o orquestrador do epic-flow. Somente leitura: não altere nenhum arquivo.

Argumentos: `$ARGUMENTS` (vazio = todos os épicos)

1. Leia o frontmatter (`id`, `tipo`, `titulo`, `status`, `versao`, `gate`, `questoes-abertas`) dos artefatos em `epic-flow/epicos/` (filtrando pelo argumento), do mapa `epic-flow/epicos/mapa-epicos.md` (com a tabela de épicos e a situação de cada um) as fichas em `epic-flow/insumos/` as fichas do épico em `epic-flow/epicos/EP-*/insumos/` e as de feature e história em `.../features/FT-*/insumos/` e `.../historias/insumos/US-*/`.
2. Leia `epic-flow/transversal/decisoes-e-questoes.md` e selecione as Q-nnn `aberta` que afetam o recorte (critério do passo 1 de `.claude/commands/ef-esclarecer.md`), com a `prioridade` de cada uma (sem `prioridade` conta como `importante`). Aplique a trava de bloqueantes (`epic-flow/processo/01-fluxo.md` §4, "Trava de bloqueantes", tabela de alvo e entradas por comando) a cada artefato e a cada próximo comando possível: estão **BLOQUEADOS** os que têm Q-nnn `bloqueante` aberta ligada ao alvo, às entradas upstream ou à etapa (`E0`…`E6`).
3. Mostre:
   - **BLOQUEADOS** primeiro e em destaque: etapas (comando que não pode rodar) e artefatos (gate recusado ou artefato retido em `rascunho`), cada um com as Q-nnn bloqueantes que o travam e o próximo passo `/ef-esclarecer <ID>`;
   - mapa de épicos (status, gate G0) e árvore EP → FT → US/SP/TK com status de cada um;
   - **gates aguardando você** (artefatos `em-revisao`, com o gate e o aprovador);
   - **próximos comandos possíveis**, marcando como BLOQUEADO o que a trava impede (ex.: fichas sem mapa → `/ef-mapa-epicos`; épico `proposto` do mapa aprovado ainda sem PRD → `/ef-epico EP-nn [insumos=<pasta>]`; PRD aprovado sem `arquitetura-referencia.md` → `/ef-arq-ref EP-nn`);
   - Q-nnn abertas: contagem por prioridade (bloqueante, importante, menor) e por artefato, com o que cada bloqueante trava e as reclassificadas (`reclassificada-por`); se houver bloqueante, o próximo passo é `/ef-esclarecer <ID>`; se houver só importante, sugira `/ef-esclarecer <ID>` (ou `/ef-esclarecer todas`);
   - inconsistências encontradas (ID sem pai, `EP-nn` com PRD fora do mapa ou `descartado`, artefato aprovado com entrada não aprovada, artefato `em-revisao` ou `aprovado` com Q-nnn `bloqueante` aberta ligada, frontmatter incompleto).
