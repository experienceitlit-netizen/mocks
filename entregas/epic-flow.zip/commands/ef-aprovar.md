---
description: "Epic-flow: registra a aprovação humana de um gate (G0–G6) em um artefato e nos filhos que o gate cobre"
argument-hint: "<ID> [por=<nome/papel>] [obs=<comentário>]"
---
Você é o orquestrador do epic-flow. Este comando registra uma decisão **do usuário humano**; os agentes nunca o executam por conta própria.

Argumentos: `$ARGUMENTS`

1. Localize o artefato pelo ID (MAPA → `epicos/mapa-epicos.md`, G0, junto com as fichas `IN-nnn` listadas em `insumos` do mapa; EP-nn → `prd.md`, G1, junto com as fichas `IN-EPnn-nn` listadas em `insumos` do PRD (`epicos/EP-nn-<slug>/insumos/`); AR-nn → `arquitetura-referencia.md`; FT-nn.nn → `feature.md` + `historias/*`, junto com as fichas `IN-FTnn.nn-nn` (`insumos/` da feature) e `IN-USnn.nn.nn-nn` (`historias/insumos/US-*/`) delas; AS-nn.nn → `arquitetura-solucao.md`; SP-nn.nn.nn → spec + suas tasks; TK-… → task; AD-nn → ADR).
2. Só aprove artefatos em `em-revisao`. Exceção, task no **G6**: task `aprovado` com `execucao: em-review` e PR revisado; nesse caso grave `execucao: concluida`, `g6-aprovado-por` e `g6-aprovado-em` (não mexa em `status`/`versao`). Em outro estado, pare e explique.
3. **Trava de bloqueantes** (`epic-flow/processo/01-fluxo.md` §4, "Trava de bloqueantes"). Leia `epic-flow/transversal/decisoes-e-questoes.md` e liste as Q-nnn `aberta` com `prioridade: bloqueante` ligadas ao artefato e aos filhos que o gate cobre (critério do passo 1 de `.claude/commands/ef-esclarecer.md`). Se houver qualquer uma, o gate é **recusado**: não há aprovação com bloqueante aberta. Mostre-as e ofereça com AskUserQuestion (`header: "Bloqueantes"`):
   - `Esclarecer agora`: execute a rodada obrigatória (`.claude/commands/ef-esclarecer.md`, "Modo rodada obrigatória", com incorporação) com essas Q-nnn. Com `LIBERADO`, recomece do passo 2, porque a incorporação gera nova versão do artefato; com `BLOQUEADO`, encerre sem alterar status, informando que o gate segue recusado e por quais Q-nnn;
   - `Cancelar`: não altere nada; o gate segue recusado.
   O aprovador que entende que uma questão não bloqueia usa, dentro da rodada, a opção `Não bloqueia (reclassificar)`, com justificativa obrigatória registrada na própria Q-nnn.
4. Mostre um resumo do que será aprovado (artefatos, gate, aprovador esperado de `processo/04-convencoes.md` §4, Q-nnn abertas ligadas, por prioridade) e **peça confirmação explícita** ao usuário antes de alterar. Se houver Q-nnn aberta não bloqueante que ainda cita o artefato em `bloqueia` (ex.: reclassificada), avise.
5. Após confirmação, em cada arquivo: `status: aprovado`, `aprovado-por` (de `por=` ou pergunte), `aprovado-em` (data de hoje), `versao` (1.0 na primeira aprovação, senão próxima maior) e `data`. Se houver `obs=` ou Q-nnn reclassificadas no passo 3, registre no fim do artefato numa seção "Registro de gate" (data, gate, aprovador, `obs` e IDs das Q-nnn reclassificadas, com a justificativa).
6. Informe o próximo comando do fluxo.
