---
description: "Epic-flow: relatório de consumo de tokens e custo estimado em US$ por etapa (E0–E6), agente, execução e chamada"
argument-hint: "[E0..E6] [projeto=<pasta>] [sessao=<id>|todas] [desde=AAAA-MM-DD] [detalhe] [chamadas=<filtro>] [csv]"
---
Você é o orquestrador do epic-flow. Somente leitura, exceto o CSV opcional.

Argumentos: `$ARGUMENTS`

1. Monte a chamada a partir dos argumentos (sem argumento = todas as sessões do projeto):
   `python3 epic-flow/metricas/consumo.py [--sessao <id>] [--desde AAAA-MM-DD] [--detalhe] [--chamadas "<filtro>"] [--csv epic-flow/metricas/consumo.csv]`
   `chamadas=<filtro>` lista cada chamada à API das execuções cuja descrição contém o filtro (ex.: `chamadas="E1 EP-01"`).
   `E0`..`E6` vira `--etapa E0` (filtra a etapa). `projeto=<pasta>` vira `--projeto <pasta>`: o Claude Code guarda o histórico por diretório de trabalho, então se o fluxo foi rodado em outra pasta (ex.: `/home/itl/Projects/CASH/piloto`), aponte para ela. Sem `projeto=`, procure também em `~/.claude/projects/` diretórios cujo nome comece com o do projeto atual (ex.: `-home-itl-Projects-CASH-piloto`) que tenham execuções com prefixo de etapa e rode o relatório para cada um, avisando o usuário.
   Execute a partir de `/home/itl/Projects/CASH`.
2. Mostre as tabelas ao usuário como estão e acrescente 2–3 observações curtas: a etapa mais cara, a proporção de leitura de cache e execuções sem prefixo de etapa (aparecem como `outros` ou com o padrão do agente).
3. A coluna US$ é estimativa a preço de API (tabela `PRECOS` em `consumo.py`). Em plano de assinatura não há cobrança por token: trate como equivalente de API para comparar etapas. Se aparecer "modelos sem preço", avise para atualizar a tabela.
