# Épicos

Status: **vazio até a aplicação do fluxo**.

O ponto de partida é o [`mapa-epicos.md`](mapa-epicos.md) (id `MAPA`, etapa E0, gate G0): lista de todos os épicos extraídos dos insumos, com descrição, dores que atacam e insumos de origem. Cada linha do mapa reserva um `EP-nn`.

Cada épico de negócio ganha uma pasta `EP-nn-<slug>/` com insumos do épico (opcional), PRD, Arquitetura de Referência e features (cada uma com histórias, Arquitetura de Solução, specs e tasks). Estrutura, IDs, frontmatter e status: [04-convencoes](../processo/04-convencoes.md) §1–§4.

Não há lista prévia de épicos: o agente `pm` deriva o mapa só das fichas `IN-nnn` registradas via `/ef-insumos`. O PRD de cada `EP-nn` só é escrito depois do G0.

Material específico de um épico entra por `/ef-epico EP-nn insumos=<pasta>`: no mesmo comando, um subagente `pm` registra uma ficha por arquivo da pasta em `EP-nn-<slug>/insumos/IN-EPnn-nn-<slug>.md` (índice em `EP-nn-<slug>/insumos/README.md`, mesmo cabeçalho de [04-convencoes](../processo/04-convencoes.md) §7) e, em seguida, outro subagente `pm` escreve o `prd.md` usando também essas fichas. As fichas do épico são revisadas junto com o PRD no G1.

O mesmo vale para feature e história, em E3: `/ef-features EP-nn feature=FT-nn.nn insumos=<pasta>` registra fichas `IN-FTnn.nn-nn` em `features/FT-nn.nn-<slug>/insumos/` e `/ef-features EP-nn historia=US-nn.nn.nn insumos=<pasta>` registra fichas `IN-USnn.nn.nn-nn` em `features/FT-nn.nn-<slug>/historias/insumos/US-nn.nn.nn/` (cada pasta com índice `README.md`). O alvo já deve existir; um subagente `pm` registra as fichas e, em seguida, o `po` revisa a feature (e suas histórias) ou só a história alvo. Essas fichas são revisadas junto com a feature e as histórias no G3.

## Índice

| ID | Épico | Capacidades (da AR, E2) | Status PRD | Status Arq. Ref. | Features |
|---|---|---|---|---|---|
| — | — | — | — | — | — |
