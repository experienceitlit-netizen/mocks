# Insumos

Material bruto que alimenta o fluxo: transcrições, atas, notas, apresentações, documentos de fluxo de pipeline, e de processo AS-IS. Etapa **E0 Insumos**, dono: agente `pm`.

Só entra no fluxo o que for registrado aqui via `/ef-insumos <pasta|arquivos>`: as fichas `IN-nnn` e os arquivos apontados no campo `fonte` delas são a única fonte externa permitida (Regra de Isolamento, [01-fluxo §7](../processo/01-fluxo.md#7-isolamento-de-fontes)). O comando pode ser rodado de novo para acrescentar arquivos.

Insumos específicos de um épico do mapa não entram aqui: são registrados por `/ef-epico EP-nn insumos=<pasta>` como fichas `IN-EPnn-nn` em `../epicos/EP-nn-<slug>/insumos/`, com o mesmo cabeçalho e índice próprio ([04-convencoes §1 e §7](../processo/04-convencoes.md)). Da mesma forma, insumos de uma feature ou história entram por `/ef-features EP-nn feature=FT-nn.nn|historia=US-nn.nn.nn insumos=<pasta>` como fichas `IN-FTnn.nn-nn` ou `IN-USnn.nn.nn-nn`, na pasta `insumos/` da feature ou em `historias/insumos/US-nn.nn.nn/`.

## Como registrar um insumo

1. Escolha o próximo ID livre `IN-nnn` (maior da tabela abaixo + 1).
2. Crie a ficha `IN-nnn-<slug>.md` nesta pasta, com o cabeçalho padrão de [04-convencoes §7](../processo/04-convencoes.md#7-cabeçalho-padrão-de-insumo): `tipo-insumo`, `fonte`, `data-insumo`, `autor-reuniao`, `produto`, `temas` (assuntos citados, texto livre, sem ID), `maturidade`.
3. Não copie o original. A ficha aponta para ele em `fonte`, que deve ser um dos caminhos passados no argumento de `/ef-insumos`, e traz resumo, conceitos e regras com `arquivo:L<linha>`.
4. Cada trecho marcado no original como `[...]`, "cortado", "truncado" ou "(Dúvida!)" vira uma `Q-nnn` em [`../transversal/decisoes-e-questoes.md`](../transversal/README.md), listada em `questoes-abertas` da ficha.
5. Acrescente uma linha no índice abaixo.

Valores de `tipo-insumo`: `transcricao`, `ata`, `nota`, `apresentacao`, `fluxo-pipeline`, `processo-as-is`.
Valores de `maturidade`: `completo`, `parcial`, `truncado`.

## Índice

| ID | Título | Tipo | Fonte | Produto | Temas | Maturidade | Questões | Status |
|---|---|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — | — |

## Piloto CASH

Os insumos do piloto são os arquivos da pasta que o usuário indicar em `/ef-insumos` (ex.: `/ef-insumos docs-precificacao/`). Eles são indexados aqui, sem cópia, na aplicação do fluxo. A pasta `fotos/` do projeto não é lida.
