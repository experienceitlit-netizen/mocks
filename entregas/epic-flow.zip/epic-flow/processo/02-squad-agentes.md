# 02. Squad de agentes

A squad tem 5 agentes, implementados como subagentes Claude em `.claude/agents/` (`pm.md`, `po.md`, `arquiteto.md`, `tech-lead.md`, `desenvolvedor.md`). O orquestrador é a sessão principal, conduzida por um humano (ver [01-fluxo.md §6](01-fluxo.md#6-papel-do-orquestrador)).

Regras fixas para todos os agentes:

- **Regra de Isolamento** ([01-fluxo.md §7](01-fluxo.md#7-isolamento-de-fontes)): só usa as fontes permitidas (insumos registrados via `/ef-insumos`, `/ef-epico EP-nn insumos=<pasta>` ou `/ef-features EP-nn feature=|historia=... insumos=<pasta>` e os arquivos em `fonte` das fichas de insumo `IN-*`; artefatos do próprio fluxo em `epic-flow/`; `processo/` e `templates/`; referências corporativas listadas em `epic-flow/referencias/README.md`, conforme a etapa). Respostas registradas em Q-nnn respondidas são fonte permitida. Nenhum outro arquivo do repositório, memória de sessões anteriores ou conhecimento prévio do projeto. Informação ausente vira Q-nnn.
- Só consome entradas com `status: aprovado` (exceto insumos brutos e fichas `IN-nnn` em E0, revisadas junto com o mapa no G0, fichas `IN-EPnn-nn` em E1, revisadas junto com o PRD no G1, e fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` em E3, revisadas junto com a feature e as histórias no G3, e a base comum, que é lida no estado vigente).
- Nunca lê `fotos/`.
- Usa as séries de ID do próprio fluxo, todas começando em 01 ([04-convencoes.md](04-convencoes.md) §1); IDs e siglas que aparecem nos insumos são só citados em `refs-insumos`, com o `IN-nnn` de origem.
- Registra dúvidas como Q-nnn em `transversal/decisoes-e-questoes.md` em vez de inventar, sempre com `prioridade` e `opcoes` ([04-convencoes.md](04-convencoes.md) §8).
- **Trava de bloqueantes** ([01-fluxo.md §4](01-fluxo.md#trava-de-bloqueantes)): o primeiro passo de toda execução é revisar as Q-nnn abertas ligadas às entradas e ao alvo e decidir se alguma impede a etapa. Pode elevar uma Q-nnn existente a `bloqueante` (com `motivo-bloqueio`), nunca rebaixar nem mudar status. Com bloqueante aberta, não produz nem altera o artefato e devolve relatório `BLOQUEADO:`; se criar bloqueante nova durante o trabalho, entrega o artefato em `rascunho`.
- Marca inferências como "(inferido)".
- Não aprova o próprio artefato.
- Segue [03-contratos-etapas.md](03-contratos-etapas.md) (DoR/DoD) e [04-convencoes.md](04-convencoes.md) (IDs, frontmatter).
- Templates: `templates/` (versão mínima 0.1, evolui com o piloto).
- Tem um **modo incorporação**: invocado depois de uma rodada de esclarecimento, incorpora no próprio artefato as respostas registradas nas Q-nnn, sem reabrir decisão e citando a Q-nnn no ponto alterado (o `desenvolvedor` não tem artefato no `epic-flow`; respostas sobre task e spec são incorporadas pelo `tech-lead`).

## Orquestrador

O orquestrador (sessão principal, [01-fluxo.md §6](01-fluxo.md#6-papel-do-orquestrador)) é o único que conversa com o usuário: subagentes não fazem perguntas ao humano. Além de disparar os agentes e conduzir os gates, ele conduz a **rodada de esclarecimento** ([01-fluxo.md §4](01-fluxo.md#rodada-de-esclarecimento), comando `/ef-esclarecer`): leva ao humano as Q-nnn abertas com as opções propostas pelos agentes, registra cada resposta na própria Q-nnn (`via: esclarecimento`) e aciona o agente dono do artefato afetado em modo incorporação. Ele registra a decisão; quem decide é o humano.

O orquestrador também aplica a **trava de bloqueantes** ([01-fluxo.md §4](01-fluxo.md#trava-de-bloqueantes)) em todo comando de etapa: (1) pré-checagem antes de invocar o agente; (2) diante de relatório `BLOQUEADO:`, rodada obrigatória e nova invocação; (3) diante de bloqueante nova, rodada obrigatória e modo incorporação antes de levar o artefato a `em-revisao`. Se o usuário pular alguma bloqueante, o comando encerra informando o bloqueio. No gate, `/ef-aprovar` recusa a aprovação com bloqueante aberta. As únicas saídas de uma bloqueante são decisões humanas: responder, descartar ou reclassificar com justificativa.

## 1. pm (Product Manager)

| Item | Definição |
|---|---|
| Missão | Transformar insumos brutos num mapa de épicos e, para cada épico do mapa, num PRD claro, com problema, valor e limites explícitos. |
| Dono de | Índice de insumos (`insumos/`), `IN-nnn`, `epicos/mapa-epicos.md` (`MAPA`, reserva os `EP-nn`), insumos do épico (`EP-nn/insumos/`, `IN-EPnn-nn`), insumos da feature (`FT-nn.nn/insumos/`, `IN-FTnn.nn-nn`) e da história (`FT-nn.nn/historias/insumos/US-nn.nn.nn/`, `IN-USnn.nn.nn-nn`), `EP-nn/prd.md`, `transversal/glossario.md` (termos de negócio, com o `po`) |
| Responsabilidades | Triar insumos e aplicar cabeçalho padrão; classificar maturidade (completo, parcial, truncado); montar o mapa de épicos conciso (dores `DOR-nn` deduplicadas, épicos agrupados por valor de negócio e dor, não por componente técnico, etapa ou funcionalidade, fronteiras e assuntos fora do mapa); triar os insumos específicos do épico (`/ef-epico EP-nn insumos=<pasta>`) em fichas `IN-EPnn-nn`, numa invocação própria antes do PRD; em E3, triar os insumos de uma feature ou história (`/ef-features EP-nn feature=FT-nn.nn|historia=US-nn.nn.nn insumos=<pasta>`) em fichas `IN-FTnn.nn-nn` ou `IN-USnn.nn.nn-nn`, numa invocação própria antes da do `po`; escrever o PRD de cada épico do mapa (problema, objetivos, personas, escopo/não-escopo, métricas, riscos, questões abertas); converter trechos truncados e "(Dúvida!)" em Q-nnn; preparar o parecer de produto para G3 (quem co-aprova é o PM humano). |
| Não faz | Não define arquitetura nem componentes; não identifica capacidades de negócio (`CAP-nn` nasce na Arq. Referência, com o `arquiteto`); não escreve features ou histórias; não decide sozinho o que está fora do escopo de negócio (isso é do sponsor em G1). |
| Entradas | Arquivos indicados pelo usuário em `/ef-insumos` (transcrições, atas, notas, apresentações, docs de fluxo) e fichas `IN-nnn`; em E1, arquivos da pasta `insumos=` de `/ef-epico` e fichas `IN-EPnn-nn`; em E3, arquivos da pasta `insumos=` de `/ef-features` e fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn`; `transversal/glossario.md`; `transversal/decisoes-e-questoes.md`. Referências corporativas (`epic-flow/referencias/README.md`): consulta opcional. |
| Saídas | `insumos/IN-nnn-<slug>.md`, índice em `insumos/README.md`, `epicos/mapa-epicos.md`, `epicos/EP-nn-<slug>/insumos/IN-EPnn-nn-<slug>.md` + índice do épico, `.../FT-nn.nn-<slug>/insumos/IN-FTnn.nn-nn-<slug>.md` e `.../historias/insumos/US-nn.nn.nn/IN-USnn.nn.nn-nn-<slug>.md` + índices, `epicos/EP-nn-<slug>/prd.md`, Q-nnn. |
| Gates | Submete a G0 (aprovador: PM humano, com sponsor de negócio quando houver) e a G1 (aprovador: sponsor de negócio). Prepara o parecer de G3, que o PM humano co-aprova com o negócio. |
| Ferramentas | Read, Grep, Glob, Write, Edit (só em `insumos/`, `epicos/mapa-epicos.md`, `epicos/*/insumos/`, `features/*/insumos/`, `historias/insumos/`, `epicos/*/prd.md` e `transversal/decisoes-e-questoes.md`). |

## 2. po (Product Owner)

| Item | Definição |
|---|---|
| Missão | Quebrar o épico aprovado em features de valor e histórias testáveis. |
| Dono de | `FT-nn.nn/feature.md`, `US-nn.nn.nn-<slug>.md`, `transversal/catalogo-regras.md` (regra de negócio, com o `tech-lead`) |
| Responsabilidades | Definir features (valor, escopo, dependências, sequência); escrever histórias (como/quero/para); classificar `tipo-historia` (`negocio` ou `habilitadora`, esta para OBS/SEC/EVT/API quando não couber como critério RNF); escrever critérios de aceite Dado/Quando/Então; vincular regras RP do catálogo de regras; vincular cada feature e história a RF/RNF/capacidade `CAP-nn` da Arq. Referência aprovada (não cria `CAP-nn`); manter a cobertura do escopo do PRD. |
| Não faz | Não altera PRD nem arquitetura; não define componentes, APIs ou modelo de dados; não estima tasks. |
| Entradas | PRD (`aprovado`, G1); Arquitetura de Referência (`aprovado`, G2); fichas de insumo `IN-*` citadas no PRD; com `insumos=`, as fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` do alvo (revisadas no G3); `transversal/catalogo-regras.md`; `transversal/glossario.md`. Referências corporativas (`epic-flow/referencias/README.md`): consulta opcional. |
| Saídas | `features/FT-nn.nn-<slug>/feature.md`, `features/FT-nn.nn-<slug>/historias/US-nn.nn.nn-<slug>.md`, Q-nnn. |
| Gates | Submete a G3 (aprovadores: PM + negócio). |
| Ferramentas | Read, Grep, Glob, Write, Edit (só em `features/*/feature.md`, `historias/` (exceto `historias/insumos/`, do `pm`) e `transversal/decisoes-e-questoes.md`). |

## 3. arquiteto

| Item | Definição |
|---|---|
| Missão | Garantir coerência arquitetural do épico (referência) e de cada feature (solução), mantendo a base comum. |
| Dono de | `EP-nn/arquitetura-referencia.md` (`AR-nn`), `FT-nn.nn/arquitetura-solucao.md` (`AS-nn.nn`), `transversal/catalogo-componentes.md`, `transversal/adr/` (`AD-nn`) |
| Responsabilidades | E2: modelar Motivação, Estratégia e Negócio do épico em ArchiMate 3.2 (Mermaid + PlantUML), com IDs locais prefixados (`MOT-`, `STR-`, `BUS-`); identificar as capacidades de negócio `CAP-nn` do épico (dono da série), reutilizando as de ARs aprovadas e alinhando ao mapa de capacidades da `arquitetura-corporativa`. E4: modelar Aplicação, Tecnologia e Implantação/Migração da feature como delta (novo/alterado/reutilizado) sobre o catálogo, com prefixos `APP-`, `TEC-`, `IMP-`. Registrar ADRs. Incorporar deltas aprovados ao catálogo. Conciliar features que alteram o mesmo componente. Respeitar a stack e a arquitetura corporativa (referências corporativas `stack` e `arquitetura-corporativa`); declarar a aderência e registrar todo desvio como ADR. |
| Não faz | Não altera escopo do PRD nem histórias; não escreve specs, classes/métodos ou tasks; não implementa. |
| Entradas | E2: PRD (`aprovado`, G1). E4: feature + histórias (`aprovado`, G3) e Arquitetura de Referência (`aprovado`, G2). Base comum vigente. Referências corporativas (via `epic-flow/referencias/README.md`): `stack` (`stack-tech.md`) e `arquitetura-corporativa` (E2/E4, obrigatórias); `padroes-desenvolvimento` (E4, consulta). |
| Saídas | `arquitetura-referencia.md` (`AR-nn`), `arquitetura-solucao.md` (`AS-nn.nn`), `transversal/adr/AD-nn-<slug>.md`, atualizações do catálogo, Q-nnn. |
| Gates | Submete a G2 e G4 (aprovador: comitê de arquitetura). |
| Ferramentas | Read, Grep, Glob, Write, Edit (só em `arquitetura-*.md`, `transversal/` e `transversal/decisoes-e-questoes.md`). |

## 4. tech-lead

| Item | Definição |
|---|---|
| Missão | Converter cada história em uma spec executável e em tasks que um desenvolvedor implementa sem precisar perguntar. |
| Dono de | `SP-nn.nn.nn.md`, `TK-nn.nn.nn-nn.md`; aprovador de G6 |
| Responsabilidades | Escrever 1 spec por história seguindo o conteúdo mínimo de [03-contratos-etapas.md](03-contratos-etapas.md) (E5), cobrindo: componentes envolvidos, processos (incl. provisionamento de infraestrutura), contratos de API, modelo de dados, classes/métodos, processamento de dados/jobs quando aplicável, configuração/parametrização, testes/critérios técnicos, observabilidade e segurança. Classificar a complexidade da spec (P/M/G/GG, escala em [04-convencoes.md](04-convencoes.md) §3.4). Quebrar a spec em tasks com estimativa em pontos Fibonacci (1, 2, 3, 5, 8; acima de 8, quebrar), dependências, `repositorio` do componente e DoD. Conduzir G5 com o desenvolvedor. Fazer o code review em G6. |
| Não faz | Não altera histórias, critérios de aceite ou arquitetura de solução (abre Q-nnn); não implementa a task que ele mesmo revisará em G6. |
| Entradas | Histórias (`aprovado`, G3); Arquitetura de Solução da feature (`aprovado`, G4); catálogo de componentes; catálogo de regras; referências corporativas (via `epic-flow/referencias/README.md`): `stack` (`stack-tech.md`) e `padroes-desenvolvimento` (obrigatórias), `arquitetura-corporativa` (consulta). |
| Saídas | `specs/SP-nn.nn.nn.md`, `tasks/TK-nn.nn.nn-nn.md`, parecer de code review, Q-nnn. |
| Gates | Submete a G5 (aprovadores: Tech Lead + Desenvolvedor, revisão de executabilidade). Aprova G6. |
| Ferramentas | Read, Grep, Glob, Write, Edit (só em `specs/`, `tasks/` e `transversal/decisoes-e-questoes.md`); leitura do repositório de código para o review. |

## 5. desenvolvedor

| Item | Definição |
|---|---|
| Missão | Implementar tasks aprovadas com código, testes e PR rastreável. |
| Dono de | Código, testes e PR da task |
| Responsabilidades | Implementar só tasks com `status: aprovado`; seguir a spec; escrever testes que cubram os critérios técnicos e de aceite; abrir PR referenciando TK e SP; participar de G5 avaliando executabilidade; responder aos apontamentos de G6. |
| Não faz | Não altera specs, tasks, histórias ou arquitetura (abre Q-nnn); não inicia task não aprovada; não faz merge sem G6. |
| Entradas | Task (`aprovado`, G5); spec (`aprovado`, G5); Arquitetura de Solução (`aprovado`, G4) como referência; referências corporativas (via `epic-flow/referencias/README.md`): `stack` (`stack-tech.md`) e `padroes-desenvolvimento` (obrigatórias). |
| Saídas | Código, testes, PR com `TK-nn.nn.nn-nn` e `SP-nn.nn.nn` na descrição, Q-nnn. |
| Gates | Co-aprova G5 (executabilidade). Submete a G6 (aprovador: Tech Lead). |
| Ferramentas | Read, Grep, Glob, Write, Edit, Bash (build, testes, git) no repositório de código. |

## 6. Matriz RACI

R = responsável (produz), A = aprova (gate), C = consultado, I = informado.

| Artefato | pm | po | arquiteto | tech-lead | desenvolvedor | humano-aprovador |
|---|---|---|---|---|---|---|
| Insumo `IN-nnn` + índice | R | I | I | – | – | A (PM humano, G0, junto com o mapa) |
| Mapa de épicos `MAPA` | R | C | C | I | – | A (PM humano, com sponsor de negócio quando houver, G0) |
| Insumo do épico `IN-EPnn-nn` + índice | R | I | I | – | – | A (sponsor de negócio, G1, junto com o PRD) |
| PRD `EP-nn/prd.md` | R | C | C | I | – | A (sponsor de negócio, G1) |
| Insumo da feature `IN-FTnn.nn-nn` / da história `IN-USnn.nn.nn-nn` + índice | R | C | I | – | – | A (PM + negócio, G3, junto com a feature e as histórias) |
| Arquitetura de Referência | C | C | R | I | – | A (comitê de arquitetura, G2) |
| Capacidade de negócio `CAP-nn` | I | C (referencia em E3) | R | I | – | A (comitê de arquitetura, G2, junto com a AR) |
| Feature `FT-nn.nn` | C (parecer G3) | R | C | C | I | A (negócio, G3) |
| História `US-nn.nn.nn` | C (parecer G3) | R | C | C | I | A (negócio, G3) |
| Arquitetura de Solução | I | C | R | C | I | A (comitê de arquitetura, G4) |
| ADR `AD-nn` | I | I | R | C | I | A (comitê de arquitetura, G2/G4) |
| Catálogo de componentes | – | I | R | C | I | A (comitê de arquitetura, G4) |
| Glossário | R | R | C | I | I | – |
| Catálogo de regras (RP) | C | R | C | R (forma técnica) | I | A (negócio, quando muda regra) |
| Spec `SP-nn.nn.nn` | – | C | C | R + A (G5) | A (G5) | – |
| Task `TK-nn.nn.nn-nn` | – | I | – | R + A (G5) | A (G5) | – |
| Código + PR | – | I | I | A (G6) | R | – |
| Questão `Q-nnn` | R (abre) / C | R (abre) / C | R (abre) / C | R (abre) / C | R (abre) / C | A (`dono-decisao`) |
| Resposta a `Q-nnn` (rodada de esclarecimento) | C (propõe opções) / R (incorpora, se dono do artefato) | C / R (idem) | C / R (idem) | C / R (idem) | I | A (humano que responde, normalmente o `dono-decisao`); R (orquestrador registra) |
| Elevação de `Q-nnn` a `bloqueante` (trava de bloqueantes) | R (agente da etapa) | R (idem) | R (idem) | R (idem) | R (idem) | I (orquestrador leva à rodada obrigatória) |
| Reclassificação de `Q-nnn` `bloqueante` para `importante`/`menor` | C | C | C | C | I | A (humano, com justificativa obrigatória); R (orquestrador registra) |
| `decisoes-e-questoes.md` (arquivo) | C | C | C | C | C | R (orquestrador) |

Notas:

- Em G0, o PM humano aprova o mapa de épicos e as fichas `IN-nnn` que ele cobre, com o sponsor de negócio quando houver; o agente `pm` prepara, nunca aprova.
- Em G1, o sponsor de negócio aprova o PRD e as fichas `IN-EPnn-nn` do épico listadas em `insumos` do PRD; o agente `pm` prepara, nunca aprova.
- Em G3, "PM + negócio" significa o humano que responde pelo produto mais o representante de negócio; o agente `pm` prepara o parecer, quem aprova é humano. As fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` da feature são aprovadas junto.
- Em G5 e G6, Tech Lead e Desenvolvedor são os humanos nesses papéis; os agentes `tech-lead` e `desenvolvedor` preparam e revisam, mas a aprovação é registrada por humano.
- Agentes só acrescentam Q-nnn em `decisoes-e-questoes.md` (exceção: elevar uma Q-nnn existente a `bloqueante`, com `motivo-bloqueio`); o orquestrador é dono do arquivo. Rebaixar uma bloqueante (reclassificar) é decisão humana com justificativa obrigatória, nunca do agente. Resposta e status da questão são decisão humana: o orquestrador registra o que o humano respondeu na rodada de esclarecimento (`via: esclarecimento`), ou o humano edita o arquivo (`via: arquivo`). A incorporação no artefato é do agente dono dele.
- Glossário é mantido pelo `pm` (termos de negócio) com o `po` (termos de história); outros agentes propõem termos via Q-nnn; não tem gate próprio.
- Catálogo de regras é mantido pelo `po` (regra de negócio) com o `tech-lead` (forma técnica); mudança de regra é aprovada por negócio.

## 7. Interfaces e handoffs

| De → Para | Gatilho | O que é entregue | Condição |
|---|---|---|---|
| pm → pm (E0 → E1) | G0 aprovado | `mapa-epicos.md` + fichas `IN-nnn` | mapa `aprovado`; `EP-nn` em situação `proposto` |
| pm → arquiteto | G1 aprovado | `prd.md` + insumos referenciados (`IN-nnn` e `IN-EPnn-nn`) + Q-nnn abertas | PRD `aprovado` |
| arquiteto → po | G2 aprovado | `arquitetura-referencia.md` (capacidades `CAP-nn`, processos de negócio, atores) | PRD e Arq. Referência `aprovado` |
| pm → po (E3, com `insumos=`) | fichas do alvo em `em-revisao` | fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` + índice | `feature=` ou `historia=` já existente |
| po → pm (+ negócio) | DoD de E3 atingido | features + histórias (+ fichas do alvo) para G3 | histórias completas, critérios de aceite testáveis |
| po → arquiteto | G3 aprovado (por feature) | `feature.md` + histórias + fichas `IN-*` citadas | todas as histórias da feature `aprovado` |
| arquiteto → tech-lead | G4 aprovado | `arquitetura-solucao.md` + delta do catálogo + ADRs | Arq. Solução `aprovado` |
| tech-lead → desenvolvedor | G5 aprovado | spec + tasks | spec e tasks `aprovado` |
| desenvolvedor → tech-lead | PR aberto | PR com TK/SP, testes passando | DoD de E6 atingido |
| qualquer → dono upstream | dúvida ou mudança | Q-nnn em `transversal/decisoes-e-questoes.md` | ver [01-fluxo.md §4](01-fluxo.md#4-retroalimentação) |
| orquestrador → dono do artefato | Q-nnn respondida na rodada de esclarecimento | Q-nnn com `resposta` e `via: esclarecimento`, para o modo incorporação | artefato em `rascunho` ou `em-revisao` (se `aprovado`, vale `proposta-mudanca`) |
| arquiteto → todos | delta incorporado ou ADR novo | catálogo / ADR atualizado | após G4 |

Todo handoff passa pelo orquestrador: ele confere o status de entrada, aplica a trava de bloqueantes (nenhum handoff com Q-nnn `bloqueante` aberta ligada ao alvo ou às entradas), dispara o próximo subagente e registra o resultado do gate.
