# 01. Fluxo agêntico: do insumo à implementação

Este documento define as etapas, os gates humanos, a justificativa da arquitetura em dois níveis, a retroalimentação, as regras de paralelismo e o isolamento de fontes do `epic-flow`. A regra de isolamento ([§7](#7-isolamento-de-fontes)) e a [trava de bloqueantes](#trava-de-bloqueantes) (§4) valem para todas as etapas e todos os agentes.

Documentos relacionados:

- [02-squad-agentes.md](02-squad-agentes.md): papéis, RACI e handoffs.
- [03-contratos-etapas.md](03-contratos-etapas.md): entradas, saídas, DoR, DoD e aprovador por etapa.
- [04-convencoes.md](04-convencoes.md): IDs, frontmatter, status, pastas e rastreabilidade.

## 1. Visão geral

O fluxo tem 7 etapas (E0–E6) e 7 gates humanos (G0–G6). Cada etapa tem um único agente dono. Cada gate fica numa transição de dono ou de escopo: o passo seguinte só começa quando o artefato anterior estiver `aprovado`. O G0 fecha o E0: o mapa de épicos define quais PRDs serão escritos (um PRD por épico do mapa).

```mermaid
flowchart TD
    E0["E0 Insumos + Mapa de Épicos<br/>agente: pm"]
    G0{{"G0 Mapa de Épicos<br/>PM humano (+ sponsor)"}}
    E1["E1 PRD do Épico<br/>agente: pm, um por EP-nn do mapa"]
    G1{{"G1 PRD<br/>sponsor de negócio"}}
    E2["E2 Arquitetura de Referência<br/>agente: arquiteto<br/>Motivação, Estratégia, Negócio"]
    G2{{"G2 Arq. Referência<br/>comitê de arquitetura"}}
    E3["E3 Features e Histórias<br/>agente: po"]
    G3{{"G3 Features+Histórias<br/>PM + negócio"}}
    E4["E4 Arquitetura de Solução da Feature<br/>agente: arquiteto<br/>Aplicação, Tecnologia, Implantação/Migração"]
    G4{{"G4 Arq. Solução<br/>comitê de arquitetura"}}
    E5["E5 Specs e Tasks<br/>agente: tech-lead"]
    G5{{"G5 Specs+Tasks<br/>Tech Lead + Desenvolvedor"}}
    E6["E6 Implementação<br/>agente: desenvolvedor"]
    G6{{"G6 Code review<br/>Tech Lead"}}
    DONE(["Entregue"])

    BASE[("transversal/<br/>glossário, catálogo de componentes,<br/>catálogo de regras, ADRs")]
    DQ[("transversal/<br/>decisoes-e-questoes.md<br/>Q-nnn")]
    REF[("Referências corporativas (fixas)<br/>epic-flow/referencias/README.md<br/>stack, arquitetura corporativa,<br/>padrões de desenvolvimento")]

    E0 --> G0 --> E1 --> G1 --> E2 --> G2 --> E3 --> G3 --> E4 --> G4 --> E5 --> G5 --> E6 --> G6 --> DONE

    BASE -.-> E2
    BASE -.-> E4
    BASE -.-> E5
    E4 -. "delta aprovado atualiza" .-> BASE

    REF -.-> E2
    REF -.-> E4
    REF -.-> E5
    REF -.-> E6

    E2 -. questão .-> DQ
    E3 -. questão .-> DQ
    E4 -. questão .-> DQ
    E5 -. questão .-> DQ
    E6 -. questão .-> DQ
    E1 -. questão .-> DQ
    DQ -. "mudança aprovada reabre gate" .-> G0
    DQ -. "mudança aprovada reabre gate" .-> G1
```

Versão em texto:

```
E0 Insumos + Mapa de Épicos ─[pm]──────────────── G0 (PM humano + sponsor)
  ─[pm]─► E1 PRD do Épico (um por EP-nn) ───────── G1 (sponsor de negócio)
  ─[arquiteto]─► E2 Arquitetura de Referência ───── G2 (comitê de arquitetura)
  ─[po]─► E3 Features e Histórias ────────────────── G3 (PM + negócio)
  ─[arquiteto]─► E4 Arquitetura de Solução da Feature G4 (comitê de arquitetura)
  ─[tech-lead]─► E5 Specs e Tasks ────────────────── G5 (Tech Lead + Desenvolvedor)
  ─[desenvolvedor]─► E6 Implementação ────────────── G6 (code review do Tech Lead)
```

## 2. Etapas

| Etapa | Objetivo | Dono | Saída principal | Gate de saída |
|---|---|---|---|---|
| E0 Insumos | Triar o material bruto, registrar cada insumo com cabeçalho padrão, levantar questões abertas e extrair dos insumos a lista de épicos (nome, descrição, dores, insumos) | pm | fichas `insumos/IN-nnn-<slug>.md` (apontam para o original, sem cópia) + índice em `insumos/README.md` + `epicos/mapa-epicos.md` (id `MAPA`, reserva os `EP-nn`) | G0 Mapa de Épicos (PM humano, com sponsor de negócio quando houver); as fichas são revisadas junto com o mapa |
| E1 PRD do Épico | Para um épico do mapa aprovado, definir problema, objetivos, personas, escopo e não-escopo, métricas, riscos e questões abertas | pm | `epicos/EP-nn-<slug>/prd.md` (id `EP-nn` reservado no mapa); com `/ef-epico EP-nn insumos=<pasta>`, antes do PRD, fichas do épico `epicos/EP-nn-<slug>/insumos/IN-EPnn-nn-<slug>.md` + índice | G1 PRD (sponsor de negócio); as fichas do épico são revisadas junto com o PRD |
| E2 Arquitetura de Referência | Modelar o épico nas camadas ArchiMate Motivação, Estratégia e Negócio e identificar as capacidades de negócio `CAP-nn` (mapa e PRD não as tratam) | arquiteto | `epicos/EP-nn-<slug>/arquitetura-referencia.md` (id `AR-nn`) | G2 Arq. Referência (comitê de arquitetura) |
| E3 Features e Histórias | Quebrar o épico em features (valor, escopo, dependências, sequência) e histórias com critérios de aceite Dado/Quando/Então e regras RP vinculadas | po (fichas: pm) | `.../features/FT-nn.nn-<slug>/feature.md` e `.../historias/US-nn.nn.nn-<slug>.md`; com `/ef-features EP-nn feature=FT-nn.nn insumos=<pasta>` ou `historia=US-nn.nn.nn insumos=<pasta>`, antes, fichas `IN-FTnn.nn-nn` (`.../FT-nn.nn-<slug>/insumos/`) ou `IN-USnn.nn.nn-nn` (`.../historias/insumos/US-nn.nn.nn/`) + índice | G3 Features+Histórias (PM + negócio); as fichas da feature e da história são revisadas junto |
| E4 Arquitetura de Solução da Feature | Modelar a feature nas camadas ArchiMate Aplicação, Tecnologia e Implantação/Migração, como delta sobre a base comum | arquiteto | `.../features/FT-nn.nn-<slug>/arquitetura-solucao.md` (id `AS-nn.nn`) + ADRs `transversal/adr/AD-nn-<slug>.md` + atualização do catálogo | G4 Arq. Solução (comitê de arquitetura) |
| E5 Specs e Tasks | Escrever 1 spec por história com tudo que o desenvolvedor precisa, e quebrá-la em tasks estimadas | tech-lead | `.../specs/SP-nn.nn.nn.md` e `.../tasks/TK-nn.nn.nn-nn.md` | G5 Specs+Tasks (Tech Lead + Desenvolvedor) |
| E6 Implementação | Implementar a task: código, testes e PR referenciando TK e SP | desenvolvedor | código + testes + PR | G6 Code review (Tech Lead) |

Detalhamento de entradas, saídas, DoR e DoD: [03-contratos-etapas.md](03-contratos-etapas.md).

### Gates

| Gate | Artefato avaliado | Aprovador humano | O que se verifica |
|---|---|---|---|
| G0 Mapa de Épicos | `mapa-epicos.md` + fichas `IN-nnn` do mapa | PM humano (com sponsor de negócio quando houver) | todo insumo coberto por épico ou em "Fora do mapa"; épicos por valor de negócio e dor, não por componente, etapa ou funcionalidade; mapa conciso (descrições curtas, dores deduplicadas); fronteiras entre épicos explícitas |
| G1 PRD | `prd.md` | sponsor de negócio | problema e objetivos corretos, escopo e não-escopo aceitos, métricas mensuráveis, questões abertas conhecidas |
| G2 Arq. Referência | `arquitetura-referencia.md` | comitê de arquitetura | coerência Motivação → Estratégia → Negócio, capacidades `CAP-nn` no nível de capacidade (não etapa nem função) e reutilizadas quando já existirem, aderência à base comum e à arquitetura corporativa (desvio exige ADR), IDs prefixados |
| G3 Features+Histórias | `feature.md` + histórias | PM + negócio | cobertura do escopo do PRD, valor por feature, critérios de aceite testáveis, regras RP vinculadas |
| G4 Arq. Solução | `arquitetura-solucao.md` (+ ADRs) | comitê de arquitetura | delta explícito (novo/alterado/reutilizado), aderência à stack e à arquitetura corporativa (referências corporativas; desvio exige ADR), ADRs para decisões novas |
| G5 Specs+Tasks | specs + tasks | Tech Lead + Desenvolvedor | revisão de executabilidade: o desenvolvedor consegue implementar sem perguntar; padrões de desenvolvimento aplicados |
| G6 Code review | PR | Tech Lead | código aderente à spec, testes passando, PR referenciando TK/SP |

Regras dos gates:

- Nenhum agente aprova o próprio artefato. Aprovação é sempre humana.
- Ao passar no gate, o aprovador humano muda `status` para `aprovado` e preenche `aprovado-por` e `aprovado-em`. A `versao` fica em 0.x durante o rascunho e vira 1.0 na primeira aprovação (detalhes em [04-convencoes.md](04-convencoes.md)).
- Reprovação devolve o artefato para `rascunho`, com os apontamentos registrados no próprio artefato ou em `transversal/decisoes-e-questoes.md`.

## 3. Por que duas arquiteturas

A arquitetura é feita em dois níveis, ligados por uma base comum e enquadrados pelas referências corporativas (fixas, listadas em [`../referencias/README.md`](../referencias/README.md)).

| Nível | Granularidade | Camadas ArchiMate | Por quê |
|---|---|---|---|
| Arquitetura de Referência | épico | Motivação, Estratégia, Negócio | Motivação, estratégia e negócio mudam no ritmo do valor de negócio, e o épico é a unidade de valor. |
| Arquitetura de Solução | feature | Aplicação, Tecnologia, Implantação/Migração | A feature é a menor entrega coerente de aplicação e tecnologia. |
| Base comum (`transversal/`) | transversal | catálogo de componentes, ADRs, glossário, catálogo de regras | Evita que cada feature redesenhe componentes compartilhados (ex.: `<componente>` usado por várias features). |

Alternativas descartadas:

- **Arquitetura de Solução por história:** granular demais. Uma história isolada raramente define componente, implantação ou migração; o resultado seria fragmentação e retrabalho.
- **Arquitetura de Solução por épico:** vira cascata. O épico inteiro teria de ser desenhado antes de qualquer feature andar, e a solução envelheceria antes da implementação.

Papel da base comum:

- A Arquitetura de Solução é escrita como **delta**: cada componente aparece como `novo`, `alterado` ou `reutilizado`, sempre com referência ao `transversal/catalogo-componentes.md`.
- Quando G4 aprova a feature, o arquiteto incorpora o delta ao catálogo e registra decisões novas como ADR em `transversal/adr/` (série `AD-nn`, a partir de `AD-01`).
- Glossário (`transversal/glossario.md`) e catálogo de regras (`transversal/catalogo-regras.md`) são lidos por todas as etapas. A base comum nasce vazia e só é preenchida pelo fluxo, a partir dos insumos registrados.

## 4. Retroalimentação

Qualquer agente pode abrir uma **questão** ou **proposta de mudança** contra um artefato acima dele.

1. **Registro.** O agente acrescenta uma entrada `Q-nnn` em `transversal/decisoes-e-questoes.md` (só acrescenta; a única edição permitida numa entrada existente é a elevação a `bloqueante` da [trava de bloqueantes](#trava-de-bloqueantes)), com `tipo` (`questao` ou `proposta-mudanca`), `prioridade` (`bloqueante`, `importante` ou `menor`), artefato afetado, autor, descrição, impacto, `opcoes` (2 a 4 respostas candidatas com a consequência de cada uma), `bloqueia` (IDs bloqueados) e `refs-insumos` quando a questão vier de uma pendência citada no insumo (ex.: `[IN-003:L45]`). Entra com status `aberta`. O arquivo pertence ao orquestrador.
2. **Decisão.** O dono do artefato afetado (agente) prepara as opções; quem decide é o humano `dono-decisao`, normalmente o aprovador do gate daquele artefato. A resposta é colhida na rodada de esclarecimento (abaixo), em que o orquestrador a registra (`via: esclarecimento`), ou o humano edita a Q-nnn direto no arquivo (`via: arquivo`). O status passa a `respondida` ou `descartada`; uma `bloqueante` também pode ser reclassificada pelo humano, com justificativa ([trava de bloqueantes](#trava-de-bloqueantes)).
3. **Mudança aprovada.** O artefato afetado volta para `em-revisao`, e o gate correspondente é reaberto (ex.: mudança no PRD reabre G1; mudança de fronteira entre épicos reabre o G0 do `MAPA`).
4. **Propagação.** Todo artefato downstream impactado vai para `em-revisao` até ser revalidado no seu próprio gate. Artefatos downstream não impactados mantêm `aprovado`, e a análise de impacto fica registrada na Q-nnn.
5. **Fechamento.** A Q-nnn `respondida` registra a decisão, a data e os IDs/versões dos artefatos alterados; os IDs em `bloqueia` ficam liberados.

Regras complementares:

- Pontos truncados ou marcados com "(Dúvida!)" nos insumos viram questões abertas já no PRD (E1).
- Um PRD por épico do mapa: `/ef-epico` só roda para `EP-nn` `proposto` no mapa aprovado (G0). Épico novo ou mudança de fronteira descoberta no PRD vira Q-nnn contra `MAPA`.
- Agente não inventa resposta: dúvida vira Q-nnn, e inferência é marcada como "(inferido)".
- Questão aberta que bloqueia uma história impede a história de passar em G3 (ou impede a spec em G5, se o bloqueio for técnico).
- Q-nnn `bloqueante` aberta trava a etapa e o gate: nenhuma etapa roda e nenhum gate aprova enquanto houver bloqueante ligada ao alvo ou às entradas ([trava de bloqueantes](#trava-de-bloqueantes)). Questão `importante` ou `menor` sem resposta não trava o fluxo: o trabalho segue com a lacuna explícita.
- Uma decisão que muda arquitetura gera ADR (`AD-nn`) em `transversal/adr/`, referenciada na Q-nnn.
- Q-nnn `bloqueante` aberta ligada ao artefato ou aos filhos recusa o gate: `/ef-aprovar` só oferece esclarecer agora ou cancelar. O aprovador que entende que a questão não bloqueia a reclassifica, com justificativa, dentro da rodada.

### Rodada de esclarecimento

Subagentes não conversam com o usuário: quem pergunta é o orquestrador. A rodada leva ao humano as Q-nnn abertas de um artefato, com as opções que o agente propôs, e devolve as respostas ao agente dono para incorporação. Roda por `/ef-esclarecer <ID|todas>` e é oferecida automaticamente depois do rascunho em `/ef-mapa-epicos` e `/ef-epico` (para as `importante`). Para bloqueantes ela é **obrigatória**: todo comando de etapa e o `/ef-aprovar` executam a **rodada obrigatória** (só bloqueantes) nos pontos da [trava de bloqueantes](#trava-de-bloqueantes), e a etapa ou o gate só seguem com zero bloqueantes.

```mermaid
flowchart LR
    A["agente gera rascunho<br/>+ Q-nnn com prioridade e opções"] --> S["orquestrador seleciona<br/>Q-nnn abertas do artefato<br/>bloqueante → importante"]
    S --> P["perguntas ao humano<br/>até 4 por vez<br/>opções + Pular"]
    P --> R["orquestrador registra na Q-nnn<br/>respondida, descartada<br/>ou reclassificada (bloqueante)"]
    R --> I["agente dono em modo incorporação<br/>ajusta o artefato, cita a Q-nnn"]
    I --> G{{"gate<br/>zero bloqueantes abertas"}}
    P -. pulada .-> X["Q-nnn continua aberta<br/>bloqueante: etapa e gate travados"]
```

1. **Seleção.** Q-nnn `aberta` do artefato (e dos filhos, para `EP-nn` e `FT-nn.nn`), por prioridade (padrão: bloqueante + importante), bloqueantes primeiro.
2. **Perguntas.** Até 4 por vez; cada uma com a pergunta, 1 linha de contexto com a fonte, as `opcoes` da Q-nnn e "Pular por agora"; bloqueante tem também "Não bloqueia (reclassificar)". Questão com `opcoes: []` é respondida em texto livre.
3. **Registro.** Só o orquestrador grava, porque é registro de decisão humana: `status: respondida`, `resposta`, `respondido-por`, `respondido-em`, `via: esclarecimento` (ou `descartada`, ou a reclassificação da bloqueante com justificativa). Questão pulada continua `aberta`; se for bloqueante, a etapa ou o gate que a rodada destravaria continuam travados.
4. **Incorporação.** O agente dono do artefato (pm, po, arquiteto ou tech-lead) ajusta só o necessário, cita a Q-nnn no ponto alterado, atualiza `questoes-abertas` e devolve o artefato a `em-revisao` (ou o mantém em `rascunho`, se restar ou surgir bloqueante ligada a ele). Artefato já `aprovado` não é reaberto pela rodada: resposta que muda conteúdo segue a regra de `proposta-mudanca` e `gate-de-retorno` (passo 3 acima).
5. **Fechamento.** Tabela com Q-nnn, resposta e status, e o próximo passo (outra rodada ou o gate).

### Trava de bloqueantes

Regra crítica, no mesmo nível da Regra de Isolamento (§7): **cada etapa reavalia as questões abertas que bloqueiam o seu desenvolvimento; se houver bloqueante, a etapa não segue.** Questão `importante` ou `menor` não trava: o trabalho segue com a lacuna explícita (`[A DEFINIR]`, "(inferido)", "a validar com o negócio").

**Quando uma Q-nnn bloqueia uma execução.** Quando, ao mesmo tempo:

- `status: aberta`;
- `prioridade: bloqueante`;
- `artefato-afetado` ou `bloqueia` contém o ID do artefato-alvo da execução, o ID de qualquer entrada upstream dela ou a própria etapa (`E0`…`E6`).

ID de épico ou de feature inclui a descendência, com o critério de seleção de `/ef-esclarecer` (passo 1): `EP-nn` cobre as fichas `IN-EPnn-*`, `AR-nn`, `FT-nn.*`, `US-nn.*`, `AS-nn.*`, `SP-nn.*`, `TK-nn.*` e os ADRs do épico; `FT-nn.nn` cobre as fichas `IN-FTnn.nn-*` e `IN-USnn.nn.*`, `US-nn.nn.*`, `AS-nn.nn`, `SP-nn.nn.*` e `TK-nn.nn.*`; `MAPA` cobre as fichas `IN-nnn` do mapa.

| Comando | Etapa | Alvo | Entradas upstream |
|---|---|---|---|
| `/ef-insumos` | E0 | fichas `IN-nnn` novas | nenhuma (só pontos 2 e 3) |
| `/ef-mapa-epicos` | E0 | `MAPA` | fichas `IN-nnn` do recorte |
| `/ef-epico` | E1 | `EP-nn` | `MAPA`, fichas `IN-nnn` e `IN-EPnn-nn` do recorte |
| `/ef-arq-ref` | E2 | `AR-nn` | `EP-nn` |
| `/ef-features` | E3 | `FT-nn.*` do épico (ou a `FT-nn.nn` de `feature=`, ou a `US-nn.nn.nn` de `historia=`) — trava **por feature** | `EP-nn`, `AR-nn`; com `insumos=`, as fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` do alvo |
| `/ef-arq-sol` | E4 | `AS-nn.nn` | `FT-nn.nn` (com as histórias), `AR-nn` |
| `/ef-specs` | E5 | `SP-nn.nn.nn` e `TK-` do recorte — trava **por história** | `US-nn.nn.nn` do recorte, `AS-nn.nn` |

**Granularidade da trava em E3 e E5.** Bloqueante ligada ao nível de cima (em E3: `EP-nn`, `AR-nn` ou `E3`; em E5: `FT-nn.nn`, `AS-nn.nn` ou `E5`) trava a etapa inteira. Bloqueante ligada a um item (em E3: uma feature ou história dela; em E5: uma história ou sua spec/tasks) trava **só aquele item**: ele sai do recorte da execução e os demais seguem. O agente sinaliza com `BLOQUEADO PARCIAL:` quando ele mesmo identifica o bloqueio de um item. O item bloqueado é destravado com `/ef-esclarecer <ID>` e gerado depois com `feature=` (E3) ou com a lista de histórias (E5).
| `/ef-dev` | E6 | `TK-nn.nn.nn-nn` | `SP-nn.nn.nn` |

**Três pontos de trava** em toda etapa que invoca agente (`/ef-insumos` não tem upstream e aplica só os pontos 2 e 3):

```mermaid
flowchart TD
    GE["gate de entrada conferido"] --> P1{"1. pré-checagem (orquestrador)<br/>há bloqueante que bloqueia a execução?"}
    P1 -- sim --> R1["rodada obrigatória<br/>/ef-esclarecer, só bloqueantes"]
    R1 -- "zero bloqueantes" --> AG["agente invocado"]
    R1 -- "alguma pulada" --> X1(["comando encerra:<br/>etapa BLOQUEADA por Q-nnn"])
    P1 -- não --> AG
    AG --> P2{"2. revisão pelo agente<br/>alguma Q-nnn impede esta etapa?"}
    P2 -- "sim: existente ou elevada" --> B["relatório BLOQUEADO:<br/>nada produzido nem alterado"]
    B --> R1
    P2 -- não --> W["agente trabalha"]
    W --> P3{"3. pós-checagem<br/>criou bloqueante nova?"}
    P3 -- não --> ER(["artefato em-revisao<br/>comando sugere o gate"])
    P3 -- sim --> RS["artefato fica em rascunho"] --> R3["rodada obrigatória"]
    R3 -- "zero bloqueantes" --> INC(["modo incorporação<br/>em-revisao, comando sugere o gate"])
    R3 -- "alguma pulada" --> X3(["comando encerra:<br/>artefato em rascunho, BLOQUEADO"])
```

1. **Pré-checagem (orquestrador).** Logo depois da checagem do gate de entrada e antes de invocar o agente, o orquestrador lista as Q-nnn que bloqueiam a execução. Havendo qualquer uma, não invoca o agente: mostra a lista e executa a **rodada obrigatória** de `/ef-esclarecer` restrita a elas. A etapa só segue com zero bloqueantes; se o usuário pular alguma, o comando encerra informando que a etapa está bloqueada e por quais Q-nnn, sem invocar o agente.
2. **Revisão pelo agente ("reaver questões").** O primeiro passo obrigatório de todo agente é revisar as Q-nnn abertas, de qualquer prioridade, ligadas às suas entradas e ao seu alvo, e decidir se alguma impede o trabalho desta etapa. O agente pode elevar uma Q-nnn existente: `prioridade: bloqueante`, alvo ou etapa atual acrescentados em `bloqueia` e 1 linha em `motivo-bloqueio`. É a única edição permitida numa Q-nnn existente; o agente nunca rebaixa prioridade nem muda status. Havendo bloqueante (existente ou elevada agora), o agente não produz nem altera o artefato e devolve relatório começando com `BLOQUEADO:` e a lista de Q-nnn. O orquestrador executa a rodada obrigatória e, zerados os bloqueantes, invoca o agente de novo.
3. **Pós-checagem.** Se durante o trabalho o agente criar Q-nnn nova `bloqueante`, entrega o artefato em `rascunho` (não `em-revisao`) e o relatório lista as bloqueantes. O orquestrador executa a rodada obrigatória e, zerados os bloqueantes, aciona o modo incorporação; só então o artefato vai a `em-revisao` e o comando sugere o gate. Se o usuário pular alguma, o artefato fica em `rascunho` e o comando encerra informando o bloqueio. Em E6 não há artefato no `epic-flow`: a task não vai a `execucao: em-review` enquanto houver bloqueante nova.

O gate aplica a mesma trava: com bloqueante aberta ligada ao artefato ou aos filhos que ele cobre, `/ef-aprovar` recusa o gate e só oferece esclarecer agora ou cancelar. Não há aprovação por cima de bloqueante.

**Saídas de uma bloqueante.** São só três, todas decisões humanas registradas pelo orquestrador na própria Q-nnn (ou editadas pelo humano no arquivo, `via: arquivo`):

| Saída | Registro na Q-nnn |
|---|---|
| (a) responder | `status: respondida`, `resposta`, `respondido-por`, `respondido-em`, `via` |
| (b) descartar ("não se aplica", com confirmação do usuário) | `status: descartada`, motivo em `resposta` e demais campos de resposta |
| (c) reclassificar para `importante` ou `menor` | nova `prioridade`, `reclassificada-por`, `reclassificada-em` e `justificativa-reclassificacao` (obrigatória); `status` continua `aberta` |

Agente não usa nenhuma das três. Q-nnn reclassificada por humano não é elevada de novo pelo agente: se um fato novo voltar a impedir a etapa, o agente abre Q-nnn nova `bloqueante` citando a anterior.

## 5. Paralelismo

- Épicos diferentes podem andar em paralelo.
- Features diferentes do mesmo épico podem andar em paralelo, cada uma na sua etapa.
- Uma feature só entra em E4 com suas histórias aprovadas em G3.
- Uma história só entra em E5 com a Arquitetura de Solução da sua feature aprovada em G4.
- Uma task só entra em E6 com spec e tasks aprovadas em G5.
- Duas features que alteram o mesmo componente da base comum devem ter o delta conciliado pelo arquiteto antes de G4 da segunda feature.

## 6. Papel do orquestrador

O orquestrador é a sessão principal do Claude Code, conduzida por um humano. Ele não é um agente da squad e não é dono de artefato.

| Faz | Não faz |
|---|---|
| Dispara o subagente da etapa (`pm`, `po`, `arquiteto`, `tech-lead`, `desenvolvedor`) com as entradas aprovadas | Não pula gate |
| Confere DoR antes de disparar e DoD antes de submeter ao gate | Não aprova artefato em nome do aprovador humano |
| Leva o artefato ao aprovador humano e registra o resultado (status, versão) | Não edita artefato de outro dono para "acelerar" |
| Mantém a rastreabilidade (IDs, `origem`, links) consistente | Não decide questão Q-nnn |
| Mantém `transversal/decisoes-e-questoes.md`, encaminha Q-nnn ao dono e reabre gates quando uma mudança é aprovada | Não lê `fotos/` |
| Conduz a rodada de esclarecimento (§4): pergunta ao humano, registra a resposta na Q-nnn (`via: esclarecimento`) e aciona o agente dono para incorporá-la | Não responde Q-nnn por conta própria nem reabre artefato `aprovado` sozinho |
| Aplica a [trava de bloqueantes](#trava-de-bloqueantes) (§4): pré-checagem antes de invocar o agente, rodada obrigatória diante de `BLOQUEADO:` ou de bloqueante nova, recusa do gate com bloqueante aberta | Não invoca agente nem aprova gate com bloqueante aberta; não reclassifica bloqueante sem decisão humana com justificativa |
| Passa a cada agente a Regra de Isolamento (§7) e a lista explícita das fontes permitidas da execução, incluindo as referências corporativas aplicáveis à etapa | Não usa memória, análises anteriores nem contexto de sessões anteriores; se o usuário pedir algo fora dos insumos, orienta a registrar via `/ef-insumos` |
| Paraleliza épicos e features quando as regras da seção 5 permitem | |

## 7. Isolamento de fontes

A análise que serviu para **desenhar** este fluxo não é fonte de conteúdo ao **aplicá-lo**. Ao aplicar o fluxo, só as fontes abaixo podem ser lidas e citadas.

Fontes permitidas:

1. Os arquivos registrados via `/ef-insumos`: as fichas `epic-flow/insumos/IN-nnn-*.md` e os arquivos apontados no campo `fonte` delas. Também os insumos do épico registrados via `/ef-epico EP-nn insumos=<pasta>`: as fichas `epic-flow/epicos/EP-nn-*/insumos/IN-EPnn-*.md` e os arquivos apontados no campo `fonte` delas. E os insumos de feature e de história registrados via `/ef-features EP-nn feature=FT-nn.nn insumos=<pasta>` ou `historia=US-nn.nn.nn insumos=<pasta>`: as fichas `.../FT-nn.nn-*/insumos/IN-FTnn.nn-*.md` e `.../FT-nn.nn-*/historias/insumos/US-nn.nn.nn/IN-USnn.nn.nn-*.md` e os arquivos no `fonte` delas. As quatro séries são as **fichas de insumo (`IN-*`)** ([04](04-convencoes.md) §1); nas etapas seguintes, as fichas `IN-*` citadas pelos artefatos upstream são fonte permitida.
2. Os artefatos produzidos pelo próprio fluxo em `epic-flow/`: mapa de épicos, PRDs, arquiteturas, features, histórias, specs, tasks e `transversal/`. Respostas registradas em Q-nnn respondidas são fonte permitida: a resposta de uma `Q-nnn` com `status: respondida` em `transversal/decisoes-e-questoes.md` (registrada pelo orquestrador na rodada de esclarecimento ou editada pelo humano) é decisão humana e é citada como `Q-nnn`.
3. Os documentos de processo e os templates em `epic-flow/processo/` e `epic-flow/templates/`.
4. As referências corporativas listadas em `epic-flow/referencias/README.md` (fontes fixas configuráveis por projeto: stack de tecnologia, arquitetura corporativa, padrões de desenvolvimento), lidas por cada agente conforme a etapa indicada ali.

Proibido:

- qualquer outro arquivo ou pasta do repositório (ex.: `docs-final/`, análises anteriores, anexos, briefs);
- memória ou contexto de sessões anteriores;
- conhecimento prévio sobre o projeto.

Nomes, IDs, siglas e decisões só podem aparecer num artefato se estiverem nas fontes permitidas.

Regras:

- Informação ausente nas fontes vira `Q-nnn` em `transversal/decisoes-e-questoes.md`; nunca é completada com conhecimento externo.
- Inferência feita a partir das fontes permitidas continua marcada "(inferido)".
- Referências corporativas do projeto: configuradas em `epic-flow/referencias/README.md` (hoje, tudo dentro de `epic-flow/referencias/`: `stack-tech.md` e as pastas `arquitetura-corporativa/` e `padroes-desenvolvimento/`; fontes fixas, versionadas fora dos insumos). Os agentes descobrem os caminhos só por esse arquivo. Para outro projeto, basta mudar os caminhos ou acrescentar categorias.
- Arquiteto, tech-lead e desenvolvedor usam a stack da referência corporativa `stack`. Referência vazia ou ausente não bloqueia: o agente registra `Q-nnn` ("referência corporativa `<categoria>` ausente") e segue. Divergência entre referência corporativa e insumo vira `Q-nnn`.
- Nomes de tecnologia (plataformas, produtos) podem aparecer em artefatos gerados quando vierem da referência `stack` ou dos insumos; nos templates e documentos de processo ficam placeholders genéricos (`<plataforma>`).
- `/ef-insumos` aceita a pasta ou os arquivos que o usuário indicar no argumento. Só o que for registrado ali entra no fluxo; nenhuma ficha é criada para arquivo fora do argumento. Vale o mesmo para `/ef-epico EP-nn insumos=<pasta>`: só os arquivos da pasta indicada ganham ficha `IN-EPnn-nn`; e para `/ef-features ... insumos=<pasta>` (fichas `IN-FTnn.nn-nn` ou `IN-USnn.nn.nn-nn`, só com `feature=` ou `historia=` de alvo já existente).
- IDs, siglas ou nomes que aparecem literalmente nos insumos são citados em `refs-insumos`, sempre com o `IN-nnn` de origem (ex.: `[IN-003:RP-12]`); as séries de ID do fluxo são próprias e começam em 01 ([04-convencoes.md](04-convencoes.md) §1 e §5).
- Em E6, o repositório de código indicado no campo `repositorio` da task é a área de trabalho do desenvolvedor, não fonte de requisitos: requisitos vêm só da task, da spec e dos artefatos upstream.
- O orquestrador inclui esta regra e a lista explícita das fontes permitidas (fichas de insumo `IN-*` do recorte e artefatos upstream aprovados) no prompt de cada agente.
