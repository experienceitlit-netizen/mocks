# 04 — Convenções

Regras de identificação, estrutura, metadados e status de todos os artefatos do `epic-flow`. Valem para humanos e para os subagentes (`pm`, `po`, `arquiteto`, `tech-lead`, `desenvolvedor`).

Documentos relacionados: [01-fluxo](01-fluxo.md) · [02-squad-agentes](02-squad-agentes.md) · [03-contratos-etapas](03-contratos-etapas.md)

Toda convenção abaixo obedece à Regra de Isolamento ([01-fluxo §7](01-fluxo.md#7-isolamento-de-fontes)): nomes, IDs, siglas e decisões só aparecem num artefato se estiverem nas fontes permitidas.

---

## 1. IDs hierárquicos

O ID carrega a rastreabilidade: de `TK-01.02.03-04` se lê épico 01, feature 02, história 03, task 04.

| Artefato | Formato | Exemplo | Onde nasce | Quem cria | Etapa |
|---|---|---|---|---|---|
| Insumo | `IN-nnn` | `IN-007` | `insumos/IN-007-<slug>.md` | `pm` | E0 |
| Insumo do épico | `IN-EPnn-nn` | `IN-EP01-03` | `epicos/EP-01-<slug>/insumos/IN-EP01-03-<slug>.md` (via `/ef-epico EP-01 insumos=<pasta>`) | `pm` | E1 |
| Insumo da feature | `IN-FTnn.nn-nn` | `IN-FT01.02-01` | `.../features/FT-01.02-<slug>/insumos/IN-FT01.02-01-<slug>.md` (via `/ef-features EP-01 feature=FT-01.02 insumos=<pasta>`) | `pm` | E3 |
| Insumo da história | `IN-USnn.nn.nn-nn` | `IN-US01.02.03-01` | `.../FT-01.02-<slug>/historias/insumos/US-01.02.03/IN-US01.02.03-01-<slug>.md` (via `/ef-features EP-01 historia=US-01.02.03 insumos=<pasta>`) | `pm` | E3 |
| Questão / proposta de mudança | `Q-nnn` | `Q-012` | `transversal/decisoes-e-questoes.md` | qualquer agente ou humano | todas |
| Mapa de épicos | `MAPA` (único) | `MAPA` | `epicos/mapa-epicos.md` | `pm` | E0 |
| Dor (local ao mapa) | `DOR-nn` | `DOR-03` | seção "Dores identificadas" de `epicos/mapa-epicos.md` | `pm` | E0 |
| Épico | `EP-nn` | `EP-01` | linha da tabela de épicos de `epicos/mapa-epicos.md`; o PRD vai em `epicos/EP-01-<slug>/prd.md` | `pm` | E0 (reserva no mapa), E1 (PRD) |
| Arquitetura de Referência | `AR-nn` | `AR-01` | `epicos/EP-01-<slug>/arquitetura-referencia.md` | `arquiteto` | E2 |
| Feature | `FT-nn.nn` | `FT-01.02` | `.../features/FT-01.02-<slug>/feature.md` | `po` | E3 |
| História de usuário | `US-nn.nn.nn` | `US-01.02.03` | `.../FT-01.02-<slug>/historias/US-01.02.03-<slug>.md` | `po` | E3 |
| Arquitetura de Solução | `AS-nn.nn` | `AS-01.02` | `.../FT-01.02-<slug>/arquitetura-solucao.md` | `arquiteto` | E4 |
| Spec (1 por história) | `SP-nn.nn.nn` | `SP-01.02.03` | `.../FT-01.02-<slug>/specs/SP-01.02.03.md` | `tech-lead` | E5 |
| Task | `TK-nn.nn.nn-nn` | `TK-01.02.03-04` | `.../FT-01.02-<slug>/tasks/TK-01.02.03-04.md` | `tech-lead` | E5 |
| Capacidade de negócio | `CAP-nn` | `CAP-03` | seção "Capacidades de negócio" da Arq. Referência (`epicos/EP-01-<slug>/arquitetura-referencia.md`) | `arquiteto` | E2 |
| Decisão de arquitetura | `AD-nn` | `AD-01` | `transversal/adr/AD-01-<slug>.md` | `arquiteto` | E2, E4 |
| Regra parametrizável | `RP-nn` | `RP-01` | `transversal/catalogo-regras.md` | `po` + `tech-lead` | E3, E5 |
| Requisito | `RF-nn`; `RNF-nn` | `RF-01`, `RNF-01` | PRD do épico | `pm` | E1 |
| Marco | `MC-n` | `MC-1` | PRD / Arq. Solução (Implantação/Migração) | `pm`, `arquiteto` | E1, E4 |

Regras:

- Números com zero à esquerda (`EP-01`, `IN-007`) e nunca reutilizados. Artefato descartado vira `obsoleto`; o ID não volta para a fila.
- O ID da spec repete o da história (`US-01.02.03` → `SP-01.02.03`). A task acrescenta um sequencial de 2 dígitos à spec.
- Todas as séries começam em 01 dentro do `epic-flow` (`AD-01`, `RP-01`, `RF-01`, `RNF-01`, `CAP-01`, `MC-1`). Nenhuma série continua numeração de material externo.
- `Q-nnn`, `IN-nnn`, `CAP-nn`, `AD-nn`, `RP-nn`, `RF-nn` e `RNF-nn` são globais ao `epic-flow` (não por épico). Próximo número = maior existente + 1. Em execuções paralelas o orquestrador resolve colisões.
- `IN-EPnn-nn` é série local ao épico `EP-nn`: começa em 01, nunca é reutilizada e o próximo número = maior da pasta `epicos/EP-nn-<slug>/insumos/` + 1. Só é criada por `/ef-epico EP-nn insumos=<pasta>`, com uma ficha por arquivo da pasta indicada.
- `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` seguem a mesma regra, como séries locais à feature e à história: começam em 01, nunca são reutilizadas e o próximo número = maior da pasta de insumos do alvo + 1. Só são criadas por `/ef-features EP-nn feature=FT-nn.nn insumos=<pasta>` ou `/ef-features EP-nn historia=US-nn.nn.nn insumos=<pasta>`, com o alvo já existente (`feature.md` ou arquivo da história).
- **Fichas de insumo (`IN-*`)** é o termo genérico para as quatro séries de ficha: `IN-nnn` (raiz, E0), `IN-EPnn-nn` (épico, E1), `IN-FTnn.nn-nn` (feature, E3) e `IN-USnn.nn.nn-nn` (história, E3). Todas usam o cabeçalho de §7, têm dono `pm` e são fonte permitida (01 §7) quando citadas por um artefato do fluxo.
- Mover uma feature de épico gera nova feature com novo ID; a antiga vira `obsoleto` com `substituido-por`.
- `EP-nn` nasce no mapa de épicos: cada linha reserva um número (próximo = maior do mapa + 1). Épico removido do mapa continua como linha com situação `descartado` e o ID não volta para a fila. O PRD usa o `EP-nn` reservado; não existe PRD de épico fora do mapa.
- `CAP-nn` nasce só na Arq. Referência (E2, `arquiteto`), na camada Estratégia, como elemento `STR-CAP<n>` com o `CAP-nn` no rótulo; próximo número = maior existente nas ARs + 1. Mapa de épicos (E0) e PRD (E1) não tratam capacidades (§5.1).
- `DOR-nn` é local ao mapa e não se confunde com Drivers ArchiMate (`MOT-D<n>`) (§5.4).
- Épicos só existem a partir do mapa, derivados das fichas `IN-nnn`. Não use `E<n>` para épico: `E0`–`E6` são as etapas do fluxo.

---

## 2. Estrutura de pastas

```
epic-flow/
  README.md
  referencias/                      # referências corporativas (fixas)
    README.md                       # configuração: categorias, caminhos, quem usa
    stack-tech.md                   # stack de tecnologia
    arquitetura-corporativa/        # arquitetura de referência corporativa
    padroes-desenvolvimento/        # padrões de desenvolvimento
  processo/
    01-fluxo.md
    02-squad-agentes.md
    03-contratos-etapas.md
    04-convencoes.md
  templates/
    README.md                       # templates do próximo passo
  insumos/
    README.md                       # índice de insumos
    IN-001-<slug>.md                # ficha do insumo (aponta para o original, sem cópia)
  transversal/                      # base comum
    README.md
    glossario.md
    catalogo-componentes.md
    catalogo-regras.md
    decisoes-e-questoes.md
    adr/
      AD-01-<slug>.md
  epicos/
    README.md
    mapa-epicos.md                            # E0, pm (MAPA, G0)
    EP-01-<slug>/
      insumos/                                # E1, pm (só com /ef-epico EP-01 insumos=<pasta>)
        README.md                             # índice das fichas do épico
        IN-EP01-01-<slug>.md                  # ficha do insumo do épico (aponta para o original, sem cópia)
      prd.md                                  # E1, pm
      arquitetura-referencia.md               # E2, arquiteto
      features/
        FT-01.01-<slug>/
          insumos/                            # E3, pm (só com /ef-features EP-01 feature=FT-01.01 insumos=<pasta>)
            README.md                         # índice das fichas da feature
            IN-FT01.01-01-<slug>.md           # ficha do insumo da feature
          feature.md                          # E3, po
          historias/
            US-01.01.01-<slug>.md             # E3, po
            US-01.01.02-<slug>.md
            insumos/                          # E3, pm (só com /ef-features EP-01 historia=US-01.01.01 insumos=<pasta>)
              US-01.01.01/
                README.md                     # índice das fichas da história
                IN-US01.01.01-01-<slug>.md    # ficha do insumo da história
          arquitetura-solucao.md              # E4, arquiteto
          specs/
            SP-01.01.01.md                    # E5, tech-lead
            SP-01.01.02.md
          tasks/
            TK-01.01.01-01.md                 # E5, tech-lead
            TK-01.01.01-02.md
        FT-01.02-<slug>/
          ...
    EP-02-<slug>/
      ...
```

O código (E6) não fica em `epic-flow/`. Ele vai para o repositório do componente (`<repositorio-do-componente>`), indicado no campo `repositorio` da task. O PR referencia a task e a spec.

---

## 3. Frontmatter YAML

Todo artefato abre com frontmatter YAML. Campos ausentes ficam com valor vazio (`[]` ou `""`), nunca omitidos.

### 3.1 Campos comuns (obrigatórios em todos os tipos)

| Campo | Tipo | Conteúdo |
|---|---|---|
| `id` | texto | ID conforme §1 |
| `tipo` | enum | `insumo`, `mapa-epicos`, `prd-epico`, `arquitetura-referencia`, `feature`, `historia`, `arquitetura-solucao`, `spec`, `task`, `adr` |
| `titulo` | texto | Nome curto, em português |
| `dono` | enum | `pm`, `po`, `arquiteto`, `tech-lead`, `desenvolvedor`, `orquestrador` |
| `status` | enum | `rascunho`, `em-revisao`, `aprovado`, `obsoleto` (ver §4) |
| `versao` | texto | `0.1`, `0.2`... até a 1ª aprovação; `1.0` na aprovação; `1.1`, `2.0`... depois |
| `data` | data ISO | Data da última alteração (`2026-10-03`) |
| `origem` | lista | IDs upstream do novo fluxo e insumos (`[EP-01, AR-01, IN-003]`) |
| `refs-insumos` | lista | IDs, siglas ou nomes que aparecem literalmente nos insumos, sempre com o IN de origem (`[IN-003:RP-12, IN-005:<sigla>]`), ver §5.2 |
| `questoes-abertas` | lista | `Q-nnn` com status `aberta` que afetam o artefato |
| `aprovado-por` | texto | Nome/papel do humano aprovador. Só humano preenche |
| `aprovado-em` | data ISO | Data da aprovação no gate. Só humano preenche |
| `substituido-por` | texto | ID do sucessor, quando `obsoleto` |

### 3.2 Campos específicos por tipo

| Tipo | Campos adicionais obrigatórios |
|---|---|
| `insumo` | ver §7 (cabeçalho de insumo) |
| `mapa-epicos` | `insumos` (`[IN-001, IN-002]`, fichas usadas), `epicos` (`[EP-01, EP-02]`, todos os reservados, inclusive descartados), `gate: G0` |
| `prd-epico` | `insumos` (`[IN-001, IN-EP01-01]`, fichas da raiz e do épico usadas), `gate: G1`; `origem` inclui `MAPA` |
| `arquitetura-referencia` | `epico`, `camadas: [motivacao, estrategia, negocio]`, `capacidades` (`[CAP-01, CAP-02]`, saída da AR: capacidades novas ou reutilizadas), `adrs` (`[AD-01, AD-02]`), `gate: G2` |
| `feature` | `epico`, `capacidades` (`CAP-nn` da AR aprovada), `sequencia` (ordem no épico), `depende-de` (`[FT-01.01]`), `marco` (`MC-n`, opcional), `gate: G3`; `origem` inclui as fichas `IN-FTnn.nn-nn` usadas |
| `historia` | `feature`, `capacidades` (`CAP-nn` da AR aprovada), `rf` (`[RF-01]`), `rnf` (`[RNF-02]`), `regras-rp` (`[RP-12]`), `tipo-historia` (`negocio` ou `habilitadora`), `depende-de`, `gate: G3`; `origem` inclui as fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` usadas |
| `arquitetura-solucao` | `feature`, `epico`, `camadas: [aplicacao, tecnologia, implantacao-migracao]`, `componentes-novos`, `componentes-alterados`, `componentes-reutilizados`, `adrs`, `gate: G4` |
| `spec` | `historia`, `componentes` (`[<componente-a>, <componente-b>]`, nomes do catálogo), `complexidade` (`P`, `M`, `G`, `GG`, ver §3.4), `gate: G5` |
| `task` | `spec`, `estimativa` (pontos 1, 2, 3, 5 ou 8; acima de 8, quebrar), `depende-de` (`[TK-01.02.03-01]`), `repositorio`, `pr` (link, preenchido em E6), `execucao` (`pendente`, `em-andamento`, `em-review`, `concluida`; o `desenvolvedor` move até `em-review`), `g6-aprovado-por` e `g6-aprovado-em` (só humano, no code review), `gate: G5` (o G5 aprova a task; o G6 fica registrado nos campos `g6-*`) |
| `adr` | `decisao` (`proposta`, `aceita`, `rejeitada`, `substituida`), `impacta` (`[AD-01, AD-02]`), `alternativas` (lista), `gate: G2` (ADR nascida em E2) ou `G4` (nascida em E4) |

### 3.3 Exemplo (história)

```yaml
---
id: US-01.02.03
tipo: historia
titulo: Simular resultado por cenário sem efetivar
dono: po
status: rascunho
versao: 0.1
data: 2026-10-03
origem: [FT-01.02, EP-01, AR-01, IN-002]
refs-insumos: [IN-002:RP-12]
questoes-abertas: [Q-003]
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
feature: FT-01.02
capacidades: [CAP-02]
rf: [RF-02]
rnf: [RNF-02]
regras-rp: [RP-03, RP-04]
tipo-historia: negocio
depende-de: [US-01.02.01]
gate: G3
---
```

### 3.4 Escala de complexidade da spec

| Valor | Critério |
|---|---|
| `P` | Mudança localizada em um componente, sem contrato novo nem migração de dados |
| `M` | Um componente com contrato ou modelo de dados novo/alterado, ou dois componentes com integração já existente |
| `G` | Vários componentes, integração nova ou migração de dados; ainda cabe numa spec |
| `GG` | Grande demais para uma spec: a história volta ao `po` via Q-nnn para ser quebrada |

---

## 4. Ciclo de status

```
rascunho ──► em-revisao ──► aprovado ──► obsoleto
   ▲              │             │
   └──────────────┘             └──► em-revisao (mudança aprovada via Q-nnn)
```

| Transição | Quem pode | Condição |
|---|---|---|
| (novo) → `rascunho` | agente dono | DoR da etapa atendido ([03-contratos-etapas](03-contratos-etapas.md)), inclusive zero Q-nnn bloqueantes que bloqueiem a execução |
| `rascunho` → `em-revisao` | agente dono | DoD da etapa atendido; relatório entregue ao orquestrador; nenhuma Q-nnn `bloqueante` aberta ligada ao artefato. Artefato em que o agente criou bloqueante nova **fica em `rascunho`** até a rodada obrigatória zerá-la ([01-fluxo §4](01-fluxo.md#trava-de-bloqueantes)) |
| `em-revisao` → `rascunho` | aprovador humano ou orquestrador | Gate devolveu com ajustes |
| `em-revisao` → `aprovado` | **somente o aprovador humano do gate** | Zero Q-nnn `bloqueante` abertas no artefato e nos filhos que o gate cobre; gate Gx aprovado; preencher `aprovado-por`, `aprovado-em`, `versao: 1.0` (ou próxima maior) |
| `aprovado` → `em-revisao` | dono do artefato, após Q-nnn `respondida` que aprova mudança | Volta pelo mesmo gate |
| qualquer → `obsoleto` | orquestrador (humano) | Substituído ou descartado; preencher `substituido-por` |

Gates e aprovadores:

| Gate | Artefato | Aprovador humano |
|---|---|---|
| G0 Mapa de Épicos | `mapa-epicos.md` + fichas `IN-nnn` que ele cobre | PM humano (com sponsor de negócio quando houver) |
| G1 PRD | `prd.md` + fichas `IN-EPnn-nn` do épico | Sponsor de negócio |
| G2 Arq. Referência | `arquitetura-referencia.md` + ADRs do épico | Comitê de arquitetura |
| G3 Features+Histórias | `feature.md` + `historias/*` + fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` da feature | PM + negócio |
| G4 Arq. Solução | `arquitetura-solucao.md` + ADRs da feature | Comitê de arquitetura |
| G5 Specs+Tasks | `specs/*` + `tasks/*` | Tech Lead + Desenvolvedor (revisão de executabilidade) |
| G6 Code review | PR da task | Tech Lead |

Regras fixas:

- Agente nunca muda status para `aprovado` nem preenche `aprovado-por`/`aprovado-em`, inclusive no próprio artefato.
- Agente só consome entrada com status `aprovado`. Se a entrada estiver em outro status, para e reporta ao orquestrador. Exceção: no E0 o mapa de épicos consome fichas `IN-nnn` ainda não aprovadas, porque elas passam pelo G0 junto com o mapa; da mesma forma, o PRD (E1) consome fichas `IN-EPnn-nn` e a feature e as histórias (E3) consomem fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` ainda não aprovadas, revisadas no G1 e no G3.
- Conteúdo só entra num artefato a partir das fontes permitidas (01 §7); nada de fora delas conta como entrada, aprovada ou não.
- Mudança em artefato `aprovado` exige Q-nnn do tipo `proposta-mudanca` respondida pelo dono da decisão.
- Trava de bloqueantes ([01-fluxo §4](01-fluxo.md#trava-de-bloqueantes)): com Q-nnn `bloqueante` aberta ligada ao alvo, às entradas ou à etapa, nenhum artefato é criado ou alterado pela etapa, nenhum artefato vai a `em-revisao` e nenhum gate aprova.

---

## 5. Capacidades, referências dos insumos e colisões

### 5.1 Capacidades (`CAP-nn`)

- ID global ao `epic-flow`, dono `arquiteto`. Nasce só na Arq. Referência (E2), seção 3.1 "Capacidades de negócio" do template, e é aprovada no G2. Mapa de épicos (E0) e PRD (E1) não identificam capacidades: tratam dores, épicos e requisitos.
- Capacidade de negócio = o que o negócio precisa ser capaz de fazer, estável e independente de processo, sistema ou organização; nome como substantivo ou "Gestão de X". Nível 1–2, tipicamente poucas por épico. Etapas de metodologia, passos e funções do sistema não são capacidades: viram processos `BUS-PR` na AR ou, adiante, features e histórias.
- Reutilização: antes de criar, o `arquiteto` consulta os `CAP-nn` das ARs aprovadas e reutiliza o existente; próximo número = maior `CAP-nn` já usado em qualquer AR + 1. Não há catálogo transversal de capacidades: a lista vive nas ARs (campo `capacidades` e §3.1).
- Alinhamento corporativo: se a referência `arquitetura-corporativa` tiver mapa de capacidades, a AR reutiliza os nomes e registra o vínculo; capacidade nova fora do mapa corporativo é registrada explicitamente, com ADR se for desvio de padrão.
- Na AR vira elemento `STR-CAP<n>` com o `CAP-nn` no rótulo (§6) e entra em `capacidades` do frontmatter.
- Downstream (E3 em diante) só referencia: `capacidades` de feature e história usam `CAP-nn` da AR aprovada do épico, e `foco=CAP-nn` vale a partir de `/ef-features`. O `po` não cria `CAP-nn`.
- Capacidade nova descoberta depois do G2 entra por Q-nnn `proposta-mudanca` contra a AR.

### 5.2 Referências dos insumos (`refs-insumos`)

- Lista no frontmatter de todo artefato com os IDs, siglas ou nomes que aparecem **literalmente** nos insumos e que o artefato cita, sempre com o IN de origem: `[IN-003:RP-12, IN-005:<sigla>]`.
- Citar não é adotar: um ID do insumo nunca vira ID do fluxo nem define a numeração das séries do §1. Quando o insumo usar o mesmo formato de um ID do fluxo (ex.: `RP-12` no insumo e `RP-01` no catálogo), o texto do artefato sempre cita o do insumo com o prefixo `IN-nnn:`.
- Nome ou sigla que não está em nenhuma fonte permitida não entra no artefato (01 §7).

### 5.3 Séries do fluxo

Todas as séries do §1 começam em 01 (`AD-01`, `RP-01`, `RF-01`, `RNF-01`, `CAP-01`, `MC-1`) e são numeradas só pelo fluxo.

### 5.4 Colisões de siglas e como resolver

| Sigla ambígua | Significados que colidem | Regra no fluxo |
|---|---|---|
| `E0`–`E6` | Etapas do fluxo x épicos | Etapas mantêm `E<n>`; épicos são sempre `EP-nn` |
| `G0`–`G6` | Gates x Goals ArchiMate | Gates mantêm `G<n>`; Goals viram `MOT-G<n>` |
| `D<n>` | Drivers ArchiMate x dores do mapa | Drivers viram `MOT-D<n>`; dores do mapa são `DOR-nn` |
| `P<n>`, `R<n>`, `A<n>` | Principles, Requirements e Assessments ArchiMate x siglas dos insumos | Sempre prefixados: `MOT-P<n>`, `MOT-R<n>`, `MOT-A<n>` |
| `T<n>` | Elementos de Tecnologia x tarefas citadas nos insumos | Tecnologia vira `TEC-T<n>`; tarefa do insumo é citada como `IN-nnn:<nome>` |
| Siglas dos insumos | ID ou sigla do insumo com o mesmo formato de um ID do fluxo | Sempre citada com o prefixo `IN-nnn:` (§5.2) |

---

## 6. Prefixos ArchiMate

IDs locais de elementos ArchiMate (dentro de diagramas e tabelas de elementos) **sempre** levam o prefixo da camada. O motivo: IDs curtos (`G1`, `D1`, `P1`, `R1`, `A1`...) colidem com gates, dores e siglas dos insumos (§5.4).

| Prefixo | Camada ArchiMate 3.2 | Artefato | Exemplos |
|---|---|---|---|
| `MOT-` | Motivação (Stakeholder, Driver, Goal, Principle, Requirement, Constraint, Assessment) | Arq. Referência | `MOT-SK1`, `MOT-D1`, `MOT-G1`, `MOT-P1`, `MOT-R1`, `MOT-K1`, `MOT-A1` |
| `STR-` | Estratégia (Capability, Course of Action, Resource, Value Stream) | Arq. Referência | `STR-CAP1`, `STR-CoA1`, `STR-RES1`, `STR-VS1` |
| `BUS-` | Negócio (Actor, Role, Process, Event, Object, Service) | Arq. Referência | `BUS-ACT1`, `BUS-RL1`, `BUS-PR1`, `BUS-EV1`, `BUS-OB1`, `BUS-SV1` |
| `APP-` | Aplicação (Component, Function, Service, Interface, Event, Data Object) | Arq. Solução | `APP-AC1`, `APP-AS1`, `APP-AI1`, `APP-DO1` |
| `TEC-` | Tecnologia (Node, Device, System Software, Technology Service, Artifact, Network) | Arq. Solução | `TEC-N1`, `TEC-T1`, `TEC-ART1` |
| `IMP-` | Implantação e Migração (Work Package, Deliverable, Implementation Event, Plateau, Gap) | Arq. Solução | `IMP-W1`, `IMP-DL1`, `IMP-PL1`, `IMP-GAP1` |

- Elementos que são capacidades usam o `CAP-nn` no rótulo (`STR-CAP1 «Capability» CAP-02 <nome>`). O prefixo identifica o elemento; o `CAP-nn` identifica o conceito.
- Componentes canônicos (`<componente>`) aparecem pelo nome do catálogo (`transversal/catalogo-componentes.md`), com o ID `APP-`/`TEC-` só como chave local do diagrama.
- IDs ArchiMate são locais ao documento. A mesma chave (`APP-AC1`) em duas features não significa o mesmo elemento: o nome canônico é que vale.

---

## 7. Cabeçalho padrão de insumo

Cada insumo tem uma ficha `insumos/IN-nnn-<slug>.md`. O original não é copiado: a ficha aponta para ele em `fonte`.

O mesmo cabeçalho vale para as fichas do épico (`epicos/EP-nn-<slug>/insumos/IN-EPnn-nn-<slug>.md`, §1): `id: IN-EPnn-nn` e `fonte` aponta um arquivo da pasta passada em `/ef-epico EP-nn insumos=<pasta>`.
Vale também para as fichas da feature (`.../FT-nn.nn-<slug>/insumos/IN-FTnn.nn-nn-<slug>.md`) e da história (`.../FT-nn.nn-<slug>/historias/insumos/US-nn.nn.nn/IN-USnn.nn.nn-nn-<slug>.md`), com `fonte` dentro da pasta passada em `/ef-features ... insumos=<pasta>`.

```yaml
---
id: IN-003
tipo: insumo
titulo: <título curto do insumo>
dono: pm
status: rascunho
versao: 0.1
data: 2026-10-03
origem: []
refs-insumos: [IN-003:<sigla-citada>]
questoes-abertas: [Q-004, Q-005]
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
tipo-insumo: fluxo-pipeline        # transcricao | ata | nota | apresentacao | fluxo-pipeline | processo-as-is
fonte: <caminho passado no argumento de /ef-insumos>/<arquivo>
data-insumo: ""                    # data da reunião/documento; vazio se desconhecida
autor-reuniao: ""                  # autor ou reunião de origem; vazio se desconhecido
produto: []                        # produtos/linhas citados no insumo, ou transversal
temas: []                          # assuntos citados no insumo, texto livre e sem ID
maturidade: parcial                # completo | parcial | truncado
---
```

Corpo da ficha: resumo (até 10 linhas), conceitos e regras identificados (com `arquivo:L<linha>`), e pendências.

**Pendências viram Q-nnn.** Toda marca no original do tipo `[...]`, "cortado", "truncado", "(Dúvida!)", "?" de negócio ou lista incompleta vira uma Q-nnn em `transversal/decisoes-e-questoes.md`, com a linha de origem. A ficha lista as Q-nnn em `questoes-abertas` e o PRD as herda.

Maturidade:

| Valor | Critério |
|---|---|
| `completo` | Sem trechos cortados; regras com valores |
| `parcial` | Legível de ponta a ponta, mas com "(Dúvida!)", regras sem valor ou referências externas não fornecidas |
| `truncado` | Trechos cortados ou páginas faltando |

---

## 8. Questões e propostas de mudança (Q-nnn)

Arquivo único: `transversal/decisoes-e-questoes.md`. Dono do arquivo: orquestrador. Qualquer agente **acrescenta** Q-nnn e pode **elevar** uma Q-nnn existente a `bloqueante` (trava de bloqueantes, [01-fluxo §4](01-fluxo.md#trava-de-bloqueantes)); status, resposta e reclassificação mudam só por decisão humana, registrada pelo orquestrador na rodada de esclarecimento (`/ef-esclarecer`, [01-fluxo §4](01-fluxo.md#4-retroalimentação)) ou editada direto no arquivo pelo humano.

Índice no topo do arquivo:

| ID | Tipo | Prioridade | Título | Artefato afetado | Aberta por | Dono da decisão | Status | Bloqueia |
|---|---|---|---|---|---|---|---|---|
| Q-001 | questao | bloqueante | <título da questão> | EP-01 | pm | <papel humano> | aberta | US-01.01.02, SP-01.01.02 |

Uma seção por questão:

```markdown
### Q-001 — <título da questão>

- tipo: questao                       # questao | proposta-mudanca
- prioridade: bloqueante              # bloqueante | importante | menor
- artefato-afetado: EP-01
- aberta-por: pm
- aberta-em: 2026-10-03
- dono-decisao: <papel humano>        # nunca um agente
- status: aberta                      # aberta | respondida | descartada
- bloqueia: [US-01.01.02, SP-01.01.02]
- refs-insumos: [IN-007:<sigla>]       # pendência citada no insumo, com IN de origem
- fonte: IN-007:L210                   # ou <arquivo da fonte>:L<linha>
- contexto: <o que se sabe; até 5 linhas>
- pergunta: <curta e objetiva, respondível sem abrir o insumo>
- opcoes:                             # 2 a 4 respostas candidatas; [] quando a resposta é livre (número, nome)
  - A) <rótulo curto> — <consequência em 1 linha>
  - B) <rótulo curto> — <consequência em 1 linha> (inferido)
- resposta: ""                        # texto da opção escolhida ou resposta livre; só por decisão humana
- respondido-por: ""                  # usuário ou papel humano que respondeu
- respondido-em: ""                   # AAAA-MM-DD
- via: ""                             # esclarecimento | arquivo
- gate-de-retorno: ""                 # para proposta-mudanca aprovada: G0..G6
- impacto-downstream: ""              # artefatos que voltam a em-revisao se a mudança for aceita
- motivo-bloqueio: ""                 # 1 linha; preenchido pelo agente que elevou a Q a bloqueante
- reclassificada-por: ""              # humano que rebaixou a bloqueante (importante | menor)
- reclassificada-em: ""               # AAAA-MM-DD
- justificativa-reclassificacao: ""   # obrigatória na reclassificação
```

Prioridade (obrigatória):

| `prioridade` | Quando usar |
|---|---|
| `bloqueante` | Sem a resposta não dá para decidir escopo, fronteira (entre épicos, features ou componentes) ou a aprovação do gate, ou a etapa não consegue produzir o artefato. **Trava a etapa e o gate** até ser respondida, descartada ou reclassificada |
| `importante` | Muda o conteúdo do artefato, mas o gate pode ser decidido com a lacuna explícita (`[A DEFINIR]`, "a validar com o negócio") |
| `menor` | Detalhe, valor ou redação que pode ser resolvido na etapa seguinte sem retrabalho relevante |

Opções (obrigatórias):

- 2 a 4 respostas candidatas, cada uma com rótulo curto (até 5 palavras; vira o `label` na rodada de esclarecimento) e consequência em 1 linha (vira a descrição da opção).
- O agente que abre a Q propõe as opções a partir das fontes permitidas (01 §7); opção sem base nas fontes leva "(inferido)" na consequência.
- `proposta-mudanca`: `A) Manter` e `B) <mudança proposta>` (mais alternativas, se houver).
- Questão que não admite opções (resposta numérica, nome, data) usa `opcoes: []` e é perguntada como texto livre.
- A opção "Pular por agora" não entra em `opcoes`: o orquestrador a acrescenta na rodada.

Resposta:

- `resposta`, `respondido-por`, `respondido-em` e `via` são preenchidos só por decisão humana, junto com `status: respondida` (ou `descartada`, com o motivo em `resposta`).
- `via: esclarecimento`: o orquestrador registrou a resposta dada pelo humano em `/ef-esclarecer`. `via: arquivo`: o humano editou o arquivo diretamente.
- `respondido-por` é quem respondeu (padrão "usuário", ou o papel informado); se for diferente do `dono-decisao`, o orquestrador sinaliza no fechamento da rodada.
- Q-nnn sem `prioridade` (anterior a esta convenção) conta como `importante`; sem `opcoes`, é perguntada como texto livre.

Elevação e reclassificação (trava de bloqueantes, [01-fluxo §4](01-fluxo.md#trava-de-bloqueantes)):

- **Elevação (agente).** Ao reavaliar as Q-nnn abertas no início da etapa, o agente pode mudar `prioridade` para `bloqueante`, acrescentar o alvo ou a etapa atual (`E0`…`E6`) em `bloqueia` e preencher `motivo-bloqueio` (1 linha), atualizando as colunas Prioridade e Bloqueia do índice. É a única edição de agente numa Q-nnn existente: nunca rebaixa prioridade, nunca muda `status` nem campos de resposta, e não eleva de novo uma Q com `reclassificada-por` preenchido (fato novo vira Q-nnn nova citando a anterior).
- **Reclassificação (humano).** Uma das três saídas legítimas de uma bloqueante, junto com responder e descartar. O orquestrador registra a nova `prioridade` (`importante` ou `menor`), `reclassificada-por`, `reclassificada-em` e `justificativa-reclassificacao` (obrigatória: sem justificativa, a Q continua `bloqueante`); `status` continua `aberta` e o índice é atualizado.

Regras:

- `bloqueia` lista os IDs (ou as etapas `E0`…`E6`) que não podem ir para `em-revisao` (ou, no caso de specs, gerar tasks) enquanto a Q estiver `aberta`. `prioridade: bloqueante` qualifica a decisão; Q com `bloqueia` preenchido normalmente é `bloqueante`.
- Q-nnn `bloqueante` aberta trava a etapa e o gate ([01-fluxo §4](01-fluxo.md#trava-de-bloqueantes)): bloqueia a execução de etapa cujo alvo, entrada upstream ou a própria etapa aparece em `artefato-afetado` ou `bloqueia` (épico e feature incluem a descendência), e `/ef-aprovar` recusa o gate do artefato ligado. Só sai do caminho respondida, descartada ou reclassificada com justificativa. `importante` e `menor` não travam.
- `proposta-mudanca` contra artefato `aprovado`: se `respondida` com aceite, o dono do artefato o devolve a `em-revisao` e ele passa de novo pelo `gate-de-retorno`.
- Pendências citadas nos insumos (dúvidas, lacunas, decisões pendentes) entram como Q-nnn com `fonte` e, quando o insumo der um ID ou sigla à pendência, `refs-insumos`. Uma Q pode consolidar várias pendências equivalentes.

---

## 9. Inferência e validação

| Marca | Quando usar | Efeito |
|---|---|---|
| `(inferido)` | Afirmação que não está explícita em entrada aprovada nem em insumo; dedução do agente feita só a partir das fontes permitidas | Logo após a frase ou célula. O aprovador do gate confirma ou devolve |
| `a validar com o negócio` | Definição de trabalho que depende de confirmação de negócio | Se bloqueia algo, abrir Q-nnn e citar o ID ao lado: `a validar com o negócio (Q-004)` |
| `[A DEFINIR]` | Lacuna sem definição de trabalho possível | Sempre acompanhada de Q-nnn; o item não vira task |

Nunca inventar valor, regra, nome de tabela ou aprovador. Na dúvida, registrar Q-nnn.

Citação de fontes:

- insumo: `IN-nnn:L<linha>` ou `<arquivo da fonte>:L<linha>` (arquivo apontado em `fonte` de uma ficha);
- artefato do fluxo: `<ID> §<seção>` (ex.: `EP-01 §4`);
- decisão humana registrada: `Q-nnn` (Q-nnn `respondida`; a resposta é fonte permitida, 01 §7);
- referência corporativa: `<categoria>:<arquivo> §<seção>` (ex.: `stack:stack-tech.md §2`), com caminhos resolvidos por `epic-flow/referencias/README.md`.

Fonte fora dessa lista não é citada: o que faltar vira Q-nnn.

---

## 10. Nomes de arquivos

- Formato: `<ID>-<slug>.md` para insumo, épico (pasta), feature (pasta), história e ADR. Specs e tasks usam só o ID (`SP-01.02.03.md`, `TK-01.02.03-04.md`). Documentos fixos têm nome fixo (`prd.md`, `feature.md`, `arquitetura-referencia.md`, `arquitetura-solucao.md`).
- Slug: kebab-case, minúsculo, ASCII sem acento nem cedilha, sem artigos desnecessários, até ~40 caracteres. Ex.: "Simulação por cenário" → `simulacao-por-cenario`.
- ID sempre em maiúsculas no nome do arquivo e no frontmatter.
- Renomear o slug é permitido enquanto `rascunho`. Depois de `aprovado`, o caminho é estável (outros artefatos apontam para ele).
- Links entre artefatos são relativos (`../FT-01.01-<slug>/feature.md`).

---

## 11. Rastreabilidade (checklist)

- [ ] `origem` de cada artefato aponta para o pai imediato e para os insumos usados.
- [ ] Todo `EP-nn` com PRD existe no mapa de épicos com situação `proposto`; todo `IN-nnn` do mapa está em um épico ou em "Fora do mapa"; toda ficha `IN-EPnn-nn` da pasta do épico está em `insumos` do PRD.
- [ ] Toda ficha `IN-FTnn.nn-nn` da pasta da feature está em `origem` de `feature.md` (ou de uma história dela); toda ficha `IN-USnn.nn.nn-nn` está em `origem` da sua história.
- [ ] `refs-insumos` cita, com o `IN-nnn` de origem, os IDs, siglas e nomes dos insumos usados.
- [ ] Todo `CAP-nn` nasce numa Arq. Referência (seção "Capacidades de negócio", dono `arquiteto`); todo `CAP-nn` citado em feature ou história existe em `capacidades` da AR aprovada do épico. Mapa e PRD não citam `CAP-nn`.
- [ ] `feature.md` lista as histórias com status; `prd.md` lista as features (após E3).
- [ ] Toda RP citada em história existe em `transversal/catalogo-regras.md`.
- [ ] Todo componente citado em Arq. Solução ou spec existe em `transversal/catalogo-componentes.md` (ou está em `componentes-novos`).
- [ ] Toda Q-nnn em `questoes-abertas` existe em `decisoes-e-questoes.md` com status `aberta`.
- [ ] PR cita `TK-` e `SP-` no título ou na descrição.
