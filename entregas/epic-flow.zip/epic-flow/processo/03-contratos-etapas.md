# 03. Contratos por etapa

Para cada etapa E0–E6: dono, entradas, saídas, DoR, DoD e gate. Os agentes (`.claude/agents/*.md`) usam este documento como contrato.

Convenções de ID, frontmatter e status: [04-convencoes.md](04-convencoes.md). Isolamento de fontes: [01-fluxo.md §7](01-fluxo.md#7-isolamento-de-fontes).

Abreviações usadas nos caminhos:

- `<EP>` = `epic-flow/epicos/EP-nn-<slug>/`
- `<FT>` = `<EP>features/FT-nn.nn-<slug>/`

Regras válidas para todas as etapas:

- **Trava de bloqueantes** ([01-fluxo.md §4](01-fluxo.md#trava-de-bloqueantes)), regra crítica: o DoR de toda etapa inclui **zero Q-nnn bloqueantes que bloqueiem a execução** (`aberta`, `prioridade: bloqueante`, ligada ao alvo, a qualquer entrada upstream ou à própria etapa); o DoD de toda etapa inclui **nenhuma bloqueante aberta criada nesta etapa**. O orquestrador confere antes de invocar o agente (pré-checagem); o agente reavalia as Q-nnn abertas como primeiro passo e, com bloqueante, devolve `BLOQUEADO:` sem produzir; bloqueante nova criada no trabalho deixa o artefato em `rascunho` até a rodada obrigatória. Questão `importante` ou `menor` não trava.
- Regra de Isolamento ([01-fluxo.md §7](01-fluxo.md#7-isolamento-de-fontes)): entradas e citações vêm só dos insumos registrados via `/ef-insumos` (fichas `IN-nnn` e arquivos em `fonte`), dos artefatos do próprio fluxo de `processo/`/`templates/` e das referências corporativas listadas em `epic-flow/referencias/README.md` (conforme a etapa); respostas registradas em Q-nnn respondidas são fonte permitida. Informação ausente vira Q-nnn; referência corporativa vazia ou ausente não bloqueia: vira Q-nnn ("referência corporativa `<categoria>` ausente").
- Entrada obrigatória só vale com o status exigido; caso contrário, a etapa não começa (DoR falha).
- Todo artefato de saída tem frontmatter completo (`id`, `tipo`, `titulo`, `dono`, `status`, `versao`, `data`, `origem`, `refs-insumos`, `questoes-abertas`, `aprovado-por`, `aprovado-em`, `substituido-por`), conforme [04](04-convencoes.md) §3; `aprovado-por` e `aprovado-em` são preenchidos só pelo humano no gate.
- `versao` fica em 0.x durante o rascunho e vira 1.0 na primeira aprovação.
- As séries de ID do fluxo começam em 01 (`AD-01`, `RP-01`, `RF-01`, `RNF-01`, `CAP-01`); IDs e siglas citados nos insumos entram em `refs-insumos` com o `IN-nnn` de origem.
- O agente entrega o artefato em `em-revisao` (ou em `rascunho`, se criou bloqueante nova); só o aprovador humano muda para `aprovado`.
- Dúvida ou proposta de mudança vira Q-nnn (`tipo: questao | proposta-mudanca`), com `prioridade` e `opcoes` ([04](04-convencoes.md) §8), apenas acrescentada a `transversal/decisoes-e-questoes.md`; inferência é marcada "(inferido)".
- Q-nnn bloqueante aberta recusa o gate: `/ef-aprovar` lista as Q-nnn `bloqueante` abertas do artefato e dos filhos e só oferece esclarecer agora ou cancelar. Saídas de uma bloqueante (decisão humana): responder, descartar ou reclassificar para `importante`/`menor` com justificativa.
- Respostas de Q-nnn colhidas na rodada de esclarecimento ([01-fluxo.md §4](01-fluxo.md#rodada-de-esclarecimento)) são registradas só pelo orquestrador e incorporadas ao artefato pelo agente dono, em modo incorporação.
- Nunca ler `fotos/`.

## E0 Insumos

| Campo | Contrato |
|---|---|
| Dono | `pm` |
| Entradas obrigatórias | Pasta ou arquivos indicados pelo usuário no argumento de `/ef-insumos` (transcrições, atas, notas, apresentações, docs de fluxo de pipeline, processos AS-IS); sem exigência de status. Para o mapa: fichas `IN-nnn` do recorte |
| Entradas opcionais / base comum | `transversal/glossario.md` (vigente); `transversal/decisoes-e-questoes.md` (vigente) |
| Saídas | (1) Ficha `insumos/IN-nnn-<slug>.md` (uma por insumo, com cabeçalho padrão em frontmatter, apontando para o original sem copiá-lo); índice em `insumos/README.md`; Q-nnn para trechos truncados ou "(Dúvida!)". (2) Mapa de épicos `epicos/mapa-epicos.md` (id `MAPA`, tipo `mapa-epicos`, template `templates/mapa-epicos.md`): épicos `EP-nn` com nome, descrição curta, dores `DOR-nn` e insumos de origem; sobreposições e fronteiras; o que ficou fora do mapa. O mapa não trata capacidades de negócio (nascem em E2) |
| Gate e aprovador | G0 Mapa de Épicos, aprovador: PM humano (com sponsor de negócio quando houver). As fichas `IN-nnn` são revisadas junto com o mapa. |

DoR:

- [ ] Material bruto indicado pelo usuário no argumento de `/ef-insumos` e acessível (fora de `fotos/`)
- [ ] Produto ou iniciativa de referência conhecido
- [ ] Para o mapa: fichas `IN-nnn` do recorte existem; se o mapa já estiver `aprovado`, há Q-nnn `proposta-mudanca` respondida contra `MAPA`
- [ ] Zero Q-nnn bloqueantes que bloqueiem a execução (trava de bloqueantes; em `/ef-insumos`, sem upstream, vale a revisão do agente)

DoD:

- [ ] Todo insumo tem `IN-nnn` e cabeçalho padrão de [04](04-convencoes.md) §7 (`tipo-insumo`, `fonte`, `data-insumo`, `autor-reuniao`, `produto`, `temas` (assuntos em texto livre, sem ID), `maturidade`: completo, parcial, truncado)
- [ ] Índice em `insumos/README.md` atualizado
- [ ] Trechos truncados e "(Dúvida!)" registrados como Q-nnn
- [ ] Termos novos propostos ao glossário via Q-nnn
- [ ] Mapa de épicos com uma linha por épico (`EP-nn`, nome, descrição, dores, insumos, situação `proposto` ou `descartado`), derivado só das fichas `IN-nnn`
- [ ] Mapa conciso: épico é agrupamento de valor, não lista de etapas, componentes ou funcionalidades; descrição com até 2 linhas, sem metodologia, fórmulas, passos ou regras; tipicamente 3 a 8 épicos
- [ ] Dores agrupadas e deduplicadas, 1 linha cada, apontando a dor e não a solução
- [ ] Sem capacidades de negócio (`CAP-nn`) nas fichas e no mapa
- [ ] Todo `IN-nnn` do recorte aparece em ao menos um épico ou em "Fora do mapa"
- [ ] Toda `DOR-nn` é atacada por ao menos um épico ou justificada em "Fora do mapa"
- [ ] Épicos agrupados por valor de negócio e dor, não por componente técnico; sobreposições com o corte adotado
- [ ] Q-nnn com `prioridade` e `opcoes`; rodada de esclarecimento oferecida para as `importante`
- [ ] Nenhuma bloqueante aberta criada nesta etapa (respondida, descartada ou reclassificada com justificativa na rodada obrigatória)
- [ ] Mapa e fichas em `em-revisao`, prontos para G0

Rastreabilidade:

- [ ] Todo `IN-nnn` aponta em `fonte` um caminho passado no argumento de `/ef-insumos`
- [ ] Toda Q-nnn aberta aponta o `IN-nnn` de origem (`fonte` e, quando houver, `refs-insumos`)
- [ ] `insumos` e `epicos` do frontmatter do mapa batem com as tabelas; `EP-nn` descartados mantidos

## E1 PRD do Épico

| Campo | Contrato |
|---|---|
| Dono | `pm` |
| Entradas obrigatórias | `epicos/mapa-epicos.md` com status `aprovado` (G0) e o `EP-nn` em situação `proposto`; fichas `IN-nnn` da linha do épico |
| Entradas opcionais / base comum | `transversal/glossario.md`; `transversal/decisoes-e-questoes.md`; `transversal/adr/` (decisões vigentes); IN-nnn extras indicados pelo orquestrador; pasta `insumos=<pasta>` de `/ef-epico` com material específico do épico |
| Saídas | `<EP>prd.md` (id `EP-nn` reservado no mapa, tipo `prd-epico`; um PRD por épico do mapa): problema, objetivos, personas, escopo/não-escopo, métricas, requisitos `RF-nn`/`RNF-nn`, features candidatas (hipótese), riscos, questões abertas. O PRD não trata capacidades de negócio (nascem em E2). Com `insumos=<pasta>`, antes do PRD uma invocação própria do `pm` registra as fichas do épico `epicos/EP-nn-<slug>/insumos/IN-EPnn-nn-<slug>.md` (uma por arquivo da pasta, cabeçalho de [04](04-convencoes.md) §7) e o índice `epicos/EP-nn-<slug>/insumos/README.md`; o PRD usa todas as fichas do épico |
| Gate e aprovador | G1 PRD, aprovador: sponsor de negócio. As fichas `IN-EPnn-nn` do épico são revisadas junto com o PRD. |

DoR:

- [ ] Mapa de épicos `aprovado` (G0)
- [ ] `EP-nn` presente no mapa com situação `proposto`
- [ ] Fichas `IN-nnn` da linha do épico existem
- [ ] Com `insumos=<pasta>`: pasta acessível, fora de `fotos/`, com arquivos; só os arquivos dela ganham ficha do épico
- [ ] Sponsor de negócio identificado
- [ ] Zero Q-nnn bloqueantes que bloqueiem a execução (trava de bloqueantes)

DoD:

- [ ] Problema, objetivos e personas descritos
- [ ] Escopo e não-escopo explícitos
- [ ] Métricas de sucesso mensuráveis
- [ ] Riscos listados, com a fonte (`IN-nnn`) quando vierem dos insumos
- [ ] Questões abertas listadas como Q-nnn, incluindo pontos truncados e "(Dúvida!)"
- [ ] Requisitos como `RF-nn`/`RNF-nn` (série do fluxo), em linguagem de negócio e com a fonte `IN-nnn`; IDs citados nos insumos em `refs-insumos`; sem `CAP-nn`
- [ ] Q-nnn com `prioridade` e `opcoes`; rodada de esclarecimento oferecida para as `importante`
- [ ] Nenhuma bloqueante aberta criada nesta etapa (respondida, descartada ou reclassificada com justificativa na rodada obrigatória)
- [ ] Fichas do épico (quando houver) com cabeçalho de [04](04-convencoes.md) §7, índice do épico atualizado e pendências registradas como Q-nnn
- [ ] PRD e fichas do épico em `em-revisao`, prontos para G1

Rastreabilidade:

- [ ] `origem` do PRD lista `MAPA` e os `IN-nnn` e `IN-EPnn-nn` usados; `insumos` do PRD cita todas as fichas da pasta do épico
- [ ] Toda ficha `IN-EPnn-nn` aponta em `fonte` um arquivo da pasta passada em `insumos=`
- [ ] Escopo coerente com a descrição, dores e fronteiras do épico no mapa; mudança de fronteira vira Q-nnn contra `MAPA`
- [ ] Toda afirmação de escopo aponta ao menos um `IN-nnn`
- [ ] Inferências marcadas "(inferido)"

## E2 Arquitetura de Referência

| Campo | Contrato |
|---|---|
| Dono | `arquiteto` |
| Entradas obrigatórias | `<EP>prd.md` com status `aprovado` (G1) |
| Entradas opcionais / base comum | `transversal/glossario.md`; `transversal/catalogo-regras.md`; `transversal/catalogo-componentes.md`; `transversal/adr/`; fichas de insumo (`IN-*`, [04](04-convencoes.md) §1) citadas no PRD, inclusive as `IN-EPnn-nn` do épico; `capacidades` das ARs já aprovadas (reutilização de `CAP-nn`); referências corporativas `arquitetura-corporativa` (obrigatória: conformidade) e `stack` (`stack-tech.md`), via `epic-flow/referencias/README.md` |
| Saídas | `<EP>arquitetura-referencia.md` (id `AR-nn`): camadas ArchiMate Motivação, Estratégia e Negócio (ArchiMate 3.2, Mermaid + PlantUML), IDs locais prefixados (`MOT-`, `STR-`, `BUS-`); capacidades de negócio `CAP-nn` identificadas aqui (novas ou reutilizadas, campo `capacidades`); ADRs novos em `transversal/adr/AD-nn-<slug>.md`, se houver |
| Gate e aprovador | G2 Arq. Referência, aprovador: comitê de arquitetura |

DoR:

- [ ] PRD `aprovado` em G1
- [ ] Zero Q-nnn bloqueantes que bloqueiem a execução (trava de bloqueantes) (inclui as do PRD; aceitar como risco = reclassificar com justificativa)

DoD:

- [ ] Motivação: stakeholders, drivers, objetivos, princípios e requisitos ligados ao PRD
- [ ] Estratégia: capacidades e cursos de ação ligados aos objetivos
- [ ] Negócio: atores, papéis, processos, serviços e objetos de negócio
- [ ] Diagramas em Mermaid e PlantUML
- [ ] IDs locais prefixados, sem colidir com IDs globais
- [ ] Capacidades de negócio identificadas como `CAP-nn` ([04](04-convencoes.md) §5.1): o que o negócio precisa ser capaz de fazer, nome de capacidade (não etapa nem função), nível 1–2, poucas por épico; etapas e passos modelados como processos `BUS-PR`
- [ ] `CAP-nn` de ARs aprovadas reutilizados; vínculo com o mapa de capacidades da `arquitetura-corporativa` registrado (nova fora dele explícita; desvio com ADR)
- [ ] Cada `CAP-nn` representada como elemento `STR-CAP<n>` (CAP-nn no rótulo) e listada em `capacidades`
- [ ] Seção "Aderência à arquitetura corporativa" preenchida; todo desvio com ADR (ou Q-nnn se a referência estiver ausente)
- [ ] Nenhuma bloqueante aberta criada nesta etapa
- [ ] Status `em-revisao`, pronto para G2

Rastreabilidade:

- [ ] Todo objetivo (`MOT-`) aponta um objetivo do PRD
- [ ] Toda capacidade (`STR-`) aponta ao menos um objetivo (`MOT-`)
- [ ] Todo processo de negócio (`BUS-`) aponta ao menos uma capacidade

## E3 Features e Histórias

| Campo | Contrato |
|---|---|
| Dono | `po` |
| Entradas obrigatórias | `<EP>prd.md` `aprovado` (G1); `<EP>arquitetura-referencia.md` `aprovado` (G2) |
| Entradas opcionais / base comum | `transversal/catalogo-regras.md`; `transversal/glossario.md`; `transversal/decisoes-e-questoes.md`; fichas de insumo (`IN-*`) citadas no PRD; alvo `feature=FT-nn.nn` ou `historia=US-nn.nn.nn` (já existente) com pasta `insumos=<pasta>` de `/ef-features`, registrada antes como fichas `IN-FTnn.nn-nn` ou `IN-USnn.nn.nn-nn` |
| Saídas | `<FT>feature.md` (`FT-nn.nn`: valor, escopo, dependências, sequência); `<FT>historias/US-nn.nn.nn-<slug>.md` (`tipo-historia`: `negocio` ou `habilitadora`; como/quero/para, critérios de aceite Dado/Quando/Então, regras RP vinculadas). Com `insumos=`: fichas `<FT>insumos/IN-FTnn.nn-nn-<slug>.md` (feature) ou `<FT>historias/insumos/US-nn.nn.nn/IN-USnn.nn.nn-nn-<slug>.md` (história) + índice `README.md` da pasta, registradas por uma invocação do `pm` antes da do `po` |
| Gate e aprovador | G3 Features+Histórias, aprovadores: PM + negócio. As fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` da feature são revisadas junto com a feature e as histórias |

DoR:

- [ ] PRD `aprovado` (G1) e Arq. Referência `aprovado` (G2)
- [ ] Capacidades do épico (`CAP-nn`) identificadas na Arq. Referência aprovada (G2)
- [ ] Zero Q-nnn bloqueantes do épico (`EP-nn`, `AR-nn`, `E3`); features com bloqueante própria ficam fora do recorte (trava por feature, [01 §4](01-fluxo.md#trava-de-bloqueantes))
- [ ] Com `insumos=<pasta>`: alvo `feature=` ou `historia=` informado e já existente; pasta acessível, fora de `fotos/`, com arquivos; só os arquivos dela ganham ficha; alvo `aprovado` exige Q-nnn `proposta-mudanca` respondida

DoD:

- [ ] Toda feature tem valor, escopo, dependências e posição na sequência
- [ ] Toda história tem `tipo-historia` (`negocio` ou `habilitadora`) e segue como/quero/para
- [ ] Todo critério de aceite está em Dado/Quando/Então e é testável
- [ ] Regras RP aplicáveis vinculadas pelo ID do catálogo de regras
- [ ] Escopo do PRD integralmente coberto pelas features (ou exclusão justificada)
- [ ] Q-nnn abertas (`importante`/`menor`) que afetam histórias listadas em `questoes-abertas`
- [ ] Nenhuma bloqueante aberta nas features entregues ao gate; features bloqueadas listadas no relatório, em `rascunho` ou fora do recorte
- [ ] Fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` (quando houver) com cabeçalho de [04](04-convencoes.md) §7, índice da pasta atualizado e pendências como Q-nnn; com `historia=`, só a história alvo é alterada (nova história ou divisão vira Q-nnn `proposta-mudanca` contra a `FT-nn.nn`)
- [ ] Feature, histórias e fichas do alvo em `em-revisao`, prontas para G3

Rastreabilidade:

- [ ] Toda feature referencia o `EP-nn` e ao menos uma capacidade (`CAP-nn` / `STR-`) da AR aprovada; o `po` não cria `CAP-nn` (faltando, Q-nnn `proposta-mudanca` contra a AR)
- [ ] Toda história referencia sua `FT-nn.nn` e ao menos um RF, RNF, RP ou capacidade `CAP-nn` da AR (história `habilitadora` referencia o RNF que atende)
- [ ] Todo critério de aceite derivado de regra cita o RP ou a referência do insumo (`IN-nnn:L<linha>`, ou o ID da ficha `IN-*` de origem)
- [ ] Toda ficha `IN-FTnn.nn-nn` aponta em `fonte` um arquivo da pasta de `insumos=` e está em `origem` da feature (ou de uma história dela); toda ficha `IN-USnn.nn.nn-nn` idem, em `origem` da sua história

## E4 Arquitetura de Solução da Feature

| Campo | Contrato |
|---|---|
| Dono | `arquiteto` |
| Entradas obrigatórias | `<FT>feature.md` e todas as suas histórias `aprovado` (G3); `<EP>arquitetura-referencia.md` `aprovado` (G2) |
| Entradas opcionais / base comum | `transversal/catalogo-componentes.md`; `transversal/adr/`; `transversal/catalogo-regras.md`; fichas de insumo (`IN-*`) citadas na feature e nas histórias; referências corporativas `stack` (`stack-tech.md`) e `arquitetura-corporativa` (obrigatórias) e `padroes-desenvolvimento` (consulta), via `epic-flow/referencias/README.md` |
| Saídas | `<FT>arquitetura-solucao.md` (id `AS-nn.nn`): camadas ArchiMate Aplicação, Tecnologia, Implantação/Migração como delta (componentes novos, alterados, reutilizados), IDs locais prefixados (`APP-`, `TEC-`, `IMP-`); ADRs `transversal/adr/AD-nn-<slug>.md`; proposta de atualização de `transversal/catalogo-componentes.md` |
| Gate e aprovador | G4 Arq. Solução, aprovador: comitê de arquitetura |

DoR:

- [ ] Todas as histórias da feature `aprovado` em G3
- [ ] Arq. Referência do épico `aprovado` em G2
- [ ] Nenhuma outra feature em E4 alterando o mesmo componente sem conciliação
- [ ] Zero Q-nnn bloqueantes que bloqueiem a execução (trava de bloqueantes)

DoD:

- [ ] Todo componente marcado como `novo`, `alterado` ou `reutilizado`, com link ao catálogo
- [ ] Aplicação: componentes, serviços, interfaces e objetos de dados
- [ ] Tecnologia: nós, plataformas e serviços de infraestrutura aderentes à referência corporativa `stack` (`stack-tech.md`)
- [ ] Seção "Aderência à arquitetura corporativa" preenchida; todo desvio com ADR
- [ ] Implantação/Migração: pacotes de trabalho, plataformas transitórias e convivência com os sistemas atuais (AS-IS)
- [ ] Decisões novas registradas como ADR (`AD-nn`)
- [ ] Diagramas em Mermaid e PlantUML
- [ ] Nenhuma bloqueante aberta criada nesta etapa
- [ ] Status `em-revisao`, pronto para G4

Rastreabilidade:

- [ ] Todo componente da solução existe (ou é proposto) em `transversal/catalogo-componentes.md`
- [ ] Toda história da feature é atendida por ao menos um elemento `APP-`
- [ ] Todo elemento `APP-` aponta um processo/serviço `BUS-` da Arq. Referência
- [ ] Todo ADR novo é citado no artefato e na Q-nnn de origem, se houver

## E5 Specs e Tasks

| Campo | Contrato |
|---|---|
| Dono | `tech-lead` |
| Entradas obrigatórias | `US-nn.nn.nn` `aprovado` (G3); `<FT>arquitetura-solucao.md` `aprovado` (G4) |
| Entradas opcionais / base comum | `transversal/catalogo-componentes.md`; `transversal/catalogo-regras.md`; `transversal/adr/`; fichas de insumo (`IN-*`) citadas na história e na feature; referências corporativas `stack` (`stack-tech.md`) e `padroes-desenvolvimento` (obrigatórias) e `arquitetura-corporativa` (consulta), via `epic-flow/referencias/README.md` |
| Saídas | `<FT>specs/SP-nn.nn.nn.md` (1 por história, complexidade P/M/G/GG, ver [04](04-convencoes.md) §3.4); `<FT>tasks/TK-nn.nn.nn-nn.md` (estimativa em pontos Fibonacci, dependências, `repositorio`, DoD) |
| Gate e aprovador | G5 Specs+Tasks, aprovadores: Tech Lead + Desenvolvedor (revisão de executabilidade) |

Conteúdo mínimo da spec:

| Seção | O que contém |
|---|---|
| Componentes envolvidos | IDs do catálogo, papel de cada um na história |
| Processos | fluxo de execução, incluindo provisionamento de infraestrutura |
| Contratos de API | endpoints, payloads, códigos de erro, versionamento, exposição via gateway |
| Modelo de dados | tabelas, campos, chaves, camadas de dados, migrações |
| Classes/métodos | assinaturas, responsabilidades, pacotes/módulos |
| Processamento de dados / jobs | clusters, notebooks ou scripts, agendamento, dependências — quando aplicável |
| Configuração/parametrização | parâmetros, regras RP aplicadas, `.env`/segredos (sem valores) |
| Testes/critérios técnicos | unitários, integração, contrato, dados; mapeamento para os critérios de aceite |
| Observabilidade | logs, métricas, traces, alertas |
| Segurança | autenticação, autorização, dados sensíveis, segredos |
| Padrões de desenvolvimento aplicados | stack aplicada (`stack-tech.md`) e padrões da referência `padroes-desenvolvimento` usados, com exceções em Q-nnn ou ADR |

DoR:

- [ ] História `aprovado` em G3
- [ ] Arq. Solução da feature `aprovado` em G4
- [ ] Zero Q-nnn bloqueantes da feature (`FT-nn.nn`, `AS-nn.nn`, `E5`); histórias com bloqueante própria ficam fora do recorte (trava por história, [01 §4](01-fluxo.md#trava-de-bloqueantes))

DoD:

- [ ] Spec cobre todas as seções do conteúdo mínimo (ou declara "não se aplica" com motivo)
- [ ] Spec segue a stack (`stack-tech.md`), os ADRs vigentes e os padrões de desenvolvimento; seção "Padrões de desenvolvimento aplicados" preenchida, com exceções em Q-nnn ou ADR
- [ ] Todo critério de aceite da história mapeado para ao menos um teste
- [ ] Spec com complexidade P/M/G/GG ([04](04-convencoes.md) §3.4)
- [ ] Tasks com estimativa em pontos Fibonacci (1, 2, 3, 5, 8; acima de 8, quebrar), dependências, `repositorio` e DoD próprio
- [ ] Tasks pequenas o bastante para um PR cada
- [ ] Nenhuma bloqueante aberta nas specs/tasks entregues ao gate; histórias bloqueadas listadas no relatório, em `rascunho` ou fora do recorte
- [ ] Status `em-revisao`, pronto para G5

Rastreabilidade:

- [ ] Toda spec referencia sua `US-nn.nn.nn` e os componentes do catálogo usados
- [ ] Toda task referencia sua `SP-nn.nn.nn`
- [ ] Toda regra parametrizável citada pelo RP de origem

## E6 Implementação

| Campo | Contrato |
|---|---|
| Dono | `desenvolvedor` |
| Entradas obrigatórias | `TK-nn.nn.nn-nn` `aprovado` (G5); `SP-nn.nn.nn` `aprovado` (G5) |
| Entradas opcionais / base comum | `<FT>arquitetura-solucao.md` (`aprovado`, G4); `transversal/catalogo-componentes.md`; fichas de insumo (`IN-*`) citadas na spec e na história; referências corporativas `stack` (`stack-tech.md`) e `padroes-desenvolvimento` (obrigatórias), via `epic-flow/referencias/README.md`. O repositório de código da task é área de trabalho, não fonte de requisitos |
| Saídas | Código, testes e PR no repositório do componente (campo `repositorio` da task, fora de `epic-flow/`), com `TK-nn.nn.nn-nn` e `SP-nn.nn.nn` na descrição |
| Gate e aprovador | G6 Code review, aprovador: Tech Lead |

DoR:

- [ ] Task e spec `aprovado` em G5
- [ ] Dependências da task concluídas
- [ ] Ambiente local preparado conforme setup do repositório de código
- [ ] Zero Q-nnn bloqueantes que bloqueiem a execução (trava de bloqueantes)

DoD:

- [ ] Código implementa a task conforme a spec, sem alterar a spec
- [ ] Testes escritos e passando (incluindo os mapeados aos critérios de aceite)
- [ ] Observabilidade e segurança da spec implementadas
- [ ] Código segue os padrões de desenvolvimento listados na spec (desvio vira Q-nnn)
- [ ] PR aberto referenciando TK e SP
- [ ] Task com `pr` preenchido e `execucao: em-review` (o G6 é registrado por humano nos campos `g6-*` via `/ef-aprovar`)
- [ ] Desvios da spec registrados como Q-nnn, não resolvidos no código
- [ ] Nenhuma bloqueante aberta criada nesta etapa (com bloqueante nova, a task não vai a `execucao: em-review`)

Rastreabilidade:

- [ ] Todo PR referencia `TK-nn.nn.nn-nn` e `SP-nn.nn.nn`
- [ ] Todo commit da task é rastreável ao PR
- [ ] Todo teste de aceite cita o critério da `US-nn.nn.nn` que cobre

## Resumo

| Etapa | Dono | Entrada obrigatória (status) | Saída | Gate | Aprovador |
|---|---|---|---|---|---|
| E0 Insumos | pm | material bruto | `IN-nnn` + índice + `mapa-epicos.md` (`MAPA`) | G0 Mapa de Épicos | PM humano (+ sponsor quando houver) |
| E1 PRD do Épico | pm | `MAPA` `aprovado` + `EP-nn` `proposto` (+ pasta `insumos=` opcional) | `EP-nn/prd.md` (`EP-nn`) + fichas `IN-EPnn-nn` (opcional) | G1 PRD | sponsor de negócio |
| E2 Arquitetura de Referência | arquiteto | PRD `aprovado` | `arquitetura-referencia.md` (`AR-nn`) | G2 Arq. Referência | comitê de arquitetura |
| E3 Features e Histórias | po (fichas: pm) | PRD + Arq. Ref. `aprovado` (+ `feature=`/`historia=` com pasta `insumos=` opcional) | `FT-nn.nn`, `US-nn.nn.nn` + fichas `IN-FTnn.nn-nn` / `IN-USnn.nn.nn-nn` (opcional) | G3 Features+Histórias | PM + negócio |
| E4 Arquitetura de Solução da Feature | arquiteto | feature + histórias + Arq. Ref. `aprovado` | `arquitetura-solucao.md` (`AS-nn.nn`), `AD-nn` | G4 Arq. Solução | comitê de arquitetura |
| E5 Specs e Tasks | tech-lead | história + Arq. Sol. `aprovado` | `SP-nn.nn.nn`, `TK-nn.nn.nn-nn` | G5 Specs+Tasks | Tech Lead + Desenvolvedor |
| E6 Implementação | desenvolvedor | task + spec `aprovado` | código + testes + PR | G6 Code review | Tech Lead |
