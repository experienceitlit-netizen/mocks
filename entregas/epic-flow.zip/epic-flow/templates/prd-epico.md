---
id: EP-<nn>
tipo: prd-epico
titulo: <titulo-curto>
dono: pm
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: []                         # MAPA + IN-nnn e IN-EPnn-nn usados
refs-insumos: []                   # IDs/siglas/nomes dos insumos, com IN de origem: [IN-003:RP-12]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
insumos: []                        # ex.: [IN-001, IN-EP01-01]; todas as fichas de EP-nn-<slug>/insumos/
gate: G1
---

# EP-<nn> — <titulo-curto>

<!-- Toda afirmação de escopo aponta IN-nnn; dedução marcada (inferido). IDs dos insumos só em refs-insumos, com IN de origem. Capacidades de negócio (CAP-nn) não são tratadas no PRD: nascem na Arq. Referência (E2, arquiteto). -->

## 1. Contexto e problema

TODO <!-- dor atual, quem sofre, evidência (IN-nnn:L<linha>) -->

## 2. Objetivos e métricas de sucesso

| Objetivo | Métrica | Linha de base | Meta | Fonte |
|---|---|---|---|---|
| <objetivo> | <métrica mensurável> | <valor ou [A DEFINIR] (Q-nnn)> | <valor> | <IN-nnn:L<linha>> |

## 3. Personas e stakeholders

| Persona / stakeholder | Necessidade | Envolvimento | Fonte |
|---|---|---|---|
| <persona> | <necessidade> | <usa / aprova / é impactado> | <IN-nnn> |

Sponsor de negócio (aprovador G1): <papel>

## 4. Escopo

- <item de escopo> — <IN-nnn:L<linha>>

## 5. Não-escopo

- <item fora> — <motivo>

## 6. Requisitos

<!-- RF-nn / RNF-nn: série do fluxo, a partir de 01 (próximo = maior existente + 1). Linguagem de negócio, sem solução técnica; toda linha aponta a fonte IN-nnn. -->

| ID | Tipo | Descrição (linguagem de negócio) | Fonte | Refs dos insumos |
|---|---|---|---|---|
| <RF-nn> | funcional | <descrição> | <IN-nnn:L<linha>> | <IN-nnn:<id-ou-sigla>> |
| <RNF-nn> | não funcional | <descrição> | <IN-nnn:L<linha>> | <IN-nnn:<id-ou-sigla>> |

## 7. Features candidatas

<!-- Hipótese para o PO; não é decisão. O PO cria FT-nn.nn em E3, ligando-as às capacidades CAP-nn da Arq. Referência. -->

| Feature candidata | Requisitos (RF/RNF) | Valor esperado |
|---|---|---|
| <nome> | <RF-nn, RNF-nn> | <valor> |

## 8. Dependências e premissas

- Dependência: <épico / sistema / decisão>
- Premissa: <premissa> (inferido)

## 9. Riscos

| Risco | Fonte | Impacto | Mitigação |
|---|---|---|---|
| <risco> | <IN-nnn:L<linha> ou (inferido)> | <alto / médio / baixo> | <mitigação> |

## 10. Questões abertas

| Q-nnn | Prioridade | Título | Bloqueia |
|---|---|---|---|
| Q-<nnn> | <bloqueante / importante / menor> | <título> | <IDs ou "—"> |

## 11. Rastreabilidade de insumos

<!-- Cobre as fichas da raiz (IN-nnn) e as do épico (IN-EPnn-nn, em insumos/ desta pasta). -->

| IN-nnn / IN-EPnn-nn | Seções do PRD que usam |
|---|---|
| IN-<nnn> | <§1, §4, §6> |
| IN-EP<nn>-<nn> | <§4, §6> |

## Checklist DoD E1

- [ ] Problema, objetivos e personas descritos
- [ ] Escopo e não-escopo explícitos
- [ ] Métricas de sucesso mensuráveis
- [ ] Riscos listados, com a fonte (`IN-nnn`) quando vierem dos insumos
- [ ] Questões abertas listadas como Q-nnn, com `prioridade` e `opcoes`, incluindo pontos truncados e "(Dúvida!)"
- [ ] Rodada de esclarecimento oferecida para as `importante`; nenhuma Q-nnn `bloqueante` aberta (trava de bloqueantes: respondida, descartada ou reclassificada com justificativa)
- [ ] Requisitos como `RF-nn`/`RNF-nn` em linguagem de negócio, com a fonte `IN-nnn`; IDs citados nos insumos em `refs-insumos`; sem capacidades (`CAP-nn` nasce na Arq. Referência)
- [ ] `origem` lista `MAPA` e os `IN-nnn` e `IN-EPnn-nn` usados
- [ ] Toda ficha `IN-EPnn-nn` da pasta `insumos/` do épico citada em `insumos` e na §11
- [ ] Escopo coerente com a linha do `EP-nn` no mapa; mudança de fronteira registrada como Q-nnn contra `MAPA`
- [ ] Toda afirmação de escopo aponta ao menos um `IN-nnn`
- [ ] Inferências marcadas "(inferido)"
- [ ] Status `em-revisao`, pronto para G1
