# Template — entrada Q-nnn

<!-- Não vira arquivo próprio: a entrada é ACRESCENTADA ao fim de transversal/decisoes-e-questoes.md (04 §8). -->
<!-- Acrescente também uma linha no índice do topo do arquivo. Próximo número = maior Q existente + 1. -->
<!-- Agente só acrescenta e sempre preenche prioridade e opcoes. Status, resposta, respondido-por, respondido-em e via mudam só por decisão humana: o orquestrador registra na rodada de esclarecimento (/ef-esclarecer, via: esclarecimento) ou o humano edita o arquivo (via: arquivo). -->
<!-- Trava de bloqueantes (01-fluxo §4): bloqueante aberta trava a etapa e o gate. Única edição de agente numa Q existente: elevar a bloqueante (prioridade, bloqueia, motivo-bloqueio). Rebaixar é reclassificação humana com justificativa (campos reclassificada-*). -->
<!-- Pergunta curta e objetiva, que dê para responder sem abrir o insumo, com a fonte citada. -->

Linha do índice:

| ID | Tipo | Prioridade | Título | Artefato afetado | Aberta por | Dono da decisão | Status | Bloqueia |
|---|---|---|---|---|---|---|---|---|
| Q-<nnn> | <questao / proposta-mudanca> | <bloqueante / importante / menor> | <título> | <ID> | <agente ou humano> | <papel humano> | aberta | <IDs> |

Entrada:

```markdown
### Q-<nnn> — <título>

- tipo: <tipo>                        # questao | proposta-mudanca
- prioridade: <prioridade>            # bloqueante (impede decidir escopo, fronteira, aprovação ou produzir o artefato; trava etapa e gate) | importante | menor
- artefato-afetado: <ID ou templates/<arquivo>>
- aberta-por: <agente ou humano>
- aberta-em: <AAAA-MM-DD>
- dono-decisao: <papel humano>        # nunca um agente
- status: aberta                      # aberta | respondida | descartada
- bloqueia: []                        # IDs (ou etapas E0..E6) que não vão a em-revisao enquanto aberta
- refs-insumos: []                    # ID/sigla que o insumo dá à pendência, com IN de origem: [IN-003:<sigla>]
- fonte: <arquivo>:L<linha>           # ou IN-nnn:L<linha> / <ID do artefato> §<seção>; só fontes permitidas (01 §7)
- contexto: <o que se sabe; até 5 linhas>
- pergunta: <curta e objetiva, respondível sem abrir o insumo; em proposta-mudanca, a mudança proposta>
- opcoes:                             # 2 a 4; em proposta-mudanca: A) Manter, B) <mudança>; [] se a resposta é livre (número, nome)
  - A) <rótulo curto> — <consequência em 1 linha>
  - B) <rótulo curto> — <consequência em 1 linha>   # sem base nas fontes: termine com (inferido)
- resposta: ""                        # texto da opção escolhida ou resposta livre; só por decisão humana
- respondido-por: ""                  # usuário ou papel humano que respondeu
- respondido-em: ""                   # AAAA-MM-DD
- via: ""                             # esclarecimento | arquivo
- gate-de-retorno: ""                 # para proposta-mudanca aprovada: G0..G6
- impacto-downstream: <artefatos a revisar se respondida>   # opcional
- motivo-bloqueio: ""                 # 1 linha; só quando um agente elevou a Q a bloqueante
- reclassificada-por: ""              # só por decisão humana: quem rebaixou a bloqueante (importante | menor)
- reclassificada-em: ""               # AAAA-MM-DD
- justificativa-reclassificacao: ""   # obrigatória na reclassificação; status continua aberta
```
