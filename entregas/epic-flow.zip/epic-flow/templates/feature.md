---
id: FT-<nn.nn>
tipo: feature
titulo: <titulo-curto>
dono: po
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [EP-<nn>, AR-<nn>]         # + fichas IN-* usadas (IN-nnn, IN-EPnn-nn, IN-FTnn.nn-nn da pasta insumos/ da feature)
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
epico: EP-<nn>
capacidades: []                    # CAP-nn da AR aprovada do épico (G2), ex.: [CAP-02]; o PO não cria CAP
sequencia: <n>                     # ordem no épico
depende-de: []                     # ex.: [FT-01.01]
marco: ""                          # MC-n, opcional
gate: G3
---

# FT-<nn.nn> — <titulo-curto>

## 1. Descrição e valor

TODO <!-- o que entrega e para quem; valor de negócio em 2–4 linhas -->

## 2. Hipótese de benefício e métrica

Acreditamos que <entrega> resultará em <resultado> para <persona>. Saberemos quando <métrica> atingir <meta>.

<!-- Métrica alinhada à tabela de métricas do PRD (EP-nn §2). -->

## 3. Escopo e fora de escopo

Escopo:

- <item> — <EP-nn §4 / IN-nnn:L<linha>>

Fora de escopo:

- <item> — <motivo ou feature que cobre>

## 4. Capacidades e elementos da AR atendidos

<!-- Só CAP-nn e elementos STR-/BUS- da Arq. Referência aprovada (G2). Capacidade faltante vira Q-nnn proposta-mudanca contra a AR. -->

| Capacidade (CAP-nn) | Elemento AR | Tipo | Como a feature atende |
|---|---|---|---|
| <CAP-nn> | STR-CAP<n> | Capability | <descrição> |
| — | BUS-PR<n> | Process | <descrição> |

## 5. Histórias

| US | Título | Tipo | Status |
|---|---|---|---|
| US-<nn.nn.nn> | <título> | <negocio / habilitadora> | rascunho |

## 6. Dependências e sequência

- Posição no épico: <sequencia> — <justificativa>
- Depende de: <FT-nn.nn / Q-nnn / sistema externo>
- Habilita: <FT-nn.nn>

## 7. Critérios de pronto da feature

- [ ] Todas as histórias da tabela §5 aprovadas em G3 e implementadas
- [ ] Métrica da §2 instrumentada <ou "não se aplica: motivo">
- [ ] <critério específico da feature>

## 8. Questões abertas

| Q-nnn | Título | Bloqueia |
|---|---|---|
| Q-<nnn> | <título> | <US-nn.nn.nn> |

## Checklist DoD E3 (feature)

- [ ] Valor, escopo, dependências e posição na sequência preenchidos
- [ ] Referencia o `EP-nn` e ao menos uma capacidade (`CAP-nn` / `STR-`) da AR aprovada do épico
- [ ] Tabela de histórias completa, com tipo e status
- [ ] Escopo do PRD coberto pelas features do épico (ou exclusão justificada)
- [ ] Nenhuma Q-nnn `bloqueante` aberta ligada à feature ou às histórias (trava de bloqueantes); Q-nnn abertas `importante`/`menor` listadas em `questoes-abertas`
- [ ] Com `insumos=`: toda ficha `IN-FTnn.nn-nn` da pasta `insumos/` da feature citada em `origem` da feature (ou de uma história dela)
- [ ] Status `em-revisao`, pronto para G3
