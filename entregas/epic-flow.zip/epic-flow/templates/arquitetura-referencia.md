---
id: AR-<nn>
tipo: arquitetura-referencia
titulo: <titulo-curto>
dono: arquiteto
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [EP-<nn>]                  # PRD + IN-nnn usados
refs-insumos: []                   # IDs/siglas/nomes dos insumos, com IN de origem: [IN-003:RP-12]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
epico: EP-<nn>
camadas: [motivacao, estrategia, negocio]
capacidades: []                    # CAP-nn identificadas (novas) ou reutilizadas nesta AR, ex.: [CAP-01, CAP-02]
adrs: []                           # ex.: [AD-01, AD-02]
gate: G2
---

# AR-<nn> — <titulo-curto>

<!-- ArchiMate 3.2, seguindo os guidelines da arquitetura corporativa (epic-flow/referencias/README.md). IDs locais sempre prefixados (04 §6); CAP-nn só no rótulo. Diagramas em Mermaid E PlantUML. Só fontes permitidas (01 §7). -->

## 1. Introdução e escopo

TODO <!-- recorte do épico coberto, camadas tratadas, o que fica para a Arq. Solução -->

## 2. Visão de Motivação

<!-- Tipos: Stakeholder SK, Driver D, Assessment A, Goal G, Principle P, Requirement R, Constraint K. -->

| ID | Tipo | Nome | Descrição | Relaciona-se com | Origem (PRD / IN) |
|---|---|---|---|---|---|
| MOT-SK1 | Stakeholder | <nome> | <descrição> | MOT-D1 | <EP-nn §3> |
| MOT-D1 | Driver | <nome> | <descrição> | MOT-G1 | <EP-nn §1> |
| MOT-G1 | Goal | <nome> | <descrição> | MOT-R1 | <EP-nn §2> |
| MOT-R1 | Requirement | <nome> | <descrição> | STR-CAP1 | <RF-nn> |

```mermaid
flowchart LR
  SK1["MOT-SK1 «Stakeholder» <nome>"]:::mot --> D1["MOT-D1 «Driver» <nome>"]:::mot
  D1 --> G1["MOT-G1 «Goal» <nome>"]:::mot
  G1 --> R1["MOT-R1 «Requirement» <nome>"]:::mot
  classDef mot fill:#e6d9f2,stroke:#7a4fa3
  classDef str fill:#f7e3c8,stroke:#b5762b
  classDef bus fill:#fff6b3,stroke:#b5a300
```

```plantuml
@startuml
!include <archimate/Archimate>
Motivation_Stakeholder(SK1, "MOT-SK1 <nome>")
Motivation_Goal(G1, "MOT-G1 <nome>")
Rel_Influence(SK1, G1, "")
@enduml
```

## 3. Visão de Estratégia

<!-- É aqui que nascem as capacidades de negócio do fluxo (CAP-nn, 04 §5.1); mapa e PRD não as tratam.
- Capacidade de negócio = O QUE o negócio precisa ser capaz de fazer, estável e independente de processo, sistema ou organização. Nome como substantivo ou "Gestão de X", nunca verbo de etapa.
- Nível 1–2 de decomposição; tipicamente poucas por épico (ex.: 3 a 8). Sub-nível só quando necessário.
- Etapas de metodologia, passos e funções do sistema NÃO são capacidades: vão para a camada de Negócio como processos (BUS-PR) ou, mais adiante, para features e histórias.
- Mapa de capacidades na referência corporativa `arquitetura-corporativa`: alinhe e reutilize os nomes, registrando o vínculo na tabela abaixo. Capacidade nova fora do mapa corporativo fica registrada como "nova"; se for desvio de padrão, com ADR (§6).
- CAP-nn é global no epic-flow: antes de criar, consulte as capacidades das ARs já aprovadas e reutilize o CAP-nn existente. Próximo = maior CAP-nn já usado em qualquer AR (aprovada ou não) + 1; só reutilize CAP-nn de AR aprovada. Sem catálogo transversal de capacidades, a lista fica nas próprias ARs.
Exemplo (genérico):
  bom: "Gestão de Preços", "Gestão de Clientes", "Gestão de Contratos"
  ruim: "Calcular percentil P75 por cluster" (passo de metodologia → BUS-PR), "Exportar relatório em CSV" (função do sistema → feature/história), "Validar cadastro antes de aprovar" (etapa de processo → BUS-PR) -->

### 3.1 Capacidades de negócio

| CAP-nn | Nome | Descrição (o que o negócio é capaz de fazer) | Nível | Situação | Vínculo corporativo | Objetivo (MOT-) |
|---|---|---|---|---|---|---|
| CAP-<nn> | <Gestão de X> | <descrição em 1 linha> | 1 <!-- 1 / 2 --> | <nova / reutilizada de AR-nn> | <`arquitetura-corporativa:<arquivo> §<seção>` / nova fora do mapa corporativo (AD-nn se desvio) / referência ausente (Q-nnn)> | MOT-G1 |

### 3.2 Elementos de Estratégia

| ID | Tipo | Nome (com CAP-nn) | Realiza / serve | Objetivo (MOT-) |
|---|---|---|---|---|
| STR-CAP1 | Capability | <CAP-nn nome> | <STR-VS1> | MOT-G1 |
| STR-RES1 | Resource | <nome> | STR-CAP1 | MOT-G1 |
| STR-CoA1 | Course of Action | <nome> | STR-CAP1 | MOT-G1 |
| STR-VS1 | Value Stream | <nome> | — | MOT-G1 |

<!-- Diagrama Mermaid + PlantUML no mesmo padrão da Motivação, classe `str`. -->

## 4. Visão de Negócio

<!-- Tipos: Actor ACT, Role RL, Process PR, Event EV, Object OB, Service SV. Nomes como aparecem nos insumos ou no glossário. -->

| ID | Tipo | Nome | Descrição | Capacidade (STR-) |
|---|---|---|---|---|
| BUS-ACT1 | Actor | <nome> | <descrição> | — |
| BUS-PR1 | Process | <nome> | <descrição> | STR-CAP1 |
| BUS-SV1 | Service | <nome> | <descrição> | STR-CAP1 |
| BUS-OB1 | Object | <nome> | <descrição> | STR-CAP1 |

```mermaid
flowchart LR
  ACT1["BUS-ACT1 «Actor» <nome>"]:::bus --> PR1["BUS-PR1 «Process» <nome>"]:::bus
  EV1(["BUS-EV1 «Event» <nome>"]):::bus --> PR1
  PR1 --> SV1["BUS-SV1 «Service» <nome>"]:::bus
  PR1 -.-> OB1[("BUS-OB1 «Object» <nome>")]:::bus
  classDef bus fill:#fff6b3,stroke:#b5a300
```

<!-- Bloco PlantUML equivalente (Business_Actor, Business_Process, Business_Service...). -->

## 5. Mapa capacidade × processo × objetivo

| Capacidade (STR-) | Processos (BUS-) | Objetivos (MOT-) | Capacidade (CAP-nn) |
|---|---|---|---|
| STR-CAP1 | BUS-PR1 | MOT-G1 | <CAP-nn> |

## 6. Aderência à arquitetura corporativa

<!-- Referência corporativa `arquitetura-corporativa` (caminho em epic-flow/referencias/README.md). Todo desvio exige ADR. Referência ausente → Q-nnn. -->

| Princípio/padrão corporativo | Como é atendido | Desvio? → ADR |
|---|---|---|
| `<id do princípio/padrão>` (`arquitetura-corporativa:<arquivo> §<seção>`) | <elementos MOT-/STR-/BUS-/APP-/TEC- que atendem> | não \| sim → `AD-<nn>` |

## 7. ADRs relacionadas

| ADR | Título | Situação | Impacto nesta AR |
|---|---|---|---|
| AD-<nn> | <título> | <vigente / proposta> | <elementos afetados> |

## 8. Rastreabilidade

| Elemento | PRD (EP-nn §) | Insumo (IN-nnn:L) |
|---|---|---|
| MOT-G1 | <EP-nn §2> | <IN-nnn:L<linha>> |

## 9. Questões abertas

| Q-nnn | Título | Elementos afetados |
|---|---|---|
| Q-<nnn> | <título> | <MOT-/STR-/BUS-> |

## Checklist DoD E2

- [ ] Motivação: stakeholders, drivers, objetivos, princípios e requisitos ligados ao PRD
- [ ] Estratégia: capacidades e cursos de ação ligados aos objetivos
- [ ] Negócio: atores, papéis, processos, serviços e objetos de negócio
- [ ] Diagramas em Mermaid e PlantUML
- [ ] IDs locais prefixados, sem colidir com IDs globais
- [ ] Capacidades de negócio identificadas aqui como `CAP-nn` (§3.1): nome de capacidade, não etapa nem função; nível 1–2; poucas por épico
- [ ] `CAP-nn` de ARs aprovadas reutilizados; vínculo com o mapa corporativo registrado (nova fora do mapa corporativo explícita; desvio com ADR)
- [ ] Cada `CAP-nn` representada como elemento `STR-CAP<n>` (CAP-nn no rótulo) e listada em `capacidades` do frontmatter
- [ ] Todo objetivo (`MOT-`) aponta um objetivo do PRD
- [ ] Toda capacidade (`STR-`) aponta ao menos um objetivo (`MOT-`)
- [ ] Todo processo de negócio (`BUS-`) aponta ao menos uma capacidade
- [ ] Aderência à arquitetura corporativa declarada; todo desvio com ADR
- [ ] ADRs novas (`AD-nn`) criadas em `transversal/adr/` e listadas em `adrs`
- [ ] Status `em-revisao`, pronto para G2
