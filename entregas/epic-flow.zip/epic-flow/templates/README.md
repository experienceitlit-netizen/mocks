# Templates

Status: **versão mínima 0.1** (2026-10-03). Os templates serão evoluídos a partir do uso no piloto CASH. O frontmatter segue [04-convencoes](../processo/04-convencoes.md) §3 e os checklists seguem o DoD de [03-contratos-etapas](../processo/03-contratos-etapas.md).

Como usar: o agente copia o template para o caminho do artefato (ver 04 §2), troca os `<placeholders>`, preenche todas as seções e remove os comentários `<!-- -->`. Seção sem conteúdo fica com `Não se aplica: <motivo>` ou vira `Q-nnn`; não se apaga seção. O conteúdo vem só das fontes permitidas ([01-fluxo §7](../processo/01-fluxo.md#7-isolamento-de-fontes)), incluindo as referências corporativas de [`../referencias/README.md`](../referencias/README.md); os exemplos entre `<>` são placeholders, não nomes do projeto.

## Templates

| Arquivo | Artefato | Etapa | Dono |
|---|---|---|---|
| `insumo.md` | Ficha de insumo `IN-nnn` (E0, `/ef-insumos`) do épico `IN-EPnn-nn` (E1, `/ef-epico EP-nn insumos=<pasta>`), da feature `IN-FTnn.nn-nn` ou da história `IN-USnn.nn.nn-nn` (E3, `/ef-features EP-nn feature=\|historia=... insumos=<pasta>`) | E0, E1, E3 | `pm` |
| `mapa-epicos.md` | Mapa de épicos `MAPA` (lista de `EP-nn` com descrição, dores `DOR-nn` e insumos; gate G0) | E0 | `pm` |
| `prd-epico.md` | PRD de um épico `EP-nn` do mapa | E1 | `pm` |
| `arquitetura-referencia.md` | Arq. de Referência `AR-nn` (Motivação, Estratégia, Negócio) | E2 | `arquiteto` |
| `feature.md` | Feature `FT-nn.nn` | E3 | `po` |
| `historia.md` | História `US-nn.nn.nn` | E3 | `po` |
| `arquitetura-solucao.md` | Arq. de Solução `AS-nn.nn` (Aplicação, Tecnologia, Implantação/Migração) | E4 | `arquiteto` |
| `spec.md` | Spec `SP-nn.nn.nn` | E5 | `tech-lead` |
| `task.md` | Task `TK-nn.nn.nn-nn` | E5 | `tech-lead` |
| `adr.md` | Decisão de arquitetura `AD-nn` (série do fluxo, a partir de AD-01) | E2, E4 | `arquiteto` |
| `questao.md` | Entrada `Q-nnn` de `transversal/decisoes-e-questoes.md` | todas | qualquer agente |

Cada template deve trazer o frontmatter completo do tipo, as seções obrigatórias e o checklist de DoD da etapa.

## Evolução

Sugestões de melhoria nos templates entram como `Q-nnn` do tipo `proposta-mudanca` com `artefato afetado: templates/<arquivo>`. Mudança de template não reabre artefatos já aprovados.
