---
id: IN-<nnn>                       # IN-nnn (raiz, /ef-insumos), IN-EPnn-nn (épico, /ef-epico EP-nn insumos=<pasta>), IN-FTnn.nn-nn ou IN-USnn.nn.nn-nn (feature/história, /ef-features EP-nn feature=|historia=... insumos=<pasta>)
tipo: insumo
titulo: <titulo-curto>
dono: pm
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: []
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
tipo-insumo: <tipo>                # transcricao | ata | nota | apresentacao | fluxo-pipeline | processo-as-is
fonte: <caminho-relativo-do-original>    # deve estar dentro do argumento de /ef-insumos ou da pasta de insumos= (/ef-epico, /ef-features)
data-insumo: ""                    # data da reunião/documento; vazio se desconhecida
autor-reuniao: ""                  # autor ou reunião de origem; vazio se desconhecido
produto: []                        # produtos/linhas citados no insumo, ou transversal
temas: []                          # assuntos citados no insumo, texto livre e sem ID (ex.: ["<tema>"])
maturidade: <maturidade>           # completo | parcial | truncado
---

# IN-<nnn> — <titulo-curto>

<!-- Ficha aponta para o original em `fonte`; nunca copiar o conteúdo integral. Nunca ler fotos/. Só o arquivo de `fonte` é lido: nada de outros arquivos, memória ou conhecimento prévio (01 §7). -->

## Resumo

<!-- 3–5 linhas (máx. 10, 04 §7): do que trata, para quem, por que importa. -->

TODO

## Conteúdo relevante

<!-- Agrupar por tema; toda afirmação com referência `<arquivo>:L<linha>`. Dedução do agente marcada (inferido). -->

### <tema-1>

- <conceito ou trecho resumido> — `<arquivo>:L<linha>`

### <tema-2>

- <conceito ou trecho resumido> — `<arquivo>:L<linha>`

## Atores citados

| Ator / papel | Como aparece no texto | Referência |
|---|---|---|
| <ator> | <descrição curta> | `<arquivo>:L<linha>` |

## Regras e números citados

<!-- Valores exatamente como no original; sem valor = registrar Q-nnn. ID ou sigla que o próprio insumo dá à regra vai na coluna "ID no insumo" e em refs-insumos. -->

| Regra / número | Valor | ID no insumo | Referência |
|---|---|---|---|
| <regra> | <valor ou [A DEFINIR]> | <id literal ou ""> | `<arquivo>:L<linha>` |

## Pendências do texto

<!-- Todo "[...]", "cortado", "truncado", "(Dúvida!)", "?" de negócio ou lista incompleta vira Q-nnn (questao.md). -->

| Trecho | Tipo de pendência | Referência | Q-nnn |
|---|---|---|---|
| <trecho> | <truncado / dúvida / sem valor / termo novo> | `<arquivo>:L<linha>` | Q-<nnn> |

## Uso previsto

<!-- Hipótese, não decisão, tirada só deste insumo. Temas só viram EP-nn no mapa de épicos (mapa-epicos.md, G0); na ficha do épico (IN-EPnn-nn), aponte seções ou temas do PRD do EP-nn; na ficha da feature (IN-FTnn.nn-nn) ou da história (IN-USnn.nn.nn-nn), aponte seções, histórias ou critérios de aceite do alvo. Capacidades de negócio não são classificadas aqui: nascem na Arq. Referência (E2). -->

| Tema ou EP-nn | Como o insumo contribui |
|---|---|
| <tema ou EP-nn> | <contribuição> |

## Checklist DoD E0 (ficha)

- [ ] `IN-nnn` e cabeçalho completo: id, tipo-insumo, fonte, data-insumo, autor-reuniao, produto, temas, maturidade
- [ ] `fonte` aponta o original (caminho ou referência), sem cópia
- [ ] Trechos truncados e "(Dúvida!)" registrados como Q-nnn e listados em `questoes-abertas`
- [ ] Termos novos propostos ao glossário via Q-nnn
- [ ] Temas de uso listados em "Uso previsto" (hipótese)
- [ ] Toda Q-nnn aberta aponta este `IN-nnn` (`fonte`) e, quando houver, `refs-insumos`
- [ ] Linha do insumo acrescentada a `insumos/README.md` (ou ao índice `insumos/README.md` da pasta do épico, da feature ou da história, nas fichas `IN-EPnn-nn`, `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn`)
