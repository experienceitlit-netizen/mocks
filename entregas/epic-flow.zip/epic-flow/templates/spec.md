---
id: SP-<nn.nn.nn>
tipo: spec
titulo: <nome curto da spec>
dono: tech-lead
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [US-<nn.nn.nn>, AS-<nn.nn>, FT-<nn.nn>]
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
historia: US-<nn.nn.nn>
componentes: []
complexidade: ""
gate: G5
---

# SP-<nn.nn.nn> — <título>

<!-- Agente: conteúdo mínimo de 03 (E5); seção não aplicável → "Não se aplica: <motivo>". Complexidade P|M|G|GG (04 §3.4). Tecnologias conforme a stack (stack-tech.md) e os padrões de desenvolvimento, via epic-flow/referencias/README.md, e os ADRs vigentes; referência ausente → Q-nnn. -->

## 1. Objetivo e história

- História: [US-<nn.nn.nn>](../historias/US-<nn.nn.nn>-<slug>.md)
- Objetivo técnico: <1–3 linhas>
- RF/RNF/RP: <IDs>

## 2. Componentes envolvidos

| Componente (catálogo) | Papel nesta história | Situação na AS |
|---|---|---|
| `<componente>` | <papel> | novo \| alterado \| reutilizado |

## 3. Processo e fluxo

### 3.1 Fluxo de execução

1. <passo>
2. <passo>

### 3.2 Provisionamento de infraestrutura

| Recurso | Ambiente(s) | IaC / ferramenta | Segredos (nome, sem valor) |
|---|---|---|---|
| <recurso da `<plataforma>`> | <ambientes> | <ferramenta conforme a stack (stack-tech.md)> | `<NOME_SEGREDO>` |

## 4. Contratos de API

| Método | Endpoint | Exposição | Versão |
|---|---|---|---|
| `<MÉTODO>` | `/<api>/v1/<recurso>` | <gateway ou acesso direto> | v1 |

Request:

```json
{ "<campo>": "TODO" }
```

Response `200`:

```json
{ "<campo>": "TODO" }
```

| Status | Código de negócio | Quando |
|---|---|---|
| `<status>` | `<CODIGO_ESTAVEL>` | <condição> |

<!-- Formato de erro, idempotência e versionamento conforme a stack (stack-tech.md), os padrões de desenvolvimento e os ADRs vigentes. -->

## 5. Modelo de dados

| Tabela | Camada / schema | Campos-chave | Operação |
|---|---|---|---|
| `<schema.tabela>` | <camada> | `<pk>` | <C/R/U/D> |

```sql
-- <script de migração conforme a stack (stack-tech.md)>
CREATE TABLE <schema>.<tabela> ( TODO );
```

- Migração: <ferramenta; compatibilidade com dados existentes>

## 6. Design de código

<!-- Estrutura de módulos/pacotes conforme a stack (stack-tech.md), os padrões de desenvolvimento e os ADRs vigentes. -->

| Pacote / módulo | Classe ou função | Assinatura | Responsabilidade |
|---|---|---|---|
| `<pacote>` | `<Classe>` | `<retorno> <metodo>(<params>)` | <responsabilidade> |

## 7. Processamento de dados / jobs

<!-- Quando aplicável: clusters, notebooks ou scripts, schedule. Senão, "Não se aplica: <motivo>". -->

| Item | Valor |
|---|---|
| Job / tarefa | `<job>` / `<tarefa>` |
| Cluster / recurso de execução | <tipo, tamanho, política> |
| Agendamento | `<cron / orquestrador / evento>` |
| Notebook / script / entrypoint | `<caminho>` |
| Parâmetros | <parâmetros> |
| Dependências | <tarefas upstream> |

## 8. Configuração e parametrização

| Parâmetro / regra | Origem | Default | Observação |
|---|---|---|---|
| `RP-<nn>` | `transversal/catalogo-regras.md` | <valor ou `[A DEFINIR]` + Q-nnn> | |
| `<VAR_AMBIENTE>` | `.env` / secret | — | sem valor no repositório |

## 9. Testes e critérios técnicos

| Critério de aceite (US) | Tipo de teste | Caso / arquivo |
|---|---|---|
| CA-01 | unitário \| integração \| contrato \| dados \| golden test | `<teste>` |

- Unitários: <escopo; cobertura mínima>
- Integração: <ferramenta conforme a stack (stack-tech.md)>
- Golden test: <arquivo de casos entrada/saída e origem>
- Critérios técnicos adicionais: <latência, idempotência etc.>

## 10. Observabilidade

- Logs: <eventos; campos de correlação, versões; dados mascarados>
- Métricas: <nome, tipo>
- Traces: <spans>
- Alertas: <condição → destino>

## 11. Segurança

- Autenticação: <mecanismo>
- Autorização: <perfis `<contexto>.<papel>`>
- Dados sensíveis: <campos e tratamento>
- Segredos: <onde ficam; nunca no código>

## 12. Padrões de desenvolvimento aplicados

<!-- Referência corporativa `padroes-desenvolvimento` + stack (`stack-tech.md`), caminhos em epic-flow/referencias/README.md. Exceção a padrão → Q-nnn ou ADR. Referência ausente → Q-nnn. -->

- Stack aplicada: <linguagem, frameworks, plataformas> (`stack:stack-tech.md §<seção>`)

| Padrão | Onde se aplica | Exceção (→ Q-nnn ou ADR) |
|---|---|---|
| `<id do padrão>` (`padroes-desenvolvimento:<arquivo> §<seção>`) | <seções desta spec / tasks> | não \| `Q-<nnn>` \| `AD-<nn>` |

## 13. Referências e questões

- Insumos: `IN-<nnn>:L<linha>`
- Referências corporativas: `<categoria>:<arquivo> §<seção>`
- ADRs: `AD-<nn>`
- Questões abertas: `Q-<nnn>` — <resumo>

## 14. Checklist DoD E5 (spec)

- [ ] Todas as seções do conteúdo mínimo preenchidas ou com "Não se aplica: <motivo>"
- [ ] Stack (stack-tech.md), ADRs vigentes e padrões de desenvolvimento seguidos; seção "Padrões de desenvolvimento aplicados" preenchida, exceções com Q-nnn ou ADR
- [ ] Todo critério de aceite da história mapeado para ao menos um teste
- [ ] Complexidade P/M/G/GG definida
- [ ] Referencia a `US-<nn.nn.nn>` e os componentes do catálogo usados
- [ ] Toda regra parametrizável citada pelo RP de origem
- [ ] Nenhuma Q-nnn bloqueante aberta contra a história
- [ ] Tasks geradas (`TK-<nn.nn.nn>-nn`) e referenciando esta spec
- [ ] Status `em-revisao`, pronto para G5
