---
id: AD-<nn>
tipo: adr
titulo: <decisão em uma frase>
dono: arquiteto
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: []
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
decisao: proposta
impacta: []
alternativas: []
gate: ""
---

# AD-<nn> — <título>

<!-- Agente: série AD-nn do fluxo (começa em AD-01; próximo = maior existente + 1); gate G2 (Arq. Referência) ou G4 (Arq. Solução); `decisao` só muda para aceita/rejeitada no gate. -->

## 1. Contexto

<problema, forças e restrições; fontes citadas (IN-nnn:L<linha>, ID de artefato do fluxo, Q-nnn)>

## 2. Decisão

<o que se decide, em termos verificáveis>

## 3. Alternativas consideradas

| Opção | Prós | Contras |
|---|---|---|
| A — <nome> (escolhida) | | |
| B — <nome> | | |

## 4. Consequências

Positivas:

- <consequência>

Negativas:

- <consequência>

## 5. Impacto em ADRs e componentes existentes

| Item | Tipo | Impacto |
|---|---|---|
| `AD-<nn>` | ADR | complementa \| substitui \| restringe |
| `<componente>` | componente | <mudança> |

## 6. Requisitos atendidos

- RF: `RF-<nn>`
- RNF: `RNF-<nn>`

## 7. Status e histórico

| Data | Versão | Decisão | Por | Nota |
|---|---|---|---|---|
| <AAAA-MM-DD> | 0.1 | proposta | arquiteto | criação |
