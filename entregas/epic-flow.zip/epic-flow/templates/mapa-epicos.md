---
id: MAPA
tipo: mapa-epicos
titulo: Mapa de épicos
dono: pm
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: []                         # IN-nnn usados
refs-insumos: []                   # IDs/siglas/nomes dos insumos, com IN de origem: [IN-003:RP-12]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
insumos: []                        # ex.: [IN-001, IN-002]
epicos: []                         # EP-nn reservados neste mapa, inclusive descartados
gate: G0
---

# MAPA — Mapa de épicos

<!-- Um único mapa por epic-flow, derivado só das fichas IN-nnn (01 §7). Agrupar por valor de negócio e dor, não por componente técnico. Cada linha reserva um EP-nn; épico removido fica com situação "descartado" e o ID não é reutilizado. Sem prioridade nem sequência nesta versão: podem entrar em versão futura do template.
Capacidades de negócio (CAP-nn) não são tratadas no mapa nem no PRD: nascem na Arq. Referência (E2, arquiteto; 04 §5.1). -->

<!-- Concisão (o mapa deve caber numa leitura de poucos minutos):
- épico é agrupamento de valor de negócio, não lista de etapas, componentes ou funcionalidades;
- descrição com no máximo 2 linhas, sem metodologia, fórmulas, passos ou regras (isso vai para o PRD);
- dores agrupadas e deduplicadas, 1 linha cada, apontando a dor e não a solução;
- se surgir muita coisa, prefira menos épicos mais amplos e registre as fronteiras em "Sobreposições e fronteiras";
- tipicamente 3 a 8 épicos (orientação, não limite rígido). -->

## Visão geral

TODO <!-- 2–4 linhas: o que os insumos cobrem e como foram recortados em épicos -->

## Épicos

| ID | Nome | Descrição (1–2 linhas) | Dores que ataca | Insumos de origem | Situação |
|---|---|---|---|---|---|
| EP-<nn> | <nome> | <descrição> | DOR-<nn>, DOR-<nn> | IN-<nnn>, IN-<nnn> | proposto <!-- proposto / descartado --> |

## Dores identificadas

<!-- DOR-nn é local ao mapa (não confundir com Drivers ArchiMate MOT-D<n>; ver 04 §5.4). Dores agrupadas e deduplicadas, 1 linha cada, descrevendo o problema sentido, não a solução. -->

| DOR-nn | Dor | Quem sente | Insumos |
|---|---|---|---|
| DOR-<nn> | <dor> | <persona / área> | IN-<nnn> |

## Sobreposições e fronteiras

- EP-<nn> x EP-<nn>: <onde encostam> — <como foi cortado>

## Fora do mapa

- <assunto dos insumos> — <por que não virou épico> (IN-<nnn>)

## Questões abertas

| Q-nnn | Prioridade | Título | Bloqueia |
|---|---|---|---|
| Q-<nnn> | <bloqueante / importante / menor> | <título> | <EP-nn ou "—"> |

## Checklist DoD G0

- [ ] Todo `IN-nnn` do recorte aparece em ao menos um épico ou em "Fora do mapa"
- [ ] Todo épico `proposto` cita ao menos uma `DOR-nn` e um `IN-nnn`
- [ ] Toda `DOR-nn` é atacada por ao menos um épico ou está justificada em "Fora do mapa"
- [ ] Épicos agrupados por valor de negócio, não por componente técnico, etapa de processo ou funcionalidade
- [ ] Descrições com até 2 linhas, sem metodologia, fórmulas, passos ou regras; dores deduplicadas, 1 linha cada
- [ ] Mapa enxuto (tipicamente 3 a 8 épicos); excesso de itens resolvido com épicos mais amplos e fronteiras registradas
- [ ] Sem capacidades de negócio (`CAP-nn`): elas nascem na Arq. Referência (E2)
- [ ] Sobreposições entre épicos explicitadas com o corte adotado
- [ ] `insumos` e `epicos` do frontmatter batem com as tabelas; IDs descartados mantidos
- [ ] Dúvidas registradas como Q-nnn, com `prioridade` e `opcoes`; inferências marcadas "(inferido)"
- [ ] Rodada de esclarecimento oferecida para as `importante`; nenhuma Q-nnn `bloqueante` aberta (trava de bloqueantes: respondida, descartada ou reclassificada com justificativa)
- [ ] Status `em-revisao`, pronto para G0
