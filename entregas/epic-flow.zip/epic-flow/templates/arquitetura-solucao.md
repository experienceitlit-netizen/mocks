---
id: AS-<nn.nn>
tipo: arquitetura-solucao
titulo: <nome curto da solução da feature>
dono: arquiteto
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [FT-<nn.nn>, AR-<nn>, EP-<nn>]
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
feature: FT-<nn.nn>
epico: EP-<nn>
camadas: [aplicacao, tecnologia, implantacao-migracao]
componentes-novos: []
componentes-alterados: []
componentes-reutilizados: []
adrs: []
gate: G4
---

# AS-<nn.nn> — <título>

<!-- Agente: descreva só o delta da feature sobre a base comum; IDs locais com prefixo APP-/TEC-/IMP- (04 §6). Plataformas só da referência corporativa `stack` (stack-tech.md, via epic-flow/referencias/README.md). -->

## 1. Escopo

- Feature: [FT-<nn.nn>](feature.md) · Histórias: `US-<nn.nn.nn>`, `US-<nn.nn.nn>` · Fora de escopo: <item>

## 2. Delta sobre a base comum

| Componente (catálogo) | Situação | Responsabilidade na feature | Ref. catálogo |
|---|---|---|---|
| `<componente>` | novo \| alterado \| reutilizado | <responsabilidade> | `transversal/catalogo-componentes.md#<ancora>` |

## 3. Visão de Aplicação

| ID | Tipo ArchiMate | Nome canônico | Atende (US / BUS-) |
|---|---|---|---|
| `APP-AC1` | Application Component | `<componente>` | `US-<nn.nn.nn>` / `BUS-<id>` |
| `APP-AS1` / `APP-AI1` / `APP-DO1` | Service / Interface / Data Object | <nome> | |

```mermaid
flowchart LR
  AI1[["APP-AI1 «Interface» TODO"]] --> AC1["APP-AC1 «Component» TODO"] --> DO1[("APP-DO1 «Data Object» TODO")]
```

```plantuml
@startuml
!include <archimate/Archimate>
Application_Component(APP_AC1, "TODO")
@enduml
```

## 4. Visão de Cooperação e fluxo

```mermaid
sequenceDiagram
  Canal->>Gateway: <requisição>
  Gateway->>Componente: <chamada>
  Componente-->>Canal: <resposta>
```

## 5. Visão de Tecnologia

| ID | Tipo ArchiMate | Plataforma | Uso na feature |
|---|---|---|---|
| `TEC-N1` | Node | `<plataforma>` (conforme a stack, stack-tech.md) | <uso> |
| `TEC-T1` | Technology Service | `<serviço de infraestrutura>` | <uso> |

## 6. Visão de Implantação e Migração

| ID | Tipo ArchiMate | Descrição | Marco |
|---|---|---|---|
| `IMP-W1` / `IMP-PL1` / `IMP-GAP1` | Work Package / Plateau / Gap | <descrição> | `MC-<n>` |

- Ambientes dev → hml → prd: <particularidades>
- Convivência com os sistemas atuais (AS-IS): <como coexistem; critério de desligamento>

## 7. Integrações e contratos

| Origem | Destino | Protocolo | Contrato |
|---|---|---|---|
| `<origem>` | `<destino>` | REST \| evento \| JDBC \| arquivo | `<recurso/tópico/tabela>` |

## 8. Dados

- `<schema.tabela>` — dono `<componente>` — <C/R/U/D>

## 9. Atendimento a RNF

- `RNF-<nn>` — <mecanismo que atende>

## 10. Aderência à arquitetura corporativa

<!-- Referência corporativa `arquitetura-corporativa` (caminho em epic-flow/referencias/README.md). Todo desvio exige ADR. Referência ausente → Q-nnn. -->

| Princípio/padrão corporativo | Como é atendido | Desvio? → ADR |
|---|---|---|
| `<id do princípio/padrão>` (`arquitetura-corporativa:<arquivo> §<seção>`) | <elementos MOT-/STR-/BUS-/APP-/TEC- que atendem> | não \| sim → `AD-<nn>` |

## 11. ADRs, riscos e questões

- ADRs novas: `AD-<nn>` — <título> · impactadas: `AD-<nn>` — <impacto>
- Riscos técnicos: <risco> → <mitigação>
- Questões abertas: `Q-<nnn>` — <resumo> (bloqueia: <IDs>)

## 12. Checklist DoD E4

- [ ] Todo componente marcado `novo`, `alterado` ou `reutilizado`, com link ao catálogo
- [ ] Aplicação: componentes, serviços, interfaces e objetos de dados
- [ ] Tecnologia aderente à stack (stack-tech.md, referência corporativa `stack`)
- [ ] Aderência à arquitetura corporativa declarada; todo desvio com ADR
- [ ] Implantação/Migração: pacotes de trabalho, plataformas transitórias e convivência com os sistemas atuais (AS-IS)
- [ ] Decisões novas registradas como ADR (`AD-nn`), citadas aqui e na Q-nnn de origem
- [ ] Diagramas em Mermaid e PlantUML
- [ ] Toda história atendida por ao menos um `APP-`; todo `APP-` aponta um `BUS-`
- [ ] Todo componente existe (ou é proposto) em `transversal/catalogo-componentes.md`
- [ ] Status `em-revisao`, pronto para G4
