---
id: US-<nn.nn.nn>
tipo: historia
titulo: <titulo-curto>
dono: po
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [FT-<nn.nn>, EP-<nn>, AR-<nn>]   # + fichas IN-* usadas (inclusive IN-FTnn.nn-nn da feature e IN-USnn.nn.nn-nn de historias/insumos/US-nn.nn.nn/)
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
feature: FT-<nn.nn>
capacidades: []                    # CAP-nn da AR aprovada do épico (G2), ex.: [CAP-02]
rf: []
rnf: []
regras-rp: []
tipo-historia: <tipo>              # negocio | habilitadora
depende-de: []
gate: G3
---

# US-<nn.nn.nn> — <titulo-curto>

## 1. História

Como <persona>, quero <ação>, para <valor>.

<!-- Habilitadora: persona pode ser o time/sistema; o valor cita o RNF atendido. -->

## 2. Contexto e notas

TODO <!-- por que agora, elementos BUS-/STR- da AR envolvidos, referências IN-nnn:L<linha> -->

## 3. Critérios de aceite

<!-- Testáveis; critério derivado de regra cita RP ou a referência do insumo (IN-nnn:L<linha>). Ao menos um caminho alternativo/erro. -->

**CA-01 — <caminho principal>** (<RP-nn / IN-nnn:L<linha>>)

```gherkin
Dado <contexto>
Quando <ação>
Então <resultado observável>
```

**CA-02 — <caminho alternativo ou erro>** (<RP-nn / IN-nnn:L<linha>>)

```gherkin
Dado <contexto>
Quando <ação inválida ou condição de exceção>
Então <resultado esperado / mensagem>
```

## 4. Regras de negócio

| RP | Descrição | Valores / parâmetros |
|---|---|---|
| RP-<nn> | <descrição> | <valor ou [A DEFINIR] (Q-nnn)> |

## 5. Requisitos não funcionais aplicáveis

| RNF | Exigência nesta história |
|---|---|
| RNF-<nn> | <exigência mensurável> |

## 6. Dados de exemplo

| <campo> | <campo> | Resultado esperado |
|---|---|---|
| <valor> | <valor> | <valor> |

## 7. Fora de escopo

- <item> — <história/feature que cobre>

## 8. Questões abertas

| Q-nnn | Título | Bloqueia esta história? |
|---|---|---|
| Q-<nnn> | <título> | <sim / não> |

## Checklist INVEST

- [ ] Independente (dependências explícitas em `depende-de`)
- [ ] Negociável (descreve o quê, não o como)
- [ ] Valiosa (valor claro para a persona ou RNF atendido)
- [ ] Estimável (sem lacuna que impeça a spec)
- [ ] Pequena (cabe em uma spec)
- [ ] Testável (critérios de aceite verificáveis)

## Checklist DoD E3 (história)

- [ ] `tipo-historia` preenchido e texto em como/quero/para
- [ ] Todo critério de aceite em Dado/Quando/Então e testável, com ao menos um caminho alternativo/erro
- [ ] Regras RP aplicáveis vinculadas pelo ID do catálogo de regras; critério derivado de regra cita RP ou `IN-nnn:L<linha>`
- [ ] Referencia sua `FT-nn.nn` e ao menos um RF, RNF, RP ou capacidade `CAP-nn` da AR (habilitadora: o RNF atendido)
- [ ] Nenhuma Q-nnn `bloqueante` aberta ligada à história (trava de bloqueantes); Q-nnn abertas `importante`/`menor` listadas em `questoes-abertas`
- [ ] Com `insumos=`: toda ficha `IN-USnn.nn.nn-nn` de `historias/insumos/US-nn.nn.nn/` citada em `origem`
- [ ] Status `em-revisao`, pronto para G3
