---
id: TK-<nn.nn.nn>-<nn>
tipo: task
titulo: <verbo + objeto, curto>
dono: tech-lead
status: rascunho
versao: 0.1
data: <AAAA-MM-DD>
origem: [SP-<nn.nn.nn>, US-<nn.nn.nn>]
refs-insumos: []                   # [IN-nnn:<id-ou-sigla>]
questoes-abertas: []
aprovado-por: ""
aprovado-em: ""
substituido-por: ""
spec: SP-<nn.nn.nn>
estimativa: ""
depende-de: []
repositorio: ""
pr: ""
execucao: pendente
g6-aprovado-por: ""
g6-aprovado-em: ""
gate: G5
---

# TK-<nn.nn.nn>-<nn> — <título>

<!-- Agente: estimativa 1|2|3|5|8 (acima de 8, quebrar); uma task = um PR; gate G5 aprova a task (status); G6 aprova o código (campos g6-*, só humano). -->

## 1. Objetivo

<1–2 linhas>

## 2. O que fazer

1. <passo>
2. <passo>

## 3. Arquivos e componentes afetados

- `<repositorio>/<caminho>` — <criar \| alterar>

## 4. Critérios de pronto

- [ ] Código implementa a task conforme [SP-<nn.nn.nn>](../specs/SP-<nn.nn.nn>.md) §<n>
- [ ] Testes escritos e passando (incluindo os ligados aos CA da história)
- [ ] Observabilidade e segurança da spec aplicadas
- [ ] Segue os padrões de desenvolvimento listados na spec
- [ ] PR aberto citando `TK-<nn.nn.nn>-<nn>` e `SP-<nn.nn.nn>`, revisado pelo Tech Lead (G6)
- [ ] Documentação do repositório atualizada, se aplicável

## 5. Como validar

```bash
TODO  # comando de build/teste do repositório (conforme a stack e os padrões de desenvolvimento)
```

## 6. Dependências

- Tasks: `TK-<...>`
- Externas: <ambiente, acesso, dado>

## 7. Notas para o desenvolvedor

- <armadilhas, decisões já tomadas, Q-nnn relacionadas>

## 8. Registro de execução

<!-- Preenchido em E6 pelo desenvolvedor. -->

| Campo | Valor |
|---|---|
| PR | |
| Data | |
| Desvios da spec (Q-nnn) | |
