#!/usr/bin/env python3
"""Consumo de tokens do epic-flow por etapa, agente e execução.

Lê as transcrições locais do Claude Code em ~/.claude/projects/<projeto>/:
  <sessao>.jsonl                       -> orquestrador (sessão principal)
  <sessao>/subagents/agent-*.jsonl     -> cada execução de subagente
  <sessao>/subagents/agent-*.meta.json -> agentType e description

A etapa vem do início da description da execução ("E1 EP-01 ..."), que os
comandos /ef-* preenchem. Sem esse prefixo, usa o padrão do tipo de agente.

Uso:
  python3 epic-flow/metricas/consumo.py                 # todas as sessões
  python3 epic-flow/metricas/consumo.py --sessao <id>   # uma sessão
  python3 epic-flow/metricas/consumo.py --desde 2026-10-03 --detalhe
  python3 epic-flow/metricas/consumo.py --csv epic-flow/metricas/consumo.csv
  python3 epic-flow/metricas/consumo.py --chamadas "E1 EP-01"  # cada chamada à API dessa execução

Custo em US$: estimativa a preço de API (tabela PRECOS abaixo, US$ por milhão de
tokens, preços públicos de 2026-09). Em plano de assinatura (Pro/Max/Team) não há
cobrança por token; o valor serve como equivalente de API para comparar etapas.
"""
import argparse
import csv
import glob
import json
import os
import re
from collections import defaultdict

CAMPOS = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens", "output_tokens")
ETAPA_PADRAO = {
    "pm": "E0/E1",
    "arquiteto": "E2/E4",
    "po": "E3",
    "tech-lead": "E5",
    "desenvolvedor": "E6",
}
# US$ por 1M tokens: entrada, saída, leitura de cache. Escrita de cache = entrada x1,25 (TTL 5 min) ou x2 (TTL 1 h).
# Atualize quando os preços mudarem; modelo ausente aparece como "sem preço".
PRECOS = {
    "claude-fable-5-1": (10.00, 50.00, 0.25),
    "claude-fable-5": (10.00, 50.00, 0.25),
    "claude-opus-5-5": (4.00, 20.00, 0.20),
    "claude-opus-5": (5.00, 25.00, 0.50),
    "claude-opus-4-8": (5.00, 25.00, 0.50),
    "claude-opus-4-7": (5.00, 25.00, 0.50),
    "claude-opus-4-6": (5.00, 25.00, 0.50),
    "claude-sonnet-5-5": (2.00, 10.00, 0.20),
    "claude-sonnet-5": (2.00, 10.00, 0.20),
    "claude-sonnet-4-6": (3.00, 15.00, 0.30),
    "claude-haiku-4-5": (1.00, 5.00, 0.10),
}
ALIAS = {"opus": "claude-opus-5-5", "sonnet": "claude-sonnet-5-5", "haiku": "claude-haiku-4-5", "fable": "claude-fable-5-1"}
SEM_PRECO = set()


def custo_usd(modelo, uso):
    """Custo estimado de uma chamada; None se o modelo não está na tabela."""
    m = re.sub(r"\[.*\]$", "", modelo or "")
    m = ALIAS.get(m, m)
    if m == "<synthetic>":
        return 0.0
    if m not in PRECOS:
        SEM_PRECO.add(modelo)
        return None
    p_in, p_out, p_read = PRECOS[m]
    cc = uso.get("cache_creation") or {}
    w1h = cc.get("ephemeral_1h_input_tokens") or 0
    w5m = cc.get("ephemeral_5m_input_tokens")
    if w5m is None:
        w5m = max((uso.get("cache_creation_input_tokens") or 0) - w1h, 0)
    return ((uso.get("input_tokens") or 0) * p_in + w5m * p_in * 1.25 + w1h * p_in * 2
            + (uso.get("cache_read_input_tokens") or 0) * p_read + (uso.get("output_tokens") or 0) * p_out) / 1e6


RE_ETAPA = re.compile(r"^\s*(E[0-6])\b\s*([A-Z]{2,3}-(?:EP|FT|US)?[\d.\-]+|MAPA)?")


def pasta_projeto(cwd):
    return os.path.expanduser("~/.claude/projects/" + re.sub(r"[^A-Za-z0-9]", "-", cwd))


def ler_chamadas(caminho):
    """Uma entrada por chamada à API; registros repetidos do mesmo id (streaming) ficam com o maior valor."""
    por_msg = {}
    inicio = None
    with open(caminho, encoding="utf-8") as f:
        for linha in f:
            try:
                r = json.loads(linha)
            except json.JSONDecodeError:
                continue
            if inicio is None and r.get("timestamp"):
                inicio = r["timestamp"]
            msg = r.get("message")
            if r.get("type") != "assistant" or not isinstance(msg, dict) or not msg.get("usage"):
                continue
            uso = msg["usage"]
            chave = msg.get("id") or r.get("uuid")
            atual = por_msg.setdefault(chave, {"modelo": msg.get("model") or "", "hora": r.get("timestamp", ""),
                                               "cache_creation": {}, **dict.fromkeys(CAMPOS, 0)})
            for c in CAMPOS:
                atual[c] = max(atual[c], uso.get(c) or 0)
            for k, v in (uso.get("cache_creation") or {}).items():
                atual["cache_creation"][k] = max(atual["cache_creation"].get(k, 0), v or 0)
    chamadas = list(por_msg.values())
    for ch in chamadas:
        ch["usd"] = custo_usd(ch["modelo"], ch)
    return chamadas, inicio or ""


def somar_uso(caminho):
    chamadas, inicio = ler_chamadas(caminho)
    total = dict.fromkeys(CAMPOS, 0)
    total["usd"] = 0.0
    for ch in chamadas:
        for c in CAMPOS:
            total[c] += ch[c]
        total["usd"] += ch["usd"] or 0.0
    total["chamadas"] = len(chamadas)
    modelos = ",".join(sorted({ch["modelo"] for ch in chamadas if ch["modelo"]}))
    return total, inicio, modelos


def coletar(base, sessao=None, desde=None):
    execucoes = []
    for jsonl in sorted(glob.glob(os.path.join(base, "*.jsonl"))):
        sid = os.path.basename(jsonl)[:-6]
        if sessao and sid != sessao:
            continue
        uso, inicio, modelo = somar_uso(jsonl)
        execucoes.append(dict(sessao=sid, etapa="orquestrador", id="", agente="orquestrador",
                              descricao="sessão principal", inicio=inicio, modelo=modelo,
                              arquivo=jsonl, **uso))
        for sub in sorted(glob.glob(os.path.join(base, sid, "subagents", "agent-*.jsonl"))):
            meta = {}
            meta_path = sub[:-6] + ".meta.json"
            if os.path.exists(meta_path):
                with open(meta_path, encoding="utf-8") as f:
                    meta = json.load(f)
            agente = meta.get("agentType") or "?"
            descricao = meta.get("description") or ""
            m = RE_ETAPA.match(descricao)
            etapa = m.group(1) if m else ETAPA_PADRAO.get(agente, "outros")
            uso, inicio, modelo = somar_uso(sub)
            execucoes.append(dict(sessao=sid, etapa=etapa, id=(m.group(2) or "") if m else "",
                                  agente=agente, descricao=descricao, inicio=inicio, modelo=modelo,
                                  arquivo=sub, **uso))
    if desde:
        execucoes = [e for e in execucoes if e["inicio"][:10] >= desde]
    return execucoes


def fmt(n):
    return f"{n:,}".replace(",", ".")


def entrada(e):
    return e["input_tokens"] + e["cache_creation_input_tokens"] + e["cache_read_input_tokens"]


def tabela(titulo, linhas, chave):
    grupos = defaultdict(lambda: defaultdict(int))
    for e in linhas:
        g = grupos[chave(e)]
        g["execucoes"] += 1
        for c in CAMPOS + ("chamadas", "usd"):
            g[c] += e[c]
    print(f"\n### {titulo}\n")
    print("| Grupo | Execuções | Chamadas | Entrada nova | Escrita cache | Leitura cache | Saída | Total tokens | US$ (est.) |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    soma = defaultdict(int)
    for k in sorted(grupos):
        g = grupos[k]
        tot = sum(g[c] for c in CAMPOS)
        for c in CAMPOS + ("execucoes", "chamadas", "usd"):
            soma[c] += g[c]
        print(f"| {k} | {g['execucoes']} | {g['chamadas']} | {fmt(g['input_tokens'])} | "
              f"{fmt(g['cache_creation_input_tokens'])} | {fmt(g['cache_read_input_tokens'])} | "
              f"{fmt(g['output_tokens'])} | {fmt(tot)} | {usd(g['usd'])} |")
    print(f"| **Total** | {soma['execucoes']} | {soma['chamadas']} | {fmt(soma['input_tokens'])} | "
          f"{fmt(soma['cache_creation_input_tokens'])} | {fmt(soma['cache_read_input_tokens'])} | "
          f"{fmt(soma['output_tokens'])} | {fmt(sum(soma[c] for c in CAMPOS))} | **{usd(soma['usd'])}** |")


def usd(v):
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def listar_chamadas(execs, filtro):
    alvo = [e for e in execs if filtro.lower() in f"{e['agente']} {e['descricao']}".lower()]
    if not alvo:
        raise SystemExit(f"Nenhuma execução corresponde a '{filtro}'.")
    for e in alvo:
        chamadas, _ = ler_chamadas(e["arquivo"])
        print(f"\n### Chamadas — {e['inicio'][:16]} {e['agente']} — {e['descricao']}\n")
        print("| # | Hora | Modelo | Entrada nova | Escrita cache | Leitura cache | Saída | US$ (est.) |")
        print("|---:|---|---|---:|---:|---:|---:|---:|")
        for i, ch in enumerate(sorted(chamadas, key=lambda c: c["hora"]), 1):
            print(f"| {i} | {ch['hora'][11:19]} | {ch['modelo']} | {fmt(ch['input_tokens'])} | "
                  f"{fmt(ch['cache_creation_input_tokens'])} | {fmt(ch['cache_read_input_tokens'])} | "
                  f"{fmt(ch['output_tokens'])} | {usd(ch['usd'] or 0)} |")
        print(f"\nTotal da execução: {len(chamadas)} chamadas, US$ {usd(e['usd'])}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--projeto", default=os.getcwd(), help="diretório do projeto (padrão: cwd)")
    ap.add_argument("--sessao", help="id da sessão (padrão: todas)")
    ap.add_argument("--desde", help="data mínima AAAA-MM-DD")
    ap.add_argument("--etapa", help="filtra por etapa (ex.: E0, E1); o orquestrador fica fora quando há filtro")
    ap.add_argument("--detalhe", action="store_true", help="lista cada execução")
    ap.add_argument("--csv", help="grava as execuções neste CSV (sobrescreve)")
    ap.add_argument("--chamadas", metavar="FILTRO", help="lista cada chamada à API das execuções cuja descrição/agente contém FILTRO")
    a = ap.parse_args()

    base = pasta_projeto(os.path.abspath(a.projeto))
    if not os.path.isdir(base):
        raise SystemExit(f"Transcrições não encontradas em {base}")
    execs = coletar(base, a.sessao, a.desde)
    if a.etapa:
        execs = [e for e in execs if e["etapa"].upper().startswith(a.etapa.upper())]
    if not execs:
        raise SystemExit("Nenhuma execução encontrada para o filtro.")

    print(f"Consumo de tokens — {base}")
    tabela("Por etapa", execs, lambda e: e["etapa"])
    tabela("Por agente", execs, lambda e: e["agente"])
    if a.detalhe:
        tabela("Por execução", execs, lambda e: f"{e['inicio'][:16]} {e['agente']} — {e['descricao'][:50]}")
    if a.chamadas:
        listar_chamadas(execs, a.chamadas)
    print("\nUS$ (est.) = estimativa a preço de API por modelo (entrada, escrita de cache 5 min x1,25 / 1 h x2,"
          " leitura de cache, saída). Em plano de assinatura não há cobrança por token: use como equivalente de API.")
    if SEM_PRECO:
        print(f"Modelos sem preço na tabela (contados como US$ 0): {', '.join(sorted(SEM_PRECO))}")

    if a.csv:
        os.makedirs(os.path.dirname(os.path.abspath(a.csv)), exist_ok=True)
        cols = ["sessao", "inicio", "etapa", "id", "agente", "descricao", "modelo", "chamadas", *CAMPOS, "usd"]
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(execs)
        print(f"CSV gravado em {a.csv}")


if __name__ == "__main__":
    main()
