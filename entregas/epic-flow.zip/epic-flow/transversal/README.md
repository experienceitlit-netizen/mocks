# Base comum (transversal)

Conhecimento compartilhado por todos os épicos e features. Evita que cada feature redesenhe componentes, regras e termos já definidos (ex.: um `<componente>` usado por várias features). A Arquitetura de Solução de cada feature é escrita como **delta** sobre esta base.

Status: **vazia**. A base comum nasce vazia e só é preenchida pelo próprio fluxo, a partir dos insumos registrados via `/ef-insumos` e dos artefatos aprovados nos gates (Regra de Isolamento, [01-fluxo §7](../processo/01-fluxo.md#7-isolamento-de-fontes)). Não há carga inicial de nenhuma outra fonte.

## Arquivos previstos

| Arquivo | Conteúdo | Dono | Quando é preenchido |
|---|---|---|---|
| `glossario.md` | Termos de negócio e linguagem ubíqua, nomes canônicos (com o `IN-nnn` de origem) | `pm` (negócio) + `po` (termos de história) | E0–E3, a partir das fichas `IN-nnn` e dos PRDs |
| `catalogo-componentes.md` | Componentes canônicos: responsabilidade, tecnologia, interfaces, dados, status (existente / novo / a desligar) | `arquiteto` | E4, com o delta aprovado no G4 (sistemas atuais só se citados nos insumos) |
| `catalogo-regras.md` | Regras parametrizáveis `RP-nn` (a partir de `RP-01`), com valor, maturidade, uso e `IN-nnn` de origem | `po` (regra de negócio) + `tech-lead` (forma técnica) | E3 e E5 |
| `adr/` | Decisões de arquitetura `AD-nn-<slug>.md` (a partir de `AD-01`) | `arquiteto` | E2 e E4 |
| `decisoes-e-questoes.md` | Registro único de questões e propostas de mudança `Q-nnn` | orquestrador (agentes só acrescentam) | todas as etapas |

## Regras

- Só o dono edita o arquivo. Outro agente que precisar de mudança abre `Q-nnn` em `decisoes-e-questoes.md`.
- Séries de ID do fluxo começam em 01 (`AD-01`, `RP-01`); IDs e siglas citados nos insumos aparecem só como `IN-nnn:<id>`. Ver [04-convencoes](../processo/04-convencoes.md) §1 e §5.
- Status e resposta de cada Q-nnn (`aberta`, `respondida`, `descartada`) só mudam por decisão humana: o orquestrador registra a resposta dada na rodada de esclarecimento (`/ef-esclarecer`, `via: esclarecimento`) ou o humano edita o arquivo (`via: arquivo`). Toda Q-nnn tem `prioridade` e `opcoes` ([04-convencoes](../processo/04-convencoes.md) §8).
