# epic-flow

Fluxo agêntico reutilizável que leva insumos brutos (transcrições, atas, notas, apresentações, docs de fluxo) até a implementação, passando por PRD, arquitetura em dois níveis, features, histórias, specs e tasks. Cada etapa tem um agente dono e cada transição de dono tem um gate humano.


## Isolamento de fontes

Ao aplicar o fluxo, os agentes só usam: (a) os insumos registrados via `/ef-insumos` (fichas `insumos/IN-nnn-*.md`), via `/ef-epico EP-nn insumos=<pasta>` (fichas `epicos/EP-nn-*/insumos/IN-EPnn-*.md`) ou via `/ef-features EP-nn feature=|historia=... insumos=<pasta>` (fichas `IN-FTnn.nn-nn` e `IN-USnn.nn.nn-nn` nas pastas `insumos/` da feature e da história), e os arquivos apontados no campo `fonte` delas; (b) os artefatos produzidos pelo próprio fluxo em `epic-flow/`; (c) os documentos de `processo/` e `templates/`; (d) as **referências corporativas** listadas em [`referencias/README.md`](referencias/README.md). Respostas registradas em `Q-nnn` respondidas (decisão humana colhida na rodada de esclarecimento) também são fonte permitida. Nenhum outro arquivo do repositório, nenhuma memória ou contexto de sessões anteriores e nenhum conhecimento prévio sobre o projeto entram nos artefatos. Informação ausente vira `Q-nnn`.

Referências corporativas (fixas, em `epic-flow/referencias/`, versionadas fora dos insumos, caminhos configuráveis em [`referencias/README.md`](referencias/README.md)):

| Categoria | Caminho neste projeto | Usada por |
|---|---|---|
| stack de tecnologia | `referencias/stack-tech.md` | `arquiteto` E2/E4, `tech-lead` E5, `desenvolvedor` E6 |
| arquitetura corporativa | `referencias/arquitetura-corporativa/` | `arquiteto` E2/E4 (conformidade), `tech-lead` E5 (consulta) |
| padrões de desenvolvimento | `referencias/padroes-desenvolvimento/` | `tech-lead` E5, `desenvolvedor` E6, `arquiteto` E4 (consulta) |

Para reutilizar o fluxo em outro projeto, basta mudar os caminhos em `referencias/README.md` (ou o conteúdo da pasta `referencias/`). Regra completa em [processo/01-fluxo.md §7](processo/01-fluxo.md#7-isolamento-de-fontes).

## A squad

| Agente | Dono de | Gate que submete |
|---|---|---|
| `pm` | insumos, mapa de épicos, insumos do épico e PRD do épico | G0 Mapa de Épicos (PM humano, com sponsor quando houver); G1 PRD (sponsor de negócio); parecer de produto no G3 (aprovação é do PM humano) |
| `arquiteto` | Arq. de Referência, Arq. de Solução, base comum | G2 Arq. Referência e G4 Arq. Solução (comitê de arquitetura) |
| `po` | features e histórias | G3 Features+Histórias (PM + negócio) |
| `tech-lead` | specs e tasks | G5 Specs+Tasks (Tech Lead + Desenvolvedor); aprova G6 |
| `desenvolvedor` | código, testes e PR | G6 Code review (Tech Lead) |

Os agentes são subagentes Claude em `../.claude/agents/`. O orquestrador é a sessão principal, conduzida por um humano: dispara os agentes, nunca pula gate, mantém a rastreabilidade e é o único que faz perguntas ao usuário (rodada de esclarecimento das `Q-nnn`).


## Comandos

Os comandos ficam em `.claude/commands/`. Cada um confere o gate anterior, chama o agente dono e diz qual é o próximo passo. Se a entrada não estiver `aprovado`, o comando para.

**Trava de bloqueantes (regra crítica):** cada etapa reavalia as `Q-nnn` abertas que bloqueiam o seu desenvolvimento; com `Q-nnn` `bloqueante` aberta ligada ao alvo, às entradas ou à etapa, a etapa não segue e o gate não aprova até a bloqueante ser respondida, descartada ou reclassificada com justificativa (decisão humana). Regra completa em [processo/01-fluxo.md §4](processo/01-fluxo.md#trava-de-bloqueantes).

| Comando | Etapa / agente | Exemplo |
|---|---|---|
| `/ef-insumos <pasta\|arquivos> [foco=]` | E0 · `pm`: fichas `IN-nnn` | `/ef-insumos docs-precificacao/` |
| `/ef-mapa-epicos [IN-ids\|todos] [foco=] [revisar]` | E0 · `pm`: mapa de épicos (`MAPA`, reserva `EP-nn`) | `/ef-mapa-epicos todos` |
| `/ef-epico <EP-nn> [insumos=<pasta>] [foco=] [IN-ids extras]` | E1 · `pm`: PRD de um épico do mapa; com `insumos=`, antes registra as fichas `IN-EPnn-nn` do épico (um subagente para as fichas, outro para o PRD) | `/ef-epico EP-01 insumos=<pasta> foco="<tema>"` |
| `/ef-arq-ref <EP>` | E2 · `arquiteto`: `AR-nn` e capacidades de negócio `CAP-nn` | `/ef-arq-ref EP-01` |
| `/ef-features <EP> [foco=] [feature=\|historia=] [insumos=<pasta>]` | E3 · `po`: features e histórias (referenciam `CAP-nn` da AR); com `insumos=` (exige `feature=` ou `historia=` existente), antes o `pm` registra as fichas `IN-FTnn.nn-nn` ou `IN-USnn.nn.nn-nn` | `/ef-features EP-01 feature=FT-01.02 insumos=<pasta>` |
| `/ef-arq-sol <FT>` | E4 · `arquiteto`: `AS-nn.nn` | `/ef-arq-sol FT-01.02` |
| `/ef-specs <FT\|US,...> [so-specs\|so-tasks]` | E5 · `tech-lead`: specs e tasks | `/ef-specs FT-01.02` |
| `/ef-dev <TK>` | E6 · `desenvolvedor`: código, testes, PR | `/ef-dev TK-01.02.01-01` |
| `/ef-esclarecer <ID\|todas> [prioridade=bloqueante\|importante\|todas]` | rodada de esclarecimento: pergunta ao usuário as `Q-nnn` abertas (até 4 por vez, com opções), registra as respostas e aciona o agente dono para incorporá-las | `/ef-esclarecer EP-01` |
| `/ef-status [EP\|FT]` | painel: status, gates aguardando você, etapas e artefatos BLOQUEADOS, `Q-nnn` abertas | `/ef-status EP-01` |
| `/ef-consumo [sessao=] [desde=] [detalhe] [chamadas=] [csv]` | tokens e US$ estimado por etapa, agente, execução e chamada (`metricas/consumo.py`) | `/ef-consumo detalhe chamadas="E1 EP-01"` |
| `/ef-aprovar <ID> [por=] [obs=]` | **humano** registra o gate (G0–G6) | `/ef-aprovar EP-01 por="Sponsor X"` |
| `/ef-devolver <ID> <motivo>` | **humano** devolve para `rascunho` | `/ef-devolver FT-01.02 "falta cenário de alçada"` |

Ciclo típico: `/ef-insumos` → `/ef-mapa-epicos` → (rodada de esclarecimento) → `/ef-aprovar MAPA` → `/ef-epico EP-01` (um por épico do mapa) → (rodada de esclarecimento) → `/ef-aprovar EP-01` → `/ef-arq-ref EP-01` → `/ef-aprovar AR-01` → `/ef-features EP-01` → `/ef-aprovar FT-01.01` → `/ef-arq-sol FT-01.01` → `/ef-aprovar AS-01.01` → `/ef-specs FT-01.01` → `/ef-aprovar SP-01.01.01` → `/ef-dev TK-01.01.01-01`. Em qualquer passo, havendo `Q-nnn` bloqueante, o comando executa a rodada obrigatória (só bloqueantes) antes de seguir e encerra como BLOQUEADO se alguma for pulada; destrave com `/ef-esclarecer <ID>`. A rodada para as `importante` é oferecida depois de `/ef-mapa-epicos` e `/ef-epico`; nas demais etapas, rode `/ef-esclarecer <ID>` quando o comando sugerir.

## Fluxo resumido

```mermaid
%%{init: {"flowchart": {"wrappingWidth": 420}}}%%
flowchart TB
    E0["E0 Insumos + Mapa de Épicos<br/>pm<br/>/ef-insumos &lt;pasta&gt;<br/>/ef-mapa-epicos"] --> G0{{"G0<br/>/ef-aprovar MAPA"}} --> E1["E1 PRD do Épico<br/>pm, um por EP-nn<br/>/ef-epico EP-nn [insumos=&lt;pasta&gt;]"] --> G1{{"G1<br/>/ef-aprovar EP-nn"}}
    G1 --> E2["E2 Arquitetura de Referência<br/>arquiteto<br/>/ef-arq-ref EP-nn"] --> G2{{"G2<br/>/ef-aprovar AR-nn"}}
    G2 --> E3["E3 Features e Histórias<br/>po<br/>/ef-features EP-nn [feature=|historia=] [insumos=&lt;pasta&gt;]"] --> G3{{"G3<br/>/ef-aprovar FT-nn.nn"}}
    G3 --> E4["E4 Arquitetura de Solução da Feature<br/>arquiteto<br/>/ef-arq-sol FT-nn.nn"] --> G4{{"G4<br/>/ef-aprovar AS-nn.nn"}}
    G4 --> E5["E5 Specs e Tasks<br/>tech-lead<br/>/ef-specs FT-nn.nn"] --> G5{{"G5<br/>/ef-aprovar SP-nn.nn.nn"}}
    G5 --> E6["E6 Implementação<br/>desenvolvedor<br/>/ef-dev TK-nn.nn.nn-nn"] --> G6{{"G6<br/>/ef-aprovar TK-nn.nn.nn-nn"}}
```

Em qualquer etapa: `/ef-esclarecer <ID>` (questões `Q-nnn`), `/ef-devolver <ID> <motivo>` (gate reprovado), `/ef-status` e `/ef-consumo`.

Arquitetura em dois níveis: a **Arquitetura de Referência** é por épico (Motivação, Estratégia, Negócio) e a **Arquitetura de Solução** é por feature (Aplicação, Tecnologia, Implantação/Migração), escrita como delta sobre a base comum em `transversal/`. As duas arquiteturas declaram aderência à arquitetura corporativa (referências corporativas fixas, ao lado de `transversal/`); desvio exige ADR. Justificativa em [processo/01-fluxo.md §3](processo/01-fluxo.md#3-por-que-duas-arquiteturas).

## Navegação

| Pasta / arquivo | Conteúdo |
|---|---|
| [processo/01-fluxo.md](processo/01-fluxo.md) | etapas E0–E6, gates G0–G6, por que duas arquiteturas, retroalimentação, paralelismo, orquestrador, isolamento de fontes |
| [processo/02-squad-agentes.md](processo/02-squad-agentes.md) | papéis dos 5 agentes, RACI, handoffs |
| [processo/03-contratos-etapas.md](processo/03-contratos-etapas.md) | entradas, saídas, DoR, DoD, aprovador e fontes por etapa |
| [processo/04-convencoes.md](processo/04-convencoes.md) | IDs, frontmatter, status, estrutura de pastas, rastreabilidade |
| [referencias/](referencias/README.md) | referências corporativas (fixas): stack, arquitetura corporativa, padrões de desenvolvimento; caminhos configuráveis por projeto |
| [insumos/](insumos/README.md) | registro de insumos `IN-nnn` com cabeçalho padrão; insumos específicos de um épico ficam em `epicos/EP-nn-<slug>/insumos/` (`IN-EPnn-nn`), de uma feature em `FT-nn.nn-<slug>/insumos/` (`IN-FTnn.nn-nn`) e de uma história em `FT-nn.nn-<slug>/historias/insumos/US-nn.nn.nn/` (`IN-USnn.nn.nn-nn`) |
| [transversal/](transversal/README.md) | base comum: glossário, catálogo de componentes, catálogo de regras, ADRs, decisões e questões `Q-nnn` (nasce vazia, preenchida só pelo fluxo) |
| [epicos/](epicos/README.md) | `mapa-epicos.md` (lista de épicos, G0) e um diretório por épico `EP-nn-<slug>/` (vazio até a aplicação do fluxo) |
| [templates/](templates/README.md) | templates dos artefatos (a definir) |

## Status do piloto CASH

| Fase | Status |
|---|---|
| Fluxo definido (processo, papéis, contratos, convenções, subagentes) | concluído |
| Templates dos artefatos em `templates/` (versão mínima 0.1) | concluído |
| Aplicação do fluxo (E0 em diante) | próximo passo |

O piloto é o projeto CASH. Os insumos do piloto são os arquivos da pasta que o usuário indicar ao rodar `/ef-insumos` (ex.: `/ef-insumos docs-precificacao/`). Não há lista prévia de épicos: o mapa de épicos nasce só das fichas `IN-nnn`. Mapa e PRD não tratam capacidades de negócio; elas são identificadas na Arquitetura de Referência (E2, `arquiteto`).

## Setup

Esta é uma pasta de documentação. Pelo padrão de `/home/itl/Projects/AGENTS.md`, basta o `README.md`; `setup.sh`, declaração de dependências e `.env.example` não se aplicam. Para usar o fluxo, abra o Claude Code em `/home/itl/Projects/CASH` e confira que `/agents` lista `pm`, `po`, `arquiteto`, `tech-lead` e `desenvolvedor`.
