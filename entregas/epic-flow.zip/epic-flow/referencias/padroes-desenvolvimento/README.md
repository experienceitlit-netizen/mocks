# Padrões de desenvolvimento

Fonte fixa do `epic-flow` (categoria `padroes-desenvolvimento`), lida pelos agentes conforme [`epic-flow/referencias/README.md`](../README.md). O `tech-lead` a usa na etapa E5 (specs e tasks) e o `desenvolvedor` na E6 (implementação); o `arquiteto` a consulta na E4.

O que colocar aqui (um arquivo `.md` por tema):

- padrões de código (estrutura de módulos, nomenclatura, revisão);
- padrões de API (contratos, versionamento, erros, idempotência);
- padrões de testes (tipos, cobertura, dados de teste);
- CI/CD (pipeline, branches, ambientes, promoção);
- segurança (autenticação, autorização, segredos, dados sensíveis);
- observabilidade (logs, métricas, traces, alertas).

Cada padrão deve ter um identificador estável para que a spec o cite na seção "Padrões de desenvolvimento aplicados". Se a pasta estiver vazia, o fluxo não para: o agente registra `Q-nnn`.
