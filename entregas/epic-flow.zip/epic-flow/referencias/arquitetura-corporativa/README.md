# Arquitetura corporativa

Fonte fixa do `epic-flow` (categoria `arquitetura-corporativa`), lida pelos agentes conforme [`epic-flow/referencias/README.md`](../README.md). O `arquiteto` a usa nas etapas E2 e E4 para verificar conformidade, e o `tech-lead` a consulta na E5.

O que colocar aqui (um arquivo `.md` por tema):

- princípios de arquitetura da organização;
- padrões de integração (síncrona, assíncrona, eventos, arquivos);
- building blocks corporativos reutilizáveis (plataformas, serviços compartilhados);
- guidelines ArchiMate corporativos (viewpoints, notação, cores, nomenclatura).

Cada princípio ou padrão deve ter um identificador estável para que os artefatos o citem na seção "Aderência à arquitetura corporativa". Se a pasta estiver vazia, o fluxo não para: o agente registra `Q-nnn`.
