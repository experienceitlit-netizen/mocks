1 - Salesforce Financial Service
2 - Azure Cloud 
3 - Java para transações e operações é prioritário
4 - Python é usado principalmente para processamento de dados, ETL, cargas de dados.
5 - Databricks usado para ambiente analítico, ETL, processamento de dados.
6 - ARO - Azure RedHat OpenShift, plataforma de container corporativa onde são hospedados os serviços, sejam eles java ou python.
7 - Axway API Gateway
8 - Azue Application Gateway Loadbalance.
9 - Akamai, porta de entrada para canais externo (Akamai -> Loadbalance -> Axway API Gateway -> Microsserviços)
