# Referências corporativas

Arquivo de configuração do projeto. Lista as **referências corporativas**: fontes fixas do `epic-flow`, mantidas em `epic-flow/referencias/` e versionadas fora dos insumos, que os agentes leem conforme a etapa. Elas são a fonte (d) da Regra de Isolamento ([processo/01-fluxo.md §7](../processo/01-fluxo.md#7-isolamento-de-fontes)).

Os agentes descobrem os caminhos **só por este arquivo**. Agentes, comandos e templates citam a categoria (ex.: "referência corporativa `padroes-desenvolvimento`"), nunca o caminho.

## Referências do projeto

Caminhos relativos a esta pasta (`epic-flow/referencias/`). Por padrão, todas as referências ficam aqui dentro do `epic-flow`; um caminho pode apontar para fora (ex.: repositório corporativo compartilhado) se o projeto preferir.

| Categoria | Caminho | Usada por (agentes/etapas) | Obrigatória? |
|---|---|---|---|
| `stack` — stack de tecnologia | `stack-tech.md` | `arquiteto` E2/E4; `tech-lead` E5; `desenvolvedor` E6 | sim, para arquiteto, tech-lead e desenvolvedor |
| `arquitetura-corporativa` — princípios, padrões de integração, building blocks, guidelines ArchiMate corporativos | `arquitetura-corporativa/` | `arquiteto` E2/E4 (conformidade); `tech-lead` E5 (consulta) | sim, para o arquiteto; consulta para o tech-lead |
| `padroes-desenvolvimento` — padrões de código, API, testes, CI/CD, segurança e observabilidade | `padroes-desenvolvimento/` | `tech-lead` E5; `desenvolvedor` E6; `arquiteto` E4 (consulta) | sim, para tech-lead e desenvolvedor; consulta para o arquiteto |

`pm` e `po` podem consultar qualquer referência, mas não dependem delas.

## Regras

- Referência corporativa é fonte permitida, não insumo: não passa por `/ef-insumos` nem ganha ficha `IN-nnn`. Ao citá-la num artefato, use `<categoria>:<arquivo> §<seção>` (ex.: `padroes-desenvolvimento:api.md §2`).
- Arquivo ou pasta vazio ou ausente **não bloqueia** o fluxo: o agente registra `Q-nnn` ("referência corporativa `<categoria>` ausente"), marca o ponto afetado como "a validar" e segue.
- Na Arquitetura de Referência e na Arquitetura de Solução, todo desvio de princípio ou padrão da `arquitetura-corporativa` exige ADR. Na spec, exceção a um padrão de `padroes-desenvolvimento` exige `Q-nnn` ou ADR.
- Quando a referência corporativa e um insumo divergirem, o agente não escolhe: registra `Q-nnn`.

## Reutilizar o fluxo em outro projeto

Para reutilizar o fluxo, basta trocar os caminhos da tabela ou acrescentar uma categoria (nova linha com caminho, agentes/etapas e obrigatoriedade). Agentes, comandos e templates não precisam mudar.
