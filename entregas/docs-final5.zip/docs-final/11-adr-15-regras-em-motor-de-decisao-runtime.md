# ADR AD-15 — Regras de precificação em um único motor de decisão, executado online e em lote (alternativa à BRP gerada pelo pipeline)

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-21 |
| Status | **Proposto — alternativa em avaliação**; não substitui AD-01 e AD-04 até decisão do comitê |
| Origem | Discussão do arquiteto com a gestão em 2026-09-21: "a BRP poderia ser gerada em tempo de execução, com as regras das etapas num motor de decisão (FICO) consultando bases replicadas?" |
| Documentos afetados se aprovado | 03 (M2), 05 (BCs Modelagem, Publicação e Cálculo), 06 (§5.1, §5.2, §6, ADR), 07 (dbx-ppp, dbx-brp, svc-pricing, svc-parametros), 08 (épicos PPP, BRP, PRC, PAR), 09 (F1) e arquitetura-solucao-archmate.md |
| Convenção de referências | `NN:L<linha>` = `docs-precificacao/NN-*.md`; `A0`, `A1`, `A2` = anexos |

## 1. Contexto

A arquitetura vigente (AD-01, AD-03, AD-04) faz o pipeline no Databricks (`dbx-ppp`) executar as 15 etapas dos fluxos de produto e consolidação e publicar, uma vez por ciclo, a BRP Cash com os cenários de preço já decididos (MPA) e a posição de cada cliente (PPC). O motor online (`svc-pricing`) apenas classifica, consulta o cenário e aciona alçada.

Esse desenho tem uma fragilidade estrutural: as regras de negócio ficam em dois lugares. O pipeline aplica tier, cluster, alvo e sugerido para gerar a BRP; o motor online reaplica tier e cluster quando o gerente simula uma volumetria diferente da observada. Qualquer mudança de faixa exige alterar os dois, e o módulo de parametrização (M1) existe em boa parte para manter os dois sincronizados.

A pergunta da gestão é se a BRP precisa existir como tabela construída por regras, ou se pode ser o resultado de um único modelo de decisão executado quando necessário. Este ADR avalia essa alternativa e propõe um desenho em duas passadas que a torna viável.

Premissa corrigida: a BRP não é carregada diariamente. O ciclo é mensal (`07:L112`, tabelas `SIMUL_*_AAAAMM`) e o preço por produto é semestral; as janelas de entrada vão de 3 a 13 meses (`00-etapas:L5-16`). O ganho de frescor de um cálculo em runtime é, portanto, limitado pela cadência dos próprios insumos.

## 2. Separação fundamental: estatística de população x regra por cliente

As etapas dos fluxos (A1 "Padrão comum de etapas"; A2 Fluxos 05 e 06) se dividem em dois tipos com naturezas incompatíveis para execução em runtime.

| Tipo | Etapas | Por que importa |
|---|---|---|
| **Estatística de população** | Percentis de tarifa por cluster (P25…P90), referência corporate ponderada por volume, ajuste de monotonicidade (cummin), contagem N de grupos por cluster, esqueleto de cenários (`01:L94-106`, `05:L20-29`) | Um percentil só existe olhando todos os clientes do cluster. Não é uma regra sobre um cliente; é uma agregação sobre 12 meses de movimento de milhares de grupos. Calcular por consulta significaria varrer a população a cada chamada, ou cachear o resultado, o que é um lote com outro nome. |
| **Regra por cliente** | Tier pela volumetria (`01:L59-79`), cluster por tier x segmento x região (`01:L81-92`, `05:L56-96`), alvo = max(tarifa, P75) (`01:L112`), derivação do sugerido (lacuna 1), desconto por relacionamento (`06:L137`), scores de stickiness e impacto (`06:L62-123`), uplift (`01:L116`), exclusões e exceções (`07:L48-60`), alçada (`00-neg:L22`) | Aplicam faixas, tabelas e fórmulas aos dados de um único grupo econômico. São exatamente o que um motor de decisão faz bem, online ou em lote. |

Conclusão: "tudo em runtime" não é uma opção. A escolha real é **onde fica a fronteira** entre o que o lote produz e o que o motor de decisão aplica.

## 3. Opções

### Opção A — vigente (AD-01/AD-04): pipeline decide, BRP publica cenários prontos

O Databricks executa estatística **e** regra; publica MPA e PPC; o motor online faz lookup e reaplica só tier/cluster para volumetrias simuladas. Regras em duas implementações (PySpark e Java), sincronizadas por parâmetros versionados.

### Opção B — proposta deste ADR: um único modelo de decisão, executado online e em lote, com ciclo em duas passadas

- O Databricks produz **apenas** estatística de população e insumos por cliente. Não conhece tier, cluster, alçada ou sugerido.
- Um **modelo de decisão único** (FICO Platform ou serviço Java com tabelas de decisão; ver §7) contém todas as regras por cliente, versionado e publicado pela parametrização.
- O mesmo modelo é chamado de dois modos: **online**, um cliente por consulta, e **lote**, todos os clientes na virada do ciclo. O resultado do lote é o snapshot do ciclo.
- A BRP Cash deixa de ser "tabela gerada por regras do pipeline" e passa a ser a **materialização da saída do modelo de decisão** em uma data, com a versão do modelo e dos insumos gravada. Continua existindo, mas como cache auditável, não como segunda lógica.

### Opção C — variante de B sem chamada do motor de decisão a partir do Databricks

Igual a B, mas a regra de cluster é **exportada como tabela de parâmetro** (produto x tier x segmento x região → cluster, mais faixas de tier) que o Databricks lê para agrupar as tarifas e calcular percentis. Evita a integração Databricks → motor de decisão na passada 1 ao custo de uma dependência de dado. Aceitável se a tabela for gerada a partir da mesma versão publicada do modelo, nunca editada à parte.

## 4. O problema que obriga duas passadas

Os percentis são calculados **por cluster** (`01:L96`, `05:L20`), e cluster é uma regra do modelo de decisão. Logo, para o Databricks agrupar tarifas e tirar o P75, ele precisa saber em que cluster cada cliente está **antes** de calcular a estatística. E o modelo de decisão, para dar o preço, precisa do P75 **depois** que a estatística existe. Há uma dependência circular entre regra e estatística que se resolve com duas passadas do modelo de decisão no mesmo ciclo.

## 5. Fluxo do ciclo em duas passadas (Opção B)

```mermaid
flowchart LR
  subgraph DBX["Databricks — estatística e insumos (sem regra de preço)"]
    E0["Extração e tratamento<br/>movimento 12m, eventos tarifados,<br/>segmentos, ROB, saldos, shares"]
    I1[("Insumos por cliente<br/>(volumetria, tarifa praticada,<br/>saldo IF/DAV, share, ROB)")]
    S1[("Estatísticas por cluster<br/>P25..P90, N, referência corporate,<br/>cummin — por ciclo")]
    E0 --> I1
  end
  subgraph MD["Motor de decisão — modelo único versionado"]
    P1["Passada 1 — Classificar<br/>tier + cluster por cliente x produto<br/>(lote, versão v)"]
    P2["Passada 2 — Decidir preço<br/>alvo, sugerido, desconto, uplift,<br/>elegibilidade, alçada por faixa<br/>(lote, versão v)"]
    ON["Consulta online<br/>mesmo modelo, versão v,<br/>um cliente por chamada"]
  end
  subgraph SNAP["Materialização do ciclo"]
    C1[("Classificação do ciclo<br/>cliente x produto → tier, cluster")]
    B1[("BRP Cash = snapshot<br/>saída da passada 2 + versão do modelo<br/>+ versão dos insumos")]
  end
  I1 --> P1 --> C1
  C1 --> S1
  I1 --> S1
  S1 --> P2
  I1 --> P2
  P2 --> B1
  S1 --> ON
  I1 --> ON
  B1 -. "onda de reprecificação,<br/>auditoria, histórico" .-> C2["C2 / C3 / Calculadora<br/>(foto congelada)"]
  ON --> SF["Calculadora Salesforce<br/>(consulta viva)"]
  classDef dbx fill:#C9E7B7,stroke:#5a7d3a,color:#222;
  classDef md fill:#B5FFFF,stroke:#2a7d8d,color:#222;
  classDef snap fill:#FFFFB5,stroke:#8d7d2a,color:#222;
  class E0,I1,S1 dbx; class P1,P2,ON md; class C1,B1 snap;
```

Sequência da virada de ciclo:

```mermaid
sequenceDiagram
  autonumber
  participant CM as Control-M
  participant DBX as Databricks (dbx-ppp)
  participant MD as Motor de decisão (lote)
  participant PRM as Parametrização (versões)
  participant SNAP as sql-motor (snapshot / BRP)
  CM->>DBX: iniciar ciclo anomes
  DBX->>DBX: extrair e tratar insumos por cliente (12m, segmentos, saldos, shares, ROB)
  DBX->>PRM: obter versão publicada v do modelo de decisão
  DBX->>MD: Passada 1 - classificar todos os clientes x produto (tier, cluster) com versão v
  MD-->>DBX: classificação do ciclo
  DBX->>DBX: calcular estatísticas por cluster (percentis, N, referência corporate, cummin)
  DBX->>MD: Passada 2 - decidir preço por cliente x produto (estatísticas + insumos), versão v
  MD-->>SNAP: gravar snapshot (alvo, sugerido, uplift, elegibilidade) + versão v + id dos insumos
  SNAP->>SNAP: validar e ativar versão do ciclo (swap atômico, rollback disponível)
  Note over MD,SNAP: A consulta online passa a usar as estatísticas do ciclo ativo e a mesma versão v
```

Na consulta online, o motor recebe cliente, produto e volumetria informada, lê os insumos do cliente e as estatísticas do ciclo ativo, e executa a mesma versão v do modelo. Se a volumetria informada muda o tier, o cluster muda e o P75 usado muda com ele, sem nenhuma reclassificação escrita em Java.

## 6. O que muda por componente

| Componente | Opção A (vigente) | Opção B (este ADR) |
|---|---|---|
| `dbx-ppp` | 7 notebooks portados com regra e estatística | Só extração, tratamento, insumos por cliente e estatísticas por cluster; chama o motor de decisão nas passadas 1 e 2 (ou lê a tabela de cluster, Opção C) |
| `dbx-brp` / BRP Cash | Tabelas gold com cenários decididos (MPA, PPC) | Snapshot da saída do modelo por ciclo, com versão do modelo e id dos insumos; estatísticas por cluster como tabela própria |
| `svc-pricing` | Lookup do cenário + reclassificação tier/cluster em Java + alçada | Fachada fina: monta o contexto do cliente e invoca o motor de decisão; grava a cotação com versão v e ids dos insumos |
| `svc-parametros` (M1) | Versões de parâmetros consumidas por PySpark e Java | Publica versões do **modelo de decisão**; boa parte do CRUD de faixas migra para a ferramenta de decisão, se FICO; staging vira "versão candidata do modelo" |
| `svc-alcada` | Serviço próprio | Regra de alçada entra no modelo; o serviço fica só com o workflow do pedido de aprovação |
| Salesforce | Consome APIs | Igual; não sabe se atrás há FICO ou Java |
| Reverse ETL | Cenários prontos para o Azure SQL | Insumos por cliente + estatísticas por cluster + snapshot; volume maior, mas todos derivados |
| Auditoria (RNF-03, RNF-09) | Cotação grava versão da BRP e dos parâmetros | Cotação grava versão do modelo, id do ciclo de estatísticas e **valores dos insumos usados**, porque o preço depende deles |

## 7. FICO ou Java para o modelo de decisão

Este ADR é sobre a **fronteira** (estatística no lote, regra num único motor), não sobre o produto. As duas execuções são possíveis.

| Critério | FICO Platform (Decision Modeler / DMP) | Java + tabelas de decisão (Spring, DMN via Kogito/Camunda, ou motor próprio) |
|---|---|---|
| Autoria pelo negócio | Nativa: tabelas de decisão, testes, simulação, comparação de versões | Precisa construir telas e simulação (parte do M1 atual) |
| Execução lote e online com a mesma versão | Nativa | Precisa desenhar (endpoint unitário e endpoint em lote sobre o mesmo código) |
| Aderência à stack (`stack-tech.md`) | Fora da stack; Java é prioritário para transações | Aderente |
| Custo e skill | Licença e escassez de profissionais (AD-04) | Time existente |
| Lock-in | Regras em formato proprietário; exportação parcial | Regras em código e tabelas versionadas |
| Integração com Databricks nas passadas 1 e 2 | API de decisão em lote; validar throughput para dezenas de milhares de grupos x 18 produtos | Job Spark chamando serviço, ou biblioteca Java empacotada no cluster (mais eficiente) |
| Latência online | Depende do deployment; validar p95 ≤ 500 ms no Axway com bases replicadas (critério eliminatório da prova de conceito, RNF-02) | Controlável |

Recomendação dentro da Opção B: decidir o produto por prova de conceito na F0 com a regra mais complexa que existe hoje (cluster + percentil com referência corporate e cummin), medindo tempo de autoria, throughput em lote e latência online. Se a autoria pelo negócio for o critério decisivo, FICO; se aderência e custo, Java com DMN.

## 8. Ganhos e perdas

**Ganhos**
- Uma única implementação das regras por cliente; elimina a sincronização PySpark x Java que motivou boa parte do M1.
- Parametrização, staging e simulação de regras passam a ser do motor de decisão, que já resolve versionamento e teste.
- Mudança de regra vale na próxima consulta sem esperar o ciclo, quando a regra não depende de estatística nova.
- O snapshot vira derivado e reproduzível: qualquer preço do ciclo é recalculável com a mesma versão e os mesmos insumos.
- Volumetria simulada pelo gerente usa exatamente as mesmas regras do ciclo.

**Perdas e riscos**
- O Databricks continua indispensável (estatística e insumos, premissa `00-neg:L27`); a replicação de bases passa a ser de insumos brutos por cliente, maior que os cenários prontos.
- Ciclo em duas passadas é mais longo e tem uma integração nova (Databricks ↔ motor de decisão) no caminho crítico da virada mensal.
- Auditoria mais pesada: a cotação precisa persistir os insumos usados, não só versões.
- Latência e disponibilidade online piores que um lookup; a consulta executa o modelo completo a cada chamada. Mitigação: cache das estatísticas e dos insumos por cliente na memória do serviço.
- Onda de reprecificação e comparações entre ciclos continuam exigindo o snapshot congelado; quem esperava "acabar com a BRP" não a elimina, apenas muda sua natureza.
- Se FICO: custo, skill, lock-in e desvio da stack (R8, RNF-10).
- Disciplina obrigatória "mesma versão, mesmos insumos, mesmo motor" entre lote e online; sem ela a Opção B degenera na duplicação que quer evitar.

## 9. Riscos novos

| ID | Risco | Mitigação |
|---|---|---|
| R11 | Throughput do motor de decisão em lote insuficiente para a virada mensal | POC na F0 com volume real; empacotar o modelo como biblioteca no cluster (Java) ou usar execução em lote nativa (FICO) |
| R12 | Regra "vazar" para o Databricks (ex.: alguém codificar tier no PySpark para acelerar) | Revisão de arquitetura; Databricks não recebe parâmetros de regra, só versão e classificação |
| R13 | Divergência entre consulta online e snapshot por insumo atualizado no meio do ciclo | Insumos por cliente versionados por ciclo; online lê o mesmo id de ciclo até a próxima ativação |
| R14 | Custo/licença FICO não aprovado após desenho dependente dele | Modelo de decisão em DMN ou tabelas, portável entre engines; decisão de produto só após POC |

## 10. Impacto nas decisões existentes

| Decisão | Efeito se AD-15 for aprovado |
|---|---|
| AD-01 (Databricks para preparação) | Mantida, com escopo reduzido a estatística e insumos; passadas 1 e 2 chamam o motor de decisão |
| AD-02 (Azure SQL de serviço) | Mantida; passa a guardar insumos por cliente, estatísticas por cluster e snapshot |
| AD-03 (reverse ETL e ativação atômica) | Mantida; o objeto ativado é o snapshot + estatísticas do ciclo |
| AD-04 (Java + tabelas, FICO só se necessário) | **Substituída**: motor de decisão único com produto a definir por POC (FICO ou Java/DMN) |
| AD-06 (parametrização com staging) | Reescopada: versões do modelo de decisão; telas de faixas migram para a ferramenta se FICO |
| AD-11 (cache) | Ampliada: cache de estatísticas e insumos por cliente |
| AD-14 (shadow run) | Mantida e reforçada: comparar snapshot e online contra SQL 010 |
| Lacuna 1 (regra do sugerido) | Continua; passa a ser modelada no motor de decisão em vez de etapa T6b do pipeline |

## 11. Perguntas para o comitê decidir

1. A autoria de regras pelo time de Precificação, sem TI, é requisito ou desejo? Define o peso do FICO.
2. A virada mensal pode crescer em tempo (duas passadas) sem impacto operacional?
3. A área de dados aceita que o Databricks chame um serviço de decisão dentro do workflow (Opção B) ou prefere ler tabela de cluster (Opção C)?
4. Compliance aceita cotação com insumos persistidos (dados de saldo e share por cliente na base do motor)?
5. Há orçamento e prazo para uma POC de 4 a 6 semanas na F0 com FICO e com Java/DMN sobre a mesma regra?

## 12. Recomendação

**Revisão de 2026-09-21, após discussão sobre a real extensão da duplicação.** Na Opção A, o motor online não recalcula preço: alvo, sugerido e percentis vêm prontos da tabela de cenários. O que existe em dois lugares (PySpark e Java) são apenas as **faixas de tier** e a **tabela tier x segmento x região → cluster**, necessárias para reposicionar o cliente quando o gerente simula outra volumetria. Com essas duas tabelas lidas da mesma versão publicada pela parametrização, a duplicação é administrável e a Opção A é a mais simples para o que está documentado hoje.

A Opção B passa a ser recomendada **sob condição**: se a engenharia reversa do preço sugerido na F0 (lacuna 1) mostrar que ele depende de regras por cliente fora da tabela de cenários (saldo IF/DAV, negociações recentes, RFPs, nichos, gradação por Stickiness x Impacto aplicada individualmente), então a lista de regras duplicadas cresce e a fronteira da Opção B deve ser adotada. Nesse caso, a preferência de produto é o **motor de decisão em Java com tabelas DMN**, empacotado como serviço (online) e como biblioteca carregada no Databricks (passadas 1 e 2), ficando o FICO como troca de produto sem mudança de fronteira se a autoria pelo negócio for requisito e houver licença e time.

Recomendação original mantida abaixo para registro da avaliação completa da Opção B:

Aprovar a **fronteira** da Opção B (estatística no Databricks, regras por cliente num único motor de decisão executado online e em lote, snapshot derivado por ciclo), com a regra de cluster obtida pela **Opção C** na primeira versão (tabela exportada da mesma versão do modelo), evoluindo para a chamada direta na passada 1 quando a integração estiver madura. Decidir o produto do motor de decisão apenas após POC na F0. Até lá, AD-01 e AD-04 permanecem como documentadas; os épicos PPP, PRC e PAR do doc 08 devem ser marcados como dependentes desta decisão antes de virarem tasks.
