# Guia conceitual do modelo de precificação Cash — como cada conceito nasce e se encaixa

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-21 |
| Status | Material de estudo; números dos exemplos são ilustrativos, marcados como tal |
| Público | Quem precisa entender o modelo por dentro (arquitetura, engenharia, novos integrantes) |
| Fontes | `docs-precificacao/` (referências `NN:L<linha>`), anexos `A1` e `A2`; catálogo de regras no doc 12 |

## 1. O problema que o modelo resolve

O banco cobra tarifas por evento nos produtos de payments do Atacado: cada boleto registrado, cada baixa, cada TED a fornecedor, cada PIX pago, cada guia arrecadada gera um evento tarifado. Milhares de grupos econômicos pagam tarifas negociadas uma a uma ao longo dos anos, por gerentes diferentes, em momentos diferentes. O resultado é dispersão: dois clientes parecidos podem pagar tarifas muito diferentes pelo mesmo evento.

O modelo de precificação existe para responder três perguntas de forma padronizada:

1. **Quanto clientes parecidos com este pagam?** (referência de mercado interno)
2. **Quanto este cliente deveria pagar?** (preço alvo e preço sugerido)
3. **Quanto o banco ganharia se ele passasse a pagar isso?** (uplift)

E, nas evoluções, mais duas: **quem reprecificar primeiro e com que intensidade** (Stickiness x Impacto) e **o cliente está cumprindo o que combinou** (reciprocidade).

O business case organiza isso em quatro passos (`01:L126-135`, `05:L102-113`): (1) agrupar clientes comparáveis em clusters; (2) propor tarifa-alvo por cluster; (3) ajustar pelo relacionamento (saldo em Invest Fácil); (4) planejar reajustes graduais pela matriz de retenção x impacto. Os notebooks automatizam os passos 1 e 2; os passos 3 e 4 têm insumos calculados, mas a aplicação está na planilha e na Calculadora, sem documentação.

## 2. Mapa mental do modelo

```mermaid
flowchart TB
  subgraph D["Dados de um cliente x produto (12 meses)"]
    EV["Eventos tarifados<br/>quantidade e valor cobrado"]
    SEG["Segmento e grupo econômico"]
    UF["UF → região comercial"]
  end
  TP["Tarifa praticada<br/>= valor cobrado / quantidade"]
  TIER["Tier de volume<br/>faixa da quantidade mensal"]
  CL["Cluster de precificação<br/>tier, depois segmento, depois região<br/>(árvore de decisão, códigos 1 a 10)"]
  subgraph POP["Estatística sobre todos os clientes do cluster"]
    PCT["Percentis da tarifa praticada<br/>P25 … P90"]
    N["N = nº de grupos no cluster"]
    REF["Referência corporate<br/>+ ajuste cummin"]
  end
  ALVO["Preço alvo<br/>= max(tarifa praticada, P75 do cluster)"]
  UP["Uplift anual<br/>ganho se subir ao alvo"]
  SUG["Preço sugerido por cenário<br/>alvo + premissas (desconto, custos, RFP)"]
  BRP[("BRP Cash / Planilha Ano 1<br/>cenários + posição por cliente")]
  CALC["Calculadora Salesforce<br/>praticado, alvo, sugerido, cenários, alçada"]
  subgraph REL["Relacionamento (insumos dos passos 3 e 4)"]
    STK["Stickiness<br/>share de cash e de crédito"]
    IMP["Impacto<br/>ROB e receita cash"]
    REC["Indicadores de reciprocidade<br/>saldo IF/DAV, SoW boletos, emissões L3M"]
  end
  EV --> TP
  EV --> TIER
  SEG --> CL
  UF --> CL
  TIER --> CL
  CL --> PCT
  TP --> PCT
  PCT --> REF
  N --> ALVO
  REF --> ALVO
  TP --> ALVO
  ALVO --> UP
  ALVO --> SUG
  SUG --> BRP
  UP --> BRP
  STK --> BRP
  IMP --> BRP
  REC --> BRP
  BRP --> CALC
```

Leia de cima para baixo: os dados brutos de cada cliente viram uma tarifa praticada e um tier; tier, segmento e região, nessa ordem, decidem o cluster; sobre todos os clientes do cluster calcula-se a estatística; a estatística volta para cada cliente como preço alvo; o alvo vira sugerido por cenário e tudo é publicado para a Calculadora.

## 3. Tarifa praticada: o ponto de partida

Cada produto tem uma base de eventos tarifados dos últimos 12 meses (`00-etapas:L9-16`). Para cada grupo econômico e produto, o notebook soma a quantidade de eventos e o valor cobrado, e calcula a **tarifa praticada**: valor cobrado dividido pela quantidade (`01:L15`), ou a última tarifa observada com quantidade maior que zero (PIX e Arrecadação), ou a tarifa de contrato vigente (Multipag, `02:L19-21`).

É o "quanto ele paga hoje". Na Planilha aparece como a coluna `TARIFA` da Base Pricing.

Exemplo ilustrativo: o grupo Alfa registrou 60.000 boletos em 12 meses em "Quando do registro Cliente" e pagou R$ 90.000. Tarifa praticada: R$ 1,50 por boleto. Quantidade mensal média: 5.000.

## 4. Tier de volume: em que faixa de tamanho o cliente está

Volume é o principal determinante de preço: quem gera mais eventos paga menos por evento. O **tier** classifica a quantidade mensal do cliente em três faixas por produto, com limites definidos empiricamente pelo time de Precificação (`01:L61`). Tier 1 é o maior volume, tier 3 o menor.

| Produto (exemplo real) | Tier 3 | Tier 2 | Tier 1 |
|---|---|---|---|
| Quando do registro Cliente (`01:L65`) | até 17.000/mês | 17.001 a 100.000 | acima de 100.000 |
| Multipag Fornecedores TED (`02:L30`) | até 4.000 | 4.001 a 50.000 | acima de 50.000 |
| PIX Pagamentos (`03:L52-56`) | até 100 | 101 a 500 | acima de 500 |

O grupo Alfa, com 5.000 boletos por mês, cai no tier 3 de "Quando do registro Cliente".

Alguns produtos não têm tier 3 (Débito de Cobrança em conta corrente, `01:L79`): tudo abaixo do limite de tier 2 é tier 2. A faixa por produto é a regra RP-09 do catálogo.

## 5. Cluster de precificação: quem é comparável com quem

O cluster junta o tier com duas dimensões de perfil do cliente: o **segmento** comercial (Ultra, Large, Corporate, Global, Agro) e a **região** (SP, SE exceto SP, Sul, Centro-Oeste, Norte-Nordeste). A ideia é que a tarifa de referência de um cliente venha de clientes do mesmo tamanho, mesmo porte e mesma praça, porque a concorrência e o custo de servir variam entre eles.

Não é um produto cartesiano das três dimensões. É uma **árvore de decisão** que olha tier, depois segmento, depois região, e para na primeira dimensão que basta para distinguir o cliente. O resultado é um código de 1 a 10:

1. **Tier primeiro.** Tier 1 vira cluster 1; tier 2 vira cluster 2. Segmento e região são ignorados.
2. **Se for tier 3, olha o segmento.** Ultra ou Global: cluster 3. Large: cluster 4. Agro: cluster 10. Região ignorada.
3. **Se for tier 3 e Corporate ou Institucional, olha a região.** SP: 5. SE exceto SP: 6. Sul: 7. Centro-Oeste: 8. Norte-Nordeste: 9.

A mesma regra em forma de tabela (`05:L60-73`, grupo 1 de produtos):

| Situação | Cluster |
|---|---|
| Tier 1 (qualquer segmento) | 1 |
| Tier 2 (qualquer segmento) | 2 |
| Tier 3 e Ultra ou Global Corporate | 3 |
| Tier 3 e Large Corporate | 4 |
| Tier 3 e Corporate/Institucional em SP | 5 |
| Tier 3 e Corporate/Institucional em SE exceto SP | 6 |
| Tier 3 e Corporate/Institucional no Sul | 7 |
| Tier 3 e Corporate/Institucional no Centro-Oeste | 8 |
| Tier 3 e Corporate/Institucional no Norte-Nordeste | 9 |
| Tier 3 e Agro Corporate | 10 |

Repare na lógica: nos tiers grandes, o volume domina e o segmento não importa (clusters 1 e 2). No tier pequeno, o segmento passa a distinguir (3, 4, 10) e, para o miolo Corporate, a região distingue (5 a 9). Os clusters 5 a 9 são chamados de **clusters corporate** e têm papel especial na estatística, explicado adiante.

O grupo Alfa em "Quando do registro Cliente": 5.000 boletos por mês, logo tier 3; segmento Corporate, então a região decide; São Paulo: cluster 5.

**O cluster é por produto.** O tier depende da faixa de volume de cada produto, então o mesmo grupo Alfa pode ser cluster 5 em "Quando do registro Cliente" e cluster 2 em "PIX Pagamentos", se lá o volume dele cair no tier 2. Por isso as 75 combinações de tier x segmento x região continuam existindo como cenários (seção 8), mas várias delas apontam para o mesmo cluster: o cenário é a chave de consulta; o cluster é onde a estatística é calculada.

Cada produto pertence a um "grupo de regra" (1, 2 ou 3) com pequenas variações dessa tabela (`05:L75-94`), e Arrecadação usa uma regra diferente (`04:L54-61`). Essas diferenças estão nas regras RP-04 e RP-12.

## 6. Percentis, N, referência corporate e cummin: a estatística do cluster

Aqui o modelo deixa de olhar um cliente e olha todos os clientes do cluster. Tomando as tarifas praticadas de todos os grupos do cluster 5 de "Quando do registro Cliente", o notebook calcula os **percentis** (`01:L96`): o P25 é a tarifa abaixo da qual estão 25% dos clientes; o P50 é a mediana; o P75 é a tarifa abaixo da qual estão 75% deles; e assim por diante até o P90.

Exemplo ilustrativo para o cluster 5:

| Estatística | Valor |
|---|---|
| N (grupos no cluster) | 42 |
| P25 | R$ 1,20 |
| P50 | R$ 1,60 |
| P75 | R$ 2,10 |
| P90 | R$ 2,60 |

**N** (`01:L106`) é o número de grupos econômicos distintos que formaram esse cálculo. Com N pequeno, o percentil é frágil: três clientes não definem um mercado. Por isso a regra "N menor que 15 não gera uplift" (`01:L120`).

Os percentis P25 e P75, que são os que importam para o preço, não são usados crus. Passam por dois ajustes (`01:L97-102`):

**Referência corporate.** Em vez de cada cluster ter o seu P75 isolado, o modelo calcula um P75 de referência a partir dos clusters corporate (5 a 9), ponderando pelo volume de cada um. Esse é o patamar de tarifa dos clientes de menor porte, que é o teto natural: ninguém maior deveria pagar mais que eles.

**Ajuste de monotonicidade (cummin).** Depois, o modelo percorre os clusters na ordem de "força" decrescente do cliente, corporate → 10 → 4 → 3 → 2 → 1, e aplica o mínimo acumulado: o P75 de cada cluster passa a ser o menor entre o valor calculado para ele e o valor do cluster anterior na lista. O resultado é uma escada que nunca sobe.

Exemplo ilustrativo, P75 antes e depois do cummin:

| Cluster (ordem do cummin) | P75 calculado | P75 após cummin | O que aconteceu |
|---|---|---|---|
| Referência corporate (5 a 9) | R$ 2,10 | R$ 2,10 | teto |
| 10 (Agro) | R$ 2,30 | R$ 2,10 | estava acima do teto; puxado para baixo |
| 4 (Large) | R$ 1,90 | R$ 1,90 | mantido |
| 3 (Ultra/Global) | R$ 1,95 | R$ 1,90 | estava acima do Large; puxado |
| 2 (tier 2) | R$ 1,40 | R$ 1,40 | mantido |
| 1 (tier 1) | R$ 1,10 | R$ 1,10 | mantido |

Sem o ajuste, o cliente Agro ou Ultra veria uma referência maior que a de um cliente Corporate menor, o que seria indefensável na negociação. O preço que se paga por essa coerência é que alguns clusters ficam com referência abaixo do que seus próprios dados mostravam.

## 7. Preço alvo e uplift: de volta ao cliente

O **preço alvo** é a tarifa que o modelo considera adequada para o cluster do cliente, com uma trava: **alvo = máximo entre a tarifa praticada e o P75 do cluster** (`01:L112`). É a política "nunca reduzir": o modelo nunca propõe baixar a tarifa de ninguém; quem já paga acima do P75 fica onde está.

Grupo Alfa: paga R$ 1,50; P75 do cluster 5 é R$ 2,10; alvo = R$ 2,10.

O **uplift** é a receita adicional anual se o cliente passasse a pagar o alvo (`01:L114-116`). Para tarifas abaixo de R$ 1.000, é a diferença de tarifa vezes a quantidade anual. Para tarifas altas (acima de R$ 1.000, típicas de eventos de valor), usa-se a variação percentual sobre o valor tarifado, para não distorcer.

Grupo Alfa: (2,10 − 1,50) × 60.000 = R$ 36.000 por ano.

Se N do cluster fosse menor que 15, o alvo seria a própria tarifa e o uplift zero: o cliente não entra na reprecificação por falta de referência confiável.

Somando o uplift de todos os clientes e produtos, o notebook de consolidação obtém o potencial total da onda (`05:L39`). É o número que sustenta o business case.

## 8. Preço sugerido e cenários: o que a Calculadora mostra

O alvo é a referência estatística. O **preço sugerido** é o que o banco de fato recomenda ao gerente para o cenário do cliente, e ele já vem pronto na Planilha Ano 1 (aba "Preço por Produto", `07:L30`; tabela `SIMUL_PRECO_POR_PRODUTO`, `07:L112`). Entre o alvo e o sugerido entram as premissas comerciais: desconto por relacionamento (saldo em Invest Fácil e DAV, passo 3 da metodologia, `06:L137`), custos, preços de RFP, tratamento de nichos. Como essas premissas se combinam está na macro da planilha e no Motor da Calculadora, e não foi documentado (lacuna 1). É o principal item de engenharia reversa do projeto.

Um **cenário** é uma linha da tabela de preços: produto x tier x segmento x região, com o cluster resultante, os percentis, o alvo e o sugerido. São até 1.620 combinações (18 produtos x 3 tiers x 6 segmentos x 5 regiões, `05:L25`). Quando o gerente simula uma volumetria diferente, o cliente cai em outro tier, portanto em outro cenário, e vê outros preços. É isso que a Calculadora faz: posiciona o cliente no cenário e mostra praticado, alvo, sugerido e os cenários vizinhos.

Se o gerente negociar abaixo do sugerido, entra a **alçada** (`00-neg:L22`): o desvio define quem precisa aprovar. No sugerido ou acima, contrata sem aprovação.

## 9. Stickiness e impacto: quem reprecificar primeiro e com que força

Aumentar tarifa tem risco de perder o cliente. O passo 4 da metodologia classifica cada grupo econômico em dois eixos (`06-matriz-stickiness-impacto-fluxo.md`) para calibrar a intensidade do reajuste:

**Stickiness** mede o quanto o cliente depende do banco, pela participação do Bradesco no cash dele (share de cash, `06:L32`) e no crédito dele (share de crédito, com um piso de materialidade por segmento para o crédito contar, `06:L73`). Cada share vira um score de 1 a 4 nas faixas 0,1 / 0,4 / 0,7 (`06:L67-82`), e o stickiness é o maior dos dois: Baixo, Médio Baixo, Médio Alto, Alto. Cliente com share alto tem menos alternativa e aceita reajuste com menos risco.

**Impacto** mede o quanto o cliente vale para o banco, pelo resultado operacional bruto (ROB) dos últimos 6 meses e pela receita de cash, com faixas em reais por segmento (`06:L99-113`). Score de 1 a 3, o maior dos dois: Baixo, Médio, Alto.

A matriz cruza os dois. A intuição: cliente de alto impacto e baixo stickiness pede reajuste gradual e cuidadoso; cliente de baixo impacto e alto stickiness pode ir direto ao alvo. Como a matriz se traduz em percentual ou etapas de reajuste não está documentado (`06:L138`, texto truncado). É uma regra a definir para a Onda de Reprecificação (C2).

## 10. Reciprocidade: o combinado está sendo cumprido

Na negociação, o gerente dá um preço melhor esperando volume, saldo ou outros produtos em troca. **Reciprocidade** é acompanhar se isso aconteceu. O modelo já calcula os indicadores por grupo econômico (`06:L44-56`, `07:L24`): saldo médio em Invest Fácil e DAV, share of wallet de boletos (quantos boletos o cliente emite no Bradesco contra o total dele), emissões dos últimos 3 meses.

O que ainda não existe é o outro lado da comparação: o registro do que foi acordado. Sem ele, os indicadores mostram o realizado, mas não o desvio. É por isso que a Gestão de Reciprocidade (C3) é uma capacidade a detalhar: precisa definir o que é o acordo, onde fica e qual tolerância dispara a reprecificação.

## 11. Como tudo chega à Planilha Ano 1 e à Calculadora

O ciclo mensal (`07-planilha-ano1-fluxo.md`) é uma linha de montagem:

1. Extração das bases do Databricks para arquivos.
2. Sete notebooks em sequência: cinco de produto (calculam tarifa praticada, tier, cluster, percentis, alvo e uplift por cliente), um de consolidação (junta os produtos e monta a tabela de cenários) e um de relacionamento (stickiness, impacto, saldos, share of wallet).
3. Cópia manual das saídas para abas da planilha, mais abas manuais de premissas e exceções.
4. Macro que gera o preço por produto e o resumo por grupo econômico.
5. Duas saídas: a equipe de Precificação decide reprecificações à mão, e as abas vão por SAS para o servidor SQL 010, de onde a Calculadora Salesforce lê.

No TO-BE, esse conjunto publicado por ciclo é a BRP Cash: a Matriz de Cenários de Preço (a tabela de preços com alvo e sugerido), a Posição de Preço por cliente (a Base Pricing), a Matriz de Relacionamento e os Indicadores de Reciprocidade, versionados por mês de referência.

## 12. Glossário de bolso

| Termo | Em uma frase |
|---|---|
| Evento tarifado | Cada ocorrência cobrável de um produto (registro de boleto, baixa, TED, PIX, guia). |
| Tarifa praticada | O que o cliente paga hoje por evento, medido nos últimos 12 meses. |
| Tier | Faixa de volume mensal do cliente no produto (1 maior, 3 menor). |
| Cluster | Grupo de clientes comparáveis em um produto, decidido por tier, depois segmento, depois região (árvore, não produto cartesiano); códigos 1 a 10. |
| Clusters corporate | Clusters 5 a 9 (Corporate no tier 3 por região); servem de teto de referência. |
| Percentil (P25 a P90) | Distribuição da tarifa praticada dentro do cluster; P75 é a referência de preço. |
| N | Número de grupos econômicos no cluster; abaixo de 15 não há reprecificação. |
| Referência corporate | P25/P75 dos clusters corporate ponderados por volume, usado como teto. |
| cummin | Ajuste que garante que a referência nunca suba do cluster mais fraco para o mais forte. |
| Preço alvo | max(tarifa praticada, P75 do cluster); nunca reduz. |
| Uplift | Receita anual adicional se o cliente for ao alvo. |
| Preço sugerido | Preço recomendado do cenário, já com premissas comerciais; piso da negociação sem alçada. |
| Cenário | Linha da tabela de preços: produto x tier x segmento x região com cluster, percentis, alvo e sugerido. |
| Alçada | Nível de aprovação exigido quando o preço negociado fica abaixo do sugerido. |
| Stickiness | Dependência do cliente em relação ao banco (share de cash e de crédito). |
| Impacto | Relevância financeira do cliente (ROB e receita de cash). |
| Reciprocidade | Cumprimento do volume, saldo e produtos combinados na negociação. |
| Ciclo de precificação | Rodada mensal que gera a BRP; identificado pelo mês de referência (anomes). |
| Onda de reprecificação | Campanha de reajuste sobre um conjunto de clientes elegíveis, usando a BRP de um ciclo. |
