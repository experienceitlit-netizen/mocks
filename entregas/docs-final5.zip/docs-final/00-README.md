# Motor de Precificação Cash — Documentação de Arquitetura

Versão 1.0 · 2026-09-18 · Status: rascunho para validação
Gerado a partir da análise dos documentos de negócio em `docs-precificacao/` (fluxos 00 a 07) e da stack em `stack-tech.md`.

## Como ler

| # | Documento | Público | Responde |
|---|---|---|---|
| 01 | [Contexto de negócio — introdutório](01-contexto-negocio-introdutorio.md) | Quem nunca trabalhou com precificação de cash | O que é o negócio, quem são os atores, como funciona hoje, glossário, FAQ |
| 02 | [Contexto de negócio — especialista](02-contexto-negocio-especialista.md) | Precificação / Produtos | Estratégia embutida no modelo, cadeia de valor, capacidades, oportunidades, decisões pendentes, KPIs |
| 03 | [Desenho conceitual](03-desenho-conceitual.md) | Negócio + TI | Camadas de negócio e capacidades (C1 prioritária; C2 e C3 evoluções), parametrização, legado, dados |
| 04 | [Capacidades e rastreabilidade](04-capacidades-rastreabilidade.md) | Negócio + TI | Descrição de cada capacidade e onde foi identificada nos documentos fonte |
| 05 | [Domínios, bounded contexts e context mapping](05-dominios-bounded-contexts-context-mapping.md) | Arquitetura / Engenharia | Linguagem ubíqua, subdomínios, agregados, eventos, context map |
| 06 | [Arquitetura de solução](06-arquitetura-solucao.md) | Arquitetura / Engenharia | AS-IS, TO-BE (contexto e contêineres), arquitetura por capacidade, dados, APIs, RNFs, transição |
| 07 | [Componentes: definição e justificativa](07-componentes-definicao-justificativa.md) | Arquitetura / Comitê | Ficha de cada componente, alternativas, requisitos atendidos, fase |
| 07b | [Arquitetura de solução em ArchiMate](arquitetura-solucao-archmate.md) | Arquitetura / Comitê | Arquitetura de solução em notação ArchiMate: viewpoints de camadas, negócio, aplicação, tecnologia, migração |
| 08 | [Especificações técnicas](08-especificacoes-tecnicas.md) | Tech leads | Especificações por épico (SPEC-xxx) para posterior criação de tasks |
| 09 | [Roadmap de implementação](09-roadmap-implementacao.md) | Comitê / PMO | Fases F0-F5, marcos, transição, desligamento do legado, riscos |
| 10 | [Apresentação executiva (pptx)](10-apresentacao-executiva.pptx) | Executivos | Onepage, desenho conceitual, arquitetura macro, riscos, roadmap |
| 11 | [ADR AD-15: regras em motor de decisão único (alternativa)](11-adr-15-regras-em-motor-de-decisao-runtime.md) | Arquitetura / Comitê | Alternativa proposta em 2026-09-21: estatística no Databricks, regras por cliente num único motor de decisão (FICO ou Java/DMN) executado online e em lote, ciclo em duas passadas; ganhos, perdas, impacto em AD-01/AD-04 |
| 12 | [Catálogo de regras parametrizáveis](12-catalogo-regras-parametrizaveis.md) | Precificação / Engenharia | 45 regras dos fluxos expressas como tabelas de decisão (RP-01 a RP-45): formato, uso (pipeline / online), valores conhecidos, fonte e maturidade; base da carga inicial da Parametrização |
| 13 | [Guia conceitual do modelo](13-guia-conceitual-modelo-precificacao.md) | Estudo / onboarding | Como cada conceito nasce e se encaixa: tarifa praticada, tier, cluster, percentis, N, referência corporate, cummin, alvo, uplift, sugerido e cenários, stickiness x impacto, reciprocidade; exemplo numérico ilustrativo ponta a ponta |

## Anexos (`anexos/`)

| Arquivo | Conteúdo |
|---|---|
| `A0-brief-decisoes.md` | Fonte única de nomes, definições de preço, capacidades, bounded contexts, decisões de arquitetura (AD-01..14), requisitos (RF/RNF), lacunas, fases e riscos. Todos os documentos derivam dele. |
| `A1-analise-fluxos-produtos.md` | Análise detalhada dos fluxos de Cobrança, Multipag, PIX e Arrecadação, com referência de linha aos docs fonte. |
| `A2-analise-fluxos-consolidacao.md` | Análise dos fluxos Uplift Consolidado, Stickiness x Impacto e Planilha Ano 1 / Calculadora Salesforce, com pipeline end-to-end e entidades da base final. |
| `A3-relatorio-revisao.md` | Relatório da revisão de consistência dos documentos 00-09: verificações, correções por documento e divergências substantivas pendentes de decisão. |
| `bradesco_style.py`, `build_deck.py` | Biblioteca de estilo e script que gera a apresentação (python-pptx). |

## Nomes canônicos (resumo)

- **Motor de Precificação Cash (MPC)**: a solução. A Calculadora Salesforce passa a ser um canal do motor.
- **Base de Referência de Preços Cash (BRP Cash)**: nome proposto para a base final hoje chamada "Planilha Ano 1", versionada por ciclo (`anomes`).
- **C1** Cálculo, Simulação e Entrega de Preços (prioritária, funciona hoje) · **C2** Onda de Reprecificação (evolução) · **C3** Gestão de Reciprocidade (evolução) · **M1** Parametrização · **M2** Preparação de Dados · **M3** Legado e Base Histórica · **M4** Governança, Auditoria e Segurança.

## Premissas desta documentação

- Os documentos fonte descrevem os passos 1 e 2 da metodologia (clusterização e preço-alvo); os passos 3 e 4 (relacionamento e reajuste gradual) e as regras da macro / Motor da Calculadora (SQL 010) não estão documentados. Onde foi necessário, definições de trabalho estão marcadas como "(inferido)" ou "a validar com o negócio".
- Revisão 1.1: o preço sugerido é lido da BRP Cash por cenário; o motor online não o calcula.
- O estilo visual Bradesco da apresentação foi reproduzido a partir da identidade pública (vermelho #CC092F, cinzas, Arial). Ajustar ao template oficial se disponível.
- A pasta `fotos/` não foi lida, conforme instrução.
- 2026-09-21: o doc 11 (AD-15) registra uma alternativa em avaliação que, se aprovada, reescopa AD-01, AD-04 e AD-06; os demais documentos ainda refletem a arquitetura vigente.
