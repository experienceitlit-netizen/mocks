# Arquitetura de Solução — notação ArchiMate: Motor de Precificação Cash (MPC)

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Relação com o doc 06 | Este documento é a **expressão em ArchiMate 3.2** da mesma arquitetura descrita em `06-arquitetura-solucao.md` (notação C4). Contêineres, APIs, modelo de dados, fluxos e decisões AD-01..AD-14 são os mesmos; aqui eles aparecem como elementos e relações ArchiMate organizados por viewpoint. Em caso de divergência de semântica do preço sugerido, prevalece `anexos/A0-brief-decisoes.md` §2. |
| Fontes | `anexos/A0-brief-decisoes.md` (nomes §1, preços §2, capacidades §3, camadas §4, BCs §5, decisões §6, requisitos §7, lacunas §8, fases §9, riscos §10); `06-arquitetura-solucao.md`; `03-desenho-conceitual.md`; `05-dominios-bounded-contexts-context-mapping.md`; `07-componentes-definicao-justificativa.md`; `09-roadmap-implementacao.md`; `stack-tech.md`; `docs-precificacao/00-doc-negocio.md` |
| Documentos relacionados | 03 Desenho conceitual; 04 Capacidades; 05 Bounded contexts; 06 Arquitetura de solução (C4); 07 Componentes; 08 Especificações técnicas; 09 Roadmap |

Convenção: C2 (Onda de Reprecificação) e C3 (Gestão de Reciprocidade) são **[EVOLUÇÃO — a detalhar com o negócio]** e aparecem tracejados em cinza. Toda decisão cita seu ID (AD-xx) e os requisitos atendidos (RF-xx / RNF-xx). Referências no formato `docs-precificacao/<arquivo>:L<linha>`; "lacuna n" refere-se ao brief §8; "marco Mn" refere-se aos marcos do doc 09 (não confundir com os módulos M1-M4 do brief §3).

---

## 1. Introdução, convenções e legenda ArchiMate

**Objetivo.** Oferecer uma visão da solução na linguagem que a arquitetura corporativa usa para repositório e governança (ArchiMate 3.2), cobrindo as camadas de Motivação, Estratégia, Negócio, Aplicação, Tecnologia e Implementação/Migração. O doc 06 responde "como os contêineres se conectam"; este documento responde "por que existem, que capacidade realizam, que processo servem, onde rodam e em que plateau entram".

**Ponto de atenção semântico.** O preço **sugerido não é calculado pelo motor online**. Ele é pré-calculado pelo Pipeline de Preparação de Preços (`dbx-ppp`) e publicado na BRP Cash por **cenário** (produto x região x segmento x tier). O `svc-pricing` classifica o cliente (tier, cluster), consulta o cenário correspondente, compõe a resposta (praticado, alvo, sugerido, cenários vizinhos, uplift) e aciona a alçada. Isso está refletido nas funções de aplicação da §5 e nos objetos de dados da §7 (brief §2).

**Como ler os diagramas.** ArchiMate não tem renderizador nativo em Markdown. Os diagramas usam Mermaid `flowchart` emulando a notação:

| Camada ArchiMate | Cor de preenchimento | Elementos usados neste documento |
|---|---|---|
| Motivation | `#CCCCFF` (lilás) | «Stakeholder», «Driver», «Goal», «Principle», «Requirement», «Constraint», «Assessment» |
| Strategy | `#F5DEAA` (bege) | «Capability», «Course of Action», «Resource», «Value Stream» |
| Business | `#FFFFB5` (amarelo) | «Business Actor», «Business Role», «Business Process», «Business Event», «Business Object», «Business Service» |
| Application | `#B5FFFF` (ciano) | «Application Component», «Application Function», «Application Service», «Application Interface», «Application Event», «Data Object» |
| Technology | `#C9E7B7` (verde) | «Node», «Device», «System Software», «Technology Service», «Artifact», «Communication Network» |
| Implementation & Migration | `#FFE0E0` (rosa) | «Work Package», «Deliverable», «Implementation Event», «Plateau», «Gap» |
| Evolução (C2/C3, a desligar) | cinza `#EEEEEE`, borda tracejada | qualquer elemento marcado [EVOLUÇÃO] ou [A DESLIGAR] |

| Relação ArchiMate | Representação Mermaid | Significado |
|---|---|---|
| Composition / Aggregation | `subgraph` contendo os elementos | parte-de / agrupa |
| Assignment | seta sólida `-- assignment -->` | quem executa / onde roda |
| Serving | seta sólida `-- serving -->` | fornece serviço a |
| Triggering | seta sólida `-- triggering -->` | dispara |
| Flow | seta sólida `-- flow -->` (com o nome do que flui) | transfere informação/valor |
| Realization | seta pontilhada `-. realization .->` | realiza / concretiza |
| Access | seta pontilhada `-. access .->` | lê/escreve objeto de dados |
| Influence | seta pontilhada `-. influence .->` | influencia (motivação) |
| Association | linha sem rótulo | relação genérica |

```mermaid
flowchart LR
  classDef strategy fill:#F5DEAA,stroke:#8a6d1f,color:#000
  classDef business fill:#FFFFB5,stroke:#8a8a1f,color:#000
  classDef application fill:#B5FFFF,stroke:#1f7a8a,color:#000
  classDef technology fill:#C9E7B7,stroke:#3f7a2a,color:#000
  classDef motivation fill:#CCCCFF,stroke:#4a4a9a,color:#000
  classDef impl fill:#FFE0E0,stroke:#9a4a4a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  L_MOT["«Goal» Motivation"]
  L_STR["«Capability» Strategy"]
  L_BUS["«Business Process» Business"]
  L_APP["«Application Component» Application"]
  L_TEC["«Node» Technology"]
  L_IMP["«Work Package» Implementation"]
  L_EVO["«Capability» C2 [EVOLUÇÃO]"]
  L_STR -. realization .-> L_MOT
  L_BUS -. realization .-> L_STR
  L_APP -- serving --> L_BUS
  L_TEC -. realization .-> L_APP
  L_IMP -- triggering --> L_EVO
  class L_MOT motivation
  class L_STR strategy
  class L_BUS business
  class L_APP application
  class L_TEC technology
  class L_IMP impl
  class L_EVO evol
```

Cada viewpoint traz: objetivo, diagrama, tabela de elementos (nome, tipo ArchiMate, descrição, rastreio para capacidade / bounded context / componente canônico) e tabela de relações (origem, relação, destino, significado).

---

## 2. Motivation Viewpoint

**Objetivo.** Registrar quem se importa com o motor, por quê, o que se quer alcançar, que princípios governam o desenho e que requisitos e restrições o limitam. É a base para as decisões AD-01..AD-14 (brief §6) e para o roadmap.

```mermaid
flowchart TB
  classDef motivation fill:#CCCCFF,stroke:#4a4a9a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph STK["Stakeholders"]
    SK1["«Stakeholder» Precificação"]
    SK2["«Stakeholder» Comercial / Gerente de cash"]
    SK3["«Stakeholder» Produtos"]
    SK4["«Stakeholder» OPCH"]
    SK5["«Stakeholder» TI (arquitetura, engenharia)"]
    SK6["«Stakeholder» Dados"]
    SK7["«Stakeholder» Auditoria / Compliance"]
  end
  subgraph DRV["Drivers"]
    D1["«Driver» Monetização de payments no Atacado"]
    D2["«Driver» Dispersão de preço entre clientes similares"]
    D3["«Driver» Ciclo manual sem rastreabilidade"]
    D4["«Driver» Retenção e reciprocidade"]
  end
  subgraph GOL["Goals"]
    G1["«Goal» G1 Uplift de tarifas com política nunca reduzir"]
    G2["«Goal» G2 Preço padronizado por cluster"]
    G3["«Goal» G3 Autonomia comercial com alçada controlada"]
    G4["«Goal» G4 Reter clientes e garantir reciprocidade [EVOLUÇÃO]"]
    G5["«Goal» G5 Governança e auditoria de parâmetros e preços"]
  end
  subgraph PRI["Principles"]
    P1["«Principle» P1 Salesforce é canal, não motor"]
    P2["«Principle» P2 Regras como parâmetros versionados"]
    P3["«Principle» P3 BRP Cash versionada por ciclo"]
    P4["«Principle» P4 Legado atrás de camada anticorrupção"]
    P5["«Principle» P5 Sugerido vem da BRP, motor só consulta"]
  end
  subgraph REQ["Requirements e constraints"]
    R1["«Requirement» RF-01 Praticado, alvo e sugerido por cliente x produto"]
    R2["«Requirement» RF-02 Simular sem efetivar; expor cenários"]
    R3["«Requirement» RF-03 Alçada e aprovador abaixo do sugerido"]
    R4["«Requirement» RF-04 Preço vigente e histórico 12 meses"]
    R5["«Requirement» RF-05 e RF-06 Parametrizar com versão e staging"]
    R6["«Requirement» RF-07 APIs para canais e integradores"]
    R7["«Requirement» RF-09 Auditoria completa de execuções"]
    R8["«Requirement» RF-13 BRP Cash versionada por ciclo"]
    N1["«Requirement» RNF-02 p95 até 500 ms no gateway (a validar)"]
    N2["«Requirement» RNF-03 e RNF-09 Rastreabilidade e reprodutibilidade"]
    N3["«Requirement» RNF-01 (SLO 99,9%) e RNF-08 Contingência e implantação gradual"]
    K1["«Constraint» RNF-10 Stack corporativa (Salesforce, Azure, Java, Databricks, ARO, Axway)"]
    K2["«Constraint» Service Bus fora da stack — validar (lacuna 9)"]
    A1["«Assessment» Lacuna 1: regra do sugerido não documentada (R1)"]
  end
  SK1 --- D2
  SK1 --- D3
  SK2 --- D1
  SK3 --- D1
  SK4 --- D3
  SK5 --- D3
  SK6 --- D3
  SK7 --- D3
  SK2 --- D4
  D1 -. influence .-> G1
  D2 -. influence .-> G2
  D1 -. influence .-> G3
  D4 -. influence .-> G4
  D3 -. influence .-> G5
  G1 -. realization .-> R1
  G2 -. realization .-> R8
  G3 -. realization .-> R2
  G3 -. realization .-> R3
  G5 -. realization .-> R5
  G5 -. realization .-> R7
  G5 -. realization .-> N2
  P1 -. influence .-> R6
  P2 -. influence .-> R5
  P3 -. influence .-> R8
  P4 -. influence .-> R4
  P5 -. influence .-> R1
  K1 -. influence .-> P1
  K2 -. influence .-> N3
  A1 -. influence .-> R1
  class SK1,SK2,SK3,SK4,SK5,SK6,SK7,D1,D2,D3,D4,G1,G2,G3,G5,P1,P2,P3,P4,P5,R1,R2,R3,R4,R5,R6,R7,R8,N1,N2,N3,K1,K2,A1 motivation
  class G4 evol
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| Precificação | Stakeholder | Dona das regras, parâmetros, políticas e da publicação de ciclos | M1, M2; BC Parametrização, Publicação de Referência |
| Comercial / Gerente de cash | Stakeholder | Usuário da Calculadora; negocia e contrata | C1; sf-calculadora |
| Produtos | Stakeholder | Dono do catálogo de produtos e macroprodutos | M1 |
| OPCH | Stakeholder | Operação e processos; desligamento da cadeia SAS/SQL 010 | M3 |
| TI (arquitetura, engenharia) | Stakeholder | Aderência à stack, construção, operação | RNF-10 |
| Dados | Stakeholder | Governança das bases no Databricks e do pipeline | M2; RNF-06 |
| Auditoria / Compliance | Stakeholder | Exige trilha imutável de preços e parâmetros | M4; RNF-03 |
| Monetização de payments no Atacado | Driver | Business case de Pricing Cash (`00-doc-negocio.md:L1-3`) | G1 |
| Dispersão de preço entre clientes similares | Driver | Clientes do mesmo cluster pagam tarifas distintas | G2 |
| Ciclo manual sem rastreabilidade | Driver | Planilha, macro, SAS e SQL 010 sem versão nem log (doc 06 §2, D1-D7) | G5 |
| Retenção e reciprocidade | Driver | Stickiness x Impacto e acordos de reciprocidade | G4 (evolução) |
| G1..G5 | Goal | Objetivos da camada Estratégia do brief §4 | Todas as capacidades |
| P1..P5 | Principle | Princípios do doc 06 §1 mais o princípio P5 do brief §2 | AD-05, AD-04/06, AD-01/03, AD-10, brief §2 |
| RF-xx / RNF-xx | Requirement | Seleção dos principais do brief §7 | Ver §11 |
| RNF-10 Stack corporativa | Constraint | `stack-tech.md`: Salesforce FSC, Azure, Java, Python para dados, Databricks, ARO, Axway, App Gateway, Akamai | AD-01..AD-14 |
| Service Bus a validar | Constraint | Não consta da stack; fallback outbox (AD-09) | Lacuna 9, risco R5 |
| Lacuna 1 | Assessment | A regra que gera o sugerido por cenário vive na macro e no SQL 010; pertence ao pipeline (M2) e à parametrização (M1) no TO-BE | Risco R1; F0 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Stakeholder | association | Driver | O stakeholder é sensível ao driver |
| Driver | influence | Goal | O driver motiva o objetivo |
| Goal | realization | Requirement | O requisito concretiza o objetivo |
| Principle | influence | Requirement | O princípio orienta como o requisito é atendido |
| Constraint | influence | Principle / Requirement | A restrição limita as escolhas |
| Assessment | influence | Requirement RF-01 | A lacuna condiciona a entrega do sugerido no MVP |

---

## 3. Strategy Viewpoint

**Objetivo.** Ligar objetivos a capacidades, aos cursos de ação escolhidos e aos recursos que os viabilizam. As capacidades usam exatamente os IDs do brief §3.

```mermaid
flowchart TB
  classDef strategy fill:#F5DEAA,stroke:#8a6d1f,color:#000
  classDef motivation fill:#CCCCFF,stroke:#4a4a9a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  G1["«Goal» G1 Uplift com política nunca reduzir"]
  G3["«Goal» G3 Autonomia comercial com alçada"]
  G5["«Goal» G5 Governança e auditoria"]
  VS["«Value Stream» Preparar referência → Simular → Negociar → Contratar → Monitorar reciprocidade → Reprecificar"]
  subgraph CAP["Capacidades de negócio"]
    C1["«Capability» C1 Cálculo, Simulação e Entrega de Preços (C1.1 a C1.6)"]
    C2["«Capability» C2 Onda de Reprecificação [EVOLUÇÃO]"]
    C3["«Capability» C3 Gestão de Reciprocidade [EVOLUÇÃO]"]
  end
  subgraph MOD["Módulos transversais"]
    M1["«Capability» M1 Parametrização"]
    M2["«Capability» M2 Preparação de Dados (PPP → BRP Cash)"]
    M3["«Capability» M3 Legado e Base Histórica"]
    M4["«Capability» M4 Governança, Auditoria e Segurança"]
  end
  subgraph COA["Cursos de ação"]
    A1["«Course of Action» CoA-1 Motor em paralelo ao legado (shadow, AD-14)"]
    A2["«Course of Action» CoA-2 Parametrização desde o início (AD-06)"]
    A3["«Course of Action» CoA-3 Sugerido pré-calculado no pipeline, motor consulta (brief §2)"]
    A4["«Course of Action» CoA-4 C2 e C3 após discovery (F3), preparados por eventos"]
  end
  subgraph RES["Recursos"]
    RS1["«Resource» BRP Cash (versionada por ciclo)"]
    RS2["«Resource» Plataforma Databricks e bases governadas"]
    RS3["«Resource» Salesforce FSC (canal)"]
    RS4["«Resource» Time de Precificação (conhecimento das regras)"]
  end
  C1 -. realization .-> G1
  C1 -. realization .-> G3
  M1 -. realization .-> G5
  M4 -. realization .-> G5
  C2 -. realization .-> G1
  C3 -. realization .-> G1
  VS -. realization .-> G1
  C1 -- serving --> VS
  M2 -- serving --> C1
  M1 -- serving --> C1
  M3 -- serving --> C1
  M4 -- serving --> C1
  C1 -- serving --> C2
  C3 -- serving --> C2
  M1 -- serving --> C2
  M1 -- serving --> C3
  M2 -- serving --> C3
  A1 -. realization .-> C1
  A2 -. realization .-> M1
  A3 -. realization .-> C1
  A3 -. realization .-> M2
  A4 -. realization .-> C2
  A4 -. realization .-> C3
  RS1 -- assignment --> M2
  RS1 -- assignment --> C1
  RS2 -- assignment --> M2
  RS3 -- assignment --> C1
  RS4 -- assignment --> M1
  class G1,G3,G5 motivation
  class VS,C1,M1,M2,M3,M4,A1,A2,A3,RS1,RS2,RS3,RS4 strategy
  class C2,C3,A4 evol
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| Preparar referência → ... → Reprecificar | Value Stream | Cadeia de valor do preço: a BRP é preparada por ciclo, o gerente simula e negocia, contrata (com ou sem alçada), a reciprocidade é monitorada e, se houver desvio, o cliente entra numa onda | C1, C3, C2 |
| C1 Cálculo, Simulação e Entrega de Preços | Capability | Prioritária; sub-capacidades C1.1 consulta de preços, C1.2 simulação e cenários, C1.3 alçada, C1.4 vigente/histórico, C1.5 APIs, C1.6 rastreabilidade | BC Cálculo de Preço, Alçada; svc-pricing, svc-alcada, svc-legado-adapter |
| C2 Onda de Reprecificação [EVOLUÇÃO] | Capability | Planejamento, elegíveis, cálculo em lote, aprovação, efetivação, acompanhamento (C2.1-C2.5) | BC Reprecificação; svc-reprecificacao; F4 |
| C3 Gestão de Reciprocidade [EVOLUÇÃO] | Capability | Acordo, monitoramento, desvio, elegibilidade (C3.1-C3.4); capacidade própria, não sub-capacidade de C2 (brief §3) | BC Reciprocidade; svc-reciprocidade; F3 |
| M1 Parametrização | Capability | Catálogo, domínios, tiers, cluster, percentis, premissas, exceções, versionamento, staging, vigência | BC Parametrização; svc-parametros, sf-parametrizacao |
| M2 Preparação de Dados | Capability | Pipeline dos 7 notebooks no Databricks gerando a BRP Cash por `anomes`; é onde o sugerido por cenário nasce | BC Modelagem de Preço, Publicação de Referência; dbx-ppp, dbx-brp, svc-publicacao |
| M3 Legado e Base Histórica | Capability | Preço vigente, histórico 12 meses, contratos, cadastro; desligamento de SAS/SQL 010/Planilha | BC Preço Vigente e Histórico; svc-legado-adapter |
| M4 Governança, Auditoria e Segurança | Capability | Auditoria append-only, perfis, monitoramento, contingência | BC Identidade e Acesso, Auditoria e Observabilidade |
| CoA-1 Motor em paralelo ao legado | Course of Action | Shadow run com comparador e corte por produto (AD-14; RNF-08) | F1-F2 |
| CoA-2 Parametrização desde o início | Course of Action | M1 entra na F1 com versionamento básico, telas completas na F2 (AD-06) | F1-F2 |
| CoA-3 Sugerido pré-calculado no pipeline | Course of Action | O motor online não deriva o sugerido; engenharia reversa da macro/SQL 010 na F0 alimenta o pipeline e os parâmetros | Brief §2; risco R1 |
| CoA-4 C2 e C3 após discovery | Course of Action | Discovery na F3; arquitetura preparada por eventos e reuso do motor (AD-07, AD-08, AD-09) | F3-F4; risco R2 |
| BRP Cash | Resource | Base de Referência de Preços Cash, versionada por Ciclo de Precificação | dbx-brp, sql-motor |
| Plataforma Databricks e bases governadas | Resource | Bases de origem já ingeridas (premissa `00-doc-negocio.md:L27`) | AD-01 |
| Salesforce FSC | Resource | Canal corporativo do comercial | AD-05 |
| Time de Precificação | Resource | Detém o conhecimento das regras não documentadas | Lacunas 1-3 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Capability | realization | Goal | A capacidade concretiza o objetivo |
| M1, M2, M3, M4 | serving | C1 | Os módulos transversais são pré-requisito de C1 desde a F1 |
| C1, C3, M1 | serving | C2 | A onda reusa o motor, consome elegibilidade de C3 e parâmetros de M1 |
| Course of Action | realization | Capability | O curso de ação é o caminho escolhido para entregar a capacidade |
| Resource | assignment | Capability | O recurso é alocado à capacidade |

---

## 4. Business Layer Viewpoint (Business Process Cooperation)

**Objetivo.** Mostrar atores, papéis, processos, eventos e objetos de negócio do ciclo de precificação, independentemente de tecnologia. Os processos derivam da jornada do doc 03 §4.3 e dos fluxos do doc 06 §5.

```mermaid
flowchart TB
  classDef business fill:#FFFFB5,stroke:#8a8a1f,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph ATORES["Atores e papéis"]
    AC1["«Business Actor» Gerente comercial de cash"]
    AC2["«Business Actor» Time de Precificação"]
    AC3["«Business Actor» Diretoria / Gerência regional"]
    AC4["«Business Actor» Cliente / Grupo econômico"]
    RL1["«Business Role» Gerente de cash"]
    RL2["«Business Role» Parametrizador"]
    RL3["«Business Role» Analista de Precificação (publica ciclo)"]
    RL4["«Business Role» Aprovador de alçada"]
    RL5["«Business Role» Contratante"]
  end
  subgraph EVT["Eventos de negócio"]
    E1["«Business Event» Negociação iniciada"]
    E2["«Business Event» Preço negociado abaixo do sugerido"]
    E3["«Business Event» Pedido decidido (aprovado ou recusado)"]
    E4["«Business Event» Ciclo de precificação fechado (anomes)"]
    E5["«Business Event» Nova versão de parâmetros necessária"]
    E6["«Business Event» Desvio de reciprocidade detectado [EVOLUÇÃO]"]
  end
  subgraph PROC["Processos de negócio"]
    PR1["«Business Process» Simular preço"]
    PR2["«Business Process» Contratar sem alçada"]
    PR3["«Business Process» Solicitar aprovação de alçada"]
    PR4["«Business Process» Decidir aprovação"]
    PR5["«Business Process» Publicar versão de parâmetros"]
    PR6["«Business Process» Publicar ciclo da BRP Cash"]
    PR7["«Business Process» Monitorar reciprocidade [EVOLUÇÃO]"]
    PR8["«Business Process» Executar onda de reprecificação [EVOLUÇÃO]"]
  end
  subgraph OBJ["Objetos de negócio"]
    BO1["«Business Object» Cotação"]
    BO2["«Business Object» Cenário de preço (praticado, alvo, sugerido, percentis)"]
    BO3["«Business Object» Pedido de aprovação"]
    BO4["«Business Object» Versão de parâmetros"]
    BO5["«Business Object» Ciclo de precificação (BRP Cash anomes)"]
    BO6["«Business Object» Acordo de reciprocidade [EVOLUÇÃO]"]
    BO7["«Business Object» Onda de reprecificação [EVOLUÇÃO]"]
  end
  subgraph BSV["Serviços de negócio"]
    BS1["«Business Service» Precificação para o comercial"]
    BS2["«Business Service» Aprovação de alçada"]
    BS3["«Business Service» Governança de parâmetros"]
    BS4["«Business Service» Publicação de referência de preços"]
  end
  AC1 -- assignment --> RL1
  AC1 -- assignment --> RL5
  AC2 -- assignment --> RL2
  AC2 -- assignment --> RL3
  AC3 -- assignment --> RL4
  AC4 --- E1
  RL1 -- assignment --> PR1
  RL5 -- assignment --> PR2
  RL1 -- assignment --> PR3
  RL4 -- assignment --> PR4
  RL2 -- assignment --> PR5
  RL3 -- assignment --> PR6
  RL2 -- assignment --> PR8
  E1 -- triggering --> PR1
  PR1 -- triggering --> E2
  E2 -- triggering --> PR3
  PR1 -- triggering --> PR2
  PR3 -- triggering --> PR4
  PR4 -- triggering --> E3
  E3 -- triggering --> PR2
  E4 -- triggering --> PR6
  E5 -- triggering --> PR5
  PR7 -- triggering --> E6
  E6 -- triggering --> PR8
  PR8 -- triggering --> PR4
  PR1 -. access .-> BO1
  PR1 -. access .-> BO2
  PR3 -. access .-> BO3
  PR5 -. access .-> BO4
  PR6 -. access .-> BO5
  PR2 -. access .-> BO6
  PR7 -. access .-> BO6
  PR8 -. access .-> BO7
  PR1 -. realization .-> BS1
  PR2 -. realization .-> BS1
  PR4 -. realization .-> BS2
  PR5 -. realization .-> BS3
  PR6 -. realization .-> BS4
  BS4 -- serving --> PR1
  BS3 -- serving --> PR1
  class AC1,AC2,AC3,AC4,RL1,RL2,RL3,RL4,RL5,E1,E2,E3,E4,E5,PR1,PR2,PR3,PR4,PR5,PR6,BO1,BO2,BO3,BO4,BO5,BS1,BS2,BS3,BS4 business
  class E6,PR7,PR8,BO6,BO7 evol
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| Gerente comercial de cash | Business Actor | Negocia com o cliente; usa a Calculadora | C1; sf-calculadora |
| Time de Precificação | Business Actor | Mantém parâmetros, valida e publica ciclos, planeja ondas | M1, M2, C2 |
| Diretoria / Gerência regional | Business Actor | Aprova preços abaixo do sugerido conforme nível | C1.3 |
| Cliente / Grupo econômico | Business Actor | Origem da negociação; classificado por segmento, região e volumetria | BC Cadastro (Conformist) |
| Gerente de cash | Business Role | Simula e solicita aprovação | PR1, PR3 |
| Parametrizador | Business Role | Cria rascunho, envia a staging (perfil `precificacao.editor`) | PR5; RF-10 |
| Analista de Precificação | Business Role | Valida qualidade do ciclo e ativa a versão da BRP (perfil publicador) | PR6 |
| Aprovador de alçada | Business Role | Decide pedidos no seu nível; papel devolvido pela `politica_alcada` | PR4 |
| Contratante | Business Role | Efetiva a contratação no canal | PR2 |
| Negociação iniciada | Business Event | Gerente abre a Calculadora para um cliente x produto | C1 |
| Preço negociado abaixo do sugerido | Business Event | Condição da regra de alçada (brief §2) | RF-03 |
| Pedido decidido | Business Event | Resultado de PR4; evento de aplicação `PrecoAprovado`/`PrecoRecusado` | svc-alcada |
| Ciclo de precificação fechado | Business Event | Fechamento mensal (`anomes`) que dispara o pipeline | M2; Control-M |
| Nova versão de parâmetros necessária | Business Event | Mudança de tier, percentil-alvo, premissa ou catálogo | M1 |
| Desvio de reciprocidade detectado [EVOLUÇÃO] | Business Event | Realizado abaixo do acordado além da tolerância | C3.3 |
| Simular preço | Business Process | Informa volumetria e preço negociado; recebe praticado, alvo, sugerido, cenários, uplift e indicação de alçada | C1.1, C1.2, C1.3; RF-01, RF-02 |
| Contratar sem alçada | Business Process | Preço negociado ≥ sugerido do cenário: contratação direta; registra acordo (evolução) | RF-03 |
| Solicitar aprovação de alçada | Business Process | Abre pedido com justificativa quando negociado < sugerido | C1.3 |
| Decidir aprovação | Business Process | Aprovador do papel indicado aprova ou recusa | C1.3, C2.4 |
| Publicar versão de parâmetros | Business Process | Rascunho → staging → aprovação → publicação imediata ou agendada | M1; RF-05, RF-06 |
| Publicar ciclo da BRP Cash | Business Process | Pipeline gera, valida, carrega e o analista ativa o `anomes` | M2; RF-13 |
| Monitorar reciprocidade [EVOLUÇÃO] | Business Process | Compara acordado x realizado; gera desvio e elegibilidade | C3.2-C3.4 |
| Executar onda de reprecificação [EVOLUÇÃO] | Business Process | Planeja, seleciona elegíveis, calcula, aprova, efetiva, acompanha | C2.1-C2.5 |
| Cotação | Business Object | Registro de cada simulação com entradas, saídas e versões usadas; identidade `cotacao_id` referenciada no Salesforce | C1.6 |
| Cenário de preço | Business Object | Linha da MPA para produto x tier x segmento x região: alvo, sugerido, percentis | C1.1 |
| Pedido de aprovação | Business Object | Pedido, nível, papel, decisão | C1.3 |
| Versão de parâmetros | Business Object | Conjunto versionado de tiers, clusters, percentis, premissas, exceções | M1 |
| Ciclo de precificação | Business Object | Versão `anomes` da BRP Cash | M2 |
| Acordo de reciprocidade [EVOLUÇÃO] | Business Object | Volumetria, saldo e produtos acordados na negociação (lacuna 4) | C3.1 |
| Onda de reprecificação [EVOLUÇÃO] | Business Object | Escopo, calendário, metas, elegíveis, resultado | C2 |
| Precificação para o comercial | Business Service | O que o gerente recebe: preço de referência e simulação com alçada | C1 |
| Aprovação de alçada | Business Service | Decisão sobre preços abaixo do sugerido | C1.3 |
| Governança de parâmetros | Business Service | Regras versionadas e auditadas | M1 |
| Publicação de referência de preços | Business Service | BRP Cash ativa e íntegra a cada ciclo | M2 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Business Actor | assignment | Business Role | O ator desempenha o papel |
| Business Role | assignment | Business Process | O papel executa o processo |
| Business Event | triggering | Business Process | O evento dispara o processo |
| Simular preço | triggering | Preço negociado abaixo do sugerido | A simulação pode gerar a condição de alçada |
| Business Process | access | Business Object | O processo cria/lê o objeto |
| Business Process | realization | Business Service | O processo entrega o serviço |
| Publicação de referência / Governança de parâmetros | serving | Simular preço | Sem ciclo ativo e parâmetros vigentes não há simulação |

---

## 5. Application Cooperation Viewpoint

**Objetivo.** Mostrar os componentes canônicos (brief §6), os serviços de aplicação que expõem, as interfaces e os fluxos entre eles. Destaque para a decomposição funcional do `svc-pricing`, que **não contém função de cálculo do sugerido**.

```mermaid
flowchart TB
  classDef application fill:#B5FFFF,stroke:#1f7a8a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph CANAIS["Canais (Salesforce FSC)"]
    SFC["«Application Component» sf-calculadora (LWC)"]
    SFP["«Application Component» sf-parametrizacao (LWC)"]
    SFR["«Application Component» sf-reprecificacao (LWC) [EVOLUÇÃO]"]
    OUT["«Application Component» Outros canais e integradores"]
  end
  subgraph IFC["Interfaces"]
    IF1["«Application Interface» REST /mpc/v1 no apigw-axway (OAuth2, JWT)"]
    IF2["«Application Interface» Tópicos de eventos em sb-eventos (fallback outbox)"]
  end
  subgraph SVCS["Serviços de aplicação"]
    AS1["«Application Service» Serviço de Simulação de Preço"]
    AS2["«Application Service» Serviço de Alçada"]
    AS3["«Application Service» Serviço de Parametrização"]
    AS4["«Application Service» Serviço de Publicação de Referência"]
    AS5["«Application Service» Serviço de Preço Vigente e Histórico"]
    AS6["«Application Service» Serviço de Reciprocidade [EVOLUÇÃO]"]
    AS7["«Application Service» Serviço de Onda de Reprecificação [EVOLUÇÃO]"]
  end
  subgraph PRICING["«Application Component» svc-pricing (Cálculo de Preço)"]
    F1["«Application Function» Resolver contexto (grupo, segmento, região, catálogo)"]
    F2["«Application Function» Classificar (tier por volumetria, cluster por tier x segmento x região)"]
    F3["«Application Function» Consultar cenário na BRP (praticado, alvo, sugerido, percentis, vizinhos)"]
    F4["«Application Function» Compor resposta (cenários, uplift anual, versões)"]
    F5["«Application Function» Avaliar alçada (delegada ao svc-alcada)"]
    F6["«Application Function» Registrar cotação"]
  end
  ALC["«Application Component» svc-alcada"]
  PAR["«Application Component» svc-parametros"]
  PUB["«Application Component» svc-publicacao"]
  LEG["«Application Component» svc-legado-adapter (ACL)"]
  REC["«Application Component» svc-reciprocidade [EVOLUÇÃO]"]
  REP["«Application Component» svc-reprecificacao [EVOLUÇÃO]"]
  PPP["«Application Component» dbx-ppp (Pipeline de Preparação de Preços)"]
  TAR["«Application Component» Sistema legado de tarifas e contratos"]
  SFC -- serving --> IF1
  SFP -- serving --> IF1
  SFR -- serving --> IF1
  OUT -- serving --> IF1
  IF1 -. realization .-> AS1
  IF1 -. realization .-> AS2
  IF1 -. realization .-> AS3
  IF1 -. realization .-> AS4
  IF1 -. realization .-> AS5
  IF1 -. realization .-> AS6
  IF1 -. realization .-> AS7
  F1 -- triggering --> F2
  F2 -- triggering --> F3
  F3 -- triggering --> F4
  F4 -- triggering --> F5
  F5 -- triggering --> F6
  PRICING -. realization .-> AS1
  ALC -. realization .-> AS2
  PAR -. realization .-> AS3
  PUB -. realization .-> AS4
  LEG -. realization .-> AS5
  REC -. realization .-> AS6
  REP -. realization .-> AS7
  AS2 -- serving --> F5
  AS5 -- serving --> F3
  AS3 -- serving --> F2
  AS4 -- serving --> F3
  AS1 -- serving --> REP
  AS2 -- serving --> REP
  PPP -->|"flow: BRP Cash por anomes (reverse ETL) e pedido de validação"| PUB
  PAR -->|"flow: versão vigente de parâmetros"| PPP
  LEG -->|"flow: consulta online opcional (tarifa vigente)"| TAR
  PUB -->|"flow: VersaoBrpPublicada"| IF2
  PAR -->|"flow: VersaoParametroPublicada"| IF2
  ALC -->|"flow: PrecoAprovado, PrecoRecusado"| IF2
  REC -->|"flow: DesvioReciprocidadeDetectado, ClienteElegivel"| IF2
  IF2 -->|"flow: invalidação de cache"| PRICING
  IF2 -->|"flow: elegíveis e aprovações"| REP
  IF2 -->|"flow: alertas e fila do aprovador"| SFC
  class SFC,SFP,OUT,IF1,IF2,AS1,AS2,AS3,AS4,AS5,F1,F2,F3,F4,F5,F6,ALC,PAR,PUB,LEG,PPP,TAR application
  class SFR,AS6,AS7,REC,REP evol
  style PRICING fill:#B5FFFF,stroke:#1f7a8a
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| sf-calculadora | Application Component | LWC da Calculadora; Apex apenas proxy HTTP; guarda `cotacao_id` na oportunidade | C1.5; AD-05; contêiner sf-calculadora |
| sf-parametrizacao | Application Component | Telas de versões, staging, publicação, simulação em staging | M1; AD-05 |
| sf-reprecificacao [EVOLUÇÃO] | Application Component | Telas de onda e aprovação | C2; F4 |
| Outros canais e integradores | Application Component | Consumidores das mesmas APIs | RF-07 |
| REST /mpc/v1 no apigw-axway | Application Interface | OAuth2 client credentials + JWT do usuário; quotas; versionamento por caminho | AD-12; doc 06 §7 |
| Tópicos de eventos em sb-eventos | Application Interface | `mpc.publicacao`, `mpc.parametros`, `mpc.alcada`, `mpc.reciprocidade`, `mpc.reprecificacao`; fallback outbox | AD-09; lacuna 9 |
| Serviço de Simulação de Preço | Application Service | `POST /precos/simulacoes`, `GET /precos/{grupo}/{produto}/referencia`, `GET /cotacoes/{id}`, `/lote` (evolução) | C1.1, C1.2; RF-01, RF-02 |
| Serviço de Alçada | Application Service | `POST /alcadas/avaliacoes`, `/pedidos`, `/decisao` | C1.3; RF-03 |
| Serviço de Parametrização | Application Service | `/parametros/versoes/*`, `/parametros/vigentes` | M1; RF-05, RF-06 |
| Serviço de Publicação de Referência | Application Service | `/brp/versoes/{anomes}/validar`, `/ativar`, `/reverter`, `/brp/ativa` | M2; RF-13 |
| Serviço de Preço Vigente e Histórico | Application Service | `/legado/precos/.../vigente` e `/historico` (interno; exposto ao canal via svc-pricing) | C1.4; RF-04; AD-10 |
| Serviço de Reciprocidade [EVOLUÇÃO] | Application Service | `/reciprocidade/acordos`, `/monitoramentos`, `/desvios`, `/elegiveis` | C3; RF-12 |
| Serviço de Onda de Reprecificação [EVOLUÇÃO] | Application Service | `/reprecificacao/ondas/*` | C2; RF-11 |
| svc-pricing | Application Component | Núcleo C1; composto pelas seis funções abaixo; cache Caffeine (AD-11) | BC Cálculo de Preço; AD-04 |
| Resolver contexto | Application Function | Grupo econômico, segmento, região (PPC/cadastro) e catálogo do produto | C1.1 |
| Classificar | Application Function | Tier pelas faixas parametrizadas; cluster pela regra de cluster vigente | C1.1; M1 |
| Consultar cenário na BRP | Application Function | Lookup na MPA/PPC do `anomes` ativo: praticado (via Adaptador), alvo, **sugerido**, percentis P25-P90, cenários vizinhos de tier. **Não há fórmula de desconto online** | Brief §2; C1.1, C1.2 |
| Compor resposta | Application Function | Monta cenários (a)-(d) do brief §2; única conta online é o uplift anual por cenário | C1.2 |
| Avaliar alçada | Application Function | Desvio negociado x sugerido enviado ao svc-alcada; recebe nível e papel | C1.3 |
| Registrar cotação | Application Function | Persiste `cotacao` com `anomes_brp`, `versao_parametros`, `hash_entrada`, `origem_praticado` | C1.6; RF-09; RNF-09 |
| svc-alcada | Application Component | Classifica desvio em nível e papel; registra pedidos e decisões | BC Alçada e Aprovação |
| svc-parametros | Application Component | Versões, status, vigência, auditoria de mudança | BC Parametrização; AD-06 |
| svc-publicacao | Application Component | Catálogo de versões da BRP, validação pós-carga, ativação atômica, rollback | BC Publicação de Referência; AD-03 |
| svc-legado-adapter | Application Component | Anti-corruption layer: estratégias foto, online, auto | BC Preço Vigente e Histórico; AD-10 |
| svc-reciprocidade [EVOLUÇÃO] | Application Component | Acordo, monitoramento por job, desvio, eventos | BC Reciprocidade; AD-07 |
| svc-reprecificacao [EVOLUÇÃO] | Application Component | Onda; cálculo em lote via svc-pricing; aprovação via svc-alcada | BC Reprecificação; AD-08 |
| dbx-ppp | Application Component | Workflow `ppp_ciclo_{anomes}` com tarefas T0-T11; gera MPA (com alvo e sugerido por cenário), PPC, Matriz de Relacionamento, Indicadores, foto do legado | BC Modelagem de Preço; AD-01 |
| Sistema legado de tarifas e contratos | Application Component | Externo; fonte de preço vigente; alvo da efetivação em C2 (pendente) | M3; lacuna 4 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Canais | serving | REST /mpc/v1 | Os canais consomem a interface publicada (Open Host Service) |
| Interface | realization | Application Service | A interface expõe o serviço |
| Component | realization | Application Service | O componente implementa o serviço |
| Application Function | triggering | Application Function | Encadeamento interno do svc-pricing: contexto → classificação → lookup → composição → alçada → cotação |
| Serviço de Alçada | serving | Avaliar alçada | Customer/Supplier (doc 05) |
| Serviço de Parametrização | serving | Classificar | Faixas de tier e regra de cluster vigentes |
| Serviço de Publicação / Preço Vigente | serving | Consultar cenário na BRP | Published Language da BRP e ACL do legado |
| dbx-ppp | flow | svc-publicacao | Reverse ETL em staging e pedido de validação (AD-03) |
| svc-parametros | flow | dbx-ppp | O pipeline lê a versão vigente (tiers, clusters, percentis, janelas) para gerar o ciclo |
| Componentes | flow | Tópicos de eventos | Eventos de domínio (doc 06 §5.7) |
| Tópicos de eventos | flow | svc-pricing, svc-reprecificacao, sf-calculadora | Consumo assíncrono: invalidação de cache, elegíveis, alertas |

---

## 6. Application Usage Viewpoint (alinhamento negócio-aplicação)

**Objetivo.** Tornar explícito qual serviço de aplicação serve qual processo de negócio (relação *serving*) e qual papel usa qual componente de canal. A matriz substitui o diagrama: cada célula marcada é uma relação `serving` entre o serviço da coluna e o processo da linha.

| Processo de negócio | Simulação de Preço | Alçada | Parametrização | Publicação de Referência | Preço Vigente e Histórico | Reciprocidade [EVOL] | Onda [EVOL] | Canal usado |
|---|---|---|---|---|---|---|---|---|
| Simular preço | serving (principal) | serving (indicação de alçada) | serving (versão vigente, implícito) | serving (BRP ativa, implícito) | serving (praticado e histórico) | — | — | sf-calculadora, outros canais |
| Contratar sem alçada | serving (cotação válida) | — | — | — | — | serving (registrar acordo) | — | sf-calculadora |
| Solicitar aprovação de alçada | serving (cotação) | serving (abrir pedido) | — | — | — | — | — | sf-calculadora |
| Decidir aprovação | — | serving (fila e decisão) | — | — | — | — | serving (aprovação por lote) | sf-calculadora (fila), sf-reprecificacao |
| Publicar versão de parâmetros | serving (simulação em staging) | — | serving (principal) | — | — | — | — | sf-parametrizacao |
| Publicar ciclo da BRP Cash | — | — | serving (versão usada pelo pipeline) | serving (principal) | — | — | — | sf-parametrizacao (tela de ativação), Control-M |
| Monitorar reciprocidade [EVOL] | — | — | serving (regras e tolerâncias) | serving (indicadores do ciclo) | — | serving (principal) | — | Salesforce (alertas), Control-M |
| Executar onda de reprecificação [EVOL] | serving (cálculo em lote) | serving (aprovação) | serving (gradação, exceções) | serving (elegíveis pré-computados) | serving (efetivação, pendente) | serving (elegibilidade) | serving (principal) | sf-reprecificacao |

Leitura: o processo "Simular preço" depende de cinco serviços, mas apenas dois são chamados pelo canal (Simulação e, através dele, Alçada). Parametrização, Publicação e Preço Vigente são consumidos internamente pelo `svc-pricing`, o que mantém o contrato do canal estável quando as regras mudam (RNF-07).

---

## 7. Information Structure Viewpoint

**Objetivo.** Descrever os objetos de dados, sua realização dos objetos de negócio e onde cada um é persistido. A **rastreabilidade das simulações** (Cotação + Auditoria) recebe destaque próprio, pois é o que permite reproduzir qualquer preço devolvido (RF-09, RNF-03, RNF-09) e o que o comparador do shadow run consome (AD-14).

```mermaid
flowchart TB
  classDef business fill:#FFFFB5,stroke:#8a8a1f,color:#000
  classDef application fill:#B5FFFF,stroke:#1f7a8a,color:#000
  classDef technology fill:#C9E7B7,stroke:#3f7a2a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph BO["Objetos de negócio"]
    BO1["«Business Object» Cotação"]
    BO2["«Business Object» Cenário de preço"]
    BO3["«Business Object» Pedido de aprovação"]
    BO4["«Business Object» Versão de parâmetros"]
    BO5["«Business Object» Ciclo de precificação"]
    BO6["«Business Object» Acordo de reciprocidade [EVOLUÇÃO]"]
    BO7["«Business Object» Onda de reprecificação [EVOLUÇÃO]"]
  end
  subgraph BRP["BRP Cash (por anomes)"]
    DO1["«Data Object» Versão BRP (anomes, status, dt_ativacao, resumo_qualidade, versao_parametros_usada)"]
    DO2["«Data Object» Matriz de Cenários de Preço MPA (produto x tier x segmento x região → cluster, preço alvo, preço sugerido, P25..P90, N)"]
    DO3["«Data Object» Posição de Preço Cliente-Produto PPC (grupo x produto → tier, cluster, praticado, alvo, sugerido do cenário, uplift)"]
    DO4["«Data Object» Matriz de Relacionamento (stickiness x impacto, shares)"]
    DO5["«Data Object» Indicadores de Reciprocidade (saldo IF/DAV, SoW boletos, emissões L3M)"]
    DO6["«Data Object» Foto de preço vigente e Histórico 12 meses (origem, dt_referencia)"]
  end
  subgraph PARAM["Parâmetros versionados"]
    DO7["«Data Object» Versão de parâmetros (escopo, status, vigência, autor, aprovador)"]
    DO8["«Data Object» Itens de parâmetro (catálogo, domínios, tier, regra de cluster, percentis, exceções, janelas)"]
    DO9["«Data Object» Política de alçada (produto, segmento, faixa de desvio → nível, papel)"]
  end
  subgraph RASTRO["Rastreabilidade das simulações (C1.6, RF-09, RNF-03, RNF-09)"]
    DO10["«Data Object» Cotação (cotacao_id, usuário, canal, modo, entrada_json, saida_json, anomes_brp, versao_parametros, origem_praticado, hash_entrada)"]
    DO11["«Data Object» Auditoria append-only (seq, usuário, entidade, operação, antes, depois)"]
    DO12["«Data Object» Pedido de aprovação (nível, papel, status, decisor)"]
    AE1["«Application Event» Evento de domínio (envelope: id, tipo, correlação, versões)"]
  end
  subgraph EVO["Evolução"]
    DO13["«Data Object» Acordo e Desvio de reciprocidade [EVOLUÇÃO]"]
    DO14["«Data Object» Onda e Onda cliente-produto [EVOLUÇÃO]"]
  end
  subgraph PERSIST["Persistência"]
    T1["«Artifact» Tabelas Delta dbx-brp (gold, partição anomes, time travel)"]
    T2["«Artifact» Tabelas sql-motor (versão ativa e anterior, stg_* → swap)"]
    T3["«Artifact» Tabelas sql-motor (parâmetros, alçada, cotação, auditoria, evolução)"]
    T4["«Artifact» Salesforce: apenas cotacao_id na oportunidade"]
  end
  DO2 -. realization .-> BO2
  DO3 -. realization .-> BO2
  DO1 -. realization .-> BO5
  DO7 -. realization .-> BO4
  DO8 -. realization .-> BO4
  DO9 -. realization .-> BO4
  DO10 -. realization .-> BO1
  DO12 -. realization .-> BO3
  DO13 -. realization .-> BO6
  DO14 -. realization .-> BO7
  DO10 -->|"referencia anomes_brp"| DO1
  DO10 -->|"referencia versao_parametros"| DO7
  DO12 -->|"referencia cotacao_id"| DO10
  DO11 -->|"registra mudanças de"| DO7
  DO11 -->|"registra execuções de"| DO10
  AE1 -->|"correlação com"| DO10
  DO13 -->|"origina de"| DO10
  DO14 -->|"calcula via"| DO10
  T1 -. realization .-> DO2
  T1 -. realization .-> DO3
  T1 -. realization .-> DO4
  T1 -. realization .-> DO5
  T1 -. realization .-> DO6
  T2 -. realization .-> DO1
  T2 -. realization .-> DO2
  T2 -. realization .-> DO3
  T2 -. realization .-> DO4
  T2 -. realization .-> DO5
  T2 -. realization .-> DO6
  T3 -. realization .-> DO7
  T3 -. realization .-> DO8
  T3 -. realization .-> DO9
  T3 -. realization .-> DO10
  T3 -. realization .-> DO11
  T3 -. realization .-> DO12
  T3 -. realization .-> DO13
  T3 -. realization .-> DO14
  T4 -. access .-> DO10
  class BO1,BO2,BO3,BO4,BO5 business
  class DO1,DO2,DO3,DO4,DO5,DO6,DO7,DO8,DO9,DO10,DO11,DO12,AE1 application
  class T1,T2,T3,T4 technology
  class BO6,BO7,DO13,DO14 evol
  style RASTRO fill:#E0F7FF,stroke:#1f7a8a,stroke-width:2px
```

**Elementos**

| Elemento | Tipo | Descrição | Persistido em | Rastreio |
|---|---|---|---|---|
| Versão BRP | Data Object | Catálogo do ciclo: `anomes`, status (carregada, validada, ativa, anterior), qualidade, versão de parâmetros usada pelo pipeline | sql-motor `versao_brp`; Delta `brp.qualidade_ciclo` | BC Publicação de Referência; AD-03 |
| Matriz de Cenários de Preço (MPA) | Data Object | Um registro por cenário; carrega **preço alvo e preço sugerido** pré-calculados, percentis P25-P90, cluster e N. Nome físico `matriz_cenarios_preco` (doc 06 §6; antes `matriz_preco_alvo_cluster`), com colunas `cenario_id` e `preco_sugerido`; a PPC (`posicao_preco_cliente_produto`) carrega `cenario_id` e `preco_sugerido` do cenário do cliente | dbx-brp gold; sql-motor (ativa e anterior) | Brief §1-§2; C1.1 |
| Posição de Preço Cliente-Produto (PPC) | Data Object | Por grupo x produto: tier, cluster, praticado, alvo e sugerido do cenário em que o cliente caiu no ciclo, volumetria, receita, uplift | dbx-brp; sql-motor | C1.1; brief §2 |
| Matriz de Relacionamento | Data Object | Stickiness x impacto, share de cash e crédito | dbx-brp; sql-motor | C2.3 (gradação), C3 |
| Indicadores de Reciprocidade | Data Object | Saldo IF/DAV, SoW boletos, emissões L3M | dbx-brp; sql-motor | C3.2; possível dimensão do cenário (lacuna 3) |
| Foto de preço vigente e Histórico | Data Object | Tarifa vigente e série de 12 meses com origem e data de referência | dbx-brp; sql-motor | C1.4; AD-10 |
| Versão de parâmetros | Data Object | Cabeçalho da versão: escopo global ou por produto, status, vigência, autor, aprovador | sql-motor `parametro_versao` | M1; AD-06 |
| Itens de parâmetro | Data Object | Tabelas tipadas por tipo (`parametro_item_tier`, `_regra_cluster`, `_percentil`, `_excecao`, `_janela`, `catalogo_produto`, `dominio`) | sql-motor | M1 |
| Política de alçada | Data Object | Faixas de desvio por produto e segmento → nível e papel aprovador (conteúdo de `premissas_alcada`, lacuna 2) | sql-motor `politica_alcada` | C1.3 |
| Cotação | Data Object | Cada simulação, com entrada e saída em JSON, `anomes_brp`, `versao_parametros`, `hash_entrada`, `origem_praticado`, `modo` (produção ou staging). Partição mensal, 24 meses online, exportação ao Delta | sql-motor `cotacao` | C1.6; RF-09; RNF-09; AD-02 (reavaliar por volume) |
| Auditoria | Data Object | Append-only: quem, quando, entidade, operação, antes e depois; sem UPDATE/DELETE por permissão de banco | sql-motor `auditoria`; exportação ao Delta | M4; RNF-03; AD-12 |
| Pedido de aprovação | Data Object | Nível, papel, status, decisor, data de decisão; vinculado à cotação | sql-motor `pedido_aprovacao` | C1.3 |
| Evento de domínio | Application Event | Envelope padrão com id, tipo, ocorrido_em, correlação e versões; idempotência por `evento_id` | sb-eventos ou `evento_outbox` | AD-09 |
| Acordo e Desvio de reciprocidade [EVOLUÇÃO] | Data Object | Acordo vinculado à cotação de origem; desvios por `anomes` | sql-motor | C3 |
| Onda e Onda cliente-produto [EVOLUÇÃO] | Data Object | Escopo, meta, elegíveis, preço proposto vinculado à cotação de lote | sql-motor | C2 |
| Tabelas Delta dbx-brp | Artifact | Gold, partição por `anomes`, Unity Catalog, time travel: histórico completo de ciclos (M3) | Databricks | AD-01 |
| Tabelas sql-motor | Artifact | Versão ativa e anterior da BRP via `stg_*` + `SWITCH PARTITION`; view `v_brp_ativa` | Azure SQL | AD-02, AD-03 |
| Salesforce: cotacao_id | Artifact | O canal não persiste preço; guarda apenas a referência da cotação | Salesforce | AD-05; P1 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Data Object | realization | Business Object | O objeto de dados é a representação do objeto de negócio |
| Cotação | association | Versão BRP, Versão de parâmetros | Toda cotação aponta as versões que a geraram: reexecutar a mesma entrada com as mesmas versões reproduz o preço |
| Pedido de aprovação | association | Cotação | O pedido nasce de uma cotação com negociado < sugerido |
| Auditoria | association | Versão de parâmetros, Cotação | Trilha de mudança (parâmetros) e trilha de execução (simulações) |
| Evento de domínio | association | Cotação | Correlação por `X-Correlation-Id` para tracing ponta a ponta |
| Artifact | realization | Data Object | Onde o dado vive fisicamente |
| Salesforce | access | Cotação | Leitura por `cotacao_id` (`GET /cotacoes/{id}`); nunca escrita |

---

## 8. Technology Viewpoint

**Objetivo.** Mostrar os nós, softwares de sistema, serviços de tecnologia e artefatos que realizam os componentes de aplicação, seguindo o fluxo de entrada da stack corporativa: Akamai → Application Gateway → Axway → microsserviços (`stack-tech.md`).

```mermaid
flowchart TB
  classDef application fill:#B5FFFF,stroke:#1f7a8a,color:#000
  classDef technology fill:#C9E7B7,stroke:#3f7a2a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph BORDA["Borda"]
    AK["«Node» Akamai (TLS, DDoS, WAF externo)"]
    AG["«Node» Azure Application Gateway (L7, WAF, zona-redundante)"]
    AX["«Node» Axway API Gateway"]
    TS1["«Technology Service» Gateway de API (OAuth2, quotas, catálogo /mpc/v1)"]
  end
  subgraph SAAS["Salesforce (SaaS)"]
    SF["«Node» Salesforce FSC"]
    AR1["«Artifact» Metadados LWC, Apex proxy, Named Credentials"]
  end
  subgraph ARO["«Node» ARO — Azure Red Hat OpenShift (namespaces mpc-dev, mpc-hml, mpc-prd)"]
    OS["«System Software» OpenShift (HPA, PDB, secrets, service mesh opcional)"]
    P1["«Node» Pod svc-pricing (3+ réplicas, multi-zona)"]
    P2["«Node» Pod svc-alcada"]
    P3["«Node» Pod svc-parametros"]
    P4["«Node» Pod svc-publicacao"]
    P5["«Node» Pod svc-legado-adapter"]
    P6["«Node» Pod svc-reciprocidade [EVOLUÇÃO]"]
    P7["«Node» Pod svc-reprecificacao [EVOLUÇÃO]"]
    AR2["«Artifact» Imagens OCI svc-* (Java 21, Spring Boot, Flyway)"]
    TS2["«Technology Service» Execução de contêineres"]
  end
  subgraph DADOS["Dados de serviço"]
    SQL["«Node» Azure SQL Database sql-motor (zona-redundante, réplica de leitura, TDE)"]
    TS3["«Technology Service» Banco relacional"]
  end
  subgraph MSG["Mensageria"]
    SB["«Node» Azure Service Bus sb-eventos (a validar; fallback outbox)"]
    TS4["«Technology Service» Mensageria de eventos"]
  end
  subgraph DBX["«Node» Databricks (workspace prd)"]
    DL["«System Software» Delta Lake e Unity Catalog"]
    JC["«Node» Job cluster (PySpark)"]
    AR3["«Artifact» Workflow ppp_ciclo_anomes (Asset Bundle)"]
    AR4["«Artifact» Tabelas Delta bronze, silver, brp.* (gold)"]
    TS5["«Technology Service» Processamento analítico e reverse ETL (JDBC)"]
  end
  subgraph ORQ["Orquestração"]
    CM["«System Software» Control-M"]
    TS6["«Technology Service» Agendamento e disparo corporativo (Jobs API)"]
  end
  subgraph LEG["Legado e fontes"]
    L1["«Node» Sistema de tarifas e contratos"]
    L2["«Node» Cadastro de cliente e grupo econômico"]
    L3["«Node» SAS SIMUL_* e Servidor SQL 010 [A DESLIGAR na F2]"]
    L4["«Node» Planilha Preço Ano 1 e macro [A DESLIGAR]"]
  end
  subgraph TRANSV["Transversais"]
    OB["«Technology Service» Observabilidade (logs centralizados, métricas, tracing por X-Correlation-Id)"]
    ID["«Technology Service» Identidade (AD corporativo, SSO Salesforce, JWT)"]
  end
  subgraph APPS["Componentes de aplicação realizados"]
    A1["«Application Component» svc-pricing, svc-alcada, svc-parametros, svc-publicacao, svc-legado-adapter"]
    A2["«Application Component» dbx-ppp"]
    A3["«Application Component» sf-calculadora, sf-parametrizacao"]
    A4["«Application Component» svc-reciprocidade, svc-reprecificacao [EVOLUÇÃO]"]
  end
  AK -->|"flow: HTTPS"| AG
  AG -->|"flow: HTTPS"| AX
  SF -->|"flow: HTTPS via Named Credential"| AG
  AX -->|"flow: REST/JSON"| P1
  AX -->|"flow: REST/JSON"| P2
  AX -->|"flow: REST/JSON"| P3
  AX -->|"flow: REST/JSON"| P4
  AX -. realization .-> TS1
  OS -. realization .-> TS2
  SQL -. realization .-> TS3
  SB -. realization .-> TS4
  JC -. realization .-> TS5
  CM -. realization .-> TS6
  P1 -->|"flow: JDBC"| SQL
  P2 -->|"flow: JDBC"| SQL
  P3 -->|"flow: JDBC"| SQL
  P4 -->|"flow: JDBC"| SQL
  P5 -->|"flow: JDBC"| SQL
  P5 -->|"flow: conector a definir (REST, MQ, DB link)"| L1
  JC -->|"flow: JDBC reverse ETL para stg_*"| SQL
  JC -->|"flow: REST validar versão"| P4
  L1 -->|"flow: foto mensal vigente e histórico"| DL
  L2 -->|"flow: segmentos, grupo, região"| DL
  CM -->|"flow: Jobs API run-now"| JC
  CM -->|"flow: HTTP job periódico"| P6
  CM -->|"flow: HTTP lote"| P7
  TS4 -- serving --> P1
  TS4 -- serving --> P7
  OB -- serving --> ARO
  ID -- serving --> AX
  ID -- serving --> SF
  AR2 -- assignment --> P1
  AR3 -- assignment --> JC
  AR4 -- assignment --> DL
  AR1 -- assignment --> SF
  ARO -. realization .-> A1
  DBX -. realization .-> A2
  SF -. realization .-> A3
  ARO -. realization .-> A4
  class AK,AG,AX,TS1,SF,AR1,OS,P1,P2,P3,P4,P5,AR2,TS2,SQL,TS3,SB,TS4,DL,JC,AR3,AR4,TS5,CM,TS6,L1,L2,OB,ID technology
  class A1,A2,A3 application
  class P6,P7,L3,L4,A4 evol
  style ARO fill:#C9E7B7,stroke:#3f7a2a
  style DBX fill:#C9E7B7,stroke:#3f7a2a
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| Akamai | Node | Porta de entrada de canais externos: TLS, DDoS, roteamento | akamai; RNF-04 |
| Azure Application Gateway | Node | Balanceamento L7, WAF, zona-redundante; entrada também do Salesforce (Named Credential) | appgw-azure |
| Axway API Gateway | Node | OAuth2, JWT, quotas, versionamento de contrato, logs de acesso | apigw-axway; AD-12 |
| Gateway de API | Technology Service | Serviço que o Axway presta aos componentes de aplicação | RF-07 |
| Salesforce FSC | Node | SaaS; hospeda os canais LWC | AD-05 |
| Metadados LWC, Apex proxy, Named Credentials | Artifact | Pacote SFDX versionado; Apex sem regra de negócio | sf-*; risco R6 |
| ARO | Node | Cluster OpenShift corporativo; namespaces por ambiente | aro; doc 06 §9 |
| OpenShift | System Software | HPA, PDB, secrets, health checks, observabilidade padrão | AD-12, AD-13 |
| Pods svc-* | Node | Uma implantação por microsserviço; svc-pricing com 3+ réplicas em zonas distintas | AD-13; RNF-01 |
| Imagens OCI svc-* | Artifact | Build Maven, Java 21, Spring Boot, migrações Flyway, deploy por Helm/ArgoCD ou Tekton (premissa) | doc 06 §9 |
| Execução de contêineres | Technology Service | Serviço prestado pelo ARO aos componentes Java | AD-04 |
| Azure SQL Database sql-motor | Node | Zona-redundante, réplica de leitura, TDE, particionamento por `anomes` | sql-motor; AD-02, AD-13 |
| Azure Service Bus sb-eventos | Node | Tópicos e assinaturas; **não está na stack**, fallback outbox + polling | AD-09; lacuna 9 |
| Databricks | Node | Workspace com job cluster PySpark, Delta Lake e Unity Catalog | dbx-ppp, dbx-brp; AD-01 |
| Workflow ppp_ciclo_anomes | Artifact | Tarefas T0-T11 versionadas em Git com Asset Bundles | AD-01, AD-03 |
| Tabelas Delta | Artifact | Bronze governada, silver por produto, gold BRP Cash por `anomes` | RNF-06 |
| Control-M | System Software | Disparador corporativo dos jobs (pipeline, reciprocidade, lote); não orquestra tarefas internas do workflow | controlm; AD-01, AD-07 |
| Sistema de tarifas e contratos | Node | Legado; fonte do preço vigente; conector a definir (P9) | M3; AD-10 |
| Cadastro de cliente e grupo econômico | Node | Segmentos, CNPJ → grupo, região; ingerido no Databricks | Conformist |
| SAS SIMUL_* e SQL 010 [A DESLIGAR] | Node | Cadeia de distribuição atual; congelada e desativada na F2 (marco M5) | AD-14 |
| Planilha Preço Ano 1 [A DESLIGAR] | Node | Deixa de alimentar o SAS no marco M2; sai de uso operacional no marco M7 | AD-14 |
| Observabilidade | Technology Service | Logs, métricas Prometheus, tracing distribuído; alertas do Databricks e Control-M | RNF-05 |
| Identidade | Technology Service | AD corporativo, SSO Salesforce, claims de perfil no JWT | RNF-04; RF-10 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Akamai → App Gateway → Axway → Pods | flow | — | Caminho de entrada obrigatório da stack |
| Salesforce | flow | App Gateway | Named Credential; o canal não fala direto com o ARO |
| Node / System Software | realization | Technology Service | O nó presta o serviço de tecnologia |
| Pods, Job cluster | flow | Azure SQL | JDBC (leitura/escrita do motor; reverse ETL em `stg_*`) |
| svc-legado-adapter | flow | Sistema de tarifas | Consulta online opcional (estratégia `online`/`auto`) |
| Legado, Cadastro | flow | Delta Lake | Foto mensal e cadastro ingeridos no lake (premissa `00-doc-negocio.md:L29`) |
| Control-M | flow | Job cluster, pods de job | Disparo via Jobs API e HTTP |
| Artifact | assignment | Node | O artefato é implantado no nó |
| Node | realization | Application Component | O nó realiza (hospeda) o componente |
| Observabilidade, Identidade | serving | ARO, Axway, Salesforce | Serviços transversais |

---

## 9. Layered Viewpoint

**Objetivo.** Um único diagrama que atravessa as camadas para os dois fluxos principais: (A) **simulação com alçada** (C1) e (B) **publicação do ciclo da BRP Cash** (M2). Lê-se de cima para baixo: o objetivo é realizado pela capacidade; o processo realiza a capacidade; o serviço de aplicação serve o processo; o componente realiza o serviço; o nó realiza o componente.

```mermaid
flowchart BT
  classDef strategy fill:#F5DEAA,stroke:#8a6d1f,color:#000
  classDef business fill:#FFFFB5,stroke:#8a8a1f,color:#000
  classDef application fill:#B5FFFF,stroke:#1f7a8a,color:#000
  classDef technology fill:#C9E7B7,stroke:#3f7a2a,color:#000
  classDef motivation fill:#CCCCFF,stroke:#4a4a9a,color:#000
  subgraph L0["Motivação e Estratégia"]
    G1["«Goal» G1 Uplift com política nunca reduzir"]
    G3["«Goal» G3 Autonomia comercial com alçada"]
    C1["«Capability» C1 Cálculo, Simulação e Entrega de Preços"]
    M2["«Capability» M2 Preparação de Dados"]
  end
  subgraph L1["Negócio"]
    RL1["«Business Role» Gerente de cash"]
    RL4["«Business Role» Aprovador de alçada"]
    RL3["«Business Role» Analista de Precificação"]
    PR1["«Business Process» Simular preço"]
    PR3["«Business Process» Solicitar aprovação de alçada"]
    PR4["«Business Process» Decidir aprovação"]
    PR6["«Business Process» Publicar ciclo da BRP Cash"]
    BO1["«Business Object» Cotação"]
    BO5["«Business Object» Ciclo de precificação"]
  end
  subgraph L2["Aplicação"]
    AS1["«Application Service» Serviço de Simulação de Preço"]
    AS2["«Application Service» Serviço de Alçada"]
    AS5["«Application Service» Serviço de Preço Vigente"]
    AS4["«Application Service» Serviço de Publicação de Referência"]
    SFC["«Application Component» sf-calculadora"]
    PRC["«Application Component» svc-pricing (classifica, consulta cenário, compõe, aciona alçada)"]
    ALC["«Application Component» svc-alcada"]
    LEG["«Application Component» svc-legado-adapter"]
    PUB["«Application Component» svc-publicacao"]
    PPP["«Application Component» dbx-ppp"]
    DO10["«Data Object» Cotação e Auditoria"]
    DO2["«Data Object» MPA e PPC (alvo e sugerido por cenário)"]
  end
  subgraph L3["Tecnologia"]
    SF["«Node» Salesforce FSC"]
    AX["«Node» Axway API Gateway"]
    ARO["«Node» ARO (pods Java)"]
    SQL["«Node» Azure SQL sql-motor"]
    DBX["«Node» Databricks (job cluster, Delta)"]
    CM["«System Software» Control-M"]
  end
  C1 -. realization .-> G1
  C1 -. realization .-> G3
  M2 -. realization .-> G1
  PR1 -. realization .-> C1
  PR3 -. realization .-> C1
  PR4 -. realization .-> C1
  PR6 -. realization .-> M2
  RL1 -- assignment --> PR1
  RL1 -- assignment --> PR3
  RL4 -- assignment --> PR4
  RL3 -- assignment --> PR6
  PR1 -- triggering --> PR3
  PR3 -- triggering --> PR4
  PR1 -. access .-> BO1
  PR6 -. access .-> BO5
  AS1 -- serving --> PR1
  AS2 -- serving --> PR3
  AS2 -- serving --> PR4
  AS4 -- serving --> PR6
  AS4 -- serving --> PR1
  SFC -- serving --> PR1
  SFC -- serving --> PR4
  PRC -. realization .-> AS1
  ALC -. realization .-> AS2
  LEG -. realization .-> AS5
  PUB -. realization .-> AS4
  AS2 -- serving --> PRC
  AS5 -- serving --> PRC
  PPP -->|"flow: BRP por anomes (reverse ETL)"| PUB
  PRC -. access .-> DO10
  PRC -. access .-> DO2
  PPP -. access .-> DO2
  DO10 -. realization .-> BO1
  DO2 -. realization .-> BO5
  SF -. realization .-> SFC
  AX -- serving --> SFC
  ARO -. realization .-> PRC
  ARO -. realization .-> ALC
  ARO -. realization .-> LEG
  ARO -. realization .-> PUB
  DBX -. realization .-> PPP
  SQL -- serving --> ARO
  DBX -->|"flow: JDBC"| SQL
  CM -- triggering --> DBX
  class G1,G3 motivation
  class C1,M2 strategy
  class RL1,RL4,RL3,PR1,PR3,PR4,PR6,BO1,BO5 business
  class AS1,AS2,AS5,AS4,SFC,PRC,ALC,LEG,PUB,PPP,DO10,DO2 application
  class SF,AX,ARO,SQL,DBX,CM technology
```

**Leitura do fluxo A (simulação com alçada).** O Gerente de cash executa "Simular preço" pelo `sf-calculadora`; o Serviço de Simulação de Preço (realizado por `svc-pricing`) classifica o cliente, consulta o cenário na MPA/PPC do `anomes` ativo, obtém o praticado pelo Serviço de Preço Vigente (`svc-legado-adapter`), compõe cenários e uplift, pede ao Serviço de Alçada (`svc-alcada`) o nível e o papel quando o negociado fica abaixo do sugerido, e grava a Cotação com as versões usadas. Se houver alçada, "Solicitar aprovação" abre o pedido e "Decidir aprovação" é executada pelo Aprovador na fila do Salesforce. Tudo roda em pods no ARO atrás do Axway, com dados no Azure SQL.

**Leitura do fluxo B (publicação do ciclo).** O Control-M dispara o workflow `dbx-ppp` no Databricks; o pipeline gera as entidades da BRP Cash (incluindo alvo e sugerido por cenário), valida, faz reverse ETL para `stg_*` no Azure SQL e pede validação ao `svc-publicacao`; o Analista de Precificação ativa o `anomes` (swap atômico), o evento `VersaoBrpPublicada` invalida o cache do `svc-pricing`, e "Simular preço" passa a usar o novo ciclo.

---

## 10. Implementation & Migration Viewpoint

**Objetivo.** Descrever os estados intermediários da arquitetura (plateaus), os gaps entre eles e os pacotes de trabalho por fase (F0-F5, brief §9) com entregáveis e marcos (doc 09).

```mermaid
flowchart LR
  classDef impl fill:#FFE0E0,stroke:#9a4a4a,color:#000
  classDef evol fill:#EEEEEE,stroke:#777,color:#333,stroke-dasharray:5 5
  subgraph PLT["Plateaus"]
    PL0["«Plateau» Plateau 0 AS-IS: Planilha, macro, SAS SIMUL_*, SQL 010, Calculadora"]
    PL1["«Plateau» Plateau 1 fim da F1: motor C1 em shadow; BRP Cash v1; legado ainda oficial"]
    PL2["«Plateau» Plateau 2 fim da F2: motor oficial; parametrização completa; SAS, SQL 010 e Planilha desligados"]
    PL3["«Plateau» Plateau 3 fim da F3/F4: C3 e C2 em operação [EVOLUÇÃO]"]
  end
  subgraph GAPS["Gaps"]
    GP1["«Gap» Regras do sugerido não documentadas; sem pipeline governado; sem auditoria"]
    GP2["«Gap» Sem telas de parametrização, staging, vigência, perfis; legado ainda alimenta a Calculadora"]
    GP3["«Gap» Sem acordo, monitoramento, eventos, onda; efetivação no legado indefinida"]
  end
  subgraph WP["Pacotes de trabalho"]
    W0["«Work Package» F0 Mobilização e fechamento de lacunas (out-nov/2026)"]
    W1["«Work Package» F1 MVP C1 em paralelo ao legado (nov/2026-mar/2027)"]
    W2["«Work Package» F2 Parametrização completa e desligamento do legado (abr-jun/2027)"]
    W3["«Work Package» F3 Discovery C2/C3 e MVP Reciprocidade (jul-set/2027) [EVOLUÇÃO]"]
    W4["«Work Package» F4 MVP Onda de Reprecificação (out/2027-jan/2028) [EVOLUÇÃO]"]
    W5["«Work Package» F5 Escala e otimização (2028) [EVOLUÇÃO]"]
  end
  subgraph DLV["Entregáveis"]
    D0["«Deliverable» Decisões das lacunas, contrato de dados da BRP, catálogo de parâmetros, arquitetura aprovada, ambientes"]
    D1["«Deliverable» dbx-ppp portado, BRP Cash v1, reverse ETL, svc-pricing, svc-alcada, svc-legado-adapter (foto), svc-parametros básico, APIs no Axway, sf-calculadora em shadow, auditoria, comparador"]
    D2["«Deliverable» sf-parametrizacao, staging lógico, vigência agendada, perfis, validação de dados, APIs para outros canais, runbooks, desligamento por produto"]
    D3["«Deliverable» Documento de discovery C2/C3, svc-reciprocidade, eventos, alertas ao gerente"]
    D4["«Deliverable» svc-reprecificacao, sf-reprecificacao, cálculo em lote, aprovação, efetivação (decisão), acompanhamento"]
  end
  subgraph MRC["Marcos (Implementation Event)"]
    E1["«Implementation Event» Marco M1 Arquitetura aprovada 13/11/2026"]
    E2["«Implementation Event» Marco M2 BRP Cash v1 publicada 15/01/2027"]
    E3["«Implementation Event» Marco M3 Piloto C1 em shadow 12/02/2027"]
    E4["«Implementation Event» Marco M4 Go-live C1 31/03/2027"]
    E5["«Implementation Event» Marco M5 Desligamento SAS e SQL 010 30/06/2027"]
    E6["«Implementation Event» Marco M6 MVP C3 30/09/2027"]
    E7["«Implementation Event» Marco M7 MVP C2 31/01/2028"]
  end
  PL0 --- GP1
  GP1 --- PL1
  PL1 --- GP2
  GP2 --- PL2
  PL2 --- GP3
  GP3 --- PL3
  W0 -- triggering --> W1
  W1 -- triggering --> W2
  W2 -- triggering --> W3
  W3 -- triggering --> W4
  W4 -- triggering --> W5
  W0 -. realization .-> D0
  W1 -. realization .-> D1
  W2 -. realization .-> D2
  W3 -. realization .-> D3
  W4 -. realization .-> D4
  D0 -. realization .-> PL1
  D1 -. realization .-> PL1
  D2 -. realization .-> PL2
  D3 -. realization .-> PL3
  D4 -. realization .-> PL3
  W0 -- triggering --> E1
  W1 -- triggering --> E2
  W1 -- triggering --> E3
  W1 -- triggering --> E4
  W2 -- triggering --> E5
  W3 -- triggering --> E6
  W4 -- triggering --> E7
  class PL0,PL1,PL2,GP1,GP2,W0,W1,W2,D0,D1,D2,E1,E2,E3,E4,E5 impl
  class PL3,GP3,W3,W4,W5,D3,D4,E6,E7 evol
```

**Elementos**

| Elemento | Tipo | Descrição | Rastreio |
|---|---|---|---|
| Plateau 0 AS-IS | Plateau | Cadeia Planilha → macro → SAS → SQL 010 → Calculadora; sem versão, sem log (doc 06 §2) | Dores D1-D7 |
| Plateau 1 fim da F1 | Plateau | Motor C1 completo (C1.1-C1.6) respondendo em shadow; BRP Cash v1 ativa; comparador automático; primeiro produto cortado no marco M4 | AD-14; CoA-1 |
| Plateau 2 fim da F2 | Plateau | Motor oficial para os quatro macroprodutos; M1 completo; SAS, SQL 010 e Planilha fora da operação | Marco M5 |
| Plateau 3 fim da F3/F4 [EVOLUÇÃO] | Plateau | C3 e C2 em operação; efetivação no legado conforme decisão P4 | Marcos M6, M7 |
| Gap 1 | Gap | Regras do sugerido (macro, SQL 010) não documentadas; pipeline manual; sem auditoria; sem APIs | Lacunas 1, 2, 3, 6; risco R1 |
| Gap 2 | Gap | Sem staging, vigência agendada, perfis; Calculadora ainda depende do SQL 010 para os produtos não cortados | RF-05, RF-06, RF-10 |
| Gap 3 | Gap | Acordo de reciprocidade sem registro; sem eventos; onda manual na planilha; efetivação indefinida | Lacuna 4; risco R2 |
| F0..F5 | Work Package | Fases canônicas do brief §9 | Doc 09 |
| Entregáveis D0..D4 | Deliverable | Entregas principais por fase (brief §9; doc 09) | — |
| Marcos M1..M7 | Implementation Event | Datas do doc 09; são metas de trabalho a validar com a capacidade das equipes | Doc 09 |

**Relações**

| Origem | Relação | Destino | Significado |
|---|---|---|---|
| Plateau | association | Gap | O gap é a diferença entre dois plateaus consecutivos |
| Work Package | triggering | Work Package | Sequência das fases (com critérios de entrada do doc 09) |
| Work Package | realization | Deliverable | A fase produz o entregável |
| Deliverable | realization | Plateau | Os entregáveis levam ao estado-alvo |
| Work Package | triggering | Implementation Event | A fase atinge o marco |

**Notas de transição** (AD-14, RNF-08): o corte do legado é por produto (ordem sugerida Multipag, PIX, Arrecadação, Cobrança), com feature flag de fonte no Salesforce, comparação automática de tier, cluster, alvo, sugerido e alçada por dois ciclos consecutivos, e rollback por flag (minutos) ou por reativação de versão da BRP/parâmetros (segundos). Durante o Plateau 1 coexistem duas fontes de verdade; a auditoria (Cotação) é o instrumento que permite medir a divergência.

---

## 11. Rastreabilidade

| Elemento ArchiMate (viewpoint) | Bounded context (doc 05) | Contêiner C4 (doc 06) | Componente (doc 07) | Fase (doc 09) |
|---|---|---|---|---|
| Capability C1; Processos Simular preço, Contratar sem alçada; Serviço de Simulação de Preço; funções Classificar, Consultar cenário, Compor resposta | Cálculo de Preço (Pricing Engine) | svc-pricing | §4.1 svc-pricing | F1 (marco M4) |
| Capability C1.3; Processos Solicitar/Decidir aprovação; Serviço de Alçada; Data Objects Política de alçada, Pedido de aprovação | Alçada e Aprovação | svc-alcada | §4.2 svc-alcada | F1 (regras mínimas), F2 |
| Capability M1; Processo Publicar versão de parâmetros; Serviço de Parametrização; Data Objects Versão e Itens de parâmetro | Parametrização | svc-parametros, sf-parametrizacao | §4.3, §1.2 | F1 (básico), F2 (completo) |
| Capability M2; Component dbx-ppp; Artifacts Workflow e Tabelas Delta; Data Objects MPA, PPC, Matriz de Relacionamento, Indicadores | Modelagem de Preço (analítico) | dbx-ppp, dbx-brp | §6.1, §6.2 | F1 (marco M2) |
| Capability M2; Processo Publicar ciclo da BRP; Serviço de Publicação de Referência; Data Object Versão BRP | Publicação de Referência (BRP Cash) | svc-publicacao, sql-motor | §4.4, §5.1 | F1 (marco M2) |
| Capability M3; Serviço de Preço Vigente e Histórico; Data Object Foto de preço vigente e Histórico; Nodes Sistema de tarifas, SAS/SQL 010 | Preço Vigente e Histórico (Legado, ACL) | svc-legado-adapter | §4.5, §8 | F1 (foto), F2 (desligamento, marco M5) |
| Node Cadastro de cliente e grupo econômico | Cadastro de Cliente e Grupo Econômico | Fontes no Databricks | §6.2 | F1 |
| Capability M4; Technology Services Identidade e Observabilidade; Data Object Auditoria | Identidade e Acesso; Auditoria e Observabilidade | apigw-axway, aro, sql-motor | §7.2, §7.3 | F1, F2 |
| Interfaces REST /mpc/v1; Nodes Akamai, App Gateway, Axway | — (Open Host Service) | akamai, appgw-azure, apigw-axway | §2.1-§2.3 | F1 (APIs), F2 (outros canais) |
| Component sf-calculadora; Role Gerente de cash | — (canal) | sf-calculadora | §1.1 | F1 (shadow), F2 |
| Interface Tópicos de eventos; Node Service Bus; Application Event | — (Published Language via eventos) | sb-eventos | §5.2 | F1 (outbox), validação na F0 |
| System Software Control-M | — | controlm | §7.1 | F1 |
| Capability C3 [EVOL]; Processo Monitorar reciprocidade; Serviço de Reciprocidade; Data Object Acordo e Desvio | Reciprocidade | svc-reciprocidade | §4.6 | F3 (marco M6) |
| Capability C2 [EVOL]; Processo Executar onda; Serviço de Onda; Data Object Onda | Reprecificação | svc-reprecificacao, sf-reprecificacao | §4.7, §1.3 | F4 (marco M7) |
| Plateaus 0-3; Work Packages F0-F5 | — | — | §10 (matriz componente x fase) | F0-F5 |

Requisitos por viewpoint: Motivation (todos os RF/RNF selecionados); Business (RF-01, RF-02, RF-03, RF-05, RF-06, RF-11, RF-12); Application (RF-01..RF-09, RF-13, RNF-02, RNF-07, RNF-09); Information (RF-09, RNF-03, RNF-09); Technology (RNF-01, RNF-04, RNF-05, RNF-06, RNF-10); Implementation (RNF-08).

---

## 12. Apêndice — modelo em PlantUML ArchiMate (Layered Viewpoint)

Modelo textual para importação em ferramentas que suportem PlantUML com a biblioteca padrão ArchiMate (`!include <archimate/Archimate>`). **Não renderizado neste ambiente** (não há `plantuml.jar` disponível); a sintaxe segue as macros documentadas da stdlib e deve ser validada na ferramenta de destino. Cobre o Layered Viewpoint da §9.

```plantuml
@startuml mpc-layered-viewpoint
!include <archimate/Archimate>

title Motor de Precificação Cash — Layered Viewpoint (ArchiMate 3.2)

' ===== Motivação e Estratégia =====
Grouping(motiv, "Motivação e Estratégia") {
  Motivation_Goal(g1, "G1 Uplift com política nunca reduzir")
  Motivation_Goal(g3, "G3 Autonomia comercial com alçada controlada")
  Motivation_Principle(p5, "P5 Sugerido vem da BRP; motor só consulta")
  Strategy_Capability(c1, "C1 Cálculo, Simulação e Entrega de Preços")
  Strategy_Capability(m2, "M2 Preparação de Dados (PPP -> BRP Cash)")
}

' ===== Negócio =====
Grouping(biz, "Negócio") {
  Business_Role(rl1, "Gerente de cash")
  Business_Role(rl4, "Aprovador de alçada")
  Business_Role(rl3, "Analista de Precificação")
  Business_Process(pr1, "Simular preço")
  Business_Process(pr3, "Solicitar aprovação de alçada")
  Business_Process(pr4, "Decidir aprovação")
  Business_Process(pr6, "Publicar ciclo da BRP Cash")
  Business_Event(e2, "Preço negociado abaixo do sugerido")
  Business_Object(bo1, "Cotação")
  Business_Object(bo5, "Ciclo de precificação")
}

' ===== Aplicação =====
Grouping(app, "Aplicação") {
  Application_Interface(if1, "REST /mpc/v1 (Axway, OAuth2)")
  Application_Service(as1, "Serviço de Simulação de Preço")
  Application_Service(as2, "Serviço de Alçada")
  Application_Service(as5, "Serviço de Preço Vigente e Histórico")
  Application_Service(as4, "Serviço de Publicação de Referência")
  Application_Component(sfc, "sf-calculadora (LWC)")
  Application_Component(prc, "svc-pricing")
  Application_Function(f2, "Classificar (tier, cluster)")
  Application_Function(f3, "Consultar cenário na BRP")
  Application_Function(f4, "Compor resposta")
  Application_Function(f5, "Avaliar alçada")
  Application_Component(alc, "svc-alcada")
  Application_Component(leg, "svc-legado-adapter (ACL)")
  Application_Component(pub, "svc-publicacao")
  Application_Component(ppp, "dbx-ppp")
  Application_DataObject(do10, "Cotação e Auditoria")
  Application_DataObject(do2, "MPA e PPC (alvo e sugerido por cenário)")
}

' ===== Tecnologia =====
Grouping(tec, "Tecnologia") {
  Technology_Node(sf, "Salesforce FSC (SaaS)")
  Technology_Node(ak, "Akamai")
  Technology_Node(ag, "Azure Application Gateway")
  Technology_Node(ax, "Axway API Gateway")
  Technology_Node(aro, "ARO — OpenShift (pods Java)")
  Technology_Node(sql, "Azure SQL Database sql-motor")
  Technology_Node(dbx, "Databricks (job cluster, Delta)")
  Technology_SystemSoftware(cm, "Control-M")
  Technology_Artifact(img, "Imagens OCI svc-*")
  Technology_Artifact(wf, "Workflow ppp_ciclo_anomes")
}

' ===== Relações entre camadas =====
Rel_Realization(c1, g1, "realiza")
Rel_Realization(c1, g3, "realiza")
Rel_Realization(m2, g1, "realiza")
Rel_Influence(p5, c1, "orienta")
Rel_Realization(pr1, c1)
Rel_Realization(pr3, c1)
Rel_Realization(pr4, c1)
Rel_Realization(pr6, m2)

Rel_Assignment(rl1, pr1)
Rel_Assignment(rl1, pr3)
Rel_Assignment(rl4, pr4)
Rel_Assignment(rl3, pr6)
Rel_Triggering(pr1, e2)
Rel_Triggering(e2, pr3)
Rel_Triggering(pr3, pr4)
Rel_Access(pr1, bo1, "cria")
Rel_Access(pr6, bo5, "ativa")

Rel_Serving(as1, pr1)
Rel_Serving(as2, pr3)
Rel_Serving(as2, pr4)
Rel_Serving(as4, pr6)
Rel_Serving(as4, pr1, "BRP ativa")
Rel_Serving(sfc, pr1, "canal")
Rel_Serving(sfc, pr4, "fila do aprovador")
Rel_Realization(if1, as1)
Rel_Realization(if1, as2)
Rel_Realization(if1, as4)

Rel_Composition(prc, f2)
Rel_Composition(prc, f3)
Rel_Composition(prc, f4)
Rel_Composition(prc, f5)
Rel_Triggering(f2, f3)
Rel_Triggering(f3, f4)
Rel_Triggering(f4, f5)
Rel_Realization(prc, as1)
Rel_Realization(alc, as2)
Rel_Realization(leg, as5)
Rel_Realization(pub, as4)
Rel_Serving(as2, f5, "nível e papel")
Rel_Serving(as5, f3, "praticado")
Rel_Flow(ppp, pub, "BRP por anomes (reverse ETL)")
Rel_Access(prc, do10, "escreve")
Rel_Access(prc, do2, "lê")
Rel_Access(ppp, do2, "escreve")
Rel_Realization(do10, bo1)
Rel_Realization(do2, bo5)

Rel_Realization(sf, sfc)
Rel_Flow(sf, ag, "HTTPS Named Credential")
Rel_Flow(ak, ag, "HTTPS")
Rel_Flow(ag, ax, "HTTPS")
Rel_Serving(ax, sfc, "gateway")
Rel_Realization(aro, prc)
Rel_Realization(aro, alc)
Rel_Realization(aro, leg)
Rel_Realization(aro, pub)
Rel_Realization(dbx, ppp)
Rel_Assignment(img, aro)
Rel_Assignment(wf, dbx)
Rel_Serving(sql, aro, "JDBC")
Rel_Flow(dbx, sql, "JDBC reverse ETL")
Rel_Triggering(cm, dbx, "Jobs API")

legend right
  C2 e C3 [EVOLUÇÃO] omitidos deste viewpoint; ver §5 e §10.
  Preço sugerido é lido da BRP Cash por cenário (brief A0 §2).
endlegend
@enduml
```

Observações para importação: (1) ferramentas como Archi importam melhor via CSV ou Open Exchange Format; este PlantUML serve como modelo textual de referência e para renderização em wikis; (2) as macros `Grouping`, `Rel_*` e os nomes de elementos seguem a stdlib `archimate/Archimate`; se a ferramenta usar a versão antiga (`archimate/archimate.puml`), substituir `Rel_Realization` por `Rel_Realization_Up`/`_Down` conforme o layout desejado; (3) C2 e C3 foram omitidos do modelo por serem [EVOLUÇÃO]; ao incluí-los, marcar com `<<evol>>` e estilo tracejado na ferramenta.
