# 07 — Componentes da Solução: Definição, Justificativa e Requisitos Atendidos

| Campo | Valor |
|---|---|
| Versão | 1.1 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Revisão | Revisão 1.1 (2026-09-18): preço sugerido passa a ser lido da BRP Cash por cenário; MPA renomeada para Matriz de Cenários de Preço |
| Fontes | `anexos/A0-brief-decisoes.md` (§6 decisões AD-01..AD-14 e nomes canônicos; §7 requisitos; §9 roadmap; §10 riscos); `stack-tech.md`; `docs-precificacao/00-doc-negocio.md`; `docs-precificacao/07-planilha-ano1-fluxo.md`; `06-arquitetura-solucao.md` |

Este documento é o catálogo de componentes do Motor de Precificação Cash (MPC). Cada ficha usa o nome canônico do brief §6, indica a tecnologia e a responsabilidade, justifica a escolha frente às alternativas consideradas e lista os requisitos funcionais (RF) e não funcionais (RNF) atendidos. Componentes de C2 e C3 são **[EVOLUÇÃO — a detalhar com o negócio]**. Ao final, as matrizes componente x requisito e componente x fase.

Legenda de status: **novo** (a construir), **existente** (plataforma corporativa reutilizada), **a desligar** (legado substituído).

Convenção de referências: "lacuna n" refere-se ao brief `anexos/A0` §8; "D1-D7" são as dores do AS-IS e "P1-P10" as decisões pendentes do doc `06-arquitetura-solucao.md` (§2 e §11); R1-R10 são os riscos do brief §10; `NN:L<linha>` abrevia `docs-precificacao/<arquivo>:L<linha>` para os fluxos 01 a 07 (por exemplo, `07:L33` é `docs-precificacao/07-planilha-ano1-fluxo.md:L33`); `A1` e `A2` são os anexos.

---

## 1. Canais (Salesforce FSC)

### 1.1 sf-calculadora

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Calculadora de Preços Cash (Salesforce) |
| Tipo | Interface de usuário (LWC) |
| Tecnologia | Salesforce Financial Services Cloud, Lightning Web Components, Apex apenas como proxy HTTP via Named Credential |
| Responsabilidade | Jornada do gerente: selecionar cliente/produto, informar volumetria e preço negociado, exibir praticado/alvo/sugerido, cenários, uplift e alçada; contratar sem alçada no sugerido ou abrir pedido de aprovação; exibir preço vigente e histórico de 12 meses; fila do aprovador; exibir "última cotação conhecida" em contingência |
| Capacidade / BC | C1 (C1.1 a C1.4, C1.6); BC Cálculo de Preço e Alçada como consumidor (Open Host Service) |
| Interfaces | Entrada: usuário; eventos `PrecoAprovado` (Platform Event via integração). Saída: `POST /precos/simulacoes`, `GET /precos/.../vigente`, `.../historico`, `POST /alcadas/pedidos`, `GET /alcadas/pedidos`, `POST /alcadas/pedidos/{id}/decisao` via appgw-azure → apigw-axway |
| Dados que possui | Nenhum dado de preço persistido; guarda `cotacao_id`, versões e carimbo na Oportunidade; cache local da última cotação para contingência |
| Justificativa | AD-05: o Salesforce FSC é a ferramenta do comercial hoje (a Calculadora já existe nele, `07-planilha-ano1-fluxo.md:L40-42`); mantê-lo como canal evita reeducar o usuário. A lógica sai do SQL 010 e vai para o backend, nunca para Apex, porque Apex não é versionável por parâmetro, não é auditável como o motor e não serve a outros canais (RF-07). |
| Alternativas consideradas | Manter Calculadora ligada ao SQL 010 (mantém a dor D1/D4); Apex com regras (risco R6); front próprio (segundo canal para o mesmo usuário) |
| RF atendidos | RF-01, RF-02, RF-03, RF-04 (exibição), RF-07 (como consumidor de referência) |
| RNF atendidos | RNF-01 (última cotação conhecida), RNF-04 (SSO e perfis do Salesforce), RNF-08 (feature flag por produto para shadow) |
| Fase | F1 (shadow e piloto), F2 (corte por produto) |
| Riscos / dependências | R6 (lógica vazando para Apex); dependência de Named Credential e cliente OAuth no Axway; limites de callout do Salesforce (máximo de 120 s; configurar 5 s para falhar rápido, RNF-02; tamanho de resposta) |
| Status | Existente (Calculadora) com reconstrução das integrações: **novo** na prática |

### 1.2 sf-parametrizacao

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Console de Parametrização do Motor |
| Tipo | Interface de usuário (LWC) |
| Tecnologia | Salesforce FSC, LWC, Named Credential |
| Responsabilidade | Telas de manutenção de catálogo de produtos, domínios, tiers, regras de cluster, percentis, premissas de desconto/alçada/remuneração, listas de exceção e janelas; fluxo rascunho → staging → aprovação → publicação/agendamento; simulação "em staging"; comparação de versões; catálogo e ativação de versões da BRP Cash |
| Capacidade / BC | M1 Parametrização; M2 Publicação de Referência (tela de ativação); M4 (perfis) |
| Interfaces | Saída: `/parametros/*`, `/brp/*`, `POST /precos/simulacoes` com cabeçalho de versão candidata |
| Dados que possui | Nenhum; tudo via API |
| Justificativa | AD-05 e AD-06: um único front e um único modelo de acesso (perfis do AD via Salesforce). As telas são CRUD tabular com workflow simples, que o LWC comporta. Evita criar segundo front React com segunda esteira e segundo modelo de autenticação. |
| Alternativas consideradas | Front React próprio hospedado no ARO (só se a UX de administração de tabelas grandes não couber no LWC; registrar como alternativa se F2 mostrar limitação); edição via planilha importada (retorna à dor D2) |
| RF atendidos | RF-05, RF-06, RF-10 (interface com perfis), RF-13 (ativação da BRP) |
| RNF atendidos | RNF-04, RNF-07, RNF-09 (visualização de versões) |
| Fase | F1 (versionamento básico e ativação de BRP), F2 (completo: staging, agendamento, perfis) |
| Riscos / dependências | R10 (governança de quem aprova); R8 (capacidade Salesforce); limites de governor para grades grandes (paginação obrigatória) |
| Status | Novo |

### 1.3 sf-reprecificacao [EVOLUÇÃO — a detalhar com o negócio]

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Console de Onda de Reprecificação |
| Tipo | Interface de usuário (LWC) |
| Tecnologia | Salesforce FSC, LWC |
| Responsabilidade | Planejar onda (escopo, calendário, meta), revisar elegíveis e preços propostos, aprovar em lote, acompanhar efetivação e resultado; receber alertas de reciprocidade como tarefas do gerente |
| Capacidade / BC | C2 (C2.1, C2.4, C2.5); consumidor de eventos de C3 |
| Interfaces | Saída: `/reprecificacao/*`, `/alcadas/*`. Entrada: eventos `ClienteElegivelParaReprecificacao`, `OndaCalculada` |
| Dados que possui | Nenhum de preço; tarefas/alertas como registros Salesforce |
| Justificativa | AD-05 e AD-08: a onda é um processo comercial com aprovação; o Salesforce já tem tarefas, filas e aprovação, e é onde o gerente vive. |
| Alternativas consideradas | Planilha exportada (AS-IS Saída 1, `07:L33`); workflow em ferramenta BPM (componente novo sem necessidade) |
| RF atendidos | RF-11 |
| RNF atendidos | RNF-04, RNF-08 |
| Fase | F4 |
| Riscos / dependências | R2 (C2 indefinido); depende de svc-reprecificacao e da decisão de efetivação (P4) |
| Status | Novo (evolução) |

---

## 2. Borda

### 2.1 akamai

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Porta de entrada externa |
| Tipo | CDN / WAF / proteção de borda |
| Tecnologia | Akamai (existente) |
| Responsabilidade | Terminação TLS externa, proteção DDoS/WAF, roteamento para o Application Gateway para canais fora da rede corporativa (integradores, plataformas externas) |
| Capacidade / BC | C1.5 (APIs para canais); M4 |
| Interfaces | Entrada: HTTPS de canais externos. Saída: HTTPS para appgw-azure |
| Dados que possui | Nenhum dado de negócio |
| Justificativa | `stack-tech.md:L9` define o fluxo Akamai → Load Balancer → Axway → microsserviços para canais externos. Não é escolha, é padrão; o Salesforce (SaaS externo) também entra por aqui ou por rota dedicada do App Gateway, conforme política de rede a confirmar na F0. |
| Alternativas consideradas | Nenhuma (padrão corporativo) |
| RF atendidos | RF-07 |
| RNF atendidos | RNF-04, RNF-10 |
| Fase | F2 (outros canais); possivelmente F1 se o Salesforce entrar por Akamai |
| Riscos / dependências | Política de rede para tráfego Salesforce → Azure (IP allowlist) |
| Status | Existente |

### 2.2 appgw-azure

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Balanceador de aplicação |
| Tipo | Load balancer L7 / WAF |
| Tecnologia | Azure Application Gateway com WAF, zona-redundante (existente) |
| Responsabilidade | Balanceamento, WAF, terminação/re-encriptação TLS, roteamento por caminho para o Axway; ponto de entrada das Named Credentials do Salesforce |
| Capacidade / BC | C1.5; M4 |
| Interfaces | Entrada: HTTPS de akamai e do Salesforce. Saída: HTTPS para apigw-axway |
| Dados que possui | Nenhum |
| Justificativa | `stack-tech.md:L8-9`; padrão corporativo. |
| Alternativas consideradas | Nenhuma |
| RF atendidos | RF-07 |
| RNF atendidos | RNF-01 (zona-redundante), RNF-04, RNF-10 |
| Fase | F1 |
| Riscos / dependências | Certificados e regras WAF que podem bloquear payloads JSON legítimos (ajustar exclusões) |
| Status | Existente |

### 2.3 apigw-axway

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Gateway de APIs do Motor |
| Tipo | API Gateway |
| Tecnologia | Axway API Gateway / API Manager (existente) |
| Responsabilidade | Publicar as APIs `/mpc/v1/*` (Open Host Service): autenticação OAuth2 client credentials por canal, validação de JWT do usuário, quotas e throttling, versionamento de contrato, logs de acesso, catálogo para integradores |
| Capacidade / BC | C1.5 (RF-07); M4 |
| Interfaces | Entrada: HTTPS de appgw-azure. Saída: HTTP(S) para serviços no ARO (svc-pricing, svc-alcada, svc-parametros, svc-publicacao, svc-reciprocidade, svc-reprecificacao) |
| Dados que possui | Aplicações cliente, chaves, políticas, métricas de uso |
| Justificativa | `stack-tech.md:L7`; é o ponto único onde "APIs para canais, plataformas, integradores" (`00-doc-negocio.md:L15`) ganham segurança e governança sem código nos serviços. Versionamento de API por caminho no Axway permite evoluir contratos sem quebrar o Salesforce. |
| Alternativas consideradas | Ingress do OpenShift direto (sem OAuth2 centralizado nem catálogo); Azure API Management (não está na stack) |
| RF atendidos | RF-07, RF-09 (logs de acesso complementam auditoria) |
| RNF atendidos | RNF-02 (throttling protege o motor), RNF-04, RNF-05 (métricas de uso), RNF-10 |
| Fase | F1 |
| Riscos / dependências | Latência adicional do gateway (orçar ~20-40 ms no p95); processo de publicação de APIs corporativo pode ser lento (planejar na F0) |
| Status | Existente |

---

## 3. Plataforma de execução

### 3.1 aro

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Plataforma de contêineres |
| Tipo | Plataforma Kubernetes gerenciada |
| Tecnologia | Azure Red Hat OpenShift (existente); namespaces `mpc-dev`, `mpc-hml`, `mpc-prd` |
| Responsabilidade | Executar os microsserviços Java: deploy, autoescala (HPA), health checks, PodDisruptionBudget, secrets, rede interna, logs/métricas/tracing padrão, esteira de deploy |
| Capacidade / BC | Todos os BCs de serviço; M4 (observabilidade) |
| Interfaces | Entrada: apigw-axway, Control-M (endpoints de lote), Databricks (`/brp/validar`). Saída: sql-motor, sb-eventos, legado |
| Dados que possui | Configuração e secrets |
| Justificativa | `stack-tech.md:L6`: plataforma corporativa onde serviços Java e Python são hospedados. Não é escolha. Serviços stateless permitem 3+ réplicas e rolling update sem indisponibilidade (RNF-01). |
| Alternativas consideradas | Azure Functions / App Service (fora da stack; menos controle de rede e observabilidade padronizada) |
| RF atendidos | — (habilitador) |
| RNF atendidos | RNF-01, RNF-02 (escala horizontal), RNF-04, RNF-05, RNF-10 |
| Fase | F1 |
| Riscos / dependências | R8 (capacidade de operação em OpenShift); cotas de namespace |
| Status | Existente |

---

## 4. Microsserviços (Java, Spring Boot, no ARO)

### 4.1 svc-pricing

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Cálculo de Preço (núcleo do motor) |
| Tipo | Microsserviço transacional |
| Tecnologia | Java 21, Spring Boot 3, Spring Data JDBC, Caffeine, Resilience4j, OpenAPI; 3+ réplicas |
| Responsabilidade | Dado cliente + produto + volumetria + contexto: resolver segmento/região, tier, cluster; consultar o cenário na MPA (`matriz_cenarios_preco`) e ler alvo, sugerido e percentis pré-computados (lookup, sem fórmula de preço; revisão 1.1); aplicar "nunca reduzir" ao alvo com o praticado; expor cenários (percentis, tier ±1 lidos da mesma MPA) e calcular uplift por cenário (única conta online); obter praticado via Adaptador; solicitar alçada ao svc-alcada se negociado < sugerido; persistir cotação com versões e `cenario_id`; modo staging por cabeçalho; cálculo em lote para C2 |
| Capacidade / BC | C1 (C1.1, C1.2, C1.6); BC Cálculo de Preço (core) |
| Interfaces | Entrada: `POST /precos/simulacoes`, `/lote` [EVOL], `GET /precos/{grupo}/{produto}/referencia`, `GET /cotacoes/{id}`; eventos `VersaoBrpPublicada`, `VersaoParametroPublicada` (invalidação de cache). Saída: sql-motor (leitura de `v_brp_ativa`, parâmetros vigentes; escrita de `cotacao`); svc-alcada; svc-legado-adapter |
| Dados que possui | `cotacao` (dono); lê BRP (`matriz_cenarios_preco` com alvo e sugerido por cenário, `posicao_preco_cliente_produto`) e parâmetros (não é dono) |
| Justificativa | AD-04: as regras online são tabelas de faixas (tier, regra de cluster, alçada) e lookup de cenários pré-computados; o motor não é engine de fórmulas de desconto, pois o sugerido vem pronto da BRP (revisão 1.1). Isso reforça Java + tabelas: Java na stack para transações (`stack-tech.md:L3`); sem licença nem lock-in. AD-11: cache em memória por instância é suficiente para MPA (milhares de linhas) e parâmetros; Redis não está na stack e só entraria por evidência de latência. As regras da macro/SQL 010 que gerem o sugerido (R1) são absorvidas pelo pipeline e pela parametrização, não por estratégias deste serviço; se um dia FICO for necessário para gradação de C2, encaixa-se atrás da interface do svc-reprecificacao. |
| Alternativas consideradas | FICO Blaze/Decision Modeler (licença, skill, lock-in; regras atuais não justificam; reavaliar na F3/F5 por evidência); manter no SQL 010 (não auditável, não versionável, sem API); Python (stack reserva Python para dados) |
| RF atendidos | RF-01, RF-02, RF-03 (orquestra), RF-04 (orquestra via Adaptador), RF-07, RF-09 (cotação), RF-11 (cálculo em lote, EVOL) |
| RNF atendidos | RNF-01, RNF-02, RNF-03, RNF-07, RNF-09, RNF-10 |
| Fase | F1 (MVP), F2 (regras completas), F4 (lote) |
| Riscos / dependências | R1 indireto (depende de a BRP trazer `preco_sugerido` por cenário; a regra é do pipeline), R3 (qualidade da BRP, agora inclui o sugerido), R7 (transição); depende de svc-parametros, svc-publicacao, svc-legado-adapter, sql-motor |
| Status | Novo |

### 4.2 svc-alcada

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Alçada e Aprovação |
| Tipo | Microsserviço transacional |
| Tecnologia | Java 21, Spring Boot 3 |
| Responsabilidade | Classificar desvio entre negociado e sugerido em nível de alçada e papel aprovador conforme `politica_alcada` (por produto, segmento, faixa de desvio %, valor de uplift perdido); registrar pedidos e decisões; publicar `PrecoAprovado`/`PrecoRecusado`; servir C1 e C2 (Customer/Supplier) |
| Capacidade / BC | C1.3, C2.4; BC Alçada e Aprovação (core compartilhado) |
| Interfaces | Entrada: `POST /alcadas/avaliacoes`, `POST /alcadas/pedidos`, `GET /alcadas/pedidos`, `POST /alcadas/pedidos/{id}/decisao`. Saída: sql-motor (`pedido_aprovacao`, leitura de `politica_alcada`); sb-eventos |
| Dados que possui | `pedido_aprovacao` (dono); `politica_alcada` é versionada por svc-parametros mas lida aqui |
| Justificativa | AD-04 e brief §5 (Customer/Supplier em vez de Shared Kernel): separar alçada do cálculo evita que C2 acople ao svc-pricing e mantém a política de alçada como parâmetro versionado. A regra "se negociado ≥ sugerido, sem alçada" (`00-doc-negocio.md:L22`) é trivial; a complexidade está nos níveis e aprovadores, ainda não definidos (lacuna 3), o que reforça a escolha de tabela parametrizada em vez de engine. |
| Alternativas consideradas | Alçada dentro do svc-pricing (acoplaria C2 e dificultaria evolução); processo de aprovação nativo do Salesforce (Approval Process) para o fluxo de decisão, mantendo a classificação no serviço: alternativa válida para a fila do aprovador, a avaliar na F1 |
| RF atendidos | RF-03, RF-09 (decisões auditadas), RF-11 (aprovação de onda, EVOL) |
| RNF atendidos | RNF-03, RNF-04 (papéis), RNF-07 |
| Fase | F1 (regras mínimas), F2 (níveis completos), F4 (lote) |
| Riscos / dependências | Lacuna 3 (níveis e aprovadores); R10; depende de perfis no JWT |
| Status | Novo |

### 4.3 svc-parametros

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Parametrização |
| Tipo | Microsserviço transacional |
| Tecnologia | Java 21, Spring Boot 3, Flyway, scheduler para vigência agendada |
| Responsabilidade | Ciclo de vida de versões de parâmetro (rascunho, staging, aprovada, agendada, publicada, encerrada, revertida); itens tipados (catálogo, domínios, tier, regra de cluster, percentis, desconto, alçada, remuneração, exceções, janelas, reciprocidade [EVOL]); resolução do conjunto vigente em uma data; diff entre versões; autorização por perfil e segregação de funções; trilha de auditoria; publicação de `VersaoParametroPublicada` |
| Capacidade / BC | M1; BC Parametrização (supporting) |
| Interfaces | Entrada: `/parametros/*`. Saída: sql-motor (`parametro_versao`, `parametro_item_*`, `politica_alcada`, `auditoria`); sb-eventos |
| Dados que possui | Todas as tabelas de parâmetro e a auditoria de parâmetros (dono) |
| Justificativa | AD-06: versionamento, staging, vigência agendada e auditoria são requisitos explícitos (`00-doc-negocio.md:L13-14`, `L17-18`, `L42`); só um serviço com modelo relacional versionado atende a todos. O staging é implementado como estado de versão consultável pelo svc-pricing por cabeçalho, o que elimina um ambiente físico e garante teste fiel à produção. Azure SQL porque as vigências e versões exigem integridade referencial e consultas por intervalo. |
| Alternativas consideradas | Parâmetros em configmap/arquivo (sem auditoria, sem vigência, sem perfis); Custom Metadata do Salesforce (prende parâmetros ao canal e a outros canais não chegariam, RF-07); FICO como repositório de regras (versionamento bom, mas custo e lock-in, AD-04) |
| RF atendidos | RF-05, RF-06, RF-09, RF-10, RF-13 (parâmetros lidos pelo pipeline) |
| RNF atendidos | RNF-03, RNF-04, RNF-07, RNF-09 |
| Fase | F1 (versionamento básico e conjunto vigente), F2 (staging, agendamento, perfis, diff) |
| Riscos / dependências | Lacuna 2 (conteúdo das premissas) define o catálogo de tipos; R9 (regras divergentes por produto); R10 |
| Status | Novo |

### 4.4 svc-publicacao

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Publicação da BRP Cash |
| Tipo | Microsserviço transacional / operacional |
| Tecnologia | Java 21, Spring Boot 3; procedures T-SQL de ativação |
| Responsabilidade | Catálogo de versões da BRP Cash por `anomes`; validação pós-carga (contagens `stg_*` x métricas do pipeline, integridade relacional, checks de sanidade); ativação atômica (swap de partição/tabela) com perfil publicador; rollback para versão anterior; publicação de `VersaoBrpPublicada`; exposição do `anomes` ativo |
| Capacidade / BC | M2; BC Publicação de Referência (supporting) |
| Interfaces | Entrada: `POST /brp/versoes/{anomes}/validar` (dbx-ppp), `/ativar`, `/reverter` (sf-parametrizacao), `GET /brp/*`. Saída: sql-motor (`versao_brp`, procedures); sb-eventos |
| Dados que possui | `versao_brp` (dono); executa as procedures sobre as entidades da BRP |
| Justificativa | AD-03: separar a carga (Databricks) da ativação (serviço com autorização e auditoria) resolve a governança de "quem publica" (R10) e dá rollback em segundos (AD-13). Um serviço pequeno é preferível a lógica de ativação embutida no notebook, que não teria perfil nem trilha. |
| Alternativas consideradas | Ativação direta pelo job Databricks (sem perfil/aprovação humana); Azure Data Factory com pipeline de ativação (componente adicional, equivalente; registrado como alternativa) |
| RF atendidos | RF-08 (validação pós-carga), RF-09, RF-13 |
| RNF atendidos | RNF-01 (rollback de versão), RNF-03, RNF-06, RNF-09 |
| Fase | F1 |
| Riscos / dependências | R3; depende de layout de partição no sql-motor e do contrato de dados da BRP (F0) |
| Status | Novo |

### 4.5 svc-legado-adapter

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Adaptador de Legado (preço vigente e histórico) |
| Tipo | Microsserviço interno (anti-corruption layer) |
| Tecnologia | Java 21, Spring Boot 3, Resilience4j (timeout, circuit breaker); conector ao sistema de tarifas a definir (REST, MQ ou DB link) |
| Responsabilidade | Fornecer preço praticado vigente e histórico de 12 meses com estratégias `foto` (tabelas carregadas pelo Databricks), `online` (consulta ao legado) e `auto` (online com fallback para foto); traduzir o modelo do legado para o modelo do motor; carimbar origem e data; [EVOL] efetivar tarifa quando decidido |
| Capacidade / BC | C1.4, M3; BC Preço Vigente e Histórico (external/ACL) |
| Interfaces | Entrada: `GET /legado/precos/{grupo}/{produto}/vigente`, `/historico`, `POST /legado/tarifas/efetivacoes` [EVOL] (interno, não exposto no Axway). Saída: sql-motor (`preco_vigente_foto`, `historico_preco`); sistema de tarifas |
| Dados que possui | Nenhum próprio; lê foto e histórico carregados por dbx-ppp |
| Justificativa | AD-10: a premissa `00-doc-negocio.md:L29` diz que o vigente e o histórico vêm pelo Databricks, mas `L16` exige "informação mais atualizada disponível", e o AS-IS usa a `TARIFA` da base analítica (D5). Duas estratégias atrás de uma interface deixam a decisão de latência com o negócio (lacuna 7, R4) sem mudar o motor. O ACL impede que o modelo de tarifas do legado contamine o domínio de preço (padrão do brief §5). |
| Alternativas consideradas | Só foto (vigente defasado até 1 mês); só online (motor refém da disponibilidade do legado, contrária a RNF-01); svc-pricing acessando o legado diretamente (acoplamento) |
| RF atendidos | RF-04, RF-07 (informação mais atual), RF-11 (efetivação, EVOL) |
| RNF atendidos | RNF-01 (fallback), RNF-02 (timeout curto), RNF-06 (bases de origem não substituídas) |
| Fase | F1 (foto), F2 (online, se decidido), F4 (efetivação, se decidido) |
| Riscos / dependências | R4; P4 (efetivação); P5 (latência); depende do dono do legado para conector e SLA |
| Status | Novo |

### 4.6 svc-reciprocidade [EVOLUÇÃO — a detalhar com o negócio]

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Gestão de Reciprocidade |
| Tipo | Microsserviço transacional + job periódico |
| Tecnologia | Java 21, Spring Boot 3; execução do monitoramento disparada por Control-M |
| Responsabilidade | Registrar acordo (volumetria, saldo, produtos, vigência, tolerâncias) na contratação; comparar acordado x realizado com Indicadores de Reciprocidade da BRP; detectar desvios com regras parametrizadas; gerar elegibilidade para C2; publicar eventos; alimentar alertas ao gerente |
| Capacidade / BC | C3 (C3.1 a C3.4); BC Reciprocidade (core, evolução) |
| Interfaces | Entrada: `POST /reciprocidade/acordos`, `POST /reciprocidade/monitoramentos` (Control-M), `GET /reciprocidade/desvios`, `/elegiveis`; evento `VersaoBrpPublicada`. Saída: sql-motor (`acordo_reciprocidade`, `desvio_reciprocidade`, leitura de `indicadores_reciprocidade`); sb-eventos (`AcordoRegistrado`, `DesvioReciprocidadeDetectado`, `ClienteElegivelParaReprecificacao`) |
| Dados que possui | `acordo_reciprocidade`, `desvio_reciprocidade` (dono) |
| Justificativa | AD-07 e decisão do brief §3 de manter C3 como capacidade própria: o acordo nasce na negociação (transacional), o monitoramento roda continuamente e serve a outros consumidores além de C2. Indicadores continuam vindo do Databricks (não se duplica cálculo analítico). Eventos (AD-09) desacoplam C3 de C2. |
| Alternativas consideradas | Dentro do pipeline Databricks (perde acordo transacional e integração com o gerente); sub-módulo do svc-reprecificacao (acopla ciclos de vida distintos) |
| RF atendidos | RF-12, RF-09 |
| RNF atendidos | RNF-03, RNF-05, RNF-07 (tolerâncias parametrizadas) |
| Fase | F3 |
| Riscos / dependências | R2; P7 (onde o acordo é registrado hoje); depende de sb-eventos ou outbox e de `parametro_item_reciprocidade` |
| Status | Novo (evolução) |

### 4.7 svc-reprecificacao [EVOLUÇÃO — a detalhar com o negócio]

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Serviço de Onda de Reprecificação |
| Tipo | Microsserviço de orquestração + processamento em lote |
| Tecnologia | Java 21, Spring Boot 3, Spring Batch (ou processamento assíncrono por fatias); disparo por Control-M |
| Responsabilidade | Ciclo da onda: planejamento (escopo, calendário, meta, gradação), seleção de elegíveis (eventos de C3 + filtros pré-computados no Databricks + regras parametrizadas), cálculo em lote via svc-pricing, aprovação via svc-alcada, efetivação (via Adaptador, se decidido) e acompanhamento do uplift realizado |
| Capacidade / BC | C2 (C2.1 a C2.5); BC Reprecificação (core, evolução) |
| Interfaces | Entrada: `/reprecificacao/ondas/*`; eventos de C3 e `PrecoAprovado`. Saída: svc-pricing (`/lote`), svc-alcada, svc-legado-adapter [efetivação], sql-motor (`onda_reprecificacao`, `onda_cliente_produto`), sb-eventos |
| Dados que possui | `onda_reprecificacao`, `onda_cliente_produto` (dono) |
| Justificativa | AD-08: reusar svc-pricing garante que preço de onda e preço de balcão saem da mesma versão de BRP e de parâmetros, com a mesma auditoria (RNF-09). O Databricks pré-computa filtros de elegibilidade porque são consultas analíticas sobre 12 meses; o serviço orquestra, aprova e efetiva porque isso exige workflow e integração com o Salesforce. |
| Alternativas consideradas | Tudo em Databricks (sem aprovação nem integração); planilha (AS-IS Saída 1); FICO para gradação (reavaliar se a política de gradação se tornar complexa, AD-04) |
| RF atendidos | RF-11, RF-09 |
| RNF atendidos | RNF-03, RNF-07, RNF-09 |
| Fase | F4 |
| Riscos / dependências | R2; P4 (efetivação); depende de svc-reciprocidade (F3), do endpoint de lote em svc-pricing e da gradação Stickiness x Impacto como parâmetro |
| Status | Novo (evolução) |

---

## 5. Dados de serviço e mensageria

### 5.1 sql-motor

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Base de serviço do Motor |
| Tipo | Banco relacional gerenciado |
| Tecnologia | Azure SQL Database, zona-redundante, réplica de leitura; tier a dimensionar na F0 (Business Critical ou Hyperscale); TDE; particionamento por `anomes` e por mês em `cotacao` |
| Responsabilidade | Persistir a BRP Cash ativa e versões anteriores (MPA como `matriz_cenarios_preco` com `preco_alvo` e `preco_sugerido` por cenário, PPC com `cenario_id` e `preco_sugerido` do cliente, Matriz de Relacionamento, Indicadores, foto de vigente, histórico), parâmetros versionados, políticas de alçada, cotações, pedidos de aprovação, auditoria e, em evolução, acordos, desvios e ondas; procedures de ativação de versão |
| Capacidade / BC | Todos os BCs de serviço (cada serviço é dono de seu schema) |
| Interfaces | Entrada: JDBC dos serviços; JDBC do dbx-ppp em `stg_*`. Saída: exportação periódica de `cotacao`/`auditoria` para o Delta |
| Dados que possui | Modelo da §6 de `06-arquitetura-solucao.md` |
| Justificativa | AD-02: as entidades são matrizes por chave composta, vigências e versões com integridade referencial; consultas são pontuais por chave com joins de parâmetros (o lookup do cenário na MPA é a consulta central do motor, revisão 1.1). Isso é relacional. Azure SQL está na stack; documentos aninhados (MongoDB) não trazem vantagem e trariam fornecedor e operação novos. Zona-redundância e réplica atendem AD-13. |
| Alternativas consideradas | MongoDB (modelo tabular não se beneficia; fora da stack; reavaliar apenas para `cotacao` por volume); consultar o Databricks diretamente no online (SQL Warehouse tem latência e custo inadequados a p95 < 500 ms e não é transacional); PostgreSQL no ARO (operação própria, sem ganho) |
| RF atendidos | RF-01, RF-04 (foto e histórico), RF-05, RF-09, RF-13 (destino do reverse ETL) |
| RNF atendidos | RNF-01, RNF-02, RNF-03, RNF-06, RNF-09, RNF-10 |
| Fase | F1 |
| Riscos / dependências | Dimensionamento; crescimento de `cotacao` (retenção P10); permissões append-only na auditoria |
| Status | Novo |

### 5.2 sb-eventos

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Barramento de eventos de domínio |
| Tipo | Mensageria (tópicos/assinaturas) |
| Tecnologia | Azure Service Bus Premium (a validar, não consta da stack); fallback: tabela `evento_outbox` em cada serviço + publicador/polling |
| Responsabilidade | Transportar eventos de domínio entre contextos: publicação de versões (BRP e parâmetros), decisões de alçada, desvios de reciprocidade, elegibilidade, ondas; notificação a canais |
| Capacidade / BC | Transversal; essencial para C3 → C2 e para invalidação de cache |
| Interfaces | Produtores: svc-publicacao, svc-parametros, svc-alcada, svc-reciprocidade, svc-reprecificacao. Consumidores: svc-pricing, svc-reciprocidade, svc-reprecificacao, integração Salesforce |
| Dados que possui | Mensagens transientes (retenção curta); dead-letter |
| Justificativa | AD-09: chamadas REST síncronas entre C3 e C2 criariam acoplamento temporal e retrabalho de retry; eventos com envelope versionado permitem adicionar consumidores (alertas, observabilidade) sem alterar produtores. É o único componente fora da stack; por isso a interface de domínio é a mesma na implementação outbox, que só perde latência (polling) e fan-out fácil. |
| Alternativas consideradas | REST síncrono (acoplamento); Kafka/Event Hubs (fora da stack e sobredimensionado); Platform Events do Salesforce como barramento central (prende integração ao canal); outbox + polling (fallback adotado) |
| RF atendidos | RF-11, RF-12 (dependência C3 → C2), RF-06 (publicação notifica motor) |
| RNF atendidos | RNF-02 (invalidação de cache), RNF-05 (eventos rastreáveis por correlação) |
| Fase | F1 (publicação e alçada, possivelmente via outbox), F3 (reciprocidade), F4 (ondas) |
| Riscos / dependências | R5; P6 (aprovação na stack) |
| Status | Novo (pendente de validação) |

---

## 6. Plataforma analítica (Databricks)

### 6.1 dbx-ppp

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Pipeline de Preparação de Preços (PPP) |
| Tipo | Pipeline analítico orquestrado |
| Tecnologia | Databricks Workflows, PySpark (Pandas API on Spark na transição), Delta Lake, Unity Catalog, Databricks Asset Bundles; expectations de qualidade (DLT ou Great Expectations); JDBC para Azure SQL |
| Responsabilidade | Portar os 7 notebooks como tarefas (T1-T7), validar fontes (T0), gerar foto do legado (T8), validar a BRP (T9), executar reverse ETL para `stg_*` (T10) e solicitar validação/ativação (T11); calcular o preço alvo e o **preço sugerido por cenário** (etapa `preco_sugerido_cenario` em T6, regra hoje na macro "Preço por Produto"/`SIMUL_PRECO_POR_PRODUTO`, a levantar na lacuna 1; revisão 1.1) e gravá-los na MPA e na PPC; parametrizar `anomes`, janelas, listas e versão de parâmetros (lidos de svc-parametros); pré-computar filtros de elegibilidade para C2 [EVOL]; comparador do shadow run |
| Capacidade / BC | M2; BC Modelagem de Preço (supporting); apoio a C2 e à transição |
| Interfaces | Entrada: Jobs API (Control-M), tabelas bronze governadas, `GET /parametros/vigentes`. Saída: dbx-brp (Delta), sql-motor (`stg_*`), `POST /brp/versoes/{anomes}/validar` |
| Dados que possui | Silver (`*_vats`, L3M) e gold (BRP) via dbx-brp |
| Justificativa | AD-01: as bases já estão no Databricks (`00-doc-negocio.md:L27`, `L30`) e o negócio já escreve Python; portar para PySpark é incremental. Microsserviços Python no ARO exigiriam extrair dezenas de milhões de linhas por ciclo via JDBC (lento, ocupa warehouse), Delta Sharing (copia dado, governança de shares) ou exportação para storage (recria a pasta `entradas`), além de reimplementar versionamento, lineage e qualidade que o Delta/Unity Catalog já têm. Control-M dispara e monitora, mas não orquestra tarefas internas (retry, dependências e logs por tarefa são nativos do Workflow). |
| Alternativas consideradas | Microsserviços Python + Control-M (rejeitada, ver acima); Azure Data Factory como orquestrador (componente extra; aceitável só para o reverse ETL); manter notebooks locais (AS-IS) |
| RF atendidos | RF-08, RF-13, RF-11 (filtros de elegíveis, EVOL) |
| RNF atendidos | RNF-05 (alertas de execução), RNF-06, RNF-08 (comparador do shadow), RNF-09 (reprodutibilidade por `anomes` e versão), RNF-10 |
| Fase | F1 (porte e BRP v1), F2 (validações completas), F4 (filtros C2) |
| Riscos / dependências | R1 (dono do risco na revisão 1.1: a regra do sugerido por cenário não é portável até o levantamento; enquanto isso a BRP v1 pode importar o sugerido da planilha do ciclo), R3, R9, lacuna 6 (datas hard-coded); depende de contrato de dados da BRP (F0) e de acesso às tabelas bronze |
| Status | Novo (porte dos notebooks existentes) |

### 6.2 dbx-brp

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Base de Referência de Preços Cash (BRP Cash) no lake |
| Tipo | Conjunto de tabelas Delta (gold) |
| Tecnologia | Delta Lake, Unity Catalog (schema `brp`), partição por `anomes`, time travel, Delta Sharing opcional para analistas |
| Responsabilidade | Guardar todas as versões da BRP Cash: `matriz_cenarios_preco` (Matriz de Cenários de Preço, MPA; antes `matriz_preco_alvo_cluster`; uma linha por cenário com `preco_alvo`, `preco_sugerido` e percentis), `posicao_preco_cliente_produto` (com `cenario_id` e `preco_sugerido` do cliente), `matriz_relacionamento`, `indicadores_reciprocidade`, `preco_vigente_foto`, `historico_preco`, `qualidade_ciclo`; receber carga única dos ciclos legados (SIMUL_*, incluindo `SIMUL_PRECO_POR_PRODUTO` e `SIMUL_PRC_ALVO_CLUSTER`); ser a fonte do reverse ETL e da análise da Precificação |
| Capacidade / BC | M2, M3 (base histórica); BC Publicação de Referência (Published Language: contrato de dados da BRP) |
| Interfaces | Entrada: dbx-ppp. Saída: JDBC (reverse ETL), SQL Warehouse/Delta Sharing para analistas e relatórios (substitui a planilha como visão) |
| Dados que possui | BRP Cash completa, todos os ciclos |
| Justificativa | AD-01/AD-03: a BRP precisa ser versionada por ciclo e preservada indefinidamente (M3); Delta oferece isso nativamente. O sql-motor guarda apenas N versões online. O contrato de dados da BRP (Published Language) é o acoplamento entre analítico e online, e vive aqui. |
| Alternativas consideradas | Guardar histórico apenas no Azure SQL (crescimento e custo); manter planilhas versionadas em pasta (AS-IS) |
| RF atendidos | RF-13, RF-04 (histórico completo), RF-08 (métricas de qualidade) |
| RNF atendidos | RNF-03 (versões imutáveis), RNF-06, RNF-09 |
| Fase | F1 |
| Riscos / dependências | R3; governança do Unity Catalog; contrato de dados (F0) |
| Status | Novo |

---

## 7. Orquestração, observabilidade e identidade

### 7.1 controlm

| Campo | Conteúdo |
|---|---|
| Nome de negócio | Orquestração corporativa de jobs |
| Tipo | Scheduler corporativo |
| Tecnologia | Control-M (existente) |
| Responsabilidade | Disparar o workflow dbx-ppp no calendário do ciclo (via Databricks Jobs API), com dependências de cargas de origem; disparar o monitoramento de reciprocidade [EVOL] e o cálculo em lote de ondas [EVOL]; monitorar status e alertar a operação; não orquestra tarefas internas do Databricks |
| Capacidade / BC | M2, C3, C2; M4 (monitoramento operacional) |
| Interfaces | Saída: Databricks Jobs API, `POST /reciprocidade/monitoramentos`, `POST /reprecificacao/ondas/{id}/calcular`. Entrada: status dos jobs |
| Dados que possui | Definições de jobs e histórico de execução |
| Justificativa | AD-01/AD-07: a governança de scheduling do banco passa pelo Control-M; usá-lo como disparador dá visibilidade única à operação sem duplicar orquestração. Se a governança não exigir, o agendamento nativo do Databricks basta para M2. |
| Alternativas consideradas | Scheduler nativo do Databricks (equivalente para M2); cron no ARO para os jobs Java (menos visível à operação) |
| RF atendidos | RF-13, RF-12 (EVOL), RF-11 (EVOL) |
| RNF atendidos | RNF-05, RNF-10 |
| Fase | F1 (dbx-ppp), F3, F4 |
| Riscos / dependências | Integração Control-M ↔ Databricks Jobs API (token de serviço, rede) |
| Status | Existente |

### 7.2 Observabilidade e auditoria

| Campo | Conteúdo |
|---|---|
| Nome canônico | (transversal; padrão ARO + tabelas de auditoria) |
| Nome de negócio | Monitoramento e trilha de auditoria do Motor |
| Tipo | Capacidade transversal |
| Tecnologia | Stack de observabilidade do ARO (logs centralizados, métricas Prometheus/Grafana, tracing distribuído com `X-Correlation-Id`); alertas do Databricks Workflows e do Control-M; tabelas `auditoria` e `cotacao` append-only no sql-motor com exportação ao Delta; logs de acesso do Axway |
| Responsabilidade | Rastrear cada execução (quem, quando, entrada, saída, versões), cada mudança de parâmetro e de versão da BRP; medir latência, erro e uso por canal; alertar falhas de integração e de qualidade de dados; dashboards de versões ativas e de concordância no shadow run |
| Capacidade / BC | M4; BC Auditoria e Observabilidade (generic) |
| Interfaces | Entrada: todos os serviços, gateway, pipeline. Saída: dashboards, alertas, exportação para o Delta |
| Dados que possui | Logs, métricas, traces; `auditoria` e `cotacao` (donos são svc-parametros/svc-pricing, acesso de leitura aqui) |
| Justificativa | AD-12: o padrão ARO já entrega logs, métricas e tracing; investir em componente próprio seria redundante. Auditoria de negócio precisa ser **dado** (tabela imutável, consultável por versão), não log, porque `00-doc-negocio.md:L14` exige rastrear responsáveis e versões usadas em cada execução. |
| Alternativas consideradas | Ferramenta de APM adicional (só se o padrão ARO se mostrar insuficiente); auditoria apenas em logs (não consultável por versão; retenção curta) |
| RF atendidos | RF-08 (alertas), RF-09 |
| RNF atendidos | RNF-03, RNF-05 |
| Fase | F1 |
| Riscos / dependências | Retenção e custo de logs; permissões append-only |
| Status | Existente (plataforma) + novo (tabelas e dashboards) |

### 7.3 Identidade e acesso

| Campo | Conteúdo |
|---|---|
| Nome canônico | (transversal; AD corporativo + Salesforce + Axway) |
| Nome de negócio | Perfis, papéis e alçadas de usuário |
| Tipo | Capacidade transversal |
| Tecnologia | AD corporativo (Entra ID) como fonte de identidade; SSO no Salesforce; OAuth2 client credentials para canais no Axway; JWT com claims de perfil (`precificacao.editor`, `precificacao.aprovador`, `precificacao.publicador`, `alcada.nivelN`, `comercial.gerente`) propagado aos serviços; autorização por operação nos serviços |
| Responsabilidade | Autenticar canais e usuários, propagar perfil, autorizar operações de parametrização, publicação e aprovação; segregação de funções (editor não aprova a própria versão) |
| Capacidade / BC | M4; BC Identidade e Acesso (generic) |
| Interfaces | Entrada: AD/Entra ID. Saída: claims para Salesforce, Axway e serviços |
| Dados que possui | Usuários, grupos, papéis (fora do MPC) |
| Justificativa | AD-12 e `00-doc-negocio.md:L18`, `L35`: perfis e alçadas são definidos pelo time de precificação, mas a identidade é corporativa. Reusar AD + Salesforce evita um cadastro de usuários no motor. O Axway concentra a autenticação de canal; os serviços só autorizam. |
| Alternativas consideradas | Cadastro de usuários próprio no motor (duplicação); autorização apenas no Salesforce (outros canais ficariam sem controle, RF-07) |
| RF atendidos | RF-10, RF-03 (papel aprovador), RF-07 |
| RNF atendidos | RNF-04 |
| Fase | F1 (canal e perfis básicos), F2 (perfis completos de parametrização) |
| Riscos / dependências | Mapeamento de grupos AD → papéis (P3, P8); R10 |
| Status | Existente (plataforma) + novo (papéis do MPC) |

---

## 8. Componentes a desligar

### 8.1 Planilha Preço Ano 1 (`Preço ano 1.xlsx` + macro)

| Campo | Conteúdo |
|---|---|
| Tipo | Workbook Excel com macro VBA |
| Responsabilidade atual | Consolidar saídas dos notebooks, listas manuais e premissas; recalcular "Preço por Produto" e "Resumo por GE"; origem dos 11 arquivos para o SAS (`07:L21-34`) |
| Substituído por | dbx-brp (dados, inclusive o preço sugerido por cenário), svc-parametros (premissas, tiers, listas), dbx-ppp (cálculo do alvo e do sugerido por cenário, regra da macro a levantar; revisão 1.1), relatórios sobre o Delta (visão da Precificação). O svc-pricing apenas consulta o resultado |
| Requisitos hoje não atendidos | RF-05, RF-06, RF-09, RF-10, RNF-03, RNF-09 (sem versionamento nem auditoria, `A2` Fluxo 07 §9) |
| Plano de desligamento | F0: engenharia reversa da macro (P1) e inventário das abas manuais → catálogo de parâmetros. F1: carga única das abas de premissas/listas para svc-parametros; planilha mantida como fonte oficial. F2: por produto, quando o corte ocorrer, a aba deixa de ser gerada; ao final da F2 a planilha vira relatório gerado a partir do Delta, sem macro. Arquivo histórico arquivado com os ciclos legados carregados no Delta. |
| Riscos | R1 (macro), R9; resistência de uso pela Precificação (mitigar com relatório equivalente no Databricks SQL) |
| Status | A desligar (F2) |

### 8.2 SAS — tabelas `SIMUL_*_AAAAMM` (`DCPS_EXP`)

| Campo | Conteúdo |
|---|---|
| Tipo | Programa SAS de importação + tabelas versionadas por mês |
| Responsabilidade atual | Importar 11 xlsx e gravar `SIMUL_EMISSOES_LM`, `SIMUL_PRC_ALVO_CLUSTER`, `SIMUL_REGIAO`, `SIMUL_SALDO_DAV`, `SIMUL_SALDO_IF`, `SIMUL_SHARE_BOLETOS`, `SIMUL_PRECO_POR_PRODUTO` por `anomes` (`07:L37-38`, `L87-112`) |
| Substituído por | Reverse ETL dbx-ppp → sql-motor (AD-03) e svc-publicacao (versão por `anomes`) |
| Plano de desligamento | F1: continua como fonte do SQL 010 durante o shadow; carga única de todos os `SIMUL_*_AAAAMM` existentes para o Delta (ciclos legados, preserva histórico e permite comparação). F2: por produto, interromper geração do arquivo correspondente; após o último produto, um ciclo em modo leitura, depois desativar o programa e congelar as tabelas (retenção conforme política). |
| Riscos | Captura das tabelas cortada no doc (lacuna 8): inventariar no SAS antes da carga única |
| Status | A desligar (F2) |

### 8.3 Motor da Calculadora (Servidor SQL 010)

| Campo | Conteúdo |
|---|---|
| Tipo | Procedimentos SQL Server com regra de negócio + tabelas próprias para a Calculadora |
| Responsabilidade atual | Consultar `DCPS_EXP.SIMUL_*_anomes`, aplicar regra de negócio (cálculo do preço final/sugerido, desconto, alçada) e carregar tabelas que a Calculadora Salesforce lê (`07:L40-42`, `L114`) |
| Substituído por | svc-pricing (classificação, lookup do cenário e composição da resposta), svc-alcada, svc-legado-adapter, sql-motor. Se a engenharia reversa (P1) mostrar que o SQL 010 também deriva preço, essa parte vai para o dbx-ppp, não para o svc-pricing (revisão 1.1) |
| Requisitos hoje não atendidos | RF-07 (sem API), RF-09, RNF-09 (sem versão de regra), RNF-07 (regra em código SQL) |
| Plano de desligamento | F0: engenharia reversa dos procedimentos (P1) com o time de TI do legado; extrair regras para parâmetros e estratégias. F1: shadow run com comparador (respostas do SQL 010 x svc-pricing) por produto; discrepâncias alimentam o backlog de regras. F2: corte por produto via flag no Salesforce; SQL 010 mantido um ciclo como retaguarda; depois desativado. Conector do Salesforce ao SQL 010 removido. |
| Riscos | R1, R7; dependência de acesso ao código dos procedimentos |
| Status | A desligar (F2) |

---

## 9. Matriz componente x requisitos

X = atende diretamente; (x) = habilita ou contribui; E = evolução (C2/C3).

| Componente | RF-01 | RF-02 | RF-03 | RF-04 | RF-05 | RF-06 | RF-07 | RF-08 | RF-09 | RF-10 | RF-11 | RF-12 | RF-13 | RNF-01 | RNF-02 | RNF-03 | RNF-04 | RNF-05 | RNF-06 | RNF-07 | RNF-08 | RNF-09 | RNF-10 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| sf-calculadora | X | X | X | X | | | (x) | | | | | | | X | | | X | | | | X | | X |
| sf-parametrizacao | | | | | X | X | | | (x) | X | | | X | | | | X | | | X | | (x) | X |
| sf-reprecificacao | | | | | | | | | | | E | | | | | | X | | | | X | | X |
| akamai | | | | | | | X | | | | | | | | | | X | | | | | | X |
| appgw-azure | | | | | | | X | | | | | | | X | | | X | | | | | | X |
| apigw-axway | | | | | | | X | | (x) | | | | | | X | | X | X | | | | | X |
| aro | | | | | | | | | | | | | | X | X | | X | X | | | | | X |
| svc-pricing | X | X | (x) | (x) | | (x) | X | | X | | E | | | X | X | X | | | | X | | X | X |
| svc-alcada | | | X | | | | | | X | (x) | E | | | | | X | X | | | X | | | X |
| svc-parametros | | | | | X | X | | | X | X | | | (x) | | | X | X | | | X | | X | X |
| svc-publicacao | | | | | | | | X | X | (x) | | | X | X | | X | | | X | | | X | X |
| svc-legado-adapter | | | | X | | | X | | | | E | | | X | X | | | | X | | | | X |
| svc-reciprocidade | | | | | | | | | (x) | | | E | | | | X | | X | | X | | | X |
| svc-reprecificacao | | | | | | | | | (x) | | E | | | | | X | | | | X | | X | X |
| sql-motor | X | | | X | X | | | | X | | E | E | X | X | X | X | | | X | | | X | X |
| sb-eventos | | | | | | (x) | | | | | E | E | | | (x) | | | X | | | | | (x) |
| dbx-ppp | (x) | | | | | | | X | | | E | | X | | | | | X | X | | X | X | X |
| dbx-brp | (x) | | | X | | | | (x) | | | | | X | | | X | | | X | | | X | X |
| controlm | | | | | | | | | | | E | E | X | | | | | X | | | | | X |
| Observabilidade/auditoria | | | | | | | | X | X | | | | | | | X | | X | | | | | X |
| Identidade/acesso | | | X | | | | X | | | X | | | | | | | X | | | | | | X |

Leitura da matriz: RF-01 a RF-04 e RF-07 concentram-se em svc-pricing, svc-alcada, svc-legado-adapter e sf-calculadora (núcleo do MVP F1); dbx-ppp e dbx-brp contribuem para RF-01 porque o preço alvo e o preço sugerido por cenário nascem no pipeline e são publicados na BRP (revisão 1.1). RF-05, RF-06, RF-10 dependem de svc-parametros e sf-parametrizacao (F2 completa). RF-08 e RF-13 são do par dbx-ppp/svc-publicacao. RF-11 e RF-12 só têm cobertura em componentes de evolução. Nenhum requisito fica sem componente responsável.

---

## 10. Matriz componente x fase do roadmap

N = construção/porte; E = evolução funcional; O = operação; D = desligamento; P = preparação (decisões, contratos).

| Componente | F0 | F1 | F2 | F3 | F4 | F5 |
|---|---|---|---|---|---|---|
| sf-calculadora | P | N (shadow, piloto) | E (corte por produto, contingência) | E (alertas C3) | O | O |
| sf-parametrizacao | P | N (básico, ativação BRP) | N (staging, agendamento, perfis, diff) | O | O | E |
| sf-reprecificacao | | | | P | N | E |
| akamai | P | (O) | N (outros canais) | O | O | O |
| appgw-azure | P | N (rotas) | O | O | O | O |
| apigw-axway | P (processo de publicação) | N (APIs v1) | E (canais externos) | O | E (APIs C2/C3) | O |
| aro | P (namespaces) | N | O | O | O | O |
| svc-pricing | P | N (MVP) | E (regras completas) | O | E (lote) | E |
| svc-alcada | P | N (mínimo) | E (níveis completos) | O | E (lote) | O |
| svc-parametros | P (catálogo) | N (versão básica) | E (completo) | E (reciprocidade) | E (onda) | O |
| svc-publicacao | P | N | O | O | O | O |
| svc-legado-adapter | P (P5) | N (foto) | E (online) | O | E (efetivação, se P4) | O |
| svc-reciprocidade | | | | N | O | E |
| svc-reprecificacao | | | | P | N | E |
| sql-motor | P (dimensionar) | N | E | E | E | O |
| sb-eventos | P (P6) | N (ou outbox) | O | E | E | O |
| dbx-ppp | P (contrato de dados) | N (porte + BRP v1) | E (validações, comparador) | O | E (filtros C2) | E |
| dbx-brp | P | N | O | O | O | O |
| controlm | P | N (dbx-ppp) | O | E (job C3) | E (lote C2) | O |
| Observabilidade/auditoria | P | N | O | O | O | O |
| Identidade/acesso | P (papéis) | N | E (perfis completos) | O | O | O |
| Planilha Ano 1 | P (eng. reversa) | O (fonte oficial) | D | | | |
| SAS SIMUL_* | P (inventário) | O + carga única no Delta | D | | | |
| Motor SQL 010 | P (eng. reversa) | O (shadow) | D | | | |

Contagem: 21 componentes do TO-BE (3 canais, 3 de borda, 1 plataforma, 7 microsserviços, 2 de dados/mensageria, 2 analíticos, 3 transversais), dos quais 3 são evolução (sf-reprecificacao, svc-reciprocidade, svc-reprecificacao), 7 são plataformas existentes reutilizadas (akamai, appgw-azure, apigw-axway, aro, controlm, observabilidade, identidade) e 1 está pendente de validação na stack (sb-eventos). 3 componentes legados a desligar na F2.
