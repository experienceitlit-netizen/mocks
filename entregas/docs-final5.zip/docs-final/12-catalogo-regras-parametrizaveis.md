# Catálogo de regras parametrizáveis (tabelas de decisão) — Motor de Precificação Cash

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-21 |
| Status | Rascunho para validação com o time de Precificação |
| Objetivo | Listar cada regra dos fluxos de precificação que pode ser expressa como tabela ou constante parametrizável, com o formato proposto, onde é usada e a origem nos documentos de negócio. Serve de base para o módulo de Parametrização (M1), para a carga inicial dos valores hoje fixos em código e planilhas, e para a decisão do AD-15 (motor de decisão único). |
| Fontes | `docs-precificacao/` (referências no formato `NN:L<linha>`; `00-neg` = `00-doc-negocio.md`; `00-etapas` = `00-etapas-geracao-planilha-ano1.md`); anexos `A1` (fluxos de produto) e `A2` (fluxos de consolidação), que trazem o detalhe por linha |
| Relação com outros docs | Brief `A0` §3 (M1) e §6 (AD-06); doc 03 §7 (módulo de parametrização); doc 06 §5.3 e §6 (`parametro_versao`, `parametro_item_*`); doc 08 épico PAR; doc 11 (AD-15) |

## 1. Como ler

- **Uso**: `P` = pipeline de preparação (Databricks); `O` = motor online (consulta e simulação); `C2/C3` = capacidades de evolução. As regras marcadas `P + O` são as que hoje existem em duas implementações (PySpark e Java) e, por isso, precisam sair da mesma versão publicada.
- **Maturidade**: `Documentada` (valores conhecidos nos fluxos), `Parcial` (regra conhecida, valores incompletos ou inconsistentes entre fluxos), `Desconhecida` (existe a planilha ou a premissa, conteúdo não documentado).
- Toda tabela proposta tem, além das colunas listadas, as colunas de governança comuns: `versao`, `vigencia_inicio`, `vigencia_fim`, `status` (rascunho, staging, aprovado, publicado, expirado), `alterado_por`, `aprovado_por`.
- IDs `RP-nn` são desta versão do catálogo e podem ser usados nos SPECs do doc 08 e na carga inicial (SPEC-PAR).

## 2. Escopo e elegibilidade

| ID | Regra | Tabela proposta (colunas) | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-01 | Segmentos elegíveis ao motor | `segmento_elegivel`: cod_segmento, nome, elegivel (S/N), agrupamento_faixas (ULTRA/GLOBAL, LARGE, CORPORATE/AGRO) | P + O | ULTRA CORPORATE, LARGE CORPORATE, CORPORATE, GLOBAL CORPORATE, AGRO CORPORATE; INSTITUCIONAL entra no esqueleto de cenários (`05:L51`) mas sai da matriz de relacionamento (`06:L33`) — decidir | `05:L51`, `06:L33`, `01:L12`, `02:L21`, `03:L19`, `04:L24` | Parcial (INSTITUCIONAL) |
| RP-02 | Grupos econômicos excluídos | `grupo_excluido`: cd_grupo, motivo | P | Grupo 616 nos fluxos 02, 03 e 04; "grupo Bradesco" no fluxo 01 (código não informado); CD_GRUPO = 0 excluído no consolidado | `02`, `03`, `04` (A1 §Diferenças), `01:L14`, `05:L37` | Parcial (motivo não documentado) |
| RP-03 | Listas especiais de clientes | `lista_especial`: tipo (poder_publico, associacao_religiosa, nicho, rfp), cnpj ou cd_grupo, tratamento (excluir, preço próprio, carência), observacao | P, C2 | Poder público excluído em todos os fluxos; associações religiosas e nichos tratados à parte na Planilha; conteúdo das listas não documentado | `01:L9`, `02:L24`, `03:L22`, `04:L21`, `07:L18`, `07:L54-60` | Parcial |
| RP-04 | Catálogo de produtos e macroprodutos | `produto`: cod_produto, nome, macroproduto (COBRANCA, ARRECADACAO, MULTIPAG, PIX), visao (Cliente/Banco), grupo_regra_cluster (1, 2, 3), ativo | P + O | 18 produtos do esqueleto (`05:L49`); grupos de regra 1/2/3 (`05:L60-94`); `NA BAIXA POR PAGAMENTO Banco` sem grupo; CANAIS DIGITAIS e DÉBITO AUTOMÁTICO sem fluxo gerador; produtos de Arrecadação fora do esqueleto | `05:L34`, `05:L49`, `05:L60-96`, `01:L35-57` | Parcial |
| RP-05 | Mapeamento de evento de origem para produto | `evento_produto`: sistema_origem, chave (DESCR_TARIFA, CD_TARF, mídia, serviço de contrato), cod_produto, tipo_documento (Arrecadação) | P | Cobrança: DESCR_TARIFA → 13 modalidades (regra não descrita); PIX: lista de CD_TARF; Multipag: serviços PAGAMENTO VIA TED / FORNECEDORES; Arrecadação: mídia → produto e recorte DIVERSOS | `01:L10`, `01:L55`, `03`, `02`, `04` (A1 §5 de cada produto) | Parcial |
| RP-06 | Constantes de produto para bases sem coluna PRODUTO | `produto_padrao_base`: base_origem, cod_produto | P | Multipag → FORNECEDORES TED; PIX → PIX PAGAMENTOS | `05:L22-23`, `05:L32-33` | Documentada |
| RP-07 | Janelas temporais por base | `janela_base`: tipo_base, meses, referencia (data fim relativa ao ciclo) | P | Movimento 12; LTM 13 referências; L3M 3; ROB 6 (hoje `REF >= 202506` fixo); share de cash 3 (datas fixas 2026-03 a 05); saldo IF/DAV 3; share de boletos 12 | `00-etapas:L5-16`, `01:L16-17`, `06:L17`, `06:L26`, `06:L50` | Documentada (mas hard-coded) |
| RP-08 | Filtros técnicos de entrada | `filtro_entrada`: base, condicao, acao | P | QTD_MENSAL > 0 (Cobrança); RCTA ≥ 0 (PIX); gateway impressão/postagem e classificação de emissor (Cobrança, regra não descrita) | `01:L26`, `01:L8`, `01:L11`, `03` | Parcial |

## 3. Tier de volume

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-09 | Faixas de tier por produto | `faixa_tier`: cod_produto, tier (1, 2, 3), limite_inferior, limite_superior, base_volume (média mensal ou total anual), unidade | **P + O** | Cobrança: 13 tabelas por modalidade (ex.: NA BAIXA POR COMPENSACAO Cliente ≤ 25.500 / ≤ 150.000 / > 150.000; QUANDO DO REGISTRO Cliente ≤ 17.000 / ≤ 100.000 / > 100.000); Multipag 4.000 / 50.000; PIX 100 / 500; Arrecadação 200 mil / 5 milhões e 70 mil / 750 mil (anual) | `01:L59-79`, `02:L30`, `03:L52-56`, `04:L45-48`, `07:L65`, `07:L76` | Documentada |
| RP-10 | Tier suprimido | `faixa_tier.tier_suprimido` ou flag por produto | P + O | DEBITO DE COBRANCA C/C (Banco ≤ 75.000, Cliente ≤ 30.000) não tem tier 3: tudo abaixo do limite de tier 2 é tier 2 | `01:L67`, `01:L71`, `01:L79` | Documentada |
| RP-11 | Base de volume usada no tier | coluna `base_volume` de RP-09 | P + O | Média mensal (Cobrança, Multipag, PIX) x total anual (Arrecadação, inferido) | `01:L61`, `02:L30`, `03:L30`, `04:L29` | Parcial |

## 4. Cluster de precificação

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-12 | Regra de cluster por grupo de produto | `regra_cluster`: grupo_regra, tier, cod_segmento, cod_regiao (ou `*`), cluster | **P + O** | Grupo 1: tier 1 → 1; tier 2 → 2; tier 3 + ULTRA/GLOBAL → 3; + LARGE → 4; + AGRO → 10; + CORPORATE/INSTITUCIONAL por região SP 5, SE ex-SP 6, S 7, CO 8, NNE 9. Grupo 2 (Débito C/C): sem distinção de tier 2/3 nem região, clusters 1-4 e 10. Grupo 3: clusters 1-5 e 10, sem região. Arrecadação diverge: cluster 3 = LARGE + INSTITUCIONAL, 4 = CORPORATE, sem região | `05:L56-96`, `01:L81-92`, `02:L31`, `03:L31`, `04:L54-61` | Parcial (Arrecadação e texto cortado em `01:L92`) |
| RP-13 | Regiões comerciais e mapa UF → região | `regiao`: cod_regiao, nome; `uf_regiao`: uf, cod_regiao | P + O | S, CO, NNE, SE ex-SP, SP; tabela UF → região nos fluxos 02 e 03; chave de cruzamento diverge (CPF/CNPJ em 01, CD_GRUPO em 02/03); `regiao_por_ge.xlsx` na Planilha | `05:L52`, `02`, `03`, `01:L18`, `07:L82` | Documentada (mapa), Parcial (chave) |
| RP-14 | Clusters de referência corporate | `cluster_referencia`: cod_produto, lista de clusters | P | Multipag e PIX: [5, 6, 7, 8, 9]; Arrecadação: [5]; Cobrança: ilegível | `02:L50`, `03:L60`, `04:L69`, `01:L97` | Parcial |
| RP-15 | Ordem de precedência do cummin | `ordem_cummin`: cod_produto ou grupo_regra, posicao, cluster | P | corporate ≥ 10 ≥ 4 ≥ 3 ≥ 2 ≥ 1 (Cobrança explícita; demais em ordem decrescente de código) | `01:L98-102` | Documentada |
| RP-16 | Fallback para cenário sem estatística | `fallback_cenario`: cod_produto, cluster_sem_dado, acao (cluster vizinho, preço de lista, bloquear) | P + O | Hoje o merge inner descarta combinações sem percentil (`05:L28`); sem regra definida | `05:L28`, `05:L96` | Desconhecida |

## 5. Percentis, preço alvo e uplift

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-17 | Percentis calculados e percentil-alvo | `politica_percentil`: cod_produto, percentis_calculados, percentil_alvo | P | P25, P35, P40, P50, P60, P75, P90; alvo = P75 em todos os produtos | `01:L96`, `01:L112`, `05:L20` | Documentada |
| RP-18 | Fonte dos percentis por produto | `fonte_percentil`: cod_produto, base (completa ou recorte) | P | Arrecadação: percentis da base completa, uplift da base Diversos | `05:L17`, `05:L21`, `05:L31` | Documentada (motivo não) |
| RP-19 | Campo de ponderação da referência corporate | `politica_percentil.campo_peso` | P | QT_MENSAL / QTDE / QTDE_ARRECADADO | `01:L97`, `02`, `03`, `04` | Documentada |
| RP-20 | Política "nunca reduzir" | `politica_alvo`: cod_produto, nunca_reduzir (S/N) | P | Ativa em todos: alvo = max(tarifa atual, P75) | `01:L112`, `01:L133` | Documentada |
| RP-21 | Limiar das fórmulas de uplift | `constante`: chave = LIMIAR_UPLIFT, valor | P + O (uplift da simulação) | 1.000: abaixo, (alvo − tarifa) × quantidade; a partir dele, (alvo / tarifa − 1) × valor tarifado | `01:L116` | Documentada |
| RP-22 | N mínimo de representatividade | `constante`: chave = N_MINIMO, valor | P | 15: com N < 15 mantém tarifa e zera uplift | `01:L120` | Documentada |
| RP-23 | Divisor de mensalização | `constante`: chave = MESES_ANO, valor | P | 12 (Arrecadação) | `05:L31` | Documentada |

## 6. Preço sugerido e premissas comerciais

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-24 | Desconto por relacionamento | `desconto_relacionamento`: cod_segmento, indicador (saldo IF, saldo DAV), faixa_inferior, faixa_superior, percentual_desconto | P (gera o sugerido por cenário) | Existe como `premissas_desconto.xlsx`; passo 3 da metodologia ("preço alvo → desconto por saldo IF → preço de referência"); valores não documentados | `06:L137`, `07:L79`, `05:L110` | Desconhecida |
| RP-25 | Preço por produto (semestral) | `preco_por_produto`: cod_produto, preco, ciclo_semestral | P | Aba "Preço por Produto" recalculada por macro; publicada como `SIMUL_PRECO_POR_PRODUTO` a cada 6 meses; lógica da macro não documentada | `07:L30`, `07:L112`, `07:L77` | Desconhecida |
| RP-26 | Custos e piso de preço | `custo_produto`: cod_produto, custo_unitario, piso | P | Aba "Custos"; conteúdo não documentado | `07:L55` | Desconhecida |
| RP-27 | Preços de RFP e negociações recentes | `preco_acordado`: cd_grupo, cod_produto, preco, data, origem (RFP, negociação), vigencia, carencia_meses | P, O (exibição), C2 (filtro) | Abas "RFPs" e "Negociações Recentes"; conteúdo não documentado; uso inferido como exceção e carência | `07:L52`, `07:L54` | Desconhecida |
| RP-28 | Remuneração | a definir | P | `premissas_remuneracao.xlsx`; conteúdo não documentado | `07:L80` | Desconhecida |
| RP-29 | Premissas gerais | a definir | P | Aba "Premissas"; conteúdo não documentado | `07:L64` | Desconhecida |

## 7. Alçada

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-30 | Níveis de alçada | `politica_alcada`: macroproduto ou cod_produto, cod_segmento, desvio_min_pct, desvio_max_pct (ou faixa em R$ de uplift perdido), nivel, papel_aprovador, prazo | **O**, C2 | Alçada acionada quando o preço negociado fica abaixo do sugerido; contratação sem alçada no sugerido; `premissas_alcada.xlsx` existe, conteúdo não documentado | `00-neg:L22`, `07:L78` | Desconhecida |
| RP-31 | Base de comparação da alçada | `politica_alcada.base` (sugerido, alvo, praticado) | O | Definição de trabalho: sugerido | `A0 §2` | Parcial (a validar) |

## 8. Relacionamento, stickiness e impacto

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-32 | Macroprodutos considerados "cash" no ROB | `macroproduto_cash`: descricao_gdad_macro, e_cash (S/N) | P, C3 | Arrecadação, Cobrança, Folha de Pagamento, Fornecedores, Tarifas de Conta Corrente, Pix | `06:L19` | Documentada |
| RP-33 | Materialidade de crédito por segmento | `materialidade_credito`: cod_segmento, saldo_mercado_minimo | P, C3 | ULTRA 500 milhões; LARGE 40 milhões; GLOBAL 40 milhões; CORPORATE 2 milhões; AGRO 2 milhões | `06:L66`, `06:L73` | Documentada |
| RP-34 | Faixas de score de share (cash e crédito) | `faixa_score_share`: tipo (cash, credito), limite_inferior, score | P, C3 | ≥ 0,7 → 4; ≥ 0,4 → 3; ≥ 0,1 → 2; senão 1 | `06:L67-71`, `06:L77-82` | Documentada |
| RP-35 | Faixas de score de ROB por segmento | `faixa_score_rob`: agrupamento_segmento, limite_inferior, score | P, C3 | ULTRA/GLOBAL: ≥ 12,6 milhões → 3, ≥ 1,38 milhão → 2; LARGE: ≥ 6,3 milhões → 3, ≥ 1,38 milhão → 2; CORPORATE/AGRO: ≥ 525 mil → 3, ≥ 93 mil → 2; senão 1 | `06:L99-103` | Documentada |
| RP-36 | Faixas de score de receita cash por segmento | `faixa_score_receita_cash`: agrupamento_segmento, limite_inferior, score | P, C3 | ULTRA/GLOBAL: ≥ 2,25 milhões → 3, ≥ 300 mil → 2; LARGE: ≥ 1,5 milhão → 3, ≥ 300 mil → 2; CORPORATE/AGRO: ≥ 102 mil → 3, ≥ 9 mil → 2; senão 1 | `06:L109-113` | Documentada |
| RP-37 | Função de combinação dos scores | `constante`: FUNCAO_STICKINESS, FUNCAO_IMPACTO (max, média, ponderada) | P, C3 | Máximo em ambos | `06:L86`, `06:L117` | Documentada |
| RP-38 | Rótulos de stickiness e impacto | `rotulo_score`: tipo, score, rotulo | P, C2, C3 | Stickiness 1 Baixo, 2 Médio Baixo, 3 Médio Alto, 4 Alto; Impacto 1 Baixo, 2 Médio, 3 Alto | `06:L88-93`, `06:L119-123` | Documentada |
| RP-39 | Sentinelas e tratamento de nulos | `constante`: SHARE_SEM_MERCADO (−1), SOW_SEM_COBRANCA ('sem cobrança'), NULO_COMO_ZERO (S/N) | P | Definidos no código; "sem dado" hoje vira score baixo | `06:L32`, `06:L55`, `06:L47` | Documentada (política a validar) |
| RP-40 | Gradação de reajuste por Stickiness x Impacto | `gradacao_reajuste`: stickiness, impacto, percentual_maximo_reajuste ou etapas | C2 | Passo 4 da metodologia; matriz existe, regra de tradução em reajuste não documentada (texto truncado em `06:L138`) | `05:L111`, `06:L131-138` | Desconhecida |
| RP-41 | Carência entre reprecificações | `carencia_reprecificacao`: cod_segmento ou cod_produto, meses; `data_reprecificacao`: cd_grupo, cod_produto, data | C2 | Aba "Datas de Reprecificação"; carência inferida | `07:L53` | Desconhecida |
| RP-42 | Tolerâncias de reciprocidade | `tolerancia_reciprocidade`: indicador (volumetria, saldo IF/DAV, SoW), cod_segmento, desvio_tolerado_pct, periodo_observacao | C3 | Nenhum fluxo define; capacidade a detalhar com o negócio | brief `A0` §3 (C3) | Desconhecida |

## 9. Ciclo e publicação

| ID | Regra | Tabela proposta | Uso | Valores conhecidos | Fonte | Maturidade |
|---|---|---|---|---|---|---|
| RP-43 | Cadência de publicação por entidade | `cadencia`: entidade, periodicidade (mensal, semestral) | P | Tabelas SIMUL_* mensais; preço por produto semestral | `07:L112` | Documentada |
| RP-44 | Mês de referência e versão ativa | `ciclo`: anomes, status (staging, ativo, anterior), data_ativacao, versao_parametros | P + O | `anomes` nas tabelas SAS; versão ativa e rollback no TO-BE | `07:L89`, `07:L104-110`, `A0` AD-03 | Documentada |
| RP-45 | Perfis e alçadas de parametrização | `perfil_parametrizacao`: perfil, tipo_regra, pode_editar, pode_aprovar, pode_publicar | O (governança) | Exigido pelo escopo; perfis a definir pelo time de Precificação | `00-neg:L18`, `00-neg:L35`, `00-neg:L42` | Desconhecida |

## 10. O que não vira tabela (permanece código)

| Item | Motivo | Onde |
|---|---|---|
| Cálculo de percentis por cluster, referência corporate ponderada, cummin e N | Estatística sobre a população; depende de todos os clientes do cluster | Pipeline (Spark) |
| Fórmula do alvo: max(tarifa, P75) | Operação fixa; os valores (percentil-alvo, nunca reduzir) vêm de RP-17 e RP-20 | Pipeline |
| Fórmulas de uplift nas duas formas | Operação fixa; o limiar vem de RP-21 | Pipeline e motor (uplift da simulação) |
| Cálculo de share, saldo de mercado e SoW | Divisões e produtos simples; sentinelas em RP-39 | Pipeline |
| De-para de colunas, deduplicações, tratamento de tipos | Engenharia de dados, não regra de negócio | Pipeline |

## 11. Resumo por maturidade e uso

| Grupo | Regras | Documentadas | Parciais | Desconhecidas | Usadas também online (P + O) |
|---|---|---|---|---|---|
| Escopo e elegibilidade | RP-01 a RP-08 | 2 | 6 | 0 | RP-01, RP-04 |
| Tier | RP-09 a RP-11 | 2 | 1 | 0 | todas |
| Cluster | RP-12 a RP-16 | 2 | 2 | 1 | RP-12, RP-13, RP-16 |
| Percentis, alvo, uplift | RP-17 a RP-23 | 7 | 0 | 0 | RP-21 |
| Sugerido e premissas | RP-24 a RP-29 | 0 | 0 | 6 | RP-27 (exibição) |
| Alçada | RP-30 a RP-31 | 0 | 1 | 1 | todas |
| Relacionamento | RP-32 a RP-42 | 8 | 0 | 3 | nenhuma (C2/C3) |
| Ciclo e publicação | RP-43 a RP-45 | 2 | 0 | 1 | RP-44 |
| **Total** | **45** | **23** | **10** | **12** | **12** |

Leitura: das 45 regras, 23 já podem ser carregadas com os valores que estão nos fluxos; 10 precisam de decisão para fechar inconsistências (INSTITUCIONAL, cluster de Arrecadação, grupo 616, chave de UF, clusters de referência de Cobrança); 12 dependem de o negócio abrir o conteúdo das planilhas de premissas e detalhar C2 e C3. As 12 regras usadas também online são as que o AD-15 discute: hoje só tier, cluster e o limiar de uplift são de fato compartilhados entre pipeline e motor; alçada é só online; o restante é só pipeline.

## 12. Próximos passos sugeridos

1. Validar com Precificação os valores das 23 regras documentadas e registrar as decisões das 10 parciais (F0).
2. Obter e transcrever as planilhas `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto`, `regiao_por_ge` e as abas Custos, RFPs, Negociações Recentes, Premissas e Tears de Volume (F0, lacuna 2).
3. Usar este catálogo como escopo da carga inicial do módulo de Parametrização (doc 08, épico PAR) e como insumo da prova de conceito do AD-15.
