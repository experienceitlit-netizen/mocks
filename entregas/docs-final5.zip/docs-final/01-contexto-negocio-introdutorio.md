# Contexto de Negócio — Introdução ao Motor de Precificação Cash (MPC)

| Campo | Valor |
|---|---|
| Versão | 1.0 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Revisão 1.1 (2026-09-18) | Preço sugerido passa a ser lido da BRP Cash por cenário |
| Público | Arquitetos, PMs e analistas que nunca trabalharam com precificação de cash |
| Fontes | `anexos/A0-brief-decisoes.md`; `docs-precificacao/00-doc-negocio.md`; `docs-precificacao/00-etapas-geracao-planilha-ano1.md`; `anexos/A1-analise-fluxos-produtos.md`; `anexos/A2-analise-fluxos-consolidacao.md` |

Este documento explica do zero o que é precificação de cash no Atacado, como ela funciona hoje e o que o projeto pretende construir. Onde há inferência do redator, o texto marca **(inferido)**. Exemplos numéricos são **ilustrativos** e não representam valores reais do banco.

Convenção de referências: `docs-precificacao/<arquivo>:L<linha>`, abreviada para `NN:L<linha>` quando o arquivo é um dos fluxos 01 a 07 (por exemplo, `07:L29` é `docs-precificacao/07-planilha-ano1-fluxo.md:L29`); `00-doc-negocio.md` e `00-etapas-geracao-planilha-ano1.md` aparecem pelo nome. `anexos/A0`, `A1` e `A2` são os anexos desta documentação.

---

## 1. O que é "Cash" e o que são os produtos de payments

**Cash Management** é o conjunto de serviços que um banco oferece a uma empresa para movimentar dinheiro no dia a dia: receber de clientes e pagar fornecedores, funcionários e tributos. No segmento de **Atacado** (grandes empresas), esses serviços são vendidos por um gerente de relacionamento e cobrados por **tarifa**.

Os produtos de **payments** em escopo se dividem em dois grupos (`docs-precificacao/00-doc-negocio.md:L34`):

| Grupo | Macroproduto | O que faz | Exemplo de evento tarifado |
|---|---|---|---|
| Contas a receber | **Cobrança** | Emissão e liquidação de boletos | "Quando do registro" (boleto emitido), "Na baixa por compensação" (boleto pago) |
| Contas a receber | **Arrecadação** | Recebimento de contas e documentos por canal (mídia): internet banking, débito automático etc. | "Canais Digitais", "Débito Automático" |
| Contas a receber | **PIX** (recebimento, quando aplicável) | Recebimento via PIX | — |
| Contas a pagar | **Multipag / Fornecedores TED** | Pagamento a fornecedores via TED | Uma TED de pagamento a fornecedor |
| Contas a pagar | **PIX Pagamentos** | Pagamento via PIX | Códigos de tarifa específicos de PIX Pagamentos |

**Tarifa por evento.** Diferente de uma mensalidade, a tarifa de cash é cobrada cada vez que um evento acontece. Um boleto pode gerar tarifa no registro e outra na liquidação. Cada "evento tarifado" é uma linha na base do banco, identificada por uma descrição (por exemplo, `QUANDO DO REGISTRO`) (`anexos/A1`, seção Cobrança §7).

**Visão Cliente x Banco.** Em Cobrança, a mesma modalidade pode aparecer duas vezes: "Cliente" e "Banco". O sufixo indica quem é o lado tarifado daquele evento (`docs-precificacao/01-cobrança-fluxo.md:L57`). Para o modelo de preços, "NA BAIXA POR COMPENSACAO Cliente" e "NA BAIXA POR COMPENSACAO Banco" são dois produtos distintos, com faixas de volume e preços próprios.

Analogia: pense numa conta de luz em que cada kWh custa um valor. A precificação de cash decide quanto vale o "kWh" de cada empresa, e isso depende de quanto ela consome, de quem ela é e de onde está.

## 2. Quem são os atores

| Ator | Papel no processo |
|---|---|
| **Time de Precificação** | Dono das regras: define e valida parâmetros, políticas, tiers, clusters e premissas (`00-doc-negocio.md:L26`, `L33`, `L35`). Hoje também opera os notebooks e a planilha. |
| **Gerente de cash / comercial** | Negocia a tarifa com o cliente. Usa a Calculadora Salesforce para simular preços e, quando necessário, aciona alçada de aprovação (`00-doc-negocio.md:L22`). |
| **Cliente (grupo econômico)** | A empresa ou conjunto de empresas que contrata os produtos. |
| **Áreas de dados** | Extraem as bases dos sistemas de origem e as disponibilizam no Databricks (`00-doc-negocio.md:L27-28`). |
| **TI** | Constrói e opera o motor, as APIs, as integrações e o canal Salesforce. |
| **OPCH** | Equipe citada como parceira na definição da jornada de contratação sem alçada (`00-doc-negocio.md:L22`). Papel exato não detalhado nos docs. |

**Grupo econômico (CD_GRUPO).** Uma grande empresa costuma ter vários CNPJs (matriz, filiais, coligadas). O banco os consolida em um **grupo econômico**, que é a unidade de análise e de precificação (`anexos/A1`, Cobrança §7). Um CNPJ sem grupo (código 0) é descartado da análise (`docs-precificacao/05-uplift-consolidado-fluxo.md:L37`).

**Segmento.** Classificação comercial do cliente pelo porte. Os segmentos de Atacado em escopo são **ULTRA CORPORATE, LARGE CORPORATE, CORPORATE, GLOBAL CORPORATE e AGRO CORPORATE**. **INSTITUCIONAL** aparece em alguns fluxos e está em aberto (`anexos/A0`, §1).

**Região comercial.** Agrupamento de estados usado na precificação: **SP, SE ex-SP (Sudeste sem São Paulo), S, CO e NNE** (`docs-precificacao/05-uplift-consolidado-fluxo.md:L52`). A região vem do cadastro (UF do grupo) e só diferencia preço em alguns casos.

## 3. Como a precificação funciona hoje (AS-IS)

Hoje não existe um "motor". Existe uma cadeia de etapas, parte em Python, parte manual, que produz uma planilha e a distribui para a Calculadora Salesforce (`docs-precificacao/07-planilha-ano1-fluxo.md:L17-42`; `anexos/A2`, Síntese transversal):

1. **Extração de bases.** Áreas de dados rodam SQL no Databricks e geram arquivos CSV: movimento e eventos tarifados de cada produto (12 meses), segmentos, ROB (resultado operacional), saldos de Invest Fácil e DAV (3 meses), shares de mercado, listas de poder público e associações religiosas (`docs-precificacao/00-etapas-geracao-planilha-ano1.md:L5-18`).
2. **Sete notebooks Python.** Um por produto (Cobrança em dois, Multipag, PIX, Arrecadação) calcula tier, cluster, percentis, preço-alvo e uplift por grupo econômico. Um sexto consolida tudo em `base_total.xlsx` e monta a matriz `tabela_precos.xlsx`. Um sétimo classifica os clientes na matriz Stickiness x Impacto e calcula saldos e share de boletos.
3. **Planilha Ano 1.** Alguém copia manualmente as saídas para abas de um workbook Excel, preenche abas manuais (Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos, Premissas, Tears de Volume) e executa uma **macro** que recalcula as abas "Preço por Produto" e "Resumo por GE". A lógica da macro não está documentada (`07:L29-31`).
4. **Bifurcação.** A planilha serve a dois destinos: a equipe de Precificação decide ações de reprecificação manualmente, e as abas são copiadas para 11 arquivos Excel da pasta "calculadora salesforce" (`07:L32-34`).
5. **SAS.** Uma query SAS, executada à mão, importa os 11 arquivos e grava tabelas `SIMUL_*_AAAAMM` (uma por insumo e por mês) (`07:L35-38`).
6. **Servidor SQL 010.** O "Motor da Calculadora" lê as tabelas SAS, aplica regras de negócio não documentadas e carrega tabelas próprias (`07:L40-42`, `L114`).
7. **Calculadora Salesforce.** O gerente consulta preço-alvo, cluster, saldo e share e simula a tarifa para o cliente.

**Por que isso é frágil.** Cada etapa depende de uma pessoa lembrar de fazer a próxima. As datas da janela de análise estão escritas no código (por exemplo, `REF >= 202506`) e precisam ser editadas a cada ciclo (`docs-precificacao/06-matriz-stickiness-impacto-fluxo.md:L17`, `L26`). Listas de produtos, segmentos e exclusões estão fixas nos notebooks; incluir um produto exige alterar código, e um produto já ficou de fora por não ter regra de cluster (`05:L96`). A macro e o SQL 010 concentram a regra que gera o preço sugerido, sem documentação (`anexos/A0`, §8 item 1). Não há versionamento nem trilha de auditoria: não se sabe qual versão de parâmetro gerou cada preço (`anexos/A2`, Fluxo 07 §9).

## 4. A metodologia de 4 passos do business case

O modelo de precificação segue uma metodologia em 4 passos (`docs-precificacao/03-pix-fluxo.md:L70-81`):

| Passo | O que faz | Está automatizado? |
|---|---|---|
| 1. Clusterizar clientes | Agrupar clientes comparáveis por tier de volume, segmento e região. | **Sim**, nos notebooks de produto. |
| 2. Propor tarifa-alvo por cluster | Olhar quanto os clientes daquele cluster já pagam e propor um preço de referência (P75). | **Sim**, nos notebooks de produto. |
| 3. Reconhecer nível de relacionamento | Ajustar o preço pelo saldo médio de Invest Fácil (e DAV) do cliente. | **Não.** O saldo é calculado (`06:L44-51`), mas o desconto vive na macro/premissas, sem documentação. O resultado (preço sugerido por cenário) já sai na Planilha Ano 1 (`07:L30`). |
| 4. Planejar reajustes graduais | Usar a matriz Stickiness x Impacto para decidir quem reajusta primeiro e quanto. | **Não.** A matriz é calculada (`06:L34-41`), mas a regra de gradação não está em código nem documentada. |

Resumo: a máquina de hoje faz bem os passos 1 e 2. Os passos 3 e 4 têm os insumos prontos, mas a aplicação é manual e não documentada (`anexos/A2`, Síntese transversal).

## 5. Conceitos-chave

Cada conceito abaixo traz uma definição simples e um exemplo **ilustrativo**.

**Tier de volume.** Faixa de quantidade mensal (ou anual, em Arrecadação) que o cliente movimenta no produto. Tier 1 é o maior volume, Tier 3 o menor. Os cortes são definidos empiricamente por produto (`docs-precificacao/01-cobrança-fluxo.md:L61`). Exemplo real de Multipag: até 4.000 TEDs por mês é Tier 3, até 50.000 é Tier 2, acima é Tier 1 (`02-multipag-fluxo.md:L30`).

**Cluster de precificação.** Código numérico de 1 a 10 que junta tier, segmento e, em alguns produtos, região. Clientes de Tier 1 ficam no cluster 1 independentemente do segmento; clientes de Tier 3 são separados por segmento (ULTRA/GLOBAL = 3, LARGE = 4, AGRO = 10) e, para CORPORATE, por região (SP = 5, SE ex-SP = 6, S = 7, CO = 8, NNE = 9) (`02-multipag-fluxo.md:L31`). Analogia: o cluster é a "turma" com quem o cliente vai ser comparado.

**Percentis de tarifa (P25 … P90).** Dentro de cada cluster, ordena-se a tarifa que os clientes pagam. P75 é o valor abaixo do qual estão 75% dos clientes. Ilustrativo: se em um cluster as tarifas vão de R$ 1,00 a R$ 4,00 e P75 = R$ 3,20, então 75% dos clientes pagam até R$ 3,20. Os percentis calculados são P25, P35, P40, P50, P60, P75 e P90 (`anexos/A1`, Síntese, item 29). P25 e P75 recebem um ajuste de "referência corporate" e de monotonicidade para evitar que um cluster de cliente maior tenha percentil maior que um de cliente menor (`01-cobrança-fluxo.md:L97-102`).

**Preço praticado, alvo e sugerido.** Definições de trabalho do brief (`anexos/A0`, §2), a validar com o negócio:

| Preço | Definição simples | Ilustrativo |
|---|---|---|
| **Praticado (vigente)** | O que o cliente paga hoje. | R$ 2,00 |
| **Alvo** | Referência do cluster: o maior entre a tarifa atual e o P75 do cluster. | max(2,00; 3,20) = R$ 3,20 |
| **Sugerido** | Preço recomendado para o **cenário** do cliente (produto x região x segmento x tier de volume), já calculado pelo pipeline e publicado na BRP Cash junto com o alvo. O motor não o calcula: classifica o cliente e lê o cenário. É o piso de negociação sem alçada. | R$ 2,88, lido do cenário "Cobrança, SP, CORPORATE, Tier 3" na BRP Cash (como o pipeline chega a esse valor não está documentado) |
| **Negociado / simulado** | O que o gerente digita na simulação. | R$ 2,70 |

**Uplift.** Ganho anual de receita se o cliente for levado da tarifa atual ao preço-alvo. Ilustrativo: (3,20 − 2,00) × 100.000 eventos/ano = R$ 120.000. Quando a tarifa é alta (≥ 1.000), a fórmula usa a variação percentual sobre a receita (`01-cobrança-fluxo.md:L116`).

**Política "nunca reduzir".** O modelo nunca propõe preço abaixo do que o cliente já paga: o piso do alvo é a tarifa atual (`01-cobrança-fluxo.md:L112`).

**N mínimo de representatividade.** N é o número de grupos econômicos distintos no cluster. Se N < 15, o cluster é pequeno demais para ser referência: mantém-se a tarifa atual e o uplift é zerado (`01-cobrança-fluxo.md:L120`).

**Alçada.** Nível de aprovação exigido quando o gerente negocia abaixo do preço sugerido (`00-doc-negocio.md:L22`). Ilustrativo: negociar 5% abaixo do sugerido passa pelo gerente regional; 15% abaixo, pelo diretor. Os níveis reais estão em `premissas_alcada`, cujo conteúdo não está documentado (`anexos/A0`, §8 item 2).

**Stickiness.** Grau de dependência do cliente em relação ao banco, medido pelo maior entre o share de cash e o share de crédito. Rótulos: Baixo, Médio Baixo, Médio Alto, Alto (`06-matriz-stickiness-impacto-fluxo.md:L84-93`). Cliente "grudado" tem menos chance de sair se o preço subir.

**Impacto.** Relevância financeira do cliente para o banco, medida pelo maior entre o score de ROB e o score de receita de cash. Rótulos: Baixo, Médio, Alto (`06:L115-123`).

**Reciprocidade.** Contrapartida que o cliente oferece ao banco para justificar uma condição de preço: saldo aplicado (Invest Fácil, DAV), volume de boletos no banco versus concorrência (share of wallet), volumetria contratada. Hoje os indicadores existem, mas não há comparação entre o que foi acordado e o que foi entregue (`anexos/A1`, Lacunas transversais).

**Ciclo de precificação (anomes) x onda de reprecificação.** O **ciclo** é a publicação periódica da base de referência, identificada pelo mês (por exemplo, 202605); hoje as tabelas SAS são mensais, exceto o preço por produto, que é semestral (`07-planilha-ano1-fluxo.md:L112`). A **onda** é o ciclo de reprecificação de clientes, em que a equipe decide quem reajustar e comunica os novos preços (`anexos/A0`, §1). Um ciclo publica dados; uma onda muda tarifas.

## 6. O que o projeto quer construir

**Objetivo.** Implementar o **Motor de Precificação Cash (MPC)** para parametrizar, controlar e fornecer tarifas dos produtos de payments, permitindo que canais consultem e simulem online preço-alvo, sugerido, vigente e histórico (`00-doc-negocio.md:L3`). A Calculadora Salesforce deixa de ser "o produto" e vira um **canal** do motor (`anexos/A0`, §1).

**Escopo em linguagem simples** (`00-doc-negocio.md:L7-22`): o motor classifica o cliente (tier e cluster), consulta o cenário dele na BRP Cash e devolve os preços por cliente e produto; permite simular sem efetivar tarifa; consulta o preço vigente e o histórico no legado; tem telas de parametrização com versionamento; registra auditoria de tudo; expõe APIs; tem ambiente de staging; controla acesso por perfil; valida os dados de entrada; e suporta alçadas para preços abaixo do sugerido.

**Premissas em linguagem simples** (`00-doc-negocio.md:L26-42`): o time de Precificação é dono das regras; as bases vêm do Databricks; o motor consulta as bases sem substituí-las; os canais cuidam das próprias interfaces; começa por payments no Atacado; implantação gradual por pilotos; precisa de contingência quando o motor estiver fora; parametrizações podem ter vigência agendada.

**Capacidades** (`anexos/A0`, §3):

| ID | Capacidade | Status |
|---|---|---|
| **C1** | Cálculo, Simulação e Entrega de Preços: consulta de preços, simulação e cenários, alçada, preço vigente e histórico, APIs, rastreabilidade. | **Prioritária. É o que funciona hoje** com Calculadora + SAS + SQL 010 + Planilha, e o que o motor substitui primeiro. |
| **C2** | Onda de Reprecificação: planejar a onda, selecionar elegíveis, calcular novo preço, aprovar, efetivar e acompanhar. | **[EVOLUÇÃO — a detalhar com o negócio].** Hoje é feito manualmente na Saída 1 da planilha. Critérios de elegibilidade e gradação não estão definidos. |
| **C3** | Gestão de Reciprocidade: registrar o acordo, monitorar o realizado, detectar desvio, gerar elegibilidade para C2 e alertas ao gerente. | **[EVOLUÇÃO — a detalhar com o negócio].** Nenhum fluxo atual compara acordado x realizado. O que é "acordo de reciprocidade" e onde é registrado ainda não foi definido. |

Atenção: C2 e C3 são capacidades futuras com **pouco detalhamento de negócio**. Ninguém deve assumir que existe regra pronta para elas. O brief decidiu manter C3 como capacidade própria, e não como parte de C2, porque ela começa na contratação e roda continuamente, servindo a outros consumidores além da reprecificação (`anexos/A0`, §3).

**Módulos transversais** (`anexos/A0`, §3):

- **M1 Parametrização.** Catálogo de produtos, domínios, faixas de tier, regra de cluster, percentis, premissas, exceções, janelas temporais, com versionamento, staging, vigência agendada e auditoria. Substitui as listas fixas no código e as abas manuais.
- **M2 Preparação de Dados.** O **Pipeline de Preparação de Preços (PPP)** porta os 7 notebooks para Databricks Workflows e gera a **Base de Referência de Preços Cash (BRP Cash)**, versionada por ciclo. A BRP Cash é o novo nome da "Planilha Ano 1" e contém a Matriz de Cenários de Preço (MPA), com alvo, sugerido e percentis por cenário, a Posição de Preço Cliente-Produto (PPC), com praticado, alvo e sugerido do cenário de cada cliente, a Matriz de Relacionamento e os Indicadores de Reciprocidade.
- **M3 Legado e Base Histórica.** Acesso ao preço vigente e histórico de 12 meses, tarifas de contrato e cadastro via um **Adaptador de Legado**; desligamento gradual de SAS, SQL 010 e Planilha.
- **M4 Governança, Auditoria e Segurança.** Logs, perfis, alçadas, monitoramento, contingência.

## 7. Glossário

| Termo | Definição | Onde aparece |
|---|---|---|
| Alçada | Nível de aprovação para preço abaixo do sugerido | `00-doc-negocio.md:L22`; `premissas_alcada` |
| Anomes | Mês de referência (AAAAMM) que identifica o ciclo de precificação | Tabelas `SIMUL_*_AAAAMM` (`07:L89`) |
| BRP Cash | Base de Referência de Preços Cash: base final versionada consumida pelo motor (hoje Planilha Ano 1) | `anexos/A0` §1 |
| Calculadora Salesforce | Ferramenta do gerente para consultar e simular preços | `07:L40-42` |
| Ciclo de precificação | Publicação periódica da BRP Cash, chave `anomes` | `anexos/A0` §1 |
| Cluster de precificação | Código 1-10 que combina tier, segmento e região | `05:L56-94` |
| Cluster corporate | Clusters usados como referência ponderada para P25/P75 | `02:L50`; `04:L67` |
| DAV | Depósito à vista (saldo em conta corrente) | `06:L45` |
| Evento tarifado | Registro de cobrança de tarifa por evento (registro, baixa etc.) | `01:L5` |
| Grupo econômico (CD_GRUPO) | Consolidação de CNPJs de um mesmo cliente | `01:L19`; `05:L37` |
| Impacto | Relevância financeira do cliente (ROB e receita de cash) | `06:L115-123` |
| Invest Fácil (IF) | Produto de investimento cujo saldo médio mede relacionamento | `06:L44`, `L137` |
| L3M / LTM | Últimos 3 meses / últimos 13 meses | `01:L16-17` |
| Macroproduto | Família de produto: COBRANCA, ARRECADACAO, MULTIPAG, PIX | `05:L34` |
| Modalidade | Tipo de tarifa de cobrança (ex.: QUANDO DO REGISTRO) | `01:L35-55` |
| Motor da Calculadora (SQL 010) | Componente legado que aplica regras e alimenta a Calculadora | `07:L41`, `L114` |
| MPA | Matriz de Cenários de Preço: alvo, sugerido e percentis por cenário produto x região x segmento x tier (hoje `tabela_precos` + "Preço por Produto") | `anexos/A0` §1; `07:L30`, `L77` |
| N | Número de grupos econômicos distintos no cluster | `01:L106` |
| Onda de reprecificação | Ciclo de reajuste de tarifas de clientes (capacidade C2) | `anexos/A0` §1; `07:L18` |
| Percentil (P25…P90) | Estatística da tarifa praticada por cluster | `01:L96` |
| Poder público | Clientes excluídos da análise | `01:L9`; `02:L22` |
| PPC | Posição de Preço Cliente-Produto (hoje `base_total`) | `anexos/A0` §1 |
| PPP | Pipeline de Preparação de Preços (Databricks) | `anexos/A0` §1 |
| Preço alvo | max(tarifa atual, P75 do cluster) | `01:L112` |
| Preço praticado | Tarifa efetivamente cobrada hoje | `01:L19`; `anexos/A0` §2 |
| Preço sugerido | Preço recomendado do cenário do cliente, pré-calculado pelo pipeline e lido da BRP Cash (definição de trabalho) | `anexos/A0` §2; `07:L30`, `L112` |
| Reciprocidade | Contrapartida do cliente (saldo, share, volumetria) por uma condição de preço | `anexos/A0` §3 (C3) |
| Região comercial | SP, SE ex-SP, S, CO, NNE | `05:L52` |
| ROB | Resultado operacional bruto do grupo econômico | `06:L15-18` |
| Segmento | ULTRA, LARGE, CORPORATE, GLOBAL, AGRO CORPORATE (INSTITUCIONAL em aberto) | `02:L15`; `06:L33` |
| SoW de boletos | Share of wallet de cobrança: boletos no banco / total | `06:L55` |
| Stickiness | Dependência do cliente (share de cash e de crédito) | `06:L84-93` |
| Tier de volume | Faixa de volume mensal por produto (Tier 1 maior, Tier 3 menor) | `01:L61`; `02:L30` |
| Uplift | Ganho anual de receita ao levar a tarifa ao preço-alvo | `01:L114-116` |
| Visão Cliente / Banco | Lado tarifado da modalidade de cobrança | `01:L57` |

## 8. Perguntas que você vai ouvir nas reuniões e como responder

1. **"O motor vai substituir a Calculadora Salesforce?"** Não. A Calculadora continua sendo a tela do gerente. O que muda é a origem dos números: em vez de SAS + SQL 010, ela consome as APIs do motor (`anexos/A0`, §1).

2. **"Qual a diferença entre preço alvo e preço sugerido?"** O alvo é a referência do cluster (max entre tarifa atual e P75). O sugerido é o preço recomendado do cenário do cliente (produto x região x segmento x tier), que já vem pronto na BRP Cash; o motor só classifica o cliente e lê o cenário. Como o pipeline deriva o sugerido do alvo (premissas de desconto por relacionamento, custos, RFP, nichos) não está documentado. Essas definições são de trabalho e ainda precisam de validação com o negócio (`anexos/A0`, §2).

3. **"O modelo pode propor redução de tarifa?"** Não. A política é "nunca reduzir": o piso do alvo é a tarifa atual (`01-cobrança-fluxo.md:L112`).

4. **"Por que P75 e não P50?"** É a escolha atual do modelo em todos os produtos (`anexos/A1`, Síntese item 30). O motor deve tratar o percentil-alvo como parâmetro, não como constante.

5. **"O que acontece se o cluster tiver poucos clientes?"** Se N < 15, o cluster não serve de referência: mantém-se a tarifa e o uplift é zero (`01:L120`).

6. **"A onda de reprecificação vai ser automática?"** Ainda não. C2 é evolução e o negócio não detalhou elegibilidade, gradação nem se o motor efetiva a tarifa no legado (`anexos/A0`, §8 item 4).

7. **"O que é reciprocidade e o sistema já controla?"** É a contrapartida do cliente (saldo, share, volume). Hoje só se mede o realizado; não existe registro do acordado. C3 é evolução (`anexos/A1`, Lacunas transversais).

8. **"Onde está a regra do preço sugerido hoje?"** Na macro da planilha (aba "Preço por Produto", `07:L30`) e no Motor da Calculadora (SQL 010), ambos não documentados. O valor resultante já existe por cenário na Planilha Ano 1 (`SIMUL_PRECO_POR_PRODUTO`, `07:L112`); no TO-BE essa regra fica no pipeline, e o motor apenas lê o cenário. É a lacuna número 1 do projeto (`anexos/A0`, §8 item 1).

9. **"Por que o grupo 616 é excluído?"** Ninguém documentou o motivo. Em Cobrança fala-se em "grupo Bradesco". Precisa de decisão do negócio (`anexos/A0`, §8 item 5).

10. **"INSTITUCIONAL está no escopo?"** Está em aberto: entra no esqueleto de preços, mas é excluído da matriz de relacionamento (`anexos/A2`, Fluxo 06 §9).

11. **"Por que Arrecadação usa regra de cluster diferente?"** Não se sabe se é intencional. Em Arrecadação, cluster 3 = LARGE/INSTITUCIONAL e 4 = CORPORATE, invertendo os demais produtos, e não há região (`anexos/A1`, Arrecadação §9).

12. **"O preço vigente vai ser em tempo real?"** Depende de decisão do negócio. O brief prevê duas estratégias: foto via Databricks e consulta online ao legado (`anexos/A0`, AD-10).

13. **"Ciclo e onda são a mesma coisa?"** Não. Ciclo é a publicação mensal ou semestral da base de referência (`anomes`). Onda é o processo de reajustar clientes (C2) (`anexos/A0`, §1).

14. **"Vamos precisar de um motor de regras tipo FICO?"** A decisão atual é não: as regras são tabelas de faixas que cabem em parametrização de dados. Reavaliar só se C2 trouxer políticas muito complexas (`anexos/A0`, AD-04).

15. **"Quando o SAS e o SQL 010 são desligados?"** Gradualmente, por produto, depois de execução paralela (shadow) entre o motor novo e o legado (`anexos/A0`, AD-14).
