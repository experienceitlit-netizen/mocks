# 08 — Especificações Técnicas: Motor de Precificação Cash (MPC)

| Campo | Valor |
|---|---|
| Versão | 1.1 |
| Data | 2026-09-18 |
| Revisão 1.1 (2026-09-18) | preço sugerido passa a ser lido da BRP Cash por cenário (brief §2); o `svc-pricing` não o calcula. Revisão 1.2 (2026-10-02): metas de RNF-01 e RNF-02 detalhadas (`anexos/A0` §7) e aplicadas em SPEC-PRC-04, SPEC-API-01, SPEC-SF-01 e SPEC-OBS-01 |
| Status | Rascunho para validação |
| Fontes | `anexos/A0-brief-decisoes.md` (nomes §1, definições §2, decisões §6, requisitos §7, lacunas §8, fases §9); `anexos/A1-analise-fluxos-produtos.md` (regras por produto, 34 famílias de parâmetros); `anexos/A2-analise-fluxos-consolidacao.md` (fluxos 05-07, entidades da BRP Cash); `06-arquitetura-solucao.md` (contêineres, modelo de dados, APIs); `07-componentes-definicao-justificativa.md`; `stack-tech.md` |
| Documentos relacionados | 06 Arquitetura; 07 Componentes; 09 Roadmap |

Propósito: descrever, por épico e item de especificação (`SPEC-<COMP>-<nn>`), **o que construir** com detalhe suficiente para a posterior quebra em tasks. Este documento **não** cria tasks. Cada SPEC traz objetivo, descrição técnica, critérios de aceite, dependências, requisitos (RF/RNF), fase (F0-F5), complexidade (P/M/G/GG) e dúvidas a resolver (referenciando as lacunas do brief §8). Fórmulas e valores são apenas os que constam nos anexos; tudo o que foi deduzido está marcado **(inferido)** e o que depende de decisão de negócio está marcado **[A DEFINIR — lacuna n]**. C2 e C3 são **[EVOLUÇÃO — a detalhar com o negócio]**.

---

## 0. Convenções

### 0.1 Nomenclatura

| Domínio | Convenção | Exemplos |
|---|---|---|
| Componentes | Nomes canônicos do brief §6 | `svc-pricing`, `dbx-ppp`, `sql-motor`, `sf-calculadora` |
| Schemas no sql-motor | Um schema por serviço dono; `brp` para as entidades da BRP Cash; `stg` para staging do reverse ETL | `brp.matriz_cenarios_preco`, `parametros.parametro_versao`, `pricing.cotacao`, `alcada.pedido_aprovacao`, `stg.matriz_cenarios_preco` |
| Tabelas e colunas | `snake_case`, singular para entidade, `anomes` como `CHAR(6)` (AAAAMM), chaves compostas explícitas, `_json` para colunas JSON | `cd_grupo`, `cod_produto`, `preco_alvo`, `preco_sugerido`, `entrada_json` |
| Delta (Unity Catalog) | Catálogo `mpc_<amb>`; schemas `bronze` (fontes governadas, não copiadas), `silver` (bases por produto), `brp` (gold) | `mpc_prd.silver.cobranca_vats`, `mpc_prd.brp.posicao_preco_cliente_produto` |
| Tarefas do Workflow | `T<nn>_<nome>` conforme doc 06 §5.1 | `T2_uplift_cobranca`, `T9_validar_brp` |
| APIs | `/mpc/v1/<recurso>` no Axway; recursos no plural em português; JSON `snake_case` | `/mpc/v1/precos/simulacoes` |
| Eventos | `mpc.<contexto>` como tópico; nome do evento em PascalCase no passado | `mpc.publicacao` / `VersaoBrpPublicada` |
| Perfis (claims JWT) | `<contexto>.<papel>` | `precificacao.editor`, `alcada.nivel2`, `comercial.gerente` |
| Códigos de produto | `cod_produto` estável (slug maiúsculo) e `nome_produto` igual ao AS-IS | `COB_BAIXA_COMPENSACAO_CLIENTE` / `NA BAIXA POR COMPENSACAO Cliente` |
| Referências a fontes | `NN:L<linha>` abrevia `docs-precificacao/<arquivo>:L<linha>` para os fluxos 01 a 07; `00-etapas:L<linha>` é `00-etapas-geracao-planilha-ano1.md`; `A1`/`A2` são os anexos; "lacuna n" é o brief §8; P1-P10 são as decisões pendentes do doc 06 §11 e "dor Dn" as dores do doc 06 §2 (as dúvidas D1-D15 da §16 deste documento são outra lista) | `01:L112` = `docs-precificacao/01-cobrança-fluxo.md:L112` |

Nota sobre nomes físicos: o schema `stg` (`stg.<entidade>`) corresponde às tabelas `stg_*` citadas nos docs 06 e 07, e as views `brp.v_brp_ativa_*` (uma por entidade) correspondem à view `v_brp_ativa` do doc 06.

### 0.2 Padrões de código Java / Spring

- Java 21, Spring Boot 3.x, Maven multi-módulo por serviço (`<svc>-domain`, `<svc>-application`, `<svc>-adapters`, `<svc>-app`), arquitetura hexagonal: domínio sem dependência de framework; portas de entrada (REST) e saída (JDBC, HTTP, eventos) em adapters.
- Persistência com Spring Data JDBC (sem lazy loading); migrações Flyway versionadas junto do serviço (`V<yyyyMMddHHmm>__<descricao>.sql`); nenhuma DDL fora do Flyway.
- Contratos OpenAPI 3.1 gerados no build (springdoc) e publicados no Axway; DTOs de API separados do modelo de domínio.
- Resiliência com Resilience4j (timeout, retry idempotente, circuit breaker) nas chamadas a legado e entre serviços; Micrometer para métricas; `X-Correlation-Id` propagado por filtro.
- Regras de negócio como **estratégias** (`interface EstrategiaTier`, `EstrategiaCluster`, `EstrategiaCenario` para o lookup do cenário na BRP) selecionadas por parâmetro (grupo de regra), nunca por `if` em produto. Não existe estratégia de cálculo do sugerido no motor: o sugerido é lido do cenário (Revisão 1.1).
- Testes: JUnit 5 + AssertJ; Testcontainers (imagem `mcr.microsoft.com/mssql/server`) para repositórios e procedures; ArchUnit para dependências entre camadas; testes de contrato (Spring Cloud Contract ou Pact) entre svc-pricing ↔ svc-alcada ↔ svc-legado-adapter; cobertura mínima de 85% no módulo de domínio; **golden tests**: cada regra de cálculo tem um arquivo de casos (entrada/saída) derivado dos notebooks.
- Logs estruturados em JSON com `correlation_id`, `usuario`, `versao_brp`, `versao_parametros`; nunca logar CNPJ completo (mascarar).

### 0.3 Padrões PySpark / Databricks

- Repositório único `dbx-ppp` com Databricks Asset Bundles (`dev`, `hml`, `prd`); notebooks são apenas orquestradores; a lógica fica em pacote Python `ppp/` (`ppp/regras/tier.py`, `cluster.py`, `percentis.py`, `preco_alvo.py`, `preco_sugerido.py`, `relacionamento.py`, `qualidade.py`, `parametros.py`) com funções puras sobre DataFrames Spark.
- Testes com pytest e Spark local (`chispa` para comparação de DataFrames); um caso de teste por regra dos anexos, com os valores literais dos docs fonte; teste de regressão com amostra anonimizada comparando saída do notebook AS-IS x tarefa portada.
- Sem datas ou listas literais no código: tudo derivado de `anomes` e de `GET /parametros/vigentes` (SPEC-PPP-01). Toda tarefa recebe `anomes`, `versao_parametros`, `modo`.
- Escrita Delta idempotente: `MERGE`/`replaceWhere anomes = :anomes`; nunca `overwrite` de tabela inteira. Tabelas gold com `CHECK (anomes rlike '^[0-9]{6}$')` e propriedade `delta.enableChangeDataFeed = true`.
- Qualidade: expectations declaradas em `ppp/qualidade/contratos/*.yaml`; resultado sempre gravado em `brp.qualidade_ciclo`.

### 0.4 Versionamento de API, erros, idempotência

- Versão maior no caminho (`/v1`); compatível = campos novos opcionais; incompatível = `/v2` com convivência de duas versões e depreciação anunciada no catálogo do Axway.
- Erros em `application/problem+json` (RFC 7807): `type`, `title`, `status`, `detail`, `instance`, `correlation_id`, `erros[]{campo, codigo, mensagem}`. Códigos de negócio estáveis (`SEM_REFERENCIA_CLUSTER`, `VERSAO_NAO_VIGENTE`, `PERFIL_INSUFICIENTE`).
- Idempotência em todo `POST` que cria estado: cabeçalho `Idempotency-Key` (UUID) com retenção de 24 h por cliente OAuth; repetição devolve a mesma resposta (`200` com `X-Idempotent-Replay: true`).
- Cabeçalhos de resposta: `X-Versao-BRP`, `X-Versao-Parametros`, `X-Versao-API`, `X-Correlation-Id`.

### 0.5 Escala de complexidade e formato dos SPECs

| Sigla | Ordem de grandeza |
|---|---|
| P | até 1 sprint de uma dupla |
| M | 1-2 sprints de uma dupla |
| G | 2-4 sprints, uma squad |
| GG | mais de 4 sprints ou mais de uma frente (Java + Databricks + Salesforce) |

Cada SPEC segue: linha de metadados (fase, complexidade, RF/RNF, dependências), objetivo, descrição técnica, critérios de aceite, dúvidas.

---

## 1. Épico PPP — Pipeline de Preparação de Preços (dbx-ppp)

Contexto: porta os sete notebooks (`01_Base_cobranca` … `07_Matriz de Stickiness vs Impacto`) para tarefas de um Databricks Workflow `ppp_ciclo`, gerando a BRP Cash por `anomes`. Padrão comum dos quatro fluxos de produto em `A1` Síntese transversal (15 etapas); consolidação em `A2` Fluxo 05; relacionamento em `A2` Fluxo 06.

### SPEC-PPP-01 — Biblioteca comum de regras (`ppp/regras`) e leitura de parâmetros

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-13, RNF-07, RNF-09 | **Depende de** SPEC-PAR-02, SPEC-PAR-04

Objetivo: implementar uma única vez as regras repetidas nos quatro fluxos de produto (tier, cluster, percentis com referência corporate e cummin, preço-alvo, uplift, N mínimo) e o cliente de parâmetros, eliminando as cópias entre notebooks.

Descrição técnica:

- `ppp/parametros.py`: `carregar_conjunto_vigente(anomes, versao_parametros=None) -> ConjuntoParametros` via `GET /parametros/vigentes?data=<último dia do anomes>` (SPEC-PAR-04); resultado cacheado por execução e gravado como snapshot em `brp.parametros_snapshot(anomes, versao_id, conteudo_json)` para reprodutibilidade.
- `classificar_tier(df, faixas)`: faixas por `cod_produto` com `limite_inferior`, `limite_superior`, `base_volume` (`MEDIA_MENSAL` | `TOTAL_ANUAL`) e flag `sem_tier3`. Regra (A1 `01:L59-79`, `02:L30`, `03:L52-56`, `04:L45-48`): volume ≤ limite T3 → Tier 3; ≤ limite T2 → Tier 2; acima → Tier 1; se `sem_tier3`, tudo abaixo do limite de Tier 2 é Tier 2 (caso DEBITO DE COBRANCA C/C).
- `classificar_cluster(df, regras)`: tabela (grupo_regra, tier, segmento ou `*`, regiao ou `*`) → cluster; resolução do mais específico para o genérico. Valores hoje em código (A2 `05:L60-94`): Grupo 1: T1→1, T2→2, T3+ULTRA/GLOBAL→3, T3+LARGE→4, T3+AGRO→10, T3+demais por região SP→5, SE ex-SP→6, S→7, CO→8, NNE→9. Grupo 2 (DEBITO DE COBRANCA C/C Banco/Cliente): T1→1; T2 ou T3: ULTRA/GLOBAL→2, LARGE→3, AGRO→10, demais→4. Grupo 3: T1→1, T2→2, T3: ULTRA/GLOBAL→3, LARGE→4, AGRO→10, demais→5. Sem correspondência → `cluster = NULL` e registro em `qualidade_ciclo` (nunca descarte silencioso).
- `percentis_por_cluster(df, cfg)` (A1 `01:L94-106`, `02:L48-50`): para cada `cod_produto`: P35, P40, P50, P60, P90 diretos por cluster sobre `TARIFA`; P25 e P75 calculados como **referência corporate** = média ponderada por `campo_peso` (QT_MENSAL / QTDE / QTDE_ARRECADADO) do percentil entre os `clusters_corporate` (hoje `[5,6,7,8,9]` em Multipag/PIX, `[5]` em Arrecadação, ilegível em Cobrança); a referência ocupa o cluster auxiliar `9999`; para os demais clusters na ordem `[10, 4, 3, 2, 1]` aplica-se o mínimo acumulado partindo da referência (`P_c = min(P_c_bruto, P_anterior)`); `N = count distinct cd_grupo` por cluster.
- `preco_alvo_uplift(df, cfg)` (A1 `01:L108-120`): `PRECO_ALVO = max(TARIFA, P<percentil_alvo>)` com `percentil_alvo = 75`; `UPLIFT = (PRECO_ALVO − TARIFA) × QTDE_TOTAL` se `TARIFA < limiar_uplift (1.000)`, senão `(PRECO_ALVO / TARIFA − 1) × RECEITA`; se `N < n_minimo (15)`: `PRECO_ALVO = TARIFA`, `UPLIFT = 0`, `flag_nao_representativo = true`.
- `filtros_comuns(df, cfg)`: exclusão de Poder Público (lista `PODER_PUBLICO`), grupos excluídos (`GRUPO_EXCLUIDO`: 616 e "grupo Bradesco", A1 lacunas), segmentos elegíveis, janela LTM (13 referências terminando em `anomes`, A1 `02:L17`), `cd_grupo = 0` (A2 `05:L37`).
- Enriquecimento: `segmentos` (dedup por CNPJCPF + SEGMENTO + CD_GRUPO, com regra de desempate parametrizada), `uf_regiao` (de-para `UF_REGIAO`, chave por CD_GRUPO ou CNPJ conforme produto).

Critérios de aceite:

- Dado o arquivo de casos dourados extraído dos notebooks (uma amostra por produto), quando as funções são aplicadas, então tier, cluster, percentis, preço-alvo e uplift são idênticos (tolerância 1e-6).
- Dado um produto sem regra de cluster, quando classificado, então `cluster` é nulo e existe linha em `qualidade_ciclo` com `regra = CLUSTER_AUSENTE`.
- Nenhuma constante numérica das tabelas de A1 §4 aparece no código (verificação por teste de lint que procura os literais `616`, `1000`, `15`, `202506`).

Dúvidas: clusters corporate de Cobrança (lacuna 8); grupo Bradesco = 616? (lacuna 5); regra de desempate CNPJ com dois grupos (A2 `06` §9).

### SPEC-PPP-02 — T0 `validar_fontes`: contratos de dados das bases bronze

**Fase** F1 (básico) / F2 (completo) | **Complexidade** M | **RF/RNF** RF-08, RNF-06 | **Depende de** SPEC-PPP-01

Objetivo: substituir a extração para a pasta `entradas` pela leitura direta das tabelas governadas, validando esquema, janela e volume antes de qualquer cálculo.

Descrição técnica: para cada fonte de `00-etapas:L5-18` (eventos tarifados e movimento de Cobrança, `multipag_atualizado`, `contratos_multipag`, `pix`, `arrecadacao`, `segmentos_atualizados`, `poder_publico`, `associacoes_religiosas`, `rob_historico`, `rob_uf`, `cashxcred`, `SHARE_CREDITO`, `saldo_invest`, `saldo_dav`, `share_boletos`) um contrato YAML com colunas obrigatórias e tipos, chave, `ref` mínima/máxima esperada (derivada de `anomes` e da janela parametrizada), volume mínimo e variação máxima em relação ao ciclo anterior (±X%, parâmetro), regras de nulos. Resultado em `brp.qualidade_ciclo(anomes, tarefa, fonte, regra, severidade, valor, limite, status, detalhe_json, dt)`. Severidade `BLOQUEANTE` interrompe o workflow; `ALERTA` segue. Trata as particularidades de layout descritas em A1 (`latin-1`, separadores, `decimal=','`, `.0f`) no ponto de ingestão, não nas regras.

Critérios de aceite: fonte com coluna faltante → workflow falha em T0 com linha `BLOQUEANTE`; fonte com `ref` máxima menor que `anomes` → `BLOQUEANTE` "fonte desatualizada"; volume 40% abaixo do ciclo anterior → `ALERTA` visível em `qualidade_ciclo`.

Dúvidas: nomes físicos das tabelas bronze (A1 Cobrança §9); janela de `share_boletos` (12 meses em `00-etapas:L8`, não confirmada).

### SPEC-PPP-03 — T1 `base_cobranca` (porte do nb 01, Etapa 1) e Emissões L3M

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-13 | **Depende de** SPEC-PPP-01, SPEC-PPP-02

Objetivo: gerar `silver.cobranca_tratada` e as emissões dos últimos 3 meses.

Descrição técnica (A1 Cobrança §3 Etapa 1): (1) carregar eventos tarifados de cobrança; (2) normalizar; (3) juntar `segmentos` por CNPJ/CPF; (4) classificar emissor **[regra não descrita, `01:L8`]**; (5) excluir Poder Público; (6) classificar produto por de-para `DESCR_TARIFA → modalidade` nas 13 modalidades com visão Cliente/Banco (parâmetro `MAPA_DESCR_TARIFA_PRODUTO`); (7) gateway impressão/postagem **[regra não descrita, `01:L11`]**; (8) filtrar segmentos elegíveis; (9) consolidar quantidade e receita por `cd_grupo × produto × mês`; (10) excluir grupo Bradesco (`GRUPO_EXCLUIDO`); (11) `TARIFA_PRATICADA = VALOR_TARIFADO / QTD` **(inferido)**; (12) indicadores L3M: `qtde_l3m` por `cd_grupo × produto` nas 3 últimas referências; (13) LTM 13 meses: `QTD_TOTAL`, `VALOR_TARIFADO` anuais, `QTD_MENSAL` média; (14) UF por CPF/CNPJ e região por `UF_REGIAO`.

Saídas Delta: `silver.cobranca_tratada(anomes, segmento, cd_grupo, cod_produto, qtd_mensal, qtd_total, valor_tarifado, tarifa_praticada, uf, regiao)`; `silver.cobranca_l3m(anomes, cd_grupo, cod_produto, qtde_l3m)` → alimenta `brp.indicadores_reciprocidade.emissoes_l3m` (SPEC-BRP-01).

Critérios de aceite: soma de `valor_tarifado` da base tratada = soma da base AS-IS para o mesmo mês (tolerância 0,01%); nenhum registro com `cd_grupo` em `GRUPO_EXCLUIDO`; `qtde_l3m` reproduz `df_qtde_L3M.csv` do ciclo de referência.

Dúvidas: regras das etapas 4, 7 e 11 (A1 Cobrança §9); layout de `df_qtde_L3M` (A2 Fluxo 07 §9); mapeamento `DESCR_TARIFA` (lacuna 2, inferido).

### SPEC-PPP-04 — T2 `uplift_cobranca` (porte do nb 02)

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13 | **Depende de** SPEC-PPP-03

Objetivo: gerar `silver.cobranca_vats` por modalidade com tier, cluster, percentis, preço-alvo e uplift.

Descrição técnica (A1 `01:L21-33`): filtrar `qtd_mensal > 0`; para cada modalidade do catálogo com `macroproduto = COBRANCA` (lista parametrizada, não laço fixo de 13): `classificar_tier` (faixas por modalidade, ex. NA BAIXA POR COMPENSACAO Cliente ≤ 25.500 / ≤ 150.000 / > 150.000; QUANDO DO REGISTRO Cliente ≤ 17.000 / ≤ 100.000 / > 100.000; DEBITO DE COBRANCA C/C sem Tier 3 com limites ≤ 75.000 Banco e ≤ 30.000 Cliente), `classificar_cluster` (grupo de regra do produto), `percentis_por_cluster` (peso `QT_MENSAL`), `preco_alvo_uplift`. Empilhar em `silver.cobranca_vats(anomes, segmento, cd_grupo, cod_produto, cluster, tier, qt_mensal, qt_total, vlr_tarifado, tarifa, p25, p35, p40, p50, p60, p75, p90, preco_alvo, uplift, n, flag_nao_representativo)`.

Critérios de aceite: para o `anomes` de referência, `COBRANCA_vats.xlsx` e a tabela portada coincidem em (cd_grupo, produto) com `preco_alvo` e `uplift` iguais (tolerância 1e-4); soma de `uplift` igual ao valor exibido no notebook.

Dúvidas: clusters regionais 5-9 existem em Cobrança? (`01:L92` cortado, lacuna 8); quais modalidades tratam Tier 2 como cluster próprio (`01:L88`).

### SPEC-PPP-05 — T3 `multipag` (porte do nb 03)

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13 | **Depende de** SPEC-PPP-01, SPEC-PPP-02

Objetivo: gerar `silver.multipag_vats` (produto `FORNECEDORES TED`).

Descrição técnica (A1 Multipag §3): (1) segmentos dedup; (2) `multipag_atualizado` com `REF` → data e `MES`; (3) manter `REF` na LTM (13 refs terminando em `anomes`), somar `VALOR`, `QTDE` por `MES × CNPJCPF × CONTRATO`; (4) contratos: filtro `rservc = 'PAGAMENTO VIA TED'` e `rmodld = 'FORNECEDORES'` controlado por parâmetro `aplicar_filtro_contrato` (hoje o filtro é sobrescrito, `02:L19`; default do porte = **manter comportamento efetivo = sem filtro**, com decisão registrada); tarifa vigente = primeira ocorrência por `nseq_contr_negoc` ordenada por `dinic_vgcia` desc; (5) juntar por `CONTRATO`; (6) segmento/grupo por CNPJCPF; (7) segmentos elegíveis; `RECEITA = TARIFA × QTDE`; (8) PP = 1 excluído; (9) `GRUPO_EXCLUIDO` (616); (10) consolidar por `MES × SEGMENTO × CD_GRUPO`: `TARIFA = RECEITA / QTDE`; por grupo: `QTDE` = média mensal, `RECEITA`, `QTDE_TOTAL` = somas, `TARIFA` = última com `QTDE > 0` **ordenada por MES** (corrige o não-determinismo de `02:L26`); (11) UF por `CD_GRUPO` (`rob_uf`) e região; (12) tier ≤ 4.000 / ≤ 50.000 / > 50.000 sobre média mensal; (13) cluster Grupo 1; (14) percentis com corporate `[5,6,7,8,9]`, peso `QTDE`; (15) preço-alvo e uplift.

Saída: `silver.multipag_vats(anomes, segmento, cd_grupo, cod_produto='FORNECEDORES TED', qtde, qtde_total, receita, tarifa, uf, regiao, tier, cluster, p25..p90, n, preco_alvo, uplift, flag_nao_representativo)`.

Critérios de aceite: com `aplicar_filtro_contrato = false` reproduz `MULTIPAG_vats.xlsx` do ciclo de referência; com `true`, a diferença de linhas é listada em `qualidade_ciclo` como `ALERTA` informativo.

Dúvidas: intenção do filtro de contrato (A1 Multipag §9); motivo do 616 (lacuna 5); origem de `rob_uf`.

### SPEC-PPP-06 — T4 `pix` (porte do nb 04)

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13 | **Depende de** SPEC-PPP-01, SPEC-PPP-02

Objetivo: gerar `silver.pix_vats` (produto `PIX PAGAMENTOS`).

Descrição técnica (A1 PIX §3): LTM 13 refs; segmentos; segmentos elegíveis; PP; `GRUPO_EXCLUIDO`; `CD_TARF ∈ lista CD_TARF_PIX_PAGAMENTOS` (hoje `{5518, 5517, 5534, 5563}`); `RCTA ≥ 0` (parâmetro `tratamento_receita_negativa = EXCLUIR`); consolidar por `REF × SEGMENTO × CD_GRUPO`: somas de `QTDE`, `RCTA`, `TARIFA = RCTA / QTDE` (0 se `QTDE = 0`); por grupo: `QTDE` média, `RCTA` e `QTDE_TOTAL` somas, `TARIFA` = última com `QTDE > 0` em ordem cronológica; UF por `CD_GRUPO`, região; tier ≤ 100 / ≤ 500 / > 500; cluster Grupo 1; percentis corporate `[5,6,7,8,9]`, peso `QTDE`; preço-alvo/uplift com `RCTA` como receita. Saída `silver.pix_vats` com o mesmo layout de Multipag (`rcta` renomeado para `receita`). A saída auxiliar `uf_por_grupo.xlsx` vira `silver.uf_por_grupo(anomes, cd_grupo, uf, regiao)`.

Critérios de aceite: reproduz `PIX_vats.xlsx`; alteração da lista `CD_TARF` via parâmetro muda o recorte sem alteração de código (teste com lista reduzida).

Dúvidas: significado dos códigos `CD_TARF` e da receita negativa (A1 PIX §9); consumidor de `uf_por_grupo`.

### SPEC-PPP-07 — T5 `arrecadacao` (porte do nb 05)

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13 | **Depende de** SPEC-PPP-01, SPEC-PPP-02

Objetivo: gerar `silver.arrecadacao_completa_vats` e `silver.arrecadacao_vats` (recorte `DIVERSOS`).

Descrição técnica (A1 Arrecadação §3): tipos (`CNPJCPF`, `AGENCIA` texto; valores com `.`/`,` tratados na ingestão); segmentos; PP; produto pela mídia via `MAPA_MIDIA_PRODUTO` (`MOBILE BANKING`, `NET EMPRESA`, `INTERNET BANKING` → `CANAIS DIGITAIS`; demais mantêm o nome); LTM; segmentos elegíveis; consolidar por `REF × SEGMENTO × CD_GRUPO × PRODUTO × Tipo_Documento` (somas; `TARIFA = RECEITA / QTDE_ARRECADADO`, 0 se zero); anual por `SEGMENTO × CD_GRUPO × PRODUTO × Tipo_Documento` (somas; `TARIFA` da última referência); `GRUPO_EXCLUIDO`; para cada produto em escopo (`CANAIS DIGITAIS`, `DÉBITO AUTOMÁTICO`, parametrizado): tier sobre **total anual** `QTDE_ARRECADADO` (CANAIS DIGITAIS ≤ 200.000 / ≤ 5.000.000 / > 5.000.000; DÉBITO AUTOMÁTICO ≤ 70.000 / ≤ 750.000 / > 750.000), cluster com regra **própria de Arrecadação** (T1→1, T2→2, T3: LARGE ou INSTITUCIONAL→3, CORPORATE→4, AGRO→10, demais→5; sem região; `04:L54-61`) registrada como grupo de regra `ARRECADACAO` no parâmetro, percentis com corporate `[5]` e peso `QTDE_ARRECADADO`, preço-alvo/uplift. Saída completa e recorte `Tipo_Documento = 'DIVERSOS'` (parâmetro `tipo_documento_recorte`).

Critérios de aceite: reproduz `ARRECADACAO_COMPLETA_vats.xlsx` e `ARRECADACAO_vats.xlsx`; a regra de cluster de Arrecadação e a do Grupo 3 do fluxo 05 aparecem como dois grupos de regra distintos no parâmetro, com a divergência registrada em `qualidade_ciclo` como `ALERTA` `REGRA_CLUSTER_DIVERGENTE` até decisão.

Dúvidas: divergência de cluster (lacuna 5, `04:L58-61` x `05:L85-94`); base de volume anual x mensal (inferido); motivo do recorte DIVERSOS.

### SPEC-PPP-08 — T6 `uplift_consolidado` (porte do nb 06): MPA e PPC

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-13, RNF-07 | **Depende de** SPEC-PPP-04..07, SPEC-BRP-01

Objetivo: gerar as duas entidades centrais da BRP Cash: `brp.matriz_cenarios_preco` (MPA, Matriz de Cenários de Preço) e `brp.posicao_preco_cliente_produto` (PPC). Cada linha da MPA é um **cenário** (produto x tier x segmento x região → cluster) com alvo, sugerido e percentis; o sugerido é preenchido por SPEC-PPP-13.

Descrição técnica (A2 Fluxo 05 §3):

1. Percentis únicos por `cod_produto × cluster` de cada `*_vats` (P25, P35, P40, P50, P60, P75, P90, N), primeira ocorrência; Arrecadação usa a base **completa**; Multipag/PIX recebem produto fixo pelo catálogo.
2. Esqueleto = produto cartesiano `catalogo_produto(ativo) × dominio(TIER) × dominio(SEGMENTO) × dominio(REGIAO)` (hoje 18 × 3 × 6 × 5 = 1.620), gerado do catálogo, não de lista fixa.
3. `classificar_cluster` no esqueleto pelo grupo de regra de cada produto.
4. Junção esqueleto × percentis por `cod_produto + cluster` com **política de ausência parametrizada** (`politica_sem_percentil = DESCARTAR | MANTER_NULO`), default `MANTER_NULO` com `status_linha = 'SEM_REFERENCIA'` e alerta; nunca inner silencioso (`05:L28`, `L96`).
5. `preco_alvo_ref = P<percentil_alvo>` por linha; `n` da origem; `cenario_id` determinístico (`anomes-cod_produto-tier-segmento-regiao`); `preco_sugerido` e `origem_sugerido` ficam nulos nesta tarefa e são preenchidos por T6b (SPEC-PPP-13).
6. PPC: recorte das `*_vats` aos campos padrão com de-para (Cobrança `QT_MENSAL→qtde_mensal`, `QT_TOTAL→qtde_anual`, `VLR_TARIFADO→receita`; Multipag/PIX `QTDE→qtde_mensal`, `QTDE_TOTAL→qtde_anual`, `RCTA→receita`; Arrecadação `QTDE_ARRECADADO→qtde_anual`, `qtde_mensal = qtde_anual / divisor_mensalizacao (12)`); `macroproduto` do catálogo; união; excluir `cd_grupo = 0`; adicionar `tier`, `regiao`, `uf` e `cenario_id` (o cenário da MPA em que o cliente caiu no ciclo; hoje ausentes em `base_total`, inferido como necessário para o motor); `preco_sugerido` da PPC é copiado do cenário por T6b.
7. Métrica `soma_uplift` gravada em `qualidade_ciclo`.

Critérios de aceite: MPA tem uma linha por combinação do esqueleto (com ou sem referência) e nenhuma linha duplicada por chave; PPC reproduz `base_total.xlsx` nas colunas comuns; todo registro da PPC aponta para um `cenario_id` existente na MPA do mesmo `anomes`; produto novo cadastrado no catálogo (sem código) aparece no esqueleto no ciclo seguinte.

Dúvidas: fallback para combinações sem percentil (lacuna 5); `NA BAIXA POR PAGAMENTO Banco` sem grupo; `CANAIS DIGITAIS`/`DÉBITO AUTOMÁTICO` sem fonte declarada em 05; INSTITUCIONAL no esqueleto.

### SPEC-PPP-09 — T7 `stickiness_impacto` (porte do nb 07): Matriz de Relacionamento e Indicadores

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-13, RF-12 (insumo) | **Depende de** SPEC-PPP-01, SPEC-PPP-02, SPEC-BRP-01

Objetivo: gerar `brp.matriz_relacionamento` e `brp.indicadores_reciprocidade` (saldo IF/DAV, SoW boletos).

Descrição técnica (A2 Fluxo 06 §3-4), com janelas derivadas de `anomes`:

- Impacto: `rob_historico` com `REF` nos últimos `janela_rob` meses (6; substitui `REF >= 202506`); `RESULTADO_OPERACIONAL = Σ RESULTADO` por `SEGMENTO × CD_GRUPO`; `RECEITA_CASH = Σ RESULTADO` onde `DESCRICAO_GDAD_MACRO ∈ MACRO_CASH` (Arrecadação, Cobrança, Folha de Pagamento, Fornecedores, Tarifas de Conta Corrente, Pix); junção outer.
- Stickiness: `cashxcred` nas últimas `janela_share_cash` referências (3; substitui as datas 2026-03..05), junção com segmentos por CNPJ, somas por grupo; `SHARE_CREDITO` renomeando `cgrp_econm→CD_GRUPO`, `isgmto_atcdo→SEGMENTO`, **agregado por grupo** (hoje comentado, `06:L30`, com parâmetro `agregar_share_credito`); `fillna(0)`; `SHARE_CASH = QTDE_CASH_BRAD / QTDE_CASH_TOTAL` (−1 se total 0); `SALDO_MERCADO = vtot_mercd_bacen × vperc_ccren / 100`; `SHARE_CREDITO = vperc_bdsco / 100`; segmentos elegíveis (5, sem INSTITUCIONAL).
- Scores (parâmetros `RELACIONAMENTO`): `SCORE_CREDITO` = 1 se `SALDO_MERCADO < materialidade[segmento]` (ULTRA 500.000.000; LARGE 40.000.000; GLOBAL 40.000.000; CORPORATE 2.000.000; AGRO 2.000.000), senão por `SHARE_CREDITO` ≥ 0,7 → 4; ≥ 0,4 → 3; ≥ 0,1 → 2; senão 1. `SCORE_CASH` pelas mesmas faixas sobre `SHARE_CASH` (−1 → 1). `SCORE_STICKINESS = max`; rótulos 1 Baixo, 2 Médio Baixo, 3 Médio Alto, 4 Alto. `SCORE_ROB`: ULTRA/GLOBAL ≥ 12.600.000 → 3, ≥ 1.380.000 → 2; LARGE ≥ 6.300.000 → 3, ≥ 1.380.000 → 2; CORPORATE/AGRO ≥ 525.000 → 3, ≥ 93.000 → 2; senão 1. `SCORE_RECEITA_CASH`: ULTRA/GLOBAL ≥ 2.250.000 → 3, ≥ 300.000 → 2; LARGE ≥ 1.500.000 → 3, ≥ 300.000 → 2; CORPORATE/AGRO ≥ 102.000 → 3, ≥ 9.000 → 2; senão 1. `SCORE_IMPACTO = max`; rótulos 1 Baixo, 2 Médio, 3 Alto. Função de combinação (`max`) parametrizada.
- Saldo: `saldo_invest` outer `saldo_dav` por `REF × CNPJCPF`, `fillna(0)`, segmentos, soma por `REF × SEGMENTO × CD_GRUPO`, média nas últimas `janela_saldo` (3) referências (hoje sem filtro).
- SoW: `share_boletos` (janela `janela_boletos`, 12 a confirmar) por grupo; `SOW_BOLETOS = QTDE_COB_BRAD / QTDE_COB_TOTAL`; nulo → `NULL` com `flag_sem_cobranca = true` (substitui o texto `'sem cobrança'`).

Saídas: `brp.matriz_relacionamento(anomes, cd_grupo, segmento, resultado_operacional, receita_cash, share_credito, saldo_mercado, share_cash, score_credito, score_cash, score_rob, score_receita_cash, score_stickiness, stickiness, score_impacto, impacto)`; `brp.indicadores_reciprocidade` (SPEC-BRP-01) com `saldo_if_medio`, `saldo_dav_medio`, `qtde_cob_brad`, `qtde_cob_conc`, `qtde_cob_total`, `sow_boletos`, `flag_sem_cobranca`.

Critérios de aceite: para o ciclo de referência com janelas iguais às datas literais, `matriz.xlsx`, `saldo.xlsx` e `sow_cobranca.xlsx` são reproduzidos; mudar `janela_rob` para 12 altera o recorte sem mudança de código; scores intermediários ficam disponíveis para auditoria.

Dúvidas: "sem dado" = "baixo relacionamento"? (`fillna(0)` antes do −1); duplicidade de `SHARE_CREDITO` por grupo; uso de `QTDE_*_CONC` (lacuna 10); truncamento após `06:L138` (lacuna 8).

### SPEC-PPP-10 — T8 `foto_legado`: preço vigente e histórico 12 meses

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-04, RF-13 | **Depende de** SPEC-LEG-01, SPEC-PPP-02

Objetivo: materializar por ciclo a foto do preço vigente e o histórico de 12 meses vindos do legado (premissa `00-doc-negocio.md:L29`).

Descrição técnica: lê a base de tarifas/contratos governada no Databricks (a identificar na F0), normaliza para `cd_grupo × cod_produto` usando o mesmo `MAPA_DESCR_TARIFA_PRODUTO` do catálogo, grava `brp.preco_vigente_foto(anomes, cd_grupo, cod_produto, tarifa_vigente, dt_referencia, origem)` e `brp.historico_preco(cd_grupo, cod_produto, anomes_ref, tarifa)` (12 meses rolantes). Enquanto a fonte do legado não existir no lake, `origem = 'BRP_TARIFA'` com a `tarifa_praticada` da PPC (comportamento AS-IS, dor D5 do doc 06), marcado como transitório.

Critérios de aceite: cobertura ≥ X% (parâmetro) dos pares grupo × produto com volume na PPC; `origem` sempre preenchida; histórico com exatamente 12 `anomes_ref` por par quando houver dado.

Dúvidas: fonte física do legado e latência (lacuna 7); Multipag usa tarifa de contrato, demais usam tarifa média observada (A1 Síntese, diferença relevante para "vigente").

### SPEC-PPP-11 — T9 `validar_brp`: qualidade da BRP antes da publicação (RF-08)

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-08, RNF-05 | **Depende de** SPEC-PPP-08, SPEC-PPP-09, SPEC-PPP-10, SPEC-PPP-13

Objetivo: bloquear a publicação de uma BRP inconsistente e tornar visível a qualidade de cada ciclo.

Descrição técnica: regras sobre as tabelas gold do `anomes`: (a) cobertura do esqueleto (linhas `SEM_REFERENCIA` ≤ limiar, lista por produto); (b) `n ≥ n_minimo` por cluster (abaixo: `ALERTA` com lista); (c) monotonicidade `p25 ≤ p50 ≤ p75 ≤ p90` (`BLOQUEANTE`); (d) `preco_alvo ≥ tarifa_praticada` em toda a PPC (`BLOQUEANTE`); (d') `preco_sugerido` preenchido em toda linha `OK` da MPA e da PPC, com `origem_sugerido` informada (`BLOQUEANTE`; a relação sugerido x alvo a validar é **[A DEFINIR — lacuna 1]**); (e) variação de `preco_alvo_ref` por produto × cluster contra o `anomes` anterior acima de `limiar_variacao_pct` (`ALERTA`); (f) integridade referencial (todo `cod_produto` no catálogo, todo `segmento`/`regiao` no domínio); (g) cobertura da foto do legado; (h) contagens por tabela gravadas em `qualidade_ciclo` para conferência no reverse ETL (SPEC-BRP-02). Resumo consolidado em `brp.qualidade_ciclo` com `status_ciclo = APROVADO | APROVADO_COM_ALERTAS | REPROVADO`.

Critérios de aceite: uma linha com `p75 < p25` reprova o ciclo e impede T10; ciclo com alertas segue e os alertas aparecem no catálogo do svc-publicacao (SPEC-BRP-04); métrica `soma_uplift` disponível por ciclo.

Dúvidas: limiares de variação e cobertura são decisão da Precificação (F0).

### SPEC-PPP-12 — Orquestração do Workflow `ppp_ciclo`, Control-M, versionamento por `anomes`

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13, RNF-05, RNF-09, RNF-10 | **Depende de** SPEC-PPP-02..11, SPEC-PPP-13, SPEC-BRP-02

Objetivo: executar o ciclo de ponta a ponta com parâmetros, dependências, retry e alertas, disparado pelo Control-M.

Descrição técnica: Databricks Workflow `ppp_ciclo` com tarefas T0→(T1→T2, T3, T4, T5, T7, T8)→T6→T6b→T9→T10→T11 (doc 06 §5.1; T6b acrescentada na Revisão 1.1); parâmetros de job `anomes` (obrigatório), `versao_parametros` (opcional, default vigente), `modo` (`completo` | `reprocessar_produto:<cod>`), `ambiente`; cluster de job efêmero; retry 2x com backoff nas tarefas de leitura; `timeout` por tarefa; notificação de falha para a fila de operação e para a observabilidade (SPEC-OBS-01). Control-M chama `POST /api/2.1/jobs/run-now` com `job_parameters` e faz polling de `runs/get`; a definição do job Control-M inclui dependência das cargas de origem. Reexecução do mesmo `anomes` é idempotente (`replaceWhere`). Promoção dev → hml → prd por Asset Bundles na esteira corporativa. Registro de execução em `brp.execucao_ciclo(anomes, run_id, versao_parametros, versao_codigo(git sha), inicio, fim, status)`.

Critérios de aceite: duas execuções consecutivas do mesmo `anomes` produzem tabelas idênticas; falha em T9 não deixa dados em `stg`; Control-M recebe status final e o run aparece em `execucao_ciclo` com o git sha.

Dúvidas: obrigatoriedade do Control-M para este job (doc 06 §5.1); calendário do ciclo (mensal) e do semestral de preço por produto (A2 Fluxo 07 §9).

### SPEC-PPP-13 — T6b `preco_sugerido_cenario`: preço sugerido por cenário na MPA e na PPC (Revisão 1.1)

**Fase** F0 (engenharia reversa) / F1 (porte) | **Complexidade** G | **RF/RNF** RF-13, RF-01 (insumo), RNF-07, RNF-09 | **Depende de** SPEC-PPP-08, SPEC-PPP-09, SPEC-PAR-02, SPEC-PAR-07

Objetivo: preencher `preco_sugerido` (e `origem_sugerido`) em cada cenário da MPA e, por cópia do cenário, em cada linha da PPC, substituindo o que hoje é feito pela macro "Preço por Produto"/"Resumo por GE" da Planilha Ano 1 e pelo Motor da Calculadora (SQL 010). O motor online **não** calcula o sugerido; ele apenas lê o cenário (SPEC-PRC-03).

Descrição técnica **[A DEFINIR — lacuna 1; tudo abaixo é hipótese de trabalho a confirmar na engenharia reversa da F0]**: `ppp/regras/preco_sugerido.py` recebe a MPA de T6 e os insumos de relacionamento de T7 e aplica, por cenário, uma cadeia de ajustes ordenada por `parametro_item_sugerido.ordem`, partindo de `preco_alvo_ref`: (a) desconto por faixa de relacionamento (`parametro_item_desconto`, conteúdo de `premissas_desconto.xlsx`, lacuna 2) — só é aplicável por cenário se relacionamento for dimensão do cenário (lacuna 3; caso contrário fica como exceção parametrizada por cliente na PPC); (b) lista semestral de preço por produto (`SIMUL_PRECO_POR_PRODUTO`) como piso ou substituto; (c) exceções de `parametro_item_excecao` (RFP, custo, nicho, associação religiosa, Poder Público) aplicadas na PPC por `cd_grupo × cod_produto`. Cada ajuste é uma função pura com teste próprio e pode ser desligado por parâmetro. Enquanto a regra não for confirmada, o porte grava `preco_sugerido = preco_alvo_ref` com `origem_sugerido = 'ALVO_SEM_AJUSTE'` e registra `ALERTA` `SUGERIDO_PROVISORIO` em `qualidade_ciclo`. Saída: `MERGE` em `brp.matriz_cenarios_preco` (`preco_sugerido`, `origem_sugerido`) e em `brp.posicao_preco_cliente_produto` (`preco_sugerido` do `cenario_id` do cliente, mais exceções por cliente).

Critérios de aceite: para o ciclo de referência, `preco_sugerido` por cenário reproduz a aba "Preço por Produto"/"Tabela de Preços" da Planilha Ano 1 (tolerância a definir na F0); toda linha `OK` tem `preco_sugerido` e `origem_sugerido`; desligar um ajuste por parâmetro muda o resultado sem alteração de código; a trilha de cada cenário (valores intermediários) fica disponível para o comparador (SPEC-TRN-02).

Dúvidas: lacuna 1 (regra da macro e do SQL 010), lacuna 2 (premissas), lacuna 3 (relacionamento como dimensão do cenário ou exceção por cliente).

---

## 2. Épico BRP — Publicação de Referência (dbx-brp, sql-motor, svc-publicacao)

### SPEC-BRP-01 — Contrato de dados das tabelas gold da BRP Cash

**Fase** F0/F1 | **Complexidade** M | **RF/RNF** RF-13, RNF-06, RNF-09 | **Depende de** SPEC-PAR-02 (catálogo)

Objetivo: fixar o Published Language entre o analítico e o motor.

Descrição técnica: tabelas Delta no schema `brp` (partição `anomes`, todas com `dt_geracao`, `versao_parametros`, `run_id`):

| Tabela | Chave | Colunas principais |
|---|---|---|
| `matriz_cenarios_preco` (MPA — Matriz de Cenários de Preço; antes `matriz_preco_alvo_cluster`) | `anomes, cod_produto, tier, segmento, regiao` | `cenario_id VARCHAR(120)` (único por `anomes`), `cluster INT NULL`, `p25, p35, p40, p50, p60, p75, p90 DECIMAL(18,6)`, `preco_alvo_ref DECIMAL(18,6)`, `preco_sugerido DECIMAL(18,6) NULL`, `origem_sugerido VARCHAR(30)`, `n INT`, `status_linha` (`OK`, `SEM_REFERENCIA`, `NAO_REPRESENTATIVO`) |
| `posicao_preco_cliente_produto` (PPC) | `anomes, cd_grupo, cod_produto` | `segmento, regiao, uf, tier, cluster, cenario_id, macroproduto, qtde_mensal, qtde_anual, receita, tarifa_praticada, p25, p75, p90, preco_alvo, preco_sugerido, uplift, n, flag_nao_representativo` |
| `matriz_relacionamento` | `anomes, cd_grupo` | ver SPEC-PPP-09 |
| `indicadores_reciprocidade` | `anomes, cd_grupo, cod_produto` (`cod_produto = '*'` para indicadores de grupo) | `saldo_if_medio, saldo_dav_medio, qtde_cob_brad, qtde_cob_conc, qtde_cob_total, sow_boletos, flag_sem_cobranca, emissoes_l3m` |
| `preco_vigente_foto` | `anomes, cd_grupo, cod_produto` | `tarifa_vigente, dt_referencia, origem` |
| `historico_preco` | `cd_grupo, cod_produto, anomes_ref` | `tarifa, origem` |
| `qualidade_ciclo`, `execucao_ciclo`, `parametros_snapshot` | ver SPECs PPP | — |

Tipos: `cd_grupo VARCHAR(20)`, `cod_produto VARCHAR(60)`, `segmento`/`regiao`/`tier` como códigos do domínio. Documento de contrato (`contratos/brp-v1.md`) versionado com `schemaVersion`; mudança incompatível = `brp_v2` e convivência por um ciclo.

Critérios de aceite: schema Delta validado por teste automático contra o contrato; toda tabela tem `anomes` na chave (exceto `historico_preco`); PPC não repete chave; `preco_sugerido` da PPC é igual ao do cenário apontado por `cenario_id` salvo exceção por cliente registrada em `origem_sugerido`.

Dúvidas: manter percentis P35-P60 na PPC (hoje só P25/P75/P90)? Semântica de N (lacuna 10). Relacionamento como dimensão adicional do cenário (chave da MPA cresceria) ou exceção por cliente (lacuna 3).

### SPEC-BRP-02 — T10 `reverse_etl`: carga JDBC em staging no sql-motor

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-13, RNF-01, RNF-09 | **Depende de** SPEC-BRP-01, SPEC-BRP-03

Objetivo: levar as entidades gold do `anomes` para as tabelas `stg.*` do sql-motor com verificação de contagem.

Descrição técnica: para cada entidade: `DELETE FROM stg.<entidade> WHERE anomes = :anomes`; escrita Spark JDBC (`batchsize` 50.000, `numPartitions` 8, `rewriteBatchedStatements`), usuário técnico com permissão apenas em `stg`; ao final, contagem por tabela comparada com `qualidade_ciclo` e gravada em `stg.carga(anomes, entidade, linhas_esperadas, linhas_gravadas, hash_amostra, dt)`. Depois, T11 chama `POST /mpc/v1/brp/versoes/{anomes}/validar` (interno). Segredo JDBC via Databricks secret scope apontando para o Key Vault.

Critérios de aceite: contagem diferente → tarefa falha e `versao_brp` não é criada; carga repetida do mesmo `anomes` não duplica linhas; PPC com 500 mil linhas carrega em menos de 10 min (meta a validar).

Dúvidas: Azure Data Factory como alternativa (AD-03) se a área de dados exigir.

### SPEC-BRP-03 — Modelo versionado no sql-motor e procedures de ativação/rollback

**Fase** F1 | **Complexidade** G | **RF/RNF** RNF-01, RNF-03, RNF-09 | **Depende de** SPEC-BRP-01

Objetivo: tornar a ativação de um `anomes` atômica e o rollback imediato.

Descrição técnica: tabelas `brp.<entidade>` particionadas por `anomes` (função de partição `pf_anomes`, esquema `ps_anomes` em filegroups), com índices clusterizados pela chave e não clusterizados por `cd_grupo, cod_produto`; `stg.<entidade>` com layout idêntico e mesma função de partição. `brp.versao_brp(anomes PK, status (CARREGADA, VALIDADA, ATIVA, ANTERIOR, ARQUIVADA, REPROVADA), dt_carga, dt_validacao, dt_ativacao, dt_desativacao, versao_parametros_usada, resumo_qualidade_json, ativado_por)`. Procedures: `brp.sp_validar_versao(@anomes)` (checks relacionais: chaves, FKs lógicas com catálogo, contagens x `stg.carga`); `brp.sp_ativar_versao(@anomes, @usuario)`: em transação, `ALTER TABLE stg.x SWITCH PARTITION p TO brp.x PARTITION p` para cada entidade, `UPDATE versao_brp SET status = 'ANTERIOR'` na ativa, `'ATIVA'` na nova, insere auditoria; `brp.sp_reverter_versao(@usuario)`: troca `ATIVA` ↔ `ANTERIOR`. View `brp.v_brp_ativa_*` = `SELECT ... WHERE anomes = (SELECT anomes FROM versao_brp WHERE status = 'ATIVA')`. Retenção online: `n_versoes_online` (12) ciclos; além disso `ARQUIVADA` (partição removida, dado permanece no Delta).

Critérios de aceite: ativação em menos de 5 s com leitura concorrente sem erro; após `sp_reverter`, `v_brp_ativa_*` devolve o `anomes` anterior; `UPDATE`/`DELETE` em `brp.*` negados ao usuário da aplicação (só procedures).

Dúvidas: tier do Azure SQL e uso de filegroups (Hyperscale não suporta filegroups; alternativa: tabelas por versão renomeadas). Decidir na F0.

### SPEC-BRP-04 — svc-publicacao: catálogo de versões, validação, ativação, evento

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-08, RF-09, RF-13, RNF-01 | **Depende de** SPEC-BRP-03, SPEC-EVT-01, SPEC-SEC-01

Objetivo: expor a governança da BRP como API com perfil e auditoria.

Descrição técnica: endpoints `GET /brp/versoes?status=`, `GET /brp/versoes/{anomes}` (status, `resumo_qualidade`, contagens, alertas), `POST /brp/versoes/{anomes}/validar` (chamado por T11 com credencial técnica; roda `sp_validar_versao`; `CARREGADA → VALIDADA | REPROVADA`), `POST /brp/versoes/{anomes}/ativar` (perfil `precificacao.publicador`; recusa se `status ≠ VALIDADA` ou se `resumo_qualidade.bloqueantes > 0`; exige `{"confirmacao_alertas": true}` quando houver alertas), `POST /brp/versoes/{anomes}/reverter`, `GET /brp/ativa`. Após ativar, publica `VersaoBrpPublicada {anomes, versao_parametros_usada, resumo_qualidade}` no tópico `mpc.publicacao`.

Exemplo:

```json
POST /mpc/v1/brp/versoes/202609/ativar
{ "confirmacao_alertas": true, "justificativa": "Ciclo set/2026 aprovado em comitê" }
→ 200 { "anomes": "202609", "status": "ATIVA", "anomes_anterior": "202608", "dt_ativacao": "2026-10-03T14:02:11Z" }
```

Critérios de aceite: ativar sem perfil → 403 `PERFIL_INSUFICIENTE`; ativar com bloqueante → 409 `VERSAO_REPROVADA`; evento publicado e cache do svc-pricing invalidado em até 60 s (SPEC-PRC-05); toda transição gravada em `auditoria`.

Dúvidas: quem é o publicador (R10); ativação automática sem humano em ciclos sem alerta? (decisão de governança).

---

## 3. Épico PRC — svc-pricing (Cálculo de Preço)

### SPEC-PRC-01 — Modelo de cotação e persistência

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-09, RNF-03, RNF-09 | **Depende de** SPEC-BRP-03, SPEC-PAR-01

Objetivo: registrar toda simulação com as versões que a geraram, de forma imutável e reproduzível.

Descrição técnica: `pricing.cotacao(cotacao_id UUID PK, dt DATETIME2, usuario, canal, modo (PRODUCAO | STAGING | SHADOW | LOTE), cd_grupo, cnpj_mascarado, cod_produto, anomes_brp, versao_parametros UUID, versao_parametros_candidata UUID NULL, origem_praticado, entrada_json, saida_json, hash_entrada CHAR(64), correlation_id, onda_id NULL)` particionada por mês de `dt`; índices `(cd_grupo, cod_produto, dt)`, `(hash_entrada)`, `(correlation_id)`. `hash_entrada = SHA-256(entrada canônica + anomes_brp + versao_parametros)`. Permissão do usuário da aplicação: `INSERT`/`SELECT` apenas. Exportação diária para `mpc.brp.cotacao_historico` no Delta (SPEC-OBS-02). Retenção online 24 meses **[A DEFINIR — P10]**.

Critérios de aceite: toda resposta 200 de simulação tem `cotacao_id` persistido antes do retorno; `GET /cotacoes/{id}` devolve entrada, saída e versões; tentativa de `UPDATE` falha por permissão.

### SPEC-PRC-02 — Resolução de contexto, tier e cluster no motor

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-01, RNF-07 | **Depende de** SPEC-PAR-02, SPEC-PAR-04, SPEC-BRP-03

Objetivo: reproduzir no online, com os mesmos parâmetros do pipeline, a classificação de tier e cluster para volumetria informada.

Descrição técnica: `ContextoCliente` resolvido por `cd_grupo` (ou CNPJ → grupo via PPC/cadastro): `segmento` e `regiao` da PPC do `anomes` ativo; se o cliente não estiver na PPC (cliente novo), `segmento` e `regiao` vêm do request (obrigatórios nesse caso) e a resposta marca `cliente_sem_posicao = true`. `CatalogoProduto` (macroproduto, grupo de regra, `unidade_volume`, `quem_paga`). `EstrategiaTier.classificar(cod_produto, volume, unidade)` com as faixas de `parametro_item_tier` (mesma semântica de SPEC-PPP-01, inclusive `sem_tier3`); conversão de unidade (mensal ↔ anual) por `divisor_mensalizacao`. `EstrategiaCluster.classificar(grupo_regra, tier, segmento, regiao)` sobre `parametro_item_regra_cluster` (mais específico vence). Implementação Java espelha a Python: os mesmos casos dourados (SPEC-PPP-01) são executados nos dois lados.

Critérios de aceite: para os casos dourados, tier e cluster Java = PySpark; cliente ausente na PPC sem `segmento` no request → 422 `SEGMENTO_OBRIGATORIO`.

Dúvidas: volumetria "informada" substitui ou complementa a da PPC? (definição de simulação, lacuna 3).

### SPEC-PRC-03 — Algoritmo do motor: praticado, alvo, lookup do sugerido, cenários, uplift

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-01, RF-02, RF-03, RNF-07, RNF-09 | **Depende de** SPEC-PRC-02, SPEC-LEG-02, SPEC-ALC-02, SPEC-PAR-02, SPEC-BRP-01

Objetivo: compor a resposta de simulação com regras dos anexos: classificação (SPEC-PRC-02), **lookup do cenário na BRP** (praticado do ciclo, alvo, sugerido, percentis), cenários vizinhos e uplift. Revisão 1.1: o motor **não calcula** o sugerido nem aplica ajustes sobre ele (desconto de relacionamento, pisos, exceções); isso é regra do pipeline (SPEC-PPP-13) e da parametrização (SPEC-PAR-02). A única conta feita online é o uplift por cenário.

Descrição técnica (ordem fixa; cada passo grava um item em `saida_json.trilha[]`):

1. **Praticado**: `svc-legado-adapter` (`estrategia` do request ou `auto`) → `{valor, origem, dt_referencia}`; se indisponível, `tarifa_praticada` da PPC com `origem = BRP_TARIFA` e alerta na resposta.
2. **Lookup do cenário**: MPA ativa (`brp.v_brp_ativa_matriz_cenarios_preco`) por `(cod_produto, tier, segmento, regiao)` → `cenario_id, cluster, p25..p90, preco_alvo_ref, preco_sugerido, origem_sugerido, n, status_linha`. Se o cliente está na PPC do `anomes` e a volumetria informada não muda o tier, o `cenario_id` da PPC deve coincidir (verificação na trilha). `SEM_REFERENCIA` → aplica `politica_sem_referencia` (`ERRO_422` | `CLUSTER_VIZINHO` **[A DEFINIR — lacuna 5]**); default `ERRO_422 SEM_REFERENCIA_CLUSTER`.
3. **Alvo**: `alvo = max(praticado, preco_alvo_ref)` (`preco_alvo_ref = P<percentil_alvo>`, percentil_alvo = 75, A1 `01:L112`); se `n < n_minimo (15)`: `alvo = praticado`, `alvo_flag = NAO_REPRESENTATIVO`.
4. **Sugerido** = `preco_sugerido` do cenário, sem qualquer ajuste online; resposta carrega `origem_sugerido` e `cenario_id`. Se `preco_sugerido` for nulo (cenário sem sugerido publicado), aplica `politica_sem_sugerido` (`ERRO_422 SEM_PRECO_SUGERIDO` | `USAR_ALVO` com `sugerido_flag = FALLBACK_ALVO`) **[A DEFINIR — lacuna 1]**; default `USAR_ALVO` com alerta na resposta. Exceções por cliente (RFP, nicho, Poder Público etc.) já chegam materializadas no `preco_sugerido` da PPC (SPEC-PPP-13); o motor apenas as expõe pela `origem_sugerido`.
5. **Cenários** (brief §2, todos lidos da BRP): `percentis[]` = para k em {25,35,40,50,60,75,90}: `preco_k = max(praticado, P_k)`, `uplift_k`; `tier[]` = lookup dos cenários vizinhos da MPA (mesmo produto/segmento/região, tier −1 e +1) com seus `alvo`, `sugerido` e `cenario_id`, mais os limites das faixas ("volume necessário para mudar de tier"); `relacionamento[]` = cenários de relacionamento **apenas se** relacionamento for dimensão do cenário na MPA **[A DEFINIR — lacuna 3]**, caso contrário o array vem vazio com `motivo = NAO_DISPONIVEL`; cada cenário com `uplift_anual`.
6. **Uplift** (mesma fórmula do pipeline; única conta online): `volume_anual = qtde_anual da PPC ou volumetria informada × 12`; `receita_anual = praticado × volume_anual`; `uplift(preco) = (preco − praticado) × volume_anual` se `praticado < 1.000`, senão `(preco / praticado − 1) × receita_anual`; `uplift_pct = preco / praticado − 1`.
7. **Negociado**: se informado, `desvio_pct = (sugerido − negociado) / sugerido`, `uplift_perdido = uplift(sugerido) − uplift(negociado)`; se `negociado ≥ sugerido` → `alcada.necessaria = false`; senão chama `POST /alcadas/avaliacoes` (SPEC-ALC-02).
8. Persistir cotação (SPEC-PRC-01) e responder.

Critérios de aceite: dado praticado 0,80, P75 1,00, n 40, volume anual 120.000, então alvo 1,00 e `uplift(alvo)` = 24.000,00; dado n = 10, então alvo = praticado e `alvo_flag = NAO_REPRESENTATIVO`; dado praticado 1.200 e P75 1.500, então `uplift = (1.500/1.200 − 1) × receita_anual`; dado cenário com `preco_sugerido` 0,97, então `sugerido = 0,97` e a trilha não contém nenhum passo de ajuste sobre o sugerido; ativar uma nova versão da BRP com outro `preco_sugerido` para o mesmo cenário muda o sugerido devolvido sem redeploy nem mudança de parâmetro; cenário sem `preco_sugerido` segue `politica_sem_sugerido`; a trilha lista cada passo com valores intermediários e o `cenario_id` usado.

Dúvidas: lacuna 1 (política para cenário sem sugerido), lacuna 3 (relacionamento como dimensão do cenário; volumetria informada x PPC); tratamento de Multipag onde praticado é tarifa de contrato.

### SPEC-PRC-04 — API de simulação e consulta

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-01, RF-02, RF-04, RF-07, RNF-02 | **Depende de** SPEC-PRC-03, SPEC-API-02

Objetivo: expor o cálculo e as consultas rápidas com contrato estável.

Descrição técnica: `POST /precos/simulacoes`, `GET /precos/{grupo}/{produto}/referencia`, `GET /precos/{grupo}/{produto}/vigente?estrategia=`, `GET /precos/{grupo}/{produto}/historico?meses=12` (os dois últimos delegam ao Adaptador), `GET /cotacoes/{id}`.

```json
POST /mpc/v1/precos/simulacoes
{ "cd_grupo": "104532", "cod_produto": "COB_QUANDO_REGISTRO_CLIENTE",
  "volumetria": { "qtde": 22000, "unidade": "MENSAL" },
  "preco_negociado": 0.95,
  "opcoes": { "estrategia_vigente": "auto", "cenarios": ["PERCENTIS", "TIER", "RELACIONAMENTO"] } }
→ 200
{ "cotacao_id": "3f2c…", "cliente": { "cd_grupo": "104532", "segmento": "CORPORATE", "regiao": "SP" },
  "tier": "Tier 2", "cluster": 2,
  "cenario_id": "202609-COB_QUANDO_REGISTRO_CLIENTE-T2-CORPORATE-SP",
  "praticado": { "valor": 0.80, "origem": "FOTO", "dt_referencia": "2026-08-31" },
  "alvo": { "valor": 1.00, "percentil": "P75", "n": 40, "flag": null },
  "sugerido": { "valor": 0.97, "origem": "BRP_CENARIO", "cenario_id": "202609-COB_QUANDO_REGISTRO_CLIENTE-T2-CORPORATE-SP", "flag": null },
  "uplift": { "sugerido": { "pct": 0.2125, "valor_anual": 44880.00 } },
  "negociado": { "valor": 0.95, "desvio_pct": 0.0206, "uplift_perdido": 5280.00 },
  "alcada": { "necessaria": true, "nivel": 1, "papel_aprovador": "gerente_regional" },
  "cenarios": [ { "tipo": "PERCENTIL", "ref": "P50", "preco": 0.90, "uplift_anual": 26400.00 },
                { "tipo": "TIER", "ref": "Tier 1", "cenario_id": "202609-COB_QUANDO_REGISTRO_CLIENTE-T1-CORPORATE-SP",
                  "volume_minimo": 100001, "alvo": 0.85, "sugerido": 0.83, "uplift_anual": 7920.00 } ],
  "versoes": { "brp": "202609", "parametros": "9a1e…", "api": "1.3.0" } }
```

Nota (Revisão 1.1): `sugerido` não traz lista de ajustes — o valor é o publicado no cenário da BRP; `origem` (`BRP_CENARIO`, `EXCECAO_CLIENTE`, `FALLBACK_ALVO`) diz de onde veio.

Critérios de aceite: com cache quente e 50 req/s (teste de carga em hml), consulta com p95 ≤ 150 ms / p99 ≤ 300 ms e simulação com p95 ≤ 300 ms / p99 ≤ 600 ms medidos no serviço, e p95 ≤ 500 ms medido no Axway (RNF-02); `preco_negociado` ausente → `alcada = null`; entrada inválida → 400 problem+json com `erros[]`.

### SPEC-PRC-05 — Cache Caffeine e invalidação por evento

**Fase** F1 | **Complexidade** P | **RF/RNF** RNF-02, RNF-01 | **Depende de** SPEC-EVT-01, SPEC-BRP-04, SPEC-PAR-03

Descrição técnica: caches `parametros_vigentes[versao_id]`, `mpa[anomes]` (carga integral, milhares de linhas), `catalogo[versao_id]`; TTL 5 min; invalidação ao receber `VersaoBrpPublicada`/`VersaoParametroPublicada` (assinatura) ou polling de `versao_brp`/`parametro_versao` a cada 60 s no fallback outbox; chave separada para versões candidatas (SPEC-PRC-06). PPC, indicadores e foto não são cacheados. Métricas `cache_hit_ratio`, `cache_versao_ativa`.

Critérios de aceite: após ativar nova BRP, todas as réplicas respondem com o novo `anomes` em até 60 s; hit ratio > 95% em carga sustentada.

### SPEC-PRC-06 — Modo staging (versão candidata) e reexecução com versões explícitas

**Fase** F2 (staging) / F1 (reexecução) | **Complexidade** M | **RF/RNF** RF-06, RNF-09 | **Depende de** SPEC-PRC-04, SPEC-PAR-05, SPEC-SEC-01

Descrição técnica: cabeçalhos `X-Versao-Parametros-Candidata: <uuid>` e `X-Versao-BRP-Candidata: <anomes>` aceitos apenas para claims `precificacao.*`; cotação gravada com `modo = STAGING`, sem chamada ao svc-alcada para abertura de pedido e sem `cotacao_id` contratável (`contratavel = false`). Corpo pode trazer `versoes { brp, parametros }` explícitas para reexecutar uma cotação antiga (`modo = PRODUCAO`, `reexecucao_de = <cotacao_id>`), permitido para perfis de auditoria. Endpoint `POST /precos/simulacoes/comparacoes` recebe lista de `cd_grupo × cod_produto` (até 500) e devolve vigente x candidata lado a lado (relatório de staging).

Critérios de aceite: usuário `comercial.gerente` com cabeçalho candidato → 403; reexecução com versões antigas reproduz `saida_json` idêntico (hash) da cotação original.

### SPEC-PRC-07 — Cálculo em lote `/precos/simulacoes/lote` [EVOLUÇÃO — a detalhar com o negócio]

**Fase** F4 | **Complexidade** G | **RF/RNF** RF-11, RNF-09 | **Depende de** SPEC-PRC-03, SPEC-REP-03

Descrição técnica: `POST /precos/simulacoes/lote {onda_id, itens[]{cd_grupo, cod_produto, volumetria?, gradacao?}}` → `202 {lote_id}`; processamento assíncrono em fatias de 1.000 com paralelismo configurável, idempotência por `onda_id + cd_grupo + cod_produto`, resultado em `pricing.lote_item` e `GET /precos/simulacoes/lote/{id}` (status, progresso, erros). Mesmo algoritmo de SPEC-PRC-03 com `modo = LOTE` e gradação aplicada como último ajuste **[A DEFINIR — lacuna 4]**.

Critérios de aceite: 100 mil itens em menos de 30 min (meta); reprocessar o mesmo lote não duplica cotações.

---

## 4. Épico ALC — svc-alcada (Alçada e Aprovação)

### SPEC-ALC-01 — Política de alçada parametrizável

**Fase** F1 (mínima) / F2 (completa) | **Complexidade** M | **RF/RNF** RF-03, RF-05, RNF-07 | **Depende de** SPEC-PAR-01, SPEC-PAR-02

Descrição técnica: `parametros.politica_alcada(politica_id UUID PK, versao_id FK, cod_produto ('*' ou código), segmento ('*' ou código), macroproduto ('*'), desvio_min_pct DECIMAL(9,6), desvio_max_pct DECIMAL(9,6) NULL, uplift_perdido_min DECIMAL(18,2) NULL, nivel INT, papel_aprovador VARCHAR(60), prazo_horas INT, ordem_especificidade INT)`. Semântica (brief §2, definição de trabalho): `necessaria = negociado < sugerido`; a linha aplicável é a mais específica (produto + segmento > produto > macroproduto > segmento > global) cujo intervalo `[desvio_min_pct, desvio_max_pct)` contém `desvio_pct` e, se informado, `uplift_perdido ≥ uplift_perdido_min`. Conteúdo real de `premissas_alcada.xlsx` **[A DEFINIR — lacunas 2 e 3]**; versão mínima F1: uma faixa única global `[0, ∞) → nível 1, papel_aprovador = 'gerente_regional'` **(inferido, placeholder)**. Editada pelo svc-parametros como tipo `ALCADA` (mesmo ciclo de versão).

Critérios de aceite: sem linha aplicável → 422 `POLITICA_ALCADA_AUSENTE` (nunca aprovar por omissão); intervalos sobrepostos na mesma especificidade rejeitados na publicação da versão.

### SPEC-ALC-02 — Avaliação de desvio (`POST /alcadas/avaliacoes`)

**Fase** F1 | **Complexidade** P | **RF/RNF** RF-03 | **Depende de** SPEC-ALC-01

```json
POST /mpc/v1/alcadas/avaliacoes
{ "cod_produto": "COB_QUANDO_REGISTRO_CLIENTE", "segmento": "CORPORATE", "sugerido": 0.97, "negociado": 0.95, "volume_anual": 264000, "uplift_perdido": 5280.00 }
→ 200 { "necessaria": true, "desvio_pct": 0.0206, "nivel": 1, "papel_aprovador": "gerente_regional", "politica_id": "…", "versao_parametros": "…" }
```

Sem persistência (avaliação pura, idempotente); usada pelo svc-pricing e pelo svc-reprecificacao. Critérios: `negociado ≥ sugerido` → `necessaria=false, nivel=null`; resposta em < 20 ms com cache da política.

### SPEC-ALC-03 — Pedido de aprovação, fila e decisão

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-03, RF-09, RF-10, RNF-03 | **Depende de** SPEC-ALC-02, SPEC-PRC-01, SPEC-EVT-01, SPEC-SEC-01

Descrição técnica: `alcada.pedido_aprovacao(pedido_id UUID PK, cotacao_id FK, cd_grupo, cod_produto, nivel, papel_aprovador, sugerido, negociado, desvio_pct, uplift_perdido, justificativa, solicitante, status (ABERTO, APROVADO, RECUSADO, EXPIRADO, CANCELADO), decisor, comentario, dt_abertura, dt_decisao, prazo_ate)`. `POST /alcadas/pedidos {cotacao_id, justificativa}` (recusa se cotação `modo ≠ PRODUCAO` ou `alcada.necessaria = false`); `GET /alcadas/pedidos?papel=&status=&cd_grupo=` (fila; o `papel` do JWT limita a lista); `POST /alcadas/pedidos/{id}/decisao {decisao, comentario}` (só claim igual ao `papel_aprovador`; decisor ≠ solicitante); expiração por scheduler (`prazo_horas`). Eventos `PedidoAprovacaoCriado`, `PrecoAprovado`, `PrecoRecusado` no tópico `mpc.alcada`; auditoria em cada transição. Alternativa registrada: Approval Process nativo do Salesforce para a fila, mantendo a classificação no serviço (doc 07 §4.2).

Critérios de aceite: solicitante tentando decidir o próprio pedido → 403; decisão publica evento com `cotacao_id`; pedido expirado não pode ser aprovado.

Dúvidas: níveis, papéis e prazos reais (lacuna 3); a contratação após aprovação gera novo registro no legado? (fora do escopo C1).

---

## 5. Épico PAR — svc-parametros (Parametrização)

### SPEC-PAR-01 — Modelo de versão, status, escopo e vigência

**Fase** F1 (básico) / F2 (agendamento, reversão) | **Complexidade** M | **RF/RNF** RF-05, RF-06, RNF-09 | **Depende de** —

Descrição técnica: `parametros.parametro_versao(versao_id UUID PK, numero INT, escopo (GLOBAL | PRODUTO), cod_produto NULL, descricao, status (RASCUNHO, STAGING, APROVADA, AGENDADA, PUBLICADA, ENCERRADA, REVERTIDA, CANCELADA), versao_base_id FK NULL, vigencia_inicio DATETIME2 NULL, vigencia_fim NULL, autor, aprovador, publicador, dt_criacao, dt_aprovacao, dt_publicacao)`. Máquina de estados do doc 06 §5.3; transições apenas via serviço; versão imutável a partir de `APROVADA` (itens com `UPDATE` bloqueado por trigger/permissão). Escopo `PRODUTO` permite publicar o semestral de um produto sem republicar o global; a resolução do vigente (SPEC-PAR-04) compõe GLOBAL + PRODUTO. Scheduler (Spring `@Scheduled` com lock em `parametros.scheduler_lock`) publica versões `AGENDADA` ao atingir `vigencia_inicio` e encerra a anterior (`vigencia_fim = novo início`). Reverter = reativar a última `ENCERRADA` do mesmo escopo como nova `PUBLICADA` (cópia, preservando histórico).

Critérios de aceite: tentativa de editar item de versão `APROVADA` → 409 `VERSAO_IMUTAVEL`; versão agendada para 00:00 é publicada em até 1 min; reverter cria nova versão com `versao_base_id` apontando para a revertida.

### SPEC-PAR-02 — Tipos de parâmetro (tabelas tipadas)

**Fase** F1 | **Complexidade** G | **RF/RNF** RF-05, RNF-07 | **Depende de** SPEC-PAR-01

Descrição técnica: todas com `versao_id FK`, `item_id UUID PK`, `observacao`, `origem_carga`:

| Grupo | Tabela | Colunas de negócio | Origem AS-IS |
|---|---|---|---|
| Catálogo | `catalogo_produto` | `cod_produto, nome_produto, macroproduto, grupo_regra_cluster, quem_paga (CLIENTE, BANCO, NA), unidade_volume (MEDIA_MENSAL, TOTAL_ANUAL), fonte_percentil (ex. ARRECADACAO_COMPLETA), ativo` | `05:L34`, `L49`, `L60-85` |
| Domínios | `dominio` | `tipo (SEGMENTO, REGIAO, TIER, MACROPRODUTO), codigo, nome, elegivel_atacado BIT, agrupamento_faixa (ULTRA_GLOBAL, LARGE, CORPORATE_AGRO), ordem` | `05:L50-52`, `06:L33`, `L101` |
| Tier | `parametro_item_tier` | `cod_produto, tier, limite_inferior, limite_superior NULL, base_volume, sem_tier3 BIT` | `01:L63-79`, `02:L30`, `03:L52-56`, `04:L45-48`, `tier_por_produto.xlsx` |
| Cluster | `parametro_item_regra_cluster` | `grupo_regra (G1, G2, G3, ARRECADACAO), tier, segmento ('*'), regiao ('*'), cluster, ordem_especificidade` | `05:L62-94`, `04:L54-61` |
| Percentis | `parametro_item_percentil` | `cod_produto ('*'), percentis_json, percentil_alvo, clusters_corporate_json, cluster_auxiliar (9999), campo_peso, ordem_cummin_json, n_minimo, limiar_uplift, politica_sem_referencia` | `01:L96-120`, `02:L50-52` |
| Desconto | `parametro_item_desconto` | `cod_produto ('*'), segmento ('*'), indicador (SALDO_IF, SALDO_DAV), faixa_min, faixa_max, pct_desconto` **[A DEFINIR — lacuna 2]**. Insumo do **pipeline** (SPEC-PPP-13) para compor o sugerido por cenário; o motor online não lê este tipo | `premissas_desconto.xlsx`, `06:L137` |
| Sugerido | `parametro_item_sugerido` | `ajuste (DESCONTO_RELACIONAMENTO, RFP, NICHO, ASSOC_RELIGIOSA, PODER_PUBLICO, PISO_CUSTO, PRECO_POR_PRODUTO), ordem, ativo, config_json`. Consumido pelo **pipeline** (SPEC-PPP-13) na geração da BRP; o motor online não lê este tipo (Revisão 1.1) | macro / SQL 010 **[lacuna 1]** |
| Alçada | `politica_alcada` | SPEC-ALC-01 | `premissas_alcada.xlsx` |
| Remuneração | `parametro_item_generico` | `tipo, chave, valor_json` | `premissas_remuneracao.xlsx` **[lacuna 2]** |
| Exceções | `parametro_item_excecao` | `tipo (RFP, NICHO, CUSTO, ASSOC_RELIGIOSA, PODER_PUBLICO, NEGOCIACAO_RECENTE, DATA_REPRECIFICACAO, GRUPO_EXCLUIDO), cd_grupo NULL, cnpj NULL, cod_produto NULL, valor DECIMAL NULL, data_inicio, data_fim, fonte` | abas manuais `07:L48-60`, 616, PP |
| Mapas | `parametro_item_mapa` | `tipo (UF_REGIAO, MIDIA_PRODUTO, DESCR_TARIFA_PRODUTO, CD_TARF_PIX, MACRO_CASH, REGIAO_POR_GE), origem, destino` | `02:L40-46`, `04:L22`, `03:L24`, `06:L19`, `regiao_por_ge.xlsx` |
| Janelas | `parametro_item_janela` | `nome (LTM, L3M, ROB, SHARE_CASH, SALDO, BOLETOS), meses, referencias` | `02:L17`, `06:L17`, `L26`, `L50` |
| Relacionamento | `parametro_item_relacionamento` | `tipo (MATERIALIDADE, FAIXA_SHARE, FAIXA_ROB, FAIXA_RECEITA_CASH, ROTULO_STICKINESS, ROTULO_IMPACTO, FUNCAO_COMBINACAO), segmento_ou_grupo, faixa_min, valor_ou_rotulo` | `06:L66-123` |
| Pipeline | `parametro_item_pipeline` | `chave (aplicar_filtro_contrato, tratamento_receita_negativa, tipo_documento_recorte, divisor_mensalizacao, agregar_share_credito, limiares de qualidade), valor` | A1/A2 §5 |
| Reciprocidade [EVOL] | `parametro_item_reciprocidade` | `indicador, tolerancia_pct, janela, acao` | — |

Validações na transição para `STAGING`: faixas de tier contíguas e sem sobreposição por produto; toda combinação tier × segmento × região de cada grupo de regra resolve para um cluster; `percentil_alvo` pertence a `percentis_json`; `cod_produto` referenciados existem e estão ativos; lista completa de clusters corporate existe no domínio.

Critérios de aceite: carga dos valores dos anexos (SPEC-PAR-07) passa em todas as validações exceto as marcadas como lacuna (que ficam registradas como `ALERTA`); inserir produto novo com grupo de regra existente não exige código em nenhum componente.

### SPEC-PAR-03 — APIs de versão e itens

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-05, RF-06, RF-10 | **Depende de** SPEC-PAR-01, SPEC-PAR-02, SPEC-SEC-01

Descrição técnica: rotas do doc 06 §7 (`GET/POST /parametros/versoes`, `PUT /parametros/versoes/{id}/itens/{tipo}` em lote com substituição integral do tipo no rascunho, `POST .../staging | aprovar | publicar | reverter | cancelar`, `GET .../diff/{outra}`, `GET /parametros/vigentes`). Autorização por operação: editor cria/edita/envia a staging; aprovador aprova (não a própria); publicador publica/agenda/reverte. Publicação emite `VersaoParametroPublicada {versao_id, escopo, cod_produto, vigencia_inicio}`.

```json
POST /mpc/v1/parametros/versoes/9a1e…/publicar
{ "vigencia_inicio": "2026-11-01T00:00:00-03:00" }
→ 200 { "versao_id": "9a1e…", "status": "AGENDADA", "vigencia_inicio": "2026-11-01T00:00:00-03:00" }
```

Critérios de aceite: `PUT` de itens com validação falha → 422 listando `erros[]` por linha; publicação imediata torna a anterior `ENCERRADA` na mesma transação; `diff` devolve itens adicionados/removidos/alterados por tipo.

### SPEC-PAR-04 — Resolução do conjunto vigente e snapshot

**Fase** F1 | **Complexidade** P | **RF/RNF** RNF-09, RF-13 | **Depende de** SPEC-PAR-01

Descrição técnica: `GET /parametros/vigentes?data=&produto=&versao=` resolve, para a data, a versão `PUBLICADA` GLOBAL mais recente com `vigencia_inicio ≤ data` e, por produto, a versão de escopo `PRODUTO` mais recente, compondo um `ConjuntoParametros` com `versao_efetiva_id` (hash das versões componentes) que é o valor gravado em `cotacao.versao_parametros` e em `brp.parametros_snapshot`. Resposta cacheável (`ETag`).

Critérios de aceite: para uma data no passado, o conjunto devolvido é o que vigorava então; duas chamadas com a mesma data devolvem o mesmo `versao_efetiva_id`.

### SPEC-PAR-05 — Staging e simulação em staging

**Fase** F2 | **Complexidade** M | **RF/RNF** RF-06 | **Depende de** SPEC-PAR-03, SPEC-PRC-06

Descrição técnica: uma versão `STAGING` pode ser usada como candidata em `POST /precos/simulacoes` (SPEC-PRC-06) e em `POST /precos/simulacoes/comparacoes` para uma carteira de teste (`parametros.carteira_teste(nome, itens_json)` mantida pela Precificação); relatório de comparação persistido em `parametros.relatorio_staging(versao_id, carteira, gerado_em, resumo_json, detalhe_json)` e anexado à tela de aprovação. Aprovação exige ao menos um relatório gerado para a versão (regra configurável).

Critérios de aceite: comparar versão candidata com a vigente para carteira de 200 clientes devolve, por item, alvo/sugerido/alçada nas duas versões e o delta; aprovar sem relatório → 409 quando a regra estiver ativa.

### SPEC-PAR-06 — Perfis, segregação de funções e auditoria de parâmetros

**Fase** F1 (perfis básicos) / F2 (completo) | **Complexidade** M | **RF/RNF** RF-09, RF-10, RNF-03, RNF-04 | **Depende de** SPEC-SEC-01, SPEC-OBS-02

Descrição técnica: claims `precificacao.leitor | editor | aprovador | publicador`; segregação: `aprovador ≠ autor` e `publicador` pode ser igual ao aprovador (configurável); toda operação grava em `auditoria` (SPEC-OBS-02) com `antes_json`/`depois_json` por item alterado (diff granular), `versao_id`, `correlation_id`, `origem` (canal). Consulta `GET /parametros/versoes/{id}/auditoria`.

Critérios de aceite: editor aprovando a própria versão → 403 `SEGREGACAO_FUNCOES`; alteração de uma faixa de tier gera uma linha de auditoria com o valor anterior e o novo.

### SPEC-PAR-07 — Carga inicial dos parâmetros (planilhas e notebooks)

**Fase** F0/F1 | **Complexidade** M | **RF/RNF** RF-05, RF-13 | **Depende de** SPEC-PAR-02

Objetivo: transformar tudo o que hoje é hard-code ou aba manual na versão 1 publicada de parâmetros.

Descrição técnica: notebook/CLI `carga_inicial_parametros` que lê (a) as tabelas de A1 §4 e A2 §4 já transcritas em CSVs versionados no repositório (`parametros/seed/v1/*.csv`: 18 produtos e macroprodutos, domínios, faixas de tier por produto, regras de cluster G1/G2/G3/ARRECADACAO, percentis e thresholds 75/15/1.000, clusters corporate, janelas 13/3/6/3/12, listas `CD_TARF`, mapas UF→região e mídia→produto, macroprodutos cash, materialidade e faixas de score); (b) as abas da planilha `Preço ano 1.xlsx` e os 11 arquivos da pasta `calculadora salesforce` (`tier_por_produto`, `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `regiao_por_ge`, listas Negociações Recentes, Datas de Reprecificação, RFPs, Custos, Nichos, Associações Religiosas, Poder Público) via leitura com pandas e mapeamento de colunas declarado em `seed/mapeamentos.yaml` **[layouts desconhecidos — lacuna 2; o mapeamento é produzido na F0]**; (c) grava via `PUT /parametros/versoes/{id}/itens/{tipo}` numa versão `RASCUNHO` com `origem_carga = 'SEED_V1'` e gera relatório de reconciliação (itens carregados, rejeitados, lacunas). Publicação da v1 é ato humano.

Critérios de aceite: a v1 publicada reproduz, via SPEC-PPP-01, os mesmos resultados dos notebooks para o ciclo de referência; toda constante de A1 §5 e A2 §5 tem um item correspondente ou uma entrada na lista de lacunas.

Dúvidas: conteúdo das premissas (lacuna 2); decisões de INSTITUCIONAL, 616, cluster de Arrecadação (lacuna 5) devem ser tomadas antes da publicação da v1.

---

## 6. Épico LEG — Adaptador de Legado (svc-legado-adapter)

### SPEC-LEG-01 — Foto do preço vigente e histórico no sql-motor

**Fase** F1 | **Complexidade** P | **RF/RNF** RF-04, RNF-06 | **Depende de** SPEC-BRP-01, SPEC-BRP-03

Descrição técnica: `brp.preco_vigente_foto` e `brp.historico_preco` carregadas pelo reverse ETL (SPEC-PPP-10, SPEC-BRP-02) e ativadas com a versão; índice `(cd_grupo, cod_produto)`; `historico_preco` fora do `SWITCH` (tabela rolante com `MERGE` por `anomes_ref`, mantendo 12 meses online e o restante no Delta).

Critérios de aceite: consulta pontual por par em < 10 ms; par sem foto devolve `404 PRECO_VIGENTE_INDISPONIVEL` com sugestão de estratégia `online`.

### SPEC-LEG-02 — API interna do Adaptador com estratégias foto / online / auto

**Fase** F1 (foto e auto com fallback) / F2 (online) | **Complexidade** M (F1) + G (conector F2) | **RF/RNF** RF-04, RF-07, RNF-01, RNF-02 | **Depende de** SPEC-LEG-01

Descrição técnica: `GET /legado/precos/{grupo}/{produto}/vigente?estrategia=foto|online|auto` → `{valor, origem (FOTO | ONLINE | BRP_TARIFA), dt_referencia, anomes_foto, degradado BIT}`; `GET /legado/precos/{grupo}/{produto}/historico?meses=12` → `[{anomes_ref, tarifa, origem}]`. Estratégia `auto`: tenta `online` com timeout 300 ms e circuit breaker (Resilience4j, abre com 50% de falhas em janela de 20 chamadas), cai para `foto` com `degradado = true`. Porta `ConectorTarifas` com implementação `NoOp` na F1 (sempre indisponível) e implementação real na F2 (REST, MQ ou DB link **[A DEFINIR — lacuna 7 / P5, P9]**), traduzindo o modelo do legado (contrato, evento tarifado) para `cod_produto` via `MAPA_DESCR_TARIFA_PRODUTO`. Não exposto no Axway; chamado apenas por svc-pricing (e svc-reprecificacao [EVOL]). `POST /legado/tarifas/efetivacoes` reservado [EVOL, P4].

Critérios de aceite: com conector indisponível, `auto` responde em < 350 ms com `origem = FOTO` e `degradado = true`; métrica de estado do circuit breaker exposta; resposta sempre carimbada com `dt_referencia`.

### SPEC-LEG-03 — Carga única dos ciclos legados (`SIMUL_*_AAAAMM`) no Delta

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-04, RNF-08, RNF-09 | **Depende de** SPEC-BRP-01

Descrição técnica: job Databricks `carga_ciclos_legados` que lê as tabelas `DCPS_EXP.SIMUL_EMISSOES_LM`, `SIMUL_PRC_ALVO_CLUSTER`, `SIMUL_REGIAO`, `SIMUL_SALDO_DAV`, `SIMUL_SALDO_IF`, `SIMUL_SHARE_BOLETOS`, `SIMUL_PRECO_POR_PRODUTO` de todos os `anomes` existentes (via JDBC ao SAS/SQL 010 ou exportação), mapeia para o contrato da BRP com `origem = 'LEGADO_SAS'` e grava em `brp.*` com `anomes` original, sem ativação no sql-motor; inventário prévio das tabelas (captura cortada, lacuna 8). Serve ao comparador (SPEC-TRN-02) e à continuidade histórica.

Critérios de aceite: todos os `anomes` disponíveis no SAS aparecem em `brp.execucao_ciclo` com `origem = LEGADO_SAS`; contagens por tabela reconciliadas com o SAS.

---

## 7. Épico API — Exposição no Axway e padrões de contrato

### SPEC-API-01 — Publicação das APIs no Axway com OAuth2

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-07, RNF-04, RNF-10 | **Depende de** SPEC-SEC-01

Descrição técnica: uma API por serviço exposta sob `/mpc/v1/precos`, `/mpc/v1/alcadas`, `/mpc/v1/parametros`, `/mpc/v1/brp` (+ `/reciprocidade`, `/reprecificacao` [EVOL]) a partir do OpenAPI gerado no build; aplicação cliente por canal (`sf-calculadora`, `sf-parametrizacao`, `integrador-x`) com OAuth2 client credentials (escopos `mpc.precos.simular`, `mpc.precos.consultar`, `mpc.parametros.editar`, `mpc.parametros.publicar`, `mpc.brp.publicar`, `mpc.alcada.decidir`); validação do JWT do usuário final (Entra ID) repassado no cabeçalho `X-Usuario-JWT` com claims de perfil; políticas: quota por aplicação (ex. 100 req/s `sf-calculadora`, 10 req/s integradores, a validar), throttling, tamanho máximo de payload 256 KB, timeout 3 s nas rotas online de `/precos` e `/alcadas` (RNF-02), 5 s nas demais, 30 s para comparações, CORS desligado, log de acesso com `correlation_id`; rotas internas (`/legado/*`, `/brp/versoes/*/validar`) **não** publicadas (acessíveis só na rede do ARO). Ambientes dev/hml/prd com aplicações cliente distintas.

Critérios de aceite: chamada sem token → 401 no gateway; token sem escopo → 403; quota excedida → 429 com `Retry-After`; OpenAPI publicado no catálogo com exemplos.

### SPEC-API-02 — Padrões: versionamento, erros, idempotência, cabeçalhos

**Fase** F1 | **Complexidade** P | **RF/RNF** RF-07, RNF-09 | **Depende de** —

Descrição técnica: biblioteca compartilhada `mpc-api-commons` (starter Spring) com: filtro de `X-Correlation-Id` (gera se ausente); `ProblemDetail` RFC 7807 padronizado; interceptor de `Idempotency-Key` com tabela `<svc>.idempotencia(chave, cliente, hash_request, resposta, dt)`; cabeçalhos de versão; paginação (`page`, `size`, `sort`, `X-Total-Count`); política de depreciação (`Deprecation` e `Sunset` headers); convenção de datas ISO-8601 com fuso; validação Bean Validation com mensagens em português.

```json
HTTP 422
{ "type": "https://mpc.bradesco/erros/sem-referencia-cluster", "title": "Sem referência de cluster",
  "status": 422, "detail": "Não há percentis para COB_TR_CONS_SDO_DEBAUT / Tier 3 / CORPORATE / NNE no anomes 202609",
  "instance": "/mpc/v1/precos/simulacoes", "correlation_id": "…",
  "erros": [ { "campo": "cod_produto", "codigo": "SEM_REFERENCIA_CLUSTER", "mensagem": "…" } ] }
```

Critérios de aceite: mesma `Idempotency-Key` com corpo diferente → 422 `IDEMPOTENCIA_CONFLITO`; todo erro 4xx/5xx é problem+json.

---

## 8. Épico SF — Salesforce (canais)

### SPEC-SF-01 — Integração base: Named Credentials, Apex proxy, flag por produto, contingência

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-07, RNF-01, RNF-04, RNF-08 | **Depende de** SPEC-API-01

Descrição técnica: Named Credential `MPC_API` (por sandbox/prod) com External Credential OAuth2 client credentials; classe Apex `MpcApiClient` genérica (`callout(metodo, rota, corpo)`) que só monta cabeçalhos (`X-Usuario-JWT`, `X-Correlation-Id`, `Idempotency-Key`) e repassa JSON, sem interpretar campos de preço (regra "sem lógica em Apex", verificada em code review por checklist: nenhuma aritmética sobre campos de preço, nenhum `if` sobre `tier`/`cluster`). Custom Metadata `MPC_FonteProduto__mdt (cod_produto, fonte (LEGADO | MOTOR | SHADOW))` para o corte por produto (SPEC-TRN-03). Contingência: objeto `MPC_UltimaCotacao__c` por Oportunidade/Conta × produto com `cotacao_id`, `saida_json`, `dt`; quando a API falhar (timeout/5xx), a LWC exibe a última cotação com carimbo e bloqueia "contratar sem alçada" **(regra a confirmar, doc 06 §5.2)**. Timeout do callout configurado em 5 s (o limite da plataforma é 120 s) para falhar rápido e cair na última cotação (RNF-02); resposta < 6 MB; tratamento de 429.

Critérios de aceite: teste estático (PMD com regra custom) falha o build se Apex referenciar campos `praticado`, `alvo`, `sugerido` em expressões; simulação com API fora responde com última cotação e aviso.

### SPEC-SF-02 — LWC Calculadora conectada ao motor

**Fase** F1 (shadow/piloto) / F2 (corte) | **Complexidade** G | **RF/RNF** RF-01, RF-02, RF-03, RF-04 | **Depende de** SPEC-SF-01, SPEC-PRC-04, SPEC-ALC-03

Descrição técnica: componente `mpcCalculadora` na Oportunidade/Conta: campos de entrada — cliente (Conta → CNPJ/`cd_grupo`), produto (lista do catálogo via `GET /parametros/vigentes?tipo=catalogo`), volumetria (`qtde`, unidade), preço negociado, estratégia de vigente (`auto` default; "buscar preço atualizado" força `online`); ações — Simular, Ver histórico 12 meses, Contratar sem alçada (habilitado apenas se `alcada.necessaria = false`), Pedir aprovação (abre `POST /alcadas/pedidos` com justificativa). Exibição — cartões praticado (com `origem` e `dt_referencia`), alvo (percentil, n, flag), sugerido (com `origem` e `cenario_id` do cenário lido na BRP), uplift anual; tabela de cenários por percentil; painel "e se mudar de tier" (volume mínimo para tier superior, alvo e sugerido do cenário vizinho); cenários de relacionamento apenas quando a BRP os publicar **[A DEFINIR — lacuna 3]**; bloco de alçada (nível, papel, uplift perdido); rodapé com `cotacao_id` e versões (BRP, parâmetros). Grava `cotacao_id` na Oportunidade (`MPC_CotacaoId__c`). Em `fonte = SHADOW`, a chamada ao motor é assíncrona (Queueable) e o resultado vai só para `MPC_CotacaoShadow__c` (SPEC-TRN-01).

Critérios de aceite: gerente simula e vê os três preços com versões; preço negociado abaixo do sugerido mostra alçada e desabilita "contratar"; produto com `fonte = LEGADO` continua usando o fluxo atual sem alteração visual.

### SPEC-SF-03 — Fila e decisão de alçada

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-03, RF-10 | **Depende de** SPEC-ALC-03, SPEC-SF-01

Descrição técnica: LWC `mpcFilaAprovacao` para papéis `alcada.*`: lista `GET /alcadas/pedidos?papel=<claim>&status=ABERTO` com cliente, produto, sugerido, negociado, desvio, uplift perdido, justificativa, prazo; ação aprovar/recusar com comentário; notificação ao solicitante via Platform Event `MPC_DecisaoAlcada__e` alimentado pelo evento `PrecoAprovado`/`PrecoRecusado` (integração via API ou consumidor do tópico). Alternativa: Approval Process nativo (doc 07 §4.2) a decidir na F1.

Critérios de aceite: aprovador vê apenas pedidos do seu papel; decisão reflete no pedido em < 5 s e o solicitante é notificado.

### SPEC-SF-04 — Console de parametrização e ativação da BRP

**Fase** F1 (versões, itens básicos, ativação BRP) / F2 (staging, agendamento, diff, perfis) | **Complexidade** GG | **RF/RNF** RF-05, RF-06, RF-10, RF-13 | **Depende de** SPEC-PAR-03, SPEC-PAR-05, SPEC-BRP-04, SPEC-SF-01

Descrição técnica: app Lightning `Parametrização MPC` com: (a) lista de versões (status, escopo, vigência, autor) e ações por perfil; (b) editor por tipo de parâmetro em `lightning-datatable` editável com paginação server-side (limites de governor), importação/exportação CSV por tipo (chama `PUT .../itens/{tipo}`), validação inline com os `erros[]` do serviço; (c) fluxo enviar a staging → simular em staging (seleciona carteira de teste, chama comparações, exibe relatório) → aprovar → publicar/agendar; (d) diff entre versões; (e) aba BRP Cash: catálogo de versões, qualidade do ciclo (alertas/bloqueantes), ativar/reverter com confirmação e justificativa; (f) trilha de auditoria da versão. Sem persistência local.

Critérios de aceite: editor altera faixa de tier, envia a staging, simula para carteira, aprovador aprova, publicador agenda; tudo refletido nas APIs e auditado; ativação de BRP com alerta exige confirmação explícita.

---

## 9. Épico EVT — Eventos de domínio (sb-eventos / outbox)

### SPEC-EVT-01 — Envelope de evento, publicação e fallback outbox

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-06, RNF-05 | **Depende de** SPEC-API-02

Descrição técnica: envelope `{evento_id UUID, tipo, schema_version, ocorrido_em, produtor, correlation_id, versoes{brp, parametros}, payload}`; biblioteca `mpc-eventos` com porta `PublicadorEventos` e duas implementações: `ServiceBus` (tópicos `mpc.publicacao`, `mpc.parametros`, `mpc.alcada`, `mpc.reciprocidade`, `mpc.reprecificacao`; assinaturas por consumidor; dead-letter) e `Outbox` (`<svc>.evento_outbox(evento_id, tipo, payload_json, dt, publicado_em NULL)` gravado na mesma transação; publicador agendado; `GET /eventos?apos=<cursor>&tipo=` para consumidores por polling). Consumidores idempotentes por `evento_id` (`<svc>.evento_consumido`). Seleção da implementação por configuração **[A DEFINIR — lacuna 9 / P6]**.

Critérios de aceite: evento gravado na outbox mesmo se o broker estiver fora; consumidor que recebe o mesmo `evento_id` duas vezes não repete efeito; troca de implementação sem alteração nos produtores.

---

## 10. Épicos OBS e SEC — Observabilidade, auditoria e segurança

### SPEC-OBS-01 — Observabilidade (logs, métricas, tracing, dashboards, alertas)

**Fase** F1 | **Complexidade** M | **RF/RNF** RNF-05, RF-08 | **Depende de** SPEC-API-02

Descrição técnica: padrão ARO (logs JSON para a stack central; Micrometer → Prometheus; OpenTelemetry tracing com `X-Correlation-Id` como atributo); métricas de negócio: `mpc_simulacoes_total{produto, canal, modo}`, `mpc_simulacao_latencia_seconds` (histograma; SLO p95 ≤ 300 ms no serviço e ≤ 500 ms no Axway, RNF-02); SLI de disponibilidade = respostas não 5xx / total no Axway em horário comercial, SLO 99,9% em janela de 30 dias (RNF-01); `mpc_alcada_necessaria_total`, `mpc_versao_brp_ativa` (gauge com label `anomes`), `mpc_versao_parametros_ativa`, `mpc_adapter_degradado_total`, `mpc_cache_hit_ratio`; dashboards Grafana "Motor online", "Ciclo BRP" (qualidade, execuções, tempo), "Shadow run" (concordância por produto); alertas: p95 do serviço > 300 ms ou p95 no Axway > 500 ms por 10 min, consumo do orçamento de erro do SLO de 99,9% acima de 2x em 1 h, erro 5xx > 1%, circuit breaker aberto > 5 min, ciclo reprovado, versão da BRP com mais de 45 dias, réplicas com `anomes` divergente. Alertas do Databricks Workflow e do Control-M integrados na mesma fila de operação.

Critérios de aceite: um trace percorre Salesforce → Axway → svc-pricing → svc-alcada/adapter com o mesmo `correlation_id`; alerta de ciclo reprovado dispara em teste.

### SPEC-OBS-02 — Auditoria imutável

**Fase** F1 | **Complexidade** M | **RF/RNF** RF-09, RNF-03 | **Depende de** SPEC-BRP-03

Descrição técnica: `auditoria.auditoria(seq BIGINT IDENTITY PK, dt DATETIME2(3), usuario, perfil, servico, entidade, chave, operacao, antes_json, depois_json, versao_id, correlation_id, origem, hash_anterior CHAR(64), hash CHAR(64))` com encadeamento de hash (cada linha inclui o hash da anterior) para detectar adulteração; permissões: usuários de aplicação com `INSERT` apenas; `UPDATE`/`DELETE` negados inclusive ao dono do schema em produção (só via processo de expurgo auditado); Azure SQL Ledger avaliado como alternativa. Exportação diária (Data Factory ou job Databricks JDBC) para `mpc.brp.auditoria_historico` e `cotacao_historico` no Delta; retenção online 24 meses **[P10]**. Consulta `GET /auditoria?entidade=&chave=&de=&ate=` (perfil `auditoria.leitor`).

Critérios de aceite: verificação da cadeia de hash sobre 1 milhão de linhas sem quebra; tentativa de `UPDATE` pelo usuário da aplicação → erro de permissão; toda transição de versão (parâmetros, BRP), decisão de alçada e simulação tem linha correspondente.

### SPEC-SEC-01 — Segurança, identidade e perfis

**Fase** F1 (canal e perfis básicos) / F2 (perfis completos) | **Complexidade** M | **RF/RNF** RF-10, RNF-04 | **Depende de** SPEC-API-01

Descrição técnica: identidade no Entra ID; grupos AD → claims (`precificacao.editor`, `precificacao.aprovador`, `precificacao.publicador`, `precificacao.leitor`, `alcada.nivel1..N`, `comercial.gerente`, `auditoria.leitor`, `operacao.mpc`); Salesforce SSO e emissão do JWT do usuário para o cabeçalho `X-Usuario-JWT`; Axway valida assinatura e expiração; serviços aplicam autorização por operação (`@PreAuthorize`) e registram `perfil` na auditoria; segregação de funções (SPEC-PAR-06, SPEC-ALC-03); secrets no Secrets do OpenShift sincronizados do Key Vault; TDE e TLS 1.2+; dados de cliente apenas por `cd_grupo` e CNPJ mascarado em logs/cotação (`cnpj_mascarado`); mTLS interno opcional; scan SAST/DAST na esteira; revisão anual de acessos.

Critérios de aceite: matriz operação × perfil testada por testes de autorização automatizados em cada serviço; token expirado → 401; log não contém CNPJ completo (teste de amostragem).

Dúvidas: mapeamento de grupos AD → papéis (P3, P8); usuário técnico do Databricks para `/brp/validar` e `/parametros/vigentes`.

---

## 11. Épico TRN — Transição (shadow run, comparador, corte)

### SPEC-TRN-01 — Shadow run no canal

**Fase** F1 | **Complexidade** M | **RF/RNF** RNF-08 | **Depende de** SPEC-SF-02, SPEC-PRC-04

Descrição técnica: com `MPC_FonteProduto__mdt.fonte = SHADOW`, a LWC obtém o preço oficial do fluxo atual (SQL 010) e dispara, de forma assíncrona (Queueable/Platform Event), `POST /precos/simulacoes` com a mesma entrada e `modo = SHADOW` (cabeçalho `X-Modo: SHADOW`); a resposta é gravada em `MPC_CotacaoShadow__c` junto com o resultado do legado (praticado, alvo, sugerido, alçada do SQL 010) e enviada ao Databricks por exportação diária (`mpc.silver.shadow_canal`). Grupo piloto pode ver uma aba "prévia do motor" com aviso.

Critérios de aceite: nenhuma latência adicional perceptível no fluxo oficial (chamada assíncrona); 100% das simulações do piloto têm par legado × motor gravado.

### SPEC-TRN-02 — Comparador automático de resultados (SQL 010 x motor)

**Fase** F1 | **Complexidade** G | **RF/RNF** RNF-08, RF-09 | **Depende de** SPEC-TRN-01, SPEC-LEG-03, SPEC-PRC-06

Descrição técnica: job Databricks `comparador_shadow(anomes)` com duas fontes: (a) lote — para toda a PPC do `anomes`, chama `POST /precos/simulacoes/comparacoes` (ou `/lote` quando existir) com `modo = SHADOW` e compara com as tabelas do SQL 010/`SIMUL_*` do mesmo `anomes` (carregadas via SPEC-LEG-03 ou extração direta das tabelas de saída do Motor da Calculadora **[acesso a definir — P1]**); (b) canal — `shadow_canal`. Métricas por produto × cluster: concordância de tier, cluster e alvo (igualdade exata), sugerido (dentro de ±`tolerancia_pct`, default 1%), alçada (nível igual); desvio médio e máximo; lista de discrepantes com trilha do motor (`saida_json.trilha`) para engenharia reversa (discrepância de sugerido aponta para o pipeline, SPEC-PPP-13, e não para o motor). Saída `brp.comparacao_shadow(anomes, cod_produto, cluster, metrica, valor, limiar, status)` e dashboard (SPEC-OBS-01). Limiares parametrizados: alvo idêntico ≥ 99,5%; sugerido ±1% em ≥ 98%; alçada 100% (doc 06 §10, a validar).

Critérios de aceite: relatório por produto gerado em cada ciclo; discrepância cria item de backlog (exportação CSV/Jira) com entrada, saída legado, saída motor e trilha.

### SPEC-TRN-03 — Critérios de corte, flag por produto, rollback e desligamento

**Fase** F2 | **Complexidade** M | **RF/RNF** RNF-08, RNF-01 | **Depende de** SPEC-TRN-02, SPEC-SF-01, SPEC-BRP-04, SPEC-PAR-01

Descrição técnica: procedimento operacional codificado como checklist verificável: (a) concordância acima do limiar por dois ciclos consecutivos; (b) p95 dentro da meta em hml e no shadow de produção; (c) piloto sem incidente de preço por 4 semanas; (d) aprovação formal da Precificação registrada (ata anexada à versão). Corte: alterar `MPC_FonteProduto__mdt` para `MOTOR` (deploy de metadata, minutos); SAS/SQL 010 continuam carregando o produto por um ciclo como retaguarda. Rollback: (1) flag de volta para `LEGADO`; (2) problema de dados: `POST /brp/versoes/{anomes}/reverter` ou `POST /parametros/versoes/{id}/reverter`. Ordem sugerida: Multipag, PIX, Arrecadação, Cobrança (doc 06 §5.4). Desligamento: após o último produto, um ciclo em modo leitura, depois desativar SAS e SQL 010 e remover o conector Salesforce → SQL 010.

Critérios de aceite: simulação de rollback em hml em menos de 15 min ponta a ponta; cada corte tem registro em auditoria com os quatro critérios evidenciados.

---

## 12. Épico REC — svc-reciprocidade [EVOLUÇÃO — a detalhar com o negócio]

Tudo neste épico é hipótese de modelo derivada de A2 Fluxo 06 §8 e do brief §3 (C3.1-C3.4); nenhum critério vem de documento de negócio. Depende do discovery da F3 (R2, lacuna 4).

### SPEC-REC-01 — Modelo do acordo de reciprocidade

**Fase** F3 | **Complexidade** M | **RF/RNF** RF-12, RF-09 | **Depende de** SPEC-PRC-01, SPEC-PAR-02

Hipótese: `reciprocidade.acordo_reciprocidade(acordo_id, cd_grupo, cotacao_id NULL, origem (CONTRATACAO, MANUAL, LEGADO), vigencia_inicio, vigencia_fim, status, responsavel, criado_em)` e `acordo_item(acordo_id, indicador (VOLUME_PRODUTO, SALDO_IF, SALDO_DAV, SOW_BOLETOS, SHARE_CASH, PRODUTOS_CONTRATADOS), cod_produto NULL, valor_acordado, unidade, tolerancia_pct)`. `POST /reciprocidade/acordos` chamado pela Calculadora na contratação (ou manual). **[A DEFINIR — lacuna 4 / P7: o que é "acordo", onde é registrado hoje, quem responde por ele.]**

Critérios de aceite (hipótese): acordo criado a partir de uma cotação herda produto, volumetria e desconto de relacionamento aplicado; acordo sem item → 422.

### SPEC-REC-02 — Monitoramento e regra de desvio (job)

**Fase** F3 | **Complexidade** G | **RF/RNF** RF-12 | **Depende de** SPEC-REC-01, SPEC-BRP-04, SPEC-PPP-09

Hipótese: `POST /reciprocidade/monitoramentos {anomes}` (Control-M, após `VersaoBrpPublicada`): para cada acordo vigente e item, obtém o realizado em `brp.indicadores_reciprocidade` / PPC do `anomes` (emissões L3M, `qtde_mensal`, `saldo_if_medio`, `saldo_dav_medio`, `sow_boletos`, `share_cash`), calcula `pct_desvio = (realizado − acordado) / acordado`, compara com `tolerancia_pct` (item ou `parametro_item_reciprocidade`), persiste `desvio_reciprocidade(desvio_id, acordo_id, anomes, indicador, acordado, realizado, pct_desvio, status (DETECTADO, NOTIFICADO, TRATADO, IGNORADO), acao_sugerida)`. Regras de janela (quantos ciclos consecutivos), de agregação e de ação **[A DEFINIR]**.

Critérios de aceite (hipótese): job idempotente por `anomes`; desvio dentro da tolerância não gera registro; `GET /reciprocidade/desvios?grupo=&status=` lista com paginação.

### SPEC-REC-03 — Eventos, elegibilidade e alertas ao gerente

**Fase** F3 | **Complexidade** M | **RF/RNF** RF-12, RF-11 (insumo) | **Depende de** SPEC-REC-02, SPEC-EVT-01, SPEC-SF-01

Hipótese: eventos `AcordoRegistrado`, `DesvioReciprocidadeDetectado {acordo_id, cd_grupo, indicador, pct_desvio}`, `ClienteElegivelParaReprecificacao {cd_grupo, cod_produto, motivo, anomes}` no tópico `mpc.reciprocidade`; `GET /reciprocidade/elegiveis?anomes=` para C2; integração Salesforce cria Tarefa para o gerente da conta com desvio e ação sugerida (manter desconto, revisar acordo, reprecificar). Critério de elegibilidade (quais desvios, quantos ciclos) **[A DEFINIR]**.

---

## 13. Épico REP — svc-reprecificacao [EVOLUÇÃO — a detalhar com o negócio]

Hipóteses derivadas de A2 Fluxo 07 (Saída 1, abas manuais) e brief §3 (C2.1-C2.5). Dependem do discovery da F3 e das decisões P4 (efetivação) e da gradação Stickiness x Impacto (lacuna 4).

### SPEC-REP-01 — Onda: planejamento e escopo

**Fase** F4 | **Complexidade** M | **RF/RNF** RF-11 | **Depende de** SPEC-PAR-02, SPEC-BRP-04

Hipótese: `reprecificacao.onda_reprecificacao(onda_id, nome, status (PLANEJADA, ELEGIVEIS_SELECIONADOS, CALCULADA, EM_APROVACAO, APROVADA, EFETIVADA, ACOMPANHAMENTO, ENCERRADA), escopo_json {produtos[], segmentos[], regioes[]}, anomes_base, meta_uplift, gradacao_json, calendario_json, versao_parametros, criado_por)`; `POST /reprecificacao/ondas`; gradação como matriz `stickiness × impacto → pct_reajuste_max` em `parametro_item_gradacao` **[A DEFINIR — passo 4 da metodologia, `06:L138` truncado]**.

### SPEC-REP-02 — Seleção de elegíveis

**Fase** F4 | **Complexidade** G | **RF/RNF** RF-11 | **Depende de** SPEC-REP-01, SPEC-REC-03, SPEC-PPP-08

Hipótese: tarefa Databricks `elegiveis_onda(onda_id)` que parte da PPC do `anomes_base` no escopo, exclui `parametro_item_excecao` dos tipos NEGOCIACAO_RECENTE (janela), DATA_REPRECIFICACAO (mínimo de meses desde a última), RFP vigente, NICHO, ASSOC_RELIGIOSA, PODER_PUBLICO, GRUPO_EXCLUIDO; exclui `flag_nao_representativo` (N < 15) e `uplift ≤ 0`; une com `ClienteElegivelParaReprecificacao` de C3; grava `onda_cliente_produto(onda_id, cd_grupo, cod_produto, motivo_elegibilidade, uplift_potencial, stickiness, impacto, status)` via reverse ETL; `POST /reprecificacao/ondas/{id}/elegiveis` dispara e `GET` lista com filtros para revisão manual (incluir/excluir com justificativa). Critérios e prioridades **[A DEFINIR]**.

### SPEC-REP-03 — Cálculo em lote, aprovação, efetivação e acompanhamento

**Fase** F4 | **Complexidade** GG | **RF/RNF** RF-11, RF-03, RF-09 | **Depende de** SPEC-REP-02, SPEC-PRC-07, SPEC-ALC-03, SPEC-LEG-02

Hipótese: `POST /reprecificacao/ondas/{id}/calcular` → `svc-pricing /lote` com `gradacao` da onda (`preco_proposto = min(sugerido, praticado × (1 + pct_reajuste_max[stickiness, impacto]))` **(inferido)**); revisão por lote/segmento; `POST .../aprovar` → `svc-alcada` por item ou por lote (política de alçada com `escopo = ONDA` **[A DEFINIR]**); efetivação: se P4 = "motor efetiva", `svc-legado-adapter POST /legado/tarifas/efetivacoes` com contrato a negociar; senão, exportação da lista aprovada (CSV) para o processo atual e status `EFETIVADA_EXTERNAMENTE`; comunicação ao gerente via Tarefa Salesforce; acompanhamento: no ciclo seguinte, job compara `tarifa_praticada` novo x `preco_proposto` e calcula `uplift_realizado` por item, agregado na onda (`GET /reprecificacao/ondas/{id}/acompanhamento`). Eventos `OndaPlanejada`, `OndaCalculada`, `OndaAprovada`, `OndaEfetivada`.

Critérios de aceite (hipótese): onda de 50 mil itens calculada, aprovada em lote e exportada sem intervenção de TI; uplift realizado disponível no ciclo seguinte.

---

## 14. Matriz SPEC x fase x requisitos

| SPEC | Épico | Fase | Compl. | RF | RNF |
|---|---|---|---|---|---|
| PPP-01 | PPP | F1 | G | 13 | 07, 09 |
| PPP-02 | PPP | F1/F2 | M | 08 | 06 |
| PPP-03 | PPP | F1 | G | 13 | — |
| PPP-04 | PPP | F1 | M | 13 | — |
| PPP-05 | PPP | F1 | M | 13 | — |
| PPP-06 | PPP | F1 | M | 13 | — |
| PPP-07 | PPP | F1 | M | 13 | — |
| PPP-08 | PPP | F1 | G | 13 | 07 |
| PPP-09 | PPP | F1 | G | 13, 12 | — |
| PPP-10 | PPP | F1 | M | 04, 13 | — |
| PPP-11 | PPP | F1 | M | 08 | 05 |
| PPP-12 | PPP | F1 | M | 13 | 05, 09, 10 |
| PPP-13 | PPP | F0/F1 | G | 13, 01 | 07, 09 |
| BRP-01 | BRP | F0/F1 | M | 13 | 06, 09 |
| BRP-02 | BRP | F1 | M | 13 | 01, 09 |
| BRP-03 | BRP | F1 | G | — | 01, 03, 09 |
| BRP-04 | BRP | F1 | M | 08, 09, 13 | 01 |
| PRC-01 | PRC | F1 | M | 09 | 03, 09 |
| PRC-02 | PRC | F1 | M | 01 | 07 |
| PRC-03 | PRC | F1 | G | 01, 02, 03 | 07, 09 |
| PRC-04 | PRC | F1 | M | 01, 02, 04, 07 | 02 |
| PRC-05 | PRC | F1 | P | — | 01, 02 |
| PRC-06 | PRC | F1/F2 | M | 06 | 09 |
| PRC-07 [EVOL] | PRC | F4 | G | 11 | 09 |
| ALC-01 | ALC | F1/F2 | M | 03, 05 | 07 |
| ALC-02 | ALC | F1 | P | 03 | — |
| ALC-03 | ALC | F1 | M | 03, 09, 10 | 03 |
| PAR-01 | PAR | F1/F2 | M | 05, 06 | 09 |
| PAR-02 | PAR | F1 | G | 05 | 07 |
| PAR-03 | PAR | F1 | M | 05, 06, 10 | — |
| PAR-04 | PAR | F1 | P | 13 | 09 |
| PAR-05 | PAR | F2 | M | 06 | — |
| PAR-06 | PAR | F1/F2 | M | 09, 10 | 03, 04 |
| PAR-07 | PAR | F0/F1 | M | 05, 13 | — |
| LEG-01 | LEG | F1 | P | 04 | 06 |
| LEG-02 | LEG | F1/F2 | M+G | 04, 07 | 01, 02 |
| LEG-03 | LEG | F1 | M | 04 | 08, 09 |
| API-01 | API | F1 | M | 07 | 04, 10 |
| API-02 | API | F1 | P | 07 | 09 |
| SF-01 | SF | F1 | M | 07 | 01, 04, 08 |
| SF-02 | SF | F1/F2 | G | 01, 02, 03, 04 | — |
| SF-03 | SF | F1 | M | 03, 10 | — |
| SF-04 | SF | F1/F2 | GG | 05, 06, 10, 13 | — |
| EVT-01 | EVT | F1 | M | 06 | 05 |
| OBS-01 | OBS | F1 | M | 08 | 05 |
| OBS-02 | OBS | F1 | M | 09 | 03 |
| SEC-01 | SEC | F1/F2 | M | 10 | 04 |
| TRN-01 | TRN | F1 | M | — | 08 |
| TRN-02 | TRN | F1 | G | 09 | 08 |
| TRN-03 | TRN | F2 | M | — | 01, 08 |
| REC-01 [EVOL] | REC | F3 | M | 12, 09 | — |
| REC-02 [EVOL] | REC | F3 | G | 12 | — |
| REC-03 [EVOL] | REC | F3 | M | 12, 11 | — |
| REP-01 [EVOL] | REP | F4 | M | 11 | — |
| REP-02 [EVOL] | REP | F4 | G | 11 | — |
| REP-03 [EVOL] | REP | F4 | GG | 11, 03, 09 | — |

Cobertura: todo RF-01..RF-13 e RNF-01..RNF-10 tem ao menos um SPEC; RF-11 e RF-12 apenas em SPECs de evolução. Total: 56 SPECs (13 PPP, 4 BRP, 7 PRC, 3 ALC, 7 PAR, 3 LEG, 2 API, 4 SF, 1 EVT, 2 OBS, 1 SEC, 3 TRN, 3 REC, 3 REP).

---

## 15. Ordem de implementação sugerida (grafo de dependências)

```mermaid
flowchart TB
  subgraph F0["F0 — fundações e decisões"]
    BRP01["BRP-01 contrato gold"]
    PAR02["PAR-02 tipos de parâmetro"]
    PAR07["PAR-07 carga inicial"]
    API02["API-02 padrões"]
  end
  subgraph F1A["F1 — plataforma"]
    PAR01["PAR-01 versão/estado"]
    PAR03["PAR-03 APIs"]
    PAR04["PAR-04 vigente"]
    SEC01["SEC-01 perfis"]
    API01["API-01 Axway"]
    EVT01["EVT-01 eventos/outbox"]
    OBS01["OBS-01 observabilidade"]
    OBS02["OBS-02 auditoria"]
    BRP03["BRP-03 modelo/ativação"]
  end
  subgraph F1B["F1 — pipeline"]
    PPP01["PPP-01 lib comum"]
    PPP02["PPP-02 T0"]
    PPP03["PPP-03 T1"]
    PPP04["PPP-04 T2"]
    PPP05["PPP-05 T3"]
    PPP06["PPP-06 T4"]
    PPP07["PPP-07 T5"]
    PPP08["PPP-08 T6 MPA/PPC"]
    PPP13["PPP-13 T6b sugerido por cenário"]
    PPP09["PPP-09 T7"]
    PPP10["PPP-10 T8"]
    PPP11["PPP-11 T9"]
    BRP02["BRP-02 T10 reverse ETL"]
    PPP12["PPP-12 orquestração"]
    BRP04["BRP-04 svc-publicacao"]
    LEG03["LEG-03 ciclos legados"]
  end
  subgraph F1C["F1 — motor online"]
    LEG01["LEG-01 foto"]
    LEG02["LEG-02 adapter"]
    PRC01["PRC-01 cotação"]
    PRC02["PRC-02 tier/cluster"]
    ALC01["ALC-01 política"]
    ALC02["ALC-02 avaliação"]
    PRC03["PRC-03 cálculo"]
    PRC04["PRC-04 API"]
    PRC05["PRC-05 cache"]
    ALC03["ALC-03 pedidos"]
    PRC06["PRC-06 staging/reexecução"]
  end
  subgraph F1D["F1 — canal e shadow"]
    SF01["SF-01 integração"]
    SF02["SF-02 calculadora"]
    SF03["SF-03 fila alçada"]
    SF04["SF-04 parametrização (básico)"]
    TRN01["TRN-01 shadow canal"]
    TRN02["TRN-02 comparador"]
  end
  subgraph F2["F2 — completude e corte"]
    PAR05["PAR-05 staging"]
    PAR06["PAR-06 perfis/auditoria"]
    TRN03["TRN-03 corte/rollback"]
  end
  subgraph F3F4["F3/F4 — evolução"]
    REC01["REC-01"] --> REC02["REC-02"] --> REC03["REC-03"]
    REP01["REP-01"] --> REP02["REP-02"] --> REP03["REP-03"]
    PRC07["PRC-07 lote"]
  end

  PAR02 --> PAR01 --> PAR03 --> PAR04
  PAR02 --> PAR07
  API02 --> API01 --> SEC01
  API02 --> EVT01
  BRP01 --> BRP03 --> BRP04
  EVT01 --> BRP04
  OBS02 --> BRP04
  PAR02 --> PPP01 --> PPP02
  PAR04 --> PPP01
  PPP02 --> PPP03 --> PPP04
  PPP02 --> PPP05 & PPP06 & PPP07 & PPP09 & PPP10
  PPP04 & PPP05 & PPP06 & PPP07 --> PPP08
  BRP01 --> PPP08 & PPP09
  PPP08 & PPP09 --> PPP13
  PAR07 --> PPP13
  PPP13 & PPP09 & PPP10 --> PPP11 --> BRP02 --> PPP12
  BRP03 --> BRP02
  BRP01 --> LEG03
  BRP03 --> LEG01 --> LEG02
  BRP03 --> PRC01
  PAR04 --> PRC02
  PAR02 --> ALC01 --> ALC02
  PRC02 & LEG02 & ALC02 --> PRC03 --> PRC04
  EVT01 & BRP04 --> PRC05
  PRC04 --> PRC06
  ALC02 & PRC01 & EVT01 --> ALC03
  API01 --> SF01 --> SF02 & SF03 & SF04
  PRC04 --> SF02
  ALC03 --> SF03
  PAR03 & BRP04 --> SF04
  SF02 --> TRN01 --> TRN02
  LEG03 & PRC06 --> TRN02
  PRC06 & PAR03 --> PAR05
  SEC01 --> PAR06
  TRN02 & PAR01 --> TRN03
  PRC03 --> PRC07 --> REP03
  REC03 --> REP02
  PPP09 --> REC02

  style F3F4 stroke-dasharray: 5 5
  style REC01 stroke-dasharray: 5 5
  style REC02 stroke-dasharray: 5 5
  style REC03 stroke-dasharray: 5 5
  style REP01 stroke-dasharray: 5 5
  style REP02 stroke-dasharray: 5 5
  style REP03 stroke-dasharray: 5 5
  style PRC07 stroke-dasharray: 5 5
```

Leitura: três frentes paralelas na F1 (pipeline, motor online, canal) convergem no shadow run (TRN-01/02). O caminho crítico é PAR-02 → PPP-01 → PPP-08 → PPP-13 → PPP-11 → BRP-02 → BRP-04 → PRC-05/SF-02 → TRN-02: qualquer atraso na definição dos tipos de parâmetro (PAR-02, que depende das lacunas 2 e 5) atrasa tudo. PRC-03 não depende da lacuna 1: o motor só lê o sugerido do cenário. A engenharia reversa do sugerido (lacuna 1) impacta PPP-13, que pode publicar `preco_sugerido = preco_alvo_ref` como provisório sem bloquear o shadow.

---

## 16. Lista consolidada de dúvidas a resolver antes de criar tasks

| # | Dúvida | Lacuna do brief | SPECs afetados | Dono sugerido |
|---|---|---|---|---|
| D1 | Regras da macro "Preço por Produto"/"Resumo por GE" e do Motor da Calculadora (SQL 010): como o sugerido de cada cenário é derivado do alvo e em que ordem; papel da lista semestral de preço por produto; política do motor para cenário sem sugerido publicado. Regra do **pipeline** (Revisão 1.1), não do motor | 1 | PPP-13, PPP-11, PAR-02, PRC-03 (só a política de ausência), TRN-02 | Precificação + TI legado |
| D2 | Layouts e valores de `premissas_alcada`, `premissas_desconto`, `premissas_remuneracao`, `tier_por_produto`, `regiao_por_ge` | 2 | PAR-02, PAR-07, ALC-01, PPP-13 | Precificação |
| D3 | Definição formal de alvo x sugerido; relacionamento (saldo IF/DAV, Stickiness x Impacto) como dimensão adicional do cenário na BRP ou exceção por cliente; níveis, papéis e prazos de alçada; volumetria informada substitui a da PPC? | 3 | PRC-02, PRC-03, PPP-13, BRP-01, ALC-01, ALC-03, SF-02 | Precificação + Comercial |
| D4 | C3: o que é o acordo, onde é registrado, indicadores e tolerâncias; C2: critérios de elegibilidade, gradação Stickiness x Impacto, motor efetiva ou recomenda (P4) | 4 | REC-*, REP-*, LEG-02, PRC-07 | Negócio + dono do legado |
| D5 | INSTITUCIONAL dentro ou fora; regra de cluster de Arrecadação (LARGE/INSTITUCIONAL→3, CORPORATE→4) x Grupo 3; grupo 616 = grupo Bradesco e motivo; `NA BAIXA POR PAGAMENTO Banco` sem grupo; fonte de `CANAIS DIGITAIS`/`DÉBITO AUTOMÁTICO`; fallback para combinação sem percentil | 5 | PPP-01, PPP-07, PPP-08, PAR-02, PAR-07, PRC-03 | Precificação |
| D6 | Confirmação das janelas (LTM 13, L3M 3, ROB 6, share cash 3, saldo 3, boletos 12) e do calendário mensal/semestral | 6 | PPP-02, PPP-09, PPP-12, PAR-02 | Precificação |
| D7 | Latência aceitável do preço vigente; conector ao sistema de tarifas (REST/MQ/DB link) e sua fonte no lake; Multipag usa tarifa de contrato | 7 | PPP-10, LEG-01, LEG-02, SF-02 | Negócio + dono do legado |
| D8 | Trechos truncados: clusters "demais" e corporate de Cobrança, variante com Tier 2 separado, página 10, `06` após L138, tabelas SAS cortadas | 8 | PPP-01, PPP-04, PPP-09, LEG-03 | Precificação |
| D9 | Azure Service Bus aprovado na stack ou outbox definitivo | 9 | EVT-01, PRC-05, BRP-04, ALC-03 | Arquitetura corporativa |
| D10 | Semântica de N (grupos distintos?) e uso de `QTDE_CASH_CONC`/`QTDE_COB_CONC`; "sem dado" tratado como baixo relacionamento? | 10 | PPP-01, PPP-09, BRP-01 | Precificação |
| D11 | Filtro de contrato Multipag (PAGAMENTO VIA TED/FORNECEDORES) era intencional? receita negativa em PIX; regras não descritas em Cobrança (emissor, impressão/postagem, tarifa média) | A1 §9 | PPP-03, PPP-05, PPP-06 | Precificação |
| D12 | Governança: quem publica versão de parâmetro e BRP; ativação automática permitida? retenção de cotações/auditoria (P10); tier do Azure SQL e viabilidade de `SWITCH PARTITION` | R10, P10 | BRP-03, BRP-04, PAR-06, PRC-01, OBS-02 | Precificação + TI + Compliance |
| D13 | Mapeamento de grupos AD → papéis; usuário técnico do Databricks; padrão de CI/CD e de publicação de APIs no Axway | P3, P9 | SEC-01, API-01, PPP-12 | TI |
| D14 | Fila de alçada em serviço próprio ou Approval Process nativo do Salesforce; regra de bloqueio de contratação em contingência | — | ALC-03, SF-01, SF-03 | Comercial + Salesforce |
| D15 | Nomes físicos das tabelas bronze no Databricks e acesso às tabelas de saída do SQL 010 para o comparador | — | PPP-02, TRN-02, LEG-03 | Dados + TI legado |

Regra de trabalho: nenhum SPEC marcado com **[A DEFINIR]** vira task de implementação antes da dúvida correspondente ter decisão registrada no catálogo de parâmetros (SPEC-PAR-07) ou em ata da F0; os demais SPECs podem ser quebrados em tasks imediatamente após a validação deste documento.
