# 06 — Arquitetura de Solução: Motor de Precificação Cash (MPC)

| Campo | Valor |
|---|---|
| Versão | 1.1 |
| Data | 2026-09-18 |
| Status | Rascunho para validação |
| Revisão | Revisão 1.1 (2026-09-18): preço sugerido passa a ser lido da BRP Cash por cenário; MPA renomeada para Matriz de Cenários de Preço. Revisão 1.2 (2026-10-02): metas de RNF-01 e RNF-02 detalhadas (`anexos/A0` §7) |
| Fontes | `docs-precificacao/00-doc-negocio.md`; `docs-precificacao/00-etapas-geracao-planilha-ano1.md`; `docs-precificacao/07-planilha-ano1-fluxo.md`; `stack-tech.md`; `anexos/A0-brief-decisoes.md` (decisões AD-01..AD-14, requisitos RF/RNF, roadmap); `anexos/A1` e `anexos/A2` (síntese transversal) |
| Documentos relacionados | 01 e 02 Contexto de negócio; 03 Desenho conceitual; 04 Capacidades e rastreabilidade; 05 Domínios, bounded contexts e context mapping; 07 Componentes (definição e justificativa); 08 Especificações técnicas; 09 Roadmap |

Convenção: C2 (Onda de Reprecificação) e C3 (Gestão de Reciprocidade) são **[EVOLUÇÃO — a detalhar com o negócio]**. Nos diagramas aparecem tracejados. Toda decisão cita seu ID (AD-xx) e os requisitos que atende (RF-xx / RNF-xx), conforme `anexos/A0-brief-decisoes.md` §6 e §7. Referências a fontes no formato `NN:L<linha>` abreviam `docs-precificacao/<arquivo>:L<linha>` para os fluxos 01 a 07 (por exemplo, `07:L29` é `docs-precificacao/07-planilha-ano1-fluxo.md:L29`); `00-etapas:L<linha>` refere-se a `00-etapas-geracao-planilha-ano1.md`; "lacuna n" refere-se ao brief §8; D1-D7 são as dores da §2 e P1-P10 as decisões pendentes da §11 deste documento.

---

## 1. Sumário executivo da arquitetura

O Motor de Precificação Cash substitui a cadeia manual "Planilha Ano 1 → SAS → SQL 010 → Calculadora Salesforce" por uma plataforma em duas metades bem separadas:

- **Plataforma analítica (Databricks)**, que porta os sete notebooks Python para Databricks Workflows e produz a **Base de Referência de Preços Cash (BRP Cash)** versionada por ciclo de precificação (`anomes`).
- **Motor online (microsserviços Java no ARO + Azure SQL)**, que responde em tempo real preço praticado, alvo e sugerido, cenários, uplift e alçada, consumindo a BRP Cash publicada por reverse ETL e parâmetros versionados. O motor classifica o cliente (tier, cluster) e consulta o cenário na BRP; não calcula o sugerido (revisão 1.1).

Princípios que governam todas as decisões deste documento:

1. **Salesforce é canal, não motor** (AD-05). A Calculadora, a Parametrização e, no futuro, a Reprecificação são LWC que chamam APIs. Nenhuma regra de preço vive em Apex. Isso ataca o risco R6 e garante RF-07 (outros canais consomem as mesmas APIs).
2. **Regras como dados versionados** (AD-04, AD-06). Tiers, clusters, percentis, premissas de desconto, alçada e listas de exceção são tabelas com versão, status e vigência, não código. O código Java contém apenas as estratégias de aplicação. Isso atende RF-05, RF-06, RNF-07 e RNF-09.
3. **BRP Cash versionada por ciclo** (AD-01, AD-03). Cada `anomes` é uma versão imutável; a ativação em produção é atômica e a versão anterior fica sempre disponível para rollback (AD-13).
4. **Legado atrás de uma camada anticorrupção** (AD-10). O preço vigente e o histórico de 12 meses são acessados por um Adaptador com duas estratégias (foto via Databricks e consulta online), sem que o motor conheça o modelo do sistema de tarifas.
5. **C2 e C3 preparados, não construídos** (AD-07, AD-08, AD-09). O desenho reserva eventos de domínio e o reuso do serviço de cálculo, de modo que a Onda de Reprecificação e a Gestão de Reciprocidade entrem sem refatorar o núcleo.
6. **Transição em shadow** (AD-14). O novo motor responde em paralelo ao SQL 010 durante o piloto, com comparação automática por produto antes do desligamento gradual.
7. **Aderência à stack corporativa** (RNF-10). Salesforce FSC, Azure, Java para transações, Python/Databricks para dados, ARO, Axway, Application Gateway, Akamai. O único componente fora da stack é o Azure Service Bus (AD-09), tratado como decisão pendente com fallback.

O que este desenho **não** resolve sozinho: as regras que levam ao preço sugerido de cada cenário (macro "Preço por Produto" da planilha) não estão documentadas (lacuna 1 do brief). Como o sugerido é lido pronto da BRP Cash, essas regras pertencem ao pipeline (dbx-ppp) e à parametrização (svc-parametros), não ao motor online; a engenharia reversa na F0 é pré-requisito para a BRP v1 do MVP (risco R1).

---

## 2. Visão AS-IS

Hoje o preço chega ao gerente comercial por uma cadeia de cinco tecnologias e várias etapas manuais (`docs-precificacao/07-planilha-ano1-fluxo.md:L17-42`; detalhamento em `anexos/A2` Fluxo 07).

```mermaid
flowchart LR
  subgraph ORIG["Sistemas de origem"]
    O1["Movimento e eventos tarifados<br/>Cobrança, Arrecadação, Multipag, PIX, TED"]
    O2["Segmentos, ROB, IF/DAV,<br/>share boletos/cash, regionalidade"]
  end
  subgraph EXT["Extração SQL / Databricks"]
    X1["Exportação para pasta 'entradas'<br/>arquivos csv"]
  end
  subgraph PY["Estação do analista (Python local)"]
    N1["01 Base Cobrança"]
    N2["02 Uplift Cobrança"]
    N3["03 Multipag"]
    N4["04 PIX"]
    N5["05 Arrecadação"]
    N6["06 Uplift Consolidado"]
    N7["07 Stickiness x Impacto"]
  end
  subgraph XLS["Planilha Preço Ano 1.xlsx"]
    W1["Abas de dados<br/>(cópia manual das saídas)"]
    W2["Abas manuais: Negociações Recentes,<br/>RFPs, Custos, Nichos, Premissas, Tiers"]
    W3["Macro: Preço por Produto /<br/>Resumo por GE (lógica não documentada)"]
    W4["Saída 1: reprecificação manual"]
  end
  subgraph DIST["Distribuição legada"]
    S1["SAS: importa 11 xlsx<br/>tabelas SIMUL_*_AAAAMM"]
    S2["Motor da Calculadora<br/>Servidor SQL 010 (regra de negócio)"]
    S3["Calculadora Salesforce"]
  end
  O1 --> X1
  O2 --> X1
  X1 --> N1 & N2 & N3 & N4 & N5 & N7
  N2 & N3 & N4 & N5 --> N6
  N1 & N6 & N7 --> W1
  W1 & W2 --> W3
  W3 --> W4
  W3 -->|"cópia manual de 11 arquivos"| S1
  S1 -->|"query SAS manual"| S2
  S2 --> S3
  S3 --> GER["Gerente comercial"]
  style W3 fill:#fde2e2,stroke:#c0392b
  style S2 fill:#fde2e2,stroke:#c0392b
```

**Pontos de dor** (referências em `anexos/A2` Fluxo 07 §9 e Síntese):

| # | Dor | Evidência | Consequência |
|---|---|---|---|
| D1 | Regras do preço sugerido vivem em macro VBA e em procedimento no SQL 010, sem documentação | `07:L29-31`, `L41`, `L114` | Impossível auditar, versionar ou reproduzir um preço (viola `00-doc-negocio.md:L13-14`) |
| D2 | Colagem manual de saídas em abas e de abas em arquivos | `07:L21-27`, `L34` | Erro humano, ciclo longo, sem rastreabilidade |
| D3 | Datas e listas hard-coded nos notebooks (`202506`, grupo 616, segmentos) | `anexos/A1` lacunas | Cada ciclo exige editar código |
| D4 | Três camadas de distribuição (planilha, SAS, SQL 010) só para levar dados ao Salesforce | `07:L37-42` | Custo de operação, dois pontos de falha, defasagem mensal |
| D5 | Preço vigente vem da própria base analítica (`TARIFA`), não do legado | `05:L38` | Preço praticado pode estar defasado em relação ao sistema de tarifas |
| D6 | Sem staging, sem vigência agendada, sem perfis | `00-doc-negocio.md:L17-18`, `L42` sem contrapartida no AS-IS | Governança de parâmetros inexistente |
| D7 | Cadência mista (mensal para SIMUL_*, semestral para preço por produto) sem controle de versão explícito | `07:L112` | Combinações inconsistentes de insumos |

---

## 3. Visão de contexto TO-BE (C4 nível 1)

```mermaid
flowchart TB
  GER["Gerente comercial / Cash<br/>(usa Calculadora)"]
  PREC["Equipe de Precificação<br/>(parametriza, publica, planeja ondas)"]
  APR["Aprovador de alçada<br/>(gerente regional, diretoria)"]
  OUT["Outros canais, plataformas<br/>e integradores"]

  subgraph MPC["Motor de Precificação Cash"]
    SF["Canais Salesforce FSC<br/>sf-calculadora, sf-parametrizacao, sf-reprecificacao"]
    GW["Borda<br/>Akamai, App Gateway, Axway"]
    MOTOR["Motor online<br/>microsserviços Java no ARO"]
    DADOS[("Base de serviço<br/>Azure SQL (sql-motor)")]
    PPP["Pipeline de Preparação de Preços<br/>Databricks (dbx-ppp) → BRP Cash (dbx-brp)"]
  end

  LEG["Legado de tarifas e contratos<br/>(preço vigente, histórico)"]
  CAD["Cadastro de cliente e<br/>grupo econômico"]
  FON["Fontes analíticas no Databricks<br/>(movimento, eventos tarifados, IF/DAV, ROB, share)"]
  IAM["Identidade e acesso<br/>(AD corporativo / Salesforce)"]
  CTM["Control-M<br/>(orquestração corporativa)"]

  GER --> SF
  PREC --> SF
  APR --> SF
  OUT --> GW
  SF --> GW --> MOTOR
  MOTOR --> DADOS
  PPP --> DADOS
  FON --> PPP
  LEG -.->|"foto mensal"| PPP
  LEG -.->|"consulta online (opcional)"| MOTOR
  CAD --> PPP
  IAM --> SF
  IAM --> GW
  CTM --> PPP
  CTM --> MOTOR
```

**Atores e sistemas externos**

| Ator / sistema | Papel no MPC | Interface |
|---|---|---|
| Gerente comercial / Cash | Simula preço, contrata sem alçada no sugerido, pede aprovação abaixo dele (C1) | sf-calculadora |
| Equipe de Precificação | Mantém catálogo, tiers, clusters, percentis, premissas; publica versões de parâmetro e da BRP Cash; planeja ondas (M1, M2, C2) | sf-parametrizacao, sf-reprecificacao |
| Aprovador de alçada | Aprova/recusa pedidos de preço abaixo do sugerido (C1.3, C2.4) | sf-calculadora (fila de aprovação) |
| Outros canais e integradores | Consomem as mesmas APIs de preço (RF-07) | apigw-axway via Akamai |
| Legado de tarifas e contratos | Fonte do preço vigente e do histórico (RF-04); alvo da efetivação em C2 (decisão pendente) | Foto via Databricks (premissa `00-doc-negocio.md:L29`) e/ou consulta online via svc-legado-adapter |
| Cadastro de cliente e grupo econômico | Segmento, CNPJ → grupo, região | Bases no Databricks (Conformist) |
| Fontes analíticas | Bases de movimento, eventos tarifados, IF/DAV, ROB, share (`00-etapas:L5-18`) | Tabelas no Databricks (governança RNF-06) |
| Identidade e acesso | Perfis de usuário, papéis de alçada (RF-10) | SSO Salesforce; OAuth2 no Axway |
| Control-M | Disparo e monitoração dos jobs (dbx-ppp, job de reciprocidade, cálculo em lote) | API de Jobs do Databricks; endpoints internos |

---

## 4. Visão de contêineres TO-BE (C4 nível 2)

```mermaid
flowchart TB
  subgraph CANAIS["Canais"]
    SFC["sf-calculadora<br/>LWC Salesforce FSC"]
    SFP["sf-parametrizacao<br/>LWC Salesforce FSC"]
    SFR["sf-reprecificacao<br/>LWC [EVOLUÇÃO]"]
    OUTC["Outros canais / integradores"]
  end

  subgraph BORDA["Borda"]
    AKA["akamai<br/>porta de entrada externa"]
    APPGW["appgw-azure<br/>Application Gateway / WAF / LB"]
    AXW["apigw-axway<br/>API Gateway: OAuth2, quotas, versionamento"]
  end

  subgraph ARO["Plataforma ARO (OpenShift) — microsserviços Java Spring Boot"]
    PR["svc-pricing<br/>Cálculo de Preço"]
    AL["svc-alcada<br/>Alçada e Aprovação"]
    PA["svc-parametros<br/>Parametrização"]
    PU["svc-publicacao<br/>Catálogo e ativação de versões da BRP"]
    LA["svc-legado-adapter<br/>Adaptador de Legado (ACL)"]
    RC["svc-reciprocidade<br/>[EVOLUÇÃO]"]
    RP["svc-reprecificacao<br/>[EVOLUÇÃO]"]
  end

  subgraph DADOS["Dados de serviço"]
    SQL[("sql-motor<br/>Azure SQL Database")]
  end

  subgraph MSG["Mensageria"]
    SB["sb-eventos<br/>Azure Service Bus (tópicos)<br/>fallback: outbox"]
  end

  subgraph DBX["Plataforma analítica — Databricks"]
    PPP["dbx-ppp<br/>Databricks Workflows (PySpark)"]
    BRP[("dbx-brp<br/>Delta: BRP Cash por anomes")]
    FON[("Fontes: movimento, eventos tarifados,<br/>IF/DAV, ROB, share, segmentos")]
  end

  subgraph LEG["Legado"]
    TAR["Sistema de tarifas e contratos"]
    CADS["Cadastro / grupo econômico"]
  end

  subgraph ORQ["Orquestração"]
    CTM["controlm"]
  end

  SFC & SFP & SFR -->|"Named Credential / HTTPS"| APPGW
  OUTC --> AKA --> APPGW --> AXW
  AXW --> PR & AL & PA & PU & RC & RP
  PR --> AL
  PR --> LA
  PR --> SQL
  AL --> SQL
  PA --> SQL
  PU --> SQL
  RC --> SQL
  RP --> SQL
  RP --> PR
  RP --> AL
  LA --> SQL
  LA -.->|"consulta online (opcional)"| TAR
  FON --> PPP --> BRP
  TAR -.->|"foto vigente/histórico"| FON
  CADS --> FON
  BRP -->|"reverse ETL JDBC (staging)"| SQL
  PPP -->|"notifica versão pronta"| PU
  PA & PU & RC & AL -->|"eventos"| SB
  RP & RC & SFC -.->|"consome"| SB
  CTM --> PPP
  CTM --> RC
  CTM --> RP

  style SFR stroke-dasharray: 5 5
  style RC stroke-dasharray: 5 5
  style RP stroke-dasharray: 5 5
```

### 4.1 Descrição dos contêineres

| Contêiner | Responsabilidade | Tecnologia | Dados | Interfaces | Escala / disponibilidade |
|---|---|---|---|---|---|
| **sf-calculadora** | Jornada do gerente: buscar cliente/produto, informar volumetria, receber praticado/alvo/sugerido, cenários, uplift; contratar sem alçada ou abrir pedido de aprovação; exibir preço vigente e histórico 12 meses | Salesforce FSC, LWC, Apex apenas como proxy HTTP (Named Credential) | Não persiste preço; guarda referência à cotação (`cotacao_id`) na oportunidade | Consome APIs de svc-pricing, svc-alcada, svc-legado-adapter via Axway | Salesforce SaaS |
| **sf-parametrizacao** | Telas de manutenção de catálogo, tiers, clusters, percentis, premissas, exceções; fluxo rascunho → staging → publicado; agendamento de vigência; simulação em staging | Salesforce FSC, LWC | Nenhum (leitura/escrita via API) | svc-parametros, svc-publicacao, svc-pricing (modo staging) | Salesforce SaaS |
| **sf-reprecificacao [EVOLUÇÃO]** | Planejamento da onda, lista de elegíveis, revisão de preços propostos, aprovação, acompanhamento | Salesforce FSC, LWC | Nenhum | svc-reprecificacao, svc-alcada | Salesforce SaaS |
| **akamai** | Porta de entrada de canais externos: TLS, proteção DDoS, roteamento geográfico | Akamai (existente) | — | HTTPS → appgw-azure | Serviço gerenciado |
| **appgw-azure** | Balanceamento L7, WAF, terminação TLS interna, roteamento para o Axway | Azure Application Gateway (existente) | — | HTTPS → apigw-axway | Zona-redundante |
| **apigw-axway** | Exposição das APIs do motor: OAuth2 client credentials / JWT, quotas, versionamento de contrato (`/v1`), logs de acesso | Axway API Gateway (existente) | Políticas, chaves de cliente | REST/JSON → serviços no ARO | Cluster existente |
| **aro** | Plataforma de execução dos microsserviços: deploy, autoescala (HPA), health checks, secrets, observabilidade padrão | Azure Red Hat OpenShift | — | — | Múltiplas réplicas por serviço, mín. 2 por zona |
| **svc-pricing** | Núcleo C1: dado cliente + produto + volumetria + contexto, classifica tier e cluster, consulta o cenário na MPA (lookup: alvo, sugerido, percentis, cenários vizinhos), calcula uplift por cenário (única conta online) e devolve praticado/alvo/sugerido, cenários e indicação de alçada; grava cotação com versões usadas. Não calcula o sugerido (revisão 1.1) | Java 21, Spring Boot, cache Caffeine (AD-11) | Lê sql-motor (BRP ativa, parâmetros vigentes); escreve `cotacao` | REST `/precos/*`; chama svc-alcada e svc-legado-adapter | Stateless, 3+ réplicas, p95 ≤ 300 ms no serviço e ≤ 500 ms no Axway (RNF-02) |
| **svc-alcada** | Calcula nível de alçada e papel aprovador a partir de desvio (% e R$) e `politica_alcada`; registra pedidos e decisões de aprovação | Java, Spring Boot | `politica_alcada`, `pedido_aprovacao` | REST `/alcadas/*`; publica `PrecoAprovado` | Stateless, 2+ réplicas |
| **svc-parametros** | Versões de parâmetros: rascunho, staging, aprovação, publicação imediata/agendada, vigência; trilha de auditoria; resolução do "conjunto vigente" numa data | Java, Spring Boot | `parametro_versao`, `parametro_item_*`, `auditoria` | REST `/parametros/*`; publica `VersaoParametroPublicada` | Stateless, 2 réplicas |
| **svc-publicacao** | Catálogo de versões da BRP Cash; validação pós-carga; ativação atômica por `anomes`; rollback; notifica canais | Java, Spring Boot | `versao_brp` e procedures de swap | REST `/brp/*`; chamado por dbx-ppp ao fim do reverse ETL; publica `VersaoBrpPublicada` | 2 réplicas |
| **svc-legado-adapter** | Anti-corruption layer: preço vigente e histórico 12 meses; estratégia foto (sql-motor) ou online (sistema de tarifas), com fallback e carimbo de origem/data | Java, Spring Boot | `preco_vigente_foto`, `historico_preco` (carregados pelo Databricks) | REST interno `/legado/*`; conector ao sistema de tarifas (a definir: MQ, REST ou DB link) | 2+ réplicas; circuit breaker para o legado |
| **svc-reciprocidade [EVOLUÇÃO]** | Registro do acordo, comparação acordado x realizado (indicadores da BRP), detecção de desvio, elegibilidade, alertas | Java, Spring Boot + job Control-M | `acordo_reciprocidade`, `desvio_reciprocidade` | REST `/reciprocidade/*`; publica `DesvioReciprocidadeDetectado`, `ClienteElegivelParaReprecificacao` | 2 réplicas; job diário/mensal |
| **svc-reprecificacao [EVOLUÇÃO]** | Onda: escopo, elegíveis, cálculo em lote via svc-pricing, aprovação via svc-alcada, efetivação (pendente), acompanhamento | Java, Spring Boot + job em lote | `onda_reprecificacao`, `onda_cliente_produto` | REST `/reprecificacao/*`; consome eventos de C3 | 2 réplicas; lote com paralelismo controlado |
| **sql-motor** | Base de serviço relacional: BRP Cash ativa e anterior, parâmetros, alçada, cotações, auditoria | Azure SQL Database, zona-redundante, réplica de leitura (AD-02, AD-13) | Modelo da §6 | JDBC (serviços e Databricks) | Business Critical ou Hyperscale conforme volume (a dimensionar na F0) |
| **sb-eventos** | Tópicos de eventos de domínio entre contextos; desacoplamento temporal C3 → C2 e notificações a canais | Azure Service Bus (validar, AD-09); fallback outbox + polling | Mensagens transientes | AMQP/JMS | Serviço gerenciado |
| **dbx-ppp** | Pipeline de Preparação de Preços: portes dos 7 notebooks, validações, geração da BRP por `anomes`, reverse ETL | Databricks Workflows, PySpark, Delta Live Tables opcional | Bronze/silver/gold | Jobs API (Control-M), JDBC → sql-motor, REST → svc-publicacao | Cluster de job, execução mensal / sob demanda |
| **dbx-brp** | Tabelas Delta gold da BRP Cash, particionadas por `anomes`, com time travel e histórico completo | Delta Lake / Unity Catalog | MPA (Matriz de Cenários de Preço: alvo, sugerido e percentis por cenário), PPC (com alvo e sugerido do cenário do cliente), Matriz de Relacionamento, Indicadores de Reciprocidade, foto de preço vigente/histórico | SQL/Delta Sharing para analistas; JDBC para reverse ETL | Gerenciado |
| **controlm** | Disparo corporativo dos jobs (dbx-ppp, reciprocidade, lote de reprecificação), dependências, alertas operacionais | Control-M (IBM/BMC, existente) | Definições de jobs | Databricks Jobs API; HTTP para endpoints de lote | Existente |

---

## 5. Arquitetura por capacidade e fluxo

### 5.1 Preparação de dados (M2) — dbx-ppp e dbx-brp

**Decisão**: AD-01 (Databricks Workflows), AD-03 (reverse ETL por staging + ativação atômica). Atende RF-08, RF-13, RNF-06, RNF-09.

```mermaid
flowchart LR
  subgraph BRONZE["Bronze (fontes governadas)"]
    B1[("movimento_*<br/>eventos_tarifados_*")]
    B2[("segmentos, rob, saldo_if, saldo_dav,<br/>share_boletos, cashxcred, regionalidade")]
    B3[("poder_publico, associacoes_religiosas,<br/>listas de exceção (Databricks ou svc-parametros)")]
    B4[("foto tarifas legado<br/>vigente + 12 meses")]
  end
  subgraph WF["dbx-ppp — Databricks Workflow 'ppp_ciclo_{anomes}'"]
    T0["T0 validar_fontes<br/>contratos de dados, janelas, nulos"]
    T1["T1 base_cobranca<br/>(nb 01) → emissões L3M"]
    T2["T2 uplift_cobranca (nb 02)"]
    T3["T3 multipag (nb 03)"]
    T4["T4 pix (nb 04)"]
    T5["T5 arrecadacao (nb 05)"]
    T6["T6 uplift_consolidado (nb 06)<br/>MPA (alvo + sugerido por cenário) + PPC"]
    T7["T7 stickiness_impacto (nb 07)<br/>Matriz de Relacionamento + Indicadores"]
    T8["T8 foto_legado<br/>preço vigente + histórico"]
    T9["T9 validar_brp<br/>RF-08: N mínimo, faixas, cobertura de cluster"]
    T10["T10 reverse_etl<br/>JDBC → staging sql-motor"]
    T11["T11 solicitar_ativacao<br/>POST /brp/versoes/{anomes}/validar"]
  end
  subgraph GOLD["dbx-brp — Delta gold, partição anomes"]
    G1[("brp.matriz_cenarios_preco<br/>(antes matriz_preco_alvo_cluster)")]
    G2[("brp.posicao_preco_cliente_produto")]
    G3[("brp.matriz_relacionamento")]
    G4[("brp.indicadores_reciprocidade")]
    G5[("brp.preco_vigente_foto / historico_preco")]
    G6[("brp.qualidade_ciclo (métricas e alertas)")]
  end
  SQL[("sql-motor<br/>stg_* → ativação")]
  PU["svc-publicacao"]
  CTM["controlm"]

  CTM -->|"Jobs API run-now"| T0
  B1 & B2 & B3 --> T0
  T0 --> T1 & T3 & T4 & T5 & T7
  T1 --> T2
  T2 & T3 & T4 & T5 --> T6
  B4 --> T8
  T6 --> G1 & G2
  T7 --> G3 & G4
  T8 --> G5
  G1 & G2 & G3 & G4 & G5 --> T9 --> G6
  T9 --> T10 --> SQL
  T10 --> T11 --> PU
```

**Mapeamento notebook → tarefa do workflow**

| Notebook atual | Tarefa | Saída Delta (gold) | Observações de porte |
|---|---|---|---|
| Extração SQL/Databricks (`00-etapas`) | T0 `validar_fontes` | `brp.qualidade_ciclo` | Deixa de exportar CSV; lê tabelas governadas; aplica contratos de dados (schema, janela, volume mínimo) |
| 01_Base_cobranca | T1 `base_cobranca` | `silver.cobranca_l3m`, `brp.indicadores_reciprocidade` (emissões L3M) | Janela L3M parametrizada |
| 02_Uplift_cobranca | T2 `uplift_cobranca` | `silver.cobranca_vats` | 13 modalidades como parâmetro, não laço fixo |
| 03_Multipag | T3 `multipag` | `silver.multipag_vats` | Ordenação cronológica antes de "última tarifa" (risco apontado em A1) |
| 04_Pix | T4 `pix` | `silver.pix_vats` | Lista CD_TARF como parâmetro |
| 05_Arrecadacao | T5 `arrecadacao` | `silver.arrecadacao_vats` | Regra de cluster divergente: registrar como parâmetro por produto (lacuna 5) |
| 06_Uplift_consolidado | T6 `uplift_consolidado` | `brp.matriz_cenarios_preco` (MPA; antes `matriz_preco_alvo_cluster`), `brp.posicao_preco_cliente_produto` (PPC) | Esqueleto produto x tier x segmento x região gerado a partir do catálogo em svc-parametros; grava `preco_alvo` por cenário (hoje `SIMUL_PRC_ALVO_CLUSTER`) e, na PPC, o `cenario_id` e o `preco_sugerido` do cenário do cliente |
| Aba "Preço por Produto"/"Tabela de Preços" (macro) → `SIMUL_PRECO_POR_PRODUTO` | T6 `uplift_consolidado`, etapa T6b `preco_sugerido_cenario` (nova; SPEC-PPP-13 no doc 08) | coluna `preco_sugerido` em `brp.matriz_cenarios_preco` e em `brp.posicao_preco_cliente_produto` | Origem do sugerido no AS-IS. A regra que deriva o sugerido do alvo por cenário (premissas de desconto, custos, RFP, nichos) é a lacuna 1: o que for regra de dado vira parâmetro em svc-parametros; o que for cálculo vira etapa do pipeline. Nada disso vira estratégia do svc-pricing (revisão 1.1) |
| 07_Matriz de Stickiness vs Impacto | T7 `stickiness_impacto` | `brp.matriz_relacionamento`, `brp.indicadores_reciprocidade` (saldo IF/DAV, SoW) | Limiares por segmento como parâmetro |
| (novo) | T8 `foto_legado` | `brp.preco_vigente_foto`, `brp.historico_preco` | Premissa `00-doc-negocio.md:L29` |
| (novo) | T9 `validar_brp` | `brp.qualidade_ciclo` | Bloqueia reverse ETL se falhar; alerta via Control-M/observabilidade (RF-08) |
| (novo) | T10 `reverse_etl`, T11 `solicitar_ativacao` | tabelas `stg_*` no sql-motor | AD-03 |
| Macro "Resumo por GE" (Saída 1, reprecificação manual) | **não portada** | — | Substituída por C2 [EVOLUÇÃO] e por relatórios sobre o Delta; regras a levantar na F0 junto com a lacuna 1 |

**Parâmetros de entrada do workflow**: `anomes`, `versao_parametros` (lida de svc-parametros para tiers, clusters, percentis, janelas e listas), `modo` (`completo` | `reprocessar_produto`). Todas as datas hard-coded (`202506`, `2026-03..05`) passam a ser derivadas de `anomes` e das janelas parametrizadas (lacuna 6).

**Camadas Delta**: bronze = tabelas de origem governadas (não copiadas); silver = bases por produto normalizadas e enriquecidas (`*_vats`); gold = entidades da BRP Cash, particionadas por `anomes`, com Unity Catalog para lineage e controle de acesso. Time travel do Delta preserva a base histórica de todos os ciclos (M3).

**Validações de qualidade (RF-08)**, executadas em T0 e T9, com resultado persistido em `brp.qualidade_ciclo` e replicado em `sql-motor.versao_brp.resumo_qualidade`:

- Contratos de dados: schema, tipos, chaves, volume dentro de ±X% do ciclo anterior.
- Cobertura: toda combinação produto x tier x segmento x região do esqueleto tem cluster e percentil (hoje há combinações sem cluster, lacuna 5).
- Representatividade: N ≥ 15 por cluster; clusters abaixo sinalizados.
- Sanidade de preço: P25 ≤ P75 ≤ P90; preço-alvo ≥ tarifa praticada (política "nunca reduzir"); `preco_sugerido` preenchido em todo cenário da MPA e coerente com o alvo do mesmo cenário (relação a confirmar na lacuna 1); na PPC, `preco_sugerido` ≥ tarifa praticada; variação de preço-alvo e de preço-sugerido x ciclo anterior acima de limiar gera alerta.
- Integridade da foto do legado: cobertura de clientes com produto ativo.

Falha em regra bloqueante impede T10; alerta não bloqueante segue, mas fica visível na tela de ativação (svc-publicacao) para decisão humana.

**Reverse ETL e ativação (AD-03)**

1. T10 escreve via JDBC nas tabelas `stg_<entidade>` do sql-motor, truncadas por `anomes`, com lotes de 50-100 mil linhas. Volumes esperados: MPA com poucos milhares de linhas; PPC com dezenas a centenas de milhares (grupo x produto); indicadores na mesma ordem. É volume pequeno para JDBC.
2. T11 chama `POST /brp/versoes/{anomes}/validar`; svc-publicacao confere contagens (`stg_*` x métricas informadas pelo Databricks), executa checks relacionais e marca a versão como `validada`.
3. A ativação (`POST /brp/versoes/{anomes}/ativar`) é uma procedure que, numa transação, atualiza `versao_brp.status` e faz `ALTER TABLE ... SWITCH PARTITION` (ou renomeação de tabelas por versão) para tornar o `anomes` corrente, mantendo a versão anterior íntegra. svc-pricing lê sempre pela view `v_brp_ativa`, que resolve o `anomes` ativo; o cache é invalidado por evento `VersaoBrpPublicada`.
4. Rollback = reativar o `anomes` anterior pela mesma procedure. Nunca há delete de versões; expurgo é política separada (12+ ciclos online).

**Papel do Control-M**: disparar o workflow via Databricks Jobs API no calendário do ciclo (mensal; o preço por produto semestral entra como insumo da etapa `preco_sugerido_cenario`, via parâmetro versionado em svc-parametros ou tabela semestral da BRP, decisão da F0 ligada a D7), monitorar o status, aplicar dependências com cargas de origem, e alertar a operação. O Control-M **não** orquestra tarefas dentro do workflow; isso fica no Databricks, que já tem retry, lineage e logs por tarefa. Se a governança do banco não exigir Control-M, o agendamento nativo do Databricks é suficiente.

**Avaliação crítica — Databricks Workflows x microsserviços Python schedulados por Control-M (AD-01)**

| Critério | Databricks Workflows (escolha) | Microsserviços Python no ARO + Control-M |
|---|---|---|
| Localização dos dados | As bases de origem já estão no Databricks (`00-doc-negocio.md:L27`, `L30`). Processamento acontece onde o dado está. | Exige extrair dezenas de milhões de linhas (movimento 12 meses x 5 produtos) para fora do lake a cada ciclo. |
| Como extrair se fosse Python | Não se aplica. | Três formas: (a) JDBC/ODBC contra SQL Warehouse — pagina resultados, lento para volumes de movimento, ocupa warehouse; (b) Delta Sharing — mais elegante, leitura de arquivos Parquet por protocolo aberto, mas ainda copia o dado e exige governança de shares; (c) exportação para storage (ADLS) e leitura com Pandas/Polars no pod — reintroduz arquivos intermediários (o problema da pasta `entradas`). Todas duplicam dado e governança. |
| Esforço de porte | Notebooks já são Python/Pandas; porte para PySpark é incremental, tarefa a tarefa; pode-se rodar Pandas API on Spark no início. | Reescrever como serviços, empacotar, tratar memória de pods para DataFrames de milhões de linhas (Pandas não distribui). |
| Versionamento e reprodutibilidade | Delta time travel, Unity Catalog lineage, `anomes` como partição. | Teria de ser construído (tabelas de versão, storage de saídas). |
| Qualidade de dados | Expectations nativas (DLT) ou Great Expectations no cluster. | Implementável, mas sem lineage. |
| Orquestração | Workflows com dependências, retry, alertas; Control-M dispara. | Control-M orquestra N jobs; dependência entre serviços via filas ou arquivos. |
| Escalabilidade | Cluster elástico por execução. | Pods com limite de memória; paralelismo manual. |
| Custo | DBU de cluster de job por execução mensal (baixo). | Custo de ARO é fixo; custo de engenharia é muito maior. |
| Skills | Time de precificação já usa Python/Pandas; analistas conseguem ler PySpark. | Time de engenharia Java/Python de backend; distancia o negócio do modelo. |
| Quando Python/Control-M faria sentido | — | Se as bases **não** estivessem no Databricks, ou se houvesse regra de latência (processamento intradiário por cliente) que Spark não atende bem. Nenhum dos dois é o caso. |

Conclusão: Databricks Workflows é a escolha por localidade do dado, versionamento nativo e menor esforço de porte. O caminho Python/Control-M é "mais elegante" apenas na aparência de microsserviços; na prática recria o problema de arquivos intermediários que o AS-IS já tem. Registra-se como alternativa: **Azure Data Factory** para o reverse ETL (equivalente, se for padrão da área de dados).

### 5.2 Consumo online de preços (C1) — svc-pricing

**Decisões**: AD-02 (Azure SQL), AD-04 (Java no ARO), AD-05 (Salesforce como canal), AD-10 (Adaptador), AD-11 (cache). Atende RF-01, RF-02, RF-03, RF-04, RF-07, RF-09, RNF-02, RNF-09.

```mermaid
sequenceDiagram
  autonumber
  actor G as Gerente
  participant SF as sf-calculadora (LWC)
  participant NC as Named Credential / Apex proxy
  participant GW as appgw-azure → apigw-axway
  participant PR as svc-pricing
  participant DB as sql-motor
  participant AL as svc-alcada
  participant LA as svc-legado-adapter
  participant TAR as Legado tarifas

  G->>SF: seleciona cliente, produto, volumetria, preço negociado
  SF->>NC: chamada LWC → Apex (sem regra)
  NC->>GW: POST /mpc/v1/precos/simulacoes (OAuth2 client credentials + JWT do usuário)
  GW->>PR: roteia, valida token, aplica quota
  PR->>DB: lê v_brp_ativa (MPA: cenários com alvo, sugerido e percentis, PPC), parâmetros vigentes (cache Caffeine)
  PR->>LA: GET /legado/precos/{grupo}/{produto}/vigente?estrategia=auto
  alt estratégia foto
    LA->>DB: preco_vigente_foto (anomes ativo)
  else estratégia online
    LA->>TAR: consulta tarifa contratada
    TAR-->>LA: tarifa + data
  end
  LA-->>PR: praticado, origem, carimbo de data
  PR->>PR: tier → cluster → lookup do cenário na MPA (alvo, sugerido, percentis) → cenários vizinhos (tier ±1) → uplift por cenário
  PR->>AL: POST /alcadas/avaliacoes (produto, segmento, desvio %, R$)
  AL-->>PR: nivel_alcada, papel_aprovador (ou "sem alçada")
  PR->>DB: INSERT cotacao (entrada, saída, versao_brp, versao_parametros, origem_praticado)
  PR-->>GW: 200 {praticado, alvo, sugerido{valor, cenario_id}, cenarios[], uplift, alcada, cotacao_id, versoes}
  GW-->>SF: resposta
  SF-->>G: exibe preços, cenários e alçada, com ações contratar ou pedir aprovação
```

**Lógica do svc-pricing** (estratégias em código, valores em parâmetros):

1. **Resolução de contexto**: grupo econômico, segmento e região (PPC/cadastro); catálogo do produto (macroproduto, grupo de regra de cluster, quem paga).
2. **Tier**: faixas de `parametro_item_tier` para o produto na versão vigente; volumetria informada ou a da PPC (média mensal / anual conforme produto).
3. **Cluster**: `parametro_item_regra_cluster` (grupo de regra, tier, segmento, região). Arrecadação usa regra sem região (lacuna 5, tratada como parâmetro por produto).
4. **Lookup do cenário (revisão 1.1)**: consulta `matriz_cenarios_preco` (via `v_brp_ativa`) para (produto, tier, segmento, região) e obtém `cenario_id`, cluster, percentis, `preco_alvo` e `preco_sugerido`, todos pré-computados pelo pipeline. Nenhuma fórmula de preço roda aqui.
5. **Preço alvo e sugerido**: alvo = max(praticado, `preco_alvo` do cenário), aplicando a política "nunca reduzir" com o praticado fresco do Adaptador; sugerido = `preco_sugerido` do cenário, sem transformação; o motor só valida sugerido ≥ praticado e sinaliza inconsistência da BRP quando violado. As regras que derivam o sugerido (premissas de desconto por saldo IF/DAV, exceções, piso de custo) são do pipeline/parametrização e vêm da engenharia reversa da macro (F0, lacuna 1), não deste serviço.
6. **Cenários**: percentis P25..P90 do cenário como faixas; sensibilidade a tier lendo os cenários vizinhos (tier ±1) na mesma MPA, sem recálculo; uplift anual por cenário (única conta online) com as mesmas fórmulas do pipeline: (preço − praticado) x volume anual se praticado < 1.000, senão (preço / praticado − 1) x receita anual.
7. **Alçada**: delega ao svc-alcada com o desvio entre negociado e sugerido.
8. **Persistência**: toda simulação vira `cotacao` com `versao_brp`, `versao_parametros`, `origem_praticado` e hash da entrada (RNF-09, RF-09). A resposta traz esses identificadores; o canal os guarda na oportunidade.

**Cache (AD-11)**: Caffeine por instância para (a) conjunto de parâmetros vigentes por versão, (b) MPA inteira (pequena), (c) catálogo. TTL curto (5 min) mais invalidação por evento `VersaoBrpPublicada` / `VersaoParametroPublicada` (assinatura em sb-eventos ou polling de `versao_*` a cada 60 s no fallback). PPC e indicadores não são cacheados (consulta pontual por grupo, índice por chave). Redis só se a latência exigir (não está na stack).

**Versionamento da resposta (RNF-09)**: cabeçalhos `X-Versao-BRP`, `X-Versao-Parametros`, `X-Versao-API` e corpo com `versoes{}`. Um preço é reproduzível reexecutando a mesma entrada com as mesmas versões (endpoint `POST /precos/simulacoes` aceita `versoes` explícitas para auditoria).

**Contingência (AD-13, RNF-01)**: sql-motor zona-redundante com réplica de leitura; svc-pricing com 3+ réplicas em zonas distintas; se o Adaptador falhar no modo online, cai para foto com carimbo; se o motor inteiro estiver indisponível, o Salesforce exibe a **última cotação conhecida** para aquele cliente/produto com data, e bloqueia contratação sem alçada até nova cotação válida (regra de negócio a confirmar). Metas (Revisão 1.2): SLA de 99,5% e SLO interno de 99,9% em horário comercial; RTO ≤ 30 min com esse modo degradado ativo; RPO = 0 para `cotacao` e `auditoria`.

**Avaliação crítica — Alternativa 2: FICO (Blaze/Decision Modeler) + MongoDB (AD-02, AD-04)**

| Critério | Java Spring Boot + Azure SQL (escolha) | FICO + MongoDB |
|---|---|---|
| Natureza das regras | Tabelas de faixas (tier, regra de cluster, alçada por desvio) e lookup de cenários pré-computados na MPA (alvo, sugerido, percentis). O motor não é engine de fórmulas de desconto (revisão 1.1): cabem em parametrização de dados + poucas estratégias de classificação. | FICO brilha quando negócio precisa editar **lógica** (árvores de decisão, scorecards, regras encadeadas) sem TI. Aqui a lógica é estável e os dados variam. |
| Modelo de dados | Matrizes por chave composta, joins com vigências e versões, auditoria relacional. | MongoDB acomoda documentos, mas MPA/PPC/parâmetros são tabulares; joins e integridade de versão ficariam na aplicação. Sem vantagem. |
| Stack corporativa (RNF-10) | Java, Azure SQL, ARO estão na stack. | FICO e MongoDB não constam da stack; novo fornecedor, novo contrato, nova operação. |
| Custo | Licenças já existentes (Azure SQL como serviço). | Licença FICO alta (por decisão/por core), MongoDB Atlas ou Enterprise adicional. |
| Skills | Java e SQL abundantes no banco. | Skill FICO escasso; dependência de consultoria. |
| Lock-in | Baixo; regras em tabelas exportáveis. | Alto; regras no repositório FICO, formato proprietário. |
| Staging/vigência/auditoria (RF-06, RF-09) | Construído no svc-parametros; controle total. | FICO tem versionamento de regras nativo (ponto forte real), mas auditoria de dados de parâmetro continuaria fora. |
| Desempenho | Consulta indexada + cache; p95 ≤ 300 ms no serviço e ≤ 500 ms no Axway viável. | FICO adiciona um salto de rede e licença por chamada; MongoDB rápido para leitura por chave. |
| Quando FICO faria sentido | — | Se em C2 a gradação do reajuste virar política complexa editada semanalmente pelo negócio (dezenas de regras encadeadas por segmento, com simulação what-if de política). Reavaliar na F3 com evidência (roadmap F5). |
| Quando MongoDB faria sentido | — | Histórico de cotações append-only com payload JSON grande e alto volume; hoje cabe em Azure SQL com coluna JSON e partição por mês. Reavaliar por volume. |

Conclusão: Java + Azure SQL. Com o sugerido lido da BRP, o svc-pricing se reduz a classificação, lookup, uplift e alçada, o que reforça a escolha por tabelas em vez de engine. A arquitetura protege a opção FICO isolando a decisão de alçada em svc-alcada e a gradação de C2 em estratégia do svc-reprecificacao; se um dia houver engine, ele entra atrás dessas interfaces.

### 5.3 Parametrização (M1) — svc-parametros e sf-parametrizacao

**Decisão**: AD-06. Atende RF-05, RF-06, RF-09, RF-10, RNF-07, RNF-09.

```mermaid
stateDiagram-v2
  [*] --> Rascunho: criar versão (clonar vigente)
  Rascunho --> Rascunho: editar itens
  Rascunho --> Staging: enviar para staging
  Staging --> Rascunho: reprovar / ajustar
  Staging --> Aprovada: aprovação por perfil (RF-10)
  Aprovada --> Publicada: publicar imediata
  Aprovada --> Agendada: agendar vigência
  Agendada --> Publicada: data de vigência atingida (scheduler)
  Agendada --> Aprovada: cancelar agendamento
  Publicada --> Encerrada: nova versão publicada
  Publicada --> Revertida: rollback (reativa anterior)
  Encerrada --> [*]
```

**Modelo**: `parametro_versao` (id, descrição, status, vigência início/fim, autor, aprovador, versão-base) agrupa **itens por tipo** em tabelas dedicadas (catálogo de produtos, domínios, tier, regra de cluster, percentis, desconto, alçada, remuneração, exceções, janelas). Cada item carrega `versao_id`; consulta do "conjunto vigente em D" resolve a versão publicada com vigência ≤ D mais recente. Versões são imutáveis após publicação (alterar = nova versão). Escopo de versão pode ser **global** ou **por produto**, para que o semestral de preço por produto não force republicar tiers de todos os produtos (D7).

**Staging (RF-06) é lógico, não um ambiente físico**: o mesmo svc-pricing em produção calcula com uma versão candidata quando recebe o cabeçalho `X-Versao-Parametros-Candidata: <id>` (ou `X-Versao-BRP-Candidata: <anomes>`), permitido apenas a perfis de Precificação e marcado na cotação como `modo=staging` (não contratável, não gera pedido de alçada). Assim a tela de parametrização oferece "simular em staging" contra dados reais de produção sem duplicar infraestrutura, e a comparação "vigente x candidata" para uma carteira de clientes-teste vira relatório automático. Vantagens: sem divergência de código/dados entre ambientes; a validação é sobre o que vai realmente ao ar. Salvaguarda: a versão candidata só é lida do cache com chave separada e nunca substitui a vigente.

**Aprovação com perfis (RF-10)**: papéis `precificacao.editor` (cria rascunho, envia a staging), `precificacao.aprovador` (aprova), `precificacao.publicador` (publica/agenda), `precificacao.leitor`. Perfis vêm do AD corporativo via Salesforce e trafegam no JWT; o Axway valida assinatura, o svc-parametros aplica autorização por operação. Segregação: editor não aprova a própria versão.

**Auditoria (RF-09, RNF-03)**: tabela `auditoria` append-only (quem, quando, o quê, antes/depois em JSON, versão, origem da chamada), sem UPDATE/DELETE por permissão de banco; exportação periódica para o Databricks para retenção longa e análise.

### 5.4 Legado e base histórica (M3) — svc-legado-adapter

**Decisão**: AD-10, AD-14. Atende RF-04, RNF-01, RNF-08.

```mermaid
flowchart LR
  PR["svc-pricing"] --> LA["svc-legado-adapter<br/>estratégias: foto | online | auto"]
  LA -->|"foto (padrão)"| SQL[("sql-motor<br/>preco_vigente_foto, historico_preco<br/>por anomes")]
  LA -.->|"online (quando canal exigir)"| TAR["Sistema de tarifas / contratos"]
  TARF["Foto mensal do legado<br/>(vigente + 12 meses)"] --> DBX["dbx-ppp T8 foto_legado"] --> BRP[("dbx-brp<br/>historico_preco")] -->|"reverse ETL"| SQL
  TAR --> TARF
  LA -->|"resposta com origem e carimbo"| PR
  subgraph DESLIGAR["A desligar (F2)"]
    PL["Planilha Ano 1"]
    SAS["SAS SIMUL_*"]
    S010["Motor da Calculadora SQL 010"]
  end
  style DESLIGAR stroke-dasharray: 5 5,stroke:#c0392b
```

**Estratégias do Adaptador**

| Estratégia | Fonte | Latência | Frescor | Uso |
|---|---|---|---|---|
| `foto` | `preco_vigente_foto` / `historico_preco` no sql-motor, carregados pelo Databricks a cada ciclo (premissa `00-doc-negocio.md:L29`) | < 20 ms | Até 1 mês | Padrão da Calculadora e de cenários |
| `online` | Sistema de tarifas via conector (REST, MQ ou DB link; a definir com o dono do legado) | Dependente do legado | Tempo real | Quando o canal pedir "informação mais atualizada" (`L16`) ou quando existir negociação recente |
| `auto` | Tenta `online` com timeout curto (ex. 300 ms) e circuit breaker; cai para `foto` com carimbo | Limitada | Melhor esforço | Recomendação inicial; decisão de latência aceitável é do negócio (lacuna 7, risco R4) |

A resposta sempre traz `origem` e `data_referencia`, para que o canal mostre "vigente em 31/08/2026 (foto)" ou "vigente agora (online)".

**Preservação da base histórica**: (a) todas as versões da BRP Cash ficam no Delta (`dbx-brp`) com time travel e nas tabelas versionadas do sql-motor (N versões online, demais no lake); (b) `historico_preco` por grupo x produto x mês, 12 meses rolantes no sql-motor e completo no Delta; (c) `cotacao` guarda todas as simulações com versões; (d) as tabelas SAS `SIMUL_*_AAAAMM` existentes são carregadas uma única vez para o Delta como "ciclos legados" antes do desligamento, garantindo continuidade histórica.

**Plano de desligamento** (por produto, conforme AD-14):

1. F1: motor em shadow; SAS/SQL 010 continuam alimentando a Calculadora.
2. F2, por produto (ordem sugerida: Multipag, PIX, Arrecadação, Cobrança, do mais simples ao mais complexo): quando a comparação automática atingir o critério de corte (§10), a Calculadora passa a consumir o motor para aquele produto; a carga SAS daquele produto é interrompida; SQL 010 mantém apenas produtos restantes.
3. Ao final da F2: descarte da macro; SAS e SQL 010 congelados em modo leitura por um ciclo, depois desativados; planilha vira apenas relatório gerado a partir do Delta, se o negócio ainda quiser o formato.

### 5.5 Gestão de reciprocidade (C3) [EVOLUÇÃO — a detalhar com o negócio]

**Decisão**: AD-07, AD-09. Atende RF-12. Detalhamento de negócio na F3 (risco R2).

```mermaid
flowchart LR
  SFC["sf-calculadora<br/>contratação registra acordo"] -->|"POST /reciprocidade/acordos"| RC["svc-reciprocidade"]
  RC --> SQL[("sql-motor<br/>acordo_reciprocidade<br/>desvio_reciprocidade")]
  CTM["controlm<br/>job periódico"] -->|"POST /reciprocidade/monitoramentos"| RC
  BRP[("sql-motor<br/>indicadores_reciprocidade<br/>(da BRP Cash)")] --> RC
  RC -->|"DesvioReciprocidadeDetectado<br/>ClienteElegivelParaReprecificacao"| SB["sb-eventos"]
  SB -.-> RP["svc-reprecificacao"]
  SB -.-> SFN["Salesforce: alerta/tarefa ao gerente<br/>(Platform Event ou API)"]
  style RC stroke-dasharray: 5 5
  style RP stroke-dasharray: 5 5
  style SFN stroke-dasharray: 5 5
```

- **Acordo**: registrado no momento da contratação/negociação (volumetria acordada por produto, saldo IF/DAV esperado, produtos contratados, vigência, tolerâncias). Vive no sql-motor porque é transacional e precisa de auditoria; hoje não se sabe onde é registrado (lacuna 4).
- **Monitoramento**: job Control-M (mensal após a publicação da BRP, ou diário se indicadores intra-mês existirem) compara acordado x realizado usando `indicadores_reciprocidade` (emissões L3M, saldo IF/DAV, SoW boletos, share de cash). Regras e tolerâncias em `parametro_item_reciprocidade` (svc-parametros).
- **Desvio e elegibilidade**: persistidos e publicados como eventos; C2 consome; Salesforce gera tarefa/alerta ao gerente com o desvio e a ação sugerida (manter desconto, revisar acordo, reprecificar).
- Por que não dentro do Databricks (alternativa rejeitada): o acordo é transacional, precisa de tela e de workflow; o Databricks fornece apenas os indicadores.

### 5.6 Onda de reprecificação (C2) [EVOLUÇÃO — a detalhar com o negócio]

**Decisão**: AD-08, AD-09. Atende RF-11. Efetivação no legado é decisão pendente (lacuna 4).

```mermaid
flowchart TB
  SFR["sf-reprecificacao<br/>planejar onda, revisar, aprovar, acompanhar"] --> RP["svc-reprecificacao"]
  SB["sb-eventos<br/>ClienteElegivelParaReprecificacao"] -.-> RP
  DBX[("dbx-brp<br/>filtros pré-computados:<br/>negociação recente, data de reprecificação,<br/>RFP, nicho, poder público, N mínimo")] -->|"reverse ETL"| SQL[("sql-motor<br/>onda_reprecificacao<br/>onda_cliente_produto")]
  RP --> SQL
  RP -->|"cálculo em lote<br/>POST /precos/simulacoes/lote"| PR["svc-pricing"]
  PR --> RP
  RP -->|"POST /alcadas/avaliacoes"| AL["svc-alcada"]
  AL -->|"PrecoAprovado"| SB
  RP -.->|"efetivação (decisão pendente)"| LA["svc-legado-adapter"] -.-> TAR["Sistema de tarifas"]
  RP --> ACOMP["Acompanhamento: uplift realizado x meta<br/>(BRP ciclo seguinte)"]
  CTM["controlm"] --> RP
  style SFR stroke-dasharray: 5 5
  style RP stroke-dasharray: 5 5
  style LA stroke-dasharray: 5 5
  style TAR stroke-dasharray: 5 5
```

1. **Planejamento**: escopo (produtos, segmentos, regiões), calendário, meta de uplift, gradação (Stickiness x Impacto) como parâmetros da onda.
2. **Elegíveis**: união dos eventos de C3 com filtros pré-computados no Databricks (listas que hoje são abas manuais) e regras adicionais em svc-parametros; resultado versionado em `onda_cliente_produto`.
3. **Cálculo em lote**: svc-reprecificacao chama svc-pricing em lote (endpoint `/lote` assíncrono, processado em fatias com paralelismo controlado e idempotência por `onda_id + grupo + produto`), aplicando a gradação da onda sobre o sugerido. Reuso total do motor: mesma versão de BRP e parâmetros, mesma auditoria.
4. **Aprovação**: por lote/segmento via svc-alcada; comunicação ao gerente via Salesforce.
5. **Efetivação**: se o negócio decidir que o motor efetiva, é via svc-legado-adapter (ACL) com contrato a negociar com o legado; senão, exporta lista aprovada para o processo atual.
6. **Acompanhamento**: no ciclo seguinte, a BRP traz o praticado novo; job calcula uplift realizado x aprovado.

### 5.7 Mensageria e eventos (AD-09)

Azure Service Bus (tópicos + assinaturas) **não consta da stack** (lacuna 9, risco R5). Validar na F0. Enquanto não validado, o padrão **outbox**: cada serviço grava o evento na tabela `evento_outbox` na mesma transação do negócio; um publicador (thread agendada) entrega ao Service Bus quando existir, ou os consumidores fazem polling na outbox via endpoint `GET /eventos?apos=<cursor>`. A interface de domínio é a mesma nos dois casos.

| Tópico | Evento | Produtor | Consumidores | Fase |
|---|---|---|---|---|
| `mpc.publicacao` | `VersaoBrpPublicada {anomes, versao_id, resumo_qualidade}` | svc-publicacao | svc-pricing (invalida cache), svc-reciprocidade, Salesforce (aviso) | F1 |
| `mpc.parametros` | `VersaoParametroPublicada {versao_id, escopo, vigencia}` | svc-parametros | svc-pricing, dbx-ppp (próximo ciclo) | F1 |
| `mpc.alcada` | `PedidoAprovacaoCriado`, `PrecoAprovado`, `PrecoRecusado` | svc-alcada | Salesforce (fila do aprovador), svc-reprecificacao | F1 / F4 |
| `mpc.reciprocidade` | `AcordoRegistrado`, `DesvioReciprocidadeDetectado`, `ClienteElegivelParaReprecificacao` | svc-reciprocidade | svc-reprecificacao, Salesforce (alerta) | F3 |
| `mpc.reprecificacao` | `OndaPlanejada`, `OndaCalculada`, `OndaAprovada`, `OndaEfetivada` | svc-reprecificacao | Salesforce, observabilidade | F4 |

Contratos de evento versionados (`schemaVersion`), com envelope padrão (id, tipo, ocorrido_em, correlação, versões). Idempotência nos consumidores por `evento_id`.

---

## 6. Modelo de dados de serviço (sql-motor)

```mermaid
erDiagram
  VERSAO_BRP ||--o{ MATRIZ_CENARIOS_PRECO : contem
  VERSAO_BRP ||--o{ POSICAO_PRECO_CLIENTE_PRODUTO : contem
  VERSAO_BRP ||--o{ MATRIZ_RELACIONAMENTO : contem
  VERSAO_BRP ||--o{ INDICADORES_RECIPROCIDADE : contem
  VERSAO_BRP ||--o{ PRECO_VIGENTE_FOTO : contem
  VERSAO_BRP ||--o{ HISTORICO_PRECO : contem
  PARAMETRO_VERSAO ||--o{ PARAMETRO_ITEM : agrupa
  PARAMETRO_VERSAO ||--o{ POLITICA_ALCADA : agrupa
  VERSAO_BRP ||--o{ COTACAO : usada_em
  PARAMETRO_VERSAO ||--o{ COTACAO : usada_em
  COTACAO ||--o| PEDIDO_APROVACAO : gera
  POLITICA_ALCADA ||--o{ PEDIDO_APROVACAO : classifica
  COTACAO ||--o{ ACORDO_RECIPROCIDADE : origina
  ACORDO_RECIPROCIDADE ||--o{ DESVIO_RECIPROCIDADE : monitora
  ONDA_REPRECIFICACAO ||--o{ ONDA_CLIENTE_PRODUTO : inclui
  ONDA_CLIENTE_PRODUTO }o--|| COTACAO : calcula
  AUDITORIA }o--|| PARAMETRO_VERSAO : registra

  VERSAO_BRP {
    string anomes PK
    string status
    datetime dt_carga
    datetime dt_ativacao
    string resumo_qualidade
    string versao_parametros_usada
  }
  MATRIZ_CENARIOS_PRECO {
    string anomes PK
    string cod_produto PK
    string tier PK
    string segmento PK
    string regiao PK
    string cenario_id
    int cluster
    decimal p25
    decimal p50
    decimal p75
    decimal p90
    decimal preco_alvo
    decimal preco_sugerido
    int n
  }
  POSICAO_PRECO_CLIENTE_PRODUTO {
    string anomes PK
    string cd_grupo PK
    string cod_produto PK
    string segmento
    string regiao
    string tier
    int cluster
    string cenario_id
    decimal qtde_mensal
    decimal receita
    decimal tarifa_praticada
    decimal preco_alvo
    decimal preco_sugerido
    decimal uplift
  }
  MATRIZ_RELACIONAMENTO {
    string anomes PK
    string cd_grupo PK
    string stickiness
    string impacto
    decimal share_cash
    decimal share_credito
  }
  INDICADORES_RECIPROCIDADE {
    string anomes PK
    string cd_grupo PK
    string cod_produto PK
    decimal saldo_if_medio
    decimal saldo_dav_medio
    decimal sow_boletos
    decimal emissoes_l3m
  }
  PRECO_VIGENTE_FOTO {
    string anomes PK
    string cd_grupo PK
    string cod_produto PK
    decimal tarifa_vigente
    date dt_referencia
    string origem
  }
  HISTORICO_PRECO {
    string cd_grupo PK
    string cod_produto PK
    string anomes_ref PK
    decimal tarifa
  }
  PARAMETRO_VERSAO {
    uuid versao_id PK
    string escopo
    string status
    datetime vigencia_inicio
    datetime vigencia_fim
    string autor
    string aprovador
  }
  PARAMETRO_ITEM {
    uuid item_id PK
    uuid versao_id FK
    string tipo
    string chave
    string valor_json
  }
  POLITICA_ALCADA {
    uuid politica_id PK
    uuid versao_id FK
    string cod_produto
    string segmento
    decimal desvio_min_pct
    decimal desvio_max_pct
    int nivel
    string papel_aprovador
  }
  COTACAO {
    uuid cotacao_id PK
    datetime dt
    string usuario
    string canal
    string modo
    string cd_grupo
    string cod_produto
    string anomes_brp FK
    uuid versao_parametros FK
    string entrada_json
    string saida_json
    string origem_praticado
    string hash_entrada
  }
  PEDIDO_APROVACAO {
    uuid pedido_id PK
    uuid cotacao_id FK
    int nivel
    string papel_aprovador
    string status
    string decisor
    datetime dt_decisao
  }
  ACORDO_RECIPROCIDADE {
    uuid acordo_id PK
    string cd_grupo
    uuid cotacao_id FK
    string produtos_json
    decimal volumetria_acordada
    decimal saldo_acordado
    date vigencia_inicio
    date vigencia_fim
  }
  DESVIO_RECIPROCIDADE {
    uuid desvio_id PK
    uuid acordo_id FK
    string anomes
    string tipo
    decimal pct_desvio
    string status
  }
  ONDA_REPRECIFICACAO {
    uuid onda_id PK
    string nome
    string status
    string escopo_json
    decimal meta_uplift
    date inicio
  }
  ONDA_CLIENTE_PRODUTO {
    uuid onda_id PK
    string cd_grupo PK
    string cod_produto PK
    uuid cotacao_id FK
    string motivo_elegibilidade
    decimal preco_proposto
    string status
  }
  AUDITORIA {
    bigint seq PK
    datetime dt
    string usuario
    string entidade
    string operacao
    string antes_json
    string depois_json
  }
```

Notas de modelagem:

- `MATRIZ_CENARIOS_PRECO` (Matriz de Cenários de Preço, MPA) chamava-se `matriz_preco_alvo_cluster` na versão 1.0; renomeada na revisão 1.1 porque cada linha é um cenário que carrega `preco_alvo` **e** `preco_sugerido` (mais percentis). `cenario_id` identifica a linha de forma estável dentro do `anomes` e é referenciado pela PPC (cenário em que o cliente caiu no ciclo) e pela resposta da API (`sugerido.cenario_id`). Nenhuma coluna de preço é derivada no sql-motor ou no svc-pricing.
- As entidades da BRP têm `anomes` na chave; a view `v_brp_ativa` filtra o `anomes` com `status = 'ativa'`. Para Azure SQL, particionamento por `anomes` com `SWITCH PARTITION` das tabelas `stg_*` para as tabelas finais viabiliza a ativação atômica.
- `PARAMETRO_ITEM` é apresentado genericamente; na implementação, cada tipo tem tabela própria e tipada (`parametro_item_tier`, `parametro_item_regra_cluster`, `parametro_item_percentil`, `parametro_item_desconto`, `parametro_item_excecao`, `parametro_item_janela`, `catalogo_produto`, `dominio`), todas com `versao_id`. Tabela genérica só para tipos ainda desconhecidos (premissas de remuneração).
- `COTACAO` cresce por uso (estimativa: milhares por dia); partição mensal, coluna JSON, retenção de 24 meses online e exportação para o Delta. É o candidato a reavaliação de armazenamento por evidência (AD-02).
- `AUDITORIA` só recebe INSERT; permissões de banco impedem UPDATE/DELETE pelo usuário da aplicação.
- Entidades `[EVOLUÇÃO]`: `ACORDO_RECIPROCIDADE`, `DESVIO_RECIPROCIDADE`, `ONDA_REPRECIFICACAO`, `ONDA_CLIENTE_PRODUTO`. Índices: por `cd_grupo + cod_produto` em PPC, indicadores, foto e histórico; por `dt` e `cd_grupo` em cotação.

---

## 7. APIs (contratos de alto nível)

Todas expostas no Axway sob `/mpc/v1/...`, JSON, OAuth2 client credentials para o canal + JWT do usuário final (claims de perfil). Versionamento por caminho (`/v1`, `/v2`) com convivência de duas versões e depreciação anunciada no catálogo do Axway; mudanças compatíveis (campos novos) não incrementam versão. Cabeçalhos padrão de resposta: `X-Versao-BRP`, `X-Versao-Parametros`, `X-Correlation-Id`.

**svc-pricing**

| Método e rota | Propósito | Entrada principal | Saída principal |
|---|---|---|---|
| `POST /precos/simulacoes` | Simular preço (RF-01, RF-02, RF-03) | `cd_grupo` ou `cnpj`, `cod_produto`, `volumetria{qtde, unidade}`, `preco_negociado?`, `opcoes{estrategia_vigente, cenarios[]}`, `versoes?` (staging/auditoria) | `praticado{valor, origem, data}`, `alvo`, `sugerido{valor, cenario_id}`, `tier`, `cluster`, `cenarios[]{cenario_id, tipo (cliente, percentil, tier_vizinho), tier, alvo, sugerido, preco, uplift_anual}`, `uplift{pct, valor_anual}`, `alcada{necessaria, nivel, papel_aprovador}`, `cotacao_id`, `versoes{}`. Alvo, sugerido e cenários são lidos da MPA ativa; só `uplift_anual` é calculado |
| `POST /precos/simulacoes/lote` [EVOL] | Cálculo em lote para C2 | lista de itens + `onda_id` | `lote_id` (assíncrono); `GET /precos/simulacoes/lote/{id}` para status/resultado |
| `GET /precos/{grupo}/{produto}/vigente` | Preço praticado vigente (RF-04) | `estrategia=foto|online|auto` | `valor`, `origem`, `data_referencia` |
| `GET /precos/{grupo}/{produto}/historico` | Histórico 12 meses (RF-04) | `meses=12` | lista `{anomes, tarifa}` |
| `GET /precos/{grupo}/{produto}/referencia` | Alvo, sugerido e posição sem simular (consulta rápida, lida da PPC/MPA) | — | `alvo`, `sugerido{valor, cenario_id}`, `tier`, `cluster`, `percentis`, `posicao_atual` |
| `GET /cotacoes/{id}` | Recuperar cotação com versões (RF-09) | — | cotação completa |

**svc-alcada**

| Método e rota | Propósito | Entrada | Saída |
|---|---|---|---|
| `POST /alcadas/avaliacoes` | Classificar desvio em nível e papel (RF-03) | `cod_produto`, `segmento`, `sugerido`, `negociado`, `volume_anual` | `necessaria`, `nivel`, `papel_aprovador`, `uplift_perdido` |
| `POST /alcadas/pedidos` | Abrir pedido de aprovação | `cotacao_id`, `justificativa` | `pedido_id`, `status` |
| `GET /alcadas/pedidos?papel=&status=` | Fila do aprovador | filtros | lista |
| `POST /alcadas/pedidos/{id}/decisao` | Aprovar/recusar | `decisao`, `comentario` | pedido atualizado; evento `PrecoAprovado` |

**svc-parametros**

| Método e rota | Propósito |
|---|---|
| `GET /parametros/versoes?status=&escopo=` / `GET /parametros/versoes/{id}` | Listar/consultar versões e itens |
| `POST /parametros/versoes` | Criar rascunho (clonando a vigente ou vazio) |
| `PUT /parametros/versoes/{id}/itens/{tipo}` | Substituir itens de um tipo no rascunho (lote) |
| `POST /parametros/versoes/{id}/staging` | Enviar a staging |
| `POST /parametros/versoes/{id}/aprovar` | Aprovar (perfil aprovador) |
| `POST /parametros/versoes/{id}/publicar` | Publicar imediata ou `{vigencia_inicio}` agendada (RF-06) |
| `POST /parametros/versoes/{id}/reverter` | Rollback para a anterior |
| `GET /parametros/vigentes?data=&produto=` | Conjunto vigente resolvido (uso interno do svc-pricing e do dbx-ppp) |
| `GET /parametros/versoes/{id}/diff/{outra}` | Comparação entre versões |

**svc-publicacao**

| Método e rota | Propósito |
|---|---|
| `GET /brp/versoes` / `GET /brp/versoes/{anomes}` | Catálogo: status, qualidade, datas |
| `POST /brp/versoes/{anomes}/validar` | Chamado pelo dbx-ppp após reverse ETL; roda checks relacionais |
| `POST /brp/versoes/{anomes}/ativar` | Ativação atômica (perfil publicador); emite `VersaoBrpPublicada` |
| `POST /brp/versoes/{anomes}/reverter` | Reativa a versão anterior |
| `GET /brp/ativa` | `anomes` ativo e resumo |

**svc-legado-adapter** (interno, não exposto no Axway)

| Método e rota | Propósito |
|---|---|
| `GET /legado/precos/{grupo}/{produto}/vigente?estrategia=` | Praticado vigente com origem |
| `GET /legado/precos/{grupo}/{produto}/historico` | 12 meses |
| `POST /legado/tarifas/efetivacoes` [EVOL] | Efetivação de tarifa (se decidido) |

**[EVOLUÇÃO] svc-reciprocidade**: `POST /reciprocidade/acordos`, `GET /reciprocidade/acordos/{id}`, `POST /reciprocidade/monitoramentos` (job), `GET /reciprocidade/desvios?grupo=&status=`, `GET /reciprocidade/elegiveis?onda=`.

**[EVOLUÇÃO] svc-reprecificacao**: `POST /reprecificacao/ondas`, `POST /reprecificacao/ondas/{id}/elegiveis`, `POST /reprecificacao/ondas/{id}/calcular`, `POST /reprecificacao/ondas/{id}/aprovar`, `POST /reprecificacao/ondas/{id}/efetivar`, `GET /reprecificacao/ondas/{id}/acompanhamento`.

---

## 8. Requisitos não funcionais e mecanismos

| RNF | Requisito | Mecanismo | Decisão |
|---|---|---|---|
| RNF-01 | Disponibilidade e contingência (SLA 99,5% e SLO 99,9% em horário comercial; RTO ≤ 30 min; RPO = 0 em `cotacao` e `auditoria`) | Azure SQL zona-redundante + réplica de leitura; 3+ réplicas de svc-pricing em zonas distintas com HPA e PDB no ARO; versão anterior da BRP sempre ativável; Adaptador com fallback foto; Salesforce exibe última cotação conhecida com carimbo; health checks e circuit breakers (Resilience4j) | AD-13, AD-10 |
| RNF-02 | Desempenho (p95 ≤ 300 ms no svc-pricing e ≤ 500 ms no Axway; ≤ 1,5 s percebido na Calculadora; a validar) | Cache Caffeine de parâmetros/MPA/catálogo; índices por chave composta; consultas pontuais por `cd_grupo + cod_produto`; réplica de leitura; timeout de 300 ms no legado online; timeouts de 3 s no Axway e 5 s no Salesforce; teste de carga na F1 com meta de 50 req/s (a validar) | AD-11, AD-02 |
| RNF-03 | Rastreabilidade imutável | `cotacao` e `auditoria` append-only; versões de BRP e parâmetros imutáveis após publicação; permissões de banco sem UPDATE/DELETE; exportação ao Delta | AD-06, AD-12 |
| RNF-04 | Segurança e conformidade | Akamai (WAF/DDoS) → App Gateway (WAF) → Axway (OAuth2, JWT, quotas); mTLS interno opcional no ARO; secrets no Vault/Secrets do OpenShift; perfis via AD/Salesforce; segregação de funções na parametrização; dados de cliente apenas por `cd_grupo` (sem PII além de CNPJ); criptografia em repouso (TDE) | AD-12 |
| RNF-05 | Monitoramento | Padrão ARO: logs centralizados, métricas Prometheus, tracing distribuído com `X-Correlation-Id`; dashboards de latência, erro, versões ativas; alertas do Databricks Workflows e do Control-M; métricas de qualidade da BRP por ciclo | AD-12 |
| RNF-06 | Governança de dados | Fontes permanecem no Databricks (não substituídas); bronze governada; Unity Catalog com lineage; BRP publicada por contrato de dados; reverse ETL só de entidades gold | AD-01, AD-03 |
| RNF-07 | Escalabilidade funcional | Novos produtos/segmentos/regiões via catálogo e domínios em svc-parametros; esqueleto da MPA gerado do catálogo; estratégias de cálculo genéricas por grupo de regra | AD-04, AD-06 |
| RNF-08 | Implantação gradual | Shadow run por produto; feature flag por produto no Salesforce (fonte = legado ou motor); comparação automática; desligamento por produto | AD-14 |
| RNF-09 | Versionamento e reprodutibilidade | Cada cotação grava `anomes_brp`, `versao_parametros`, `hash_entrada`; endpoint aceita versões explícitas para reexecução; Delta time travel | AD-03, AD-06 |
| RNF-10 | Aderência à stack | Todos os componentes na stack, exceto Service Bus (pendente com fallback outbox) | AD-09 |

---

## 9. Ambientes e implantação

| Ambiente | ARO | Azure SQL | Databricks | Salesforce | Uso |
|---|---|---|---|---|---|
| dev | namespace `mpc-dev` | instância dev (dados mascarados) | workspace dev, dados sintéticos/amostra | sandbox dev | Desenvolvimento e testes automatizados |
| homolog | namespace `mpc-hml` | instância hml (cópia mascarada de produção) | workspace hml (ou catálogo `hml` no mesmo workspace) | sandbox parcial/full | Testes integrados, testes de carga, aceite do negócio, shadow run inicial |
| prod | namespace `mpc-prd` | instância prd zona-redundante | workspace prd | produção | Operação |

**Staging de parâmetros não é ambiente**: como descrito na §5.3, "staging" é um estado de versão (dados) avaliado pelo mesmo serviço em produção com cabeçalho de versão candidata. Isso é intencional: o requisito `00-doc-negocio.md:L17` pede testar parametrizações antes de publicar, e a única forma de o teste ser fiel é rodar contra a BRP e o código de produção. Homologação continua existindo para testar **código**; staging testa **parâmetros**.

**CI/CD (premissa)**: assume-se a esteira corporativa existente (repositório Git, build Maven, imagem no registry corporativo, deploy por Helm/ArgoCD ou Tekton no ARO, gates de segurança e qualidade). Cada serviço tem seu pipeline; migrações de banco por Flyway versionadas junto do serviço; contratos de API publicados no Axway a partir do OpenAPI gerado no build. Notebooks/Workflows do Databricks versionados em Git com Databricks Asset Bundles e promovidos dev → hml → prd pela mesma esteira. Metadados Salesforce (LWC, Named Credentials, perfis) via pipeline SFDX. A confirmar na F0 o padrão real da esteira.

**Configuração por ambiente**: URLs de Named Credential, clientes OAuth no Axway, connection strings em Secrets do OpenShift, `anomes` ativo por ambiente (homolog pode apontar para a mesma versão de produção da BRP, copiada, para o shadow).

---

## 10. Transição AS-IS → TO-BE (AD-14)

```mermaid
flowchart LR
  SF["Calculadora Salesforce"] -->|"consulta atual"| S010["Motor da Calculadora SQL 010"]
  SF -.->|"shadow: mesma entrada"| PR["svc-pricing (novo)"]
  S010 --> CMP["Comparador de resultados<br/>(job Databricks: cotacao x SIMUL_* / respostas SQL 010)"]
  PR --> CMP
  CMP --> REL["Relatório por produto:<br/>% concordância, desvio médio, casos discrepantes"]
  REL -->|"critério de corte atingido"| CUT["Flag por produto: fonte = motor"]
  CUT --> SF
  REL -->|"discrepância"| AJ["Ajuste de parâmetros / estratégia<br/>(engenharia reversa continuada)"]
  AJ --> PR
```

1. **Shadow run (F1)**: a LWC chama o SQL 010 (fonte oficial) e, de forma assíncrona, o svc-pricing com a mesma entrada; a resposta do motor não é exibida (ou aparece em aba "prévia" para o grupo piloto). Adicionalmente, um job Databricks reexecuta em lote todas as combinações da PPC contra o motor e contra as tabelas SIMUL_*/saídas do SQL 010 do mesmo `anomes`.
2. **Comparação automática**: por produto e cluster, mede concordância de tier, cluster, alvo e sugerido; tolerância parametrizada (ex.: alvo idêntico em ≥ 99,5% dos casos; sugerido dentro de ±1% em ≥ 98%; nenhuma discrepância em alçada). Casos discrepantes viram backlog de engenharia reversa (R1).
3. **Critérios de corte por produto**: (a) concordância acima do limiar por dois ciclos consecutivos; (b) p95 dentro da meta; (c) piloto de gerentes sem incidentes de preço por 4 semanas; (d) aprovação da Precificação.
4. **Corte**: feature flag por produto no Salesforce (Custom Metadata) muda a fonte para o motor; SAS/SQL 010 seguem carregando por um ciclo como retaguarda.
5. **Rollback**: inverter a flag (minutos); ou, para problema de dados, reativar `anomes` anterior da BRP ou versão anterior de parâmetros (segundos, via svc-publicacao/svc-parametros).

---

## 11. Riscos arquiteturais e decisões pendentes

**Riscos relevantes à arquitetura** (IDs do brief §10)

| ID | Risco | Tratamento arquitetural |
|---|---|---|
| R1 | Regras do sugerido não documentadas | Risco fica no pipeline (etapa `preco_sugerido_cenario` do dbx-ppp) e na parametrização, não no motor online, que só faz lookup (revisão 1.1); enquanto a regra não for levantada, a BRP v1 pode carregar o sugerido importado da Planilha Ano 1 / `SIMUL_PRECO_POR_PRODUTO` do mesmo ciclo; shadow run e comparador (sugerido publicado x SQL 010) como instrumento de descoberta |
| R2 | C2/C3 sem definição | Eventos e reuso do motor já previstos; serviços tracejados não bloqueiam F1/F2 |
| R3 | Qualidade das bases | T0/T9 com contratos de dados e bloqueio de ativação; `qualidade_ciclo` visível |
| R4 | Latência do preço vigente | Adaptador com três estratégias; decisão de negócio na F0 |
| R5 | Service Bus fora da stack | Outbox como fallback com a mesma interface de domínio |
| R6 | Lógica em Apex | Apex apenas proxy; revisão de código; contratos OpenAPI como única fonte de campos calculados |
| R7 | Erro de preço na transição | Shadow, comparador, flag por produto, rollback de versão |
| R8 | Capacidade das equipes | Três frentes independentes (Databricks, Java, Salesforce) com contratos definidos na F0 |
| R9 | Inconsistências entre fluxos | Regras divergentes viram parâmetros por produto com decisão registrada |
| R10 | Governança de publicação | Fluxo de versão com perfis segregados e auditoria |

**Decisões pendentes** (lacunas do brief §8 que afetam a arquitetura)

| # | Decisão | Dono | Impacto se não decidida |
|---|---|---|---|
| P1 | Regras da macro e do SQL 010 (lacuna 1) | Precificação + TI legado | Bloqueia a geração do `preco_sugerido` por cenário no pipeline (BRP v1); o motor pode subir com o sugerido importado da planilha do ciclo |
| P2 | Conteúdo de `premissas_*`, `tier_por_produto`, `regiao_por_ge` (lacuna 2) | Precificação | Bloqueia catálogo de parâmetros |
| P3 | Definição formal de alvo x sugerido e níveis/aprovadores de alçada (lacuna 3) | Precificação + Comercial | Bloqueia svc-alcada |
| P4 | Motor efetiva tarifa no legado ou só recomenda (lacuna 4) | Negócio + dono do legado | Define escopo de svc-legado-adapter em C2 |
| P5 | Latência aceitável do preço vigente: foto x online (lacuna 7) | Negócio | Define conector ao legado e SLA |
| P6 | Service Bus aprovado na stack (lacuna 9) | Arquitetura corporativa | Outbox como fallback |
| P7 | Onde o acordo de reciprocidade é registrado hoje (lacuna 4) | Comercial | Modelo de `acordo_reciprocidade` |
| P8 | INSTITUCIONAL, cluster de Arrecadação, grupo 616 (lacuna 5) | Precificação | Parâmetros por produto |
| P9 | Padrão de CI/CD e de conector ao legado | TI | Premissas da §9 |
| P10 | Retenção de cotações e versões online | Precificação + Jurídico/Compliance | Política de expurgo |

---

## 12. Registro de decisões (ADR resumido)

| ID | Decisão | Alternativas consideradas | Consequências | Requisitos |
|---|---|---|---|---|
| AD-01 | Preparação de dados em Databricks Workflows (PySpark/Delta), 7 notebooks portados como tarefas; Control-M apenas dispara | Microsserviços Python no ARO schedulados por Control-M (extração via JDBC/Delta Sharing/export) | Dado processado onde está; versionamento nativo; time de precificação segue em Python; Control-M sem orquestração interna | RF-08, RF-13, RNF-06, RNF-09 |
| AD-02 | Azure SQL Database como base de serviço do motor, carregada por reverse ETL | MongoDB | Modelo relacional para matrizes e parâmetros; integridade de versão no banco; reavaliar só para `cotacao` por volume | RF-01, RF-05, RNF-02, RNF-10 |
| AD-03 | Reverse ETL por JDBC em staging + procedure de ativação atômica por `anomes` | Azure Data Factory (equivalente, se padrão da área) | Ativação e rollback em segundos; versão anterior íntegra; validação antes de ativar | RF-13, RNF-01, RNF-09 |
| AD-04 | Núcleo em microsserviços Java (Spring Boot) no ARO; regras como parâmetros + estratégias de classificação; o motor consulta alvo e sugerido pré-computados na BRP e não é engine de fórmulas de desconto (revisão 1.1) | FICO Blaze/DM | Sem licença/lock-in; skill disponível; com o sugerido vindo da BRP, a lógica online se reduz a tier, cluster, lookup, uplift e alçada, o que reforça a escolha por Java + tabelas; FICO reavaliável na F3 se gradação de C2 exigir | RF-01..RF-03, RNF-07, RNF-10 |
| AD-05 | Salesforce FSC como canal (LWC + Named Credentials); zero lógica em Apex | Front React próprio para parametrização | Um front, um modelo de acesso; APIs únicas para todos os canais | RF-07, RNF-04 |
| AD-06 | svc-parametros com versão, status, vigência agendada, auditoria; staging lógico via cabeçalho de versão candidata | Parâmetros em arquivo/configmap | Governança completa; teste de parâmetro fiel à produção sem ambiente extra | RF-05, RF-06, RF-09, RF-10, RNF-09 |
| AD-07 | Reciprocidade como serviço Java + job Control-M comparando acordo x indicadores da BRP; publica eventos | Dentro do pipeline Databricks | Acordo transacional e auditável; integração com gerente | RF-12 |
| AD-08 | Reprecificação como serviço Java orquestrando onda, com cálculo em lote reusando svc-pricing; elegíveis pré-computados no Databricks | Tudo no Databricks | Mesma versão/auditoria do C1; workflow de aprovação | RF-11 |
| AD-09 | Azure Service Bus para eventos de domínio; fallback outbox + polling | REST síncrono entre C3 e C2 | Desacoplamento temporal; dependência de validação da stack | RF-11, RF-12, RNF-05 |
| AD-10 | Adaptador de Legado com estratégias foto/online/auto | Só foto; só online | Frescor negociável pelo negócio; resiliência a indisponibilidade do legado | RF-04, RNF-01 |
| AD-11 | Cache Caffeine por instância; sem Redis | Redis | Simplicidade; invalidação por evento/polling; Redis só por evidência | RNF-02 |
| AD-12 | Observabilidade e segurança padrão ARO; OAuth2 no Axway; auditoria append-only | — | Aderência a padrões; menor esforço | RNF-03, RNF-04, RNF-05 |
| AD-13 | Contingência: SQL zona-redundante, réplicas, versão anterior da BRP, última cotação conhecida no canal | — | Motor offline degrada com informação, não com erro | RNF-01 |
| AD-14 | Transição em shadow por produto com comparação automática e flag de fonte | Big bang | Descoberta de regras, corte seguro, rollback em minutos | RNF-08 |

**Alternativas registradas sem alterar a decisão**: Azure Data Factory para o reverse ETL (AD-03); Redis compartilhado se o cache por instância gerar inconsistência perceptível entre réplicas após publicação (AD-11); armazenamento de `cotacao` em Cosmos DB/Mongo se o volume ultrapassar o confortável para Azure SQL (AD-02); FICO para gradação de C2 (AD-04).
